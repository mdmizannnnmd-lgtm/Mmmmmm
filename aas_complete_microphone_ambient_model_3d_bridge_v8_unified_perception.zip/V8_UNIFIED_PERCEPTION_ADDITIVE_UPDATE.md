# v8 — Unified Perception & Entity State (additive)

This update adds three standalone Kotlin components in `com.mizan`:

- `UnifiedPerceptionEngine`: combines existing `HumanDetection` camera results and `MicSignalEvent` signal features into a timestamped, smoothed snapshot.
- `EntityStateBus`: publishes a bounded, thread-safe primary entity state for downstream renderers/controllers.
- `PerceptionBehaviorController`: derives deterministic IDLE / ATTENDING / AUDIO_REACTIVE / TRACKING modes.

## Integration sketch

```kotlin
val perception = UnifiedPerceptionEngine()
val entityBus = EntityStateBus()
val behavior = PerceptionBehaviorController()

// Camera callback:
perception.onCamera(detection)
// Existing microphone event callback:
perception.onMicrophone(micEvent)
// On a periodic UI/animation tick:
val snapshot = perception.tick()
entityBus.publish(EntityStateBus.EntityState(
    visible = snapshot.personPresent,
    confidence = snapshot.cameraConfidence,
    x = snapshot.centerX,
    y = snapshot.centerY,
    attention = snapshot.attention,
    audioActivity = snapshot.audioLevel,
    updatedAtMs = snapshot.timestampMs
))
val mode = behavior.update(snapshot).mode
```

All changes are additive. Existing v7 files and app entry points are preserved; the new modules are not automatically wired into the UI, so downstream integration should be performed deliberately and tested on-device. Mic level and camera confidence are signal features, not speech recognition, identity recognition, or proof of a person beyond the camera detector's result.
