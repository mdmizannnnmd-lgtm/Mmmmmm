/* LEGACY STUB — NOT COMPILED. Real functional bridge: app/src/main/cpp/jni_bridge.cpp (2095+ JNI exports). Do not link this file. */
