# Microphone → Ambient / Model / 3D Bridge

This additive layer keeps the existing microphone, camera, sensor, ambient, model,
and 3D paths intact.

## Flow

`AudioRecord → AudioProcessor → RawMicBus → MicSignalBridge → subscribers`

The bridge emits signal-feature events:

- `FRAME` — every published microphone frame
- `SILENCE` — below configurable dBFS threshold
- `ACTIVE` — above configurable dBFS threshold
- `BURST` — peak above configurable threshold
- `LOW_FREQUENCY` / `MID_FREQUENCY` / `HIGH_FREQUENCY`
- `TONE_LIKE` — dominant and centroid frequency are close

## Important boundary

These events are acoustic signal features. They are **not** speech recognition,
person identification, object detection, or proof that a particular sound source
exists. Camera/AI/3D systems can subscribe to these events as control inputs while
continuing to use their existing camera/sensor/model inputs.

## Example subscriber

```kotlin
private val micBridge = MicSignalBridge.subscribe { event ->
    when (event.type) {
        MicSignalEvent.Type.ACTIVE -> { /* update ambient/model/3D state */ }
        MicSignalEvent.Type.SILENCE -> { /* reduce activity */ }
        MicSignalEvent.Type.BURST -> { /* trigger safe visual/audio indication */ }
        else -> Unit
    }
}

override fun onDestroy() {
    micBridge.close()
    super.onDestroy()
}
```

## Thresholds

Use `MicSignalSettings` for runtime thresholds. Defaults are intentionally conservative
and operate on dBFS/PCM features, not calibrated acoustic SPL.
