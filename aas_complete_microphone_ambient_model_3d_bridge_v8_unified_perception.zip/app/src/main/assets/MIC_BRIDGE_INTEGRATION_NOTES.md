# Integration map

Existing components remain the source of truth for their own domains:

- Microphone: `AudioProcessor` / `RawMicBus`
- Camera: existing camera and ONNX/YOLO paths
- Sensors: existing sensor hubs
- Ambient: existing ambient boards/panels
- Model/3D: existing anatomy/model/rendering boards

New `MicSignalBridge` is a fan-out control/event layer. It does not open another
microphone, replace camera inference, or modify 3D rendering internals.

Recommended adoption order:

1. Ambient boards subscribe first for level/activity visualization.
2. Model boards subscribe for non-destructive state changes.
3. 3D boards subscribe for animation/intensity parameters.
4. Camera/AI boards may combine mic events with their existing visual results.
5. Keep all subscriptions lifecycle-bound and close them when a board/view is destroyed.
