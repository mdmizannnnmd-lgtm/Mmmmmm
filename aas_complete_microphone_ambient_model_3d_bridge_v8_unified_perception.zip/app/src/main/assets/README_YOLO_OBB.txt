YOLO OBB + Pose complete (SenseGuard)
=====================================
POSE: COCO-WholeBody / DWPose = 133 keypoints
  body+feet 23 · face 68 · left hand 21 · right hand 21
  See WholeBodyPose133.kt

OBB (oriented box) on-device models — place ONE of:
  yolo26x-obb.onnx   (preferred)
  yolo11x-obb.onnx
  yolo26x-obb.tflite

Export from PyTorch:
  yolo export model=yolo26x-obb.pt format=onnx

.pt does NOT run natively on Android.
Classes: person, mobile, bike, car, helicopter, airplane, laptop,
computer, cycle, rickshaw, device, bus, truck, boat, ship
(See YoloObbCatalog.kt)

ANATOMY: teaching complete human (skin·eyes·organs·pose anchors)
Full medical atlases use ~2,000–2,900 meshes — not required for real-time.
