Camera detection notes

This source archive does not contain yolo26x-seg.onnx. The previous tryLoadModel()
implementation only set a boolean and did not load or run a model.

The app now uses Google ML Kit's accurate pose detector and selfie person
segmentation on camera preview frames. It feeds 33-point pose confidence,
foreground-mask bounds, and ten landmark-derived body-region confidence values
into the existing pose/body-surface systems. Frames are processed on-device and
are not saved or uploaded by this feature.

The segmentation model may require Google Play services to fetch its model the
first time it runs. A network connection may be needed for that first run.
This is not a YOLO model and is not a medical-grade 3D reconstruction: the
existing procedural inside/outside anatomy model remains a stylized visual
model, with camera pose/mask confidence driving its live body signals.
