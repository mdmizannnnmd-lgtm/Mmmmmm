PT / PTL runtime (SenseGuard complete)
======================================
Place TorchScript models in assets/:

  yolo26x-seg.pt   yolo26x-obb.pt   skin-seg.pt   human-parse.pt
  or Lite: *.ptl

Export from Ultralytics / PyTorch:
  yolo export model=yolo26x-seg.pt format=torchscript
  # or ONNX (recommended on Android without pytorch_android):
  yolo export model=yolo26x-seg.pt format=onnx

App behavior:
  1) PtModelRuntime.scanAssets + materialize to filesDir
  2) If org.pytorch:pytorch_android is on classpath → Module.load(.pt)
  3) Else file is staged; use ONNX/TFLite + ML Kit for inference

Raw training .pth state_dict alone will NOT run — must be TorchScript.
