package com.mizan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * CRITICAL: After Context.startForegroundService(), startForeground() must run within ~5s
 * or Android throws ForegroundServiceDidNotStartInTimeException.
 *
 * Strategy: call startForeground() as the very first statement in onCreate/onStartCommand
 * with the simplest notification + a type that does not require camera/mic runtime grants
 * (MEDIA_PLAYBACK). Then optionally re-promote with camera|mic if those are granted.
 */
class ForegroundSenseService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    @Volatile private var foregroundStarted = false

    override fun onCreate() {
        // MUST be before super-side effects and any permission logic
        forceStartForeground("onCreate")
        super.onCreate()
        running = true
        // Optional upgrade to camera|mic types if granted
        tryUpgradeTypes()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        forceStartForeground("onStartCommand")
        if (intent?.action == ACTION_STOP) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } else {
                    @Suppress("DEPRECATION")
                    stopForeground(true)
                }
            } catch (_: Exception) {}
            running = false
            promoted = false
            foregroundStarted = false
            stopSelf()
            return START_NOT_STICKY
        }
        tryUpgradeTypes()
        return START_NOT_STICKY
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                val ch = NotificationChannel(
                    CHANNEL_ID,
                    "SenseGuard",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
                ch.setSound(null, null)
                ch.enableVibration(false)
                ch.setShowBadge(false)
                nm.createNotificationChannel(ch)
            }
        } catch (_: Exception) {}
    }

    private fun minimalNotification(): Notification {
        ensureChannel()
        return try {
            val pi = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("SenseGuard Ultimate")
                .setContentText("Service active")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
                .build()
        } catch (_: Exception) {
            ensureChannel()
            val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, CHANNEL_ID)
            } else {
                @Suppress("DEPRECATION") Notification.Builder(this)
            }
            b.setContentTitle("SenseGuard")
                .setContentText("Active")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .build()
        }
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == android.content.pm.PackageManager.PERMISSION_GRANTED

    /**
     * Unconditional startForeground — never return without having attempted it.
     * Prefer MEDIA_PLAYBACK (declared in manifest, no cam/mic grant required).
     */
    private fun forceStartForeground(from: String) {
        if (foregroundStarted) return
        val notif = minimalNotification()
        val errors = StringBuilder()

        fun tryFg(label: String, type: Int?): Boolean {
            return try {
                when {
                    type != null && Build.VERSION.SDK_INT >= 29 ->
                        startForeground(NOTIF_ID, notif, type)
                    else ->
                        startForeground(NOTIF_ID, notif)
                }
                true
            } catch (e: Exception) {
                errors.append(label).append(':').append(e.javaClass.simpleName)
                    .append('(').append(e.message).append("); ")
                false
            }
        }

        var ok = false
        // 1) mediaPlayback first — works without camera/mic runtime permission
        if (Build.VERSION.SDK_INT >= 29) {
            ok = tryFg("media", ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        }
        // 2) shortService on 34+
        if (!ok && Build.VERSION.SDK_INT >= 34) {
            try {
                val shortType = ServiceInfo::class.java
                    .getField("FOREGROUND_SERVICE_TYPE_SHORT_SERVICE").getInt(null)
                ok = tryFg("short", shortType)
            } catch (_: Exception) {}
        }
        // 3) camera|mic if already granted
        if (!ok && Build.VERSION.SDK_INT >= 29) {
            var t = 0
            if (granted(android.Manifest.permission.CAMERA))
                t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (granted(android.Manifest.permission.RECORD_AUDIO))
                t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (t != 0) ok = tryFg("cammic", t)
        }
        // 4) untyped
        if (!ok) ok = tryFg("untyped", null)

        if (ok) {
            foregroundStarted = true
            promoted = true
            lastError = null
        } else {
            lastError = "forceStartForeground failed from=$from $errors"
            // Still mark something so we don't loop forever; stopSelf to avoid timeout zombie
            try { stopSelf() } catch (_: Exception) {}
        }
    }

    private fun tryUpgradeTypes() {
        if (Build.VERSION.SDK_INT < 29) return
        var t = 0
        if (granted(android.Manifest.permission.CAMERA))
            t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        if (granted(android.Manifest.permission.RECORD_AUDIO))
            t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (t == 0) return
        t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        try {
            startForeground(NOTIF_ID, minimalNotification(), t)
            promoted = true
            foregroundStarted = true
        } catch (e: Exception) {
            lastError = "upgrade: ${e.message}"
        }
    }

    override fun onDestroy() {
        running = false
        promoted = false
        foregroundStarted = false
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "senseguard_fg"
        const val NOTIF_ID = 7101
        const val ACTION_STOP = "com.mizan.action.STOP_FG"
        @Volatile var running = false
        @Volatile var promoted = false
        @Volatile var lastError: String? = null
    }
}
