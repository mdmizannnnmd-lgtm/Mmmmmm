package com.mizan

import kotlin.math.exp
import kotlin.math.max

/**
 * BODY MOTION — vertical movement, rotation and tilt for every body-related model (3D anatomy, brain, face lines,
 * rings + balls, all of which share the anatomy turntable), each with LEVEL · THRESHOLD · BIPOLAR and CENTERING.
 *
 * Bipolar around the threshold: signal ABOVE the threshold pushes the positive way (up / turn right / tilt back),
 * signal BELOW it pushes the negative way (down / turn left / tilt forward); at the threshold the body is exactly centred.
 * With bipolar OFF only the positive side moves. [centerPull] eases every offset back to the centre between moves,
 * [centerAll] snaps position, yaw and tilt back to the centre. RAW COMPLETE: no threshold, level or smoothing — the raw
 * signal is mapped straight onto the offset.
 *
 * Offsets are small additions on top of the board's own posY / yaw / tilt, so the existing sliders keep working.
 */
class BodyMotionHub {

    class Axis(val thr0: Float, val range0: Float) {
        @Volatile var on = true
        @Volatile var thr = thr0           // 0..1 centre point of the bipolar drive
        @Volatile var level = 0.8f         // 0..1 how much of the drive is used
        @Volatile var range = range0       // max offset (screen height fraction for vertical, radians for rotation)
        @Volatile var bipolar = true
        @Volatile var attackMs = 80
        @Volatile var releaseMs = 300
        @Volatile var out = 0f             // signed −1..+1 after level + smoothing
            internal set
        @Volatile var drive = 0f           // signed −1..+1 before smoothing
            internal set

        fun step(src: Float, dt: Float, raw: Boolean, pull: Float, centered: Boolean = true) {
            if (!on) { out = 0f; drive = 0f; return }
            val t = thr.coerceIn(0.02f, 0.98f)
            val s = src.coerceIn(0f, 1f)
            drive = if (!centered) s
            else if (raw) (s * 2f - 1f)
            else if (s >= t) (s - t) / (1f - t)
            else if (bipolar) -(t - s) / t
            else 0f
            val target = (if (raw) drive else drive * level.coerceIn(0f, 1f)).coerceIn(-1f, 1f)
            if (raw) { out = target; return }
            val rising = kotlin.math.abs(target) > kotlin.math.abs(out)
            val ms = (if (rising) attackMs else releaseMs).coerceIn(1, 5000) / 1000f
            out += (target - out) * (1f - exp(-dt / ms))
            // centre pull: eases back to centre while the drive is small
            if (kotlin.math.abs(target) < 0.08f) out *= (1f - pull.coerceIn(0f, 1f) * (1f - exp(-dt / 0.25f)))
            out = out.coerceIn(-1f, 1f)
        }
    }

    @Volatile var enabled = true
    @Volatile var centered = true            // 0 offset = body centre
    @Volatile var centerPull = 0.5f
    @Volatile var wMotion = 0.7f             // source mix: device motion
    @Volatile var wField = 0.7f              // source mix: oneness field (brain · anatomy · rings · sound)
    @Volatile var rawAll = false

    val vertical = Axis(0.30f, 0.06f)
    val yaw = Axis(0.30f, 0.60f)
    val tilt = Axis(0.30f, 0.25f)

    @Volatile var vOffset = 0f               // add to posY (fraction of view height)
        private set
    @Volatile var yawOffset = 0f             // add to yaw (radians)
        private set
    @Volatile var tiltOffset = 0f            // add to tilt (radians)
        private set

    private var lastMs = 0L

    fun tick(v: VisualShieldView) {
        val now = System.currentTimeMillis()
        val dt = if (lastMs == 0L) 0.02f else ((now - lastMs) / 1000f).coerceIn(0.001f, 0.2f)
        lastMs = now
        if (!enabled) { vOffset = 0f; yawOffset = 0f; tiltOffset = 0f; return }
        val motion = (v.motionHub?.liveMove ?: 0f).coerceIn(0f, 1f)
        val field = v.oneness.field
        val src = max(max(motion * wMotion, field * wField), v.cenDrive.moveOut).coerceIn(0f, 1f)
        val raw = rawAll
        // vertical follows the overall energy; yaw follows left/right brain balance; tilt follows inside vs outside
        val lr = (v.brain3d.right.out - v.brain3d.left.out)           // −1..+1
        val yawSrc = (0.5f + 0.5f * lr * (0.5f + src)).coerceIn(0f, 1f)
        val tiltSrc = (0.5f + 0.5f * (v.anatomy3d.inside.out - v.anatomy3d.outside.out)).coerceIn(0f, 1f)
        vertical.step(src, dt, raw, centerPull, centered)
        yaw.step(yawSrc, dt, raw, centerPull, centered)
        tilt.step(tiltSrc, dt, raw, centerPull, centered)
        vOffset = -vertical.out * vertical.range + v.cenDrive.vOffsetBias   // screen y grows downward → positive drive moves UP
        yawOffset = yaw.out * yaw.range
        tiltOffset = tilt.out * tilt.range
    }

    /** Snap every body model back to the centre: position, yaw, tilt and all motion offsets. */
    fun centerAll(v: VisualShieldView) {
        vertical.out = 0f; yaw.out = 0f; tilt.out = 0f
        vOffset = 0f; yawOffset = 0f; tiltOffset = 0f
        v.anatomy3d.posX = 0.5f
        v.anatomy3d.posY = 0.60f
        v.anatomy3d.yaw = 0f
        v.anatomy3d.tilt = 0.10f
        v.brain3d.yaw = 0f
        v.brain3d.tilt = 0.18f
    }

    fun statusLine(): String {
        if (!enabled) return "BODY MOTION off"
        return "BODY MOTION · vert ${"%+.0f".format(vertical.out * 100)}% · rot ${"%+.0f".format(yaw.out * 100)}% · " +
            "tilt ${"%+.0f".format(tilt.out * 100)}%" + (if (centered) " · CENTRED" else "") + (if (rawAll) " · RAW" else "")
    }
}
