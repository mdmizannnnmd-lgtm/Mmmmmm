package com.mizan

/**
 * Optional on-device acoustic level alert.
 *
 * It combines microphone peak dBFS with spectral centroid as a generic sound cue.
 * It does not identify weapons, injury, an electrical shock, or the sound's source.
 */
class AmbientSoundAlert {
    @Volatile var enabled = false
    @Volatile var minimumPeakDbfs = -24f
    @Volatile var minimumCentroidHz = 2500f

    @Volatile var livePeakDbfs = -90.0
        private set
    @Volatile var liveCentroidHz = 0f
        private set
    @Volatile var eventCount = 0
        private set
    @Volatile var lastEventAtMs = 0L
        private set

    private var armed = true

    /**
     * Returns true only when a new threshold crossing is accepted.
     * Measurements are kept transiently in memory and are not recorded.
     */
    @Synchronized
    fun update(peakDbfs: Double, centroidHz: Float, nowMs: Long = System.currentTimeMillis()): Boolean {
        livePeakDbfs = peakDbfs.coerceIn(-120.0, 0.0)
        liveCentroidHz = centroidHz.coerceIn(0f, 20000f)

        if (!enabled) {
            armed = true
            return false
        }

        val peakLimit = minimumPeakDbfs.coerceIn(-90f, -3f)
        val centroidLimit = minimumCentroidHz.coerceIn(250f, 10000f)
        if (livePeakDbfs < (peakLimit - 5f).toDouble() || liveCentroidHz < centroidLimit * 0.80f) {
            armed = true
        }

        val candidate = livePeakDbfs >= peakLimit && liveCentroidHz >= centroidLimit
        if (!candidate || !armed) return false

        // Consume this crossing even if the cooldown suppresses it, preventing a
        // sustained sound from alerting repeatedly when the cooldown expires.
        armed = false
        if (lastEventAtMs != 0L && nowMs - lastEventAtMs < 1500L) return false

        lastEventAtMs = nowMs
        eventCount++
        return true
    }

    fun statusLine(nowMs: Long = System.currentTimeMillis()): String {
        val state = when {
            !enabled -> "OFF"
            lastEventAtMs != 0L && nowMs >= lastEventAtMs && nowMs - lastEventAtMs <= 1800L ->
                "HIGH-FREQUENCY SOUND · UNCLASSIFIED"
            else -> "ARMED · UNCLASSIFIED"
        }
        return "$state · peak ${"%.1f".format(livePeakDbfs)} dBFS · centroid ${liveCentroidHz.toInt()} Hz · alerts $eventCount"
    }
}
