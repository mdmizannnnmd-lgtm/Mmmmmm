package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object EyeBodyAtomspareSurfacePanels {
    fun build(ctx: Context, root: LinearLayout, b: EyeBodyAtomspareSurfaceBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF26C6DA.toInt()
        p.title("EYES L/R FULL BODY LINK · EYE↔OTHER-SELF VISUAL COMM · WEAPON 3D", c)
        p.note("Eyes fully linked to whole body · eye visual ICT with other self · weapons 3D")
        p.switch("ON", b.enabled) { b.enabled = it }
        p.switch("RAW", b.rawComplete) { b.rawComplete = it }
        p.switch("Dual-self white", b.dualSelfOn) { b.dualSelfOn = it }
        p.seek("Thr", 0.05f, 0.9f, b.thr) { b.thr = it }
        p.seek("Dual-comm thr", 0.05f, 0.9f, b.dualCommThr) { b.dualCommThr = it }
        p.seek("Level", 0.2f, 1.5f, b.levelAmt) { b.levelAmt = it }
        val st = p.status("EYE-BODY-ATOM —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() {
                st.text = b.status
                Handler(Looper.getMainLooper()).postDelayed(this, 300)
            }
        })
    }
}
