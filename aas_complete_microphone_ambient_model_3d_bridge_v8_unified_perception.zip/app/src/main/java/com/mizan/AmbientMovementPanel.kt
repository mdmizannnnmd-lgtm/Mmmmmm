package com.mizan

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

/** Controls for the ambient threshold's MOVEMENT output ([AmbientMovement]) — remembered between runs. */
object AmbientMovementPanel {
    private const val P = "ambmove_"

    fun build(ctx: Context, root: LinearLayout, m: AmbientMovement) {
        val p = PanelBuilder(ctx, root)
        val coral = Color.rgb(0xFF, 0xAB, 0x91)
        val teal = Color.rgb(0x80, 0xCB, 0xC4)
        val violet = Color.rgb(0xCE, 0x93, 0xD8)

        m.on = MemoryPaths.getBool(P + "on", m.on)
        m.raw = MemoryPaths.getBool(P + "raw", m.raw)
        m.level = MemoryPaths.getFloat(P + "lv", m.level)
        m.thr = MemoryPaths.getFloat(P + "thr", m.thr)
        m.bipolar = MemoryPaths.getBool(P + "bip", m.bipolar)
        m.negGain = MemoryPaths.getFloat(P + "neg", m.negGain)
        m.posGain = MemoryPaths.getFloat(P + "pos", m.posGain)
        m.attackMs = MemoryPaths.getFloat(P + "atk", m.attackMs.toFloat()).toInt()
        m.releaseMs = MemoryPaths.getFloat(P + "rel", m.releaseMs.toFloat()).toInt()
        m.wDevice = MemoryPaths.getFloat(P + "w_dev", m.wDevice)
        m.wBody = MemoryPaths.getFloat(P + "w_body", m.wBody)
        m.wAmbient = MemoryPaths.getFloat(P + "w_amb", m.wAmbient)
        m.wCamera = MemoryPaths.getFloat(P + "w_cam", m.wCamera)
        m.insideOn = MemoryPaths.getBool(P + "in_on", m.insideOn)
        m.outsideOn = MemoryPaths.getBool(P + "out_on", m.outsideOn)
        m.insideAmt = MemoryPaths.getFloat(P + "in_amt", m.insideAmt)
        m.outsideAmt = MemoryPaths.getFloat(P + "out_amt", m.outsideAmt)
        m.rangeIn = MemoryPaths.getFloat(P + "in_rng", m.rangeIn)
        m.rangeOut = MemoryPaths.getFloat(P + "out_rng", m.rangeOut)

        p.title("AMBIENT THRESHOLD · MOVEMENT OUTPUT → 3D ANATOMY BODY (INSIDE + OUTSIDE)", coral)
        p.note("Movement = device motion · body centroid speed · ambient level over the threshold · camera body. Above the threshold the body lifts and leans into the move, below it sinks (bipolar, each rail with its own gain). OUTSIDE moves the whole body (skin · muscle · face); INSIDE (skeleton · organs · vessels · brain) moves on top of it and lags like soft tissue. RAW COMPLETE sends the live movement straight to the body — no level, threshold or smoothing.")
        p.switch("MOVEMENT output ON", m.on) { m.on = it; MemoryPaths.putBool(P + "on", it) }
        p.switch("MOVEMENT RAW COMPLETE", m.raw) { m.raw = it; MemoryPaths.putBool(P + "raw", it) }
        p.seek("Movement level", 0f, 1.5f, m.level) { m.level = it; MemoryPaths.putFloat(P + "lv", it) }
        p.seek("Movement threshold (neutral point)", 0.02f, 0.98f, m.thr) { m.thr = it; MemoryPaths.putFloat(P + "thr", it) }
        p.switch("Movement BIPOLAR (below the threshold pushes the other way)", m.bipolar) { m.bipolar = it; MemoryPaths.putBool(P + "bip", it) }
        p.seek("Rail below threshold gain (−)", 0f, 1.5f, m.negGain) { m.negGain = it; MemoryPaths.putFloat(P + "neg", it) }
        p.seek("Rail above threshold gain (+)", 0f, 1.5f, m.posGain) { m.posGain = it; MemoryPaths.putFloat(P + "pos", it) }
        p.seek("Attack (ms)", 1f, 1000f, m.attackMs.toFloat(), 0) { m.attackMs = it.toInt(); MemoryPaths.putFloat(P + "atk", it) }
        p.seek("Release (ms)", 1f, 3000f, m.releaseMs.toFloat(), 0) { m.releaseMs = it.toInt(); MemoryPaths.putFloat(P + "rel", it) }

        p.title("MOVEMENT SOURCES (mix)", teal)
        p.seek("Device motion (accelerometer · gyro)", 0f, 1.5f, m.wDevice) { m.wDevice = it; MemoryPaths.putFloat(P + "w_dev", it) }
        p.seek("Body centroid speed", 0f, 1.5f, m.wBody) { m.wBody = it; MemoryPaths.putFloat(P + "w_body", it) }
        p.seek("Ambient level over threshold", 0f, 1.5f, m.wAmbient) { m.wAmbient = it; MemoryPaths.putFloat(P + "w_amb", it) }
        p.seek("Camera body (pose · segmentation)", 0f, 1.5f, m.wCamera) { m.wCamera = it; MemoryPaths.putFloat(P + "w_cam", it) }

        p.title("OUTSIDE — whole body moves (skin · muscle · face)", coral)
        p.switch("Movement → OUTSIDE ON", m.outsideOn) { m.outsideOn = it; MemoryPaths.putBool(P + "out_on", it) }
        p.seek("Outside amount", 0f, 2f, m.outsideAmt) { m.outsideAmt = it; MemoryPaths.putFloat(P + "out_amt", it) }
        p.seek("Outside range (view fraction)", 0f, 0.15f, m.rangeOut, 3) { m.rangeOut = it; MemoryPaths.putFloat(P + "out_rng", it) }

        p.title("INSIDE — skeleton · organs · vessels · brain", violet)
        p.switch("Movement → INSIDE ON", m.insideOn) { m.insideOn = it; MemoryPaths.putBool(P + "in_on", it) }
        p.seek("Inside amount", 0f, 2f, m.insideAmt) { m.insideAmt = it; MemoryPaths.putFloat(P + "in_amt", it) }
        p.seek("Inside range (body units)", 0f, 0.4f, m.rangeIn, 3) { m.rangeIn = it; MemoryPaths.putFloat(P + "in_rng", it) }
        p.note("Locked mode (body fixed centre) keeps the outside still; the inside keeps its own lock under LOCKED INSIDE ROTATION.")

        val st = p.status("MOVE —", coral)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = m.statusLine(); h.postDelayed(this, 200) }
        })
    }
}
