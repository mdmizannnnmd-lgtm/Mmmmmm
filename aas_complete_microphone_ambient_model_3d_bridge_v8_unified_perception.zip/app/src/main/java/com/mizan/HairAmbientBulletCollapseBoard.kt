package com.mizan

/**
 * Hair ambient (draw) · bullet collapse sounds · live mic counters · auto threshold ·
 * model-driven · head front/up/down/left/right ambient. Defaults ON. RAW COMPLETE.
 */
class HairAmbientBulletCollapseBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // ── Hair ambient (visual draw energy) ──
    @Volatile var hairOn = true
    @Volatile var hairThr = 0.25f
    @Volatile var hairLv = 0.75f
    @Volatile var hairOut = 0f
    @Volatile var hairAutoThr = true
    @Volatile var hairAutoThrVal = 0.25f

    // ── Bullet collapse sounds (our own · live mic · model driven) ──
    @Volatile var bulletCollapseOn = true
    @Volatile var bulletCollapseThr = 0.28f
    @Volatile var bulletCollapseLv = 0.80f
    @Volatile var bulletCollapseOut = 0f
    @Volatile var bulletCollapseAutoThr = true
    @Volatile var bulletCollapseAutoThrVal = 0.28f
    @Volatile var bulletCollapseActive = false

    // Counters — our own bullet sounds
    @Volatile var bulletSoundCount = 0
    @Volatile var bulletCollapseCount = 0
    @Volatile var bulletHitCount = 0
    @Volatile var bulletSoundRate = 0f  // hits per recent window
    private var lastBulletMs = 0L
    private var windowHits = 0
    private var windowStartMs = 0L

    // Live mic analysis
    @Volatile var liveMicE = 0f
    @Volatile var autoThrAnalysis = 0.28f

    // Head ambient sides — all default ON
    @Volatile var headFrontOn = true
    @Volatile var headFrontThr = 0.25f
    @Volatile var headFrontLv = 0.75f
    @Volatile var headFrontOut = 0f

    @Volatile var headUpOn = true
    @Volatile var headUpThr = 0.25f
    @Volatile var headUpLv = 0.75f
    @Volatile var headUpOut = 0f

    @Volatile var headDownOn = true
    @Volatile var headDownThr = 0.25f
    @Volatile var headDownLv = 0.75f
    @Volatile var headDownOut = 0f

    @Volatile var headLeftOn = true
    @Volatile var headLeftThr = 0.25f
    @Volatile var headLeftLv = 0.75f
    @Volatile var headLeftOut = 0f

    @Volatile var headRightOn = true
    @Volatile var headRightThr = 0.25f
    @Volatile var headRightLv = 0.75f
    @Volatile var headRightOut = 0f

    @Volatile var status = "HAIR·BULLET·HEAD idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, modelDrive: Float = 1f, bulletBankOut: Float = 0f) {
        if (!enabled) {
            status = "HAIR·BULLET·HEAD OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        liveMicE = e
        val drive = 0.25f + 0.75f * modelDrive.coerceIn(0f, 1f)
        val now = android.os.SystemClock.elapsedRealtime()

        // Automatic threshold analysis from live mic floor + margin
        autoThrAnalysis = (0.10f + e * 0.30f).coerceIn(0.08f, 0.55f)
        if (hairAutoThr) {
            hairAutoThrVal = autoThrAnalysis
            hairThr = hairAutoThrVal
        }
        if (bulletCollapseAutoThr) {
            bulletCollapseAutoThrVal = (autoThrAnalysis + 0.03f).coerceIn(0.1f, 0.6f)
            bulletCollapseThr = bulletCollapseAutoThrVal
            headFrontThr = autoThrAnalysis
            headUpThr = autoThrAnalysis
            headDownThr = autoThrAnalysis
            headLeftThr = autoThrAnalysis
            headRightThr = autoThrAnalysis
        }

        hairOut = lane(hairOn, hairThr, hairLv, e * drive)

        // Our bullet collapse — live mic + existing bullet bank + model
        val bulletSrc = maxOf(e, bulletBankOut) * drive
        bulletCollapseOut = lane(bulletCollapseOn, bulletCollapseThr, bulletCollapseLv, bulletSrc)
        val was = bulletCollapseActive
        bulletCollapseActive = bulletCollapseOut > 0.05f
        if (bulletCollapseActive && !was) {
            bulletCollapseCount++
            bulletSoundCount++
            bulletHitCount++
            windowHits++
            lastBulletMs = now
        }
        if (windowStartMs == 0L) windowStartMs = now
        if (now - windowStartMs > 5000L) {
            bulletSoundRate = windowHits / 5f
            windowHits = 0
            windowStartMs = now
        }

        headFrontOut = lane(headFrontOn, headFrontThr, headFrontLv, e * drive)
        headUpOut = lane(headUpOn, headUpThr, headUpLv, e * drive)
        headDownOut = lane(headDownOn, headDownThr, headDownLv, e * drive)
        headLeftOut = lane(headLeftOn, headLeftThr, headLeftLv, e * drive)
        headRightOut = lane(headRightOn, headRightThr, headRightLv, e * drive)

        status =
            "HAIR=${(hairOut*100).toInt()}% autoT=${"%.2f".format(autoThrAnalysis)} · " +
            "BULLET-COL ${if (bulletCollapseActive) "HIT" else "-"} out=${(bulletCollapseOut*100).toInt()}% " +
            "cnt=$bulletCollapseCount snd=$bulletSoundCount rate=${"%.1f".format(bulletSoundRate)}/s · " +
            "HEAD F=${(headFrontOut*100).toInt()} U=${(headUpOut*100).toInt()} D=${(headDownOut*100).toInt()} " +
            "L=${(headLeftOut*100).toInt()} R=${(headRightOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView, sb: SoundBankGuard) {
        if (!enabled) return
        // Hair visual ambient (forehead / head skin)
        try {
            v.forehead.atmosphere = maxOf(v.forehead.atmosphere, hairOut)
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, hairOut)
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, hairOut * 0.9f)
        } catch (_: Throwable) {}

        // Bullet collapse → sound bank bullet/burst
        if (bulletCollapseOn && bulletCollapseOut > 0.02f) {
            sb.bulletOn = true
            sb.bulletOut = maxOf(sb.bulletOut, bulletCollapseOut)
            sb.bulletActive = true
            sb.burstOut = maxOf(sb.burstOut, bulletCollapseOut * 0.9f)
            // collapse path if present
            try {
                val f = sb.javaClass.getDeclaredField("collapseOut")
                f.isAccessible = true
                val cur = f.getFloat(sb)
                f.setFloat(sb, maxOf(cur, bulletCollapseOut))
            } catch (_: Throwable) {}
        }

        // Head sides
        try {
            v.forehead.atmosphere = maxOf(v.forehead.atmosphere, headFrontOut, headUpOut)
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, headFrontOut, headUpOut, headDownOut, headLeftOut, headRightOut)
            v.neck.atmosphere = maxOf(v.neck.atmosphere, headDownOut * 0.9f)
            v.face.atmosphere = maxOf(v.face.atmosphere, headFrontOut)
        } catch (_: Throwable) {}
        try {
            v.frontSideAmbient.headFrontBoost(headFrontOut, headUpOut, headDownOut, headLeftOut, headRightOut)
        } catch (_: Throwable) {
            // optional hook
        }
    }

    fun resetCounters() {
        bulletSoundCount = 0
        bulletCollapseCount = 0
        bulletHitCount = 0
        bulletSoundRate = 0f
        windowHits = 0
        windowStartMs = 0L
    }
}
