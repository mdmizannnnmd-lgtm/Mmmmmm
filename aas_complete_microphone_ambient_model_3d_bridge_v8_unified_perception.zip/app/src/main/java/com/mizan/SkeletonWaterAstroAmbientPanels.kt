package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object SkeletonWaterAstroAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: SkeletonWaterAstroAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFBCAAA4.toInt()
        p.title("SKELETON 206 · WATER BLE SCALE · ASTRO AMBIENT · 3D BONE LAYER", c)
        p.note("Symbolic. Axial/appendicular · daily water track · not medical/predictive")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Skeleton ambient ON", b.skeletonOn) { b.skeletonOn = it }
        p.seek("Shared bone thr", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Shared bone level", 0f, 1.5f, b.lv) { b.lv = it }

        p.title("BLE WATER DIGITAL SCALE", c)
        p.switch("Water track ON", b.waterOn) { b.waterOn = it }
        p.switch("Unlimited daily track", b.waterUnlimited) { b.waterUnlimited = it }
        p.switch("Scale maintain", b.waterScaleMaintain) { b.waterScaleMaintain = it }
        p.seek("Water thr", 0.05f, 0.98f, b.waterThr) { b.waterThr = it }
        p.seek("Water level", 0f, 1.5f, b.waterLv) { b.waterLv = it }
        p.seek("Daily goal L", 0.5f, 8f, b.waterDailyGoalL) { b.waterDailyGoalL = it }

        p.title("ASTRO AMBIENT (decorative)", c)
        p.switch("Astro ambient ON", b.astroOn) { b.astroOn = it }

        val st = p.status("BONE·H2O —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 250) }
        })
    }
}
