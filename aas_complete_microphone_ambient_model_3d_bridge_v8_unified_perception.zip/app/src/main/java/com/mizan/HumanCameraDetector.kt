package com.mizan

import android.content.Context
import android.graphics.ImageFormat
import android.util.Log
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseDetector
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.accurate.AccuratePoseDetectorOptions
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.Segmenter
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.min

/**
 * Local camera inference. A frame is considered a human only when the pose
 * detector and person mask both report a usable result. No frame is persisted.
 */
class HumanCameraDetector(
    context: Context,
    private val onResult: (HumanDetection) -> Unit
) : AutoCloseable {

    @Volatile var lastError: String? = null
        private set
    @Volatile var ready: Boolean = false
        private set

    private val inFlight = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)
    private val generation = AtomicInteger(0)
    private var poseDetector: PoseDetector? = null
    private var segmenter: Segmenter? = null

    init {
        try {
            poseDetector = PoseDetection.getClient(
                AccuratePoseDetectorOptions.Builder()
                    .setDetectorMode(AccuratePoseDetectorOptions.STREAM_MODE)
                    .build()
            )
            segmenter = Segmentation.getClient(
                SelfieSegmenterOptions.Builder()
                    .setDetectorMode(SelfieSegmenterOptions.STREAM_MODE)
                    .enableRawSizeMask()
                    .build()
            )
            ready = true
            onResult(HumanDetection.none("Camera detector ready · waiting for a person", true))
        } catch (t: Throwable) {
            lastError = t.message ?: "ML Kit detector initialization failed"
            onResult(HumanDetection.none("Detector unavailable · $lastError", false))
        }
    }

    /**
     * Called from Camera.PreviewCallback. ML Kit may retain the input bytes
     * until inference completes, so take a private copy before returning.
     */
    fun processNv21(bytes: ByteArray, width: Int, height: Int, rotationDegrees: Int) {
        if (closed.get() || !ready || width <= 0 || height <= 0) return
        if (!inFlight.compareAndSet(false, true)) return
        val frameGeneration = generation.get()
        val frame = bytes.clone()
        val image = try {
            InputImage.fromByteArray(
                frame,
                width,
                height,
                rotationDegrees,
                ImageFormat.NV21
            )
        } catch (t: Throwable) {
            inFlight.set(false)
            publish(HumanDetection.none("Camera frame error · ${t.message ?: "invalid NV21"}", ready))
            return
        }

        var pose: Pose? = null
        var mask: MaskSummary? = null
        var failure: String? = null
        val pending = AtomicInteger(2)

        fun completed() {
            if (pending.decrementAndGet() != 0) return
            try {
                if (closed.get() || generation.get() != frameGeneration) return
                if (failure != null) {
                    lastError = failure
                    publish(HumanDetection.none("Inference error · $failure", ready))
                } else {
                    lastError = null
                    publish(buildResult(pose, mask))
                }
            } finally {
                inFlight.set(false)
            }
        }

        fun <T> observe(task: Task<T>, accept: (T) -> Unit) {
            task.addOnCompleteListener { done ->
                if (done.isSuccessful) {
                    done.result?.let(accept)
                } else {
                    failure = done.exception?.message ?: "model inference failed"
                }
                completed()
            }
        }

        try {
            val task = poseDetector?.process(image)
            if (task == null) {
                failure = "pose detector closed"
                completed()
            } else {
                observe(task) { pose = it }
            }
        } catch (t: Throwable) {
            failure = t.message ?: "pose inference failed"
            completed()
        }

        try {
            val task = segmenter?.process(image)
            if (task == null) {
                failure = failure ?: "person segmenter closed"
                completed()
            } else {
                observe(task) { mask = summarizeMask(it) }
            }
        } catch (t: Throwable) {
            failure = failure ?: (t.message ?: "person segmentation failed")
            completed()
        }
    }

    private data class MaskSummary(
        val confidence: Float,
        val coverage: Float,
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float
    )

    private fun summarizeMask(mask: SegmentationMask): MaskSummary {
        val width = mask.width
        val height = mask.height
        if (width <= 0 || height <= 0) return MaskSummary(0f, 0f, 0f, 0f, 0f, 0f)
        val values = mask.buffer.duplicate()
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        val stride = max(1, max(width, height) / 256)
        var foreground = 0
        var confidenceSum = 0f
        var samples = 0
        var minX = width
        var minY = height
        var maxX = -1
        var maxY = -1
        var y = 0
        while (y < height) {
            var x = 0
            while (x < width) {
                val i = y * width + x
                if (i < values.limit()) {
                    val score = values.get(i).coerceIn(0f, 1f)
                    samples++
                    if (score >= MASK_PIXEL_THRESHOLD) {
                        foreground++
                        confidenceSum += score
                        minX = min(minX, x)
                        minY = min(minY, y)
                        maxX = max(maxX, x)
                        maxY = max(maxY, y)
                    }
                }
                x += stride
            }
            y += stride
        }
        if (foreground == 0 || samples == 0) {
            return MaskSummary(0f, 0f, 0f, 0f, 0f, 0f)
        }
        return MaskSummary(
            confidence = confidenceSum / foreground,
            coverage = (foreground.toFloat() / samples).coerceIn(0f, 1f),
            left = minX.toFloat() / width,
            top = minY.toFloat() / height,
            right = (maxX + 1).toFloat() / width,
            bottom = (maxY + 1).toFloat() / height
        )
    }

    private fun landmarkScore(pose: Pose, vararg types: Int): Float {
        val scores = ArrayList<Float>(types.size)
        for (type in types) {
            val lm = pose.getPoseLandmark(type) ?: continue
            scores.add(lm.inFrameLikelihood)
        }
        return if (scores.isEmpty()) 0f else (scores.sum() / scores.size).coerceIn(0f, 1f)
    }

    private fun buildResult(pose: Pose?, mask: MaskSummary?): HumanDetection {
        if (pose == null || mask == null || mask.coverage < MIN_MASK_COVERAGE) {
            return HumanDetection.none(
                if (pose == null && mask == null) "No pose or person mask" else "No clear person mask",
                ready
            )
        }

        val visible = pose.allPoseLandmarks.count { it.inFrameLikelihood >= MIN_LANDMARK_CONFIDENCE }
        val averageLandmark = pose.allPoseLandmarks
            .map { it.inFrameLikelihood }
            .average()
            .toFloat()
            .coerceIn(0f, 1f)
        val torso = landmarkScore(
            pose,
            PoseLandmark.LEFT_SHOULDER,
            PoseLandmark.RIGHT_SHOULDER,
            PoseLandmark.LEFT_HIP,
            PoseLandmark.RIGHT_HIP
        )
        val poseConfidence = (
            torso * 0.55f +
                averageLandmark * 0.30f +
                (visible / 25f).coerceIn(0f, 1f) * 0.15f
            ).coerceIn(0f, 1f)

        val partScores = listOf(
            landmarkScore(pose, PoseLandmark.NOSE, PoseLandmark.LEFT_EYE, PoseLandmark.RIGHT_EYE),
            torso,
            landmarkScore(pose, PoseLandmark.LEFT_SHOULDER, PoseLandmark.LEFT_ELBOW, PoseLandmark.LEFT_WRIST),
            landmarkScore(pose, PoseLandmark.RIGHT_SHOULDER, PoseLandmark.RIGHT_ELBOW, PoseLandmark.RIGHT_WRIST),
            landmarkScore(pose, PoseLandmark.LEFT_HIP, PoseLandmark.LEFT_KNEE, PoseLandmark.LEFT_ANKLE),
            landmarkScore(pose, PoseLandmark.RIGHT_HIP, PoseLandmark.RIGHT_KNEE, PoseLandmark.RIGHT_ANKLE),
            landmarkScore(pose, PoseLandmark.LEFT_WRIST),
            landmarkScore(pose, PoseLandmark.RIGHT_WRIST),
            landmarkScore(pose, PoseLandmark.LEFT_ANKLE),
            landmarkScore(pose, PoseLandmark.RIGHT_ANKLE)
        )

        val confidence = (poseConfidence * 0.65f + mask.confidence * 0.35f).coerceIn(0f, 1f)
        val hasPerson = poseConfidence >= MIN_POSE_CONFIDENCE &&
            mask.confidence >= MIN_MASK_CONFIDENCE &&
            mask.coverage >= MIN_MASK_COVERAGE
        if (!hasPerson) {
            return HumanDetection.none(
                "No confident person · pose ${(poseConfidence * 100).toInt()}% · mask ${(mask.confidence * 100).toInt()}%",
                ready
            )
        }
        return HumanDetection(
            hasPerson = true,
            modelReady = ready,
            confidence = confidence,
            poseConfidence = poseConfidence,
            maskConfidence = mask.confidence,
            maskCoverage = mask.coverage,
            centerX = ((mask.left + mask.right) * 0.5f).coerceIn(0f, 1f),
            centerY = ((mask.top + mask.bottom) * 0.5f).coerceIn(0f, 1f),
            boxWidth = (mask.right - mask.left).coerceIn(0f, 1f),
            boxHeight = (mask.bottom - mask.top).coerceIn(0f, 1f),
            partScores = partScores,
            status = "Person ${"%.0f".format(confidence * 100)}% · pose ${"%.0f".format(poseConfidence * 100)}% · mask ${"%.0f".format(mask.coverage * 100)}%"
        )
    }

    private fun publish(result: HumanDetection) {
        if (!closed.get()) {
            try {
                onResult(result)
            } catch (t: Throwable) {
                Log.w(TAG, "Detection listener failed", t)
            }
        }
    }

    fun reset(status: String = "Camera paused") {
        generation.incrementAndGet()
        publish(HumanDetection.none(status, ready))
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        generation.incrementAndGet()
        try { poseDetector?.close() } catch (_: Exception) {}
        try { segmenter?.close() } catch (_: Exception) {}
        poseDetector = null
        segmenter = null
        ready = false
    }

    companion object {
        private const val TAG = "HumanCameraDetector"
        private const val MASK_PIXEL_THRESHOLD = 0.55f
        private const val MIN_MASK_CONFIDENCE = 0.55f
        private const val MIN_POSE_CONFIDENCE = 0.30f
        private const val MIN_MASK_COVERAGE = 0.002f
        private const val MIN_LANDMARK_CONFIDENCE = 0.35f
    }
}
