package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object SkinMultiModelMotionPanels {
    fun build(ctx: Context, root: LinearLayout, b: SkinMultiModelMotionBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFCE93D8.toInt()
        p.title("SKIN MULTI-MODEL · POSE/SEG/OBB · MOVE · SPEED · WAVES CONTROLLER", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("MULTI MODEL SKIN", c)
        p.switch("Pose model skin", b.poseOn) { b.poseOn = it }
        p.switch("Segment model skin", b.segmentOn) { b.segmentOn = it }
        p.switch("OBB model skin", b.obbOn) { b.obbOn = it }

        p.title("SKIN AMBIENT", c)
        p.switch("Skin ambient ON", b.skinAmbientOn) { b.skinAmbientOn = it }
        p.seek("Skin ambient thr", 0.05f, 0.98f, b.skinAmbientThr) { b.skinAmbientThr = it }
        p.seek("Skin ambient level", 0f, 1.5f, b.skinAmbientLv) { b.skinAmbientLv = it }

        p.title("MOVEMENT CONTROLLER", c)
        p.switch("Move ON", b.moveOn) { b.moveOn = it }
        p.seek("Move thr / lv", 0.05f, 0.98f, b.moveThr) { b.moveThr = it }
        p.seek("Move level", 0f, 1.5f, b.moveLv) { b.moveLv = it }

        p.title("SPEED CONTROLLER", c)
        p.switch("Speed ON", b.speedOn) { b.speedOn = it }
        p.seek("Speed thr", 0.05f, 0.98f, b.speedThr) { b.speedThr = it }
        p.seek("Speed level", 0f, 1.5f, b.speedLv) { b.speedLv = it }

        p.title("WAVES CONTROLLER", c)
        p.switch("Waves ON", b.waveOn) { b.waveOn = it }
        p.seek("Wave thr", 0.05f, 0.98f, b.waveThr) { b.waveThr = it }
        p.seek("Wave level", 0f, 1.5f, b.waveLv) { b.waveLv = it }

        val st = p.status("SKIN·CTRL —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 220) }
        })
    }
}
