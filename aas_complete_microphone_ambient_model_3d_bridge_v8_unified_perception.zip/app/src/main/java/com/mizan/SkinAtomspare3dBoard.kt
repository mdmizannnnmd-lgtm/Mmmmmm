package com.mizan

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Environment
import java.io.File

/**
 * Full 3D model skin atomspare (inside + outside layers).
 * Layered skin: epidermis · dermis · fat (outside) ↔ muscle · vessels · core (inside).
 * Virtual atomspare SFX enter human body only (like bullet) — not anywhere else.
 * Modes: knife · bullet · SD card path load · audio-focused / virtual.
 * Auto threshold from live energy · RAW COMPLETE.
 */
class SkinAtomspare3dBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Skin layers (outside shell)
    @Volatile var skinOutsideOn = true
    @Volatile var epidermisOut = 0f
    @Volatile var dermisOut = 0f
    @Volatile var fatOut = 0f
    @Volatile var skinOutsideOut = 0f

    // Inside body
    @Volatile var skinInsideOn = true
    @Volatile var muscleIn = 0f
    @Volatile var vesselIn = 0f
    @Volatile var coreIn = 0f
    @Volatile var skinInsideOut = 0f

    // Atomspare body shell
    @Volatile var atomSpareOn = true
    @Volatile var atomSpareThr = 0.28f
    @Volatile var atomSpareLv = 0.75f
    @Volatile var atomSpareOut = 0f
    @Volatile var atomSpareAutoThr = true
    @Volatile var atomSpareAutoThrVal = 0.28f

    // Body-only entry gate (sounds enter full human body only — not world)
    @Volatile var bodyOnlyEntry = true
    @Volatile var bodyEntryThr = 0.32f
    @Volatile var bodyEntryOut = 0f
    @Volatile var humanBodyHit = false

    // Modes
    @Volatile var knifeMode = false
    @Volatile var bulletMode = false
    @Volatile var sdCardMode = false
    @Volatile var knifeThr = 0.40f
    @Volatile var knifeLv = 0.70f
    @Volatile var knifeOut = 0f
    @Volatile var bulletThr = 0.45f
    @Volatile var bulletLv = 0.75f
    @Volatile var bulletOut = 0f

    // Audio focused / virtual atomspare SFX
    @Volatile var audioFocusedSfx = true
    @Volatile var virtualAtomSfx = true
    @Volatile var sfxThr = 0.30f
    @Volatile var sfxLv = 0.80f
    @Volatile var sfxOut = 0f
    @Volatile var sfxBodyOnly = true

    // SD card
    @Volatile var sdCardPath = "/sdcard/Music/atomspare"
    @Volatile var sdCardLoaded = false
    @Volatile var sdCardFileCount = 0
    @Volatile var lastPlayed: String? = null
    private var player: MediaPlayer? = null
    private var fileList: List<File> = emptyList()

    @Volatile var status = "SKIN·ATOMSPARE idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float, drive: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv * drive).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f) * drive.coerceIn(0.2f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, modelDrive: Float = 1f, humanDetected: Boolean = true) {
        if (!enabled) {
            status = "SKIN·ATOMSPARE OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val drive = 0.25f + 0.75f * modelDrive.coerceIn(0f, 1f)

        if (atomSpareAutoThr) {
            // automatic threshold tracks quiet floor + margin
            atomSpareAutoThrVal = (0.12f + e * 0.25f).coerceIn(0.08f, 0.55f)
            atomSpareThr = atomSpareAutoThrVal
            bodyEntryThr = (atomSpareAutoThrVal + 0.04f).coerceIn(0.1f, 0.7f)
            sfxThr = atomSpareAutoThrVal
        }

        atomSpareOut = lane(atomSpareOn, atomSpareThr, atomSpareLv, e * 1.05f, drive)

        // Outside skin layers
        if (skinOutsideOn) {
            epidermisOut = atomSpareOut * 0.95f
            dermisOut = atomSpareOut * 0.88f
            fatOut = atomSpareOut * 0.75f
            skinOutsideOut = maxOf(epidermisOut, dermisOut, fatOut)
        } else skinOutsideOut = 0f

        // Inside
        if (skinInsideOn) {
            muscleIn = atomSpareOut * 0.90f * drive
            vesselIn = atomSpareOut * 0.82f
            coreIn = atomSpareOut * 0.70f
            skinInsideOut = maxOf(muscleIn, vesselIn, coreIn)
        } else skinInsideOut = 0f

        // Body-only entry: only when human body present (detection or force)
        val bodyOk = humanDetected || rawComplete
        bodyEntryOut = if (bodyOnlyEntry && bodyOk) {
            lane(true, bodyEntryThr, 1f, maxOf(e, atomSpareOut), drive)
        } else if (!bodyOnlyEntry) lane(true, bodyEntryThr, 1f, e, drive) else 0f
        humanBodyHit = bodyEntryOut > 0.05f && bodyOk

        knifeOut = if (knifeMode) lane(true, knifeThr, knifeLv, if (humanBodyHit) e * 1.1f else 0f, drive) else 0f
        bulletOut = if (bulletMode) lane(true, bulletThr, bulletLv, if (humanBodyHit) e * 1.15f else 0f, drive) else 0f

        val sfxE = if (sfxBodyOnly && !humanBodyHit) 0f else e
        sfxOut = if (audioFocusedSfx || virtualAtomSfx) {
            lane(true, sfxThr, sfxLv, sfxE * 1.08f, drive)
        } else 0f

        // SD card mode: trigger play when body entry + energy
        if (sdCardMode && humanBodyHit && sfxOut > 0.35f) {
            // playback requested externally via tryPlaySdCard
        }

        status =
            "SKIN out=${(skinOutsideOut*100).toInt()}% in=${(skinInsideOut*100).toInt()}% · " +
            "ATOM=${(atomSpareOut*100).toInt()}% autoThr=${"%.2f".format(atomSpareThr)} · " +
            "BODY-ENTRY ${if (humanBodyHit) "HIT" else "-"} ${(bodyEntryOut*100).toInt()}% · " +
            (if (knifeMode) "KNIFE ${(knifeOut*100).toInt()}% " else "") +
            (if (bulletMode) "BULLET ${(bulletOut*100).toInt()}% " else "") +
            (if (sdCardMode) "SD ${if (sdCardLoaded) "$sdCardFileCount files" else "path?"} " else "") +
            "SFX ${(sfxOut*100).toInt()}%" + if (rawComplete) " · RAW" else ""
    }

    fun scanSdCard(ctx: Context? = null): Int {
        val dirs = listOf(
            File(sdCardPath),
            File("/storage/emulated/0/Music/atomspare"),
            File("/storage/emulated/0/Download/atomspare"),
            File(Environment.getExternalStorageDirectory(), "atomspare"),
            File(Environment.getExternalStorageDirectory(), "Music")
        )
        val files = mutableListOf<File>()
        for (d in dirs) {
            if (!d.isDirectory) continue
            d.listFiles()?.filter {
                it.isFile && it.extension.lowercase() in setOf("mp3", "wav", "ogg", "m4a", "aac", "flac")
            }?.let { files.addAll(it) }
        }
        fileList = files.distinctBy { it.absolutePath }
        sdCardFileCount = fileList.size
        sdCardLoaded = fileList.isNotEmpty()
        return sdCardFileCount
    }

    /** Play atomspare break SFX only when human body entry is active. */
    fun tryPlaySdCard(ctx: Context): Boolean {
        if (!sdCardMode || !enabled) return false
        if (sfxBodyOnly && !humanBodyHit) return false
        if (fileList.isEmpty()) scanSdCard(ctx)
        if (fileList.isEmpty()) return false
        val f = fileList[(RawMicBus.sequence % fileList.size).toInt()]
        return try {
            player?.release()
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(ctx, Uri.fromFile(f))
                setOnCompletionListener { it.release(); player = null }
                prepare()
                // volume scales with body entry / sfx
                val v = (sfxOut * 0.9f + bodyEntryOut * 0.1f).coerceIn(0.05f, 1f)
                setVolume(v, v)
                start()
            }
            lastPlayed = f.name
            true
        } catch (_: Exception) {
            false
        }
    }

    fun stopSfx() {
        try { player?.stop(); player?.release() } catch (_: Exception) {}
        player = null
    }

    fun applyToAtmosphere(atmo: BodyAtmosphere3D) {
        if (!enabled) return
        atmo.level = maxOf(atmo.level, atomSpareOut)
        atmo.waveLevel = maxOf(atmo.waveLevel, skinOutsideOut)
        atmo.movementLevel = maxOf(atmo.movementLevel, skinInsideOut)
        if (atomSpareAutoThr) {
            atmo.threshold = atomSpareThr
        }
    }

    fun applyToSoundBank(sb: SoundBankGuard) {
        if (!enabled) return
        if (knifeMode && knifeOut > 0.05f) {
            sb.knifeOn = true
            sb.knifeOut = maxOf(sb.knifeOut, knifeOut)
            // body-only: damp if not human hit
            if (bodyOnlyEntry && !humanBodyHit) sb.knifeOut *= 0.05f
        }
        if (bulletMode && bulletOut > 0.05f) {
            sb.bulletOn = true
            sb.bulletOut = maxOf(sb.bulletOut, bulletOut)
            if (bodyOnlyEntry && !humanBodyHit) sb.bulletOut *= 0.05f
        }
        if (audioFocusedSfx) {
            sb.audioFocusOn = true
            sb.audioFocusOut = maxOf(sb.audioFocusOut, sfxOut)
        }
    }
}
