package com.mizan

/**
 * Law of Attraction + gravitational magic + teleport / universe transport / time travel.
 * Brain & body intention → visualise → gravity field → like-attracts-like → send/receive/return.
 * Symbolic on-device energy layer (visual/motion coupling only).
 */
class AttractionMagicEngine {

    @Volatile var enabled = true
    @Volatile var magicOn = true
    @Volatile var attractOn = true
    @Volatile var gravityOn = true
    @Volatile var sendOn = true
    @Volatile var receiveOn = true
    @Volatile var acceptOn = true
    @Volatile var returnBackOn = true

    // Teleport · universe · time travel
    @Volatile var teleportOn = true
    @Volatile var universeTransportOn = true
    @Volatile var timeTravelOn = true
    @Volatile var gravWavesOn = true
    @Volatile var intentionOn = true
    @Volatile var visualiseOn = true

    @Volatile var mindEnergy = 0.55f
    @Volatile var bodyEnergy = 0.55f
    @Volatile var attractLv = 0.70f
    @Volatile var gravityLv = 0.65f
    @Volatile var sendLv = 0.60f
    @Volatile var receiveLv = 0.60f
    @Volatile var acceptLv = 0.70f
    @Volatile var returnLv = 0.55f
    @Volatile var magicLv = 0.60f

    @Volatile var teleportLv = 0.70f
    @Volatile var universeLv = 0.65f
    @Volatile var timeTravelLv = 0.60f
    @Volatile var gravWaveLv = 0.70f
    @Volatile var intentionLv = 0.75f
    @Volatile var visualiseLv = 0.70f

    // Live
    @Volatile var personalEnergy = 0f
    @Volatile var attractField = 0f
    @Volatile var gravityField = 0f
    @Volatile var sentEnergy = 0f
    @Volatile var receivedEnergy = 0f
    @Volatile var acceptedEnergy = 0f
    @Volatile var returnedEnergy = 0f
    @Volatile var likeLikeScore = 0f

    @Volatile var intentionField = 0f
    @Volatile var visualiseField = 0f
    @Volatile var gravWaveField = 0f
    @Volatile var teleportCharge = 0f
    @Volatile var universePhase = 0f
    @Volatile var timeShift = 0f
    @Volatile var lastMove = 0f
    @Volatile var lastWave = 0f
    @Volatile var lastSpeed = 0f

    fun tick(
        move: Float,
        wave: Float,
        speed: Float,
        mindHint: Float = mindEnergy,
        bodyHint: Float = bodyEnergy
    ) {
        if (!enabled) return
        val mv = move.coerceIn(0f, 1f)
        val wv = wave.coerceIn(0f, 1f)
        val sp = (speed / 4f).coerceIn(0f, 1f)
        lastMove = mv
        lastWave = wv
        lastSpeed = sp

        // Brain + body intention → personal energy
        personalEnergy = (
            mindHint * 0.40f + bodyHint * 0.30f + (mv + wv + sp) / 3f * 0.30f
        ).coerceIn(0f, 1f)

        // Intention field (brain/body directed will)
        intentionField = if (intentionOn) {
            (personalEnergy * intentionLv * (0.5f + 0.5f * mindHint)).coerceIn(0f, 1f)
        } else 0f

        // Visualise: intention focuses into a clearer field
        visualiseField = if (visualiseOn) {
            (intentionField * visualiseLv * (0.4f + 0.6f * bodyHint)).coerceIn(0f, 1f)
        } else intentionField * 0.3f

        // Like attracts like
        val mean = (mv + wv + sp) / 3f
        val spread = (abs(mv - mean) + abs(wv - mean) + abs(sp - mean)) / 3f
        likeLikeScore = (1f - spread * 2f).coerceIn(0f, 1f)

        attractField = if (attractOn) {
            (likeLikeScore * attractLv * personalEnergy *
                (if (magicOn) magicLv else 0.5f) *
                (0.5f + 0.5f * visualiseField)).coerceIn(0f, 1f)
        } else 0f

        // Gravitational field from intention + attract
        gravityField = if (gravityOn) {
            (personalEnergy * gravityLv * (0.3f + 0.4f * attractField + 0.3f * visualiseField))
                .coerceIn(0f, 1f)
        } else 0f

        // Gravitational waves: oscillating carrier from move/wave/speed
        gravWaveField = if (gravWavesOn) {
            val carrier = (mv * 0.35f + wv * 0.40f + sp * 0.25f)
            (carrier * gravWaveLv * (0.4f + 0.6f * gravityField)).coerceIn(0f, 1f)
        } else 0f

        // Teleport charge: intention + gravity waves + like-score
        teleportCharge = if (teleportOn) {
            ((intentionField * 0.35f + gravityField * 0.25f + gravWaveField * 0.25f +
                likeLikeScore * 0.15f) * teleportLv).coerceIn(0f, 1f)
        } else 0f

        // Universe transport phase (0…1 “gate open”)
        universePhase = if (universeTransportOn) {
            ((teleportCharge * 0.5f + visualiseField * 0.3f + attractField * 0.2f) * universeLv)
                .coerceIn(0f, 1f)
        } else 0f

        // Time shift (symbolic lag/lead from speed + intention)
        timeShift = if (timeTravelOn) {
            val dir = (sp - 0.5f) * 2f // -1…+1
            ((dir * 0.5f + 0.5f) * timeTravelLv * (0.4f + 0.6f * intentionField)).coerceIn(0f, 1f)
        } else 0.5f

        sentEnergy = if (sendOn) {
            (personalEnergy * sendLv * (0.4f + 0.3f * attractField + 0.3f * teleportCharge))
                .coerceIn(0f, 1f)
        } else 0f

        val inbound = sentEnergy * 0.70f + gravityField * 0.15f + gravWaveField * 0.15f
        receivedEnergy = if (receiveOn) (inbound * receiveLv).coerceIn(0f, 1f) else 0f
        acceptedEnergy = if (acceptOn) (receivedEnergy * acceptLv).coerceIn(0f, 1f) else 0f

        returnedEnergy = if (returnBackOn) {
            (acceptedEnergy * returnLv * (0.4f + 0.6f * likeLikeScore)).coerceIn(0f, 1f)
        } else 0f

        personalEnergy = (personalEnergy * 0.82f + returnedEnergy * 0.18f).coerceIn(0f, 1f)
    }

    private fun abs(v: Float) = if (v < 0) -v else v

    /** Visual phase / intensity boost. */
    fun visualBoost(): Float {
        if (!enabled) return 1f
        return (1f + attractField * 0.35f + gravityField * 0.20f +
            gravWaveField * 0.20f + teleportCharge * 0.15f +
            universePhase * 0.10f + acceptedEnergy * 0.15f)
            .coerceIn(0.5f, 2.5f)
    }

    /** Time-travel phase scale (slows/speeds ring animation). */
    fun timePhaseScale(): Float {
        if (!enabled || !timeTravelOn) return 1f
        // timeShift 0 = slower past, 1 = faster future
        return (0.55f + timeShift * 0.90f).coerceIn(0.4f, 1.6f)
    }

    /** Teleport spatial jitter factor for draw offset. */
    fun teleportJitter(): Float =
        if (!enabled || !teleportOn) 0f else teleportCharge * 40f

    fun statusLine(): String {
        if (!enabled) return "ATTRACTION off"
        return "ATTRACT like=${"%.0f".format(likeLikeScore * 100)} " +
            "intent ${"%.0f".format(intentionField * 100)} vis ${"%.0f".format(visualiseField * 100)} " +
            "E ${"%.0f".format(personalEnergy * 100)} grav ${"%.0f".format(gravityField * 100)} " +
            "GW ${"%.0f".format(gravWaveField * 100)} " +
            "TP ${"%.0f".format(teleportCharge * 100)} UNI ${"%.0f".format(universePhase * 100)} " +
            "TIME ${"%.0f".format(timeShift * 100)} " +
            "TX ${"%.0f".format(sentEnergy * 100)} RX ${"%.0f".format(receivedEnergy * 100)} " +
            "ACC ${"%.0f".format(acceptedEnergy * 100)} RET ${"%.0f".format(returnedEnergy * 100)}"
    }
}
