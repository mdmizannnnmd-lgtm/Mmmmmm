package com.mizan

/**
 * Full 84 humanoid 3D channels — same settings as original body bank Region.
 * No channel selection: all 84 always active. Bulk applies to every joint.
 */
class Body84Channels {

    data class Ch(
        val name: String,
        @Volatile var on: Boolean = true,
        // Core (body bank parity)
        @Volatile var ambient: Float = 0.50f,
        @Volatile var thr: Float = 0.35f,
        @Volatile var wave: Float = 1f,
        @Volatile var atmosphere: Float = 0.45f,
        @Volatile var waveSpare: Float = 0.40f,
        @Volatile var particles: Float = 0.50f,
        @Volatile var move: Float = 0.40f,
        @Volatile var moveThr: Float = 0.30f,
        @Volatile var speed: Float = 0.40f,
        @Volatile var speedThr: Float = 0.30f,
        // Filters
        @Volatile var lrFilt: Float = 0.50f,
        @Volatile var udFilt: Float = 0.50f,
        @Volatile var randomFilt: Float = 0.50f,
        @Volatile var centerFilt: Float = 0.50f,
        @Volatile var cornerFilt: Float = 0.50f,
        @Volatile var vibFilt: Float = 0.50f,
        // Bipolar / spike
        @Volatile var bipNegDb: Float = -20f,
        @Volatile var bipPosDb: Float = 20f,
        @Volatile var pigPong: Float = 0.50f,
        @Volatile var pigPongThr: Float = 0.35f,
        @Volatile var atmoSpikeProt: Float = 0.55f,
        @Volatile var atmoSpikeProtThr: Float = 0.40f,
        // Live
        @Volatile var active: Boolean = false,
        @Volatile var out: Float = 0f
    ) {
        fun effective(): Float {
            val n = (bipNegDb.coerceIn(-120f, 0f) / 120f) * 0.20f
            val p = (bipPosDb.coerceIn(0f, 120f) / 120f) * 0.20f
            val atmo = atmosphere.coerceIn(0f, 1f) * 0.20f
            val wsp = waveSpare.coerceIn(0f, 1f) * 0.12f
            val part = particles.coerceIn(0f, 1f) * 0.10f
            val pp = if (pigPong >= pigPongThr) pigPong.coerceIn(0f, 1f) * 0.12f else 0f
            val asp = if (atmoSpikeProt >= atmoSpikeProtThr) atmoSpikeProt.coerceIn(0f, 1f) * 0.15f else 0f
            val mv = if (move >= moveThr) move.coerceIn(0f, 1f) * 0.10f else 0f
            val sp = if (speed >= speedThr) speed.coerceIn(0f, 1f) * 0.10f else 0f
            return (ambient + n + p + atmo + wsp + part + pp + asp + mv + sp).coerceIn(0f, 1f)
        }
    }

    companion object {
        val NAMES = listOf(
            "Thumb", "Middle", "Ring", "Little",
            "Proximal", "Intermediate", "Distal",
            "1 Stretched", "2 Stretched", "3 Stretched",
            "Hips", "LeftUpperLeg", "RightUpperLeg",
            "LeftLowerLeg", "RightLowerLeg", "LeftFoot", "RightFoot",
            "Spine", "UpperChest", "Neck", "Head",
            "LeftShoulder", "RightShoulder",
            "LeftUpperArm", "RightUpperArm",
            "LeftLowerArm", "RightLowerArm",
            "LeftToes", "RightToes",
            "LeftEye", "RightEye", "Jaw",
            "Spine Front-Back", "Spine Left-Right", "Spine Twist Left-Right",
            "UpperChest Front-Back", "UpperChest Left-Right", "UpperChest Twist Left-Right",
            "Neck Nod Down-Up", "Neck Tilt Left-Right", "Neck Turn Left-Right",
            "Head Nod Down-Up", "Head Tilt Left-Right", "Head Turn Left-Right",
            "Left Eye Down-Up", "Left Eye In-Out",
            "Right Eye Down-Up", "Right Eye In-Out",
            "Jaw Close", "Jaw Left-Right",
            "Left Upper Leg Front-Back", "Left Upper Leg In-Out", "Left Upper Leg Twist In-Out",
            "Left Lower Leg Stretch", "Left Lower Leg Twist In-Out",
            "Left Foot Up-Down", "Left Foot Twist In-Out", "Left Toes Up-Down",
            "Right Upper Leg Front-Back", "Right Upper Leg In-Out", "Right Upper Leg Twist In-Out",
            "Right Lower Leg Stretch", "Right Lower Leg Twist In-Out",
            "Right Foot Up-Down", "Right Foot Twist In-Out", "Right Toes Up-Down",
            "Left Shoulder Down-Up", "Left Shoulder Front-Back",
            "Left Arm Down-Up", "Left Arm Front-Back", "Left Arm Twist In-Out",
            "Left Forearm Stretch", "Left Forearm Twist In-Out",
            "Left Hand Down-Up", "Left Hand In-Out",
            "Right Shoulder Down-Up", "Right Shoulder Front-Back",
            "Right Arm Down-Up", "Right Arm Front-Back", "Right Arm Twist In-Out",
            "Right Forearm Stretch", "Right Forearm Twist In-Out",
            "Right Hand Down-Up", "Right Hand In-Out"
        )
    }

    val channels: Array<Ch> = Array(84) { i ->
        Ch(name = NAMES.getOrElse(i) { "Ch${i + 1}" })
    }

    @Volatile var masterOn = true

    // Bulk = body bank options for all 84
    @Volatile var bulkAmbient = 0.50f
    @Volatile var bulkThr = 0.35f
    @Volatile var bulkWave = 1f
    @Volatile var bulkAtmo = 0.45f
    @Volatile var bulkWaveSpare = 0.40f
    @Volatile var bulkParticles = 0.50f
    @Volatile var bulkMove = 0.40f
    @Volatile var bulkMoveThr = 0.30f
    @Volatile var bulkSpeed = 0.40f
    @Volatile var bulkSpeedThr = 0.30f
    @Volatile var bulkLr = 0.50f
    @Volatile var bulkUd = 0.50f
    @Volatile var bulkRandom = 0.50f
    @Volatile var bulkCenter = 0.50f
    @Volatile var bulkCorner = 0.50f
    @Volatile var bulkVib = 0.50f
    @Volatile var bulkBipNeg = -20f
    @Volatile var bulkBipPos = 20f
    @Volatile var bulkPigPong = 0.50f
    @Volatile var bulkPigPongThr = 0.35f
    @Volatile var bulkAtmoSpike = 0.55f
    @Volatile var bulkAtmoSpikeThr = 0.40f

    /** Body rescanning (original body bank rescanning path) */
    @Volatile var rescanOn = true
    @Volatile var rescanThr = 0.40f
    @Volatile var rescanLv = 0.60f
    @Volatile var rescanActive = false
    @Volatile var rescanOut = 0f
    private var rescanPhase = 0f

    @Volatile var activeCount = 0
    @Volatile var avgOut = 0f
    @Volatile var maxOut = 0f

    fun applyBulkToAll() {
        for (c in channels) {
            c.on = true
            c.ambient = bulkAmbient.coerceIn(0f, 1f)
            c.thr = bulkThr.coerceIn(0.05f, 1f)
            c.wave = bulkWave.coerceIn(0.05f, 4f)
            c.atmosphere = bulkAtmo.coerceIn(0f, 1f)
            c.waveSpare = bulkWaveSpare.coerceIn(0f, 1f)
            c.particles = bulkParticles.coerceIn(0f, 1f)
            c.move = bulkMove.coerceIn(0f, 1f)
            c.moveThr = bulkMoveThr.coerceIn(0.05f, 1f)
            c.speed = bulkSpeed.coerceIn(0f, 1f)
            c.speedThr = bulkSpeedThr.coerceIn(0.05f, 1f)
            c.lrFilt = bulkLr.coerceIn(0f, 1f)
            c.udFilt = bulkUd.coerceIn(0f, 1f)
            c.randomFilt = bulkRandom.coerceIn(0f, 1f)
            c.centerFilt = bulkCenter.coerceIn(0f, 1f)
            c.cornerFilt = bulkCorner.coerceIn(0f, 1f)
            c.vibFilt = bulkVib.coerceIn(0f, 1f)
            c.bipNegDb = bulkBipNeg.coerceIn(-120f, 0f)
            c.bipPosDb = bulkBipPos.coerceIn(0f, 120f)
            c.pigPong = bulkPigPong.coerceIn(0f, 1f)
            c.pigPongThr = bulkPigPongThr.coerceIn(0.05f, 1f)
            c.atmoSpikeProt = bulkAtmoSpike.coerceIn(0f, 1f)
            c.atmoSpikeProtThr = bulkAtmoSpikeThr.coerceIn(0.05f, 1f)
        }
    }

    fun tick(energy: Float) {
        if (!masterOn) {
            activeCount = 0
            avgOut = 0f
            maxOut = 0f
            rescanActive = false
            rescanOut = 0f
            for (c in channels) {
                c.active = false
                c.out = 0f
            }
            return
        }
        val e = energy.coerceIn(0f, 1f)
        var sum = 0f
        var mx = 0f
        var n = 0
        for (c in channels) {
            if (!c.on) {
                c.active = false
                c.out = 0f
                continue
            }
            val t = c.thr.coerceIn(0.05f, 1f)
            c.active = e >= t
            c.out = if (c.active) {
                val base = ((e - t) / (1f - t).coerceAtLeast(0.05f)) * c.effective()
                (base * (0.7f + 0.3f * (c.wave / 4f).coerceIn(0f, 1f))).coerceIn(0f, 1f)
            } else 0f
            if (c.active) {
                n++
                sum += c.out
                if (c.out > mx) mx = c.out
            }
        }
        activeCount = n
        avgOut = if (n > 0) sum / n else 0f
        maxOut = mx

        // Original body rescanning — sweeps all 84 when energy crosses threshold
        val rThr = rescanThr.coerceIn(0.05f, 1f)
        rescanActive = rescanOn && e >= rThr
        if (rescanActive) {
            rescanPhase = (rescanPhase + 0.07f + e * 0.05f) % 84f
            val idx = rescanPhase.toInt().coerceIn(0, 83)
            val ch = channels[idx]
            rescanOut = (ch.out * rescanLv.coerceIn(0f, 1f) + avgOut * 0.35f).coerceIn(0f, 1f)
        } else {
            rescanOut = 0f
        }
    }

    fun dampenContribution(): Float {
        if (!masterOn || activeCount == 0) return 0f
        val base = 0.18f + avgOut * 0.32f + maxOut * 0.12f
        val rs = if (rescanActive) rescanOut * 0.15f else 0f
        return (base + rs).coerceIn(0f, 0.90f)
    }

    fun statusLine(): String {
        if (!masterOn) return "BODY84 off"
        val rs = if (rescanActive) " RESCAN=${(rescanOut * 100).toInt()}%" else ""
        return "BODY84 $activeCount/84 act avg=${(avgOut * 100).toInt()}% max=${(maxOut * 100).toInt()}% " +
            "amb=${(bulkAmbient * 100).toInt()}% thr=${(bulkThr * 100).toInt()}%$rs"
    }
    fun apply(v: VisualShieldView?) {
        val vv = v ?: return
        try {
            vv.body84FullHuman.atomOut = maxOf(vv.body84FullHuman.atomOut, avgOut)
            vv.body84FullHuman.moveOut = maxOf(vv.body84FullHuman.moveOut, bulkMove * avgOut)
            vv.body84FullHuman.speedOut = maxOf(vv.body84FullHuman.speedOut, bulkSpeed * avgOut)
            vv.body84FullHuman.waveOut = maxOf(vv.body84FullHuman.waveOut, bulkWave * avgOut)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, avgOut * 0.35f)
            try {
                vv.finalProtectionMain.body84Out = maxOf(vv.finalProtectionMain.body84Out, avgOut)
                vv.finalProtectionMain.body84ActiveCount = activeCount
                vv.finalProtectionMain.body84AvgOut = avgOut
                vv.finalProtectionMain.body84MaxOut = maxOut
                vv.finalProtectionMain.body84RescanOut = rescanOut
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}
    }

}
