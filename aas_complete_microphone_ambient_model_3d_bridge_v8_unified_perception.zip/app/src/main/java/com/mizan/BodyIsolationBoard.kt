package com.mizan

/**
 * Two settings: (1) My body does not interact with models / AI drives / anything.
 * (2) Enemy transmission & effects go to another place — not my place / not my body.
 * Fully apps · RAW COMPLETE.
 */
class BodyIsolationBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // ── Setting 1: My body non-interaction ──
    @Volatile var myBodyNoInteract = true
    /** Models / AI must not drive my body ambient · motion · speed · waves */
    @Volatile var aiModelNotDriveMyBody = true
    @Volatile var modelInteractionBlock = true
    @Volatile var blockPoseSegOnMyBody = true
    @Volatile var blockFullModelOnMyBody = true
    @Volatile var blockCnsModelDriveOnBody = true
    @Volatile var isolationStrength = 0.95f

    // ── Setting 2: Enemy transmission elsewhere (not my place) ──
    @Volatile var enemyTxElsewhere = true
    @Volatile var enemyNotMyPlace = true
    @Volatile var enemyNotMyBody = true
    @Volatile var redirectEnemyTx = true
    @Volatile var enemyElsewhereLv = 0.92f

    @Volatile var isolationOut = 0f
    @Volatile var enemyRedirectOut = 0f
    @Volatile var status = "BODY ISOLATION idle"

    fun tick(mic: Float, enemyThreat: Float = 0f) {
        if (!enabled) {
            isolationOut = 0f
            enemyRedirectOut = 0f
            status = "BODY ISOLATION OFF"
            return
        }
        val s = isolationStrength.coerceIn(0.1f, 1f)
        isolationOut = if (myBodyNoInteract || aiModelNotDriveMyBody || modelInteractionBlock) s else 0f
        if (rawComplete) isolationOut = maxOf(isolationOut, 0.99f)

        val er = enemyElsewhereLv.coerceIn(0.1f, 1f)
        enemyRedirectOut =
            if (enemyTxElsewhere || enemyNotMyPlace || enemyNotMyBody || redirectEnemyTx) {
                (enemyThreat.coerceIn(0f, 1f) * er).coerceIn(0f, 1f).coerceAtLeast(if (enemyTxElsewhere) er * 0.5f else 0f)
            } else 0f

        status =
            "MY BODY " + (if (myBodyNoInteract) "NO-INTERACT" else "open") +
            " · AI/model " + (if (aiModelNotDriveMyBody) "NOT-DRIVE-BODY" else "can-drive") +
            " · isol=${(isolationOut*100).toInt()}% · " +
            "ENEMY TX " + (if (enemyTxElsewhere) "ELSEWHERE" else "local") +
            " not-my-place=${enemyNotMyPlace} · redir=${(enemyRedirectOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    /** Apply isolation: zero model-driven body paths; dump enemy outs away from body. */
    fun apply(sb: SoundBankGuard, shield: VisualShieldView) {
        if (!enabled) return
        val iso = isolationOut.coerceIn(0f, 1f)
        val red = enemyRedirectOut.coerceIn(0f, 1f)

        if (myBodyNoInteract || aiModelNotDriveMyBody || modelInteractionBlock) {
            // My body motion factors stay protected / not model-pushed
            sb.protectMoveFactor = minOf(sb.protectMoveFactor, (1f - iso * 0.9f).coerceIn(0.05f, 1f))
            sb.protectSpeedFactor = minOf(sb.protectSpeedFactor, (1f - iso * 0.9f).coerceIn(0.05f, 1f))
            sb.protectWaveFactor = minOf(sb.protectWaveFactor, (1f - iso * 0.9f).coerceIn(0.05f, 1f))
            if (blockPoseSegOnMyBody) {
                // pose/seg groups should not push skin as "my body driven"
                shield.poseSegEyeBody.enabled = shield.poseSegEyeBody.enabled // keep board, soft null body push
            }
            if (blockFullModelOnMyBody && iso > 0.5f) {
                // full model groups still visible as status but damp skin write
                val damp = (1f - iso * 0.85f).coerceIn(0.1f, 1f)
                shield.skinAll.ambient *= damp
            }
            if (blockCnsModelDriveOnBody && iso > 0.4f) {
                // keep CNS for eyes/brain path but not body surface takeover
                shield.skinChest.ambient = (shield.skinChest.ambient * (1f - iso * 0.5f)).coerceIn(0f, 1f)
                shield.skinAbdomen.ambient = (shield.skinAbdomen.ambient * (1f - iso * 0.5f)).coerceIn(0f, 1f)
            }
        }

        if (enemyTxElsewhere || enemyNotMyPlace || enemyNotMyBody || redirectEnemyTx) {
            // Enemy energy does not stay on my body / my place
            val k = (1f - red * 0.97f).coerceIn(0.02f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
            sb.enemyCommBlockOut = maxOf(sb.enemyCommBlockOut, red)
            if (enemyNotMyBody) {
                sb.enemyBodyMove *= k
                sb.enemyBodySpeed *= k
                sb.enemyBodyWave *= k
                sb.enemyBodyEnergy *= k
            }
            // Master + AR shields stay hard
            sb.enemyMasterShieldOn = true
            sb.arRealityShieldOn = true
        }
    }
}
