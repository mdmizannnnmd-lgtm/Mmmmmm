package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object SkinSoundsProtectPanels {
    fun build(ctx: Context, root: LinearLayout, b: SkinSoundsProtectBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFEF9A9A.toInt()
        p.title("SKIN SOUNDS FX PROTECT · BULLET·KNIFE·SHARP·BURST·PITCH·ATOM SPIKE · 3D+AMBIENT", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Skin SFX protect ON", b.protectOn) { b.protectOn = it }
        p.seek("Protect thr", 0.05f, 0.98f, b.protectThr) { b.protectThr = it }
        p.seek("Protect level", 0f, 1.5f, b.protectLv) { b.protectLv = it }
        val st = p.status("SKIN SFX PROT —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 200) }
        })
    }
}
