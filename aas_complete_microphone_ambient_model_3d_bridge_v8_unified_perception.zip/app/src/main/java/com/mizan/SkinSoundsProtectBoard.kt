package com.mizan

/**
 * Skin sounds effect protection — bullet · knife · sharp · burst · pitch ·
 * atomspare spike SFX — ambient skin + on-screen 3D models. RAW COMPLETE.
 */
class SkinSoundsProtectBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    @Volatile var protectOn = true
    @Volatile var protectThr = 0.22f
    @Volatile var protectLv = 0.92f
    @Volatile var protectOut = 0f

    // Per-threat skin protect
    @Volatile var bulletProt = 0f
    @Volatile var knifeProt = 0f
    @Volatile var sharpProt = 0f
    @Volatile var burstProt = 0f
    @Volatile var pitchProt = 0f
    @Volatile var atomSpikeProt = 0f

    // Skin shield presence on 3D
    @Volatile var skinShield3d = 0f
    @Volatile var skinShieldAmbient = 0f

    @Volatile var status = "SKIN SFX PROTECT idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        bullet: Float, knife: Float, sharp: Float, burst: Float,
        pitch: Float, atomSpike: Float, mic: Float
    ) {
        if (!enabled) {
            status = "SKIN SFX PROTECT OFF"
            return
        }
        bulletProt = lane(protectOn, protectThr, protectLv, bullet)
        knifeProt = lane(protectOn, protectThr, protectLv, knife)
        sharpProt = lane(protectOn, protectThr, protectLv, sharp)
        burstProt = lane(protectOn, protectThr, protectLv, burst)
        pitchProt = lane(protectOn, protectThr, protectLv, pitch)
        atomSpikeProt = lane(protectOn, protectThr, protectLv, atomSpike)

        val threat = maxOf(bullet, knife, sharp, burst, pitch, atomSpike, mic * 0.4f)
        protectOut = lane(protectOn, protectThr, protectLv, threat)
        skinShieldAmbient = protectOut
        skinShield3d = maxOf(protectOut, bulletProt, knifeProt, sharpProt, burstProt, atomSpikeProt)

        status =
            "SKIN-PROT=${(protectOut*100).toInt()}% · " +
            "B=${(bulletProt*100).toInt()} K=${(knifeProt*100).toInt()} Sh=${(sharpProt*100).toInt()} " +
            "Br=${(burstProt*100).toInt()} P=${(pitchProt*100).toInt()} Spk=${(atomSpikeProt*100).toInt()}% · " +
            "3D-SHIELD=${(skinShield3d*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled) return
        // Cancel hostile SFX energy into bank
        if (protectOut > 0.02f) {
            val k = (1f - protectOut * 0.95f).coerceIn(0.02f, 1f)
            if (bulletProt > 0.02f) sb.bulletOut *= (1f - bulletProt * 0.96f).coerceIn(0.02f, 1f)
            if (knifeProt > 0.02f) sb.knifeOut *= (1f - knifeProt * 0.96f).coerceIn(0.02f, 1f)
            if (sharpProt > 0.02f) sb.sharpOut *= (1f - sharpProt * 0.96f).coerceIn(0.02f, 1f)
            if (burstProt > 0.02f) sb.burstOut *= (1f - burstProt * 0.96f).coerceIn(0.02f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
        }
        val vv = v ?: return
        // Ambient skin shield
        try {
            vv.allBodySkinAnatomy.allSkinOut = maxOf(vv.allBodySkinAnatomy.allSkinOut, skinShieldAmbient * 0.5f)
            vv.skinMultiMotion.skinAmbientOut = maxOf(vv.skinMultiMotion.skinAmbientOut, skinShieldAmbient * 0.5f)
            vv.skinAll.atmosphere = maxOf(vv.skinAll.atmosphere, skinShieldAmbient * 0.45f)
        } catch (_: Throwable) {}
        // 3D model skin layer shield
        try {
            val a = vv.anatomy3d
            a.layerOn[0] = true
            a.layerLevel[0] = maxOf(a.layerLevel[0], skinShield3d)
            a.atmosphere = maxOf(a.atmosphere, skinShield3d * 0.6f)
            a.audioFxLevel = maxOf(a.audioFxLevel, skinShield3d * 0.4f)
        } catch (_: Throwable) {}
        try {
            vv.skinAtomspare.atomSpareOut = maxOf(vv.skinAtomspare.atomSpareOut, skinShield3d)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, protectOut)
            vv.completeAtomProtect.atomOutsideOut = maxOf(vv.completeAtomProtect.atomOutsideOut, skinShieldAmbient)
        } catch (_: Throwable) {}
        // Stack with existing cancel boards
        try {
            vv.enemySoundCancel.burstCancelOut = maxOf(vv.enemySoundCancel.burstCancelOut, burstProt)
            vv.enemySoundCancel.knifeCancelOut = maxOf(vv.enemySoundCancel.knifeCancelOut, knifeProt)
            vv.enemySoundCancel.atomEnemyCancelOut = maxOf(vv.enemySoundCancel.atomEnemyCancelOut, atomSpikeProt, protectOut)
            vv.sharpBurstMeter.antiBulletOut = maxOf(vv.sharpBurstMeter.antiBulletOut, bulletProt)
            vv.sharpBurstMeter.antiKnifeOut = maxOf(vv.sharpBurstMeter.antiKnifeOut, knifeProt)
        } catch (_: Throwable) {}
    }
}
