package com.mizan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import android.os.BatteryManager
import android.provider.Settings
import kotlin.math.abs

/**
 * Fully interconnected own-device protection:
 *   energy / screen thr → GPU budget → discharge protect → stuck dampen
 *   + GPS tracking protection (limit exposure on THIS device)
 *
 * Does NOT: drain other batteries, stuck other apps, track other phones.
 */
class SystemGuardEngine(private val appCtx: Context) {

    // —— colour ——
    @Volatile var colorGuardOn = true
    @Volatile var colorThr = 0.45f
    @Volatile var colorRail = 160
    @Volatile var colorTripped = false

    // —— battery (this device) ——
    @Volatile var battGuardOn = true
    @Volatile var battFloorPct = 25
    @Volatile var battDischargeThrMa = 200
    @Volatile var battPct = 100
    @Volatile var battDischarging = false
    @Volatile var battCurrentMa = 0
    @Volatile var battProtectActive = false

    // —— spike → discharge ——
    @Volatile var spikeDischProtectOn = true
    @Volatile var dischargeThr = 0.70f   // energy threshold to trip discharge protect
    @Volatile var dischDbNeg = -60f
    @Volatile var dischDbPos = 60f
    @Volatile var spikeDischActive = false

    // —— screen ——
    @Volatile var screenThrOn = true
    @Volatile var screenThr = 0.50f
    @Volatile var avIntensityOn = true
    @Volatile var avIntensityThr = 0.55f

    // Battery / charge / discharge intensity (own device)
    @Volatile var battIntensityOn = true
    @Volatile var battIntensityThr = 0.50f
    @Volatile var battIntensityLv = 0.70f
    @Volatile var chargeIntensityOn = true
    @Volatile var chargeIntensityThr = 0.40f
    @Volatile var chargeIntensityLv = 0.65f
    @Volatile var dischargeIntensityOn = true
    @Volatile var dischargeIntensityThr = 0.55f
    @Volatile var dischargeIntensityLv = 0.75f
    @Volatile var battIntensityActive = false
    @Volatile var chargeIntensityActive = false
    @Volatile var dischargeIntensityActive = false

    // Screen threshold discharging protection
    @Volatile var screenDischOn = true
    @Volatile var screenDischThr = 0.55f
    @Volatile var screenDischActive = false

    // Enemies screen threshold discharging (local path only)
    @Volatile var enemyScreenDischOn = true
    @Volatile var enemyScreenDischThr = 0.60f

    // Enemy / app stuck + display spike (own-device process load proxy)
    @Volatile var enemyAppStuckOn = true
    @Volatile var enemyAppStuckThr = 0.55f
    @Volatile var enemyAppStuckActive = false

    // Enemy intensity (local path only — not other devices)
    @Volatile var enemyIntensityOn = true
    @Volatile var enemyIntensityThr = 0.50f
    @Volatile var enemyIntensityLv = 0.70f
    @Volatile var enemyIntensityActive = false

    // Own-device battery discharge intensity (NEVER other phones)
    @Volatile var enemyBattDischOn = true
    @Volatile var enemyBattDischThr = 0.60f
    @Volatile var enemyBattDischLv = 0.65f
    @Volatile var enemyBattDischActive = false
    @Volatile var displaySpikeOn = true
    @Volatile var displaySpikeThr = 0.60f
    @Volatile var displaySpikeLv = 0.75f
    @Volatile var displaySpikeActive = false
    @Volatile var appStuckDisplaySpikeOn = true
    @Volatile var runningProcCount = 0
    @Volatile var runningProcHint = ""
    @Volatile var enemyScreenDischActive = false
    @Volatile var screenProtectActive = false
    @Volatile var screenStuckProtect = false
    @Volatile var screenChangeDampen = 0f

    // —— enemies-path stuck threshold (local UI only) ——
    @Volatile var enemyStuckOn = true
    @Volatile var enemyStuckThr = 0.65f
    @Volatile var appStuckThr = 0.65f
    @Volatile var enemyStuckActive = false

    // —— GPU ——
    @Volatile var gpuGuardOn = true
    @Volatile var gpuThr = 0.60f
    @Volatile var gpuBudget = 1f
    @Volatile var gpuLoad = 0f
    @Volatile var gpuTripped = false

    // —— GPS tracking protection (this device) ——
    @Volatile var gpsProtectOn = true
    @Volatile var gpsThreatThr = 0.50f
    @Volatile var gpsProviderOn = false
    @Volatile var gpsProtectActive = false
    @Volatile var gpsLockDown = false

    @Volatile var energyIn = 0f
    @Volatile var lastDb = -80.0
    @Volatile var chainLevel = 0  // 0 idle … 4 max interconnect
    @Volatile var intensityCut = 1f

    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            if (intent?.action != Intent.ACTION_BATTERY_CHANGED) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 100)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            battPct = (level * 100) / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            battDischarging = status == BatteryManager.BATTERY_STATUS_DISCHARGING ||
                status == BatteryManager.BATTERY_STATUS_NOT_CHARGING
            val bm = appCtx.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            if (bm != null) {
                battCurrentMa = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) / 1000
            }
            recomputeBatt()
        }
    }

    fun start() {
        if (registered) return
        try {
            appCtx.registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            registered = true
        } catch (_: Exception) {}
    }

    fun stop() {
        if (!registered) return
        try { appCtx.unregisterReceiver(receiver) } catch (_: Exception) {}
        registered = false
    }

    private fun recomputeBatt() {
        if (!battGuardOn) {
            battProtectActive = false
            return
        }
        val heavy = battDischarging && abs(battCurrentMa) >= battDischargeThrMa
        battProtectActive = battDischarging && (battPct <= battFloorPct || heavy)
    }

    private fun refreshGpsState() {
        try {
            val lm = appCtx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            gpsProviderOn = lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true ||
                lm?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true
        } catch (_: Exception) {
            gpsProviderOn = false
        }
        // High energy while GPS on = tracking-exposure risk → protect
        gpsProtectActive = gpsProtectOn && gpsProviderOn && energyIn >= gpsThreatThr
        // Lockdown when chain is high AND GPS on
        gpsLockDown = gpsProtectActive && chainLevel >= 2
    }

    /**
     * Full interconnect:
     *  energy → screen → enemy-stuck → GPU → discharge → GPS protect
     * Each stage tightens the next.
     */
    fun tick(energy: Float, drawLoadProxy: Float, dbLevel: Double = -80.0) {
        energyIn = energy.coerceIn(0f, 1f)
        gpuLoad = drawLoadProxy.coerceIn(0f, 1f)
        lastDb = dbLevel

        // 1) Screen
        screenProtectActive = screenThrOn && energyIn >= screenThr
        val avHit = avIntensityOn && energyIn >= avIntensityThr

        // 2) Enemies-path stuck (local only)
        enemyStuckActive = enemyStuckOn && energyIn >= maxOf(enemyStuckThr, appStuckThr)
        enemyAppStuckActive = enemyAppStuckOn && energyIn >= enemyAppStuckThr.coerceIn(0.05f, 1f)
        // Display spike: high energy + process pressure → treat as screen stuck
        val procPressure = (runningProcCount.coerceIn(0, 40) / 40f)
        displaySpikeActive = displaySpikeOn && (
            energyIn >= displaySpikeThr.coerceIn(0.05f, 1f) ||
            (procPressure >= 0.55f && energyIn >= displaySpikeThr * 0.7f)
        )
        val appStuckSpike = appStuckDisplaySpikeOn && (enemyAppStuckActive || enemyStuckActive) && displaySpikeActive
        screenStuckProtect = (avHit && screenProtectActive) || enemyStuckActive ||
            enemyAppStuckActive || displaySpikeActive || appStuckSpike
        screenChangeDampen = when {
            screenStuckProtect -> 0.90f
            screenProtectActive -> 0.55f
            avHit -> 0.35f
            else -> 0f
        }

        // 3) Colour
        colorTripped = colorGuardOn && energyIn >= colorThr

        // 4) Spike → discharge (±120 dB rails)
        val lo = dischDbNeg.coerceIn(-120f, 0f).toDouble()
        val hi = dischDbPos.coerceIn(0f, 120f).toDouble()
        val dbHit = dbLevel <= lo || dbLevel >= hi || energyIn >= 0.85f
        spikeDischActive = spikeDischProtectOn && dbHit && (battDischarging || energyIn >= dischargeThr)

        // Battery / charge / discharge intensity
        recomputeBatt()
        battIntensityActive = battIntensityOn && energyIn >= battIntensityThr &&
            (battDischarging || battPct <= battFloorPct + 15)
        chargeIntensityActive = chargeIntensityOn && !battDischarging && energyIn >= chargeIntensityThr
        dischargeIntensityActive = dischargeIntensityOn && battDischarging && energyIn >= dischargeIntensityThr

        // Screen threshold discharging + enemies path (local UI only)
        screenDischActive = screenDischOn && battDischarging && energyIn >= screenDischThr
        enemyScreenDischActive = enemyScreenDischOn && energyIn >= enemyScreenDischThr &&
            (battDischarging || dischargeIntensityActive || spikeDischActive)

        // Enemy intensity + enemy-path battery discharge protect (OWN DEVICE only —
        // reduces this phone's GPU/draw under local threat; does NOT drain other phones)
        enemyIntensityActive = enemyIntensityOn && energyIn >= enemyIntensityThr.coerceIn(0.05f, 1f)
        enemyBattDischActive = enemyBattDischOn && energyIn >= enemyBattDischThr.coerceIn(0.05f, 1f) &&
            (battDischarging || dischargeIntensityActive || enemyIntensityActive)

        if (screenDischActive || enemyScreenDischActive) {
            screenProtectActive = true
            screenStuckProtect = true
            screenChangeDampen = maxOf(screenChangeDampen, 0.92f)
        }

        // Intensity levels scale GPU budget further
        intensityCut = 1f
        if (battIntensityActive) intensityCut *= (1f - battIntensityLv * 0.35f)
        if (chargeIntensityActive) intensityCut *= (1f - chargeIntensityLv * 0.20f)
        if (dischargeIntensityActive) intensityCut *= (1f - dischargeIntensityLv * 0.40f)
        if (enemyIntensityActive) intensityCut *= (1f - enemyIntensityLv * 0.35f)
        if (enemyBattDischActive) intensityCut *= (1f - enemyBattDischLv * 0.30f)

        // 5) Chain level (interconnect strength)
        chainLevel = 0
        if (screenProtectActive) chainLevel++
        if (enemyStuckActive || enemyAppStuckActive || screenStuckProtect || screenDischActive || enemyScreenDischActive || displaySpikeActive) chainLevel++
        if (spikeDischActive || dischargeIntensityActive) chainLevel++
        if (enemyIntensityActive || enemyBattDischActive) chainLevel++
        if (battProtectActive || battIntensityActive) chainLevel++
        // stash intensity cut into gpu via later multiply

        // 6) GPU budget from full chain
        gpuTripped = gpuGuardOn && (gpuLoad >= gpuThr || chainLevel >= 2)
        gpuBudget = when {
            !gpuGuardOn -> 1f
            chainLevel >= 4 -> 0.15f
            chainLevel >= 3 || (gpuTripped && battProtectActive) -> 0.25f
            chainLevel >= 2 || gpuTripped -> 0.40f
            chainLevel >= 1 -> 0.60f
            else -> 1f
        }

        // 7) GPS tracking protection
        refreshGpsState()
        gpuBudget = (gpuBudget * intensityCut).coerceIn(0.10f, 1f)
        if (screenDischActive || enemyScreenDischActive) {
            gpuBudget = minOf(gpuBudget, 0.28f)
        }
        if (displaySpikeActive) {
            gpuBudget = minOf(gpuBudget, (1f - displaySpikeLv * 0.55f).coerceIn(0.12f, 0.45f))
            screenChangeDampen = maxOf(screenChangeDampen, 0.55f + displaySpikeLv * 0.35f)
        }
        if (enemyAppStuckActive) {
            gpuBudget = minOf(gpuBudget, 0.32f)
            screenChangeDampen = maxOf(screenChangeDampen, 0.65f)
        }
        if (gpsLockDown) {
            // further cut draw when location exposure + threat
            gpuBudget = minOf(gpuBudget, 0.30f)
        }
    }

    fun effectiveColorCeiling(base: Int): Int {
        if (!colorTripped) return base.coerceIn(0, 255)
        return minOf(base, colorRail).coerceIn(0, 255)
    }

    fun drawScale(): Float = gpuBudget.coerceIn(0.10f, 1f)

    /**
     * Sample THIS device process list (ActivityManager).
     * On modern Android, results are limited to the caller's own UID processes —
     * not other users' apps. Used only as local load pressure for stuck/spike.
     */
    fun sampleRunningProcesses() {
        try {
            val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
                ?: return
            val list = am.runningAppProcesses ?: emptyList()
            runningProcCount = list.size
            runningProcHint = list.take(4).joinToString(",") { it.processName.substringAfterLast('.') }
        } catch (_: Exception) {
            runningProcCount = 0
            runningProcHint = ""
        }
    }

    fun statusLine(): String {
        val parts = mutableListOf<String>()
        if (screenProtectActive) parts.add("SCR")
        if (screenStuckProtect) parts.add("STUCK")
        if (enemyStuckActive) parts.add("E-STUCK")
        if (enemyAppStuckActive) parts.add("E-APP-STUCK")
        if (enemyIntensityActive) parts.add("E-INT")
        if (enemyBattDischActive) parts.add("E-BATT-DISCH")
        if (displaySpikeActive) parts.add("DISP-SPIKE")
        if (screenDischActive) parts.add("SCR-DISCH")
        if (enemyScreenDischActive) parts.add("E-SCR-DISCH")
        if (gpuTripped) parts.add("GPU")
        if (spikeDischActive) parts.add("SPIKE-DISCH")
        if (battIntensityActive) parts.add("BATT-INT")
        if (chargeIntensityActive) parts.add("CHG-INT")
        if (dischargeIntensityActive) parts.add("DISCH-INT")
        if (battProtectActive) parts.add("BATT")
        if (gpsProtectActive) parts.add(if (gpsLockDown) "GPS-LOCK" else "GPS-PROT")
        if (parts.isEmpty()) parts.add("idle")
        return "CHAIN L$chainLevel E=${(energyIn*100).toInt()}% · ${parts.joinToString("+")} · bud=${(gpuBudget*100).toInt()}% bat=${battPct}% procs=$runningProcCount [$runningProcHint] gps=${if (gpsProviderOn) "ON" else "off"}"
    }
}
