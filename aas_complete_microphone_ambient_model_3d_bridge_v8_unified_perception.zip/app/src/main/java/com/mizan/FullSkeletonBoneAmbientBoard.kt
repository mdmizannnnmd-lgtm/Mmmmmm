package com.mizan

/**
 * Full skeleton / bone ambient · skull · face · occiput · limbs · hands · feet ·
 * SCALP layers · bone cells · heart bone-adjacent · 3D skeleton layer ·
 * enemy bone/skeleton thr (symbolic — cannot control real people) ·
 * mic ±dB · gun-hand intensity · neural spike protect.
 * RAW COMPLETE.
 */
class FullSkeletonBoneAmbientBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.18f
    @Volatile var lv = 0.92f

    @Volatile var skeletonOn = true

    // Skull / head
    @Volatile var craniumOut = 0f
    @Volatile var frontal = 0f
    @Volatile var parietal = 0f
    @Volatile var temporal = 0f
    @Volatile var occipital = 0f
    @Volatile var sphenoid = 0f
    @Volatile var ethmoid = 0f
    @Volatile var faceSkeleton = 0f
    @Volatile var mandible = 0f
    @Volatile var maxilla = 0f
    @Volatile var zygomatic = 0f
    @Volatile var headBack = 0f
    @Volatile var scalpSkinBone = 0f

    // Eyes orbit bone
    @Volatile var eyeOrbitL = 0f
    @Volatile var eyeOrbitR = 0f
    @Volatile var eyeBoneL = 0f
    @Volatile var eyeBoneR = 0f
    @Volatile var noseBone = 0f
    @Volatile var neckBone = 0f
    @Volatile var assBone = 0f
    @Volatile var sacrumBone = 0f
    @Volatile var coccyxBone = 0f
    @Volatile var boneWithSkin = 0f
    @Volatile var eyePitchProtectOn = true
    @Volatile var eyePitchThr = 0.18f
    @Volatile var eyePitchLv = 0.95f
    @Volatile var eyePitchOut = 0f
    @Volatile var eyePitchProtect = 0f

    // Axial / limbs
    @Volatile var spineBone = 0f
    @Volatile var ribBone = 0f
    @Volatile var pelvisBone = 0f
    @Volatile var armBoneL = 0f
    @Volatile var armBoneR = 0f
    @Volatile var handBoneL = 0f
    @Volatile var handBoneR = 0f
    @Volatile var legBoneL = 0f
    @Volatile var legBoneR = 0f
    @Volatile var footBoneL = 0f
    @Volatile var footBoneR = 0f
    @Volatile var skeletonFull = 0f

    // Bone cells (symbolic)
    @Volatile var osteoblast = 0f
    @Volatile var osteoclast = 0f
    @Volatile var osteocyte = 0f

    // Enemy bone/skeleton threshold control (symbolic protect)
    @Volatile var enemyBoneOn = true
    @Volatile var enemyBoneThr = 0.20f
    @Volatile var enemyBoneLv = 0.95f
    @Volatile var enemyBoneOut = 0f
    @Volatile var enemyMoveBlock = 0f
    @Volatile var enemyFightBlock = 0f
    @Volatile var enemyWalkBlock = 0f
    @Volatile var enemyHandFightBlock = 0f
    @Volatile var enemyGunHandBlock = 0f
    @Volatile var gunIntensityDet = 0f
    @Volatile var gunProtectOut = 0f

    // Neural spike protect
    @Volatile var neuroSpikeOn = true
    @Volatile var neuroSpikeThr = 0.22f
    @Volatile var neuroSpikeLv = 0.95f
    @Volatile var neuroSpikeOut = 0f
    @Volatile var neuroSpikeProtect = 0f

    // Mic bipolar-ish dB
    @Volatile var micDbLive = -60f
    @Volatile var micDbThrLo = -50f
    @Volatile var micDbThrHi = -5f
    @Volatile var micDbGate = 0f

    @Volatile var status = "SKELETON·BONE full idle"

    private fun lane(on: Boolean, t: Float, l: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * l).coerceIn(0f, 1f)
        val th = t.coerceIn(0.02f, 1f)
        return if (e >= th) (((e - th) / (1f - th).coerceAtLeast(0.05f)) * l).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, enemy: Float, burst: Float, bullet: Float, knife: Float, spike: Float) {
        if (!enabled) {
            status = "SKELETON OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        micDbLive = if (e < 1e-6f) -80f else (20f * kotlin.math.ln(e.coerceIn(1e-6f, 1f)) / kotlin.math.ln(10f)).coerceIn(-80f, 0f)
        micDbGate = if (micDbLive in micDbThrLo..micDbThrHi || rawComplete) {
            ((micDbLive - micDbThrLo) / (micDbThrHi - micDbThrLo).coerceAtLeast(1f)).coerceIn(0f, 1f)
        } else if (micDbLive > micDbThrHi) 1f else 0f

        val src = maxOf(e, micDbGate)
        frontal = lane(skeletonOn, thr, lv, src * 0.95f)
        parietal = lane(skeletonOn, thr, lv, src * 0.94f)
        temporal = lane(skeletonOn, thr, lv, src * 0.93f)
        occipital = lane(skeletonOn, thr, lv, src * 0.96f)
        sphenoid = lane(skeletonOn, thr, lv, src * 0.90f)
        ethmoid = lane(skeletonOn, thr, lv, src * 0.88f)
        craniumOut = maxOf(frontal, parietal, temporal, occipital, sphenoid, ethmoid)
        mandible = lane(skeletonOn, thr, lv, src * 0.92f)
        maxilla = lane(skeletonOn, thr, lv, src * 0.90f)
        zygomatic = lane(skeletonOn, thr, lv, src * 0.91f)
        faceSkeleton = maxOf(mandible, maxilla, zygomatic)
        headBack = occipital
        scalpSkinBone = lane(skeletonOn, thr, lv, src * 0.94f)
        eyeOrbitL = lane(skeletonOn, thr, lv, src * 0.91f)
        eyeOrbitR = lane(skeletonOn, thr, lv, src * 0.91f)
        eyeBoneL = eyeOrbitL
        eyeBoneR = eyeOrbitR
        noseBone = lane(skeletonOn, thr, lv, src * 0.90f)
        neckBone = lane(skeletonOn, thr, lv, src * 0.94f)
        assBone = lane(skeletonOn, thr, lv, src * 0.91f)
        sacrumBone = assBone * 0.98f
        coccyxBone = assBone * 0.92f
        boneWithSkin = maxOf(skeletonFull * 0.5f, scalpSkinBone, src * 0.85f)
        spineBone = lane(skeletonOn, thr, lv, src * 0.95f)
        ribBone = lane(skeletonOn, thr, lv, src * 0.93f)
        pelvisBone = lane(skeletonOn, thr, lv, src * 0.92f)
        armBoneL = lane(skeletonOn, thr, lv, src * 0.91f)
        armBoneR = lane(skeletonOn, thr, lv, src * 0.91f)
        handBoneL = lane(skeletonOn, thr, lv, src * 0.90f)
        handBoneR = lane(skeletonOn, thr, lv, src * 0.90f)
        legBoneL = lane(skeletonOn, thr, lv, src * 0.92f)
        legBoneR = lane(skeletonOn, thr, lv, src * 0.92f)
        footBoneL = lane(skeletonOn, thr, lv, src * 0.89f)
        footBoneR = lane(skeletonOn, thr, lv, src * 0.89f)
        osteoblast = lane(skeletonOn, thr, lv, src * 0.88f)
        osteoclast = lane(skeletonOn, thr, lv, src * 0.85f)
        osteocyte = lane(skeletonOn, thr, lv, src * 0.87f)
        skeletonFull = maxOf(
            craniumOut, faceSkeleton, spineBone, armBoneL, legBoneL, handBoneL,
            neckBone, noseBone, eyeBoneL, assBone, footBoneL, skeletonOn.toFloat()
        )
        boneWithSkin = maxOf(boneWithSkin, skeletonFull * 0.9f, scalpSkinBone)

        val threat = maxOf(enemy, burst, bullet, knife, e * 0.4f)
        enemyBoneOut = lane(enemyBoneOn, enemyBoneThr, enemyBoneLv, threat)
        enemyMoveBlock = enemyBoneOut
        enemyFightBlock = enemyBoneOut * 0.98f
        enemyWalkBlock = enemyBoneOut * 0.96f
        enemyHandFightBlock = maxOf(enemyBoneOut, handBoneL, handBoneR) * 0.95f
        gunIntensityDet = maxOf(bullet, burst, knife * 0.5f)
        gunProtectOut = lane(enemyBoneOn, enemyBoneThr, enemyBoneLv, gunIntensityDet)
        enemyGunHandBlock = maxOf(gunProtectOut, enemyHandFightBlock)

        neuroSpikeOut = lane(neuroSpikeOn, neuroSpikeThr, neuroSpikeLv, maxOf(spike, threat * 0.8f))
        neuroSpikeProtect = neuroSpikeOut
        eyePitchOut = lane(eyePitchProtectOn, eyePitchThr, eyePitchLv, maxOf(spike, knife, e * 0.5f, eyeBoneL, eyeBoneR))
        eyePitchProtect = eyePitchOut

        status =
            "SKEL full=${(skeletonFull*100).toInt()}% skull/face/back=${(craniumOut*100).toInt()}/${(faceSkeleton*100).toInt()}/${(headBack*100).toInt()} · " +
            "hand/leg=${(handBoneL*100).toInt()}/${(legBoneL*100).toInt()} · " +
            "ENEMY bone/move/fight/walk/gun=${(enemyBoneOut*100).toInt()}/${(enemyMoveBlock*100).toInt()}/${(enemyFightBlock*100).toInt()}/${(enemyWalkBlock*100).toInt()}/${(enemyGunHandBlock*100).toInt()} · " +
            "NEURO=${(neuroSpikeProtect*100).toInt()}% EYE-PITCH=${(eyePitchProtect*100).toInt()}% · " +
            "neck/nose/ass/hand=${(neckBone*100).toInt()}/${(noseBone*100).toInt()}/${(assBone*100).toInt()}/${(handBoneL*100).toInt()} · " +
            "BONE+SKIN=${(boneWithSkin*100).toInt()}% dB=${"%.0f".format(micDbLive)}" +
            if (rawComplete) " · RAW" else ""
    }

    private fun Boolean.toFloat() = if (this) 0.5f else 0f

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled) return
        val block = maxOf(enemyMoveBlock, enemyFightBlock, enemyGunHandBlock, neuroSpikeProtect)
        if (block > 0.02f) {
            val k = (1f - block * 0.96f).coerceIn(0.02f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
            sb.bulletOut *= (1f - enemyGunHandBlock * 0.95f).coerceIn(0.02f, 1f)
            sb.burstOut *= (1f - gunProtectOut * 0.9f).coerceIn(0.05f, 1f)
            sb.knifeOut *= (1f - enemyHandFightBlock * 0.9f).coerceIn(0.05f, 1f)
            sb.whipOut *= k
        }
        val vv = v ?: return
        try {
            if (vv.anatomy3d.layerOn.size > 2) {
                vv.anatomy3d.layerOn[2] = true
                vv.anatomy3d.layerLevel[2] = maxOf(vv.anatomy3d.layerLevel[2], skeletonFull)
            }
            vv.anatomy3d.atmosphere = maxOf(vv.anatomy3d.atmosphere, skeletonFull * 0.4f)
        } catch (_: Throwable) {}
        try {
            vv.skeletonWaterAstro.skeletonFull = maxOf(vv.skeletonWaterAstro.skeletonFull, skeletonFull)
            vv.skeletonWaterAstro.skullOut = maxOf(vv.skeletonWaterAstro.skullOut, craniumOut)
            vv.skeletonWaterAstro.femurOut = maxOf(vv.skeletonWaterAstro.femurOut, legBoneL, legBoneR)
            vv.skeletonWaterAstro.osteoblast = maxOf(vv.skeletonWaterAstro.osteoblast, osteoblast)
            vv.skeletonWaterAstro.osteoclast = maxOf(vv.skeletonWaterAstro.osteoclast, osteoclast)
        } catch (_: Throwable) {}
        try {
            vv.fullBodyMotionLock.lockFull = maxOf(vv.fullBodyMotionLock.lockFull, enemyMoveBlock)
            vv.fullBodyMotionLock.lockHands = maxOf(vv.fullBodyMotionLock.lockHands, enemyHandFightBlock, enemyGunHandBlock)
            vv.fullBodyMotionLock.lockLegs = maxOf(vv.fullBodyMotionLock.lockLegs, enemyWalkBlock)
            vv.fullBodyMotionLock.lockOut = maxOf(vv.fullBodyMotionLock.lockOut, block)
        } catch (_: Throwable) {}
        try {
            vv.bodyRegionEnemyProtect.fullBodyProt = maxOf(vv.bodyRegionEnemyProtect.fullBodyProt, enemyBoneOut)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, neuroSpikeProtect)
            vv.skinHead.atmosphere = maxOf(vv.skinHead.atmosphere, craniumOut * 0.3f, scalpSkinBone * 0.3f, headBack * 0.25f)
            vv.eyeL.atmosphere = maxOf(vv.eyeL.atmosphere, eyeOrbitL * 0.35f)
            vv.eyeR.atmosphere = maxOf(vv.eyeR.atmosphere, eyeOrbitR * 0.35f, eyeBoneR * 0.35f)
            vv.eyeL.atmosphere = maxOf(vv.eyeL.atmosphere, eyeBoneL * 0.35f, eyePitchProtect * 0.3f)
            vv.neck.atmosphere = maxOf(vv.neck.atmosphere, neckBone * 0.4f)
            vv.face.atmosphere = maxOf(vv.face.atmosphere, noseBone * 0.35f, faceSkeleton * 0.3f)
            try {
                vv.skinAbdomen.atmosphere = maxOf(vv.skinAbdomen.atmosphere, assBone * 0.25f)
                vv.handL.atmosphere = maxOf(vv.handL.atmosphere, handBoneL * 0.35f)
                vv.handR.atmosphere = maxOf(vv.handR.atmosphere, handBoneR * 0.35f)
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}
        try {
            vv.eyesCompleteLock.eyeLockOut = maxOf(vv.eyesCompleteLock.eyeLockOut, eyePitchProtect)
            vv.eyesCompleteLock.eyeMoveBlocked = maxOf(vv.eyesCompleteLock.eyeMoveBlocked, eyePitchProtect)
            vv.fullAmbientMaster.pitchOut *= (1f - eyePitchProtect * 0.7f).coerceIn(0.1f, 1f)
            if (eyePitchProtect > 0.02f) {
                sb.sharpOut *= (1f - eyePitchProtect * 0.85f).coerceIn(0.05f, 1f)
            }
        } catch (_: Throwable) {}
        try {
            vv.enemySoundCounters.antiBulletOut = maxOf(vv.enemySoundCounters.antiBulletOut, enemyGunHandBlock)
            vv.enemySoundCounters.antiBurstOut = maxOf(vv.enemySoundCounters.antiBurstOut, gunProtectOut)
            vv.fullAmbientMaster.spikeOut = maxOf(vv.fullAmbientMaster.spikeOut, neuroSpikeOut * 0.3f)
        } catch (_: Throwable) {}
    }
}
