package com.mizan

import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow

/**
 * One 0..1 energy → level path with every control the ambient boards have:
 * threshold · level · "degains" (dB gain on each side of the threshold, −300…0 / 0…+300) ·
 * bipolar ±120 dB rails (measured relative to the threshold, 0 dB = threshold) · attack / release · RAW COMPLETE.
 *
 * RAW COMPLETE passes the input straight through: no threshold, level, gain, rails or smoothing.
 */
class SignalPath {
    @Volatile var on = true
    @Volatile var thr = 0.20f
    @Volatile var level = 0.70f
    @Volatile var gainNegDb = 0f      // applied while the signal is below the threshold (−300…0)
    @Volatile var gainPosDb = 0f      // applied while the signal is above the threshold (0…+300)
    @Volatile var bipOn = true
    @Volatile var bipNeg = -40f       // FLOOR rail  −120…0 dB relative to the threshold
    @Volatile var bipPos = 12f        // OVER rail   0…+120 dB relative to the threshold
    @Volatile var overDamp = 0.60f    // gain left when the OVER rail trips
    @Volatile var attackMs = 40
    @Volatile var releaseMs = 250
    @Volatile var raw = false

    @Volatile var out = 0f
        private set
    @Volatile var active = false
        private set
    @Volatile var overHit = false
        private set
    @Volatile var underHit = false
        private set
    @Volatile var relDb = 0.0
        private set

    private var env = 0f
    private var lastMs = 0L

    /** Oneness link: lifts the output (and the smoothing state) to at least [v] without touching threshold / gain. */
    fun blend(v: Float) {
        if (!on) return
        val x = v.coerceIn(0f, 1f)
        if (x > out) { out = x; env = max(env, x); active = active || x > 0.001f }
    }

    fun tick(energy: Float): Float {
        val now = System.currentTimeMillis()
        val dt = if (lastMs == 0L) 0.02f else ((now - lastMs) / 1000f).coerceIn(0.001f, 0.2f)
        lastMs = now
        val x = energy.coerceIn(0f, 1f)
        if (!on) {
            env = 0f; out = 0f; active = false; overHit = false; underHit = false
            return 0f
        }
        if (raw) {
            env = x; out = x; active = x > 0.001f; overHit = false; underHit = false
            relDb = 20.0 * log10(max(x, 0.00001f).toDouble())
            return x
        }
        val t = thr.coerceIn(0.01f, 0.99f)
        val refDb = 20.0 * log10(t.toDouble())
        val xDb = 20.0 * log10(max(x, 0.00001f).toDouble())
        val below = xDb < refDb
        val gain = if (below) gainNegDb.coerceIn(-300f, 0f) else gainPosDb.coerceIn(0f, 300f)
        val rel = (xDb - refDb + gain).coerceIn(-120.0, 120.0)
        relDb = rel
        val xg = if (gain == 0f) x else (x * 10.0.pow(gain / 20.0)).toFloat().coerceIn(0f, 1f)
        overHit = bipOn && rel >= bipPos.coerceIn(0f, 120f)
        underHit = bipOn && rel <= bipNeg.coerceIn(-120f, 0f)
        active = xg >= t
        var y = if (active) ((xg - t) / (1f - t).coerceAtLeast(0.02f)) * level.coerceIn(0f, 1f) else 0f
        if (overHit) y *= overDamp.coerceIn(0f, 1f)
        // attack / release
        val ms = if (y > env) attackMs else releaseMs
        val tau = ms.coerceIn(1, 5000) / 1000f
        env += (y - env) * (1f - exp(-dt / tau))
        out = env.coerceIn(0f, 1f)
        return out
    }
}
