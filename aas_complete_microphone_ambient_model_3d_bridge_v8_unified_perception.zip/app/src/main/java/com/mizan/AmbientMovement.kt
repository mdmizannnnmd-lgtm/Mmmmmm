package com.mizan

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sqrt

/**
 * AMBIENT MOVEMENT — a new output of the ambient threshold board.
 *
 * It measures how much everything is MOVING and sends that to the complete 3D anatomy body, inside and outside:
 *
 *  sources   device motion (accelerometer / gyro) · body centroid speed (the 3D body's own centroid) ·
 *            ambient level over the threshold · camera body (pose / segmentation) — each with its own mix weight.
 *  shaping   LEVEL · THRESHOLD · BIPOLAR (rail above the threshold pushes one way, rail below the other way,
 *            each with its own gain) · attack / release smoothing · RAW COMPLETE (no level, threshold or smoothing).
 *  outputs   [out] 0..1 · [bip] −1..+1 · [inOut] (inside) · [outOut] (outside) and the body offsets below.
 *
 * OUTSIDE (skin · muscle · face — the whole body moves): [outsideDx] / [outsideDy] as a fraction of the view, plus
 *   [outsideYaw] / [outsideTilt] in radians.
 * INSIDE (skeleton · organs · vessels · brain — moves on top of the body, lagging it a little like soft tissue):
 *   [insideDx] / [insideDy] / [insideDz] in body units and [insideLean] in radians.
 *
 * It only READS the app's boards. Everything defaults to a calm, small effect and switches off with [on] = false,
 * so the original behaviour is untouched when it is not used.
 */
class AmbientMovement {

    @Volatile var on = true
    @Volatile var raw = false
    @Volatile var rawEverything = false

    @Volatile var level = 0.85f           // 0..1.5
    @Volatile var thr = 0.20f             // 0.02..0.98 neutral point of the bipolar drive
    @Volatile var bipolar = true
    @Volatile var negGain = 1.0f          // rail below the threshold (0..1.5)
    @Volatile var posGain = 1.0f          // rail above the threshold (0..1.5)
    @Volatile var attackMs = 60
    @Volatile var releaseMs = 260

    // source mix
    @Volatile var wDevice = 0.80f
    @Volatile var wBody = 0.80f
    @Volatile var wAmbient = 0.60f
    @Volatile var wCamera = 0.60f

    // where it goes
    @Volatile var insideOn = true
    @Volatile var outsideOn = true
    @Volatile var insideAmt = 0.80f       // 0..2
    @Volatile var outsideAmt = 0.80f      // 0..2
    @Volatile var rangeOut = 0.05f        // max outside shift, fraction of the view (0..0.15)
    @Volatile var rangeIn = 0.12f         // max inside shift, body units (0..0.4)

    // live readout
    @Volatile var norm = 0f
        private set
    @Volatile var bip = 0f
        private set
    @Volatile var out = 0f
        private set
    @Volatile var hit = false
        private set
    @Volatile var inOut = 0f
        private set
    @Volatile var outOut = 0f
        private set
    @Volatile var srcDevice = 0f
        private set
    @Volatile var srcBody = 0f
        private set
    @Volatile var srcAmbient = 0f
        private set
    @Volatile var srcCamera = 0f
        private set

    // offsets applied by the renderer
    @Volatile var outsideDx = 0f
        private set
    @Volatile var outsideDy = 0f
        private set
    @Volatile var outsideYaw = 0f
        private set
    @Volatile var outsideTilt = 0f
        private set
    @Volatile var insideDx = 0f
        private set
    @Volatile var insideDy = 0f
        private set
    @Volatile var insideDz = 0f
        private set
    @Volatile var insideLean = 0f
        private set

    private var smooth = 0f
    private var dirX = 0f
    private var insLag = 0f
    private var lastCx = 0f
    private var lastCy = 0f
    private var haveLast = false
    private var lastMs = 0L

    fun isRaw() = raw || rawEverything

    /** Once per frame with the live ambient board and the view that owns the motion / camera sources. */
    fun tick(board: AmbientThresholdBoard, v: VisualShieldView) {
        val now = System.currentTimeMillis()
        val dt = if (lastMs == 0L) 0.02f else ((now - lastMs) / 1000f).coerceIn(0.001f, 0.2f)
        lastMs = now
        if (!on) { clear(); return }

        // ── sources ─────────────────────────────────────────────────────────────────────────────
        val mh = v.motionHub
        srcDevice = (mh?.liveMove ?: 0f).coerceIn(0f, 1f)
        val devX = ((mh?.axisX ?: 0f)).coerceIn(-1f, 1f)

        val cx = board.bodyCx; val cy = board.bodyCy
        val speed = if (haveLast) sqrt((cx - lastCx) * (cx - lastCx) + (cy - lastCy) * (cy - lastCy)) / dt else 0f
        val vx = if (haveLast) (cx - lastCx) / dt else 0f
        lastCx = cx; lastCy = cy; haveLast = true
        srcBody = (speed * 0.6f).coerceIn(0f, 1f)

        srcAmbient = if (board.overThr) (board.ambientOutPct / 100f).coerceIn(0f, 1f) else 0f
        srcCamera = max(v.poseSurface.dampen(), v.yoloSeg.dampen()).coerceIn(0f, 1f)

        val src = max(max(srcDevice * wDevice.coerceIn(0f, 1.5f), srcBody * wBody.coerceIn(0f, 1.5f)),
            max(srcAmbient * wAmbient.coerceIn(0f, 1.5f), srcCamera * wCamera.coerceIn(0f, 1.5f))).coerceIn(0f, 1f)
        norm = src

        // ── shaping: bipolar around the threshold ───────────────────────────────────────────────
        val raw = isRaw()
        val t = thr.coerceIn(0.02f, 0.98f)
        val drive = when {
            raw -> src * 2f - 1f
            src >= t -> ((src - t) / (1f - t)) * posGain.coerceIn(0f, 1.5f)
            bipolar -> -((t - src) / t) * negGain.coerceIn(0f, 1.5f)
            else -> 0f
        }
        val target = (if (raw) drive else drive * level.coerceIn(0f, 1.5f)).coerceIn(-1f, 1f)
        if (raw) {
            smooth = target
        } else {
            val rising = abs(target) > abs(smooth)
            val ms = (if (rising) attackMs else releaseMs).coerceIn(1, 5000) / 1000f
            smooth += (target - smooth) * (1f - exp(-dt / ms))
        }
        bip = smooth.coerceIn(-1f, 1f)
        out = if (raw) src else (if (src >= t) abs(bip) else 0f).coerceIn(0f, 1f)
        hit = out > 0.02f

        // horizontal direction follows where the body (or the phone) is moving
        val dTarget = (vx * 0.8f + devX * 0.6f).coerceIn(-1f, 1f)
        dirX = if (raw) dTarget else dirX + (dTarget - dirX) * (1f - exp(-dt / 0.15f))

        // ── 3D body outputs ─────────────────────────────────────────────────────────────────────
        outOut = if (outsideOn) (abs(bip) * outsideAmt.coerceIn(0f, 2f)).coerceIn(0f, 1.5f) else 0f
        inOut = if (insideOn) (abs(bip) * insideAmt.coerceIn(0f, 2f)).coerceIn(0f, 1.5f) else 0f

        val ro = rangeOut.coerceIn(0f, 0.15f)
        if (outsideOn) {
            val a = outsideAmt.coerceIn(0f, 2f)
            outsideDy = -bip * ro * a                      // above the threshold the body lifts, below it sinks
            outsideDx = dirX * abs(bip) * ro * a
            outsideTilt = dirX * abs(bip) * 0.20f * a      // leans into the move
            outsideYaw = bip * 0.12f * a
        } else { outsideDx = 0f; outsideDy = 0f; outsideTilt = 0f; outsideYaw = 0f }

        // inside = soft tissue: same move, but it lags the skin a little (low-pass) so it swings against the body
        insLag = if (raw) bip else insLag + (bip - insLag) * (1f - exp(-dt / 0.22f))
        val ri = rangeIn.coerceIn(0f, 0.4f)
        if (insideOn) {
            val a = insideAmt.coerceIn(0f, 2f)
            val slosh = bip - insLag                      // difference between skin and tissue → visible inside motion
            insideDy = (-insLag * 0.6f - slosh * 0.8f) * ri * a
            insideDx = dirX * (abs(insLag) * 0.6f + abs(slosh)) * ri * a
            insideDz = slosh * ri * a * 0.6f
            insideLean = -dirX * abs(insLag) * 0.15f * a
        } else { insideDx = 0f; insideDy = 0f; insideDz = 0f; insideLean = 0f }
    }

    private fun clear() {
        norm = 0f; bip = 0f; out = 0f; hit = false; inOut = 0f; outOut = 0f
        smooth = 0f; insLag = 0f; dirX = 0f
        outsideDx = 0f; outsideDy = 0f; outsideYaw = 0f; outsideTilt = 0f
        insideDx = 0f; insideDy = 0f; insideDz = 0f; insideLean = 0f
        haveLast = false
    }

    /** RAW COMPLETE on everything: no level, threshold or smoothing, both sides of the body, all sources full. */
    fun enableRawComplete() {
        on = true; raw = true
        insideOn = true; outsideOn = true
        wDevice = 1f; wBody = 1f; wAmbient = 1f; wCamera = 1f
    }

    fun line(): String =
        "MOVE ${(out * 100).toInt()}% (${"%+.2f".format(bip)}) IN ${(inOut * 100).toInt()}% OUT ${(outOut * 100).toInt()}%" +
            (if (!on) " · off" else "") + (if (isRaw()) " · RAW" else "")

    fun statusLine(): String =
        line() + "\nsrc dev ${(srcDevice * 100).toInt()}% · body ${(srcBody * 100).toInt()}% · amb ${(srcAmbient * 100).toInt()}% · cam ${(srcCamera * 100).toInt()}%"
}
