package com.mizan

import android.annotation.SuppressLint
import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout

/**
 * Floating WebView with URL bar · load website · back/forward/reload · close.
 * RAW COMPLETE.
 */
class FloatingWebController(private val activity: Activity) {

    @Volatile var visible = false
    @Volatile var lastUrl = "file:///android_asset/dev/index.html"

    private var root: View? = null
    private var web: WebView? = null
    private var urlBar: EditText? = null

    @SuppressLint("SetJavaScriptEnabled")
    fun ensureAttached() {
        if (root != null) return
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        val panel = activity.layoutInflater.inflate(R.layout.floating_web_panel, content, false)
        root = panel
        web = panel.findViewById(R.id.floatingWebView)
        urlBar = panel.findViewById(R.id.floatingWebUrl)
        val go = panel.findViewById<Button>(R.id.floatingWebGo)
        val close = panel.findViewById<Button>(R.id.floatingWebClose)
        val back = panel.findViewById<Button>(R.id.floatingWebBack)
        val fwd = panel.findViewById<Button>(R.id.floatingWebFwd)
        val reload = panel.findViewById<Button>(R.id.floatingWebReload)

        web?.apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val u = request?.url?.toString() ?: return false
                    view?.loadUrl(u)
                    urlBar?.setText(u)
                    lastUrl = u
                    return true
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    if (!url.isNullOrBlank()) {
                        urlBar?.setText(url)
                        lastUrl = url
                    }
                }
            }
        }

        go.setOnClickListener { loadFromBar() }
        close.setOnClickListener { hide() }
        back.setOnClickListener { if (web?.canGoBack() == true) web?.goBack() }
        fwd.setOnClickListener { if (web?.canGoForward() == true) web?.goForward() }
        reload.setOnClickListener { web?.reload() }
        urlBar?.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                loadFromBar(); true
            } else false
        }

        content.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        panel.visibility = View.GONE
    }

    fun show(url: String? = null) {
        ensureAttached()
        val raw = url ?: lastUrl
        val u = if (raw.startsWith("file:///android_asset/")) raw else normalizeUrl(raw)
        urlBar?.setText(u)
        web?.loadUrl(u)
        lastUrl = u
        root?.visibility = View.VISIBLE
        visible = true
    }

    fun hide() {
        root?.visibility = View.GONE
        visible = false
    }

    fun toggle(url: String? = null) {
        if (visible) hide() else show(url)
    }

    private fun loadFromBar() {
        val raw = urlBar?.text?.toString()?.trim().orEmpty()
        if (raw.isEmpty()) return
        val u = normalizeUrl(raw)
        urlBar?.setText(u)
        web?.loadUrl(u)
        lastUrl = u
    }

    private fun normalizeUrl(raw: String): String {
        val t = raw.trim()
        if (t.startsWith("http://") || t.startsWith("https://") || t.startsWith("file:")) return t
        return "https://$t"
    }

    fun onDestroy() {
        try {
            web?.stopLoading()
            web?.destroy()
        } catch (_: Throwable) {}
        web = null
        root = null
    }
}
