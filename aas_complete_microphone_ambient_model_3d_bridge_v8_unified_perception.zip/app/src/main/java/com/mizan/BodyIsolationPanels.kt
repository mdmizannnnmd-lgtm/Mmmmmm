package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object BodyIsolationPanels {
    fun build(ctx: Context, root: LinearLayout, b: BodyIsolationBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFFCC80.toInt()
        p.title("BODY ISOLATION · TWO SETTINGS (full app)", c)
        p.note("1) My body does not interact · AI/models do not drive my body  2) Enemy TX elsewhere · not my place")
        p.switch("Isolation master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("SETTING 1 · MY BODY NOT INTERACTING", c)
        p.switch("My body NO interaction with anything", b.myBodyNoInteract) { b.myBodyNoInteract = it }
        p.switch("AI / model does NOT drive my body", b.aiModelNotDriveMyBody) { b.aiModelNotDriveMyBody = it }
        p.switch("Block model interactions on my body", b.modelInteractionBlock) { b.modelInteractionBlock = it }
        p.switch("Block pose/seg push on my body", b.blockPoseSegOnMyBody) { b.blockPoseSegOnMyBody = it }
        p.switch("Block full-model push on my body", b.blockFullModelOnMyBody) { b.blockFullModelOnMyBody = it }
        p.switch("Block CNS model drive on body surface", b.blockCnsModelDriveOnBody) { b.blockCnsModelDriveOnBody = it }
        p.seek("Isolation strength", 0.1f, 1f, b.isolationStrength) { b.isolationStrength = it }

        p.title("SETTING 2 · ENEMY TX ELSEWHERE (not my place)", c)
        p.switch("Enemy transmission → elsewhere", b.enemyTxElsewhere) { b.enemyTxElsewhere = it }
        p.switch("Enemy NOT my place", b.enemyNotMyPlace) { b.enemyNotMyPlace = it }
        p.switch("Enemy NOT my body", b.enemyNotMyBody) { b.enemyNotMyBody = it }
        p.switch("Redirect enemy TX away", b.redirectEnemyTx) { b.redirectEnemyTx = it }
        p.seek("Enemy elsewhere level", 0.1f, 1f, b.enemyElsewhereLv) { b.enemyElsewhereLv = it }

        val st = p.status("ISOLATION —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
