package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object BodyAnatomyShellPanels {
    fun build(ctx: Context, root: LinearLayout, b: BodyAnatomyShellBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF80CBC4.toInt()
        p.title("BODY ANATOMY OUTSIDE+INSIDE · ATOMPARE SHELL (no enemy break-out)", c)
        p.note("Outside: epidermis·dermis·hypodermis · Inside: 9 systems · THRESHOLDED move/speed/wave · bipolar · thr-comm")
        p.switch("Anatomy shell master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Outside anatomy ON", b.outsideOn) { b.outsideOn = it }
        p.switch("Inside systems ON", b.insideOn) { b.insideOn = it }
        p.switch("Inside 3D atmospheric (atomspare interior)", b.insideAtmospheric) { b.insideAtmospheric = it }
        p.switch("Inside auto threshold", b.insideAutoThr) { b.insideAutoThr = it }
        p.seek("Inside atmo thr / lv", 0.05f, 0.98f, b.insideAtmoThr) { b.insideAtmoThr = it }
        p.seek("Inside atmo level", 0f, 1.5f, b.insideAtmoLv) { b.insideAtmoLv = it }
        p.switch("Enemy MODEL abuse protection", b.enemyModelAbuseProtect) { b.enemyModelAbuseProtect = it }
        p.switch("Enemy ATOMPARE abuse protection", b.enemyAtomAbuseProtect) { b.enemyAtomAbuseProtect = it }
        p.seek("Enemy model abuse thr", 0.05f, 0.98f, b.enemyModelAbuseThr) { b.enemyModelAbuseThr = it }
        p.seek("Enemy atomspare abuse thr", 0.05f, 0.98f, b.enemyAtomAbuseThr) { b.enemyAtomAbuseThr = it }
        p.seek("Abuse protect level", 0.1f, 1f, b.enemyAbuseProtectLv) { b.enemyAbuseProtectLv = it }
        p.switch("Atomspare shell ON", b.atomSpareShellOn) { b.atomSpareShellOn = it }
        p.switch("Enemies CANNOT break out atomspare", b.enemyCannotBreakOut) { b.enemyCannotBreakOut = it }
        p.seek("Shell level", 0.1f, 1f, b.atomSpareShellLv) { b.atomSpareShellLv = it }

        p.title("THRESHOLDED MOVEMENT · SPEED · WAVES", c)
        p.switch("Thresholded movement ON", b.thrMoveOn) { b.thrMoveOn = it }
        p.seek("Move thr / level", 0.05f, 0.98f, b.thrMoveThr) { b.thrMoveThr = it }
        p.seek("Move level", 0f, 1.5f, b.thrMoveLv) { b.thrMoveLv = it }
        p.switch("Thresholded speed ON", b.thrSpeedOn) { b.thrSpeedOn = it }
        p.seek("Speed thr", 0.05f, 0.98f, b.thrSpeedThr) { b.thrSpeedThr = it }
        p.seek("Speed level", 0f, 1.5f, b.thrSpeedLv) { b.thrSpeedLv = it }
        p.switch("Thresholded waves ON", b.thrWaveOn) { b.thrWaveOn = it }
        p.seek("Waves thr", 0.05f, 0.98f, b.thrWaveThr) { b.thrWaveThr = it }
        p.seek("Waves level", 0f, 1.5f, b.thrWaveLv) { b.thrWaveLv = it }

        p.title("BIPOLAR ±120 · THRESHOLD COMMUNICATION", c)
        p.switch("Bipolar threshold ON", b.bipolarOn) { b.bipolarOn = it }
        p.seek("Bipolar −dB", -120f, 0f, b.bipNegDb) { b.bipNegDb = it }
        p.seek("Bipolar +dB", 0f, 120f, b.bipPosDb) { b.bipPosDb = it }
        p.switch("Threshold communication ON", b.thrCommOn) { b.thrCommOn = it }
        p.seek("Thr-comm thr / lv", 0.05f, 0.98f, b.thrCommThr) { b.thrCommThr = it }
        p.seek("Thr-comm level", 0f, 1.5f, b.thrCommLv) { b.thrCommLv = it }
        p.switch("Block enemy thr-comm", b.thrCommEnemyBlock) { b.thrCommEnemyBlock = it }

        val st = p.status("SHELL —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
