package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object Body3dModelInteractPanels {
    fun build(ctx: Context, root: LinearLayout, b: Body3dModelInteractBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFCE93D8.toInt()
        p.title("3D MODEL BODY · AI-ONLY · OUR vs ENEMY · IN/OUT · ATOM/WAVE", c)
        p.switch("3D model body master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("My body interact with AI only", b.myBodyAiOnly) { b.myBodyAiOnly = it }
        p.switch("Block non-AI interaction", b.blockNonAiInteract) { b.blockNonAiInteract = it }

        p.title("OUR MODEL", c)
        p.switch("Our model ON", b.ourModelOn) { b.ourModelOn = it }
        p.seek("Our model thr", 0.05f, 0.98f, b.ourModelThr) { b.ourModelThr = it }
        p.seek("Our model level", 0f, 1.5f, b.ourModelLv) { b.ourModelLv = it }
        p.seek("Our model motion thr", 0.05f, 0.98f, b.ourModelMotionThr) { b.ourModelMotionThr = it }

        p.title("ENEMIES MODEL · TRANS-COMM", c)
        p.switch("Enemy model ON", b.enemyModelOn) { b.enemyModelOn = it }
        p.seek("Enemy model thr", 0.05f, 0.98f, b.enemyModelThr) { b.enemyModelThr = it }
        p.seek("Enemy model level", 0f, 1.5f, b.enemyModelLv) { b.enemyModelLv = it }
        p.seek("Enemy model motion thr", 0.05f, 0.98f, b.enemyModelMotionThr) { b.enemyModelMotionThr = it }
        p.seek("Enemy trans-comm thr", 0.05f, 0.98f, b.enemyTransCommThr) { b.enemyTransCommThr = it }

        p.title("AR MOTION THRESHOLD", c)
        p.switch("AR motion ON", b.arMotionOn) { b.arMotionOn = it }
        p.seek("AR motion thr", 0.05f, 0.98f, b.arMotionThr) { b.arMotionThr = it }
        p.seek("AR motion level", 0f, 1.5f, b.arMotionLv) { b.arMotionLv = it }

        p.title("INSIDE ↔ OUTSIDE · ATOMSPARE · WAVESPARE", c)
        p.switch("Interconnect inside↔outside", b.interconnectOn) { b.interconnectOn = it }
        p.seek("Interconnect strength", 0f, 1.5f, b.interconnectStrength) { b.interconnectStrength = it }
        p.switch("Atomspare 3D body ON", b.atomSpareOn) { b.atomSpareOn = it }
        p.seek("Atomspare thr / lv", 0.05f, 0.98f, b.atomSpareThr) { b.atomSpareThr = it }
        p.seek("Atomspare level", 0f, 1.5f, b.atomSpareLv) { b.atomSpareLv = it }
        p.switch("Wavespare 3D body ON", b.waveSpareOn) { b.waveSpareOn = it }
        p.seek("Wavespare thr", 0.05f, 0.98f, b.waveSpareThr) { b.waveSpareThr = it }
        p.seek("Wavespare level", 0f, 1.5f, b.waveSpareLv) { b.waveSpareLv = it }

        val st = p.status("3D MODEL —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
