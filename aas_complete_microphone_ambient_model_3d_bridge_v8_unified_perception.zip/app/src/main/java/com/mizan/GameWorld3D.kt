package com.mizan

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 3D GAME WORLD — a game-style 3D scene (ground grid, orbit camera, radar, health bars, name tags) that shows
 *   · YOU: your own tracked body (driven by the shared oneness field), and
 *   · every tracked signal body: enemy body, mic enemy, magnetic-field signal, camera pose body, camera-segmented body,
 *     anti-audio source and noise cloud — each one uses the same anatomy figure and appears when its signal crosses its
 *     threshold, stands where the signal is placed (louder = closer), walks at the speed of its energy, keeps a fading trail
 *     while it is lost, and gets an energy bar + ring on the ground in the app's own ring / ball style.
 *
 * It is a separate overlay: it only READS the app's boards and never changes them (original behaviour untouched).
 * RAW COMPLETE: no threshold, no level, no hold / smoothing — every body is shown with its live signal.
 */
class GameWorld3D {

    class Body(val key: String, val label: String, val color: Int, val defaultAngle: Float) {
        @Volatile var on = true
        var energy = 0f            // live (smoothed unless raw)
        var shown = 0f             // 0..1 fade (appearance)
        var angle = defaultAngle   // radians around YOU
        var dist = 2.5f
        var tx = 0f; var tz = 0f   // trail
        var seenMs = 0L
        val trail = FloatArray(24)  // ring buffer x,z pairs
        var trailN = 0
        var tracked = false
        // 3D GAME enemy control ([GameEnemyControl]) — 0 unless the user turns a control on, so the figure is drawn as before
        @Volatile var inRotAngle = 0f   // inside layers turn about the body's vertical axis, radians
        @Volatile var pitchAngle = 0f   // head + neck nod, radians (+ = look up)
        // where the figure was last drawn on screen (touch selection)
        @Volatile var scrOn = false
        @Volatile var scrX = 0f
        @Volatile var scrY = 0f
        @Volatile var hitR = 0f
    }

    @Volatile var enabled = true
    @Volatile var raw = false
    @Volatile var bodyLocked = false
    @Volatile var emfBoardEnergy = 0f
    @Volatile var level = 0.90f
    @Volatile var thr = 0.14f
    @Volatile var holdMs = 1500
    @Volatile var camYawAuto = true
    @Volatile var camYaw = 0.35f
    @Volatile var camPitch = 0.42f
    @Volatile var camDist = 6.0f
    @Volatile var posX = 0.50f      // viewport centre, fraction of view
    @Volatile var posY = 0.82f
    @Volatile var size = 0.34f      // viewport height as fraction of view height
    @Volatile var gridOn = true
    @Volatile var radarOn = true
    @Volatile var labelsOn = true
    @Volatile var trailsOn = true
    @Volatile var youOn = true
    /** Draw every figure from the shared procedural anatomy scaffold instead of a stick figure. */
    @Volatile var anatomyOn = true
    /** Also draw the inside layers (skeleton · organs · vessels · brain) faintly through the skin. */
    @Volatile var anatomyInside = false
    /** Game-only gain controls; the original audio and sensor paths are left untouched. */
    @Volatile var micGain = 1f
    @Volatile var magneticGain = 1f
    @Volatile var magneticThresholdUt = 5f
    /** World units per GPS metre for the temporary trail behind YOU. */
    @Volatile var gpsPathScale = 0.06f
    @Volatile var trackedCount = 0
    @Volatile var rawComplete = true
        private set

    val you = Body("you", "YOU", Color.rgb(0x80, 0xDE, 0xEA), 0f)

    /** Enemy selection · inside rotation · head pitch · SUPER · RAW (touch + floating buttons). Off until used. */
    val ctl = GameEnemyControl()
    fun allBodies(): List<Body> = listOf(you) + bodies
    fun viewRect(): RectF = rect
    fun unitPx(): Float = unit
    fun boardContains(x: Float, y: Float): Boolean = rect.contains(x, y)
    /** Nearest drawn figure under the touch (a little forgiving), or null. */
    fun hitTest(x: Float, y: Float): Body? {
        var best: Body? = null
        var bestD = Float.MAX_VALUE
        for (b in allBodies()) {
            if (!b.scrOn) continue
            val d = hypot(x - b.scrX, y - b.scrY)
            if (d <= b.hitR * 1.25f + unit * 0.12f && d < bestD) { best = b; bestD = d }
        }
        return best
    }
    val bodies: List<Body> = listOf(
        Body("enemy", "ENEMY BODY", Color.rgb(0xFF, 0x70, 0x43), 2.40f),
        Body("mic", "MIC ENEMY", Color.rgb(0xFF, 0xB7, 0x4D), -2.40f),
        Body("mag", "MAG FIELD", Color.rgb(0x4D, 0xB6, 0xAC), 0.35f),
        Body("pose", "POSE BODY", Color.rgb(0xCE, 0x93, 0xD8), 1.20f),
        Body("yolo", "CAMERA BODY", Color.rgb(0xA5, 0xD6, 0xA7), -1.20f),
        Body("anti", "ANTI-AUDIO", Color.rgb(0xEF, 0x53, 0x50), 3.14f),
        // Device enemies (same body system — no separate board)
        Body("mobile", "MOBILE", Color.rgb(0x4F, 0xC3, 0xF7), 0.60f),
        Body("bike", "BIKE", Color.rgb(0xFF, 0xD5, 0x4F), -0.60f),
        Body("car", "CAR", Color.rgb(0xFF, 0x8A, 0x65), 1.80f),
        Body("helicopter", "HELICOPTER", Color.rgb(0xBA, 0x68, 0xC8), -1.80f),
        Body("airplane", "AIRPLANE", Color.rgb(0x90, 0xCA, 0xF9), 2.90f),
        Body("laptop", "LAPTOP", Color.rgb(0xA5, 0xD6, 0xA7), -2.90f),
        Body("computer", "COMPUTER", Color.rgb(0x80, 0xCB, 0xC4), 0.90f),
        Body("cycle", "CYCLE", Color.rgb(0xFF, 0xCC, 0x80), -0.90f),
        Body("rickshaw", "AUTO RICKSHAW", Color.rgb(0xFF, 0xAB, 0x91), 3.50f),
        Body("device", "ANY DEVICE", Color.rgb(0xB0, 0xBE, 0xC5), -3.50f),
        Body("noise", "NOISE BODY", Color.rgb(0x80, 0xCB, 0xC4), 0.0f)
    )

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; textAlign = Paint.Align.CENTER }
    private val rect = RectF()
    private var sx = 0f; private var sy = 0f; private var sz = 0f   // projected output (sx, sy, depth)
    private var vcx = 0f; private var vcy = 0f; private var unit = 1f
    private var cyaw = 0f
    // eye gaze of YOU (copied from the anatomy board each tick; the other bodies look straight at YOU)
    private var gLx = 0f; private var gLy = 0f; private var gRx = 0f; private var gRy = 0f; private var gPupil = 1f
    private var pxs = FloatArray(0); private var pys = FloatArray(0); private var pzs = FloatArray(0)
    private var pOrder: Array<Int> = emptyArray()
    private val gz4 = FloatArray(4)
    private var gpsTrailX = 0f
    private var gpsTrailZ = 0f
    private var gpsHeading = 0f
    private var gpsHeadingValid = false
    private var gpsTrailActive = false
    private var lastGpsSequence = Long.MIN_VALUE

    // ───────────────────────────────────────────────────────────── signals (read only)
    private fun shape(e: Float): Float {
        val x = e.coerceIn(0f, 1f)
        if (raw) return x
        val t = thr.coerceIn(0f, 0.98f)
        return if (x <= t) 0f else ((x - t) / (1f - t)) * level.coerceIn(0f, 1.5f)
    }

    fun tick(v: VisualShieldView) {
        val raw = rawComplete || v.oneness.rawEverything

        bodyLocked = v.bodyLocked
        if (!enabled) return
        val sb = v.soundBank
        val sensors = v.gameSensors
        val emf = v.emfReading
        // Real magnetometer → EMF reading board (no simulation)
        if (sensors != null && sensors.magneticActive) {
            emf.feedReal(
                sensors.magneticXUt, sensors.magneticYUt, sensors.magneticZUt,
                sensors.magneticMagnitudeUt, sensors.magneticDeltaUt,
                sensorActive = true
            )
        } else {
            emf.feedReal(0f, 0f, 0f, 0f, 0f, sensorActive = false)
        }
        val now = System.currentTimeMillis()
        val src = mapOf(
            "enemy" to sb.enemyBodyOut,
            "mic" to (sb.micEnemyOut * micGain.coerceIn(0f, 3f)).coerceIn(0f, 1f),
            "mag" to magneticEnergy(sensors, emf),
            "pose" to v.poseSurface.dampen(),
            "yolo" to v.yoloSeg.dampen(),
            "anti" to max(sb.antiAudioOut, sb.antiBodyOut),
            "noise" to max(v.noise3d.out, v.noiseRate.out),
            // Device enemies — fused from existing enemy body · mic · camera · sensors (no new board)
            "mobile" to deviceEnergy(maxOf(sb.enemyBodyOut, sb.deviceEnemyOut), sb.micEnemyOut, v.yoloSeg.dampen(), 1.00f),
            "bike" to deviceEnergy(maxOf(sb.enemyBodyOut, sb.deviceEnemyOut), sb.micEnemyOut, v.yoloSeg.dampen(), 0.85f),
            "car" to deviceEnergy(maxOf(sb.enemyBodyOut, sb.deviceEnemyOut), sb.micEnemyOut, v.yoloSeg.dampen(), 0.90f),
            "helicopter" to deviceEnergy(maxOf(sb.enemyBodyOut, sb.deviceEnemyOut), sb.micEnemyOut, v.yoloSeg.dampen(), 0.75f),
            "airplane" to deviceEnergy(maxOf(sb.enemyBodyOut, sb.deviceEnemyOut), sb.micEnemyOut, v.yoloSeg.dampen(), 0.75f),
            "laptop" to deviceEnergy(maxOf(sb.enemyBodyOut, sb.deviceEnemyOut), sb.micEnemyOut, v.yoloSeg.dampen(), 1.00f),
            "computer" to deviceEnergy(maxOf(sb.enemyBodyOut, sb.deviceEnemyOut), sb.micEnemyOut, v.yoloSeg.dampen(), 0.95f),
            "cycle" to deviceEnergy(maxOf(sb.enemyBodyOut, sb.deviceEnemyOut), sb.micEnemyOut, v.yoloSeg.dampen(), 0.85f),
            "rickshaw" to deviceEnergy(maxOf(sb.enemyBodyOut, sb.deviceEnemyOut), sb.micEnemyOut, v.yoloSeg.dampen(), 0.80f),
            "device" to deviceEnergy(maxOf(sb.enemyBodyOut, sb.deviceEnemyOut), sb.micEnemyOut, v.yoloSeg.dampen(), 1.00f)
        )
        updateGpsTrail(sensors)
        v.anatomy3d.let { gLx = it.gazeLx; gLy = it.gazeLy; gRx = it.gazeRx; gRy = it.gazeRy; gPupil = it.pupilScale }
        you.energy = v.oneness.field.coerceIn(0f, 1f).let { if (raw) it else max(it, 0.25f) }
        you.shown = if (youOn) 1f else 0f
        var n = 0
        for (b in bodies) {
            val e = shape(src[b.key] ?: 0f).coerceIn(0f, 1f)
            if (!b.on) { b.tracked = false; b.shown += (0f - b.shown) * 0.3f; continue }
            if (raw) { b.energy = e }
            else b.energy += (e - b.energy) * (if (e > b.energy) 0.5f else 0.12f)
            val live = e > 0.02f
            if (live) b.seenMs = now
            b.tracked = live || (rawComplete || raw) || (!raw && now - b.seenMs < holdMs.coerceIn(0, 10000) && b.seenMs > 0L)
            val target = if (b.tracked) 1f else 0f
            b.shown += (target - b.shown) * (if (raw) 1f else 0.18f)
            if (b.tracked) n++
            // where the sound comes from: enemy uses the collider axis, mic / others use the brain L/R balance
            var a = b.defaultAngle
            if (b.key == "enemy" && (sb.lhcAxisX > 0.02f || sb.lhcAxisZ > 0.02f))
                a = atan2(sb.lhcAxisX - 0.5f, sb.lhcAxisZ - 0.5f)
            else if (b.key == "mic")
                a = b.defaultAngle + (v.brain3d.right.out - v.brain3d.left.out) * 0.9f
            else if (b.key == "mag" && sensors?.magneticActive == true)
                a = atan2(sensors.magneticXUt, sensors.magneticZUt)
            if (raw) b.angle = a else b.angle += (a - b.angle) * 0.1f
            val d = 1.4f + (1f - b.energy.coerceIn(0f, 1f)) * 2.8f     // louder = closer
            if (raw) b.dist = d else b.dist += (d - b.dist) * 0.1f
            if (b.tracked) {
                val px = sin(b.angle) * b.dist; val pz = cos(b.angle) * b.dist
                b.tx = px; b.tz = pz
                pushTrail(b, px, pz)
            }
        }
        trackedCount = n
        if (bodyLocked) {
            // Position + motion lock only — do NOT change the 3D model itself
            for (b in bodies) {
                b.angle = b.defaultAngle
                b.tx = 0f; b.tz = 0f
                b.dist = 2.5f
            }
            you.angle = 0f; you.tx = 0f; you.tz = 0f
            // Freeze viewport centre; leave anatomy mesh / layers untouched
        }
        ctl.tick(this)
    }

    /** Fuse existing enemy body + mic enemy + camera YOLO into a device enemy rail. */
    private fun deviceEnergy(enemy: Float, mic: Float, yolo: Float, bias: Float): Float {
        val e = maxOf(enemy, mic * 0.85f, yolo * 0.70f) * bias.coerceIn(0.2f, 1.2f)
        return if (raw) e.coerceIn(0f, 1f) else shape(e.coerceIn(0f, 1f))
    }

    fun magneticEnergy(sensors: GameSensorsHub?, emf: EmfReadingBoard? = null): Float {
        // Prefer real EMF reading board when sensor is live
        if (emf != null && emf.enabled && emf.sampleCount > 0L) {
            emfBoardEnergy = emf.energy
            return if (raw) emf.energy else shape(emf.energy)
        }
        if (sensors?.magneticActive != true) return 0f
        val mag = sensors.magneticMagnitudeUt
        val delta = abs(sensors.magneticDeltaUt)
        val thr = magneticThresholdUt.coerceIn(0.5f, 200f)
        val g = magneticGain.coerceIn(0f, 3f)
        if (raw) {
            val e = ((mag / 100f) * g).coerceIn(0f, 1f)
            emfBoardEnergy = e
            return e
        }
        val e = if (delta >= thr) {
            (((delta - thr) / (thr * 3f + 1f)).coerceIn(0f, 1f) * g)
        } else (delta / (thr * 4f)).coerceIn(0f, 0.25f) * g
        emfBoardEnergy = e.coerceIn(0f, 1f)
        return emfBoardEnergy
    }

    /**
     * Keep only a short, in-memory route relative to the first accepted fix.
     * The player remains at the centre of the existing game view; GPS controls
     * the player's heading and the recent trail without changing other bodies.
     */
    private fun updateGpsTrail(sensors: GameSensorsHub?) {
        val active = sensors?.locationOptIn == true &&
            sensors.gpsActive && sensors.hasLocationFix
        gpsTrailActive = active
        if (!active || sensors == null) {
            if (sensors?.locationOptIn != true) {
                you.trailN = 0
                gpsHeadingValid = false
                lastGpsSequence = Long.MIN_VALUE
            }
            return
        }

        val x = sensors.eastMeters * gpsPathScale.coerceIn(0.01f, 0.21f)
        val z = -sensors.northMeters * gpsPathScale.coerceIn(0.01f, 0.21f)
        gpsTrailX = x
        gpsTrailZ = z
        if (sensors.gpsSequence == lastGpsSequence) return

        if (you.trailN > 0) {
            val lastIndex = ((you.trailN - 1) % (you.trail.size / 2)) * 2
            val dx = x - you.trail[lastIndex]
            val dz = z - you.trail[lastIndex + 1]
            if (sqrt(dx * dx + dz * dz) > 0.025f) {
                gpsHeading = atan2(dx, dz)
                gpsHeadingValid = true
            }
        }
        pushTrail(you, x, z)
        lastGpsSequence = sensors.gpsSequence
    }

    private fun pushTrail(b: Body, x: Float, z: Float) {
        val i = (b.trailN % (b.trail.size / 2)) * 2
        b.trail[i] = x; b.trail[i + 1] = z
        b.trailN++
    }

    // ───────────────────────────────────────────────────────────── projection
    private fun proj(x: Float, y: Float, z: Float) {
        val c = cos(cyaw); val s = sin(cyaw)
        val rx = x * c - z * s
        val rz = x * s + z * c
        val cp = cos(camPitch); val sp = sin(camPitch)
        val ry = y * cp - rz * sp
        val rz2 = y * sp + rz * cp + camDist
        val f = 1f / max(0.3f, rz2) * camDist * 0.9f
        sx = vcx + rx * f * unit
        sy = vcy - ry * f * unit
        sz = rz2
    }

    // ───────────────────────────────────────────────────────────── drawing
    fun draw(canvas: Canvas, w: Float, h: Float, phase: Float) {
        if (!enabled) return
        val vh = h * size.coerceIn(0.15f, 0.9f)
        val vw = min(w * 0.98f, vh * 1.7f)
        val lockPx = if (bodyLocked) 0.50f else posX
        val lockPy = if (bodyLocked) 0.50f else posY
        vcx = w * lockPx; vcy = h * lockPy - vh * 0.1f
        unit = vh * 0.20f
        cyaw = if (bodyLocked) 0f else if (camYawAuto) camYaw + sin(phase * 0.004f) * 0.35f else camYaw
        rect.set(w * lockPx - vw / 2, h * lockPy - vh / 2, w * lockPx + vw / 2, h * lockPy + vh / 2)
        canvas.save()
        canvas.clipRect(rect)
        fill.color = Color.argb(70, 4, 10, 14); canvas.drawRect(rect, fill)
        if (gridOn) drawGrid(canvas)
        // painter's order: far → near
        val all = ArrayList<Body>(bodies.size + 1)
        if (youOn) all.add(you)
        for (b in bodies) if (b.shown > 0.03f) all.add(b)
        val order = all.sortedByDescending { b -> val (px, pz) = pos(b); proj(px, 0f, pz); sz }
        you.scrOn = false
        for (b in bodies) b.scrOn = false
        for (b in order) drawBody(canvas, b, phase)
        canvas.restore()
        ctl.drawOverlay(canvas, this, phase)
        line.strokeWidth = unit * 0.02f; line.color = Color.argb(120, 0x80, 0xDE, 0xEA)
        canvas.drawRect(rect, line)
        if (radarOn) drawRadar(canvas)
        txt.textSize = unit * 0.13f; txt.color = Color.argb(200, 0x80, 0xDE, 0xEA)
        canvas.drawText("3D GAME · tracked $trackedCount" + (if (raw) " · RAW" else ""), rect.centerX(), rect.top + unit * 0.16f, txt)
    }

    private fun pos(b: Body): Pair<Float, Float> = if (b === you) Pair(0f, 0f) else Pair(b.tx, b.tz)

    private fun drawGrid(canvas: Canvas) {
        line.strokeWidth = max(1f, unit * 0.012f)
        for (i in -5..5) {
            val a = (70 - abs(i) * 9).coerceIn(10, 90)
            line.color = Color.argb(a, 0x4D, 0xB6, 0xAC)
            proj(i.toFloat(), 0f, -5f); val x1 = sx; val y1 = sy
            proj(i.toFloat(), 0f, 5f); canvas.drawLine(x1, y1, sx, sy, line)
            proj(-5f, 0f, i.toFloat()); val x2 = sx; val y2 = sy
            proj(5f, 0f, i.toFloat()); canvas.drawLine(x2, y2, sx, sy, line)
        }
    }
    private fun drawBody(canvas: Canvas, b: Body, phase: Float) {
        val (px, pz) = pos(b)
        val e = b.energy.coerceIn(0f, 1f)
        val k = b.shown.coerceIn(0f, 1f)
        val col = b.color
        val a = (255 * k).toInt()
        val walk = sin(phase * (0.10f + e * 0.25f)) * (0.15f + e * 0.55f)
        val face = if (b === you && gpsHeadingValid) gpsHeading else atan2(-px, -pz)
        val bob = abs(sin(phase * (0.10f + e * 0.25f))) * 0.04f * e
        // trail
        if (trailsOn && b.trailN > 1 && (b !== you || gpsTrailActive)) {
            val m = b.trail.size / 2
            val cnt = min(b.trailN, m)
            for (i in 0 until cnt) {
                val idx = ((b.trailN - 1 - i + m * 4) % m) * 2
                val trailX = if (b === you) b.trail[idx] - gpsTrailX else b.trail[idx]
                val trailZ = if (b === you) b.trail[idx + 1] - gpsTrailZ else b.trail[idx + 1]
                proj(trailX, 0.02f, trailZ)
                fill.color = Color.argb(((70 * k) * (1f - i / cnt.toFloat())).toInt().coerceIn(0, 255), Color.red(col), Color.green(col), Color.blue(col))
                canvas.drawCircle(sx, sy, unit * 0.025f, fill)
            }
        }
        // ground ring + noise wave rings (app ring style)
        for (r in 0..2) {
            val rr = 0.30f + r * 0.18f + e * 0.25f * ((phase * 0.02f + r * 0.33f) % 1f)
            line.strokeWidth = max(1.5f, unit * 0.02f)
            line.color = Color.argb(((if (r == 0) 190 else 90 - r * 25) * k).toInt().coerceIn(0, 255), Color.red(col), Color.green(col), Color.blue(col))
            var fx = 0f; var fy = 0f
            for (s in 0..24) {
                val t = s / 24f * 2f * PI.toFloat()
                proj(px + cos(t) * rr, 0.01f, pz + sin(t) * rr)
                if (s > 0) canvas.drawLine(fx, fy, sx, sy, line)
                fx = sx; fy = sy
            }
        }
        // humanoid skeleton — local frame rotated to face YOU
        fun pt(lx: Float, y: Float, lz: Float): FloatArray {
            val c = cos(face); val s = sin(face)
            proj(px + lx * c + lz * s, y + bob, pz - lx * s + lz * c)
            return floatArrayOf(sx, sy)
        }
        val s = 0.62f
        val head = pt(0f, 1.62f * s + 0.2f, 0f); val neck = pt(0f, 1.42f * s + 0.2f, 0f)
        val chest = pt(0f, 1.22f * s + 0.2f, 0f); val hip = pt(0f, 0.86f * s + 0.2f, 0f)
        val shL = pt(-0.20f * s, 1.38f * s + 0.2f, 0f); val shR = pt(0.20f * s, 1.38f * s + 0.2f, 0f)
        val elL = pt(-0.28f * s, 1.12f * s + 0.2f, walk * 0.35f * s); val elR = pt(0.28f * s, 1.12f * s + 0.2f, -walk * 0.35f * s)
        val haL = pt(-0.30f * s, 0.88f * s + 0.2f, walk * 0.7f * s); val haR = pt(0.30f * s, 0.88f * s + 0.2f, -walk * 0.7f * s)
        val hpL = pt(-0.11f * s, 0.86f * s + 0.2f, 0f); val hpR = pt(0.11f * s, 0.86f * s + 0.2f, 0f)
        val knL = pt(-0.11f * s, 0.48f * s + 0.2f, -walk * 0.45f * s); val knR = pt(0.11f * s, 0.48f * s + 0.2f, walk * 0.45f * s)
        val ftL = pt(-0.11f * s, 0.20f, -walk * 0.8f * s); val ftR = pt(0.11f * s, 0.20f, walk * 0.8f * s)
        proj(px, 0.2f, pz)
        val depthScale = (camDist / max(0.5f, sz)).coerceIn(0.4f, 2.2f)
        // screen position for touch selection
        b.scrX = (head[0] + hip[0]) * 0.5f; b.scrY = (head[1] + hip[1]) * 0.5f
        b.hitR = max(hypot(head[0] - hip[0], head[1] - hip[1]) * 0.55f, unit * 0.22f)
        b.scrOn = b.shown > 0.03f
        val bone = unit * 0.075f * depthScale
        line.color = Color.argb(a, Color.red(col), Color.green(col), Color.blue(col))
        fun seg(p: FloatArray, q: FloatArray, wMul: Float = 1f) {
            line.strokeWidth = bone * wMul
            canvas.drawLine(p[0], p[1], q[0], q[1], line)
        }
        if (anatomyOn) {
            // the SAME procedural anatomy model as the main view (skin · face · eyes, optional inside layers)
            drawAnatomyFigure(canvas, b, px, pz, face, bob, walk, k)
        } else {
            seg(neck, hip, 1.9f)
            seg(shL, shR, 1.2f); seg(hpL, hpR, 1.2f)
            seg(shL, elL); seg(elL, haL, 0.85f); seg(shR, elR); seg(elR, haR, 0.85f)
            seg(hpL, knL, 1.2f); seg(knL, ftL, 1.0f); seg(hpR, knR, 1.2f); seg(knR, ftR, 1.0f)
        }
        // energy glow at chest (the "ball" on the body) + head
        fill.color = Color.argb((60 + 150 * e).toInt().coerceIn(0, 255) * a / 255, 255, 255, 255)
        canvas.drawCircle(chest[0], chest[1], bone * (0.9f + e * 1.4f), fill)
        if (!anatomyOn) {
            fill.color = Color.argb(a, Color.red(col), Color.green(col), Color.blue(col))
            canvas.drawCircle(head[0], head[1], bone * 1.8f, fill)
            fill.color = Color.argb(a, 8, 12, 16)
            canvas.drawCircle(head[0], head[1], bone * 0.9f, fill)
        }
        // health-bar style energy bar + name tag
        if (labelsOn) {
            val bw = unit * 0.7f * depthScale; val bh = unit * 0.06f * depthScale
            val bx = head[0] - bw / 2; val by = head[1] - bone * 3.2f
            fill.color = Color.argb(a * 140 / 255, 0, 0, 0); canvas.drawRect(bx, by, bx + bw, by + bh, fill)
            fill.color = Color.argb(a, Color.red(col), Color.green(col), Color.blue(col))
            canvas.drawRect(bx, by, bx + bw * e, by + bh, fill)
            txt.textSize = unit * 0.12f * depthScale; txt.color = Color.argb(a, 235, 240, 245)
            canvas.drawText("${b.label} ${(e * 100).toInt()}%", head[0], by - bh * 0.8f, txt)
        }
    }

    private fun isFeature(n: String): Boolean =
        n.startsWith("Eyeball") || n.startsWith("Iris") || n.startsWith("Pupil") || n.startsWith("Cornea") ||
            n.startsWith("Eyelash") || n.startsWith("Brow") || n.contains("teeth") || n.startsWith("Tongue") ||
            n.endsWith("lip") || n.startsWith("Nostril") || n.startsWith("Scalp") || n.startsWith("Caruncle") ||
            n.startsWith("Sclera") || n.startsWith("Corneal") || n.startsWith("Tear film") ||
            n.contains("conjunctiva", ignoreCase = true) || n.startsWith("Plica") ||
            n.startsWith("Upper lid") || n.startsWith("Upper eyelid") ||
            n.startsWith("Lower lid") || n.startsWith("Eye skin")

    /**
     * One figure built from [AnatomyModel3D.parts] (the same scaffold as the main anatomy view): skin + face (+ inside layers when
     * [anatomyInside]) as projected ellipsoids sorted far → near, tinted with the figure's colour, limbs swinging with [walk].
     * The eye balls of YOU turn with the live gaze (centroid); the noise bodies look straight at YOU.
     */
    private fun drawAnatomyFigure(canvas: Canvas, b: Body, px: Float, pz: Float, face: Float, bob: Float, walk: Float, k: Float) {
        val parts = AnatomyModel3D.parts
        val n = parts.size
        if (pxs.size != n) {
            pxs = FloatArray(n); pys = FloatArray(n); pzs = FloatArray(n)
            pOrder = Array(n) { it }
        }
        val s2 = 0.37f                       // body units → world units (figure ≈ 1.0 tall like the old skeleton)
        val c = cos(face); val sf = sin(face)
        val rel = face - cyaw
        val cRel = abs(cos(rel)); val sRel = abs(sin(rel))
        val isYou = b === you
        val col = b.color
        // inside layers are also shown while this figure's INSIDE ROTATION is turned (so the turn is visible)
        val rotA = b.inRotAngle
        val pitA = b.pitchAngle
        val rotOn = abs(rotA) > 0.01f
        val pitOn = abs(pitA) > 0.005f
        val rC = cos(rotA); val rS = sin(rotA)
        val pC = cos(pitA); val pS = sin(pitA)
        val inside = anatomyInside || rotOn
        var cnt = 0
        for (i in 0 until n) {
            val p = parts[i]
            val outside = p.layer == AnatomyModel3D.SKIN || p.layer == AnatomyModel3D.FACE
            if (!outside && !inside) continue
            var x = p.x; var y = p.y; var z = p.z
            if (isYou && EyeGazeMath.turn(p, gLx, gLy, gRx, gRy, gPupil, gz4)) { x = gz4[0]; y = gz4[1]; z = gz4[2] }
            // selected-figure controls: inside turns inside the skin, head + neck nod about the shoulders
            if (rotOn && !outside) { val nx = x * rC + z * rS; val nz = -x * rS + z * rC; x = nx; z = nz }
            if (pitOn && y >= 1.30f && abs(x) < 0.30f) {
                val dy = y - 1.28f
                val ny = 1.28f + dy * pC + z * pS
                val nz = z * pC - dy * pS
                y = ny; z = nz
            }
            val nm = p.name
            val swing = when {
                nm.contains("leg", true) || nm.contains("thigh", true) || nm.contains("shin", true) || nm.contains("knee", true) ||
                    nm.contains("ankle", true) || nm.contains("foot", true) || nm.startsWith("Toe") -> p.side * walk * 0.30f
                nm.contains("arm", true) || nm.contains("elbow", true) || nm.contains("hand", true) || nm.contains("finger", true) ||
                    nm.startsWith("Thumb") -> -p.side * walk * 0.22f
                else -> 0f
            }
            val lx = x * s2
            val lz = z * s2 + swing
            val wy = 0.2f + (y + 0.95f) * s2 + bob
            proj(px + lx * c + lz * sf, wy, pz - lx * sf + lz * c)
            pxs[i] = sx; pys[i] = sy; pzs[i] = sz
            pOrder[cnt++] = i
        }
        java.util.Arrays.sort(pOrder, 0, cnt) { i1, i2 -> pzs[i2].compareTo(pzs[i1]) }   // far → near
        for (q in 0 until cnt) {
            val i = pOrder[q]
            val p = parts[i]
            val f = camDist * 0.9f / max(0.3f, pzs[i]) * unit * s2
            var rx = p.sx; var ry = p.sy
            var rz = p.sz
            if (isYou && p.name.startsWith("Pupil")) { rx *= gPupil; ry *= gPupil }
            val halfW = sqrt((rx * cRel) * (rx * cRel) + (rz * sRel) * (rz * sRel)) * f
            val halfH = ry * f
            if (halfW < 0.4f || halfH < 0.4f) continue
            val isOut = p.layer == AnatomyModel3D.SKIN || p.layer == AnatomyModel3D.FACE
            val base = if (isOut && !isFeature(p.name)) blend(col, p.color, 0.30f) else p.color
            val alphaF = if (isOut) (if (p.layer == AnatomyModel3D.SKIN) 0.80f else 0.95f) else 0.34f
            fill.color = Color.argb((255 * k * alphaF).toInt().coerceIn(0, 255), Color.red(base), Color.green(base), Color.blue(base))
            canvas.save()
            if (p.rotZ != 0f) canvas.rotate(-p.rotZ, pxs[i], pys[i])
            rect2.set(pxs[i] - halfW, pys[i] - halfH, pxs[i] + halfW, pys[i] + halfH)
            canvas.drawOval(rect2, fill)
            canvas.restore()
        }
    }

    private val rect2 = RectF()
    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) * (1 - t) + Color.red(b) * t).toInt(),
        (Color.green(a) * (1 - t) + Color.green(b) * t).toInt(),
        (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
    )

    private fun drawRadar(canvas: Canvas) {
        val r = unit * 0.62f
        val cx = rect.right - r - unit * 0.1f; val cy = rect.top + r + unit * 0.28f
        fill.color = Color.argb(150, 4, 14, 18); canvas.drawCircle(cx, cy, r, fill)
        line.strokeWidth = max(1f, unit * 0.012f); line.color = Color.argb(150, 0x80, 0xDE, 0xEA)
        canvas.drawCircle(cx, cy, r, line); canvas.drawCircle(cx, cy, r * 0.5f, line)
        canvas.drawLine(cx - r, cy, cx + r, cy, line); canvas.drawLine(cx, cy - r, cx, cy + r, line)
        fill.color = you.color; canvas.drawCircle(cx, cy, r * 0.07f, fill)
        for (b in bodies) {
            if (b.shown < 0.05f) continue
            val rr = (b.dist / 4.4f).coerceIn(0.1f, 1f) * r
            val ang = b.angle - cyaw
            fill.color = Color.argb((255 * b.shown).toInt().coerceIn(0, 255), Color.red(b.color), Color.green(b.color), Color.blue(b.color))
            canvas.drawCircle(cx + sin(ang) * rr, cy - cos(ang) * rr, r * (0.07f + 0.08f * b.energy), fill)
        }
    }

    fun statusLine(): String {
        // OBB tracks counted in trackedCount after YoloObbGameTrack.applyToGame

        if (!enabled) return "3D GAME off"
        val names = bodies.filter { it.tracked }.joinToString("+") { it.label.substringBefore(' ') }
        return "3D GAME · tracked $trackedCount" + (if (names.isNotEmpty()) " ($names)" else "") +
            (if (raw) " · RAW COMPLETE" else " · thr=${(thr * 100).toInt()}% lv=${(level * 100).toInt()}%")
    }
}
