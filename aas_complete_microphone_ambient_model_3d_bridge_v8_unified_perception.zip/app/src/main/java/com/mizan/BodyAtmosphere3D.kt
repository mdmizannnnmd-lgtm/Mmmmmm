package com.mizan

import android.os.SystemClock

/**
 * Global atmosphere controls for the app's 3D-style body-region overlay.
 *
 * The input is the existing 0..1 on-device render energy, not a measured
 * physiological or environmental quantity.
 */
class BodyAtmosphere3D {
    @Volatile var enabled = true
    @Volatile var level = 1f
    @Volatile var threshold = 0.05f
    @Volatile var intensityGateOn = true

    @Volatile var animationOn = true
    @Volatile var movementLevel = 1f
    @Volatile var speed = 1f
    @Volatile var waveLevel = 1f
    @Volatile var waveThreshold = 0.05f
    @Volatile var imaginationLevel = 0.35f

    @Volatile var spikeProtectionOn = true
    @Volatile var spikeProtectionThreshold = 0.95f
    @Volatile var spikeProtectionLevel = 0.70f

    @Volatile var bipolarThresholdOn = true
    @Volatile var bipolarThresholdNeg = -300f
    @Volatile var bipolarThresholdPos = 300f
    @Volatile var modelMixOn = false
    @Volatile var modelMixWeight = 0.25f
    @Volatile var modelMixThreshold = 0.55f
    @Volatile private var modelSignal = 0f
    @Volatile private var modelSignalAtMs = 0L

    @Volatile var input = 0f
        private set
    @Volatile var rawLevel = 0f
        private set
    @Volatile var bipolarUnits = -300f
        private set
    @Volatile var thresholdActive = false
        private set
    @Volatile var bipolarActive = false
        private set
    @Volatile var spikeProtectionActive = false
        private set
    @Volatile var appliedScale = 1f
        private set
    @Volatile var movementScale = 1f
        private set
    @Volatile var speedMultiplier = 1f
        private set
    @Volatile var waveScale = 1f
        private set
    @Volatile var imaginationScale = 0.35f
        private set

    // ── Atomspare · centroid · vertical · Hz · dB · inside · outside · RAW ──
    @Volatile var atomOn = true
    @Volatile var atomRaw = false
    @Volatile var boardDomHz = 0f
    @Volatile var boardDomOut = 0f
    @Volatile var atomCenHz = 0f
    @Volatile var atomVerPct = 0f
    @Volatile var atomDb = -80.0
    @Volatile var atomCenOut = 0f
    @Volatile var atomVerOut = 0f
    @Volatile var atomInsideCen = 0f
    @Volatile var atomInsideVer = 0f
    @Volatile var atomOutsideCen = 0f
    @Volatile var atomOutsideVer = 0f
    @Volatile var atomInsideHz = 0f
    @Volatile var atomOutsideHz = 0f

    fun copyFrom(o: BodyAtmosphere3D) {
        enabled = o.enabled
        level = o.level
        threshold = o.threshold
        intensityGateOn = o.intensityGateOn
        animationOn = o.animationOn
        movementLevel = o.movementLevel
        speed = o.speed
        waveLevel = o.waveLevel
        waveThreshold = o.waveThreshold
        imaginationLevel = o.imaginationLevel
        spikeProtectionOn = o.spikeProtectionOn
        spikeProtectionThreshold = o.spikeProtectionThreshold
        spikeProtectionLevel = o.spikeProtectionLevel
        bipolarThresholdOn = o.bipolarThresholdOn
        bipolarThresholdNeg = o.bipolarThresholdNeg
        bipolarThresholdPos = o.bipolarThresholdPos
    }

    fun updateModelSignal(value: Float) {
        modelSignal = value.coerceIn(0f, 1f)
        modelSignalAtMs = SystemClock.elapsedRealtime()
    }

    /**
     * Returns the multiplier for body overlay drawing. When this control is
     * disabled it is a pass-through, so it cannot change the existing renderer.
     */
    fun tick(rawInput: Float): Float {
        val raw = rawInput.coerceIn(0f, 1f)
        rawLevel = raw
        val modelFresh = modelMixOn &&
            modelSignalAtMs > 0L &&
            SystemClock.elapsedRealtime() - modelSignalAtMs <= MODEL_SIGNAL_MAX_AGE_MS
        val modelEligible = modelFresh && modelSignal >= modelMixThreshold.coerceIn(0f, 1f)
        val mixWeight = modelMixWeight.coerceIn(0f, 1f)
        input = if (modelEligible) {
            raw * (1f - mixWeight) + modelSignal * mixWeight
        } else {
            raw
        }
        bipolarUnits = (input * 600f) - 300f
        val lowTrip = bipolarThresholdOn &&
            bipolarUnits < bipolarThresholdNeg.coerceIn(-300f, 0f)
        val highTrip = bipolarThresholdOn &&
            bipolarUnits > bipolarThresholdPos.coerceIn(0f, 300f)
        bipolarActive = lowTrip || highTrip
        val intensityGateOpen = !intensityGateOn ||
            input >= threshold.coerceIn(0f, 1f) ||
            bipolarActive
        thresholdActive = intensityGateOpen
        movementScale = if (animationOn && intensityGateOpen) {
            movementLevel.coerceIn(0f, 1f)
        } else {
            0f
        }
        speedMultiplier = if (animationOn) speed.coerceIn(0f, 3f) else 0f
        waveScale = if (
            animationOn &&
            intensityGateOpen &&
            input >= waveThreshold.coerceIn(0f, 1f)
        ) {
            waveLevel.coerceIn(0f, 1f)
        } else {
            0f
        }
        imaginationScale = if (animationOn && intensityGateOpen) {
            imaginationLevel.coerceIn(0f, 1f)
        } else {
            0f
        }

        if (!enabled) {
            spikeProtectionActive = false
            appliedScale = 1f
            return appliedScale
        }

        val selectedLevel = level.coerceIn(0f, 1f)
        val gateGain = if (thresholdActive) selectedLevel else selectedLevel * 0.18f
        spikeProtectionActive = spikeProtectionOn &&
            (input >= spikeProtectionThreshold.coerceIn(0f, 1f) || highTrip)
        val spikeGain = if (spikeProtectionActive) {
            1f - spikeProtectionLevel.coerceIn(0f, 1f) * 0.70f
        } else {
            1f
        }
        appliedScale = (gateGain * spikeGain).coerceIn(0f, 1f)
        return appliedScale
    }

    fun statusLine(): String {
        val state = buildList {
            if (intensityGateOn) add(if (thresholdActive) "GATE-OPEN" else "GATE-CLOSED")
            else add("GATE-BYPASS")
            if (bipolarActive) add("BIP")
            if (spikeProtectionActive) add("SPIKE-PROT")
            if (animationOn) add("ANIM") else add("STATIC")
        }.joinToString("+")
        val modelAge = SystemClock.elapsedRealtime() - modelSignalAtMs
        val modelTag = if (modelMixOn && modelSignalAtMs > 0L && modelAge <= MODEL_SIGNAL_MAX_AGE_MS) {
            " · camera=${(modelSignal * 100f).toInt()}%"
        } else ""
        return "BODY-3D-ATMO · ${if (enabled) "ON" else "OFF"} · raw=${(rawLevel * 100f).toInt()}% " +
            "lv=${(level * 100f).toInt()}% gate=${(threshold * 100f).toInt()}% · bip=${bipolarUnits.toInt()} · " +
            "move=${(movementScale * 100f).toInt()}% speed=${"%.2f".format(speedMultiplier)}x " +
            "wave=${(waveScale * 100f).toInt()}%/${(waveThreshold * 100f).toInt()}% " +
            "im=${(imaginationScale * 100f).toInt()}% · $state$modelTag " +
            "scale=${(appliedScale * 100f).toInt()}%"
    }

    companion object {
        private const val MODEL_SIGNAL_MAX_AGE_MS = 1500L
    }
    /** Feed atomspare from ambient board (centroid · vertical · Hz · dB · inside · outside). */
    fun feedAtomspare(board: AmbientThresholdBoard) {
        if (!atomOn && !atomRaw && !board.rawEverything) return
        val raw = atomRaw || board.rawEverything
        atomCenHz = board.centroidHz
        boardDomHz = board.dominationHz
        boardDomOut = board.dominationOut
        atomVerPct = board.verticalNorm
        atomDb = board.micDb()
        atomCenOut = if (raw) board.centroidOut else board.centroidOut * level
        atomVerOut = if (raw) board.verticalOut else board.verticalOut * level
        atomInsideCen = if (raw) board.insideCenOut else board.insideCenOut * level
        atomInsideVer = if (raw) board.insideVerOut else board.insideVerOut * level
        atomOutsideCen = if (raw) board.outsideCenOut else board.outsideCenOut * level
        atomOutsideVer = if (raw) board.outsideVerOut else board.outsideVerOut * level
        atomInsideHz = board.insideHz
        atomOutsideHz = board.outsideHz
    }

    fun atomLine(): String =
        "ATOMSPARE · CEN ${atomCenHz.toInt()}Hz DOM ${boardDomHz.toInt()}Hz out=${(boardDomOut*100).toInt()}% ${"%+.0f".format(atomDb)}dB · VERT ${(atomVerPct*100).toInt()}% · " +
        "IN C${(atomInsideCen*100).toInt()}% V${(atomInsideVer*100).toInt()}% · " +
        "OUT C${(atomOutsideCen*100).toInt()}% V${(atomOutsideVer*100).toInt()}%" +
        (if (atomRaw) " · RAW" else "")

    fun enableAtomRawComplete() {
        atomOn = true
        atomRaw = true
        enabled = true
    }

}
