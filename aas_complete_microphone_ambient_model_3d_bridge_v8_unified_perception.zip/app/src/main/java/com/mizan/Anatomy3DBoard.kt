package com.mizan

/**
 * Procedural human 3D anatomy board (inside + outside), using the illustrative ellipsoid parts in
 * [AnatomyModel3D]. Layers: skin · muscle · skeleton · organs · vessels/nerves · brain. OUTSIDE layers
 * (skin, muscle) follow the body mixer's outside path, INSIDE layers (skeleton, organs,
 * vessels, brain) follow its inside path. Each path has the full control set of [SignalPath]
 * (threshold · level · degains · bipolar ±120 dB · RAW COMPLETE).
 */
class Anatomy3DBoard {
    init {
        ContinuousBodySurface.prepareAsync()
    }

    @Volatile var enabled = true
    /** Force every currently modeled layer ON (not a single-part view). */
    fun enableCompleteHumanLayers() {
        for (i in layerOn.indices) layerOn[i] = true
        for (i in layerLevel.indices) if (layerLevel[i] < 0.55f) layerLevel[i] = 0.85f
        rawAll = true
        enabled = true
    }
    @Volatile var gpuOn = true             // also draw the inside layers in the ARCore GPU renderer

    val layerOn = BooleanArray(AnatomyModel3D.LAYER_COUNT) { true }
    val layerLevel = FloatArray(AnatomyModel3D.LAYER_COUNT) { 0.85f }

    val inside = SignalPath().also { it.thr = 0.12f; it.level = 0.85f }
    val outside = SignalPath().also { it.thr = 0.12f; it.level = 0.85f }

    /** Inside warp + inside rotation of the skeleton / organs / vessels / brain layers (centroid · vertical driven). */
    val insideFx = InsideWarpRot()

    /** Ambient MOVEMENT output (set every frame by the view) — moves the inside layers on top of the body. */
    @Volatile var moveFx: AmbientMovement? = null
    /** Optional sound-reactive marker on the selected illustrative body segment. */
    @Volatile var audioFxTargetPart = HumanDetection.PART_TORSO
    @Volatile var audioFxKind = 0
    @Volatile var audioFxLevel = 0f

    val tuning = VisualShieldView.EyeTuning()
    @Volatile var colourLevel = 1.0f
    @Volatile var xray = 0.55f             // 0..1 how see-through the outer layers are
    @Volatile var atmosphere = 0.45f
    @Volatile var wave = 0.40f
    @Volatile var speed = 0.40f
    @Volatile var move = 0.40f
    @Volatile var rawVisual = false

    @Volatile var size = 0.55f             // fraction of the view height
    @Volatile var posX = 0.5f
    @Volatile var posY = 0.60f
    @Volatile var yawAuto = true
    @Volatile var yawSpeed = 0.35f
    @Volatile var yaw = 0.0f
    @Volatile var tilt = 0.10f
    @Volatile var poseRigOn = true
    @Volatile var viewPreset = "Auto"
    @Volatile var rawAll = false
        private set

    // ── driven by the ambient board's CENTROID + VERTICAL through [CentroidDrive] ────────────
    @Volatile var moveBoost = 0f
    /** When true, board reports zero motion (locked 3D body). */
    @Volatile var bodyLocked = false
    @Volatile var speedBoost = 0f
    @Volatile var ambientBoost = 0f
    /** Complete sub-systems ON (not single) — index matches [BodySystems.ALL]. */
    val subSystemOn = BooleanArray(BodySystems.COUNT) { true }
    fun enableAllSubSystems() { for (i in subSystemOn.indices) subSystemOn[i] = true }
    @Volatile var waveBoost = 0f
    /** Eye gaze, −1..+1 (x: toward the model's +x side, y: up) for the LEFT and RIGHT eye ball, and pupil size factor. */
    @Volatile var gazeLx = 0f
    @Volatile var gazeLy = 0f
    @Volatile var gazeRx = 0f
    @Volatile var gazeRy = 0f
    @Volatile var pupilScale = 1f

    fun waveEff(): Float = if (bodyLocked) 0f else (wave + waveBoost).coerceIn(0f, 1.6f)
    fun speedEff(): Float = if (bodyLocked) 0f else (yawSpeed + speedBoost).coerceIn(0f, 1.6f)
    fun moveEff(): Float = if (bodyLocked) 0f else (move + moveBoost).coerceIn(0f, 1.6f)

    /** Lock the complete anatomy model to a named orthographic-style viewing direction. */
    fun selectViewPreset(name: String) {
        yawAuto = false
        tilt = 0f
        viewPreset = name
        yaw = when (name) {
            "Back" -> Math.PI.toFloat()
            "Left" -> -Math.PI.toFloat() * 0.5f
            "Right" -> Math.PI.toFloat() * 0.5f
            else -> {
                viewPreset = "Front"
                0f
            }
        }
    }

    fun enableAutoView() {
        yawAuto = true
        viewPreset = "Auto"
    }

    fun setRawAll(on: Boolean) {
        rawAll = on
        inside.raw = on; outside.raw = on; rawVisual = on
        insideFx.rawAnatomy = on
    }

    fun tick(insideE: Float, outsideE: Float) {
        if (!enabled) { inside.tick(0f); outside.tick(0f); return }
        // Keep full figure readable even at low energy (screenshot-style continuous body)
        val oE = maxOf(outsideE, 0.40f)
        val iE = maxOf(insideE, 0.30f)
        inside.tick(iE)
        outside.tick(oE)
    }

    /** Output (0..1) that drives a given layer. */
    fun outFor(layer: Int): Float =
        if (AnatomyModel3D.isInside(layer)) inside.out else outside.out

    fun statusLine(): String {
        if (!enabled) return "ANATOMY 3D off"
        val layers = AnatomyModel3D.LAYER_NAMES.indices.filter { layerOn[it] }
            .joinToString("+") { AnatomyModel3D.LAYER_NAMES[it].substringBefore(' ') }
        return "ANATOMY 3D · in ${(inside.out * 100).toInt()}%" +
            (if (inside.overHit) " OVER" else "") + " · out ${(outside.out * 100).toInt()}%" +
            (if (outside.overHit) " OVER" else "") + " · $layers · $viewPreset" +
            (if (rawAll) " · RAW COMPLETE" else "")
    }
    fun apply(v: VisualShieldView?) {
        val vv = v ?: return
        try {
            val o = try { atmosphere } catch (_: Throwable) { try { out } catch (_: Throwable) { 0f } }
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, o * 0.2f)
        } catch (_: Throwable) {}
    }

}
