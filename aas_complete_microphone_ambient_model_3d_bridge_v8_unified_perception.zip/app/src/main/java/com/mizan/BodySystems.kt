package com.mizan

/**
 * Complete human body **sub-systems** (11 organ systems) — not a single system.
 * Teaching 3D model maps parts into these groups for layer / ambient / RAW complete.
 *
 * @see Wikipedia List of systems of the human body
 */
object BodySystems {
    enum class Id {
        INTEGUMENTARY, SKELETAL, MUSCULAR, NERVOUS, CARDIOVASCULAR,
        LYMPHATIC, RESPIRATORY, DIGESTIVE, URINARY, ENDOCRINE, REPRODUCTIVE, SENSORY
    }

    data class Sys(val id: Id, val title: String, val parts: Array<String>)

    val ALL = arrayOf(
        Sys(Id.INTEGUMENTARY, "Integumentary", arrayOf("skin", "hair", "fat", "nail")),
        Sys(Id.SKELETAL, "Skeletal", arrayOf("bone", "spine", "rib", "skull", "pelvis", "cartilage")),
        Sys(Id.MUSCULAR, "Muscular", arrayOf("muscle", "rectus", "deltoid", "bicep", "glute", "diaphragm")),
        Sys(Id.NERVOUS, "Nervous", arrayOf("brain", "spinal", "nerve", "optic", "vagus", "phrenic")),
        Sys(Id.CARDIOVASCULAR, "Cardiovascular", arrayOf("heart", "aorta", "artery", "vein", "coronary")),
        Sys(Id.LYMPHATIC, "Lymphatic", arrayOf("lymph", "spleen", "thymus", "tonsil")),
        Sys(Id.RESPIRATORY, "Respiratory", arrayOf("lung", "trachea", "bronch", "larynx", "pharynx", "diaphragm")),
        Sys(Id.DIGESTIVE, "Digestive", arrayOf("stomach", "liver", "intest", "colon", "pancreas", "gall", "oesophag", "esophag", "tongue", "teeth", "rectum", "salivary")),
        Sys(Id.URINARY, "Urinary", arrayOf("kidney", "bladder", "ureter", "urethra")),
        Sys(Id.ENDOCRINE, "Endocrine", arrayOf("thyroid", "adrenal", "pituitary", "pineal", "parathyroid", "pancreas")),
        Sys(Id.REPRODUCTIVE, "Reproductive", arrayOf("uterus", "ovary", "testis", "prostate", "fallopian", "dick", "pussy")),
        Sys(Id.SENSORY, "Sensory", arrayOf("eye", "iris", "pupil", "ear", "nose", "cornea", "retina"))
    )

    const val COUNT = 12 // 11 classic + sensory detail group

    fun match(partName: String): List<Id> {
        val n = partName.lowercase()
        return ALL.filter { s -> s.parts.any { k -> n.contains(k) } }.map { it.id }
    }
}
