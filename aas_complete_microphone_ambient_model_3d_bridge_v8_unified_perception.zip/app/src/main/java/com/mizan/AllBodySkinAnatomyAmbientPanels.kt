package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object AllBodySkinAnatomyAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: AllBodySkinAnatomyAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFFCC80.toInt()
        p.title("ALL BODY SKIN · EAR · NOSE · LEG · BRAIN · ANATOMY AMBIENT", c)
        p.note("Head face earL/R nose neck chest belly back arms hands legs feet · brain L/R · anatomy layers")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("All skin ambient ON", b.allSkinOn) { b.allSkinOn = it }
        p.switch("Force full body skin", b.forceFullBodySkin) { b.forceFullBodySkin = it }
        p.switch("Brain ambient ON", b.brainOn) { b.brainOn = it }
        p.switch("Eyes skin ambient ON", b.eyesSkinOn) { b.eyesSkinOn = it }
        p.switch("Nose skin ambient ON", b.noseSkinOn) { b.noseSkinOn = it }
        p.switch("Face skins ambient ON", b.faceSkinsOn) { b.faceSkinsOn = it }
        p.switch("Neck skin ambient ON", b.neckSkinOn) { b.neckSkinOn = it }
        p.switch("Missing skin fill (scalp lip shoulder hip knee…)", b.missingSkinOn) { b.missingSkinOn = it }
        p.switch("Brain 3D skin ambient ON", b.brain3dSkinOn) { b.brain3dSkinOn = it }
        p.switch("Heart sling 3D ON", b.heartSlingOn) { b.heartSlingOn = it }
        p.seek("Shared thr", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Shared level", 0f, 1.5f, b.lv) { b.lv = it }
        val st = p.status("SKIN·ANATOMY —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 250) }
        })
    }
}
