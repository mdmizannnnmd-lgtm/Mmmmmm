package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object WaterFullBodyAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: WaterFullBodyAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF81D4FA.toInt()
        p.title("WATER · FULL BODY AMBIENT", c)
        p.note("Intracellular · extracellular · plasma · lymph · CSF · daily track")
        p.switch("Water ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.seek("Threshold", 0.05f, 1f, b.thr) { b.thr = it }
        p.seek("Level", 0.1f, 1.5f, b.levelAmt) { b.levelAmt = it }
        p.seek("Daily liters track", 0.5f, 8f, b.dailyLitersTrack) { b.dailyLitersTrack = it }
        val st = p.status("WATER —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 300) }
        })
    }
}
