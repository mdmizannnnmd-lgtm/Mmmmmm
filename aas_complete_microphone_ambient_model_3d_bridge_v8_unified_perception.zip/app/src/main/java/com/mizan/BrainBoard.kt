package com.mizan

import kotlin.math.max

/**
 * Full 3D brain control board — LEFT and RIGHT hemisphere, each with its own signal path
 * (threshold · level · degains · bipolar ±120 dB · attack/release · RAW COMPLETE), its own brain-visual tuning
 * (contrast · brightness · colour level · per-channel colour thresholds) and its own 3D controls
 * (intensity · atmosphere · wave · speed · movement).
 *
 * MODEL MIXING: every hemisphere is fed by a different blend of the app's live signals
 *   LEFT  ← ambient + mid/high audio  + body model   (analytic / speech side)
 *   RIGHT ← camera + motion + bass audio + body model (spatial / visual side)
 * [lrBalance] favours one side, [lrCross] is the corpus-callosum coupling between them.
 * Lobes weight the hemisphere output by what they are for: frontal ← ambient, parietal ← motion,
 * temporal ← audio, occipital ← camera / eyes, cerebellum ← motion + speed, brainstem ← raw.
 *
 * EYES VISUAL: [eyeLink] 1 = eyes follow the brain visual, 2 = brain follows the eyes visual.
 *
 * RAW COMPLETE: [setRawAll] puts both hemispheres' signal paths in raw (no thr / gain / rails / smoothing)
 * and skips the brain visual tuning, so the lobes show the pure live signal.
 */
class BrainBoard {

    class Hemi(val side: Int) {
        val path = SignalPath()
        val tuning = VisualShieldView.EyeTuning()
        @Volatile var colourLevel = 1.0f     // 0..2 saturation of the lobe colours
        @Volatile var intensity = 0.85f      // 0..1 overall brightness / glow of this hemisphere
        @Volatile var atmosphere = 0.55f     // 0..1 3D atmosphere halo
        @Volatile var wave = 0.50f           // 0..1 surface wave
        @Volatile var waveThr = 0.20f
        @Volatile var speed = 0.50f          // 0..1 rotation / flow speed
        @Volatile var speedThr = 0.20f
        @Volatile var move = 0.50f           // 0..1 sway
        @Volatile var moveThr = 0.20f
        @Volatile var rawVisual = false      // skip the contrast / brightness / threshold tuning

        @Volatile var out = 0f
        @Volatile var waveOut = 0f
        @Volatile var speedOut = 0f
        @Volatile var moveOut = 0f
        @Volatile var atmoOut = 0f
    }

    @Volatile var enabled = true
    val left = Hemi(-1)
    val right = Hemi(1)

    // model mixing weights
    @Volatile var wAmbient = 0.70f
    @Volatile var wAudio = 0.60f
    @Volatile var wCamera = 0.50f
    @Volatile var wMotion = 0.50f
    @Volatile var wModel = 0.60f
    @Volatile var lrBalance = 0f         // −1 favour left … +1 favour right
    @Volatile var lrCross = 0.25f        // 0..1 coupling between hemispheres

    // lobe weights (how strongly a lobe follows its hemisphere)
    @Volatile var lobeFrontal = 1.0f
    @Volatile var lobeParietal = 1.0f
    @Volatile var lobeTemporal = 1.0f
    @Volatile var lobeOccipital = 1.0f
    @Volatile var lobeCerebellum = 1.0f
    @Volatile var lobeBrainstem = 1.0f

    // drawing
    @Volatile var sulciOn = true
    @Volatile var innerOn = true        // cut-away: show corpus callosum, thalamus, hippocampus
    @Volatile var haloOn = true
    @Volatile var size = 0.46f           // fraction of the view width
    @Volatile var yawAuto = true
    @Volatile var yawSpeed = 0.40f
    @Volatile var yaw = 0.45f            // manual yaw (radians) when yawAuto is off
    @Volatile var tilt = 0.18f
    @Volatile var eyeLink = 1            // 0 off · 1 eyes ← brain · 2 brain ← eyes
    @Volatile var glandsOn = true         // pituitary · pineal · hypothalamus
    @Volatile var opticalOn = true        // optic nerve / chiasm lines to eyes
    @Volatile var faceLinesOn = true      // 3D face contour lines
    @Volatile var rawFace = false         // face RAW COMPLETE (no thr soft)
    /** The brain lives INSIDE the 3D anatomy body (one model) instead of floating as a second brain on screen. */
    @Volatile var dockInAnatomy = true


    // live signals (for the status line)
    @Volatile var inAmbient = 0f
    @Volatile var inAudio = 0f
    @Volatile var inCamera = 0f
    @Volatile var inMotion = 0f
    @Volatile var inModel = 0f
    @Volatile var rawAll = false
        private set

    fun setRawAll(on: Boolean) {
        rawFace = on
        rawAll = on
        for (h in listOf(left, right)) { h.path.raw = on; h.rawVisual = on }
    }

    fun tick(
        ambient: Float, audioRms: Float, audioLow: Float, audioMid: Float, audioHigh: Float,
        camera: Float, motion: Float, model: Float
    ) {
        inAmbient = ambient; inAudio = audioRms; inCamera = camera; inMotion = motion; inModel = model
        if (!enabled) {
            left.out = 0f; right.out = 0f
            for (h in listOf(left, right)) { h.waveOut = 0f; h.speedOut = 0f; h.moveOut = 0f; h.atmoOut = 0f }
            return
        }
        val a = ambient.coerceIn(0f, 1f) * wAmbient
        val mdl = model.coerceIn(0f, 1f) * wModel
        val eL = max(a, max(((audioMid + audioHigh) * 0.5f).coerceIn(0f, 1f) * wAudio, mdl))
        val eR = max(camera.coerceIn(0f, 1f) * wCamera,
            max(motion.coerceIn(0f, 1f) * wMotion, max(audioLow.coerceIn(0f, 1f) * wAudio, mdl)))
        val bal = lrBalance.coerceIn(-1f, 1f)
        val gl = 1f - max(0f, bal)
        val gr = 1f + kotlin.math.min(0f, bal)
        val c = lrCross.coerceIn(0f, 1f)
        val l = (eL * gl) * (1f - c) + (eR * gr) * c
        val r = (eR * gr) * (1f - c) + (eL * gl) * c
        process(left, l)
        process(right, r)
    }

    private fun process(h: Hemi, e: Float) {
        val o = h.path.tick(e)
        h.out = o
        if (h.path.raw) {
            h.waveOut = o; h.speedOut = o; h.moveOut = o; h.atmoOut = o
        } else {
            h.waveOut = if (o >= h.waveThr) o * h.wave else 0f
            h.speedOut = if (o >= h.speedThr) o * h.speed else 0f
            h.moveOut = if (o >= h.moveThr) o * h.move else 0f
            h.atmoOut = o * h.atmosphere
        }
    }

    /** Copies the brain visual into the eyes visual (or back) according to [eyeLink]. */
    fun linkEyes(eye: VisualShieldView.EyeTuning) {
        when (eyeLink) {
            1 -> copyTuning(left.tuning, eye)
            2 -> { copyTuning(eye, left.tuning); copyTuning(eye, right.tuning) }
        }
    }

    private fun copyTuning(from: VisualShieldView.EyeTuning, to: VisualShieldView.EyeTuning) {
        to.contrastOn = from.contrastOn; to.brightnessOn = from.brightnessOn; to.thresholdOn = from.thresholdOn
        to.invert = from.invert
        to.contrast = from.contrast; to.brightness = from.brightness
        to.contrastThr = from.contrastThr; to.brightnessThr = from.brightnessThr
        to.thrR = from.thrR; to.thrG = from.thrG; to.thrB = from.thrB
        to.softness = from.softness; to.mode = from.mode
    }

    /** Output (0..1) of one lobe, from its hemisphere and the lobe's job. */
    fun lobeOut(kind: Int, side: Int): Float {
        val h = when {
            side < 0 -> left
            side > 0 -> right
            else -> null
        }
        val hemi = h?.out ?: max(left.out, right.out)
        val w = when (kind) {
            BrainModel.FRONTAL -> lobeFrontal * (0.55f + 0.45f * inAmbient.coerceIn(0f, 1f))
            BrainModel.PARIETAL -> lobeParietal * (0.55f + 0.45f * inMotion.coerceIn(0f, 1f))
            BrainModel.TEMPORAL -> lobeTemporal * (0.55f + 0.45f * inAudio.coerceIn(0f, 1f))
            BrainModel.OCCIPITAL -> lobeOccipital * (0.55f + 0.45f * inCamera.coerceIn(0f, 1f))
            BrainModel.CEREBELLUM -> lobeCerebellum * (0.55f + 0.45f * max(inMotion, hemi))
            BrainModel.BRAINSTEM, BrainModel.PONS, BrainModel.MEDULLA -> lobeBrainstem
            BrainModel.INSULA, BrainModel.AMYGDALA, BrainModel.HIPPOCAMPUS -> lobeTemporal * (0.55f + 0.45f * inAudio.coerceIn(0f, 1f))
            BrainModel.BASAL_GANGLIA, BrainModel.CINGULATE -> lobeParietal * (0.55f + 0.45f * inMotion.coerceIn(0f, 1f))
            BrainModel.PITUITARY, BrainModel.PINEAL, BrainModel.HYPOTHALAMUS ->
                lobeBrainstem * (0.50f + 0.50f * inAmbient.coerceIn(0f, 1f))
            BrainModel.THALAMUS, BrainModel.VENTRICLE ->
                lobeParietal * (0.45f + 0.55f * max(inAmbient, inModel).coerceIn(0f, 1f))
            else -> 1f
        }
        return if (rawAll) hemi else (hemi * w.coerceIn(0f, 1.5f)).coerceIn(0f, 1f)
    }

    fun statusLine(): String {
        if (!enabled) return "BRAIN 3D off"
        fun f(h: Hemi): String =
            "${(h.out * 100).toInt()}%" +
                (if (h.path.overHit) " OVER" else if (h.path.underHit) " FLOOR" else "") +
                (if (h.path.raw) " RAW" else "")
        return "BRAIN 3D · L ${f(left)} · R ${f(right)} · in amb=${(inAmbient * 100).toInt()}% " +
            "aud=${(inAudio * 100).toInt()}% cam=${(inCamera * 100).toInt()}% mot=${(inMotion * 100).toInt()}% " +
            "mdl=${(inModel * 100).toInt()}% · bal=${"%+.2f".format(lrBalance)} · " +
            "eyes=${arrayOf("off", "←brain", "→brain")[eyeLink.coerceIn(0, 2)]}" +
            (if (rawAll) " · RAW COMPLETE" else "")
    }
    fun apply(v: VisualShieldView?) {
        val vv = v ?: return
        try {
            val o = out
            vv.fullAnatomy132.brainOut = maxOf(vv.fullAnatomy132.brainOut, o)
        } catch (_: Throwable) {}
    }

}
