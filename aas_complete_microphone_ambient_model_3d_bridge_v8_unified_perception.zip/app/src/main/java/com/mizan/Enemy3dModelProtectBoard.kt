package com.mizan

/**
 * Automatic enemies 3D models threshold · rotate / motion / look-at protection ·
 * manipulation block · algorithms decay. RAW COMPLETE.
 */
class Enemy3dModelProtectBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Automatic enemy 3D model threshold
    @Volatile var autoThrOn = true
    @Volatile var autoThr = 0.32f
    @Volatile var autoThrMargin = 0.12f
    @Volatile var enemyModelThr = 0.32f
    @Volatile var enemyModelLv = 0.85f
    @Volatile var enemyModelOut = 0f

    // Rotate protection
    @Volatile var rotateProtectOn = true
    @Volatile var rotateThr = 0.30f
    @Volatile var rotateProtectLv = 0.90f
    @Volatile var rotateProtectOut = 0f

    // Motion protection
    @Volatile var motionProtectOn = true
    @Volatile var motionThr = 0.30f
    @Volatile var motionProtectLv = 0.90f
    @Volatile var motionProtectOut = 0f

    // Look-at protection (enemy model gaze / aim at us)
    @Volatile var lookAtProtectOn = true
    @Volatile var lookAtThr = 0.28f
    @Volatile var lookAtProtectLv = 0.92f
    @Volatile var lookAtProtectOut = 0f

    // Manipulation protection
    @Volatile var manipProtectOn = true
    @Volatile var manipThr = 0.35f
    @Volatile var manipProtectLv = 0.93f
    @Volatile var manipProtectOut = 0f

    // Algorithms decay (enemy model algorithm strength decays over time / under protect)
    @Volatile var algoDecayOn = true
    @Volatile var algoDecayRate = 0.08f   // per tick fraction
    @Volatile var algoDecayFloor = 0.05f
    @Volatile var algoStrength = 1f
    @Volatile var algoDecayOut = 0f

    @Volatile var status = "ENEMY 3D MODEL PROT idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, enemyThreat: Float, enemyMove: Float = 0f, enemySpeed: Float = 0f) {
        if (!enabled) {
            status = "ENEMY 3D MODEL PROT OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val enemy = enemyThreat.coerceIn(0f, 1f)
        val em = maxOf(enemyMove, enemySpeed, enemy).coerceIn(0f, 1f)

        // Automatic threshold: track enemy energy floor + margin
        if (autoThrOn) {
            autoThr = (enemy * 0.55f + e * 0.20f + autoThrMargin.coerceIn(0.05f, 0.4f)).coerceIn(0.1f, 0.7f)
            enemyModelThr = autoThr
            rotateThr = (autoThr * 0.95f).coerceIn(0.08f, 0.7f)
            motionThr = autoThr
            lookAtThr = (autoThr * 0.90f).coerceIn(0.08f, 0.7f)
            manipThr = (autoThr * 1.05f).coerceIn(0.1f, 0.75f)
        }

        enemyModelOut = lane(true, enemyModelThr, enemyModelLv, enemy)
        rotateProtectOut = lane(rotateProtectOn, rotateThr, rotateProtectLv, em)
        motionProtectOut = lane(motionProtectOn, motionThr, motionProtectLv, maxOf(em, enemy))
        lookAtProtectOut = lane(lookAtProtectOn, lookAtThr, lookAtProtectLv, enemy * 1.05f)
        manipProtectOut = lane(manipProtectOn, manipThr, manipProtectLv, maxOf(enemy, em))

        // Algorithms decay: continuous decay of enemy algo strength under protection pressure
        if (algoDecayOn) {
            val pressure = maxOf(enemyModelOut, rotateProtectOut, motionProtectOut, lookAtProtectOut, manipProtectOut)
            val decay = algoDecayRate.coerceIn(0.01f, 0.5f) * (0.35f + pressure * 0.65f)
            algoStrength = (algoStrength * (1f - decay)).coerceAtLeast(algoDecayFloor.coerceIn(0f, 0.5f))
            // recovery only when no enemy threat
            if (enemy < 0.05f && pressure < 0.05f) {
                algoStrength = (algoStrength + 0.02f).coerceAtMost(1f)
            }
            algoDecayOut = (1f - algoStrength).coerceIn(0f, 1f)
        } else {
            algoStrength = 1f
            algoDecayOut = 0f
        }

        status =
            "E3D autoT=${"%.2f".format(enemyModelThr)} mdl=${(enemyModelOut*100).toInt()}% · " +
            "rot=${(rotateProtectOut*100).toInt()}% mot=${(motionProtectOut*100).toInt()}% " +
            "look=${(lookAtProtectOut*100).toInt()}% manip=${(manipProtectOut*100).toInt()}% · " +
            "algo=${(algoStrength*100).toInt()}% decay=${(algoDecayOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard) {
        if (!enabled) return
        val prot = maxOf(
            enemyModelOut, rotateProtectOut, motionProtectOut,
            lookAtProtectOut, manipProtectOut, algoDecayOut
        )
        if (prot > 0.02f) {
            val k = (1f - prot * 0.95f).coerceIn(0.03f, 1f)
            val kAlgo = algoStrength.coerceIn(algoDecayFloor, 1f)
            sb.enemyBodyOut *= k * kAlgo
            sb.micEnemyOut *= k * kAlgo
            sb.enemyBodyMove *= if (motionProtectOn || rotateProtectOn) k * kAlgo else kAlgo
            sb.enemyBodySpeed *= if (motionProtectOn) k * kAlgo else kAlgo
            sb.enemyBodyWave *= k * kAlgo
            sb.enemyMasterShieldOn = true
            sb.arRealityShieldOn = true
            sb.enemyCommBlockOut = maxOf(sb.enemyCommBlockOut, prot * 0.9f)
        }
    }
}
