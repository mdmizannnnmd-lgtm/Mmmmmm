package com.mizan

/**
 * Camera threshold + VHS tracking + contrast / brightness / colour / channel raw.
 * Local preview path only.
 */
class CameraVhsBoard {
    @Volatile var enabled = true

    /** Camera threshold */
    @Volatile var camThrOn = true
    @Volatile var camThr = 0.45f
    @Volatile var camOver = false
    @Volatile var camEnergy = 0f

    /** VHS tracking */
    @Volatile var vhsOn = true
    @Volatile var vhsTrackOn = true
    @Volatile var vhsThr = 0.40f
    @Volatile var vhsLv = 0.65f
    @Volatile var vhsTrackActive = false
    @Volatile var vhsOut = 0f

    /** Contrast level + threshold */
    @Volatile var contrastOn = true
    @Volatile var contrast = 1.0f
    @Volatile var contrastThr = 0.30f
    @Volatile var contrastActive = false
    @Volatile var contrastOut = 0f

    /** Brightness level + threshold */
    @Volatile var brightnessOn = true
    @Volatile var brightness = 0.0f
    @Volatile var brightnessThr = 0.30f
    @Volatile var brightnessActive = false
    @Volatile var brightnessOut = 0f

    /** Colour threshold (shared) */
    @Volatile var colorThrOn = true
    @Volatile var colorThr = 0.40f
    @Volatile var colorThrActive = false
    @Volatile var colorThrOut = 0f

    /** Channel raw R / G / B (0..1) + per-channel thresholds */
    @Volatile var chRawOn = true
    @Volatile var chR = 0.55f
    @Volatile var chG = 0.55f
    @Volatile var chB = 0.55f
    @Volatile var chRThr = 0.35f
    @Volatile var chGThr = 0.35f
    @Volatile var chBThr = 0.35f
    @Volatile var chRActive = false
    @Volatile var chGActive = false
    @Volatile var chBActive = false

    fun tick(energy: Float) {
        val e = energy.coerceIn(0f, 1f)
        camEnergy = e
        if (!enabled) {
            camOver = false
            vhsTrackActive = false
            vhsOut = 0f
            contrastActive = false; contrastOut = 0f
            brightnessActive = false; brightnessOut = 0f
            colorThrActive = false; colorThrOut = 0f
            chRActive = false; chGActive = false; chBActive = false
            return
        }
        camOver = camThrOn && e >= camThr.coerceIn(0.05f, 1f)
        vhsTrackActive = vhsOn && vhsTrackOn && e >= vhsThr.coerceIn(0.05f, 1f)
        vhsOut = if (vhsTrackActive) {
            val t = vhsThr.coerceIn(0.05f, 1f)
            (((e - t) / (1f - t).coerceAtLeast(0.05f)) * vhsLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        val cThr = contrastThr.coerceIn(0.05f, 1f)
        contrastActive = contrastOn && e >= cThr
        contrastOut = if (contrastActive) {
            val depth = ((e - cThr) / (1f - cThr).coerceAtLeast(0.05f)).coerceIn(0f, 1f)
            (depth * (contrast.coerceIn(0f, 2f) / 2f)).coerceIn(0f, 1f)
        } else 0f

        val bThr = brightnessThr.coerceIn(0.05f, 1f)
        brightnessActive = brightnessOn && e >= bThr
        brightnessOut = if (brightnessActive) {
            val depth = ((e - bThr) / (1f - bThr).coerceAtLeast(0.05f)).coerceIn(0f, 1f)
            (depth * ((brightness.coerceIn(-1f, 1f) + 1f) / 2f)).coerceIn(0f, 1f)
        } else 0f

        val colT = colorThr.coerceIn(0.05f, 1f)
        colorThrActive = colorThrOn && e >= colT
        colorThrOut = if (colorThrActive) {
            (((e - colT) / (1f - colT).coerceAtLeast(0.05f))).coerceIn(0f, 1f)
        } else 0f

        if (chRawOn) {
            chRActive = chR >= chRThr.coerceIn(0.05f, 1f)
            chGActive = chG >= chGThr.coerceIn(0.05f, 1f)
            chBActive = chB >= chBThr.coerceIn(0.05f, 1f)
        } else {
            chRActive = false; chGActive = false; chBActive = false
        }
    }

    /** Effective contrast for draw/process (1 = neutral) */
    fun effectiveContrast(): Float {
        if (!enabled || !contrastOn) return 1f
        val base = contrast.coerceIn(0f, 2f)
        return if (contrastActive) base else 1f + (base - 1f) * 0.25f
    }

    /** Effective brightness add (−1..+1) */
    fun effectiveBrightness(): Float {
        if (!enabled || !brightnessOn) return 0f
        val base = brightness.coerceIn(-1f, 1f)
        return if (brightnessActive) base else base * 0.25f
    }

    /** Packed channel gains 0..1 */
    fun channelGains(): Triple<Float, Float, Float> {
        if (!enabled || !chRawOn) return Triple(1f, 1f, 1f)
        fun g(v: Float, thr: Float, act: Boolean): Float {
            val x = v.coerceIn(0f, 1f)
            return if (act) x else x * 0.35f + 0.65f
        }
        return Triple(g(chR, chRThr, chRActive), g(chG, chGThr, chGActive), g(chB, chBThr, chBActive))
    }

    fun drawCut(): Float {
        if (!enabled) return 1f
        var s = 1f
        if (camOver) s *= 0.70f
        if (vhsTrackActive) s *= (1f - vhsOut * 0.35f)
        if (contrastActive) s *= (1f - contrastOut * 0.15f)
        if (brightnessActive) s *= (1f - brightnessOut * 0.12f)
        if (colorThrActive) s *= (1f - colorThrOut * 0.18f)
        return s.coerceIn(0.25f, 1f)
    }

    fun statusLine(): String {
        if (!enabled) return "CAM/VHS off"
        val tags = buildList {
            if (camOver) add("CAM-OVER") else add("cam-ok")
            if (vhsTrackActive) add("VHS")
            if (contrastActive) add("CONTR")
            if (brightnessActive) add("BRIGHT")
            if (colorThrActive) add("COL-THR")
            if (chRActive) add("R")
            if (chGActive) add("G")
            if (chBActive) add("B")
        }.joinToString("+")
        val (r, g, b) = channelGains()
        return "$tags · C=${"%.2f".format(effectiveContrast())} B=${"%.2f".format(effectiveBrightness())} " +
            "RGB=${(r*100).toInt()}/${(g*100).toInt()}/${(b*100).toInt()} · cut=${(drawCut()*100).toInt()}%"
    }
    fun apply(v: VisualShieldView?) { /* VHS visual state */ }

}
