package com.mizan

/**
 * Complete 3D body anatomy OUTSIDE + INSIDE (systems-level, not single organ only).
 * Atomspare shell: enemies cannot break out of body atmosphere.
 * THRESHOLDED movement · speed · waves · bipolar ±120 · threshold communication.
 * RAW COMPLETE.
 *
 * Outside (integument → surface systems): epidermis, dermis, hypodermis, hair/glands surface.
 * Inside: musculoskeletal, nervous, endocrine, cardiovascular, respiratory, digestive,
 * urinary, reproductive, lymphatic + core cavities.
 */
class BodyAnatomyShellBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // ── Outside anatomy (complete surface shell) ──
    @Volatile var outsideOn = true
    @Volatile var epidermis = 0f
    @Volatile var dermis = 0f
    @Volatile var hypodermis = 0f
    @Volatile var integumentOut = 0f
    @Volatile var outsideShellOut = 0f

    // ── Inside anatomy (complete systems) ──
    @Volatile var insideOn = true
    @Volatile var musculoskeletal = 0f
    @Volatile var nervous = 0f
    @Volatile var endocrine = 0f
    @Volatile var cardiovascular = 0f
    @Volatile var respiratory = 0f
    @Volatile var digestive = 0f
    @Volatile var urinary = 0f
    @Volatile var reproductive = 0f
    @Volatile var lymphatic = 0f
    @Volatile var insideSystemsOut = 0f
    /** Inside 3D body is atmospheric (atomspare fills interior). */
    @Volatile var insideAtmospheric = true
    @Volatile var insideAtmoLv = 0.85f
    @Volatile var insideAtmoOut = 0f
    /** Automatic threshold on inside atomspare (tracks energy floor). */
    @Volatile var insideAutoThr = true
    @Volatile var insideAutoThrVal = 0.28f
    @Volatile var insideAtmoThr = 0.28f

    // ── Atomspare body shell — enemies CANNOT break out ──
    @Volatile var atomSpareShellOn = true
    @Volatile var atomSpareShellLv = 0.95f
    @Volatile var atomSpareShellOut = 0f
    @Volatile var enemyCannotBreakOut = true
    @Volatile var breakOutBlockOut = 0f
    // Enemies model + enemies atomspare abuse protection
    @Volatile var enemyModelAbuseProtect = true
    @Volatile var enemyAtomAbuseProtect = true
    @Volatile var enemyModelAbuseThr = 0.35f
    @Volatile var enemyAtomAbuseThr = 0.32f
    @Volatile var enemyModelAbuseOut = 0f
    @Volatile var enemyAtomAbuseOut = 0f
    @Volatile var enemyAbuseProtectLv = 0.92f

    // ── THRESHOLDED movement / speed / waves ──
    @Volatile var thrMoveOn = true
    @Volatile var thrMoveThr = 0.30f
    @Volatile var thrMoveLv = 0.70f
    @Volatile var thrMoveOut = 0f
    @Volatile var thrSpeedOn = true
    @Volatile var thrSpeedThr = 0.30f
    @Volatile var thrSpeedLv = 0.70f
    @Volatile var thrSpeedOut = 0f
    @Volatile var thrWaveOn = true
    @Volatile var thrWaveThr = 0.30f
    @Volatile var thrWaveLv = 0.70f
    @Volatile var thrWaveOut = 0f

    // ── Bipolar threshold ±120 dB ──
    @Volatile var bipolarOn = true
    @Volatile var bipNegDb = -60f
    @Volatile var bipPosDb = 60f
    @Volatile var bipOut = 0f

    // ── Threshold communication ──
    @Volatile var thrCommOn = true
    @Volatile var thrCommThr = 0.35f
    @Volatile var thrCommLv = 0.70f
    @Volatile var thrCommOut = 0f
    /** Block enemy threshold-comm into shell */
    @Volatile var thrCommEnemyBlock = true

    @Volatile var status = "ANATOMY SHELL idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float, drive: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv * drive).coerceIn(0f, 1f)
        val t = (thr * drive).coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv * drive).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, modelDrive: Float, enemyThreat: Float) {
        if (!enabled) {
            status = "ANATOMY SHELL OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val drive = 0.25f + 0.75f * modelDrive.coerceIn(0f, 1f)
        val enemy = enemyThreat.coerceIn(0f, 1f)

        // Outside layers
        if (outsideOn) {
            epidermis = e * 0.95f * drive
            dermis = e * 0.88f * drive
            hypodermis = e * 0.80f * drive
            integumentOut = maxOf(epidermis, dermis, hypodermis)
            outsideShellOut = integumentOut
        } else outsideShellOut = 0f

        // Inside systems (complete set)
        if (insideOn) {
            val base = e * drive
            musculoskeletal = base * 0.92f
            nervous = base * 0.90f
            endocrine = base * 0.78f
            cardiovascular = base * 0.88f
            respiratory = base * 0.85f
            digestive = base * 0.80f
            urinary = base * 0.72f
            reproductive = base * 0.70f
            lymphatic = base * 0.75f
            insideSystemsOut = maxOf(
                musculoskeletal, nervous, endocrine, cardiovascular, respiratory,
                digestive, urinary, reproductive, lymphatic
            )
        } else insideSystemsOut = 0f

        // Inside 3D atmospheric + auto threshold
        if (insideAtmospheric && insideOn) {
            if (insideAutoThr) {
                insideAutoThrVal = (0.10f + e * 0.28f).coerceIn(0.08f, 0.55f)
                insideAtmoThr = insideAutoThrVal
            }
            insideAtmoOut = lane(true, insideAtmoThr, insideAtmoLv, maxOf(e, insideSystemsOut), drive)
            insideSystemsOut = maxOf(insideSystemsOut, insideAtmoOut)
        } else insideAtmoOut = 0f

        // Atomspare shell strength
        atomSpareShellOut = if (atomSpareShellOn) {
            (maxOf(outsideShellOut, insideSystemsOut) * atomSpareShellLv.coerceIn(0.1f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Enemies cannot break out of atomspare body
        if (enemyCannotBreakOut) {
            breakOutBlockOut = (enemy * atomSpareShellOut * 0.98f).coerceIn(0f, 1f)
        } else breakOutBlockOut = 0f

        // Enemies model abuse + enemies atomspare abuse protection
        val pl = enemyAbuseProtectLv.coerceIn(0.1f, 1f)
        if (enemyModelAbuseProtect) {
            enemyModelAbuseOut = if (enemy >= enemyModelAbuseThr.coerceIn(0.05f, 1f)) {
                (((enemy - enemyModelAbuseThr) / (1f - enemyModelAbuseThr).coerceAtLeast(0.05f)) * pl).coerceIn(0f, 1f)
            } else 0f
        } else enemyModelAbuseOut = 0f
        if (enemyAtomAbuseProtect) {
            // abuse = enemy trying to force atomspare on our inside
            val abuse = enemy * (1f - insideAtmoOut * 0.5f)
            enemyAtomAbuseOut = if (abuse >= enemyAtomAbuseThr.coerceIn(0.05f, 1f)) {
                (((abuse - enemyAtomAbuseThr) / (1f - enemyAtomAbuseThr).coerceAtLeast(0.05f)) * pl).coerceIn(0f, 1f)
            } else (enemy * 0.3f * pl).coerceIn(0f, 1f)
        } else enemyAtomAbuseOut = 0f

        // THRESHOLDED move / speed / waves
        thrMoveOut = lane(thrMoveOn, thrMoveThr, thrMoveLv, e, drive)
        thrSpeedOut = lane(thrSpeedOn, thrSpeedThr, thrSpeedLv, e * 1.02f, drive)
        thrWaveOut = lane(thrWaveOn, thrWaveThr, thrWaveLv, e * 0.98f, drive)

        // Bipolar ±120
        if (bipolarOn) {
            val span = (bipPosDb.coerceIn(0f, 120f) - bipNegDb.coerceIn(-120f, 0f)).coerceAtLeast(1f)
            val mid = (bipNegDb + bipPosDb) * 0.5f
            // map energy to bipolar position
            val db = bipNegDb + e * span
            bipOut = ((db - mid) / (span * 0.5f)).coerceIn(-1f, 1f) * 0.5f + 0.5f
            bipOut = bipOut.coerceIn(0f, 1f)
        } else bipOut = 0f

        // Threshold communication
        thrCommOut = lane(thrCommOn, thrCommThr, thrCommLv, maxOf(e, thrMoveOut, thrWaveOut), drive)
        if (thrCommEnemyBlock && enemy > 0.05f) {
            // keep our thr-comm, mark enemy blocked via breakOut
            breakOutBlockOut = maxOf(breakOutBlockOut, enemy * 0.85f)
        }

        status =
            "OUT skin=${(outsideShellOut*100).toInt()}% IN sys=${(insideSystemsOut*100).toInt()}% · " +
            "SHELL=${(atomSpareShellOut*100).toInt()}% IN-ATMO=${(insideAtmoOut*100).toInt()}% autoT=${"%.2f".format(insideAtmoThr)} · " +
            "NO-BREAK=${(breakOutBlockOut*100).toInt()}% mdlAbuse=${(enemyModelAbuseOut*100).toInt()}% atomAbuse=${(enemyAtomAbuseOut*100).toInt()}% · " +
            "tMOV=${(thrMoveOut*100).toInt()} tSPD=${(thrSpeedOut*100).toInt()} tWAV=${(thrWaveOut*100).toInt()} · " +
            "BIP=${(bipOut*100).toInt()} thrCOMM=${(thrCommOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, skin: SkinAtomspare3dBoard?) {
        if (!enabled) return
        // Hard: enemy cannot break out of atomspare body
        if (enemyCannotBreakOut && breakOutBlockOut > 0.02f) {
            val k = (1f - breakOutBlockOut * 0.97f).coerceIn(0.02f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
            sb.enemyBodyMove *= k
            sb.enemyBodySpeed *= k
            sb.enemyBodyWave *= k
            sb.enemyMasterShieldOn = true
            sb.arRealityShieldOn = true
        }
        val abuse = maxOf(enemyModelAbuseOut, enemyAtomAbuseOut)
        if (abuse > 0.02f) {
            val k = (1f - abuse * 0.96f).coerceIn(0.02f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
            sb.enemyBodyMove *= k
            sb.enemyBodySpeed *= k
            sb.enemyBodyWave *= k
            sb.enemyMasterShieldOn = true
            // protect inside atmospheric from enemy atomspare abuse
            if (enemyAtomAbuseProtect) {
                sb.enemyCommBlockOut = maxOf(sb.enemyCommBlockOut, enemyAtomAbuseOut)
            }
        }
        // Thresholded factors
        if (thrMoveOn) {
            sb.protectMoveFactor = minOf(sb.protectMoveFactor, (1f - (1f - thrMoveOut) * 0.3f).coerceIn(0.1f, 1f))
            // when thresholded move active, lock enemy move further
            if (thrMoveOut > 0.05f) sb.enemyBodyMove *= (1f - thrMoveOut * 0.5f).coerceIn(0.1f, 1f)
        }
        if (thrSpeedOn && thrSpeedOut > 0.05f) {
            sb.protectSpeedFactor = minOf(sb.protectSpeedFactor, (0.5f + thrSpeedOut * 0.5f).coerceIn(0.1f, 1f))
            sb.enemyBodySpeed *= (1f - thrSpeedOut * 0.5f).coerceIn(0.1f, 1f)
        }
        if (thrWaveOn && thrWaveOut > 0.05f) {
            sb.protectWaveFactor = minOf(sb.protectWaveFactor, (0.5f + thrWaveOut * 0.5f).coerceIn(0.1f, 1f))
            sb.enemyBodyWave *= (1f - thrWaveOut * 0.5f).coerceIn(0.1f, 1f)
        }
        if (thrCommEnemyBlock && thrCommOut > 0.05f) {
            sb.enemyCommBlockOut = maxOf(sb.enemyCommBlockOut, thrCommOut)
        }
        // Feed skin atomspare outside/inside
        skin?.let { s ->
            if (s.enabled) {
                s.skinOutsideOut = maxOf(s.skinOutsideOut, outsideShellOut)
                s.skinInsideOut = maxOf(s.skinInsideOut, insideSystemsOut, insideAtmoOut)
                s.atomSpareOut = maxOf(s.atomSpareOut, atomSpareShellOut)
            }
        }
    }
}
