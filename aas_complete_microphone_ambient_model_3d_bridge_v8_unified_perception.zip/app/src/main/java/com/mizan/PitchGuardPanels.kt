package com.mizan

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

/** Control panel for the left / right screen-sounds pitch protection. */
object PitchGuardPanels {
    fun build(ctx: Context, root: LinearLayout, g: StereoPitchGuard) {
        val p = PanelBuilder(ctx, root)
        val orange = Color.rgb(0xFF, 0x8A, 0x65)
        p.note("Detects the pitch of the LEFT and RIGHT channel separately. A loud, clear pitch above the ceiling (or below the floor) dims that side, scales its eyes / hands / brain rings and lowers the energy the app reacts to.")
        p.switch("Pitch protection ON", g.enabled) { g.enabled = it }
        p.switch("RAW COMPLETE (no protection · readout only)", g.rawComplete) { g.rawComplete = it }
        p.switch("Link L ↔ R (worse side protects both)", g.linkLR) { g.linkLR = it }
        p.seek("Pitch clarity needed", 0.05f, 0.99f, g.clarityThr) { g.clarityThr = it }
        p.seek("Release (ms)", 20f, 5000f, g.releaseMs.toFloat(), 0) { g.releaseMs = it.toInt() }
        for (s in arrayOf(g.left, g.right)) {
            val name = if (s === g.left) "LEFT" else "RIGHT"
            p.title("$name SIDE", Color.rgb(0xB0, 0xBE, 0xC5))
            p.switch("$name protection ON", s.on) { s.on = it }
            p.seek("Pitch ceiling (Hz)", 500f, 4000f, s.highHz, 0) { s.highHz = it }
            p.seek("Loudness needed", 0.01f, 1f, s.levelThr) { s.levelThr = it }
            p.seek("Protection level", 0f, 1f, s.protLv) { s.protLv = it }
            p.switch("Deep-pitch guard", s.lowOn) { s.lowOn = it }
            p.seek("Pitch floor (Hz)", 60f, 500f, s.lowHz, 0) { s.lowHz = it }
        }
        val status = p.status("PITCH PROT —", orange)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                status.text = g.statusLine()
                h.postDelayed(this, 200)
            }
        })
    }
}
