package com.mizan

/**
 * 3D noise field around the body — particle / grain cloud driven by [NoiseRateBoard].
 * Multi-layer (near / mid / far), not a single blob. RAW bypasses threshold gate.
 */
class Noise3DBoard {
    @Volatile var enabled = true
    @Volatile var raw = false
    @Volatile var density = 0.65f       // 0..1 particle amount
    @Volatile var size = 0.55f          // 0..1 particle scale
    @Volatile var speed = 0.50f         // 0..1 swirl speed
    @Volatile var depth = 0.70f         // 0..1 z-spread (3D feel)
    @Volatile var colour = 0x80CBC4     // teal grain
    @Volatile var thr = 0.15f           // min noise out to show
    @Volatile var level = 0.85f
    @Volatile var out = 0f
        private set
    @Volatile var active = false
        private set

    fun tick(noiseOut: Float) {
        val n = noiseOut.coerceIn(0f, 1f)
        if (!enabled) { out = 0f; active = false; return }
        if (raw) {
            out = (n * level).coerceIn(0f, 1f)
            active = out > 0.02f
        } else {
            active = n >= thr
            out = if (active) {
                (((n - thr) / (1f - thr).coerceAtLeast(0.05f)) * level).coerceIn(0f, 1f)
            } else 0f
        }
    }

    fun statusLine(): String {
        if (!enabled) return "NOISE 3D off"
        return "NOISE 3D ${if (active) "ON" else "idle"} out=${(out * 100).toInt()}%" +
            (if (raw) " · RAW" else "")
    }
    fun apply(v: VisualShieldView?) { /* 3d noise state */ }

}
