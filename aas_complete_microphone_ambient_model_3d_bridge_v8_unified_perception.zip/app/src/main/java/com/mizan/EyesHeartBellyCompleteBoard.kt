package com.mizan

/**
 * Eyes (full optical stack L/R) · Heart (full) · Belly/gut · any remaining misses.
 * Default ON · threshold · level · RAW COMPLETE.
 */
class EyesHeartBellyCompleteBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Eyes full stack
    @Volatile var eyesOn = true
    @Volatile var eyesThr = 0.22f
    @Volatile var eyesLv = 0.85f
    @Volatile var eyeLOut = 0f
    @Volatile var eyeROut = 0f
    @Volatile var scleraL = 0f; @Volatile var scleraR = 0f
    @Volatile var corneaL = 0f; @Volatile var corneaR = 0f
    @Volatile var irisL = 0f; @Volatile var irisR = 0f
    @Volatile var pupilL = 0f; @Volatile var pupilR = 0f
    @Volatile var lensL = 0f; @Volatile var lensR = 0f
    @Volatile var retinaL = 0f; @Volatile var retinaR = 0f
    @Volatile var opticL = 0f; @Volatile var opticR = 0f
    @Volatile var lidL = 0f; @Volatile var lidR = 0f
    @Volatile var tearL = 0f; @Volatile var tearR = 0f
    @Volatile var eyesFullOut = 0f

    // Heart full
    @Volatile var heartOn = true
    @Volatile var heartThr = 0.22f
    @Volatile var heartLv = 0.85f
    @Volatile var heartOut = 0f
    @Volatile var heartAtrium = 0f
    @Volatile var heartVentricle = 0f
    @Volatile var heartValve = 0f
    @Volatile var heartRhythm = 0f
    @Volatile var heartPericardium = 0f

    // Belly / gut full
    @Volatile var bellyOn = true
    @Volatile var bellyThr = 0.22f
    @Volatile var bellyLv = 0.85f
    @Volatile var bellyOut = 0f
    @Volatile var stomach = 0f
    @Volatile var intestine = 0f
    @Volatile var liver = 0f
    @Volatile var pancreas = 0f
    @Volatile var spleen = 0f
    @Volatile var gallbladder = 0f

    // Extra misses: lungs · kidneys · bladder · reproductive · lymph
    @Volatile var extraOn = true
    @Volatile var lungsOut = 0f
    @Volatile var kidneysOut = 0f
    @Volatile var bladderOut = 0f
    @Volatile var lymphOut = 0f
    @Volatile var thyroidOut = 0f
    @Volatile var adrenalOut = 0f

    @Volatile var status = "EYES·HEART·BELLY idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float) {
        if (!enabled) {
            status = "EYES·HEART·BELLY OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)

        // Eyes L/R full optical
        eyeLOut = lane(eyesOn, eyesThr, eyesLv, e * 1.0f)
        eyeROut = lane(eyesOn, eyesThr, eyesLv, e * 0.98f)
        scleraL = eyeLOut * 0.95f; scleraR = eyeROut * 0.95f
        corneaL = eyeLOut * 0.92f; corneaR = eyeROut * 0.92f
        irisL = eyeLOut * 0.90f; irisR = eyeROut * 0.90f
        pupilL = eyeLOut * 0.88f; pupilR = eyeROut * 0.88f
        lensL = eyeLOut * 0.86f; lensR = eyeROut * 0.86f
        retinaL = eyeLOut * 0.84f; retinaR = eyeROut * 0.84f
        opticL = eyeLOut * 0.82f; opticR = eyeROut * 0.82f
        lidL = eyeLOut * 0.80f; lidR = eyeROut * 0.80f
        tearL = eyeLOut * 0.75f; tearR = eyeROut * 0.75f
        eyesFullOut = maxOf(eyeLOut, eyeROut)

        heartOut = lane(heartOn, heartThr, heartLv, e)
        heartAtrium = heartOut * 0.95f
        heartVentricle = heartOut * 0.98f
        heartValve = heartOut * 0.90f
        heartRhythm = heartOut * 0.92f
        heartPericardium = heartOut * 0.85f

        bellyOut = lane(bellyOn, bellyThr, bellyLv, e * 0.96f)
        stomach = bellyOut * 0.95f
        intestine = bellyOut * 0.92f
        liver = bellyOut * 0.90f
        pancreas = bellyOut * 0.85f
        spleen = bellyOut * 0.82f
        gallbladder = bellyOut * 0.80f

        if (extraOn || rawComplete) {
            lungsOut = lane(true, 0.22f, 0.8f, e * 0.94f)
            kidneysOut = lane(true, 0.22f, 0.8f, e * 0.88f)
            bladderOut = lane(true, 0.22f, 0.75f, e * 0.82f)
            lymphOut = lane(true, 0.22f, 0.75f, e * 0.80f)
            thyroidOut = lane(true, 0.22f, 0.78f, e * 0.86f)
            adrenalOut = lane(true, 0.22f, 0.78f, e * 0.84f)
        } else {
            lungsOut = 0f; kidneysOut = 0f; bladderOut = 0f
            lymphOut = 0f; thyroidOut = 0f; adrenalOut = 0f
        }

        status =
            "EYE L/R=${(eyeLOut*100).toInt()}/${(eyeROut*100).toInt()} full=${(eyesFullOut*100).toInt()}% · " +
            "HEART=${(heartOut*100).toInt()}% BELLY=${(bellyOut*100).toInt()}% · " +
            "LUNG=${(lungsOut*100).toInt()} KID=${(kidneysOut*100).toInt()} THY=${(thyroidOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        try {
            v.eyeL.atmosphere = maxOf(v.eyeL.atmosphere, eyeLOut)
            v.eyeR.atmosphere = maxOf(v.eyeR.atmosphere, eyeROut)
            v.eyes.atmosphere = maxOf(v.eyes.atmosphere, eyesFullOut)
            v.cenDrive.eyesOn = true
        } catch (_: Throwable) {}
        try {
            v.heart.atmosphere = maxOf(v.heart.atmosphere, heartOut, heartVentricle)
            v.belly.atmosphere = maxOf(v.belly.atmosphere, bellyOut, stomach, intestine, liver)
            v.face.atmosphere = maxOf(v.face.atmosphere, eyesFullOut * 0.5f)
            v.neck.atmosphere = maxOf(v.neck.atmosphere, thyroidOut)
            v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, heartOut * 0.9f, lungsOut)
            v.skinAbdomen.atmosphere = maxOf(v.skinAbdomen.atmosphere, bellyOut, kidneysOut * 0.8f)
        } catch (_: Throwable) {}
        try {
            v.bodyFreqRegen.bodyHeartSysOut = maxOf(v.bodyFreqRegen.bodyHeartSysOut, heartOut)
            v.bodyFreqRegen.bodyGutSysOut = maxOf(v.bodyFreqRegen.bodyGutSysOut, bellyOut)
            v.bodyFreqRegen.bodyLungSysOut = maxOf(v.bodyFreqRegen.bodyLungSysOut, lungsOut)
            v.bodyFreqRegen.bodyKidneySysOut = maxOf(v.bodyFreqRegen.bodyKidneySysOut, kidneysOut)
        } catch (_: Throwable) {}
        try {
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, eyesFullOut, heartOut, bellyOut)
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, eyesFullOut * 0.5f, heartOut * 0.6f, bellyOut * 0.6f)
        } catch (_: Throwable) {}
    }
}
