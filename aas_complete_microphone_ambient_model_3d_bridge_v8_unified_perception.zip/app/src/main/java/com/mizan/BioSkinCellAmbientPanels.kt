package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object BioSkinCellAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: BioSkinCellAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFA5D6A7.toInt()
        p.title("BIO · SKIN LAYERS · CELLS · NUCLEUS · DNA/RNA · GLANDS · MEMBRANES · BLOOD", c)
        p.note("Symbolic only. CNS glands (pineal/pituitary/hypothalamus) separate from neck/abdomen/head-surface glands.")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Skin layers ON", b.skinLayersOn) { b.skinLayersOn = it }
        p.switch("Glands ON (L/R pineal pituitary thyroid adrenal salivary…)", b.glandsOn) { b.glandsOn = it }
        p.switch("Membranes ON", b.membranesOn) { b.membranesOn = it }
        p.switch("Cell / organelles ON (belly face neck eye brain cells + non-cell + crown)", b.cellOn) { b.cellOn = it }
        p.switch("DNA / RNA analysis ON", b.dnaRnaOn) { b.dnaRnaOn = it }
        p.switch("Blood ON", b.bloodOn) { b.bloodOn = it }
        p.seek("Shared thr", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Shared level", 0f, 1.5f, b.lv) { b.lv = it }
        val st = p.status("BIO —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 250) }
        })
    }
}
