package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object CompleteHumanAnatomy360Panels {
    fun build(ctx: Context, root: LinearLayout, a: CompleteHumanAnatomy360Board, f: EnemyFoodDustbinPrankBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF66BB6A.toInt()
        p.title("COMPLETE HUMAN 360° · CAVITIES · LAYERS · CHANNELS · EYE ICT XYZ", c)
        p.note("Front/back/L/R/up/down/inner · cavities · skin→organ layers · blood/lymph/nerve/air · eye XYZ center")
        p.switch("Anatomy 360 ON", a.enabled) { a.enabled = it }
        p.switch("RAW", a.rawComplete) { a.rawComplete = it }
        p.switch("Eye ICT XYZ", a.eyeIctOn) { a.eyeIctOn = it }
        p.seek("Thr", 0.05f, 0.9f, a.thr) { a.thr = it }
        p.seek("Level", 0.2f, 1.5f, a.levelAmt) { a.levelAmt = it }
        val st = p.status("ANATOMY-360 —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() {
                st.text = a.status + " · " + f.status
                Handler(Looper.getMainLooper()).postDelayed(this, 320)
            }
        })
        p.title("SYMBOLIC FOOD/DUSTBIN PRANK TAGS (SFX·BLE ONLY)", 0xFFFFA726.toInt())
        p.note("Not real chemical/virus/food transfer — ambient tags only")
        p.switch("Prank tags ON", f.enabled) { f.enabled = it }
        p.switch("RAW", f.rawComplete) { f.rawComplete = it }
        p.seek("Prank thr", 0.05f, 0.9f, f.thr) { f.thr = it }
    }
}
