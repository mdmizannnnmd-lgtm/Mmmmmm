package com.mizan

/**
 * Eyes L/R fully linked to entire body atomspare (inside + surface + all regions) ·
 * eye visual communication with other self (dual-self ICT through vision) ·
 * kopal · white surface · bullet/knife/whip 3D draws. RAW COMPLETE.
 */
class EyeBodyAtomspareSurfaceBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.18f
    @Volatile var levelAmt = 0.92f

    // Eyes L/R + vision
    @Volatile var eyeLOut = 0f
    @Volatile var eyeROut = 0f
    @Volatile var eyeMoveOut = 0f
    @Volatile var eyeVisionOut = 0f

    // Full body link (not partial)
    @Volatile var eyeBodyLink = 0f
    @Volatile var eyeBodyFullLink = 0f
    @Volatile var bodyAtomInside = 0f
    @Volatile var bodyAtomSurface = 0f
    @Volatile var bodyAtomFull = 0f
    @Volatile var bodyHead = 0f
    @Volatile var bodyTorso = 0f
    @Volatile var bodyLimbs = 0f

    // Kopal
    @Volatile var kopalSurface = 0f

    // Other-self visual communication (eye → other self)
    @Volatile var dualSelfOn = true
    @Volatile var dualCommThr = 0.18f
    @Volatile var selfA_atom = 0f          // this self (body inside)
    @Volatile var selfB_atom = 0f          // other self (surface / mirror)
    @Volatile var eyeToOtherSelf = 0f      // eye visual ICT → other self
    @Volatile var otherSelfToEye = 0f      // other self → eye return path
    @Volatile var eyeOtherSelfComm = 0f    // bidirectional visual link
    @Volatile var dualCommOut = 0f
    @Volatile var whiteSurfaceOut = 0f

    @Volatile var surfaceMotion = 0f
    @Volatile var animCommOut = 0f

    // Weapons 3D
    @Volatile var bulletDraw = 0f
    @Volatile var knifeDraw = 0f
    @Volatile var whipDraw = 0f
    @Volatile var burstDraw = 0f
    @Volatile var arrowDraw = 0f
    @Volatile var weaponDrawFull = 0f

    @Volatile var protectOut = 0f
    @Volatile var systemFull = 0f
    @Volatile var status = "EYE-BODY-OTHERSELF idle"

    private fun lane(e: Float, t: Float = thr): Float {
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * levelAmt).coerceIn(0f, 1f)
        return if (x >= t) ((x - t) / (1.2f - t).coerceAtLeast(0.05f) * levelAmt).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        mic: Float, eyeL: Float, eyeR: Float,
        bodyInside: Float, bodyOutside: Float, model: Float, motion: Float,
        bullet: Float, knife: Float, whip: Float, burst: Float
    ) {
        if (!enabled) { status = "EYE-BODY-OTHERSELF OFF"; return }
        val e = mic.coerceIn(0f, 1.5f)

        eyeLOut = lane(maxOf(eyeL, e * 0.55f))
        eyeROut = lane(maxOf(eyeR, e * 0.55f))
        eyeVisionOut = lane(maxOf(eyeLOut, eyeROut) * 0.95f + e * 0.35f)

        // Full body regions
        bodyAtomInside = lane(maxOf(bodyInside, e * 0.5f, model * 0.45f))
        bodyAtomSurface = lane(maxOf(bodyOutside, e * 0.55f, motion * 0.5f))
        bodyHead = lane(maxOf(eyeVisionOut, bodyAtomSurface * 0.6f, e * 0.4f))
        bodyTorso = lane(maxOf(bodyAtomInside, bodyAtomSurface, model * 0.5f))
        bodyLimbs = lane(maxOf(bodyAtomSurface * 0.85f, motion * 0.6f, e * 0.35f))
        bodyAtomFull = maxOf(bodyAtomInside, bodyAtomSurface, bodyHead, bodyTorso, bodyLimbs)

        // Eyes fully linked to entire body
        eyeBodyLink = lane(maxOf(eyeVisionOut, bodyAtomFull) * 0.95f + e * 0.25f)
        eyeBodyFullLink = lane(
            maxOf(eyeLOut, eyeROut) * 0.9f +
            bodyHead * 0.5f + bodyTorso * 0.5f + bodyLimbs * 0.4f +
            bodyAtomInside * 0.45f + bodyAtomSurface * 0.45f
        )

        kopalSurface = lane(maxOf(eyeVisionOut * 0.95f, bodyHead * 0.8f, e * 0.4f))
        surfaceMotion = lane(maxOf(motion, bodyAtomSurface * 0.85f, e * 0.4f))
        animCommOut = lane(maxOf(eyeBodyFullLink, surfaceMotion, kopalSurface) * 0.9f)

        // Eye visual communication WITH OTHER SELF
        if (dualSelfOn) {
            selfA_atom = lane(bodyAtomInside * 0.95f + eyeLOut * 0.5f + bodyTorso * 0.3f)
            selfB_atom = lane(bodyAtomSurface * 0.95f + eyeROut * 0.5f + bodyLimbs * 0.3f)
            // Eye → other self (vision path)
            eyeToOtherSelf = lane(
                maxOf(eyeVisionOut, eyeBodyFullLink) * 0.95f + selfB_atom * 0.55f + e * 0.3f
            )
            // Other self → eye (return visual path)
            otherSelfToEye = lane(
                selfB_atom * 0.9f + eyeVisionOut * 0.5f + surfaceMotion * 0.4f
            )
            // Bidirectional eye ↔ other-self visual communication
            eyeOtherSelfComm = lane(maxOf(eyeToOtherSelf, otherSelfToEye) * 0.95f + animCommOut * 0.3f)

            val moveEnergy = maxOf(surfaceMotion, bodyAtomFull, animCommOut, eyeOtherSelfComm)
            dualCommOut = if (moveEnergy >= dualCommThr)
                lane(moveEnergy * 0.95f + eyeOtherSelfComm * 0.5f)
            else if (rawComplete) lane(moveEnergy * 0.65f + eyeOtherSelfComm * 0.4f) else 0f

            whiteSurfaceOut = if (moveEnergy >= dualCommThr * 0.65f || eyeOtherSelfComm > 0.2f)
                lane(maxOf(moveEnergy, eyeOtherSelfComm) * 1.05f)
            else if (rawComplete) lane(maxOf(moveEnergy, eyeOtherSelfComm) * 0.55f) else 0f
        } else {
            eyeToOtherSelf = 0f; otherSelfToEye = 0f; eyeOtherSelfComm = 0f
            dualCommOut = 0f; whiteSurfaceOut = 0f
        }

        bulletDraw = lane(maxOf(bullet, e * 0.35f))
        knifeDraw = lane(maxOf(knife, e * 0.32f))
        whipDraw = lane(maxOf(whip, e * 0.3f))
        burstDraw = lane(maxOf(burst, e * 0.33f))
        arrowDraw = lane(maxOf(bullet * 0.5f, knife * 0.4f, e * 0.25f))
        weaponDrawFull = maxOf(bulletDraw, knifeDraw, whipDraw, burstDraw, arrowDraw)
        if (rawComplete) {
            bulletDraw = maxOf(bulletDraw, 0.12f + bullet * 0.5f)
            knifeDraw = maxOf(knifeDraw, 0.12f + knife * 0.5f)
            whipDraw = maxOf(whipDraw, 0.1f + whip * 0.5f)
            burstDraw = maxOf(burstDraw, 0.1f + burst * 0.5f)
        }

        protectOut = lane(
            maxOf(eyeBodyFullLink, bodyAtomFull, dualCommOut, eyeOtherSelfComm, eyeVisionOut) * 0.95f
        )
        systemFull = maxOf(
            eyeBodyFullLink, bodyAtomFull, kopalSurface, dualCommOut,
            whiteSurfaceOut, eyeOtherSelfComm, protectOut, weaponDrawFull
        )
        if (rawComplete) systemFull = maxOf(systemFull, 0.28f)

        status =
            "EYE L/R=${(eyeLOut*100).toInt()}/${(eyeROut*100).toInt()}% vis=${(eyeVisionOut*100).toInt()}% · " +
            "FULL-LINK=${(eyeBodyFullLink*100).toInt()}% body=${(bodyAtomFull*100).toInt()}% · " +
            "eye↔otherSelf=${(eyeOtherSelfComm*100).toInt()}% (→${(eyeToOtherSelf*100).toInt()} ←${(otherSelfToEye*100).toInt()}) · " +
            "white=${(whiteSurfaceOut*100).toInt()}% prot=${(protectOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!enabled) return
        val vv = v ?: return
        try {
            vv.cnsEyesHeart.eyeLOut = maxOf(vv.cnsEyesHeart.eyeLOut, eyeLOut)
            vv.cnsEyesHeart.eyeROut = maxOf(vv.cnsEyesHeart.eyeROut, eyeROut)
            try { vv.completeHuman360.eyeIctOut = maxOf(vv.completeHuman360.eyeIctOut, maxOf(eyeVisionOut, eyeOtherSelfComm)) } catch (_: Throwable) {}

            vv.body84FullHuman.insideOut = maxOf(vv.body84FullHuman.insideOut, bodyAtomInside)
            vv.body84FullHuman.outsideOut = maxOf(vv.body84FullHuman.outsideOut, bodyAtomSurface)
            vv.body84FullHuman.atomOut = maxOf(vv.body84FullHuman.atomOut, bodyAtomFull)

            vv.soft3d.eyeBodyLinkLayer = maxOf(eyeBodyLink, eyeBodyFullLink)
            vv.soft3d.kopalSurfaceLayer = kopalSurface
            vv.soft3d.whiteSurfaceLayer = whiteSurfaceOut
            vv.soft3d.dualSelfLayer = maxOf(dualCommOut, eyeOtherSelfComm)
            vv.soft3d.bodyAtomSurfaceLayer = bodyAtomSurface
            vv.soft3d.eyeOtherSelfLayer = eyeOtherSelfComm
            vv.soft3d.bulletDrawLayer = bulletDraw
            vv.soft3d.knifeDrawLayer = knifeDraw
            vv.soft3d.whipDrawLayer = whipDraw
            vv.soft3d.burstDrawLayer = burstDraw
            vv.soft3d.arrowDrawLayer = arrowDraw

            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, protectOut)
        } catch (_: Throwable) {}
        try {
            if (sb != null && protectOut > 0.05f) {
                val d = (1f - protectOut * 0.55f).coerceIn(0.1f, 1f)
                sb.enemyBodyOut *= d
            }
        } catch (_: Throwable) {}
    }
}
