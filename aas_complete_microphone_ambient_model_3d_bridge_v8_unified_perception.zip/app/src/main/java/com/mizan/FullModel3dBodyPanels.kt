package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object FullModel3dBodyPanels {
    fun build(ctx: Context, root: LinearLayout, b: FullModel3dBodyBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFB39DDB.toInt()
        p.title("FULL 3D BODY MODEL (groups first · not single)", c)
        p.note("Full body → head/torso/arms/legs/pelvis/spine groups · optional derived singles")
        p.switch("Full 3D body master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Full body group ON", b.fullBodyOn) { b.fullBodyOn = it }
        p.switch("Head group ON", b.headGroupOn) { b.headGroupOn = it }
        p.switch("Torso group ON", b.torsoGroupOn) { b.torsoGroupOn = it }
        p.switch("Arm L/R groups ON", b.armLGroupOn) { b.armLGroupOn = it; b.armRGroupOn = it }
        p.switch("Leg L/R groups ON", b.legLGroupOn) { b.legLGroupOn = it; b.legRGroupOn = it }
        p.switch("Pelvis / spine groups ON", b.pelvisGroupOn) { b.pelvisGroupOn = it; b.spineGroupOn = it }
        p.switch("Derive singles after groups", b.deriveSingles) { b.deriveSingles = it }
        p.seek("Threshold", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Level", 0f, 1.5f, b.level) { b.level = it }
        val st = p.status("FULL3D —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 250) }
        })
    }
}
