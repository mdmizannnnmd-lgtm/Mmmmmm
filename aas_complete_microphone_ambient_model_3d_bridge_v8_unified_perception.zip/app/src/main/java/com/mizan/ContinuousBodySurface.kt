package com.mizan

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Low-resolution, smooth-union outer human surface, meshed once from rounded anatomical volumes.
 * This is a stylized visualization surface, not a clinical or scan-derived body mesh.
 */
internal object ContinuousBodySurface {

    data class Triangle(
        val ax: Float, val ay: Float, val az: Float,
        val bx: Float, val by: Float, val bz: Float,
        val cx: Float, val cy: Float, val cz: Float,
        val nx: Float, val ny: Float, val nz: Float
    )

    private data class Vec3(val x: Float, val y: Float, val z: Float)
    private data class Primitive(
        val capsule: Boolean,
        val ax: Float, val ay: Float, val az: Float,
        val bx: Float, val by: Float, val bz: Float,
        val rx: Float, val ry: Float, val rz: Float,
        val endRadius: Float = rx
    )

    private val primitives = listOf(
        // Central shell: head, neck, chest, abdomen, and pelvis merge into one surface.
        ellipsoid(0f, 1.53f, 0f, 0.16f, 0.21f, 0.14f),
        ellipsoid(0f, 1.29f, 0f, 0.085f, 0.15f, 0.085f),
        ellipsoid(0f, 1.00f, 0f, 0.29f, 0.27f, 0.16f),
        ellipsoid(0f, 0.66f, 0f, 0.235f, 0.24f, 0.145f),
        ellipsoid(0f, 0.25f, -0.005f, 0.245f, 0.16f, 0.15f),
        ellipsoid(-0.31f, 1.09f, 0f, 0.135f, 0.14f, 0.12f),
        ellipsoid(0.31f, 1.09f, 0f, 0.135f, 0.14f, 0.12f),
        // Arms, hands, fingers.
        capsule(-0.38f, 1.02f, 0f, -0.50f, 0.45f, 0f, 0.095f, 0.080f),
        capsule(-0.50f, 0.45f, 0f, -0.55f, 0.04f, 0f, 0.078f, 0.062f),
        capsule(-0.55f, 0.04f, 0f, -0.56f, -0.12f, 0.015f, 0.060f, 0.050f),
        capsule(0.38f, 1.02f, 0f, 0.50f, 0.45f, 0f, 0.095f, 0.080f),
        capsule(0.50f, 0.45f, 0f, 0.55f, 0.04f, 0f, 0.078f, 0.062f),
        capsule(0.55f, 0.04f, 0f, 0.56f, -0.12f, 0.015f, 0.060f, 0.050f),
        // Legs and feet.
        capsule(-0.13f, 0.18f, 0f, -0.16f, -0.40f, 0f, 0.135f, 0.115f),
        capsule(-0.16f, -0.40f, 0f, -0.16f, -0.80f, 0f, 0.095f, 0.073f),
        capsule(-0.16f, -0.80f, 0f, -0.16f, -0.87f, 0.20f, 0.080f, 0.065f),
        capsule(0.13f, 0.18f, 0f, 0.16f, -0.40f, 0f, 0.135f, 0.115f),
        capsule(0.16f, -0.40f, 0f, 0.16f, -0.80f, 0f, 0.095f, 0.073f),
        capsule(0.16f, -0.80f, 0f, 0.16f, -0.87f, 0.20f, 0.080f, 0.065f),
        // A restrained palm / heel volume smooths the wrists and ankles into their limbs.
        ellipsoid(-0.56f, -0.055f, 0.005f, 0.063f, 0.075f, 0.045f),
        ellipsoid(0.56f, -0.055f, 0.005f, 0.063f, 0.075f, 0.045f),
        ellipsoid(-0.16f, -0.84f, 0.075f, 0.080f, 0.055f, 0.15f),
        ellipsoid(0.16f, -0.84f, 0.075f, 0.080f, 0.055f, 0.15f)
    )

    private val cubeCorners = arrayOf(
        intArrayOf(0, 0, 0), intArrayOf(1, 0, 0),
        intArrayOf(1, 1, 0), intArrayOf(0, 1, 0),
        intArrayOf(0, 0, 1), intArrayOf(1, 0, 1),
        intArrayOf(1, 1, 1), intArrayOf(0, 1, 1)
    )
    private val tetrahedra = arrayOf(
        intArrayOf(0, 5, 1, 6), intArrayOf(0, 1, 2, 6),
        intArrayOf(0, 2, 3, 6), intArrayOf(0, 3, 7, 6),
        intArrayOf(0, 7, 4, 6), intArrayOf(0, 4, 5, 6)
    )
    private val tetraEdges = arrayOf(
        intArrayOf(0, 1), intArrayOf(0, 2), intArrayOf(0, 3),
        intArrayOf(1, 2), intArrayOf(1, 3), intArrayOf(2, 3)
    )

    private val generatedMesh: Lazy<List<Triangle>> = lazy(LazyThreadSafetyMode.SYNCHRONIZED) { buildMesh() }
    val triangles: List<Triangle> get() = generatedMesh.value
    @Volatile private var warmStarted = false

    /** Build the shared mesh off the UI/GL render thread so the first frame does not do meshing work. */
    @Synchronized
    fun prepareAsync() {
        if (generatedMesh.isInitialized() || warmStarted) return
        warmStarted = true
        Thread({
            triangles
        }, "continuous-body-mesh").apply {
            isDaemon = true
            start()
        }
    }

    private fun ellipsoid(x: Float, y: Float, z: Float, rx: Float, ry: Float, rz: Float) =
        Primitive(false, x, y, z, x, y, z, rx, ry, rz)

    private fun capsule(
        ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float,
        startRadius: Float, endRadius: Float
    ) = Primitive(true, ax, ay, az, bx, by, bz, startRadius, startRadius, startRadius, endRadius)

    private fun buildMesh(): List<Triangle> {
        val step = 0.045f
        val minX = -0.78f
        val minY = -1.00f
        val minZ = -0.34f
        val nx = ((0.78f - minX) / step).toInt()
        val ny = ((1.76f - minY) / step).toInt()
        val nz = ((0.34f - minZ) / step).toInt()
        val sx = nx + 1
        val sy = ny + 1
        val values = FloatArray(sx * sy * (nz + 1))
        fun index(x: Int, y: Int, z: Int) = (z * sy + y) * sx + x

        for (z in 0..nz) {
            val pz = minZ + z * step
            for (y in 0..ny) {
                val py = minY + y * step
                for (x in 0..nx) {
                    values[index(x, y, z)] = signedDistance(minX + x * step, py, pz)
                }
            }
        }

        val result = ArrayList<Triangle>()
        val cornerPoints = Array(8) { Vec3(0f, 0f, 0f) }
        val cornerValues = FloatArray(8)
        for (z in 0 until nz) for (y in 0 until ny) for (x in 0 until nx) {
            var hasInside = false
            var hasOutside = false
            for (c in 0 until 8) {
                val o = cubeCorners[c]
                val d = values[index(x + o[0], y + o[1], z + o[2])]
                cornerValues[c] = d
                if (d < 0f) hasInside = true else hasOutside = true
                cornerPoints[c] = Vec3(
                    minX + (x + o[0]) * step,
                    minY + (y + o[1]) * step,
                    minZ + (z + o[2]) * step
                )
            }
            if (!hasInside || !hasOutside) continue

            for (tet in tetrahedra) {
                val points = Array(4) { cornerPoints[tet[it]] }
                val distances = FloatArray(4) { cornerValues[tet[it]] }
                val cut = ArrayList<Vec3>(4)
                for (edge in tetraEdges) {
                    val a = edge[0]
                    val b = edge[1]
                    if ((distances[a] < 0f) != (distances[b] < 0f)) {
                        cut.add(interpolate(points[a], points[b], distances[a], distances[b]))
                    }
                }
                when (cut.size) {
                    3 -> addOrientedTriangle(result, cut[0], cut[1], cut[2])
                    4 -> {
                        val center = Vec3(
                            cut.sumOf { it.x.toDouble() }.toFloat() * 0.25f,
                            cut.sumOf { it.y.toDouble() }.toFloat() * 0.25f,
                            cut.sumOf { it.z.toDouble() }.toFloat() * 0.25f
                        )
                        val normal = gradient(center.x, center.y, center.z)
                        val ordered = cut.sortedBy {
                            atan2(
                                dot(subtract(it, center), cross(normal, basis(normal))),
                                dot(subtract(it, center), basis(normal))
                            )
                        }
                        addOrientedTriangle(result, ordered[0], ordered[1], ordered[2])
                        addOrientedTriangle(result, ordered[0], ordered[2], ordered[3])
                    }
                }
            }
        }
        return result
    }

    private fun interpolate(a: Vec3, b: Vec3, da: Float, db: Float): Vec3 {
        val t = (da / (da - db)).coerceIn(0f, 1f)
        return Vec3(
            a.x + (b.x - a.x) * t,
            a.y + (b.y - a.y) * t,
            a.z + (b.z - a.z) * t
        )
    }

    private fun addOrientedTriangle(out: MutableList<Triangle>, a: Vec3, b: Vec3, c: Vec3) {
        var v1 = b
        var v2 = c
        var n = cross(subtract(v1, a), subtract(v2, a))
        val length = sqrt(dot(n, n))
        if (length < 0.000001f) return
        n = Vec3(n.x / length, n.y / length, n.z / length)
        val center = Vec3((a.x + v1.x + v2.x) / 3f, (a.y + v1.y + v2.y) / 3f, (a.z + v1.z + v2.z) / 3f)
        val outward = gradient(center.x, center.y, center.z)
        if (dot(n, outward) < 0f) {
            val swap = v1
            v1 = v2
            v2 = swap
            n = Vec3(-n.x, -n.y, -n.z)
        }
        out.add(Triangle(a.x, a.y, a.z, v1.x, v1.y, v1.z, v2.x, v2.y, v2.z, n.x, n.y, n.z))
    }

    private fun signedDistance(x: Float, y: Float, z: Float): Float {
        var distance = primitiveDistance(primitives[0], x, y, z)
        for (i in 1 until primitives.size) {
            val next = primitiveDistance(primitives[i], x, y, z)
            distance = smoothUnion(distance, next, 0.065f)
        }
        return distance
    }

    private fun primitiveDistance(p: Primitive, x: Float, y: Float, z: Float): Float {
        if (p.capsule) {
            val abx = p.bx - p.ax
            val aby = p.by - p.ay
            val abz = p.bz - p.az
            val apx = x - p.ax
            val apy = y - p.ay
            val apz = z - p.az
            val denom = abx * abx + aby * aby + abz * abz
            val t = if (denom < 0.000001f) 0f else
                ((apx * abx + apy * aby + apz * abz) / denom).coerceIn(0f, 1f)
            val dx = x - (p.ax + abx * t)
            val dy = y - (p.ay + aby * t)
            val dz = z - (p.az + abz * t)
            val radius = p.rx + (p.endRadius - p.rx) * t
            return sqrt(dx * dx + dy * dy + dz * dz) - radius
        }
        val dx = x - p.ax
        val dy = y - p.ay
        val dz = z - p.az
        val qx = dx / p.rx
        val qy = dy / p.ry
        val qz = dz / p.rz
        val k0 = sqrt(qx * qx + qy * qy + qz * qz)
        val k1 = sqrt(
            dx * dx / (p.rx * p.rx * p.rx * p.rx) +
                dy * dy / (p.ry * p.ry * p.ry * p.ry) +
                dz * dz / (p.rz * p.rz * p.rz * p.rz)
        )
        return if (k1 < 0.000001f) -min(p.rx, min(p.ry, p.rz)) else k0 * (k0 - 1f) / k1
    }

    private fun smoothUnion(a: Float, b: Float, k: Float): Float {
        val h = (k - abs(a - b)).coerceAtLeast(0f) / k
        return min(a, b) - h * h * k * 0.25f
    }

    private fun gradient(x: Float, y: Float, z: Float): Vec3 {
        val e = 0.008f
        return normalize(
            Vec3(
                signedDistance(x + e, y, z) - signedDistance(x - e, y, z),
                signedDistance(x, y + e, z) - signedDistance(x, y - e, z),
                signedDistance(x, y, z + e) - signedDistance(x, y, z - e)
            )
        )
    }

    private fun basis(n: Vec3): Vec3 =
        normalize(cross(n, if (abs(n.y) < 0.85f) Vec3(0f, 1f, 0f) else Vec3(1f, 0f, 0f)))

    private fun subtract(a: Vec3, b: Vec3) = Vec3(a.x - b.x, a.y - b.y, a.z - b.z)
    private fun cross(a: Vec3, b: Vec3) =
        Vec3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x)
    private fun dot(a: Vec3, b: Vec3) = a.x * b.x + a.y * b.y + a.z * b.z
    private fun normalize(v: Vec3): Vec3 {
        val length = sqrt(dot(v, v)).coerceAtLeast(0.000001f)
        return Vec3(v.x / length, v.y / length, v.z / length)
    }
}
