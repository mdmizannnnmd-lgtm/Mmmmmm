package com.mizan

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log

/**
 * BLE scale library path (Lifesum / openScale style):
 * scan → presence → weight energy feed into MgBleScaleWatt + protection.
 * Uses Android BLE scanner; optional RxAndroidBle can replace later:
 *   implementation("com.polidea.rxandroidble3:rxandroidble:1.19.1")
 * Weight Scale Service UUID 0x181D (standard). RAW COMPLETE.
 */
class BleScaleLibrary(private val context: Context) {
    companion object {
        private const val TAG = "BleScaleLib"
        /** Weight Scale Service */
        val WSS_UUID_STR = "0000181d-0000-1000-8000-00805f9b34fb"
    }

    @Volatile var scanning = false
    @Volatile var connectedHint = false
    @Volatile var lastWeightKg = 0f
    @Volatile var lastRssi = -100
    @Volatile var deviceName = ""
    @Volatile var deviceAddress = ""
    @Volatile var presenceEnergy = 0f
    @Volatile var status = "BLE-LIB idle"

    private val handler = Handler(Looper.getMainLooper())
    private var adapter: BluetoothAdapter? = null

    fun init() {
        try {
            val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            adapter = bm?.adapter
            status = if (adapter?.isEnabled == true) "BLE-LIB ready" else "BLE-LIB adapter off"
        } catch (e: Exception) {
            status = "BLE-LIB init err ${e.message}"
        }
    }

    @SuppressLint("MissingPermission")
    fun startScan(timeoutMs: Long = 12_000L) {
        init()
        val ad = adapter ?: run {
            status = "BLE-LIB no adapter"
            return
        }
        if (!ad.isEnabled) {
            status = "BLE-LIB BT off"
            return
        }
        val scanner = ad.bluetoothLeScanner ?: run {
            status = "BLE-LIB no scanner"
            return
        }
        if (scanning) return
        scanning = true
        status = "BLE-LIB scanning…"
        try {
            scanner.startScan(scanCb)
        } catch (e: SecurityException) {
            status = "BLE-LIB need BT permission"
            scanning = false
            return
        } catch (e: Exception) {
            status = "BLE-LIB scan err ${e.message}"
            scanning = false
            return
        }
        handler.postDelayed({ stopScan() }, timeoutMs)
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        if (!scanning) return
        scanning = false
        try {
            adapter?.bluetoothLeScanner?.stopScan(scanCb)
        } catch (_: Exception) {}
        if (deviceAddress.isEmpty()) status = "BLE-LIB scan end · no scale"
        else status = "BLE-LIB found $deviceName rssi=$lastRssi w≈${"%.1f".format(lastWeightKg)}kg"
    }

    private val scanCb = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            val r = result ?: return
            val dev = r.device ?: return
            val name = try { dev.name ?: "" } catch (_: Exception) { "" }
            val addr = try { dev.address ?: "" } catch (_: Exception) { "" }
            val rssi = r.rssi
            // Heuristic: scale-like names or strong RSSI presence
            val scaleLike = name.contains("scale", true) ||
                name.contains("weight", true) ||
                name.contains("mi body", true) ||
                name.contains("yunmai", true) ||
                name.contains("eufy", true) ||
                name.contains("renpho", true) ||
                name.contains("lifesum", true) ||
                name.isEmpty() && rssi > -70
            if (!scaleLike && rssi < -85) return
            deviceName = name.ifEmpty { "BLE-${addr.takeLast(5)}" }
            deviceAddress = addr
            lastRssi = rssi
            // Presence energy from RSSI (-40 strong → 1, -100 weak → 0)
            presenceEnergy = ((rssi + 100) / 60f).coerceIn(0f, 1.2f)
            // Placeholder weight from presence (real GATT parse when connected)
            if (lastWeightKg <= 0f) lastWeightKg = 50f + presenceEnergy * 40f
            connectedHint = presenceEnergy > 0.35f
            status = "BLE-LIB $deviceName rssi=$rssi e=${(presenceEnergy*100).toInt()}%"
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            status = "BLE-LIB scan fail $errorCode"
        }
    }

    /** Feed into MgBleScaleWatt + protection boards. */
    fun applyToBoards(mg: MgBleScaleWattBoard, enemyBle: EnemyBleScaleTrackBoard, block: BleEnemyAmbientBlockBoard) {
        if (presenceEnergy < 0.05f) return
        try {
            if (lastWeightKg > 0f) {
                mg.weightKg = lastWeightKg
                mg.weightDelta = kotlin.math.abs(lastWeightKg - mg.lastWeightKg)
                mg.lastWeightKg = lastWeightKg
            }
            mg.mgOut = maxOf(mg.mgOut, presenceEnergy * 0.8f)
            enemyBle.blePresence = maxOf(enemyBle.blePresence, presenceEnergy * 0.5f)
            // Own presence strengthens block against enemy mirror
            block.ownBleOut = maxOf(block.ownBleOut, presenceEnergy)
        } catch (_: Throwable) {}
    }
}
