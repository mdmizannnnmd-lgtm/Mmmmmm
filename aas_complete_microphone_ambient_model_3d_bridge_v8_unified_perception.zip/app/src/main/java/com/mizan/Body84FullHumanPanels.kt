package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object Body84FullHumanPanels {
    fun build(ctx: Context, root: LinearLayout, b: Body84FullHumanBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFA5D6A7.toInt()
        p.title("84 FULL HUMAN · ATOMPARE IN/OUT · POSE·SEG·OBB · MOTION · VIS/COLOUR", c)
        p.note("All 84 channels active — complete human model, not single-part")
        p.switch("84 Full Human master ON", b.enabled) { b.enabled = it }
        p.switch("Outside↔Inside interconnect", try { b.interconnectOn } catch (_: Throwable) { true }) { try { b.interconnectOn = it } catch (_: Throwable) {} }
        p.seek("Interconnect level", 0.1f, 1f, try { b.interconnectLv } catch (_: Throwable) { 0.88f }) { try { b.interconnectLv = it } catch (_: Throwable) {} }
        p.switch("Object track (pose/seg/obb)", try { b.objectTrackOn } catch (_: Throwable) { true }) { try { b.objectTrackOn = it } catch (_: Throwable) {} }
        p.switch("Screen 3D anatomy ON", try { b.screen3dOn } catch (_: Throwable) { true }) { try { b.screen3dOn = it } catch (_: Throwable) {} }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Full human only (no single)", b.fullHumanOnly) { b.fullHumanOnly = it }
        p.button("Enable FULL HUMAN (all 84)") { _ -> b.enableFullHuman() }

        p.title("ATOMPARE INSIDE / OUTSIDE", c)
        p.switch("Outside atomspare ON", b.outsideOn) { b.outsideOn = it }
        p.switch("Inside atomspare ON", b.insideOn) { b.insideOn = it }
        p.seek("Atom thr", 0.05f, 0.98f, b.atomThr) { b.atomThr = it }
        p.seek("Atom level", 0f, 1.5f, b.atomLv) { b.atomLv = it }
        p.seek("Atom intensity", 0f, 1.5f, b.atomIntensity) { b.atomIntensity = it }

        p.title("MOTION CONTROL", c)
        p.switch("Motion ON", b.motionOn) { b.motionOn = it }
        p.seek("Move thr / lv", 0.05f, 0.98f, b.moveThr) { b.moveThr = it }
        p.seek("Move level", 0f, 1.5f, b.moveLv) { b.moveLv = it }
        p.seek("Speed thr", 0.05f, 0.98f, b.speedThr) { b.speedThr = it }
        p.seek("Speed level", 0f, 1.5f, b.speedLv) { b.speedLv = it }
        p.seek("Wave thr", 0.05f, 0.98f, b.waveThr) { b.waveThr = it }
        p.seek("Wave level", 0f, 1.5f, b.waveLv) { b.waveLv = it }

        p.title("VISUAL · COLOUR THRESHOLD", c)
        p.seek("Visual thr / lv", 0.05f, 0.98f, b.visualThr) { b.visualThr = it }
        p.seek("Visual level", 0f, 1.5f, b.visualLv) { b.visualLv = it }
        p.seek("Colour thr", 0.05f, 0.98f, b.colourThr) { b.colourThr = it }
        p.seek("Colour level", 0f, 1.5f, b.colourLv) { b.colourLv = it }
        p.seek("Brightness", 0f, 1.5f, b.bright) { b.bright = it }
        p.seek("Contrast", 0f, 1.5f, b.contrast) { b.contrast = it }

        p.title("POSE · SEGMENT · OBB FULL MODELS", c)
        p.switch("Pose model ON", b.poseOn) { b.poseOn = it }
        p.switch("Segment model ON", b.segmentOn) { b.segmentOn = it }
        p.switch("OBB model ON", b.obbOn) { b.obbOn = it }

        val st = p.status("84 HUMAN —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
