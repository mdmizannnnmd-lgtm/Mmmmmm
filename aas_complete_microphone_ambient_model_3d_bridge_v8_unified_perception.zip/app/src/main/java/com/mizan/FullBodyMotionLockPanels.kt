package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object FullBodyMotionLockPanels {
    fun build(ctx: Context, root: LinearLayout, b: FullBodyMotionLockBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFFCC80.toInt()
        p.title("FULL BODY MOTION LOCK · HEAD·EYES·TORSO·ARMS·LEGS · MOVE/SPEED/WAVE", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Full body motion LOCK ON", b.lockOn) { b.lockOn = it }
        p.seek("Lock thr", 0.05f, 0.98f, b.lockThr) { b.lockThr = it }
        p.seek("Lock level", 0f, 1.5f, b.lockLv) { b.lockLv = it }
        p.switch("Hard lock (max freeze)", b.hardLock) { b.hardLock = it }
        val st = p.status("BODY LOCK —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 200) }
        })
    }
}
