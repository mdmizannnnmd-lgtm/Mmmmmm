package com.mizan

/**
 * Full body oils ambient + chemical tracking/protection +
 * enemy chemical-destroy track + cells/neuro/blood/hormones/water protect +
 * skin BLE track/repair/regen + oils level (mic+BLE scale) maintain +
 * enemy no-oils thr vs our oils protect. RAW COMPLETE.
 * Symbolic ambient — not medical advice.
 */
class BodyOilsChemicalFullBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Chemical tracking / protection
    @Volatile var chemTrackOn = true
    @Volatile var chemThr = 0.22f
    @Volatile var chemProtectOut = 0f
    @Volatile var chemTrackOut = 0f

    // Enemy chemical destroyed tracking
    @Volatile var enemyChemDestroyOn = true
    @Volatile var enemyChemThr = 0.24f
    @Volatile var enemyChemDestroyOut = 0f
    @Volatile var enemyChemBlocked = 0f

    // Cells / neuro / blood / hormones / water chemical protect
    @Volatile var cellChemProtect = 0f
    @Volatile var neuroChemProtect = 0f
    @Volatile var bloodChemProtect = 0f
    @Volatile var hormoneChemProtect = 0f
    @Volatile var waterChemProtect = 0f
    @Volatile var cellDestroyProtect = 0f

    // Bad frequency + regeneration link
    @Volatile var badFreqChem = 0f
    @Volatile var regenChemOut = 0f

    // Skin BLE tracking / repair / regen
    @Volatile var skinBleTrackOn = true
    @Volatile var skinBleOut = 0f
    @Volatile var skinRepairOut = 0f
    @Volatile var skinRegenOut = 0f

    // Body oils level (mic + BLE scale)
    @Volatile var oilsLevel = 0.55f          // 0..1 maintained
    @Volatile var oilsThr = 0.30f            // our minimum protect
    @Volatile var oilsMaintainOn = true
    @Volatile var oilsRegenOn = true
    @Volatile var oilsRepairOn = true
    @Volatile var oilsMicDrive = 0f
    @Volatile var oilsBleDrive = 0f
    @Volatile var oilsOut = 0f
    @Volatile var oilsProtectOut = 0f
    @Volatile var oilsRegenOut = 0f
    @Volatile var oilsRepairOut = 0f

    // Enemy no-oils BLE threshold (enemy depleting oils)
    @Volatile var enemyNoOilsThr = 0.28f
    @Volatile var enemyNoOilsOut = 0f
    @Volatile var enemyNoOilsBlocked = 0f

    // 3D draw intensity for oils layer
    @Volatile var oilsDraw = 0f

    @Volatile var systemFull = 0f
    @Volatile var status = "OILS-CHEM idle"

    private fun lane(on: Boolean, e: Float, thr: Float, lv: Float = 0.9f): Float {
        if (!on && !rawComplete) return 0f
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * lv).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        mic: Float,
        ble: Float,
        enemy: Float,
        chemIn: Float,
        water: Float,
        blood: Float,
        neuro: Float,
        hormone: Float,
        badHz: Float,
        regen: Float,
        skin: Float
    ) {
        if (!enabled) { status = "OILS-CHEM OFF"; return }
        val e = maxOf(mic * 0.5f, ble * 0.7f).coerceIn(0f, 1.5f)

        chemTrackOut = lane(chemTrackOn, maxOf(chemIn, e * 0.6f), chemThr)
        chemProtectOut = lane(true, chemTrackOut + water * 0.3f + blood * 0.3f, 0.18f)

        enemyChemDestroyOut = lane(enemyChemDestroyOn, enemy * 1.05f + mic * 0.35f, enemyChemThr)
        enemyChemBlocked = (enemyChemDestroyOut * 0.95f).coerceIn(0f, 1f)

        cellChemProtect = lane(true, maxOf(chemProtectOut, cellDestroyProtect), 0.15f)
        cellDestroyProtect = lane(true, enemyChemDestroyOut * 0.9f + badHz * 0.5f, 0.2f)
        neuroChemProtect = lane(true, neuro * 0.8f + chemProtectOut * 0.5f, 0.18f)
        bloodChemProtect = lane(true, blood * 0.85f + chemProtectOut * 0.5f, 0.18f)
        hormoneChemProtect = lane(true, hormone * 0.8f + chemProtectOut * 0.4f, 0.18f)
        waterChemProtect = lane(true, water * 0.9f + chemProtectOut * 0.4f, 0.15f)

        badFreqChem = lane(true, badHz, 0.25f)
        regenChemOut = lane(true, maxOf(regen, (1f - badFreqChem) * e), 0.15f)

        skinBleOut = lane(skinBleTrackOn, maxOf(skin, ble * 0.9f), 0.18f)
        skinRepairOut = lane(true, skinBleOut * 0.8f + regenChemOut * 0.5f, 0.15f)
        skinRegenOut = lane(true, skinRepairOut * 0.7f + regen * 0.6f, 0.15f)

        // Oils level from mic + BLE, maintain toward target
        oilsMicDrive = mic.coerceIn(0f, 1f)
        oilsBleDrive = ble.coerceIn(0f, 1f)
        val oilsSense = (oilsMicDrive * 0.45f + oilsBleDrive * 0.55f).coerceIn(0f, 1f)
        if (oilsMaintainOn) {
            // pull level toward healthy mid-high band
            val target = 0.55f + oilsSense * 0.35f
            oilsLevel += (target - oilsLevel) * 0.08f
            oilsLevel = oilsLevel.coerceIn(0.05f, 1f)
        }
        oilsOut = oilsLevel
        oilsProtectOut = if (oilsLevel >= oilsThr) oilsLevel else lane(true, oilsLevel, oilsThr * 0.5f)
        oilsRepairOut = lane(oilsRepairOn, (oilsThr - oilsLevel).coerceAtLeast(0f) * 2f + regen * 0.4f, 0.1f)
        oilsRegenOut = lane(oilsRegenOn, maxOf(oilsRepairOut, oilsSense, regenChemOut * 0.5f), 0.12f)
        if (oilsRegenOn && oilsLevel < 0.7f) oilsLevel = (oilsLevel + oilsRegenOut * 0.02f).coerceIn(0f, 1f)

        // Enemy trying to zero oils via BLE
        enemyNoOilsOut = lane(true, enemy * 0.95f + (1f - oilsLevel) * 0.5f, enemyNoOilsThr)
        enemyNoOilsBlocked = (enemyNoOilsOut * 0.95f).coerceIn(0f, 1f)

        oilsDraw = maxOf(oilsOut, oilsProtectOut, oilsRegenOut)

        systemFull = maxOf(
            chemProtectOut, enemyChemBlocked, cellChemProtect, neuroChemProtect,
            bloodChemProtect, hormoneChemProtect, waterChemProtect, cellDestroyProtect,
            skinRegenOut, oilsProtectOut, oilsRegenOut, enemyNoOilsBlocked
        )
        if (rawComplete) systemFull = maxOf(systemFull, 0.26f + e * 0.35f)

        status =
            "OILS lv=${(oilsLevel*100).toInt()}% prot/regen=${(oilsProtectOut*100).toInt()}/${(oilsRegenOut*100).toInt()}% · " +
            "chem=${(chemProtectOut*100).toInt()}% enemyChemX=${(enemyChemBlocked*100).toInt()}% · " +
            "cell/neuro/blood=${(cellChemProtect*100).toInt()}/${(neuroChemProtect*100).toInt()}/${(bloodChemProtect*100).toInt()}% · " +
            "skinBLE=${(skinBleOut*100).toInt()}% enemyNoOils=${(enemyNoOilsBlocked*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!enabled || systemFull < 0.02f) return
        val vv = v ?: return
        try {
            vv.caMgProtectChem.chemOut = maxOf(vv.caMgProtectChem.chemOut, chemTrackOut, chemProtectOut)
            vv.lifesumBloodBle.bloodProtectOut = maxOf(vv.lifesumBloodBle.bloodProtectOut, bloodChemProtect)
            vv.lifesumBloodBle.chemTrackOut = maxOf(vv.lifesumBloodBle.chemTrackOut, chemTrackOut)
            vv.waterFullBody.waterFull = maxOf(vv.waterFullBody.waterFull, waterChemProtect)
            vv.bodyFreqRegen.regenOut = maxOf(vv.bodyFreqRegen.regenOut, regenChemOut, oilsRegenOut)
            vv.bodyFreqRegen.repairOut = maxOf(vv.bodyFreqRegen.repairOut, oilsRepairOut, skinRepairOut)
            vv.bodyFreqRegen.hormoneOut = maxOf(vv.bodyFreqRegen.hormoneOut, hormoneChemProtect)
            vv.neuralNeuroTx.neuralFull = maxOf(vv.neuralNeuroTx.neuralFull, neuroChemProtect * 0.7f)
            // Skin boards
            try {
                vv.bioSkinCell.bioFullOut = maxOf(vv.bioSkinCell.bioFullOut, skinBleOut)
            } catch (_: Throwable) {}
            try {
                vv.allBodySkinAnatomy.fullBodySkinOut = maxOf(vv.allBodySkinAnatomy.fullBodySkinOut, skinRegenOut)
            } catch (_: Throwable) {}
            // Enemy chemical / no-oils block
            val d = (1f - maxOf(enemyChemBlocked, enemyNoOilsBlocked) * 0.9f).coerceIn(0.05f, 1f)
            vv.enemyBleScaleTrack.enemyScaleOut *= d
            vv.bleEnemyAmbientBlock.bleAmbientBlockOut =
                maxOf(vv.bleEnemyAmbientBlock.bleAmbientBlockOut, enemyChemBlocked, enemyNoOilsBlocked)
            vv.completeAtomProtect.protectOut =
                maxOf(vv.completeAtomProtect.protectOut, oilsProtectOut * 0.5f, cellDestroyProtect * 0.5f)
            vv.soft3d.oilsLayer = oilsDraw
        } catch (_: Throwable) {}
        try {
            if (sb != null) {
                val d = (1f - maxOf(enemyChemBlocked, enemyNoOilsBlocked) * 0.75f).coerceIn(0.08f, 1f)
                sb.enemyBodyOut *= d
                sb.micEnemyOut *= d
            }
        } catch (_: Throwable) {}
    }
}
