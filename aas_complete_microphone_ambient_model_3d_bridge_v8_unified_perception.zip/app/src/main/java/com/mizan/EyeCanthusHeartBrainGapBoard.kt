package com.mizan

/**
 * Gaps filled: eye corners (medial/lateral canthus) · eye→heart autonomic link ·
 * face neural · eye motion protect · brain visual path. Research: EW/SCG ocular ANS.
 * Symbolic ambient. RAW COMPLETE.
 */
class EyeCanthusHeartBrainGapBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.22f
    @Volatile var levelAmt = 0.92f

    // Canthus L/R
    @Volatile var canthusMedialL = 0f
    @Volatile var canthusLateralL = 0f
    @Volatile var canthusMedialR = 0f
    @Volatile var canthusLateralR = 0f
    @Volatile var canthusFull = 0f

    // Eye motion protect
    @Volatile var eyeMotionProtectOn = true
    @Volatile var eyeMotionOut = 0f
    @Volatile var eyeMotionLock = 0f

    // Eye → heart → brain path
    @Volatile var eyeToHeart = 0f
    @Volatile var heartToBrain = 0f
    @Volatile var eyeHeartBrain = 0f

    // Face neural
    @Volatile var faceNeural = 0f
    @Volatile var trigeminalFace = 0f
    @Volatile var facialNerveOut = 0f

    // Brain visual gaps
    @Volatile var opticPath = 0f
    @Volatile var visualCortexGap = 0f
    @Volatile var ewNucleus = 0f   // Edinger-Westphal symbolic
    @Volatile var scgOcular = 0f   // superior cervical ganglion ocular

    @Volatile var gapFull = 0f
    @Volatile var status = "EYE-CANTHUS-HEART-BRAIN idle"

    private fun lane(e: Float): Float {
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * levelAmt).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * levelAmt).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, eyeL: Float, eyeR: Float, heart: Float, brain: Float, face: Float) {
        if (!enabled) { status = "EYE-GAP OFF"; return }
        val e = maxOf(mic * 0.5f, eyeL, eyeR, face * 0.7f).coerceIn(0f, 1.5f)
        canthusMedialL = lane(eyeL * 0.95f)
        canthusLateralL = lane(eyeL * 0.90f)
        canthusMedialR = lane(eyeR * 0.95f)
        canthusLateralR = lane(eyeR * 0.90f)
        canthusFull = maxOf(canthusMedialL, canthusLateralL, canthusMedialR, canthusLateralR)
        eyeMotionOut = lane(maxOf(eyeL, eyeR) * 1.05f)
        eyeMotionLock = if (eyeMotionProtectOn) eyeMotionOut * levelAmt else 0f
        eyeToHeart = lane(maxOf(eyeL, eyeR) * 0.8f + heart * 0.6f)
        heartToBrain = lane(heart * 0.7f + brain * 0.8f)
        eyeHeartBrain = maxOf(eyeToHeart, heartToBrain, lane(e * 0.9f))
        faceNeural = lane(face * 0.95f + e * 0.5f)
        trigeminalFace = lane(face * 0.9f)
        facialNerveOut = lane(face * 0.88f)
        opticPath = lane(maxOf(eyeL, eyeR) * 0.92f + brain * 0.5f)
        visualCortexGap = lane(brain * 0.95f)
        ewNucleus = lane(eyeL * 0.5f + eyeR * 0.5f + brain * 0.4f)
        scgOcular = lane(e * 0.7f + brain * 0.4f)
        gapFull = maxOf(canthusFull, eyeMotionLock, eyeHeartBrain, faceNeural, opticPath, visualCortexGap)
        if (rawComplete) gapFull = maxOf(gapFull, 0.28f + e * 0.35f)
        status =
            "CANTHUS=${(canthusFull*100).toInt()}% motionLock=${(eyeMotionLock*100).toInt()}% · " +
            "eye♥brain=${(eyeHeartBrain*100).toInt()}% faceN=${(faceNeural*100).toInt()}% · " +
            "optic/V1=${(opticPath*100).toInt()}/${(visualCortexGap*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView?) {
        if (!enabled || gapFull < 0.02f) return
        val vv = v ?: return
        try {
            vv.cnsEyesHeart.eyeLOut = maxOf(vv.cnsEyesHeart.eyeLOut, canthusMedialL * 0.8f)
            vv.cnsEyesHeart.eyeROut = maxOf(vv.cnsEyesHeart.eyeROut, canthusMedialR * 0.8f)
            vv.cnsEyesHeart.heartOut = maxOf(vv.cnsEyesHeart.heartOut, eyeToHeart * 0.5f)
            vv.neuralNeuroTx.neuralFull = maxOf(vv.neuralNeuroTx.neuralFull, faceNeural * 0.6f)
            vv.eyesCompleteLock.eyesFullOut = maxOf(vv.eyesCompleteLock.eyesFullOut, eyeMotionLock)
            vv.fullAnatomy132.brainOut = maxOf(vv.fullAnatomy132.brainOut, visualCortexGap * 0.5f)
        } catch (_: Throwable) {}
    }
}
