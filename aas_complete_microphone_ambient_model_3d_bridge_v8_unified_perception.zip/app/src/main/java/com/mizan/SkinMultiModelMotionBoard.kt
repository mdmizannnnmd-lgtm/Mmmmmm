package com.mizan

/**
 * Complete skin · multiple models (Pose / Segment / OBB) · ambient system ·
 * movement · speed · waves controllers. RAW COMPLETE.
 */
class SkinMultiModelMotionBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Multi-model skin mixers
    @Volatile var poseOn = true
    @Volatile var segmentOn = true
    @Volatile var obbOn = true
    @Volatile var poseSkin = 0f
    @Volatile var segmentSkin = 0f
    @Volatile var obbSkin = 0f
    @Volatile var multiModelSkinOut = 0f

    // Skin ambient master
    @Volatile var skinAmbientOn = true
    @Volatile var skinAmbientThr = 0.22f
    @Volatile var skinAmbientLv = 0.88f
    @Volatile var skinAmbientOut = 0f

    // Movement controller
    @Volatile var moveOn = true
    @Volatile var moveThr = 0.25f
    @Volatile var moveLv = 0.85f
    @Volatile var moveOut = 0f

    // Speed controller
    @Volatile var speedOn = true
    @Volatile var speedThr = 0.25f
    @Volatile var speedLv = 0.85f
    @Volatile var speedOut = 0f

    // Waves controller
    @Volatile var waveOn = true
    @Volatile var waveThr = 0.25f
    @Volatile var waveLv = 0.85f
    @Volatile var waveOut = 0f

    // Linked outputs
    @Volatile var skinMove = 0f
    @Volatile var skinSpeed = 0f
    @Volatile var skinWave = 0f

    @Volatile var status = "SKIN·MULTI·MOVE/SPD/WAV idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, poseE: Float, segE: Float, obbE: Float, moveE: Float, speedE: Float, waveE: Float) {
        if (!enabled) {
            status = "SKIN·MULTI·MOVE OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        poseSkin = if (poseOn) poseE.coerceIn(0f, 1f) else 0f
        segmentSkin = if (segmentOn) segE.coerceIn(0f, 1f) else 0f
        obbSkin = if (obbOn) obbE.coerceIn(0f, 1f) else 0f
        multiModelSkinOut = maxOf(poseSkin, segmentSkin, obbSkin, e * 0.5f)

        skinAmbientOut = lane(skinAmbientOn, skinAmbientThr, skinAmbientLv, maxOf(e, multiModelSkinOut))
        moveOut = lane(moveOn, moveThr, moveLv, maxOf(moveE, e * 0.6f, multiModelSkinOut * 0.8f))
        speedOut = lane(speedOn, speedThr, speedLv, maxOf(speedE, e * 0.55f, multiModelSkinOut * 0.75f))
        waveOut = lane(waveOn, waveThr, waveLv, maxOf(waveE, e * 0.5f, multiModelSkinOut * 0.7f))

        skinMove = skinAmbientOut * moveOut
        skinSpeed = skinAmbientOut * speedOut
        skinWave = skinAmbientOut * waveOut

        status =
            "SKIN=${(skinAmbientOut*100).toInt()}% · POSE/SEG/OBB=${(poseSkin*100).toInt()}/${(segmentSkin*100).toInt()}/${(obbSkin*100).toInt()}% · " +
            "MOV=${(moveOut*100).toInt()} SPD=${(speedOut*100).toInt()} WAV=${(waveOut*100).toInt()} · " +
            "SKIN×M/S/W=${(skinMove*100).toInt()}/${(skinSpeed*100).toInt()}/${(skinWave*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        try {
            v.allBodySkinAnatomy.allSkinOut = maxOf(v.allBodySkinAnatomy.allSkinOut, skinAmbientOut)
            v.allBodySkinAnatomy.completeSkinCoverage = maxOf(v.allBodySkinAnatomy.completeSkinCoverage, multiModelSkinOut)
        } catch (_: Throwable) {}
        try {
            val h = v.body84FullHuman
            h.poseOn = poseOn; h.segmentOn = segmentOn; h.obbOn = obbOn
            h.moveOut = maxOf(h.moveOut, moveOut)
            h.speedOut = maxOf(h.speedOut, speedOut)
            h.waveOut = maxOf(h.waveOut, waveOut)
            h.outsideOut = maxOf(h.outsideOut, skinAmbientOut)
            h.atomOut = maxOf(h.atomOut, multiModelSkinOut)
        } catch (_: Throwable) {}
        try {
            v.skinAll.atmosphere = maxOf(v.skinAll.atmosphere, skinAmbientOut)
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, skinAmbientOut, multiModelSkinOut)
            v.anatomy3d.layerLevel[0] = maxOf(v.anatomy3d.layerLevel[0], skinAmbientOut)
            // motion feed into anatomy wave
            try {
                v.anatomy3d.wave = maxOf(v.anatomy3d.wave, waveOut)
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}
        try {
            v.skinAtomspare.atomSpareOut = maxOf(v.skinAtomspare.atomSpareOut, skinAmbientOut)
            v.skinAtomspare.skinOutsideOut = maxOf(v.skinAtomspare.skinOutsideOut, skinAmbientOut)
        } catch (_: Throwable) {}
        try {
            v.completeAtomProtect.atomOutsideOut = maxOf(v.completeAtomProtect.atomOutsideOut, skinAmbientOut)
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, skinMove, skinSpeed, skinWave)
        } catch (_: Throwable) {}
    }
}
