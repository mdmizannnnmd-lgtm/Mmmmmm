package com.mizan

import kotlin.math.sqrt
import java.util.ArrayDeque

/**
 * Experimental optical pulse estimator using the rear camera preview with the torch enabled.
 * It is not a medical device and does not replace a validated pulse oximeter.
 */
class HeartRateMonitor {
    private data class Sample(val timeMs: Long, val pulse: Float)

    @Volatile var enabled = false
    /** Signal gain, 0..2. */
    @Volatile var level = 1f
    /** Minimum AC signal RMS in normalized red-channel units. */
    @Volatile var threshold = 0.0015f
    @Volatile var rawComplete = true
    @Volatile var bpm = 0
    @Volatile var signalLevel = 0f
    @Volatile var flashAvailable = false

    private val samples = ArrayDeque<Sample>()
    private var lastSampleAt = 0L
    private var baseline = 0f
    private var filteredPulse = 0f
    private var smoothedBpm = 0f
    private var lastEstimateAt = 0L
    private var hasBaseline = false
    @Volatile private var fingerDetected = false
    @Volatile private var confidence = 0f

    @Synchronized
    fun reset() {
        samples.clear()
        lastSampleAt = 0L
        baseline = 0f
        filteredPulse = 0f
        smoothedBpm = 0f
        lastEstimateAt = 0L
        hasBaseline = false
        fingerDetected = false
        confidence = 0f
        bpm = 0
        signalLevel = 0f
    }

    /**
     * Reads a small center crop from an NV21 preview frame. The camera callback is only enabled
     * while heart-rate mode is active; no image frames are stored.
     */
    @Synchronized
    fun onPreviewFrame(data: ByteArray, width: Int, height: Int, nowMs: Long) {
        if (!enabled || width < 8 || height < 8) return
        val yPlaneSize = width * height
        if (data.size < yPlaneSize + yPlaneSize / 2) return

        var redSum = 0.0
        var greenSum = 0.0
        var luminanceSum = 0.0
        var count = 0
        val left = width / 4
        val right = width * 3 / 4
        val top = height / 4
        val bottom = height * 3 / 4
        for (y in top until bottom step 8) {
            for (x in left until right step 8) {
                val yIndex = y * width + x
                val uvIndex = yPlaneSize + (y shr 1) * width + (x and -2)
                if (uvIndex + 1 >= data.size) continue
                val luminance = data[yIndex].toInt() and 0xff
                // NV21 stores interleaved V,U chroma after the Y plane.
                val v = (data[uvIndex].toInt() and 0xff) - 128
                val u = (data[uvIndex + 1].toInt() and 0xff) - 128
                val red = (luminance + 1.402 * v).coerceIn(0.0, 255.0)
                val green = (luminance - 0.344136 * u - 0.714136 * v).coerceIn(0.0, 255.0)
                redSum += red
                greenSum += green
                luminanceSum += luminance
                count++
            }
        }
        if (count == 0) return

        val red = redSum / count
        val green = greenSum / count
        val luminance = luminanceSum / count
        // A red-dominant, covered lens is a useful basic check before interpreting a pulse.
        fingerDetected = luminance in 8.0..252.0 && red > green * 1.025
        if (!fingerDetected) {
            samples.clear()
            lastSampleAt = 0L
            hasBaseline = false
            filteredPulse = 0f
            signalLevel = 0f
            bpm = 0
            confidence = 0f
            return
        }

        // Sample at approximately 10 Hz; the camera may deliver preview frames much faster.
        if (nowMs - lastSampleAt < 95L) return
        lastSampleAt = nowMs

        val normalizedRed = (red / 255.0).toFloat()
        if (!hasBaseline) {
            baseline = normalizedRed
            hasBaseline = true
        } else {
            // Slow baseline follows exposure drift; the remaining variation is the pulse waveform.
            baseline += (normalizedRed - baseline) * 0.025f
        }
        val highPass = normalizedRed - baseline
        filteredPulse += (highPass - filteredPulse) * 0.35f
        samples.addLast(Sample(nowMs, filteredPulse))
        while (samples.isNotEmpty() && nowMs - samples.peekFirst().timeMs > 12_000L) {
            samples.removeFirst()
        }

        if (nowMs - lastEstimateAt < 450L) return
        lastEstimateAt = nowMs
        estimate(nowMs)
    }

    private fun estimate(nowMs: Long) {
        val recent = samples.filter { nowMs - it.timeMs <= 8_000L }
        if (recent.size < 60 || !fingerDetected) {
            bpm = 0
            signalLevel = 0f
            confidence = 0f
            return
        }

        val mean = recent.sumOf { it.pulse.toDouble() } / recent.size
        val centered = FloatArray(recent.size) { (recent[it].pulse - mean).toFloat() }
        var variance = 0.0
        for (v in centered) variance += v * v
        val rms = sqrt(variance / centered.size).toFloat() * level.coerceIn(0f, 2f)
        signalLevel = (rms * 10_000f).coerceIn(0f, 100f)
        if (rms < threshold.coerceIn(0f, 0.02f)) {
            bpm = 0
            confidence = 0f
            return
        }

        // Normalized autocorrelation over plausible adult pulse periods at ~10 samples/second.
        var bestLag = 0
        var bestCorrelation = -1f
        val maxLag = minOf(15, centered.size / 4)
        for (lag in 3..maxLag) {
            var cross = 0.0
            var energyA = 0.0
            var energyB = 0.0
            val end = centered.size - lag
            for (i in 0 until end) {
                val a = centered[i].toDouble()
                val b = centered[i + lag].toDouble()
                cross += a * b
                energyA += a * a
                energyB += b * b
            }
            val denom = sqrt(energyA * energyB)
            val corr = if (denom > 1e-12) (cross / denom).toFloat() else -1f
            if (corr > bestCorrelation) {
                bestCorrelation = corr
                bestLag = lag
            }
        }
        confidence = bestCorrelation.coerceIn(0f, 1f)
        if (bestLag == 0 || bestCorrelation < 0.20f) {
            bpm = 0
            return
        }

        val rate = (600f / bestLag).toInt().coerceIn(40, 180)
        if (rawComplete || smoothedBpm <= 0f) {
            smoothedBpm = rate.toFloat()
        } else {
            smoothedBpm += (rate - smoothedBpm) * 0.28f
        }
        bpm = if (rawComplete) rate else smoothedBpm.toInt().coerceIn(40, 180)
    }

    fun statusLine(): String {
        if (!enabled) return "HEART RATE idle · camera measurement off"
        val flash = if (flashAvailable) "torch ON" else "no torch · lower confidence"
        val mode = if (rawComplete) "RAW" else "filtered"
        val rate = if (bpm > 0) "$bpm BPM" else "— BPM"
        val state = when {
            !fingerDetected -> "cover rear camera + flash with fingertip"
            bpm == 0 && signalLevel < threshold.coerceIn(0f, 0.02f) * 10_000f ->
                "hold still; weak pulse signal"
            bpm == 0 -> "collecting / unstable pulse signal"
            else -> "confidence ${(confidence * 100).toInt()}%"
        }
        return "HEART RATE $rate · signal ${(signalLevel).toInt()}% / thr ${(threshold * 10_000f).toInt()}% · $mode · $flash · $state"
    }
}
