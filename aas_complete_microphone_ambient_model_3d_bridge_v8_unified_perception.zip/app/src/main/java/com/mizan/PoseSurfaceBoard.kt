package com.mizan

/** Pose surface aligns with [WholeBodyPose133] (COCO-WholeBody 133 keypoints). */

/**
 * Full 3D / RTM-style pose surface system (own-device path only).
 * Body pose surface + enemy pose surface + ambient with atomspare / wavespare.
 * Controls: threshold, movement, wave, speed, level, bipolar ±dB.
 */
class PoseSurfaceBoard {
    /** Expected whole-body keypoint count (COCO-WholeBody / DWPose). */
    @Volatile var poseKeypointCount = WholeBodyPose133.COUNT
    @Volatile var poseBodyN = 0
    @Volatile var poseFaceN = 0
    @Volatile var poseHandLN = 0
    @Volatile var poseHandRN = 0

    @Volatile var enabled = true

    // ── Body pose surface (fully model) ──────────────────────────────────
    @Volatile var bodyOn = true
    @Volatile var bodyThr = 0.40f
    @Volatile var bodyLv = 0.65f
    @Volatile var bodyMoveOn = true
    @Volatile var bodyMoveThr = 0.35f
    @Volatile var bodyMoveLv = 0.55f
    @Volatile var bodyWaveOn = true
    @Volatile var bodyWaveThr = 0.35f
    @Volatile var bodyWaveLv = 0.55f
    @Volatile var bodySpeedOn = true
    @Volatile var bodySpeedThr = 0.35f
    @Volatile var bodySpeedLv = 0.55f
    @Volatile var bodyAtmoOn = true
    @Volatile var bodyAtmoThr = 0.40f
    @Volatile var bodyAtmoLv = 0.50f
    @Volatile var bodyWaveSpareOn = true
    @Volatile var bodyWaveSpareThr = 0.40f
    @Volatile var bodyWaveSpareLv = 0.50f
    @Volatile var bodyBipOn = true
    @Volatile var bodyBipNeg = -40f
    @Volatile var bodyBipPos = 40f

    @Volatile var bodyActive = false
    @Volatile var bodyOut = 0f
    @Volatile var bodyMoveActive = false
    @Volatile var bodyMoveOut = 0f
    @Volatile var bodyWaveActive = false
    @Volatile var bodyWaveOut = 0f
    @Volatile var bodySpeedActive = false
    @Volatile var bodySpeedOut = 0f
    @Volatile var bodyAtmoActive = false
    @Volatile var bodyAtmoOut = 0f
    @Volatile var bodyWaveSpareActive = false
    @Volatile var bodyWaveSpareOut = 0f
    @Volatile var bodyBipHit = false

    // ── Enemy pose surface (fully model, this-phone path only) ───────────
    @Volatile var enemyOn = true
    @Volatile var enemyThr = 0.45f
    @Volatile var enemyLv = 0.60f
    @Volatile var enemyMoveOn = true
    @Volatile var enemyMoveThr = 0.40f
    @Volatile var enemyMoveLv = 0.50f
    @Volatile var enemyWaveOn = true
    @Volatile var enemyWaveThr = 0.40f
    @Volatile var enemyWaveLv = 0.50f
    @Volatile var enemySpeedOn = true
    @Volatile var enemySpeedThr = 0.40f
    @Volatile var enemySpeedLv = 0.50f
    @Volatile var enemyAtmoOn = true
    @Volatile var enemyAtmoThr = 0.42f
    @Volatile var enemyAtmoLv = 0.48f
    @Volatile var enemyWaveSpareOn = true
    @Volatile var enemyWaveSpareThr = 0.42f
    @Volatile var enemyWaveSpareLv = 0.48f
    @Volatile var enemyBipOn = true
    @Volatile var enemyBipNeg = -40f
    @Volatile var enemyBipPos = 40f

    @Volatile var enemyActive = false
    @Volatile var enemyOut = 0f
    @Volatile var enemyMoveActive = false
    @Volatile var enemyMoveOut = 0f
    @Volatile var enemyWaveActive = false
    @Volatile var enemyWaveOut = 0f
    @Volatile var enemySpeedActive = false
    @Volatile var enemySpeedOut = 0f
    @Volatile var enemyAtmoActive = false
    @Volatile var enemyAtmoOut = 0f
    @Volatile var enemyWaveSpareActive = false
    @Volatile var enemyWaveSpareOut = 0f
    @Volatile var enemyBipHit = false

    // ── Fully pose ambient ───────────────────────────────────────────────
    @Volatile var ambientOn = true
    @Volatile var ambientThr = 0.30f
    @Volatile var ambientLv = 0.55f
    @Volatile var ambientActive = false
    @Volatile var ambientOut = 0f

    private fun gate(on: Boolean, e: Float, thr: Float, lv: Float): Pair<Boolean, Float> {
        val t = thr.coerceIn(0.05f, 1f)
        val active = on && e >= t
        val out = if (active) {
            (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        return active to out
    }

    fun tick(energy: Float, db: Double = -80.0, detectionValid: Boolean = true) {
        val e = energy.coerceIn(0f, 1f)
        if (!enabled || !detectionValid) {
            bodyActive = false; bodyOut = 0f
            bodyMoveActive = false; bodyMoveOut = 0f
            bodyWaveActive = false; bodyWaveOut = 0f
            bodySpeedActive = false; bodySpeedOut = 0f
            bodyAtmoActive = false; bodyAtmoOut = 0f
            bodyWaveSpareActive = false; bodyWaveSpareOut = 0f
            bodyBipHit = false
            enemyActive = false; enemyOut = 0f
            enemyMoveActive = false; enemyMoveOut = 0f
            enemyWaveActive = false; enemyWaveOut = 0f
            enemySpeedActive = false; enemySpeedOut = 0f
            enemyAtmoActive = false; enemyAtmoOut = 0f
            enemyWaveSpareActive = false; enemyWaveSpareOut = 0f
            enemyBipHit = false
            ambientActive = false; ambientOut = 0f
            return
        }

        // Body bipolar
        val bLo = bodyBipNeg.coerceIn(-120f, 0f).toDouble()
        val bHi = bodyBipPos.coerceIn(0f, 120f).toDouble()
        bodyBipHit = bodyBipOn && (db <= bLo || db >= bHi)

        var (a, o) = gate(bodyOn, e, bodyThr, bodyLv)
        if (bodyBipHit) { a = true; o = maxOf(o, 0.25f) }
        bodyActive = a; bodyOut = o

        gate(bodyMoveOn, e, bodyMoveThr, bodyMoveLv).let { bodyMoveActive = it.first; bodyMoveOut = it.second }
        gate(bodyWaveOn, e, bodyWaveThr, bodyWaveLv).let { bodyWaveActive = it.first; bodyWaveOut = it.second }
        gate(bodySpeedOn, e, bodySpeedThr, bodySpeedLv).let { bodySpeedActive = it.first; bodySpeedOut = it.second }
        gate(bodyAtmoOn, e, bodyAtmoThr, bodyAtmoLv).let { bodyAtmoActive = it.first; bodyAtmoOut = it.second }
        gate(bodyWaveSpareOn, e, bodyWaveSpareThr, bodyWaveSpareLv).let {
            bodyWaveSpareActive = it.first; bodyWaveSpareOut = it.second
        }

        // Enemy bipolar
        val eLo = enemyBipNeg.coerceIn(-120f, 0f).toDouble()
        val eHi = enemyBipPos.coerceIn(0f, 120f).toDouble()
        enemyBipHit = enemyBipOn && (db <= eLo || db >= eHi)

        var (ea, eo) = gate(enemyOn, e, enemyThr, enemyLv)
        if (enemyBipHit) { ea = true; eo = maxOf(eo, 0.22f) }
        enemyActive = ea; enemyOut = eo

        gate(enemyMoveOn, e, enemyMoveThr, enemyMoveLv).let { enemyMoveActive = it.first; enemyMoveOut = it.second }
        gate(enemyWaveOn, e, enemyWaveThr, enemyWaveLv).let { enemyWaveActive = it.first; enemyWaveOut = it.second }
        gate(enemySpeedOn, e, enemySpeedThr, enemySpeedLv).let { enemySpeedActive = it.first; enemySpeedOut = it.second }
        gate(enemyAtmoOn, e, enemyAtmoThr, enemyAtmoLv).let { enemyAtmoActive = it.first; enemyAtmoOut = it.second }
        gate(enemyWaveSpareOn, e, enemyWaveSpareThr, enemyWaveSpareLv).let {
            enemyWaveSpareActive = it.first; enemyWaveSpareOut = it.second
        }

        // Fully pose ambient
        gate(ambientOn, e, ambientThr, ambientLv).let { ambientActive = it.first; ambientOut = it.second }
    }

    /** Combined dampen for screen / draw path */
    fun dampen(): Float {
        if (!enabled) return 0f
        var d = 0f
        if (bodyActive) d = maxOf(d, 0.30f + bodyOut * 0.40f)
        if (bodyMoveActive) d = maxOf(d, 0.22f + bodyMoveOut * 0.28f)
        if (bodyWaveActive) d = maxOf(d, 0.20f + bodyWaveOut * 0.26f)
        if (bodySpeedActive) d = maxOf(d, 0.20f + bodySpeedOut * 0.26f)
        if (bodyAtmoActive) d = maxOf(d, 0.24f + bodyAtmoOut * 0.30f)
        if (bodyWaveSpareActive) d = maxOf(d, 0.18f + bodyWaveSpareOut * 0.24f)
        if (enemyActive) d = maxOf(d, 0.32f + enemyOut * 0.38f)
        if (enemyMoveActive) d = maxOf(d, 0.24f + enemyMoveOut * 0.28f)
        if (enemyWaveActive) d = maxOf(d, 0.22f + enemyWaveOut * 0.26f)
        if (enemySpeedActive) d = maxOf(d, 0.22f + enemySpeedOut * 0.26f)
        if (enemyAtmoActive) d = maxOf(d, 0.26f + enemyAtmoOut * 0.30f)
        if (enemyWaveSpareActive) d = maxOf(d, 0.20f + enemyWaveSpareOut * 0.24f)
        if (ambientActive) d = maxOf(d, 0.16f + ambientOut * 0.22f)
        return d.coerceIn(0f, 1f)
    }

    fun statusLine(): String {
        if (!enabled) return "POSE-3D off"
        val tags = buildList {
            if (bodyActive) add("BODY")
            if (bodyMoveActive) add("B-MOV")
            if (bodyWaveActive) add("B-WAV")
            if (bodySpeedActive) add("B-SPD")
            if (bodyAtmoActive) add("B-ATMO")
            if (bodyWaveSpareActive) add("B-WSP")
            if (bodyBipHit) add("B-BIP")
            if (enemyActive) add("ENEMY")
            if (enemyMoveActive) add("E-MOV")
            if (enemyWaveActive) add("E-WAV")
            if (enemySpeedActive) add("E-SPD")
            if (enemyAtmoActive) add("E-ATMO")
            if (enemyWaveSpareActive) add("E-WSP")
            if (enemyBipHit) add("E-BIP")
            if (ambientActive) add("AMB")
            if (isEmpty()) add("idle")
        }.joinToString("+")
        return "POSE-3D · $tags · body=${(bodyOut*100).toInt()}% enemy=${(enemyOut*100).toInt()}% " +
            "amb=${(ambientOut*100).toInt()}% · damp=${(dampen()*100).toInt()}%"
    }
    fun apply(v: VisualShieldView?) {
        val vv = v ?: return
        try {
            val o = try { dampen() } catch (_: Throwable) { 0f }
            vv.body84FullHuman.modelMixOut = maxOf(vv.body84FullHuman.modelMixOut, o * 0.3f)
        } catch (_: Throwable) {}
    }

}
