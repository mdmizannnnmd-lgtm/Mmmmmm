package com.mizan

/**
 * Procedural human anatomy teaching scaffold: OUTSIDE (skin, face, muscle) and INSIDE (skeleton, organs,
 * vessels / nerves, brain). The part list is a stylized subset, not a complete medical atlas. The eye inventory is
 * expanded bilaterally, but every part is still rendered as an ellipsoid rather than a segmented surface mesh.
 * Every part is one ellipsoid in body units (y up, +z toward the viewer, head top ≈ 1.75, feet ≈ −0.95),
 * the same units the ARCore GPU body surface uses. Rendered by [Soft3DRenderer] (Canvas) and, for the non-skin
 * layers, by [BodySurfaceRenderer3D] (OpenGL over the ARCore camera).
 *
 * It is a stylised teaching / visual model, not a medical or measured model of anyone's body.
 * Left/right: "L" is on the model's −x side, "R" on +x. Genital / pelvic shells are stylised teaching shapes only.
 */
object AnatomyModel3D {

    const val SKIN = 0
    const val MUSCLE = 1
    const val SKELETON = 2
    const val ORGAN = 3
    const val VESSEL = 4
    const val BRAIN = 5
    const val FACE = 6
    const val LAYER_COUNT = 7
    val LAYER_NAMES = arrayOf("Skin", "Muscle", "Skeleton", "Organs", "Vessels · nerves", "Brain", "Face")

    /** Outside layers (skin, muscle, face) follow the body mixer's OUTSIDE path, the rest its INSIDE path. */
    fun isInside(layer: Int): Boolean = layer in SKELETON..BRAIN

    class Part(
        val name: String,
        val layer: Int,
        val x: Float, val y: Float, val z: Float,
        val sx: Float, val sy: Float, val sz: Float,
        val rotZ: Float,
        val color: Int,
        /** Body84 channel this part listens to (−1 = none). */
        val channel: Int = -1,
        /** −1 left, +1 right, 0 midline. */
        val side: Int = 0,
        /** Brain lobe kind (see [BrainModel]) or −1. */
        val lobe: Int = -1
    )

    val parts: List<Part> by lazy { build() }

    private fun build(): List<Part> {
        val out = ArrayList<Part>(640)
        fun add(n: String, l: Int, x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float,
                rot: Float, c: Long, side: Int = 0, ch: Int = -1, lobe: Int = -1) {
            out.add(Part(n, l, x, y, z, sx, sy, sz, rot, c.toInt(), ch, side, lobe))
        }
        // mirrored pair: "L" is on the model's −x side
        fun pair(n: String, l: Int, x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float,
                 rot: Float, c: Long, ch: Int = -1) {
            add("$n L", l, -x, y, z, sx, sy, sz, -rot, c, -1, ch)
            add("$n R", l, x, y, z, sx, sy, sz, rot, c, 1, ch)
        }

        // ── SKIN (outside surface) ───────────────────────────────────────────
        add("Head", SKIN, 0f, 1.51f, 0f, 0.17f, 0.22f, 0.15f, 0f, 0xFF77E5FF, 0, 0)

        // ── HAIR (outside · L/R · front/back · crown) ───────────────────────
        add("Hair crown", SKIN, 0f, 1.68f, -0.02f, 0.16f, 0.08f, 0.14f, 0f, 0xFF5D4037, 0, 0)
        add("Hair front", SKIN, 0f, 1.62f, 0.10f, 0.14f, 0.05f, 0.06f, 0f, 0xFF6D4C41, 0, 0)
        add("Hair back", SKIN, 0f, 1.58f, -0.12f, 0.15f, 0.10f, 0.08f, 0f, 0xFF4E342E, 0, 0)
        pair("Hair side", SKIN, 0.14f, 1.55f, 0.02f, 0.05f, 0.12f, 0.08f, 0f, 0xFF5D4037, 0)
        // Face skin plates (complete surface · not single)
        add("Face skin center", FACE, 0f, 1.48f, 0.12f, 0.10f, 0.12f, 0.04f, 0f, 0xFFFFCCBC)
        add("Face skin forehead", FACE, 0f, 1.62f, 0.10f, 0.12f, 0.05f, 0.04f, 0f, 0xFFFFCCBC)
        pair("Face skin temple", FACE, 0.12f, 1.55f, 0.08f, 0.04f, 0.06f, 0.04f, 0f, 0xFFFFAB91)
        pair("Face skin cheek", FACE, 0.09f, 1.48f, 0.10f, 0.05f, 0.07f, 0.04f, 0f, 0xFFFFAB91)
        add("Face skin chin", FACE, 0f, 1.36f, 0.11f, 0.06f, 0.04f, 0.04f, 0f, 0xFFFFCCBC)
        // Eye skin periocular (L/R already via pair)
        pair("Eye skin out", FACE, 0.062f, 1.555f, 0.12f, 0.04f, 0.035f, 0.02f, 0f, 0xFFFFCCBC)
        pair("Eye skin in", FACE, 0.062f, 1.555f, 0.108f, 0.028f, 0.028f, 0.018f, 0f, 0xFFEF9A9A)
        // Neck complete (front already; add back · sides)
        add("Neck back", SKIN, 0f, 1.25f, -0.06f, 0.08f, 0.11f, 0.05f, 0f, 0xFF66D9EE, 0, 1)
        pair("Neck side", SKIN, 0.07f, 1.25f, 0f, 0.04f, 0.11f, 0.05f, 0f, 0xFF4DD0E1, 1)
        // Torso center / back skin
        add("Back skin", SKIN, 0f, 0.84f, -0.12f, 0.28f, 0.40f, 0.08f, 0f, 0xFF29B6F6, 0, 2)
        add("Chest center", SKIN, 0f, 0.90f, 0.10f, 0.12f, 0.20f, 0.06f, 0f, 0xFF4FC3F7, 0, 2)

        add("Neck", SKIN, 0f, 1.25f, 0f, 0.09f, 0.12f, 0.10f, 0f, 0xFF66D9EE, 0, 1)
        add("Chest", SKIN, 0f, 0.84f, 0f, 0.31f, 0.42f, 0.18f, 0f, 0xFF29B6F6, 0, 2)
        pair("Breast", SKIN, 0.12f, 0.95f, 0.12f, 0.09f, 0.09f, 0.08f, 0f, 0xFFFFAB91, 2)
        add("Waist", SKIN, 0f, 0.28f, 0.02f, 0.18f, 0.10f, 0.12f, 0f, 0xFF26C6DA, 0, 3)
        pair("Wrist", SKIN, 0.55f, 0.05f, 0f, 0.05f, 0.04f, 0.04f, 4f, 0xFF7986CB, 8)
        pair("Palm", SKIN, 0.56f, -0.02f, 0.01f, 0.05f, 0.06f, 0.03f, 4f, 0xFF9FA8DA, 8)
        add("Abdomen", SKIN, 0f, 0.37f, 0f, 0.24f, 0.27f, 0.15f, 0f, 0xFF26C6DA, 0, 3)
        add("Pelvis skin", SKIN, 0f, 0.14f, 0f, 0.25f, 0.13f, 0.14f, 0f, 0xFF26C6DA, 0, 3)
        add("Belly skin", SKIN, 0f, 0.42f, 0.06f, 0.20f, 0.16f, 0.12f, 0f, 0xFF26C6DA, 0, 3)
        add("Neck front", SKIN, 0f, 1.22f, 0.06f, 0.07f, 0.10f, 0.06f, 0f, 0xFF66D9EE, 0, 1)
        pair("Ass cheek", SKIN, 0.09f, 0.10f, -0.14f, 0.11f, 0.12f, 0.09f, 0f, 0xFF26C6DA, 3)
        pair("Hip", SKIN, 0.20f, 0.18f, 0.02f, 0.10f, 0.12f, 0.10f, 0f, 0xFF29B6F6, 3)
        pair("Upper leg", SKIN, 0.16f, -0.05f, 0.02f, 0.14f, 0.28f, 0.13f, 2f, 0xFF42A5F5, 10)
        pair("Lower leg", SKIN, 0.16f, -0.55f, 0.01f, 0.10f, 0.28f, 0.09f, 2f, 0xFF26A69A, 12)
        // Stylised genital shells (teaching model — not anatomical detail)
        add("Dick shell", SKIN, 0f, 0.02f, 0.12f, 0.035f, 0.08f, 0.04f, 0f, 0xFF4FC3F7, 0, 3)
        add("Pussy shell", SKIN, 0f, 0.04f, 0.10f, 0.05f, 0.04f, 0.03f, 0f, 0xFF81D4FA, 0, 3)
        pair("Shoulder", SKIN, 0.38f, 1.02f, 0f, 0.12f, 0.17f, 0.12f, 8f, 0xFFAB47BC, 4)
        pair("Upper arm", SKIN, 0.48f, 0.70f, 0f, 0.105f, 0.29f, 0.10f, 16f, 0xFF7E57C2, 6)
        pair("Elbow", SKIN, 0.51f, 0.43f, 0f, 0.085f, 0.06f, 0.085f, 12f, 0xFF7E57C2)
        pair("Forearm", SKIN, 0.53f, 0.26f, 0f, 0.09f, 0.25f, 0.09f, 10f, 0xFF5C6BC0, 8)
        pair("Hand", SKIN, 0.56f, -0.05f, 0f, 0.06f, 0.09f, 0.04f, 6f, 0xFF7986CB)
        pair("Thigh", SKIN, 0.16f, -0.08f, 0f, 0.15f, 0.35f, 0.14f, 2f, 0xFF42A5F5, 10)
        pair("Knee", SKIN, 0.16f, -0.41f, 0.01f, 0.10f, 0.06f, 0.10f, 0f, 0xFF42A5F5)
        pair("Shin", SKIN, 0.16f, -0.51f, 0f, 0.105f, 0.32f, 0.10f, 2f, 0xFF26A69A, 12)
        pair("Ankle", SKIN, 0.16f, -0.80f, 0f, 0.06f, 0.05f, 0.06f, 0f, 0xFF26A69A)
        pair("Foot", SKIN, 0.16f, -0.83f, 0.045f, 0.15f, 0.09f, 0.22f, 0f, 0xFF80CBC4, 14)
        // fingers (skin) — thumb + 4 fingers per hand, toes — hallux + 4 toes per foot
        val fingerOff = floatArrayOf(0.045f, 0.025f, 0.008f, -0.009f, -0.025f)
        val fingerLen = floatArrayOf(0.055f, 0.075f, 0.085f, 0.078f, 0.060f)
        val fingerNames = arrayOf("Thumb", "Index", "Middle", "Ring", "Little")
        for (f in 0 until 5) {
            pair("${fingerNames[f]} finger", SKIN, 0.56f + fingerOff[f], -0.13f - fingerLen[f] * 0.2f, 0.005f,
                0.011f, fingerLen[f] * 0.5f, 0.011f, 4f, 0xFF9FA8DA)
        }
        val toeOff = floatArrayOf(-0.04f, -0.018f, 0.002f, 0.020f, 0.036f)
        val toeLen = floatArrayOf(0.085f, 0.060f, 0.055f, 0.050f, 0.042f)
        for (t in 0 until 5) {
            pair("Toe ${t + 1}", SKIN, 0.16f + toeOff[t], -0.865f, 0.20f + toeLen[t] * 0.35f,
                0.014f, 0.016f, toeLen[t] * 0.5f, 0f, 0xFFA5D6A7)
        }

        // ── FACE (outside) ───────────────────────────────────────────────────
        add("Forehead", FACE, 0f, 1.65f, 0.11f, 0.11f, 0.055f, 0.045f, 0f, 0xFF80DEEA)
        pair("Temple", FACE, 0.14f, 1.58f, 0.06f, 0.03f, 0.06f, 0.06f, 0f, 0xFF80DEEA)
        pair("Brow", FACE, 0.065f, 1.595f, 0.135f, 0.06f, 0.014f, 0.025f, 6f, 0xFF455A64)
        pair("Upper eyelid", FACE, 0.062f, 1.572f, 0.13f, 0.034f, 0.010f, 0.022f, 0f, 0xFFB2EBF2)
        pair("Lower eyelid", FACE, 0.062f, 1.538f, 0.13f, 0.032f, 0.008f, 0.020f, 0f, 0xFFB2EBF2)
        pair("Eyeball", FACE, 0.062f, 1.555f, 0.115f, 0.026f, 0.026f, 0.026f, 0f, 0xFFF5F5F5)
        pair("Iris", FACE, 0.062f, 1.555f, 0.137f, 0.013f, 0.013f, 0.008f, 0f, 0xFF29B6F6)
        pair("Pupil", FACE, 0.062f, 1.555f, 0.145f, 0.006f, 0.006f, 0.005f, 0f, 0xFF101010)
        pair("Eyelashes", FACE, 0.062f, 1.578f, 0.14f, 0.03f, 0.004f, 0.01f, 0f, 0xFF263238)
        // ── complete EYE BALLS (L / R): cornea · lens · retina · eye muscles · optic nerve — gaze follows the centroid ──
        val chEyeL = Body84Channels.NAMES.indexOf("LeftEye")
        val chEyeR = Body84Channels.NAMES.indexOf("RightEye")
        fun eyePair(n: String, l: Int, x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, rot: Float, c: Long) {
            add("$n L", l, -x, y, z, sx, sy, sz, -rot, c, -1, chEyeL)
            add("$n R", l, x, y, z, sx, sy, sz, rot, c, 1, chEyeR)
        }
        eyePair("Cornea", FACE, 0.062f, 1.555f, 0.141f, 0.016f, 0.016f, 0.009f, 0f, 0xFFE1F5FE)
        eyePair("Caruncle", FACE, 0.036f, 1.553f, 0.128f, 0.005f, 0.006f, 0.006f, 0f, 0xFFF48FB1)
        eyePair("Sclera vessel", FACE, 0.082f, 1.560f, 0.128f, 0.009f, 0.0015f, 0.004f, 18f, 0xFFEF9A9A)
        eyePair("Lens", ORGAN, 0.062f, 1.555f, 0.126f, 0.011f, 0.011f, 0.006f, 0f, 0xFFE1F5FE)
        eyePair("Vitreous body", ORGAN, 0.062f, 1.555f, 0.108f, 0.019f, 0.019f, 0.014f, 0f, 0xFFB3E5FC)
        eyePair("Retina", ORGAN, 0.062f, 1.555f, 0.092f, 0.021f, 0.021f, 0.005f, 0f, 0xFFFF8A65)
        eyePair("Superior rectus", MUSCLE, 0.062f, 1.578f, 0.100f, 0.012f, 0.005f, 0.024f, 0f, 0xFFD32F2F)
        eyePair("Inferior rectus", MUSCLE, 0.062f, 1.532f, 0.100f, 0.012f, 0.005f, 0.024f, 0f, 0xFFD32F2F)
        eyePair("Medial rectus", MUSCLE, 0.038f, 1.555f, 0.100f, 0.005f, 0.012f, 0.024f, 0f, 0xFFE53935)
        eyePair("Lateral rectus", MUSCLE, 0.086f, 1.555f, 0.100f, 0.005f, 0.012f, 0.024f, 0f, 0xFFE53935)
        eyePair("Superior oblique", MUSCLE, 0.048f, 1.580f, 0.108f, 0.012f, 0.004f, 0.016f, -20f, 0xFFC62828)
        eyePair("Inferior oblique", MUSCLE, 0.075f, 1.534f, 0.108f, 0.012f, 0.004f, 0.016f, 20f, 0xFFC62828)
        // Eye globe wall and surface. The transparent / thin layers are schematic ellipsoids in this renderer.
        eyePair("Sclera", FACE, 0.062f, 1.555f, 0.118f, 0.025f, 0.025f, 0.022f, 0f, 0xFFFAFAFA)
        eyePair("Choroid", ORGAN, 0.062f, 1.555f, 0.100f, 0.020f, 0.020f, 0.008f, 0f, 0xFF8D6E63)
        eyePair("Conjunctiva", FACE, 0.062f, 1.555f, 0.132f, 0.028f, 0.022f, 0.006f, 0f, 0xFFE8F5E9)
        eyePair("Medial canthus", FACE, 0.038f, 1.553f, 0.125f, 0.008f, 0.010f, 0.008f, 0f, 0xFFFFCCBC)
        eyePair("Lateral canthus", FACE, 0.088f, 1.553f, 0.125f, 0.008f, 0.010f, 0.008f, 0f, 0xFFFFCCBC)
        eyePair("Lacrimal gland", ORGAN, 0.095f, 1.590f, 0.100f, 0.018f, 0.012f, 0.012f, 0f, 0xFFF8BBD0)
        eyePair("Lacrimal sac", ORGAN, 0.030f, 1.545f, 0.110f, 0.008f, 0.014f, 0.008f, 0f, 0xFFF48FB1)
        eyePair("Punctum upper", FACE, 0.034f, 1.558f, 0.132f, 0.003f, 0.003f, 0.003f, 0f, 0xFFE91E63)
        eyePair("Punctum lower", FACE, 0.034f, 1.548f, 0.132f, 0.003f, 0.003f, 0.003f, 0f, 0xFFE91E63)
        eyePair("Tarsal plate", FACE, 0.062f, 1.565f, 0.125f, 0.030f, 0.012f, 0.008f, 0f, 0xFFBCAAA4)
        eyePair("Levator lid", MUSCLE, 0.062f, 1.590f, 0.115f, 0.020f, 0.008f, 0.018f, 0f, 0xFFEF5350)
        eyePair("Orbicularis oculi", MUSCLE, 0.062f, 1.555f, 0.135f, 0.040f, 0.030f, 0.010f, 0f, 0xFFE57373)
        eyePair("Eyebrow skin", FACE, 0.065f, 1.610f, 0.120f, 0.055f, 0.018f, 0.020f, 0f, 0xFF6D4C41)
        // Corneal epithelium → Bowman's layer → stroma → Descemet membrane → endothelium.
        eyePair("Tear film", FACE, 0.062f, 1.555f, 0.151f, 0.014f, 0.014f, 0.0015f, 0f, 0x99B3E5FC)
        eyePair("Corneal epithelium", FACE, 0.062f, 1.555f, 0.149f, 0.014f, 0.014f, 0.0015f, 0f, 0xFFD7F4FF)
        eyePair("Bowman layer", FACE, 0.062f, 1.555f, 0.147f, 0.014f, 0.014f, 0.0012f, 0f, 0xFFB3E5FC)
        eyePair("Corneal stroma", ORGAN, 0.062f, 1.555f, 0.143f, 0.014f, 0.014f, 0.0035f, 0f, 0xFFB2DFEA)
        eyePair("Descemet membrane", ORGAN, 0.062f, 1.555f, 0.139f, 0.013f, 0.013f, 0.0012f, 0f, 0xFF80DEEA)
        eyePair("Corneal endothelium", ORGAN, 0.062f, 1.555f, 0.137f, 0.013f, 0.013f, 0.0012f, 0f, 0xFF4FC3F7)
        eyePair("Anterior chamber", ORGAN, 0.062f, 1.555f, 0.132f, 0.012f, 0.012f, 0.004f, 0f, 0x8851D5E8)
        eyePair("Posterior chamber", ORGAN, 0.062f, 1.555f, 0.128f, 0.009f, 0.009f, 0.003f, 0f, 0x7751D5E8)
        // Iris / pupil control and lens support.
        eyePair("Iris sphincter", MUSCLE, 0.062f, 1.555f, 0.139f, 0.009f, 0.009f, 0.0015f, 0f, 0xFF1565C0)
        eyePair("Iris dilator", MUSCLE, 0.062f, 1.555f, 0.137f, 0.011f, 0.011f, 0.0012f, 0f, 0xFF42A5F5)
        eyePair("Ciliary body", ORGAN, 0.062f, 1.555f, 0.119f, 0.016f, 0.016f, 0.004f, 0f, 0xFF8D6E63)
        eyePair("Ciliary process superior", ORGAN, 0.062f, 1.568f, 0.122f, 0.002f, 0.006f, 0.002f, 0f, 0xFFA1887F)
        eyePair("Ciliary process inferior", ORGAN, 0.062f, 1.542f, 0.122f, 0.002f, 0.006f, 0.002f, 0f, 0xFFA1887F)
        eyePair("Lens capsule", ORGAN, 0.062f, 1.555f, 0.126f, 0.012f, 0.012f, 0.007f, 0f, 0x99E1F5FE)
        eyePair("Lens cortex", ORGAN, 0.062f, 1.555f, 0.126f, 0.009f, 0.009f, 0.005f, 0f, 0xFFB3E5FC)
        eyePair("Lens nucleus", ORGAN, 0.062f, 1.555f, 0.126f, 0.005f, 0.005f, 0.0035f, 0f, 0xFFE1F5FE)
        eyePair("Zonular fibers superior", ORGAN, 0.062f, 1.568f, 0.121f, 0.0015f, 0.006f, 0.0015f, 0f, 0xFFFFF9C4)
        eyePair("Zonular fibers inferior", ORGAN, 0.062f, 1.542f, 0.121f, 0.0015f, 0.006f, 0.0015f, 0f, 0xFFFFF9C4)
        eyePair("Zonular fibers medial", ORGAN, 0.050f, 1.555f, 0.121f, 0.006f, 0.0015f, 0.0015f, 0f, 0xFFFFF9C4)
        eyePair("Zonular fibers lateral", ORGAN, 0.074f, 1.555f, 0.121f, 0.006f, 0.0015f, 0.0015f, 0f, 0xFFFFF9C4)
        // Posterior retina detail: neural retina, pigment epithelium, macula / fovea, disc and vessels.
        eyePair("Neural retina", ORGAN, 0.062f, 1.555f, 0.095f, 0.020f, 0.020f, 0.003f, 0f, 0xFFFF8A65)
        eyePair("Retinal pigment epithelium", ORGAN, 0.062f, 1.555f, 0.091f, 0.020f, 0.020f, 0.002f, 0f, 0xFF6D4C41)
        eyePair("Macula", ORGAN, 0.062f, 1.555f, 0.089f, 0.006f, 0.006f, 0.0015f, 0f, 0xFFFFB74D)
        eyePair("Fovea centralis", ORGAN, 0.062f, 1.555f, 0.087f, 0.002f, 0.002f, 0.001f, 0f, 0xFFFFF176)
        eyePair("Optic disc", ORGAN, 0.055f, 1.555f, 0.088f, 0.004f, 0.006f, 0.002f, 0f, 0xFFFFF59D)
        eyePair("Central retinal artery", VESSEL, 0.062f, 1.555f, 0.086f, 0.0015f, 0.016f, 0.0015f, 0f, 0xFFFF1744)
        eyePair("Central retinal vein", VESSEL, 0.062f, 1.555f, 0.084f, 0.0015f, 0.015f, 0.0015f, 0f, 0xFF2979FF)
        eyePair("Retinal artery branch upper", VESSEL, 0.055f, 1.563f, 0.087f, 0.006f, 0.0015f, 0.0015f, -24f, 0xFFFF1744)
        eyePair("Retinal artery branch lower", VESSEL, 0.055f, 1.547f, 0.087f, 0.006f, 0.0015f, 0.0015f, 24f, 0xFFFF1744)
        eyePair("Retinal vein branch upper", VESSEL, 0.068f, 1.563f, 0.085f, 0.006f, 0.0015f, 0.0015f, 24f, 0xFF2979FF)
        eyePair("Retinal vein branch lower", VESSEL, 0.068f, 1.547f, 0.085f, 0.006f, 0.0015f, 0.0015f, -24f, 0xFF2979FF)
        // Bilateral optic nerves are split into visible teaching segments; the chiasm is in BrainModel.
        eyePair("Optic nerve head", VESSEL, 0.062f, 1.555f, 0.082f, 0.006f, 0.006f, 0.006f, 0f, 0xFFFFEB3B)
        eyePair("Optic nerve intraorbital", VESSEL, 0.045f, 1.555f, 0.055f, 0.006f, 0.006f, 0.027f, 0f, 0xFFFFEB3B)
        eyePair("Optic nerve optic canal", VESSEL, 0.026f, 1.555f, 0.021f, 0.005f, 0.005f, 0.015f, 0f, 0xFFFFEB3B)
        eyePair("Optic nerve intracranial", VESSEL, 0.010f, 1.555f, -0.006f, 0.004f, 0.004f, 0.018f, 0f, 0xFFFFEB3B)
        // Surface / lid structures and the tear drainage route, all separately named for both sides.
        eyePair("Bulbar conjunctiva", FACE, 0.062f, 1.555f, 0.134f, 0.027f, 0.021f, 0.003f, 0f, 0x88E8F5E9)
        eyePair("Palpebral conjunctiva upper", FACE, 0.062f, 1.565f, 0.129f, 0.027f, 0.006f, 0.002f, 0f, 0xFFEF9A9A)
        eyePair("Palpebral conjunctiva lower", FACE, 0.062f, 1.545f, 0.129f, 0.027f, 0.006f, 0.002f, 0f, 0xFFEF9A9A)
        eyePair("Upper lid skin", FACE, 0.062f, 1.574f, 0.134f, 0.033f, 0.008f, 0.009f, 0f, 0xFFFFCCBC)
        eyePair("Lower lid skin", FACE, 0.062f, 1.536f, 0.134f, 0.033f, 0.007f, 0.009f, 0f, 0xFFFFCCBC)
        eyePair("Upper lid margin", FACE, 0.062f, 1.566f, 0.143f, 0.030f, 0.002f, 0.002f, 0f, 0xFFFFAB91)
        eyePair("Lower lid margin", FACE, 0.062f, 1.544f, 0.143f, 0.030f, 0.002f, 0.002f, 0f, 0xFFFFAB91)
        eyePair("Plica semilunaris", FACE, 0.040f, 1.553f, 0.130f, 0.003f, 0.009f, 0.004f, 0f, 0xFFF48FB1)
        eyePair("Lacrimal canaliculus upper", ORGAN, 0.044f, 1.558f, 0.119f, 0.010f, 0.002f, 0.002f, 12f, 0xFFF48FB1)
        eyePair("Lacrimal canaliculus lower", ORGAN, 0.044f, 1.548f, 0.119f, 0.010f, 0.002f, 0.002f, -12f, 0xFFF48FB1)
        eyePair("Nasolacrimal duct", ORGAN, 0.030f, 1.490f, 0.095f, 0.004f, 0.045f, 0.004f, 0f, 0xFFF48FB1)
        eyePair("Lacrimal gland duct 1", ORGAN, 0.084f, 1.578f, 0.107f, 0.009f, 0.002f, 0.002f, -18f, 0xFFF8BBD0)
        eyePair("Lacrimal gland duct 2", ORGAN, 0.094f, 1.575f, 0.107f, 0.009f, 0.002f, 0.002f, -8f, 0xFFF8BBD0)
        eyePair("Lacrimal gland duct 3", ORGAN, 0.103f, 1.572f, 0.107f, 0.009f, 0.002f, 0.002f, 8f, 0xFFF8BBD0)
        eyePair("Accessory lacrimal gland Krause upper", ORGAN, 0.062f, 1.578f, 0.105f, 0.008f, 0.004f, 0.004f, 0f, 0xFFF8BBD0)
        eyePair("Accessory lacrimal gland Krause lower", ORGAN, 0.062f, 1.532f, 0.105f, 0.008f, 0.004f, 0.004f, 0f, 0xFFF8BBD0)
        eyePair("Accessory lacrimal gland Wolfring upper", ORGAN, 0.062f, 1.567f, 0.118f, 0.009f, 0.003f, 0.003f, 0f, 0xFFF8BBD0)
        eyePair("Accessory lacrimal gland Wolfring lower", ORGAN, 0.062f, 1.543f, 0.118f, 0.009f, 0.003f, 0.003f, 0f, 0xFFF8BBD0)
        // Meibomian (tarsal) glands are multiple vertical glands in each upper / lower lid.
        val meibomianX = floatArrayOf(0.041f, 0.052f, 0.062f, 0.072f, 0.083f)
        for (i in meibomianX.indices) {
            eyePair("Meibomian gland upper ${i + 1}", ORGAN, meibomianX[i], 1.566f, 0.126f,
                0.0018f, 0.006f, 0.0018f, 0f, 0xFFFFD180)
            eyePair("Meibomian gland lower ${i + 1}", ORGAN, meibomianX[i], 1.544f, 0.126f,
                0.0018f, 0.006f, 0.0018f, 0f, 0xFFFFD180)
        }
        eyePair("Levator palpebrae superioris", MUSCLE, 0.062f, 1.590f, 0.110f, 0.012f, 0.020f, 0.006f, 0f, 0xFFEF5350)
        eyePair("Superior tarsal muscle", MUSCLE, 0.062f, 1.579f, 0.115f, 0.020f, 0.004f, 0.004f, 0f, 0xFFE57373)
        // ── complete SKIN sub-system (integumentary) — not single mesh ──
        // Head already has face / eye / hair skins. Body surface L/R + zones:
        pair("Scalp skin", FACE, 0.05f, 1.68f, 0.08f, 0.06f, 0.04f, 0.05f, 0f, 0xFFFFCCBC)
        add("Neck skin front", FACE, 0f, 1.42f, 0.10f, 0.08f, 0.08f, 0.04f, 0f, 0xFFFFCCBC)
        pair("Neck skin side", FACE, 0.07f, 1.42f, 0.06f, 0.04f, 0.08f, 0.04f, 0f, 0xFFFFAB91)
        add("Chest skin", FACE, 0f, 1.22f, 0.12f, 0.16f, 0.12f, 0.04f, 0f, 0xFFFFCCBC)
        pair("Breast skin", FACE, 0.08f, 1.18f, 0.12f, 0.07f, 0.07f, 0.04f, 0f, 0xFFFFAB91)
        add("Abdomen skin", FACE, 0f, 0.95f, 0.12f, 0.14f, 0.14f, 0.04f, 0f, 0xFFFFCCBC)
        pair("Flank skin", FACE, 0.12f, 0.95f, 0.06f, 0.05f, 0.12f, 0.04f, 0f, 0xFFFFAB91)
        pair("Shoulder skin", FACE, 0.18f, 1.35f, 0.08f, 0.08f, 0.06f, 0.04f, 0f, 0xFFFFCCBC)
        pair("Upper arm skin", FACE, 0.22f, 1.15f, 0.06f, 0.05f, 0.12f, 0.04f, 0f, 0xFFFFCCBC)
        pair("Forearm skin", FACE, 0.25f, 0.90f, 0.05f, 0.04f, 0.12f, 0.035f, 0f, 0xFFFFAB91)
        pair("Hand skin", FACE, 0.28f, 0.70f, 0.05f, 0.05f, 0.06f, 0.03f, 0f, 0xFFFFCCBC)
        pair("Finger skin", FACE, 0.30f, 0.62f, 0.04f, 0.04f, 0.05f, 0.025f, 0f, 0xFFFFAB91)
        pair("Thigh skin", FACE, 0.10f, 0.55f, 0.08f, 0.08f, 0.16f, 0.04f, 0f, 0xFFFFCCBC)
        pair("Shin skin", FACE, 0.10f, 0.25f, 0.06f, 0.05f, 0.14f, 0.035f, 0f, 0xFFFFAB91)
        pair("Foot skin", FACE, 0.10f, 0.05f, 0.08f, 0.06f, 0.04f, 0.04f, 0f, 0xFFFFCCBC)
        pair("Toe skin", FACE, 0.12f, 0.02f, 0.10f, 0.05f, 0.025f, 0.03f, 0f, 0xFFFFAB91)
        pair("Hip skin", FACE, 0.12f, 0.75f, 0.08f, 0.07f, 0.08f, 0.04f, 0f, 0xFFFFCCBC)
        pair("Glute skin", FACE, 0.08f, 0.72f, -0.08f, 0.08f, 0.10f, 0.05f, 0f, 0xFFFFAB91)
        add("Lower back skin", FACE, 0f, 1.05f, -0.10f, 0.14f, 0.12f, 0.04f, 0f, 0xFFFFCCBC)
        add("Upper back skin", FACE, 0f, 1.30f, -0.10f, 0.16f, 0.10f, 0.04f, 0f, 0xFFFFAB91)
        // Subcutaneous fat pads (integumentary depth)
        add("Abdominal fat", ORGAN, 0f, 0.92f, 0.08f, 0.12f, 0.10f, 0.05f, 0f, 0xFFFFE0B2)
        pair("Thigh fat", ORGAN, 0.10f, 0.55f, 0.05f, 0.06f, 0.12f, 0.04f, 0f, 0xFFFFE0B2)
        // Nails (simple pads)
        pair("Fingernail", FACE, 0.32f, 0.58f, 0.05f, 0.02f, 0.01f, 0.015f, 0f, 0xFFECEFF1)
        pair("Toenail", FACE, 0.14f, 0.01f, 0.12f, 0.025f, 0.01f, 0.015f, 0f, 0xFFECEFF1)


        add("Nasal bridge", FACE, 0f, 1.535f, 0.145f, 0.016f, 0.045f, 0.025f, 0f, 0xFF4DD0E1)
        add("Nose tip", FACE, 0f, 1.485f, 0.172f, 0.021f, 0.018f, 0.022f, 0f, 0xFF4DD0E1)
        pair("Nostril", FACE, 0.014f, 1.478f, 0.168f, 0.009f, 0.007f, 0.010f, 0f, 0xFF263238)
        pair("Nose wing", FACE, 0.030f, 1.482f, 0.150f, 0.014f, 0.016f, 0.015f, 0f, 0xFF4DD0E1)
        add("Septum", FACE, 0f, 1.478f, 0.155f, 0.005f, 0.012f, 0.02f, 0f, 0xFF80DEEA)
        pair("Cheek", FACE, 0.098f, 1.47f, 0.105f, 0.06f, 0.05f, 0.05f, 0f, 0xFF4DD0E1)
        pair("Ear", FACE, 0.176f, 1.52f, -0.005f, 0.018f, 0.05f, 0.035f, 0f, 0xFF4DD0E1)
        pair("Ear lobe", FACE, 0.176f, 1.468f, -0.005f, 0.012f, 0.014f, 0.016f, 0f, 0xFF4DD0E1)
        add("Philtrum", FACE, 0f, 1.446f, 0.150f, 0.012f, 0.014f, 0.012f, 0f, 0xFF80DEEA)
        add("Upper lip", FACE, 0f, 1.425f, 0.148f, 0.036f, 0.010f, 0.016f, 0f, 0xFFEF9A9A)
        add("Lower lip", FACE, 0f, 1.402f, 0.146f, 0.034f, 0.012f, 0.016f, 0f, 0xFFE57373)
        pair("Mouth corner", FACE, 0.04f, 1.414f, 0.135f, 0.008f, 0.008f, 0.010f, 0f, 0xFFE57373)
        add("Upper teeth", FACE, 0f, 1.418f, 0.128f, 0.032f, 0.010f, 0.018f, 0f, 0xFFFFFFFF)
        add("Lower teeth", FACE, 0f, 1.402f, 0.126f, 0.030f, 0.009f, 0.017f, 0f, 0xFFFFFFFF)
        add("Tongue", FACE, 0f, 1.405f, 0.095f, 0.030f, 0.012f, 0.050f, 0f, 0xFFF48FB1)
        add("Chin", FACE, 0f, 1.345f, 0.115f, 0.045f, 0.032f, 0.040f, 0f, 0xFF4DD0E1)
        pair("Jaw", FACE, 0.10f, 1.385f, 0.03f, 0.04f, 0.05f, 0.07f, 0f, 0xFF4DD0E1)
        add("Scalp", FACE, 0f, 1.62f, -0.01f, 0.165f, 0.12f, 0.145f, 0f, 0xFF37474F)

        // ── MUSCLE ───────────────────────────────────────────────────────────
        add("Frontalis", MUSCLE, 0f, 1.65f, 0.125f, 0.10f, 0.05f, 0.02f, 0f, 0xFFE57373)
        pair("Temporalis", MUSCLE, 0.145f, 1.58f, 0.05f, 0.02f, 0.06f, 0.07f, 0f, 0xFFD32F2F)
        pair("Orbicularis oculi", MUSCLE, 0.062f, 1.555f, 0.125f, 0.045f, 0.040f, 0.012f, 0f, 0xFFE57373)
        pair("Zygomaticus", MUSCLE, 0.08f, 1.455f, 0.12f, 0.04f, 0.012f, 0.015f, 25f, 0xFFEF5350)
        pair("Masseter", MUSCLE, 0.125f, 1.43f, 0.05f, 0.022f, 0.05f, 0.04f, 0f, 0xFFC62828)
        pair("Buccinator", MUSCLE, 0.07f, 1.42f, 0.11f, 0.03f, 0.025f, 0.02f, 0f, 0xFFE53935)
        add("Orbicularis oris", MUSCLE, 0f, 1.413f, 0.14f, 0.045f, 0.022f, 0.012f, 0f, 0xFFEF5350)
        add("Mentalis", MUSCLE, 0f, 1.36f, 0.12f, 0.03f, 0.02f, 0.015f, 0f, 0xFFEF5350)
        pair("Sternocleidomastoid", MUSCLE, 0.06f, 1.22f, 0.05f, 0.022f, 0.13f, 0.025f, -14f, 0xFFD32F2F)
        add("Platysma", MUSCLE, 0f, 1.27f, 0.085f, 0.08f, 0.07f, 0.01f, 0f, 0xFFE57373)
        add("Trapezius", MUSCLE, 0f, 1.15f, -0.06f, 0.20f, 0.10f, 0.05f, 0f, 0xFFE57373)
        pair("Pectoral", MUSCLE, 0.15f, 0.95f, 0.12f, 0.15f, 0.12f, 0.06f, 0f, 0xFFEF5350)
        pair("Serratus anterior", MUSCLE, 0.25f, 0.84f, 0.05f, 0.04f, 0.14f, 0.07f, 0f, 0xFFE53935)
        pair("Deltoid", MUSCLE, 0.40f, 1.00f, 0.02f, 0.09f, 0.12f, 0.09f, 8f, 0xFFE53935)
        pair("Supraspinatus", MUSCLE, 0.20f, 1.06f, -0.09f, 0.08f, 0.03f, 0.03f, 0f, 0xFFD32F2F)
        pair("Infraspinatus", MUSCLE, 0.22f, 0.98f, -0.115f, 0.08f, 0.06f, 0.025f, 0f, 0xFFC62828)
        pair("Teres major", MUSCLE, 0.30f, 0.93f, -0.10f, 0.05f, 0.025f, 0.025f, 0f, 0xFFD32F2F)
        pair("Rhomboid", MUSCLE, 0.07f, 1.00f, -0.10f, 0.06f, 0.07f, 0.02f, 0f, 0xFFE57373)
        pair("Latissimus", MUSCLE, 0.20f, 0.80f, -0.11f, 0.12f, 0.22f, 0.04f, 0f, 0xFFD32F2F)
        pair("Erector spinae", MUSCLE, 0.05f, 0.72f, -0.105f, 0.03f, 0.38f, 0.035f, 0f, 0xFFB71C1C)
        pair("Biceps", MUSCLE, 0.48f, 0.78f, 0.07f, 0.06f, 0.17f, 0.06f, 14f, 0xFFEF5350)
        pair("Triceps", MUSCLE, 0.48f, 0.74f, -0.07f, 0.06f, 0.17f, 0.06f, 14f, 0xFFC62828)
        pair("Brachialis", MUSCLE, 0.50f, 0.62f, 0.04f, 0.045f, 0.10f, 0.04f, 14f, 0xFFE53935)
        pair("Brachioradialis", MUSCLE, 0.54f, 0.38f, 0.05f, 0.03f, 0.12f, 0.03f, 10f, 0xFFEF5350)
        pair("Forearm flexors", MUSCLE, 0.53f, 0.25f, 0.045f, 0.05f, 0.16f, 0.035f, 10f, 0xFFE53935)
        pair("Forearm extensors", MUSCLE, 0.53f, 0.25f, -0.045f, 0.05f, 0.16f, 0.035f, 10f, 0xFFC62828)
        pair("Thenar", MUSCLE, 0.575f, -0.01f, 0.025f, 0.02f, 0.03f, 0.015f, 6f, 0xFFEF5350)
        add("Rectus abdominis", MUSCLE, 0f, 0.50f, 0.13f, 0.14f, 0.20f, 0.04f, 0f, 0xFFFF7043)
        pair("Oblique", MUSCLE, 0.20f, 0.48f, 0.08f, 0.07f, 0.20f, 0.05f, 0f, 0xFFF4511E)
        add("Transversus abdominis", MUSCLE, 0f, 0.38f, 0.10f, 0.21f, 0.14f, 0.02f, 0f, 0xFFFF8A65)
        pair("Psoas", MUSCLE, 0.07f, 0.28f, -0.05f, 0.03f, 0.18f, 0.03f, -4f, 0xFFD84315)
        pair("Iliacus", MUSCLE, 0.13f, 0.19f, -0.01f, 0.05f, 0.06f, 0.03f, 0f, 0xFFE64A19)
        pair("Gluteus maximus", MUSCLE, 0.10f, 0.14f, -0.12f, 0.10f, 0.10f, 0.08f, 0f, 0xFFD84315)
        pair("Gluteus medius", MUSCLE, 0.15f, 0.22f, -0.10f, 0.07f, 0.05f, 0.05f, 0f, 0xFFE64A19)
        pair("Tensor fasciae latae", MUSCLE, 0.22f, 0.12f, 0.03f, 0.03f, 0.10f, 0.03f, 0f, 0xFFEF5350)
        pair("Quadriceps", MUSCLE, 0.17f, -0.05f, 0.09f, 0.11f, 0.28f, 0.09f, 2f, 0xFFEF5350)
        pair("Sartorius", MUSCLE, 0.16f, -0.02f, 0.115f, 0.02f, 0.33f, 0.02f, -8f, 0xFFE53935)
        pair("Adductors", MUSCLE, 0.09f, -0.06f, 0.02f, 0.05f, 0.24f, 0.07f, 0f, 0xFFD84315)
        pair("Gracilis", MUSCLE, 0.07f, -0.10f, 0.0f, 0.02f, 0.28f, 0.02f, 0f, 0xFFE57373)
        pair("Hamstring", MUSCLE, 0.17f, -0.07f, -0.09f, 0.10f, 0.26f, 0.08f, 2f, 0xFFC62828)
        pair("Gastrocnemius", MUSCLE, 0.17f, -0.46f, -0.06f, 0.07f, 0.17f, 0.06f, 2f, 0xFFE53935)
        pair("Soleus", MUSCLE, 0.17f, -0.56f, -0.045f, 0.06f, 0.15f, 0.045f, 2f, 0xFFC62828)
        pair("Tibialis anterior", MUSCLE, 0.145f, -0.52f, 0.06f, 0.035f, 0.22f, 0.03f, 2f, 0xFFEF5350)
        pair("Peroneus", MUSCLE, 0.20f, -0.52f, 0.0f, 0.025f, 0.20f, 0.03f, 2f, 0xFFD32F2F)
        pair("Foot intrinsics", MUSCLE, 0.16f, -0.88f, 0.06f, 0.05f, 0.02f, 0.14f, 0f, 0xFFE57373)

        // ── SKELETON ─────────────────────────────────────────────────────────
        // Complete spine (not single vertebra)
        add("Cervical spine", SKELETON, 0f, 1.30f, -0.02f, 0.04f, 0.14f, 0.04f, 0f, 0xFFF5F0E1)
        add("Thoracic spine", SKELETON, 0f, 0.90f, -0.04f, 0.05f, 0.28f, 0.05f, 0f, 0xFFF1EBD8)
        add("Lumbar spine", SKELETON, 0f, 0.45f, -0.03f, 0.05f, 0.16f, 0.05f, 0f, 0xFFEFE8D2)
        add("Sacrum", SKELETON, 0f, 0.18f, -0.04f, 0.06f, 0.08f, 0.04f, 0f, 0xFFEDE7D4)
        pair("Scapula", SKELETON, 0.18f, 1.05f, -0.10f, 0.10f, 0.12f, 0.03f, 0f, 0xFFEDE7D4)
        pair("Clavicle", SKELETON, 0.16f, 1.18f, 0.04f, 0.12f, 0.02f, 0.02f, 0f, 0xFFF5F0E1)
        add("Sternum", SKELETON, 0f, 0.95f, 0.10f, 0.04f, 0.18f, 0.02f, 0f, 0xFFF5F0E1)
        add("Cranium", SKELETON, 0f, 1.57f, -0.005f, 0.14f, 0.16f, 0.125f, 0f, 0xFFF5F0E1)
        add("Frontal bone", SKELETON, 0f, 1.62f, 0.09f, 0.11f, 0.08f, 0.04f, 0f, 0xFFF5F0E1)
        pair("Parietal bone", SKELETON, 0.07f, 1.66f, -0.02f, 0.08f, 0.08f, 0.10f, 0f, 0xFFF1EBD8)
        pair("Temporal bone", SKELETON, 0.13f, 1.53f, 0.0f, 0.03f, 0.05f, 0.06f, 0f, 0xFFEFE8D2)
        add("Occipital bone", SKELETON, 0f, 1.54f, -0.10f, 0.10f, 0.09f, 0.03f, 0f, 0xFFEDE7D4)
        pair("Orbit", SKELETON, 0.062f, 1.555f, 0.10f, 0.038f, 0.034f, 0.025f, 0f, 0xFFEDE7D4)
        pair("Zygomatic bone", SKELETON, 0.10f, 1.49f, 0.09f, 0.04f, 0.022f, 0.03f, 0f, 0xFFF1EBD8)
        add("Nasal bone", SKELETON, 0f, 1.53f, 0.14f, 0.012f, 0.03f, 0.015f, 0f, 0xFFF1EBD8)
        add("Maxilla", SKELETON, 0f, 1.44f, 0.105f, 0.05f, 0.035f, 0.035f, 0f, 0xFFEDE7D4)
        add("Mandible", SKELETON, 0f, 1.375f, 0.07f, 0.085f, 0.04f, 0.075f, 0f, 0xFFEDE7D4)
        add("Hyoid", SKELETON, 0f, 1.29f, 0.06f, 0.03f, 0.008f, 0.012f, 0f, 0xFFF5F0E1)
        for (i in 0 until 7) add("Cervical vertebra C${i + 1}", SKELETON, 0f, 1.33f - i * 0.034f, -0.035f, 0.025f, 0.018f, 0.025f, 0f, 0xFFEDE7D4)
        for (i in 0 until 12) add("Thoracic vertebra T${i + 1}", SKELETON, 0f, 1.09f - i * 0.052f, -0.08f, 0.034f, 0.024f, 0.034f, 0f, 0xFFE6DFC8)
        for (i in 0 until 5) add("Lumbar vertebra L${i + 1}", SKELETON, 0f, 0.49f - i * 0.075f, -0.07f, 0.042f, 0.032f, 0.04f, 0f, 0xFFE0D8BE)
        add("Sacrum", SKELETON, 0f, 0.105f, -0.08f, 0.07f, 0.065f, 0.04f, 0f, 0xFFDCD3B6)
        add("Coccyx", SKELETON, 0f, 0.04f, -0.075f, 0.018f, 0.025f, 0.015f, 0f, 0xFFDCD3B6)
        for (i in 0 until 6) add("Intervertebral disc ${i + 1}", SKELETON, 0f, 0.455f - i * 0.075f, -0.07f, 0.038f, 0.008f, 0.036f, 0f, 0xFF90A4AE)
        pair("Clavicle", SKELETON, 0.16f, 1.13f, 0.04f, 0.16f, 0.02f, 0.03f, 8f, 0xFFF1EBD8)
        pair("Scapula", SKELETON, 0.21f, 0.98f, -0.11f, 0.10f, 0.12f, 0.02f, 0f, 0xFFEFE8D2)
        add("Manubrium", SKELETON, 0f, 1.05f, 0.145f, 0.05f, 0.03f, 0.02f, 0f, 0xFFF1EBD8)
        add("Sternum body", SKELETON, 0f, 0.91f, 0.15f, 0.03f, 0.12f, 0.02f, 0f, 0xFFF1EBD8)
        add("Xiphoid process", SKELETON, 0f, 0.77f, 0.14f, 0.012f, 0.025f, 0.012f, 0f, 0xFFF1EBD8)
        for (i in 0 until 12) {
            val w = if (i < 7) 0.12f + 0.005f * i else 0.155f - 0.016f * (i - 6)
            val d = if (i < 7) 0.12f + 0.006f * i else 0.16f - 0.022f * (i - 6)
            pair("Rib ${i + 1}", SKELETON, 0.14f - i * 0.002f, 1.10f - i * 0.05f, 0.015f, w, 0.014f, d, 0f, 0xFFEDE7D4)
        }
        pair("Costal cartilage", SKELETON, 0.06f, 0.88f, 0.15f, 0.04f, 0.14f, 0.012f, 0f, 0xFFB0BEC5)
        pair("Ilium", SKELETON, 0.14f, 0.19f, -0.01f, 0.09f, 0.07f, 0.07f, 20f, 0xFFE0D8BE)
        pair("Ischium", SKELETON, 0.12f, 0.08f, -0.03f, 0.04f, 0.05f, 0.05f, 0f, 0xFFE0D8BE)
        pair("Pubis", SKELETON, 0.04f, 0.07f, 0.07f, 0.04f, 0.025f, 0.02f, 0f, 0xFFE0D8BE)
        pair("Humerus", SKELETON, 0.48f, 0.72f, 0f, 0.03f, 0.27f, 0.03f, 16f, 0xFFF1EBD8)
        pair("Radius", SKELETON, 0.55f, 0.27f, 0.012f, 0.014f, 0.24f, 0.014f, 10f, 0xFFF1EBD8)
        pair("Ulna", SKELETON, 0.51f, 0.27f, -0.012f, 0.014f, 0.25f, 0.014f, 10f, 0xFFF1EBD8)
        pair("Carpals", SKELETON, 0.565f, 0.015f, 0f, 0.03f, 0.018f, 0.02f, 6f, 0xFFEDE7D4)
        pair("Metacarpals", SKELETON, 0.565f, -0.05f, 0f, 0.035f, 0.04f, 0.012f, 6f, 0xFFEDE7D4)
        for (f in 0 until 5) {
            val n = if (f == 0) 2 else 3
            for (k in 0 until n) {
                pair("${fingerNames[f]} phalanx ${k + 1}", SKELETON, 0.56f + fingerOff[f], -0.105f - k * 0.025f,
                    0.005f, 0.006f, 0.011f - k * 0.002f, 0.006f, 4f, 0xFFF1EBD8)
            }
        }
        pair("Femur", SKELETON, 0.16f, -0.07f, 0f, 0.04f, 0.34f, 0.04f, 2f, 0xFFF1EBD8)
        pair("Femoral head", SKELETON, 0.13f, 0.14f, 0f, 0.035f, 0.035f, 0.035f, 0f, 0xFFF1EBD8)
        pair("Patella", SKELETON, 0.16f, -0.40f, 0.06f, 0.035f, 0.035f, 0.02f, 0f, 0xFFEDE7D4)
        pair("Tibia", SKELETON, 0.165f, -0.52f, 0.005f, 0.030f, 0.31f, 0.030f, 2f, 0xFFF1EBD8)
        pair("Fibula", SKELETON, 0.205f, -0.52f, -0.005f, 0.014f, 0.30f, 0.014f, 2f, 0xFFEDE7D4)
        pair("Calcaneus", SKELETON, 0.16f, -0.885f, -0.06f, 0.035f, 0.03f, 0.06f, 0f, 0xFFEDE7D4)
        pair("Talus", SKELETON, 0.16f, -0.845f, -0.01f, 0.035f, 0.025f, 0.04f, 0f, 0xFFEDE7D4)
        pair("Tarsals", SKELETON, 0.16f, -0.87f, 0.05f, 0.05f, 0.02f, 0.03f, 0f, 0xFFE6DFC8)
        for (t in 0 until 5) {
            pair("Metatarsal ${t + 1}", SKELETON, 0.16f + toeOff[t] * 0.8f, -0.88f, 0.12f, 0.009f, 0.010f, 0.06f, 0f, 0xFFEDE7D4)
            val n = if (t == 0) 2 else 3
            for (k in 0 until n) {
                pair("Toe ${t + 1} phalanx ${k + 1}", SKELETON, 0.16f + toeOff[t], -0.88f, 0.20f + k * 0.022f,
                    0.007f, 0.008f, 0.010f, 0f, 0xFFF1EBD8)
            }
        }

        // ── ORGANS ───────────────────────────────────────────────────────────
        add("Tongue root", ORGAN, 0f, 1.37f, 0.03f, 0.03f, 0.02f, 0.04f, 0f, 0xFFF48FB1)
        add("Pharynx", ORGAN, 0f, 1.33f, -0.02f, 0.035f, 0.05f, 0.03f, 0f, 0xFFEF9A9A)
        add("Larynx", ORGAN, 0f, 1.26f, 0.045f, 0.03f, 0.03f, 0.022f, 0f, 0xFFB3E5FC)
        add("Trachea", ORGAN, 0f, 1.12f, 0f, 0.02f, 0.14f, 0.02f, 0f, 0xFFB3E5FC)
        pair("Bronchus", ORGAN, 0.045f, 0.99f, 0f, 0.05f, 0.012f, 0.012f, 25f, 0xFFB3E5FC)
        add("Thyroid", ORGAN, 0f, 1.20f, 0.05f, 0.04f, 0.025f, 0.02f, 0f, 0xFFFFAB91)
        add("Thymus", ORGAN, 0f, 1.03f, 0.10f, 0.05f, 0.05f, 0.025f, 0f, 0xFFFFE0B2)
        add("Oesophagus", ORGAN, 0f, 0.98f, -0.03f, 0.018f, 0.20f, 0.018f, 0f, 0xFFF48FB1)
        add("Lung upper lobe L", ORGAN, -0.14f, 1.02f, 0f, 0.10f, 0.10f, 0.09f, -4f, 0xFFF8BBD0, -1)
        add("Lung lower lobe L", ORGAN, -0.14f, 0.82f, -0.01f, 0.11f, 0.12f, 0.09f, -4f, 0xFFF8BBD0, -1)
        add("Lung upper lobe R", ORGAN, 0.14f, 1.02f, 0f, 0.10f, 0.10f, 0.09f, 4f, 0xFFF8BBD0, 1)
        add("Lung middle lobe R", ORGAN, 0.16f, 0.90f, 0.05f, 0.08f, 0.04f, 0.06f, 0f, 0xFFF4A9C4, 1)
        add("Lung lower lobe R", ORGAN, 0.14f, 0.80f, -0.01f, 0.11f, 0.12f, 0.09f, 4f, 0xFFF8BBD0, 1)
        add("Heart", ORGAN, -0.04f, 0.86f, 0.06f, 0.07f, 0.085f, 0.06f, -15f, 0xFFD50000)
        add("Heart outer", ORGAN, 0.05f, 0.95f, 0.08f, 0.08f, 0.09f, 0.07f, 0f, 0xFFE57373, 0, 2)
        add("Heart core", ORGAN, -0.04f, 0.86f, 0.07f, 0.05f, 0.06f, 0.045f, -15f, 0xFFFF1744)
        add("Heart · left ventricle", ORGAN, -0.06f, 0.83f, 0.065f, 0.042f, 0.055f, 0.04f, -15f, 0xFFB71C1C, -1)
        add("Heart · right ventricle", ORGAN, 0.0f, 0.855f, 0.085f, 0.038f, 0.05f, 0.035f, -10f, 0xFFE53935, 1)
        add("Heart · left atrium", ORGAN, -0.05f, 0.92f, 0.03f, 0.030f, 0.025f, 0.03f, 0f, 0xFFC62828, -1)
        add("Heart · right atrium", ORGAN, 0.02f, 0.915f, 0.045f, 0.030f, 0.032f, 0.03f, 0f, 0xFFEF5350, 1)
        add("Heart · septum", ORGAN, -0.03f, 0.86f, 0.065f, 0.008f, 0.06f, 0.04f, -15f, 0xFF8E0000)
        add("Heart · aortic valve", ORGAN, -0.025f, 0.905f, 0.055f, 0.012f, 0.008f, 0.012f, 0f, 0xFFFFCDD2, -1)
        add("Heart · mitral valve", ORGAN, -0.05f, 0.885f, 0.05f, 0.012f, 0.007f, 0.012f, 0f, 0xFFFFCDD2, -1)
        add("Heart · tricuspid valve", ORGAN, 0.01f, 0.885f, 0.065f, 0.012f, 0.007f, 0.012f, 0f, 0xFFFFCDD2, 1)
        add("Heart · pulmonary valve", ORGAN, -0.01f, 0.925f, 0.08f, 0.011f, 0.007f, 0.011f, 0f, 0xFFFFCDD2, 1)
        add("Diaphragm", ORGAN, 0f, 0.70f, 0f, 0.24f, 0.025f, 0.12f, 0f, 0xFFFFCCBC)
        add("Liver", ORGAN, 0.12f, 0.62f, 0.04f, 0.14f, 0.08f, 0.09f, -6f, 0xFF8D4B2F)
        add("Gallbladder", ORGAN, 0.10f, 0.56f, 0.08f, 0.02f, 0.03f, 0.02f, 0f, 0xFF66BB6A)
        add("Stomach", ORGAN, -0.10f, 0.60f, 0.05f, 0.09f, 0.09f, 0.07f, 20f, 0xFFFF8A65)
        add("Belly cavity", ORGAN, 0f, 0.40f, 0.04f, 0.16f, 0.14f, 0.10f, 0f, 0xFFFFAB91)
        add("Intestine loop", ORGAN, 0.02f, 0.32f, 0.03f, 0.12f, 0.10f, 0.08f, 0f, 0xFFFF8A65)
        add("Spleen", ORGAN, -0.20f, 0.64f, -0.04f, 0.04f, 0.06f, 0.03f, 0f, 0xFF7B1FA2)
        add("Pancreas", ORGAN, 0f, 0.55f, 0f, 0.10f, 0.025f, 0.03f, 0f, 0xFFFFE082)
        pair("Adrenal gland", ORGAN, 0.10f, 0.60f, -0.07f, 0.025f, 0.015f, 0.02f, 0f, 0xFFFFCC80)
        pair("Kidney", ORGAN, 0.12f, 0.52f, -0.08f, 0.04f, 0.065f, 0.035f, 0f, 0xFF8E2424)
        pair("Ureter", ORGAN, 0.09f, 0.34f, -0.07f, 0.006f, 0.17f, 0.006f, 0f, 0xFFFFF59D)
        add("Duodenum", ORGAN, 0.03f, 0.52f, 0.04f, 0.05f, 0.02f, 0.02f, 0f, 0xFFF48FB1)
        add("Jejunum", ORGAN, -0.06f, 0.38f, 0.05f, 0.09f, 0.07f, 0.07f, 0f, 0xFFF48FB1)
        add("Ileum", ORGAN, 0.04f, 0.26f, 0.05f, 0.10f, 0.07f, 0.07f, 0f, 0xFFF06292)
        add("Caecum", ORGAN, 0.19f, 0.16f, 0.04f, 0.035f, 0.035f, 0.03f, 0f, 0xFFCE93D8)
        add("Appendix", ORGAN, 0.17f, 0.12f, 0.05f, 0.008f, 0.025f, 0.008f, 20f, 0xFFBA68C8)
        add("Ascending colon", ORGAN, 0.19f, 0.32f, 0.04f, 0.03f, 0.12f, 0.03f, 0f, 0xFFCE93D8)
        add("Transverse colon", ORGAN, 0f, 0.46f, 0.07f, 0.18f, 0.03f, 0.03f, 0f, 0xFFCE93D8)
        add("Descending colon", ORGAN, -0.19f, 0.30f, 0.04f, 0.03f, 0.12f, 0.03f, 0f, 0xFFCE93D8)
        add("Sigmoid colon", ORGAN, -0.08f, 0.14f, 0.04f, 0.07f, 0.03f, 0.03f, 0f, 0xFFCE93D8)
        add("Rectum", ORGAN, 0f, 0.07f, -0.04f, 0.025f, 0.05f, 0.025f, 0f, 0xFFAB47BC)
        add("Anal canal", ORGAN, 0f, 0.01f, -0.05f, 0.015f, 0.02f, 0.015f, 0f, 0xFF8E24AA)
        // Reproductive (male + female teaching set — complete human, not single sex)
        add("Uterus", ORGAN, 0f, 0.08f, 0.04f, 0.06f, 0.05f, 0.04f, 0f, 0xFFF48FB1, 0, 3)
        pair("Ovary", ORGAN, 0.08f, 0.10f, 0.02f, 0.025f, 0.02f, 0.02f, 0f, 0xFFF8BBD0, 3)
        pair("Testis", ORGAN, 0.04f, -0.02f, 0.10f, 0.025f, 0.035f, 0.025f, 0f, 0xFFFFCC80, 3)
        add("Prostate", ORGAN, 0f, 0.02f, 0.06f, 0.04f, 0.03f, 0.03f, 0f, 0xFFFFE082, 0, 3)
        add("Pituitary", ORGAN, 0f, 1.48f, 0.02f, 0.02f, 0.015f, 0.02f, 0f, 0xFFCE93D8, 0, 0)
        add("Bladder", ORGAN, 0f, 0.11f, 0.06f, 0.05f, 0.05f, 0.04f, 0f, 0xFFFFF176)
        add("Urethra", ORGAN, 0f, 0.05f, 0.07f, 0.007f, 0.04f, 0.007f, 0f, 0xFFFFF59D)

        // ── VESSELS · NERVES · LYMPH ─────────────────────────────────────────
        add("Aorta", VESSEL, 0.0f, 0.70f, -0.04f, 0.02f, 0.35f, 0.02f, 0f, 0xFFFF1744)
        add("Aortic arch", VESSEL, -0.015f, 0.97f, 0.01f, 0.04f, 0.015f, 0.02f, 0f, 0xFFFF1744)
        add("Pulmonary trunk", VESSEL, -0.01f, 0.945f, 0.075f, 0.014f, 0.03f, 0.014f, 0f, 0xFF5C6BC0)
        pair("Pulmonary artery", VESSEL, 0.07f, 0.95f, 0.03f, 0.06f, 0.010f, 0.010f, 5f, 0xFF5C6BC0)
        pair("Pulmonary vein", VESSEL, 0.07f, 0.90f, 0.0f, 0.06f, 0.010f, 0.010f, -5f, 0xFFFF5252)
        add("Coronary artery L", VESSEL, -0.06f, 0.88f, 0.10f, 0.02f, 0.04f, 0.006f, -15f, 0xFFFF1744, -1)
        add("Coronary artery R", VESSEL, 0.01f, 0.88f, 0.10f, 0.02f, 0.04f, 0.006f, 10f, 0xFFFF1744, 1)
        add("Vena cava", VESSEL, 0.035f, 0.70f, -0.05f, 0.02f, 0.33f, 0.02f, 0f, 0xFF2979FF)
        add("Superior vena cava", VESSEL, 0.03f, 1.0f, 0.0f, 0.018f, 0.08f, 0.018f, 0f, 0xFF2979FF)
        pair("Carotid", VESSEL, 0.035f, 1.30f, 0.01f, 0.012f, 0.12f, 0.012f, 0f, 0xFFFF1744)
        pair("Jugular vein", VESSEL, 0.05f, 1.30f, 0.0f, 0.014f, 0.12f, 0.014f, 0f, 0xFF2979FF)
        pair("Vertebral artery", VESSEL, 0.03f, 1.25f, -0.04f, 0.006f, 0.10f, 0.006f, 0f, 0xFFFF1744)
        pair("Subclavian artery", VESSEL, 0.12f, 1.10f, 0.02f, 0.10f, 0.012f, 0.012f, 8f, 0xFFFF1744)
        pair("Subclavian vein", VESSEL, 0.12f, 1.12f, 0.035f, 0.10f, 0.012f, 0.012f, 8f, 0xFF2979FF)
        pair("Brachial artery", VESSEL, 0.45f, 0.60f, 0.02f, 0.012f, 0.30f, 0.012f, 14f, 0xFFFF1744)
        pair("Radial artery", VESSEL, 0.55f, 0.20f, 0.03f, 0.008f, 0.22f, 0.008f, 10f, 0xFFFF1744)
        pair("Ulnar artery", VESSEL, 0.51f, 0.20f, 0.0f, 0.008f, 0.22f, 0.008f, 10f, 0xFFFF1744)
        pair("Cephalic vein", VESSEL, 0.50f, 0.50f, 0.07f, 0.007f, 0.42f, 0.007f, 14f, 0xFF2979FF)
        pair("Basilic vein", VESSEL, 0.44f, 0.50f, 0.04f, 0.007f, 0.40f, 0.007f, 14f, 0xFF2979FF)
        pair("Renal artery", VESSEL, 0.06f, 0.54f, -0.06f, 0.035f, 0.008f, 0.008f, 0f, 0xFFFF1744)
        pair("Renal vein", VESSEL, 0.07f, 0.52f, -0.055f, 0.035f, 0.009f, 0.009f, 0f, 0xFF2979FF)
        add("Portal vein", VESSEL, 0.05f, 0.58f, 0.03f, 0.012f, 0.05f, 0.012f, 20f, 0xFF3D5AFE)
        add("Mesenteric vessels", VESSEL, 0.0f, 0.42f, 0.0f, 0.012f, 0.14f, 0.012f, 0f, 0xFFFF5252)
        pair("Common iliac artery", VESSEL, 0.04f, 0.26f, -0.04f, 0.012f, 0.07f, 0.012f, -20f, 0xFFFF1744)
        pair("Common iliac vein", VESSEL, 0.05f, 0.26f, -0.05f, 0.013f, 0.07f, 0.013f, -20f, 0xFF2979FF)
        pair("Femoral artery", VESSEL, 0.12f, -0.05f, 0.03f, 0.013f, 0.34f, 0.013f, 0f, 0xFFFF1744)
        pair("Femoral vein", VESSEL, 0.13f, -0.05f, 0.01f, 0.014f, 0.34f, 0.014f, 0f, 0xFF2979FF)
        pair("Great saphenous vein", VESSEL, 0.20f, -0.30f, 0.07f, 0.008f, 0.60f, 0.008f, 0f, 0xFF2979FF)
        pair("Popliteal artery", VESSEL, 0.16f, -0.42f, -0.05f, 0.011f, 0.06f, 0.011f, 0f, 0xFFFF1744)
        pair("Anterior tibial artery", VESSEL, 0.16f, -0.62f, 0.05f, 0.008f, 0.22f, 0.008f, 0f, 0xFFFF1744)
        pair("Posterior tibial artery", VESSEL, 0.15f, -0.62f, -0.04f, 0.008f, 0.22f, 0.008f, 0f, 0xFFFF1744)
        pair("Dorsalis pedis", VESSEL, 0.16f, -0.86f, 0.10f, 0.007f, 0.007f, 0.07f, 0f, 0xFFFF1744)
        add("Spinal cord", VESSEL, 0f, 0.85f, -0.105f, 0.015f, 0.55f, 0.015f, 0f, 0xFFFFEB3B)
        add("Cauda equina", VESSEL, 0f, 0.27f, -0.09f, 0.02f, 0.10f, 0.01f, 0f, 0xFFFFEB3B)
        pair("Vagus nerve", VESSEL, 0.045f, 1.0f, 0.0f, 0.005f, 0.40f, 0.005f, 0f, 0xFFFFEB3B)
        pair("Phrenic nerve", VESSEL, 0.07f, 0.95f, 0.04f, 0.004f, 0.25f, 0.004f, 0f, 0xFFFFEB3B)
        pair("Brachial plexus", VESSEL, 0.28f, 1.05f, -0.02f, 0.10f, 0.012f, 0.012f, 12f, 0xFFFFEB3B)
        pair("Median nerve", VESSEL, 0.50f, 0.45f, 0.02f, 0.005f, 0.50f, 0.005f, 12f, 0xFFFFEB3B)
        pair("Ulnar nerve", VESSEL, 0.50f, 0.45f, -0.03f, 0.005f, 0.50f, 0.005f, 12f, 0xFFFFEB3B)
        pair("Radial nerve", VESSEL, 0.52f, 0.45f, 0.0f, 0.005f, 0.50f, 0.005f, 12f, 0xFFFFEB3B)
        pair("Femoral nerve", VESSEL, 0.11f, 0.0f, 0.04f, 0.007f, 0.40f, 0.007f, 0f, 0xFFFFEB3B)
        pair("Sciatic nerve", VESSEL, 0.12f, -0.12f, -0.05f, 0.01f, 0.40f, 0.01f, 0f, 0xFFFFEB3B)
        pair("Common peroneal nerve", VESSEL, 0.19f, -0.50f, -0.01f, 0.005f, 0.20f, 0.005f, 0f, 0xFFFFEB3B)
        pair("Tibial nerve", VESSEL, 0.16f, -0.60f, -0.04f, 0.006f, 0.30f, 0.006f, 0f, 0xFFFFEB3B)
        pair("Cervical lymph nodes", VESSEL, 0.07f, 1.33f, 0.03f, 0.014f, 0.025f, 0.014f, 0f, 0xFFB2FF59)
        pair("Axillary lymph nodes", VESSEL, 0.30f, 0.98f, 0.0f, 0.03f, 0.03f, 0.025f, 0f, 0xFFB2FF59)
        pair("Inguinal lymph nodes", VESSEL, 0.12f, 0.10f, 0.06f, 0.03f, 0.02f, 0.02f, 0f, 0xFFB2FF59)
        add("Thoracic duct", VESSEL, -0.01f, 0.85f, -0.06f, 0.006f, 0.28f, 0.006f, 0f, 0xFFB2FF59)

        // ── BRAIN (generated from BrainModel, scaled into the skull) ─────────
        val bs = 0.11f
        val bx = 0f
        val by = 1.56f
        val bz = 0.0f
        for (l in BrainModel.lobes) {
            out.add(
                Part(
                    "Brain · ${l.name}", BRAIN,
                    bx + l.x * bs, by + l.y * bs, bz + l.z * bs,
                    l.rx * bs, l.ry * bs, l.rz * bs, l.rotZ,
                    BrainModel.baseColor(l), -1, l.side, l.kind
                )
            )
        }
        return out
    }
}

/**
 * Anatomical brain made of lobes: per hemisphere frontal / parietal / temporal / occipital + cerebellum,
 * plus midline brainstem and the deep structures corpus callosum, thalamus and hippocampus.
 * Brain units: x right, y up, z toward the face; whole brain fits roughly in ±1.
 */
object BrainModel {
    const val FRONTAL = 0
    const val PARIETAL = 1
    const val TEMPORAL = 2
    const val OCCIPITAL = 3
    const val CEREBELLUM = 4
    const val BRAINSTEM = 5
    const val CALLOSUM = 6
    const val THALAMUS = 7
    const val HIPPOCAMPUS = 8
    const val INSULA = 9
    const val CINGULATE = 10
    const val BASAL_GANGLIA = 11
    const val AMYGDALA = 12
    const val HYPOTHALAMUS = 13
    const val PONS = 14
    const val MEDULLA = 15
    const val VENTRICLE = 16
    const val PITUITARY = 17
    const val PINEAL = 18
    const val OLFACTORY = 19
    const val OPTIC_CHIASM = 20
    val KIND_NAMES = arrayOf(
        "Frontal", "Parietal", "Temporal", "Occipital", "Cerebellum",
        "Midbrain", "Corpus callosum", "Thalamus", "Hippocampus",
        "Insula", "Cingulate", "Basal ganglia", "Amygdala", "Hypothalamus",
        "Pons", "Medulla", "Ventricle", "Pituitary", "Pineal", "Olfactory bulb", "Optic chiasm"
    )

    class Lobe(
        val name: String,
        val kind: Int,
        /** −1 left hemisphere, +1 right hemisphere, 0 midline. */
        val side: Int,
        val x: Float, val y: Float, val z: Float,
        val rx: Float, val ry: Float, val rz: Float,
        val rotZ: Float,
        /** Deep structure: only drawn in cut-away mode. */
        val inner: Boolean
    )

    val lobes: List<Lobe> by lazy {
        val l = ArrayList<Lobe>(20)
        for (s in intArrayOf(-1, 1)) {
            val tag = if (s < 0) "L" else "R"
            val sf = s.toFloat()
            l.add(Lobe("Frontal $tag", FRONTAL, s, sf * 0.40f, 0.10f, 0.58f, 0.40f, 0.42f, 0.42f, sf * -4f, false))
            l.add(Lobe("Parietal $tag", PARIETAL, s, sf * 0.42f, 0.42f, -0.10f, 0.40f, 0.34f, 0.40f, sf * -4f, false))
            l.add(Lobe("Temporal $tag", TEMPORAL, s, sf * 0.57f, -0.22f, 0.12f, 0.28f, 0.24f, 0.48f, 0f, false))
            l.add(Lobe("Occipital $tag", OCCIPITAL, s, sf * 0.36f, 0.05f, -0.72f, 0.34f, 0.34f, 0.30f, 0f, false))
            l.add(Lobe("Cerebellum $tag", CEREBELLUM, s, sf * 0.24f, -0.46f, -0.58f, 0.26f, 0.20f, 0.28f, 0f, false))
            l.add(Lobe("Thalamus $tag", THALAMUS, s, sf * 0.10f, -0.02f, 0.06f, 0.10f, 0.08f, 0.11f, 0f, true))
            l.add(Lobe("Hippocampus $tag", HIPPOCAMPUS, s, sf * 0.34f, -0.30f, -0.05f, 0.07f, 0.07f, 0.30f, 0f, true))
            l.add(Lobe("Insula $tag", INSULA, s, sf * 0.55f, -0.02f, 0.18f, 0.10f, 0.16f, 0.22f, 0f, true))
            l.add(Lobe("Cingulate $tag", CINGULATE, s, sf * 0.12f, 0.22f, 0.02f, 0.07f, 0.09f, 0.50f, 0f, true))
            l.add(Lobe("Basal ganglia $tag", BASAL_GANGLIA, s, sf * 0.26f, 0.00f, 0.18f, 0.14f, 0.12f, 0.16f, 0f, true))
            l.add(Lobe("Amygdala $tag", AMYGDALA, s, sf * 0.34f, -0.30f, 0.20f, 0.06f, 0.06f, 0.07f, 0f, true))
            l.add(Lobe("Lateral ventricle $tag", VENTRICLE, s, sf * 0.16f, 0.18f, 0.0f, 0.06f, 0.07f, 0.40f, sf * -6f, true))
            l.add(Lobe("Olfactory bulb $tag", OLFACTORY, s, sf * 0.12f, -0.25f, 0.95f, 0.07f, 0.06f, 0.14f, 0f, false))
        }
        l.add(Lobe("Midbrain", BRAINSTEM, 0, 0f, -0.42f, -0.14f, 0.11f, 0.14f, 0.11f, 0f, false))
        l.add(Lobe("Pons", PONS, 0, 0f, -0.60f, -0.14f, 0.15f, 0.13f, 0.14f, 0f, false))
        l.add(Lobe("Medulla", MEDULLA, 0, 0f, -0.82f, -0.13f, 0.10f, 0.14f, 0.10f, 0f, false))
        l.add(Lobe("Hypothalamus", HYPOTHALAMUS, 0, 0f, -0.22f, 0.12f, 0.08f, 0.06f, 0.08f, 0f, true))
        l.add(Lobe("Pituitary", PITUITARY, 0, 0f, -0.34f, 0.16f, 0.04f, 0.04f, 0.04f, 0f, true))
        l.add(Lobe("Pineal", PINEAL, 0, 0f, 0.02f, -0.22f, 0.03f, 0.03f, 0.03f, 0f, true))
        l.add(Lobe("Third ventricle", VENTRICLE, 0, 0f, -0.05f, 0.04f, 0.015f, 0.09f, 0.08f, 0f, true))
        l.add(Lobe("Optic chiasm", OPTIC_CHIASM, 0, 0f, -0.28f, 0.28f, 0.10f, 0.02f, 0.03f, 0f, true))
        l.add(Lobe("Corpus callosum", CALLOSUM, 0, 0f, 0.08f, 0f, 0.10f, 0.07f, 0.52f, 0f, true))
        l
    }

    /** Left hemisphere cool, right hemisphere warm, midline neutral. */
    fun baseColor(l: Lobe): Int {
        val base = when (l.kind) {
            FRONTAL -> if (l.side < 0) 0xFF4FC3F7L else 0xFFFFB74DL
            PARIETAL -> if (l.side < 0) 0xFF4DD0E1L else 0xFFFF8A65L
            TEMPORAL -> if (l.side < 0) 0xFF64B5F6L else 0xFFFFD54FL
            OCCIPITAL -> if (l.side < 0) 0xFF7986CBL else 0xFFF06292L
            CEREBELLUM -> if (l.side < 0) 0xFF4DB6ACL else 0xFFBA68C8L
            BRAINSTEM -> 0xFFB0BEC5L
            CALLOSUM -> 0xFFFFFFFFL
            THALAMUS -> 0xFFFFF59DL
            INSULA -> if (l.side < 0) 0xFF80DEEAL else 0xFFFFCC80L
            CINGULATE -> if (l.side < 0) 0xFFB39DDBL else 0xFFF48FB1L
            BASAL_GANGLIA -> if (l.side < 0) 0xFF9FA8DAL else 0xFFFFAB91L
            AMYGDALA -> 0xFFFF5252L
            HYPOTHALAMUS -> 0xFFFFD180L
            PONS -> 0xFF90A4AEL
            MEDULLA -> 0xFF78909CL
            VENTRICLE -> 0xFF4FC3F7L
            PITUITARY -> 0xFFFFAB40L
            PINEAL -> 0xFFE040FBL
            OLFACTORY -> 0xFFCDDC39L
            OPTIC_CHIASM -> 0xFFFFEB3BL
            else -> 0xFFA5D6A7L   // hippocampus
        }
        return base.toInt()
    }
}
