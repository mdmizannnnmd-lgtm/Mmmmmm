package com.mizan

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * INSIDE WARP + INSIDE ROTATION of the 3D anatomy body (skeleton · organs · vessels/nerves · brain layers).
 *
 * Two systems, each driven by the live CENTROID and VERTICAL (the ambient board's spectral centroid and body vertical height)
 * with its own LEVEL · THRESHOLD · RAW and a live OUTPUT:
 *
 *  WARP      warpCen  — centroid bends / leans the inside sideways (grows with height) ; below the threshold it leans the other way
 *            warpVer  — vertical stretches (above the threshold) or squashes (below) the inside along the body axis
 *            + a travelling ripple up the body whose strength is the warp output.
 *  ROTATION  rotCen   — centroid turns the inside about the body's vertical axis (angle = bipolar centroid × [rotRange])
 *            rotVer   — vertical spins the inside continuously (speed = bipolar vertical × [rotSpeed])
 *            The outside (skin · muscle · face) stays where it is, so the inside visibly turns INSIDE the body.
 *
 * THRESHOLD is the neutral point of the bipolar drive, exactly like the ambient board: above it the drive pushes one way,
 * below it the other way. LEVEL scales it. RAW COMPLETE (panel switch, per-channel RAW, anatomy RAW, or ONENESS RAW EVERYTHING):
 * no level, no threshold, no smoothing — the live centroid / vertical goes straight to the warp and the rotation.
 */
class InsideWarpRot {
    val warpCen = ScreenEchoMic.Ch("wcen", 0.85f, 0.30f)
    val warpVer = ScreenEchoMic.Ch("wver", 0.85f, 0.30f)
    val rotCen = ScreenEchoMic.Ch("rcen", 0.85f, 0.30f)
    val rotVer = ScreenEchoMic.Ch("rver", 0.85f, 0.30f)
    val all = listOf(warpCen, warpVer, rotCen, rotVer)

    @Volatile var warpOn = true
    /** overall warp strength 0 … 2 */
    @Volatile var warpAmt = 0.60f
    /** travelling ripple 0 … 1 */
    @Volatile var ripple = 0.50f
    @Volatile var rotOn = true
    /** angle the centroid can turn the inside, radians (0 … π) */
    @Volatile var rotRange = 1.00f
    /** spin speed at full vertical drive, rad / s (0 … 6) */
    @Volatile var rotSpeed = 0.80f

    @Volatile var rawComplete = true
    @Volatile var rawEverything = false
    @Volatile var rawAnatomy = false

    // ── INSIDE ROTATION LOCKED MODE (part of the app's Locked settings; off by default → original behaviour) ──
    /** Inside rotation is held at [lockedYaw]: centroid and vertical no longer turn or spin it. */
    @Volatile var locked = false
    /** Angle the inside is held at while locked, radians (−π … π). 0 = the inside faces the same way as the body. */
    @Volatile var lockedYaw = 0f
    /** Lock the inside WARP (lean / stretch / ripple) as well. */
    @Volatile var lockWarp = false
    /** Also lock whenever the main LOCKED MODE (body fixed centre) is on. */
    @Volatile var followBodyLock = false
    /** LOCK RAW: the inside jumps to the locked angle at once — no easing, no level, no threshold. */
    @Volatile var lockRaw = false
    /** Set every frame by the view: the main LOCKED MODE state. */
    @Volatile var bodyLocked = false
    /** Yaw the inside would have without the lock (for "lock at current angle"). */
    @Volatile var freeYaw = 0f
        private set

    fun isLocked(): Boolean = locked || (followBodyLock && bodyLocked)

    /** Locks the inside at the angle it has right now. */
    fun lockHere() { lockedYaw = freeYaw; locked = true }

    // live outputs
    @Volatile var warpOut = 0f
        private set
    @Volatile var rotOut = 0f
        private set
    /** current extra yaw of the inside, radians */
    @Volatile var insideYaw = 0f
        private set

    private var spin = 0f
    private var lastNs = 0L

    fun isRaw(ch: ScreenEchoMic.Ch? = null) = rawComplete || rawEverything || rawAnatomy || ch?.raw == true

    /** True when the inside is being transformed at all. */
    fun active(): Boolean = warpOn || rotOn || isLocked()

    private fun warpRunning(): Boolean = warpOn && !(lockWarp && isLocked())

    private fun shape(ch: ScreenEchoMic.Ch, x: Float) {
        val s = x.coerceIn(0f, 1f)
        ch.norm = s
        if (!ch.on) { ch.active = false; ch.out = 0f; ch.bip = 0f; return }
        if (isRaw(ch)) { ch.active = true; ch.out = s; ch.bip = s * 2f - 1f; return }
        val t = ch.thr.coerceIn(0.02f, 0.98f)
        val lv = ch.lv.coerceIn(0f, 1.5f)
        val signed = if (s >= t) (s - t) / (1f - t) else -((t - s) / t)
        ch.bip = (signed * lv).coerceIn(-1f, 1f)
        ch.active = s >= t
        ch.out = if (ch.active) (((s - t) / (1f - t)) * lv).coerceIn(0f, 1f) else 0f
    }

    /** Once per frame with the live ambient board (centroid = spectral, vertical = body height). */
    fun tick(ab: AmbientThresholdBoard?) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1e9f).coerceIn(0f, 0.1f)
        lastNs = now
        val cen = ab?.centroidNorm ?: 0.5f
        val ver = ab?.verticalNorm ?: 0.5f
        shape(warpCen, cen); shape(warpVer, ver)
        shape(rotCen, cen); shape(rotVer, ver)

        val lockNow = isLocked()
        warpOut = if (warpRunning()) maxOf(abs(warpCen.bip), abs(warpVer.bip)).coerceIn(0f, 1f) else 0f
        if (rotOn) {
            if (!lockNow) {
                spin += rotVer.bip * rotSpeed.coerceIn(0f, 6f) * dt
                if (spin > Math.PI.toFloat()) spin -= 2f * Math.PI.toFloat()
                if (spin < -Math.PI.toFloat()) spin += 2f * Math.PI.toFloat()
            }
            freeYaw = rotCen.bip * rotRange.coerceIn(0f, Math.PI.toFloat()) + spin
            rotOut = maxOf(abs(rotCen.bip), abs(rotVer.bip)).coerceIn(0f, 1f)
        } else {
            freeYaw = 0f; rotOut = 0f
        }
        if (lockNow) {
            // LOCKED: hold the inside at the locked angle. RAW (lock RAW or any RAW COMPLETE) = jump there at once.
            val target = lockedYaw.coerceIn(-Math.PI.toFloat(), Math.PI.toFloat())
            val snap = lockRaw || rawComplete || rawEverything || rawAnatomy
            insideYaw = if (snap) target else insideYaw + (target - insideYaw) * (1f - kotlin.math.exp(-dt / 0.12f))
            rotOut = 0f
        } else {
            insideYaw = freeYaw
        }
    }

    /** Transforms a point of the INSIDE (body units). [out] receives x, y, z. */
    fun apply(x: Float, y: Float, z: Float, phase: Float, out: FloatArray) {
        var px = x; var py = y; var pz = z
        if (warpRunning()) {
            val a = warpAmt.coerceIn(0f, 2f)
            val cb = warpCen.bip
            val vb = warpVer.bip
            val h = y - 0.70f                              // height from the body centre
            // centroid → lean / bend sideways (a shear plus a curve that grows with height)
            px += cb * a * 0.20f * (h * 0.60f + h * h * 0.40f * (if (h >= 0f) 1f else -1f))
            // vertical → stretch / squash along the body axis (and the opposite across it)
            py = 0.70f + h * (1f + vb * a * 0.30f)
            val sq = 1f - vb * a * 0.12f
            px *= sq; pz *= sq
            // travelling ripple up the body, strength = warp output
            val rp = ripple.coerceIn(0f, 1f) * warpOut * a * 0.025f * sin(y * 7f - phase * 0.08f)
            px += rp; pz += rp * 0.6f
        }
        if (rotOn || isLocked()) {
            val c = cos(insideYaw); val s = sin(insideYaw)
            val rx = px * c + pz * s
            val rz = -px * s + pz * c
            px = rx; pz = rz
        }
        out[0] = px; out[1] = py; out[2] = pz
    }

    fun statusLine(): String {
        val r = if (rawComplete || rawEverything || rawAnatomy) " · RAW COMPLETE" else ""
        return "INSIDE WARP ${if (warpOn) "${(warpOut * 100).toInt()}%" else "off"}" +
            " (cen ${"%+.2f".format(warpCen.bip)} vert ${"%+.2f".format(warpVer.bip)})" +
            " · ROTATION ${if (isLocked()) "LOCKED${if (lockRaw) " RAW" else ""}" else if (rotOn) "${(rotOut * 100).toInt()}%" else "off"} yaw ${"%+.0f".format(Math.toDegrees(insideYaw.toDouble()))}°" +
            " (cen ${"%+.2f".format(rotCen.bip)} vert ${"%+.2f".format(rotVer.bip)})$r"
    }
}
