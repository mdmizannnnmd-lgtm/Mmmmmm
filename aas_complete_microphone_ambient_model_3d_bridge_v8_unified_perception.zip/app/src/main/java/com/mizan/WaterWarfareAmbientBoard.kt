package com.mizan

/**
 * Water ambient tiers (SYMBOLIC audio/BLE/model thresholds only — not real chemistry/biology):
 * pure / "immortal" water for self · toilet-tagged · virus-tagged for enemy lanes.
 * Tracking via mic + BLE scale + models. RAW COMPLETE.
 */
class WaterWarfareAmbientBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.24f
    @Volatile var levelAmt = 0.90f

    @Volatile var pureSelfOut = 0f
    @Volatile var immortalSelfOut = 0f
    @Volatile var toiletEnemyOut = 0f
    @Volatile var virusEnemyOut = 0f
    @Volatile var trackOut = 0f
    @Volatile var status = "WATER-WAR idle"

    private fun lane(e: Float): Float {
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * levelAmt).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * levelAmt).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, water: Float, ble: Float, enemy: Float) {
        if (!enabled) { status = "WATER-WAR OFF"; return }
        pureSelfOut = lane(maxOf(water, mic * 0.4f) * 1.05f)
        immortalSelfOut = lane(pureSelfOut * 1.1f)
        toiletEnemyOut = lane(enemy * 0.95f + ble * 0.5f)
        virusEnemyOut = lane(enemy * 0.9f + mic * 0.35f)
        trackOut = maxOf(toiletEnemyOut, virusEnemyOut, pureSelfOut * 0.5f)
        if (rawComplete) {
            pureSelfOut = maxOf(pureSelfOut, 0.3f)
            immortalSelfOut = maxOf(immortalSelfOut, pureSelfOut)
        }
        status =
            "SELF pure/immortal=${(pureSelfOut*100).toInt()}/${(immortalSelfOut*100).toInt()}% · " +
            "ENEMY toilet/virus=${(toiletEnemyOut*100).toInt()}/${(virusEnemyOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView?) {
        if (!enabled) return
        val vv = v ?: return
        try {
            vv.waterFullBody.waterFull = maxOf(vv.waterFullBody.waterFull, pureSelfOut)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, immortalSelfOut * 0.4f)
            vv.enemy3dProtect.enemyModelOut = maxOf(vv.enemy3dProtect.enemyModelOut, trackOut * 0.35f)
        } catch (_: Throwable) {}
    }
}
