package com.mizan

/**
 * Body Hz system: body Hz out · bad infection Hz · damage-cell Hz · good-frequency thr ·
 * repair / regeneration Hz · brain neuron regen · hormone fix Hz · full-body bad Hz thr ·
 * BLE watt power · mic · models · sensors · camera mixers. RAW COMPLETE.
 */
class BodyFrequencyRegenBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Live body Hz (from mic centroid / energy map)
    @Volatile var bodyHz = 0f
    @Volatile var bodyHzMin = 0f
    @Volatile var bodyHzMax = 50f
    @Volatile var bodyHzOut = 0f

    // Bad infection frequency
    @Volatile var infectionOn = true
    @Volatile var infectionHz = 0f
    @Volatile var infectionHzThr = 18f
    @Volatile var infectionBandLo = 12f
    @Volatile var infectionBandHi = 28f
    @Volatile var infectionOut = 0f
    @Volatile var infectionActive = false

    // Damage cell frequency
    @Volatile var damageCellOn = true
    @Volatile var damageCellHz = 0f
    @Volatile var damageCellHzThr = 22f
    @Volatile var damageCellOut = 0f
    @Volatile var damageCellActive = false

    // Good frequency threshold + band
    @Volatile var goodFreqOn = true
    @Volatile var goodHzLo = 4f
    @Volatile var goodHzHi = 12f
    @Volatile var goodHzThr = 0.25f
    @Volatile var goodHzOut = 0f
    @Volatile var goodActive = false

    // Repair frequency
    @Volatile var repairOn = true
    @Volatile var repairHz = 7.83f   // Schumann-like default target
    @Volatile var repairHzThr = 0.20f
    @Volatile var repairLv = 0.80f
    @Volatile var repairOut = 0f

    // Regeneration frequency (adjustable)
    @Volatile var regenOn = true
    @Volatile var regenHz = 10f
    @Volatile var regenHzThr = 0.22f
    @Volatile var regenLv = 0.85f
    @Volatile var regenOut = 0f

    // Our own regeneration frequency (user-owned path · full mix)
    @Volatile var ownRegenOn = true
    @Volatile var ownRegenHz = 10.5f
    @Volatile var ownRegenThr = 0.20f
    @Volatile var ownRegenLv = 0.90f
    @Volatile var ownRegenOut = 0f
    @Volatile var ownRegenMixMic = 0.40f
    @Volatile var ownRegenMixModel = 0.25f
    @Volatile var ownRegenMixSensor = 0.15f
    @Volatile var ownRegenMixCamera = 0.15f
    @Volatile var ownRegenMixBle = 0.20f
    @Volatile var ownRegenMixRepair = 0.30f
    @Volatile var ownRegenMixNeuron = 0.20f
    @Volatile var ownRegenMixHormone = 0.15f

    // Brain neurons regeneration
    @Volatile var neuronRegenOn = true
    @Volatile var neuronRegenHz = 40f  // gamma-ish target band map into 0-50
    @Volatile var neuronRegenThr = 0.25f
    @Volatile var neuronRegenLv = 0.80f
    @Volatile var neuronRegenOut = 0f

    // Healing frequency (distinct from repair)
    @Volatile var healingOn = true
    @Volatile var healingHz = 528f  // mapped into 0-50 display via map
    @Volatile var healingHzMapped = 10.56f  // 528 scaled feel into body band default
    @Volatile var healingThr = 0.20f
    @Volatile var healingLv = 0.88f
    @Volatile var healingOut = 0f

    // Brain EEG-style bands (app signal controls · full set)
    @Volatile var brainDeltaOn = true   // 0.5–4 Hz deep repair sleep-like
    @Volatile var brainDeltaHz = 2f
    @Volatile var brainDeltaOut = 0f
    @Volatile var brainThetaOn = true   // 4–8 Hz meditation / memory
    @Volatile var brainThetaHz = 6f
    @Volatile var brainThetaOut = 0f
    @Volatile var brainAlphaOn = true   // 8–12 Hz calm / closed-eye rest
    @Volatile var brainAlphaHz = 10f
    @Volatile var brainAlphaOut = 0f
    @Volatile var brainBetaOn = true    // 12–30 Hz focus
    @Volatile var brainBetaHz = 18f
    @Volatile var brainBetaOut = 0f
    @Volatile var brainGammaOn = true   // 30–50 Hz binding / cognition
    @Volatile var brainGammaHz = 40f
    @Volatile var brainGammaOut = 0f
    @Volatile var brainSmrOn = true     // 12–15 Hz sensorimotor
    @Volatile var brainSmrHz = 13.5f
    @Volatile var brainSmrOut = 0f
    @Volatile var brainBandThr = 0.18f
    @Volatile var brainBandLv = 0.80f
    @Volatile var brainFullOut = 0f

    // Complete brain structures L/R + midline (no missing)
    @Volatile var brainStructuresOn = true
    @Volatile var brainStructThr = 0.18f
    @Volatile var brainStructLv = 0.80f
    @Volatile var brainFrontalOut = 0f
    @Volatile var brainParietalOut = 0f
    @Volatile var brainTemporalOut = 0f
    @Volatile var brainOccipitalOut = 0f
    @Volatile var brainCerebellumOut = 0f
    @Volatile var brainThalamusOut = 0f
    @Volatile var brainHippocampusOut = 0f
    @Volatile var brainInsulaOut = 0f
    @Volatile var brainCingulateOut = 0f
    @Volatile var brainBasalOut = 0f
    @Volatile var brainAmygdalaOut = 0f
    @Volatile var brainHypothalamusOut = 0f
    @Volatile var brainBrainstemOut = 0f
    @Volatile var brainPituitaryOut = 0f
    @Volatile var brainPinealOut = 0f
    @Volatile var brainCallosumOut = 0f
    @Volatile var brainLHemOut = 0f
    @Volatile var brainRHemOut = 0f

    // Complete body organ systems (no missing)
    @Volatile var bodySystemsOn = true
    @Volatile var bodySysThr = 0.20f
    @Volatile var bodySysLv = 0.80f
    @Volatile var bodyHeartSysOut = 0f
    @Volatile var bodyLungSysOut = 0f
    @Volatile var bodyLiverSysOut = 0f
    @Volatile var bodyKidneySysOut = 0f
    @Volatile var bodySpineSysOut = 0f
    @Volatile var bodyGutSysOut = 0f
    @Volatile var bodyImmuneSysOut = 0f
    @Volatile var bodySkinSysOut = 0f
    @Volatile var bodyMuscleSysOut = 0f
    @Volatile var bodyBoneSysOut = 0f
    @Volatile var bodyCnsSysOut = 0f
    @Volatile var bodyFullSysOut = 0f

    // Hormone fixing frequency
    @Volatile var hormoneOn = true
    @Volatile var hormoneHz = 8f
    @Volatile var hormoneHzThr = 0.22f
    @Volatile var hormoneLv = 0.75f
    @Volatile var hormoneOut = 0f

    // Full-body bad Hz threshold
    @Volatile var badBodyHzThr = 15f
    @Volatile var badBodyHzOut = 0f
    @Volatile var badBodyActive = false
    @Volatile var badBodyFullScanOn = true
    @Volatile var badBodyFullOut = 0f

    // Particles threshold (full body)
    @Volatile var particlesOn = true
    @Volatile var particlesThr = 0.30f
    @Volatile var particlesLv = 0.75f
    @Volatile var particlesOut = 0f
    @Volatile var particlesAutoThr = true

    // Full body model scan
    @Volatile var modelScanOn = true
    @Volatile var modelScanThr = 0.25f
    @Volatile var modelScanLv = 0.85f
    @Volatile var modelScanOut = 0f
    @Volatile var modelScanRegions = 0
    @Volatile var modelScanActive = false

    // Level repair · face/body whitening · body brightening · sensors · BLE regen mix
    @Volatile var levelRepairOn = true
    @Volatile var levelRepairThr = 0.22f
    @Volatile var levelRepairLv = 0.85f
    @Volatile var levelRepairOut = 0f

    @Volatile var faceWhitenOn = true
    @Volatile var faceWhitenThr = 0.25f
    @Volatile var faceWhitenLv = 0.80f
    @Volatile var faceWhitenOut = 0f

    @Volatile var bodyWhitenOn = true
    @Volatile var bodyWhitenThr = 0.25f
    @Volatile var bodyWhitenLv = 0.80f
    @Volatile var bodyWhitenOut = 0f

    @Volatile var bodyBrightOn = true
    @Volatile var bodyBrightThr = 0.25f
    @Volatile var bodyBrightLv = 0.85f
    @Volatile var bodyBrightOut = 0f

    @Volatile var allSensorMixOn = true
    @Volatile var allSensorOut = 0f

    @Volatile var bleRegenMixOn = true
    @Volatile var bleRegenMixOut = 0f

    // BLE watt power mixer
    @Volatile var bleOn = true
    @Volatile var bleWatt = 0f
    @Volatile var thyroidOut = 0f
    @Volatile var bleWattMax = 10f
    @Volatile var bleWattThr = 0.5f
    @Volatile var bleWattOut = 0f
    @Volatile var bleMixMic = 0.5f
    @Volatile var bleMixModel = 0.3f
    @Volatile var bleMixSensor = 0.2f
    @Volatile var bleMixCamera = 0.2f

    // Mixer sources (set from outside)
    @Volatile var micE = 0f
    @Volatile var modelE = 0f
    @Volatile var sensorE = 0f
    @Volatile var cameraE = 0f
    @Volatile var liveCentroidHz = 0f

    @Volatile var status = "BODY Hz·REGEN idle"

    private fun mapHz(e: Float, lo: Float, hi: Float) =
        (lo + e.coerceIn(0f, 1f) * (hi - lo).coerceAtLeast(0.01f)).coerceIn(lo, hi)

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick() {
        if (!enabled) {
            status = "BODY Hz·REGEN OFF"
            return
        }
        val e = maxOf(micE, modelE * 0.8f, sensorE * 0.6f, cameraE * 0.6f).coerceIn(0f, 1f)

        // Body Hz from live centroid if in band else energy-map
        bodyHz = if (liveCentroidHz in bodyHzMin..bodyHzMax) liveCentroidHz
        else mapHz(e, bodyHzMin, bodyHzMax.coerceIn(1f, 50f))
        bodyHzOut = (bodyHz / bodyHzMax.coerceAtLeast(1f)).coerceIn(0f, 1f)

        // Infection Hz — energy in infection band
        infectionHz = bodyHz
        infectionActive = infectionOn && bodyHz in infectionBandLo..infectionBandHi &&
            bodyHz >= infectionHzThr
        infectionOut = if (infectionActive) ((bodyHz - infectionHzThr) / (infectionBandHi - infectionHzThr).coerceAtLeast(1f)).coerceIn(0f, 1f) else 0f

        // Damage cell
        damageCellHz = bodyHz
        damageCellActive = damageCellOn && bodyHz >= damageCellHzThr
        damageCellOut = if (damageCellActive) ((bodyHz - damageCellHzThr) / (bodyHzMax - damageCellHzThr).coerceAtLeast(1f)).coerceIn(0f, 1f) * e else 0f

        // Bad body Hz
        badBodyActive = bodyHz >= badBodyHzThr
        badBodyHzOut = if (badBodyActive) ((bodyHz - badBodyHzThr) / (bodyHzMax - badBodyHzThr).coerceAtLeast(1f)).coerceIn(0f, 1f) else 0f
        // Fully body bad Hz (combine infection + damage + bad)
        badBodyFullOut = if (badBodyFullScanOn) maxOf(badBodyHzOut, infectionOut, damageCellOut) else badBodyHzOut

        // Particles threshold — live energy + bad
        if (particlesAutoThr) {
            particlesThr = (0.12f + e * 0.25f).coerceIn(0.08f, 0.55f)
        }
        particlesOut = lane(particlesOn, particlesThr, particlesLv, maxOf(e, badBodyFullOut * 0.8f))

        // Full body model scan
        modelScanActive = modelScanOn && modelE >= modelScanThr.coerceIn(0.05f, 1f)
        modelScanOut = lane(modelScanOn, modelScanThr, modelScanLv, modelE)
        modelScanRegions = if (modelScanActive || rawComplete) 84 else (if (modelScanOut > 0.05f) (modelScanOut * 84).toInt() else 0)

        // Good frequency — in good band
        goodActive = goodFreqOn && bodyHz in goodHzLo..goodHzHi
        goodHzOut = if (goodActive) lane(true, goodHzThr, 1f, e) else 0f

        // Repair: stronger when NOT in bad/infection, or to counteract bad
        val needRepair = badBodyActive || infectionActive || damageCellActive
        val repairDrive = if (needRepair) e * 1.15f else e * 0.5f
        // proximity of bodyHz to repairHz target
        val repairProx = 1f - (kotlin.math.abs(bodyHz - repairHz) / bodyHzMax.coerceAtLeast(1f)).coerceIn(0f, 1f)
        repairOut = lane(repairOn, repairHzThr, repairLv, maxOf(repairDrive, repairProx * e))

        // Regeneration adjustable Hz
        val regenProx = 1f - (kotlin.math.abs(bodyHz - regenHz) / bodyHzMax.coerceAtLeast(1f)).coerceIn(0f, 1f)
        regenOut = lane(regenOn, regenHzThr, regenLv, maxOf(e, regenProx * e, if (needRepair) repairOut else 0f))

        // Our own regeneration frequency — full mixer
        val ownProx = 1f - (kotlin.math.abs(bodyHz - ownRegenHz) / bodyHzMax.coerceAtLeast(1f)).coerceIn(0f, 1f)
        val ownMix = (
            micE * ownRegenMixMic +
            modelE * ownRegenMixModel +
            sensorE * ownRegenMixSensor +
            cameraE * ownRegenMixCamera +
            bleWattOut * ownRegenMixBle +
            repairOut * ownRegenMixRepair +
            neuronRegenOut * ownRegenMixNeuron * 0f + // filled after neuron computed — see below
            0f
        ).coerceIn(0f, 2f)
        // provisional; finalized after neuron/hormone
        ownRegenOut = lane(ownRegenOn, ownRegenThr, ownRegenLv, maxOf(ownMix * 0.5f, ownProx * e, regenOut * 0.7f))

        // Brain neuron regen
        val neuronProx = 1f - (kotlin.math.abs(bodyHz - neuronRegenHz.coerceIn(0f, 50f)) / 50f).coerceIn(0f, 1f)
        neuronRegenOut = lane(neuronRegenOn, neuronRegenThr, neuronRegenLv, maxOf(e * 0.9f, neuronProx * e))

        // Healing frequency (mapped target near body band)
        val healTarget = healingHzMapped.coerceIn(0f, bodyHzMax)
        val healProx = 1f - (kotlin.math.abs(bodyHz - healTarget) / bodyHzMax.coerceAtLeast(1f)).coerceIn(0f, 1f)
        healingOut = lane(healingOn, healingThr, healingLv, maxOf(e, healProx * e, repairOut * 0.6f, ownRegenOut * 0.5f))

        // Brain bands — proximity of bodyHz to each band center
        fun bandOut(on: Boolean, center: Float, halfWidth: Float): Float {
            if (!on && !rawComplete) return 0f
            val prox = 1f - (kotlin.math.abs(bodyHz - center) / halfWidth.coerceAtLeast(0.5f)).coerceIn(0f, 1f)
            return lane(true, brainBandThr, brainBandLv, maxOf(e * 0.7f, prox * e))
        }
        brainDeltaOut = bandOut(brainDeltaOn, brainDeltaHz, 2f)
        brainThetaOut = bandOut(brainThetaOn, brainThetaHz, 2f)
        brainAlphaOut = bandOut(brainAlphaOn, brainAlphaHz, 2f)
        brainBetaOut = bandOut(brainBetaOn, brainBetaHz, 8f)
        brainGammaOut = bandOut(brainGammaOn, brainGammaHz, 10f)
        brainSmrOut = bandOut(brainSmrOn, brainSmrHz, 2f)
        brainFullOut = maxOf(brainDeltaOut, brainThetaOut, brainAlphaOut, brainBetaOut, brainGammaOut, brainSmrOut, neuronRegenOut)

        // Brain structures (proximity weights from energy + bands)
        fun sOut(weight: Float): Float =
            if (!brainStructuresOn && !rawComplete) 0f
            else lane(true, brainStructThr, brainStructLv, (e * weight + brainFullOut * (1f - weight * 0.5f)).coerceIn(0f, 1f))
        brainFrontalOut = sOut(0.95f)
        brainParietalOut = sOut(0.85f)
        brainTemporalOut = sOut(0.80f)
        brainOccipitalOut = sOut(0.75f)
        brainCerebellumOut = sOut(0.70f)
        brainThalamusOut = sOut(0.88f)
        brainHippocampusOut = sOut(0.82f)
        brainInsulaOut = sOut(0.78f)
        brainCingulateOut = sOut(0.80f)
        brainBasalOut = sOut(0.72f)
        brainAmygdalaOut = sOut(0.76f)
        brainHypothalamusOut = sOut(0.84f)
        brainBrainstemOut = sOut(0.90f)
        brainPituitaryOut = sOut(0.74f)
        brainPinealOut = sOut(0.70f)
        brainCallosumOut = sOut(0.86f)
        brainLHemOut = sOut(0.92f)
        brainRHemOut = sOut(0.92f)
        brainFullOut = maxOf(brainFullOut, brainFrontalOut, brainLHemOut, brainRHemOut, brainBrainstemOut)


        // Hormone fix
        val hormProx = 1f - (kotlin.math.abs(bodyHz - hormoneHz) / bodyHzMax.coerceAtLeast(1f)).coerceIn(0f, 1f)
        hormoneOut = lane(hormoneOn, hormoneHzThr, hormoneLv, maxOf(e * 0.85f, hormProx * e))

        // Finalize our own regen with full stack mix
        if (ownRegenOn || rawComplete) {
            val fullMix = (
                micE * ownRegenMixMic +
                modelE * ownRegenMixModel +
                sensorE * ownRegenMixSensor +
                cameraE * ownRegenMixCamera +
                bleWattOut * ownRegenMixBle +
                repairOut * ownRegenMixRepair +
                neuronRegenOut * ownRegenMixNeuron +
                hormoneOut * ownRegenMixHormone +
                regenOut * 0.35f +
                goodHzOut * 0.25f
            ).coerceIn(0f, 2.5f)
            val ownProx2 = 1f - (kotlin.math.abs(bodyHz - ownRegenHz) / bodyHzMax.coerceAtLeast(1f)).coerceIn(0f, 1f)
            ownRegenOut = lane(true, ownRegenThr, ownRegenLv, maxOf(fullMix, ownProx2 * e, if (rawComplete) e else 0f))
        } else ownRegenOut = 0f

        // BLE watt power from mixers
        if (bleOn) {
            val mix =
                (micE * bleMixMic + modelE * bleMixModel + sensorE * bleMixSensor + cameraE * bleMixCamera)
                    .coerceIn(0f, 2f)
            bleWatt = (mix * bleWattMax).coerceIn(0f, bleWattMax)
            bleWattOut = if (bleWatt >= bleWattThr) (bleWatt / bleWattMax.coerceAtLeast(0.01f)).coerceIn(0f, 1f) else 0f
        } else {
            bleWatt = 0f; bleWattOut = 0f
        }

        // Level repair (from repair + own regen + healing)
        levelRepairOut = lane(levelRepairOn, levelRepairThr, levelRepairLv,
            maxOf(repairOut, ownRegenOut, healingOut, goodHzOut))

        // All sensors mix
        allSensorOut = if (allSensorMixOn) maxOf(micE, modelE, sensorE, cameraE, bleWattOut).coerceIn(0f, 1f) else 0f

        // Face / body whitening + brightening (driven by heal + good + sensor)
        val toneDrive = maxOf(healingOut, goodHzOut, allSensorOut * 0.7f, levelRepairOut * 0.6f)
        faceWhitenOut = lane(faceWhitenOn, faceWhitenThr, faceWhitenLv, toneDrive)
        bodyWhitenOut = lane(bodyWhitenOn, bodyWhitenThr, bodyWhitenLv, toneDrive)
        bodyBrightOut = lane(bodyBrightOn, bodyBrightThr, bodyBrightLv, maxOf(toneDrive, allSensorOut))

        // BLE mixers regeneration
        bleRegenMixOut = if (bleRegenMixOn) {
            (bleWattOut * 0.5f + ownRegenOut * 0.35f + regenOut * 0.25f + repairOut * 0.25f).coerceIn(0f, 1f)
        } else 0f

        // Complete body organ systems (drive from e + repair/heal/own)
        val sysDrive = maxOf(e, levelRepairOut, healingOut, ownRegenOut, goodHzOut)
        fun bOut(w: Float): Float =
            if (!bodySystemsOn && !rawComplete) 0f
            else lane(true, bodySysThr, bodySysLv, (sysDrive * w).coerceIn(0f, 1f))
        bodyHeartSysOut = bOut(1.0f)
        bodyLungSysOut = bOut(0.92f)
        bodyLiverSysOut = bOut(0.88f)
        bodyKidneySysOut = bOut(0.85f)
        bodySpineSysOut = bOut(0.90f)
        bodyGutSysOut = bOut(0.86f)
        bodyImmuneSysOut = bOut(0.80f)
        bodySkinSysOut = bOut(0.95f)
        bodyMuscleSysOut = bOut(0.88f)
        bodyBoneSysOut = bOut(0.82f)
        bodyCnsSysOut = bOut(0.98f)
        bodyFullSysOut = maxOf(
            bodyHeartSysOut, bodyLungSysOut, bodyLiverSysOut, bodyKidneySysOut,
            bodySpineSysOut, bodyGutSysOut, bodyImmuneSysOut, bodySkinSysOut,
            bodyMuscleSysOut, bodyBoneSysOut, bodyCnsSysOut
        )

        status =
            "BODY ${"%.1f".format(bodyHz)}Hz · " +
            "INF ${if (infectionActive) "HIT" else "-"} ${"%.1f".format(infectionHz)} · " +
            "DMG ${if (damageCellActive) "HIT" else "-"} · BAD ${if (badBodyActive) "HIT" else "-"} · " +
            "GOOD ${if (goodActive) "OK" else "-"} · " +
            "REPAIR=${(repairOut*100).toInt()}% REGEN=${(regenOut*100).toInt()}% " +
            "REPAIR=${(repairOut*100).toInt()}% HEAL=${(healingOut*100).toInt()}% · BRAIN δ=${(brainDeltaOut*100).toInt()} θ=${(brainThetaOut*100).toInt()} α=${(brainAlphaOut*100).toInt()} β=${(brainBetaOut*100).toInt()} γ=${(brainGammaOut*100).toInt()} SMR=${(brainSmrOut*100).toInt()} · NEURON=${(neuronRegenOut*100).toInt()}% HORM=${(hormoneOut*100).toInt()}% OWN=${(ownRegenOut*100).toInt()}% · " +
            "BLE ${"%.2f".format(bleWatt)}W/${"%.0f".format(bleWattMax)}" +
            " · BRN L/R=${(brainLHemOut*100).toInt()}/${(brainRHemOut*100).toInt()} F=${(brainFrontalOut*100).toInt()} · " +
            "SYS H=${(bodyHeartSysOut*100).toInt()} Lng=${(bodyLungSysOut*100).toInt()} CNS=${(bodyCnsSysOut*100).toInt()} FULL=${(bodyFullSysOut*100).toInt()}% · " +
            "LVL-REP=${(levelRepairOut*100).toInt()}% FACE-W=${(faceWhitenOut*100).toInt()}% BODY-W=${(bodyWhitenOut*100).toInt()}% " +
            "BRIGHT=${(bodyBrightOut*100).toInt()}% SNS=${(allSensorOut*100).toInt()}% BLE-REGEN=${(bleRegenMixOut*100).toInt()}% · " +
            "PART=${(particlesOut*100).toInt()}% SCAN=${modelScanRegions}/84 BAD-FULL=${(badBodyFullOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView, sb: SoundBankGuard) {
        if (!enabled) return
        // Bad / infection / damage → protect damp
        val bad = maxOf(infectionOut, damageCellOut, badBodyHzOut, badBodyFullOut)
        if (bad > 0.05f) {
            val k = (1f - bad * 0.9f).coerceIn(0.05f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
        }
        // Good / repair / regen → atomspare & atmosphere boost
        val heal = maxOf(goodHzOut, repairOut, healingOut, regenOut, neuronRegenOut, hormoneOut, ownRegenOut, brainFullOut)
        try {
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, heal * 0.85f)
            v.bodyAtmo3d.level = maxOf(v.bodyAtmo3d.level, heal)
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, heal * 0.9f)
            // Brain / head for neurons
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, neuronRegenOut)
            v.forehead.atmosphere = maxOf(v.forehead.atmosphere, neuronRegenOut * 0.9f, brainFullOut * 0.9f)
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, brainDeltaOut, brainThetaOut, brainAlphaOut, brainGammaOut,
                brainFrontalOut, brainLHemOut, brainRHemOut, brainBrainstemOut, brainFullOut)
            try {
                v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, brainFullOut, bodyFullSysOut)
            } catch (_: Throwable) {}
            try {
                v.heart.atmosphere = maxOf(v.heart.atmosphere, bodyHeartSysOut)
                v.belly.atmosphere = maxOf(v.belly.atmosphere, bodyGutSysOut, bodyLiverSysOut)
                v.skinAll.atmosphere = maxOf(v.skinAll.atmosphere, bodySkinSysOut)
                v.neck.atmosphere = maxOf(v.neck.atmosphere, bodySpineSysOut * 0.9f)
            } catch (_: Throwable) {}
            // Healing boosts center body
            v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, healingOut * 0.9f)
            v.skinAbdomen.atmosphere = maxOf(v.skinAbdomen.atmosphere, healingOut * 0.85f)
            // Heart / belly for hormone
            v.heart.atmosphere = maxOf(v.heart.atmosphere, hormoneOut * 0.9f)
            v.belly.atmosphere = maxOf(v.belly.atmosphere, hormoneOut * 0.85f)
            // Our own regen drives full-body atmospheric repair
            v.skinAll.atmosphere = maxOf(v.skinAll.atmosphere, ownRegenOut)
            v.completeAtomProtect.atomInsideOut = maxOf(v.completeAtomProtect.atomInsideOut, ownRegenOut * 0.95f)
            v.completeAtomProtect.atomOutsideOut = maxOf(v.completeAtomProtect.atomOutsideOut, ownRegenOut * 0.9f)
        } catch (_: Throwable) {}
        // BLE mix affects audio focus slightly
        if (bleWattOut > 0.05f) {
            sb.audioFocusOut = maxOf(sb.audioFocusOut, bleWattOut * 0.5f)
        }
        // Particles → region particle feel via atmosphere
        try {
            if (particlesOut > 0.02f) {
                v.bodyAtmo3d.waveLevel = maxOf(v.bodyAtmo3d.waveLevel, particlesOut)
                v.anatomy3d.wave = maxOf(v.anatomy3d.wave, particlesOut)
            }
            if (modelScanActive || modelScanOut > 0.05f) {
                v.body84FullHuman.enabled = true
                v.body84FullHuman.atomOut = maxOf(v.body84FullHuman.atomOut, modelScanOut)
            }
            // Level repair
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, levelRepairOut)
            // Face whitening → face/forehead colour/bright
            if (faceWhitenOut > 0.02f) {
                v.face.atmosphere = maxOf(v.face.atmosphere, faceWhitenOut)
                v.forehead.atmosphere = maxOf(v.forehead.atmosphere, faceWhitenOut)
                try {
                    v.anatomy3d.colourLevel = maxOf(v.anatomy3d.colourLevel, 0.5f + faceWhitenOut * 0.5f)
                    v.anatomy3d.xray = maxOf(v.anatomy3d.xray, 0.4f + faceWhitenOut * 0.3f)
                } catch (_: Throwable) {}
            }
            // Body whitening + brightening
            if (bodyWhitenOut > 0.02f || bodyBrightOut > 0.02f) {
                val w = maxOf(bodyWhitenOut, bodyBrightOut)
                v.skinAll.atmosphere = maxOf(v.skinAll.atmosphere, w)
                v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, w)
                try {
                    v.anatomy3d.colourLevel = maxOf(v.anatomy3d.colourLevel, 0.5f + bodyBrightOut * 0.5f)
                    v.anatomy3d.xray = maxOf(v.anatomy3d.xray, 0.4f + bodyWhitenOut * 0.35f)
                } catch (_: Throwable) {}
            }
            // BLE regen mix → own regen path
            if (bleRegenMixOut > 0.02f) {
                ownRegenOut = maxOf(ownRegenOut, bleRegenMixOut)
                v.completeAtomProtect.atomInsideOut = maxOf(v.completeAtomProtect.atomInsideOut, bleRegenMixOut)
            }
        } catch (_: Throwable) {}
    }
}
