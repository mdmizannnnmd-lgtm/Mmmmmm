package com.mizan

import kotlin.math.max
import kotlin.math.min

/**
 * RINGS + BALLS AS 3D ANATOMY — every ring and ball of the app's body regions (forehead, face, nose, eye balls,
 * brows, lips, tongue, brain L/R, neck, heart, belly, hands, legs, glutes, pelvis) is anchored on the complete 3D
 * anatomy body ([AnatomyModel3D]) instead of floating flat on the screen:
 *
 *   · an OUTSIDE ring + ball sits on the skin / face surface,
 *   · an INSIDE ring + ball sits on the organ / bone / brain structure under it,
 *   · both turn with the same turntable as the anatomy, with perspective, depth sorting and front-facing fade,
 *   · the optional "connector" line links each outside ring to its inside organ.
 *
 * Energy per ring = the region's own ambient (same formula as the old flat rings) shaped by two [SignalPath]s —
 * one INSIDE, one OUTSIDE — with threshold · level · degains · bipolar ±120 dB rails · attack / release.
 *
 * RAW COMPLETE: both paths are raw, region ambient is passed through untouched (no FX scale, no bipolar / atmosphere
 * soft mix), every ring and ball on both layers is drawn, and the colour tuning is bypassed.
 *
 * Stylised visualisation positions on a procedural model — not a medical or measured model of anyone's body.
 */
class AnatomyRingBoard {

    /** A point on the body model, body units (y up, +z toward the viewer, left = −x), plus a surface normal. */
    class Anchor(
        val x: Float, val y: Float, val z: Float,
        val r: Float,
        val nx: Float = 0f, val ny: Float = 0f, val nz: Float = 1f
    )

    class Ring(
        val key: String,
        val label: String,
        val group: Int,
        val outside: Anchor,
        val inside: Anchor,
        val color: Int,        // outside ring / ball colour (the region's own colour)
        val inColor: Int,      // inside ring / ball colour (organ / bone colour)
        val eye: Boolean = false,
        val heart: Boolean = false
    ) {
        @Volatile var on = true
        @Volatile var level = 1.0f
        @Volatile var region: VisualShieldView.Region? = null
        @Volatile var energy = 0f
        @Volatile var outOut = 0f
        @Volatile var inOut = 0f
    }

    companion object {
        const val G_HEAD = 0
        const val G_EYES = 1
        const val G_BRAIN = 2
        const val G_TORSO = 3
        const val G_LIMBS = 4
        const val G_PELVIS = 5
        const val GROUP_COUNT = 6
        val GROUP_NAMES = arrayOf(
            "Head · face (forehead · face · nose · lips · tongue)",
            "Eyes (eye balls · brows)",
            "Brain (left + right ball)",
            "Torso (neck · heart · belly)",
            "Limbs (hands · legs)",
            "Pelvis · glutes"
        )

        private fun a(x: Float, y: Float, z: Float, r: Float, nx: Float = 0f, ny: Float = 0f, nz: Float = 1f) =
            Anchor(x, y, z, r, nx, ny, nz)

        /** Body84 channel anchor in body units (same placement the ARCore GPU body uses). */
        private fun channelAnchor(index: Int, name: String): FloatArray {
            val label = name.lowercase()
            val side = if (label.contains("left")) -1f else 1f
            return when {
                label.contains("head") -> floatArrayOf(0f, 1.51f, 0.02f)
                label.contains("eye") -> floatArrayOf(side * 0.075f, 1.53f, 0.13f)
                label.contains("jaw") -> floatArrayOf(0f, 1.39f, 0.12f)
                label.contains("neck") -> floatArrayOf(0f, 1.25f, 0.02f)
                label.contains("shoulder") -> floatArrayOf(side * 0.37f, 1.02f, 0f)
                label.contains("upperarm") || label.contains("arm") -> floatArrayOf(side * 0.48f, 0.76f, 0f)
                label.contains("forearm") || label.contains("hand") -> floatArrayOf(side * 0.53f, 0.30f, 0f)
                label.contains("finger") || label.contains("thumb") || label.contains("middle") ||
                    label.contains("ring") || label.contains("little") ->
                    floatArrayOf(side * 0.57f, 0.08f + (index % 4) * 0.025f, 0.02f)
                label.contains("leg") || label.contains("foot") || label.contains("toe") ->
                    floatArrayOf(side * 0.16f, if (label.contains("foot") || label.contains("toe")) -0.82f else -0.42f, 0.02f)
                label.contains("hip") -> floatArrayOf(0f, 0.22f, 0f)
                label.contains("chest") -> floatArrayOf(0f, 0.84f, 0.02f)
                label.contains("spine") -> floatArrayOf(0f, 0.45f + (index % 3) * 0.14f, -0.01f)
                else -> floatArrayOf(0f, -0.75f + (index % 9) * 0.22f, 0f)
            }
        }
    }

    val rings: List<Ring> = listOf(
        // ── head · face ──────────────────────────────────────────────────────────
        Ring("forehead", "Forehead", G_HEAD,
            a(0f, 1.655f, 0.130f, 0.060f, 0f, 0.25f, 1f), a(0f, 1.620f, 0.095f, 0.050f, 0f, 0.2f, 1f),
            0xFFFFE082.toInt(), 0xFFF1EBD8.toInt()),
        Ring("face", "Face", G_HEAD,
            a(0f, 1.500f, 0.150f, 0.115f), a(0f, 1.540f, 0.060f, 0.095f),
            0xFFF5C26B.toInt(), 0xFFEDE7D4.toInt()),
        Ring("nose", "Nose", G_HEAD,
            a(0f, 1.487f, 0.178f, 0.030f), a(0f, 1.530f, 0.140f, 0.022f),
            0xFFFFAB91.toInt(), 0xFFF1EBD8.toInt()),
        Ring("lipU", "Upper lip", G_HEAD,
            a(0f, 1.425f, 0.153f, 0.034f), a(0f, 1.418f, 0.128f, 0.028f),
            0xFFE65064.toInt(), 0xFFFFFFFF.toInt()),
        Ring("lipL", "Lower lip", G_HEAD,
            a(0f, 1.402f, 0.151f, 0.034f), a(0f, 1.402f, 0.126f, 0.028f),
            0xFFE65064.toInt(), 0xFFFFFFFF.toInt()),
        Ring("tongue", "Tongue", G_HEAD,
            a(0f, 1.405f, 0.105f, 0.030f), a(0f, 1.370f, 0.030f, 0.030f, 0f, 1f, 0.2f),
            0xFFF48FB1.toInt(), 0xFFF48FB1.toInt()),
        // ── eyes ────────────────────────────────────────────────────────────────
        Ring("eyeL", "Left eye ball", G_EYES,
            a(-0.062f, 1.555f, 0.142f, 0.040f), a(-0.062f, 1.555f, 0.100f, 0.034f),
            0xFFB9F6CA.toInt(), 0xFFFFEB3B.toInt(), eye = true),
        Ring("eyeR", "Right eye ball", G_EYES,
            a(0.062f, 1.555f, 0.142f, 0.040f), a(0.062f, 1.555f, 0.100f, 0.034f),
            0xFFB9F6CA.toInt(), 0xFFFFEB3B.toInt(), eye = true),
        Ring("browL", "Left brow", G_EYES,
            a(-0.065f, 1.597f, 0.140f, 0.032f, 0f, 0.3f, 1f), a(-0.065f, 1.600f, 0.105f, 0.028f),
            0xFFB48C5A.toInt(), 0xFFEDE7D4.toInt()),
        Ring("browR", "Right brow", G_EYES,
            a(0.065f, 1.597f, 0.140f, 0.032f, 0f, 0.3f, 1f), a(0.065f, 1.600f, 0.105f, 0.028f),
            0xFFB48C5A.toInt(), 0xFFEDE7D4.toInt()),
        // ── brain balls (outside ring on the scalp, inside ball = hemisphere) ──────
        Ring("brainL", "Left brain ball", G_BRAIN,
            a(-0.055f, 1.655f, 0.000f, 0.075f, -0.2f, 1f, 0.1f), a(-0.045f, 1.580f, 0.000f, 0.065f),
            0xFF4FC3F7.toInt(), 0xFF4FC3F7.toInt()),
        Ring("brainR", "Right brain ball", G_BRAIN,
            a(0.055f, 1.655f, 0.000f, 0.075f, 0.2f, 1f, 0.1f), a(0.045f, 1.580f, 0.000f, 0.065f),
            0xFFFFB74D.toInt(), 0xFFFFB74D.toInt()),
        // ── torso ───────────────────────────────────────────────────────────────
        Ring("neck", "Neck", G_TORSO,
            a(0f, 1.240f, 0.105f, 0.075f), a(0f, 1.210f, 0.050f, 0.040f),
            0xFF9CCC65.toInt(), 0xFFB3E5FC.toInt()),
        Ring("heart", "Heart", G_TORSO,
            a(-0.050f, 0.860f, 0.185f, 0.095f), a(-0.040f, 0.860f, 0.075f, 0.075f),
            0xFFFF5252.toInt(), 0xFFFF1744.toInt(), heart = true),
        Ring("belly", "Belly", G_TORSO,
            a(0f, 0.420f, 0.175f, 0.125f), a(0f, 0.400f, 0.075f, 0.095f),
            0xFFFFAB40.toInt(), 0xFFFF8A65.toInt()),
        // ── limbs ───────────────────────────────────────────────────────────────
        Ring("handL", "Left hand", G_LIMBS,
            a(-0.560f, -0.050f, 0.045f, 0.075f), a(-0.565f, 0.000f, 0.000f, 0.045f),
            0xFF7986CB.toInt(), 0xFFEDE7D4.toInt()),
        Ring("handR", "Right hand", G_LIMBS,
            a(0.560f, -0.050f, 0.045f, 0.075f), a(0.565f, 0.000f, 0.000f, 0.045f),
            0xFF7986CB.toInt(), 0xFFEDE7D4.toInt()),
        Ring("legL", "Left leg", G_LIMBS,
            a(-0.160f, -0.080f, 0.150f, 0.130f), a(-0.160f, -0.070f, 0.040f, 0.055f),
            0xFF42A5F5.toInt(), 0xFFF1EBD8.toInt()),
        Ring("legR", "Right leg", G_LIMBS,
            a(0.160f, -0.080f, 0.150f, 0.130f), a(0.160f, -0.070f, 0.040f, 0.055f),
            0xFF42A5F5.toInt(), 0xFFF1EBD8.toInt()),
        // ── pelvis · glutes ─────────────────────────────────────────────────────
        Ring("ass", "Glutes (back)", G_PELVIS,
            a(0f, 0.100f, -0.160f, 0.140f, 0f, 0f, -1f), a(0f, 0.105f, -0.085f, 0.070f, 0f, 0f, -1f),
            0xFF26C6DA.toInt(), 0xFFDCD3B6.toInt()),
        Ring("pussy", "Pelvis L", G_PELVIS,
            a(-0.060f, 0.090f, 0.140f, 0.070f), a(-0.030f, 0.100f, 0.070f, 0.045f),
            0xFFFF80AB.toInt(), 0xFFFFF176.toInt()),
        Ring("dick", "Pelvis R", G_PELVIS,
            a(0.060f, 0.090f, 0.140f, 0.070f), a(0.030f, 0.100f, 0.070f, 0.045f),
            0xFF82B1FF.toInt(), 0xFFFFF176.toInt())
    )

    // ── master + draw switches ─────────────────────────────────────────────────────
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var replace2d = true            // hide the old flat 2D rings / balls while the 3D ones are drawn
    @Volatile var ringsOn = true
    @Volatile var ballsOn = true
    @Volatile var insideOn = true
    @Volatile var outsideOn = true
    @Volatile var connectorsOn = true
    @Volatile var labelsOn = false
    @Volatile var eyeDetailOn = true          // iris + pupil on the outside eye balls
    @Volatile var channelBallsOn = true       // the 84 body channels as small balls on the body

    // ── levels / sizes ─────────────────────────────────────────────────────────────
    @Volatile var ringLevel = 0.90f
    @Volatile var ballLevel = 0.85f
    @Volatile var insideLevel = 1.0f
    @Volatile var outsideLevel = 1.0f
    @Volatile var ringScale = 1.0f
    @Volatile var ballScale = 1.0f
    @Volatile var ringWidth = 1.0f
    @Volatile var channelScale = 1.0f

    val groupOn = BooleanArray(GROUP_COUNT) { true }
    val groupLevel = FloatArray(GROUP_COUNT) { 1.0f }

    // ── signal paths + visual ──────────────────────────────────────────────────────
    val inside = SignalPath().also { it.thr = 0.10f; it.level = 0.85f }
    val outside = SignalPath().also { it.thr = 0.10f; it.level = 0.85f }
    val tuning = VisualShieldView.EyeTuning()
    @Volatile var colourLevel = 1.0f

    // ── Body84 channel balls ───────────────────────────────────────────────────────
    val channelAnchors: Array<FloatArray> =
        Array(Body84Channels.NAMES.size) { i -> channelAnchor(i, Body84Channels.NAMES[i]) }
    val channelOut = FloatArray(Body84Channels.NAMES.size)

    // ── live readouts ──────────────────────────────────────────────────────────────
    @Volatile var activeRings = 0
    @Volatile var activeChannels = 0
    @Volatile var rawAll = false
        private set

    fun setRawAll(on: Boolean) {
        rawComplete = on
        rawAll = on
        inside.raw = on; outside.raw = on
    }

    /** −1 left rings, +1 right rings, 0 centre (the more protected side). */
    private fun sideScale(key: String, scaleL: Float, scaleR: Float): Float = when (key) {
        "eyeL", "browL", "brainL", "handL", "legL", "pussy" -> scaleL
        "eyeR", "browR", "brainR", "handR", "legR", "dick" -> scaleR
        else -> min(scaleL, scaleR)
    }

    private fun regionOf(v: VisualShieldView, key: String): VisualShieldView.Region = when (key) {
        "forehead" -> v.forehead
        "face" -> v.face
        "nose" -> v.nose
        "lipU" -> v.lipU
        "lipL" -> v.lipL
        "tongue" -> v.tongue
        "eyeL" -> v.eyeL
        "eyeR" -> v.eyeR
        "browL" -> v.browL
        "browR" -> v.browR
        "brainL", "brainR" -> v.brain
        "neck" -> v.neck
        "heart" -> v.heart
        "belly" -> v.belly
        "handL" -> v.handL
        "handR" -> v.handR
        "legL" -> v.legL
        "legR" -> v.legR
        "ass" -> v.ass
        "pussy" -> v.pussy
        else -> v.dick
    }

    /**
     * @param clamped   the view's live clamped ambient (0..1)
     * @param fxScale   region FX protect scale × sound-bank scale (ignored in RAW COMPLETE)
     */
    fun tick(
        v: VisualShieldView, clamped: Float, fxScale: Float, a: Anatomy3DBoard,
        scaleL: Float = 1f, scaleR: Float = 1f
    ) {
        val raw = rawComplete || a.rawAll
        inside.raw = raw
        outside.raw = raw
        val c = clamped.coerceIn(0f, 1f)
        var sum = 0f
        for (r in rings) {
            val reg = regionOf(v, r.key)
            r.region = reg
            var e = if (raw) reg.ambient.coerceIn(0f, 1f) * (0.35f + 0.65f * c)
            else reg.effectiveAmbient() * (0.35f + 0.65f * c) * fxScale.coerceIn(0f, 1.5f)
            if (r.key == "brainL") e = max(e, v.brain3d.left.out)
            if (r.key == "brainR") e = max(e, v.brain3d.right.out)
            if (!raw) e *= sideScale(r.key, scaleL, scaleR)   // screen-sounds pitch protection, left / right
            e = e.coerceIn(0f, 1f)
            r.energy = e
            sum += e
        }
        val mean = if (rings.isEmpty()) 0f else sum / rings.size
        val iOut = inside.tick(max(a.inside.out, mean))
        val oOut = outside.tick(max(a.outside.out, mean))
        var active = 0
        for (r in rings) {
            val e = r.energy
            if (raw) {
                r.outOut = e
                r.inOut = e
            } else {
                val gl = groupLevel[r.group].coerceIn(0f, 1.5f) * r.level.coerceIn(0f, 1.5f)
                r.outOut = (e * (0.40f + 0.60f * oOut) * outsideLevel.coerceIn(0f, 1.5f) * gl).coerceIn(0f, 1f)
                r.inOut = (e * (0.40f + 0.60f * iOut) * insideLevel.coerceIn(0f, 1.5f) * gl).coerceIn(0f, 1f)
            }
            if (r.on && max(r.outOut, r.inOut) > 0.05f) active++
        }
        activeRings = active

        val ch = v.body84.channels
        var activeCh = 0
        for (i in 0 until min(ch.size, channelOut.size)) {
            val an = channelAnchors[i]
            val o = (ch[i].out * v.cenDrive.channelGain(v, an[0], an[1])).coerceIn(0f, 1f)
            channelOut[i] = o
            if (o > 0.12f) activeCh++
        }
        activeChannels = activeCh
    }

    fun statusLine(): String {
        if (!enabled) return "RINGS + BALLS 3D off"
        return "RINGS + BALLS 3D · in ${(inside.out * 100).toInt()}%" +
            (if (inside.overHit) " OVER" else "") + " · out ${(outside.out * 100).toInt()}%" +
            (if (outside.overHit) " OVER" else "") + " · rings $activeRings/${rings.size} · " +
            (if (channelBallsOn) "ch $activeChannels/${channelOut.size} · " else "") +
            (if (replace2d) "replaces 2D" else "with 2D") +
            (if (rawComplete || rawAll) " · RAW COMPLETE" else "")
    }
    fun apply(v: VisualShieldView?) { /* ring overlay state */ }

}
