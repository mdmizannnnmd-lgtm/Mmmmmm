package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object MicLiveAmbientMixerPanels {
    fun build(ctx: Context, root: LinearLayout, b: MicLiveAmbientMixerBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFA5D6A7.toInt()
        p.title("MIC LIVE AMBIENT MIXER · ALL AMBIENT ROUTES", c)
        p.note("Live mic → skin · bio · gland · chem · atom · protect · master · ear · eye · motion")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Mic live ambient ON", b.micLiveOn) { b.micLiveOn = it }
        p.seek("Mic live thr", 0.05f, 0.98f, b.micLiveThr) { b.micLiveThr = it }
        p.seek("Mic live level", 0f, 1.5f, b.micLiveLv) { b.micLiveLv = it }
        p.seek("Mix skin", 0f, 1.5f, b.mixSkin) { b.mixSkin = it }
        p.seek("Mix bio / gland", 0f, 1.5f, b.mixBio) { b.mixBio = it; b.mixGland = it }
        p.seek("Mix chem", 0f, 1.5f, b.mixChem) { b.mixChem = it }
        p.seek("Mix atom", 0f, 1.5f, b.mixAtom) { b.mixAtom = it }
        p.seek("Mix protect", 0f, 1.5f, b.mixProtect) { b.mixProtect = it }
        p.seek("Mix master ambient", 0f, 1.5f, b.mixMaster) { b.mixMaster = it }
        p.seek("Mix ear / eye", 0f, 1.5f, b.mixEar) { b.mixEar = it; b.mixEye = it }
        p.seek("Mix motion", 0f, 1.5f, b.mixMotion) { b.mixMotion = it }
        val st = p.status("MIC MIX —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 200) }
        })
    }
}
