package com.mizan

/**
 * ARCore mesh world + point cloud on MAIN app (no separate page required).
 * Own codes: point density, plane H/V, confidence gate, ambient/protect feed.
 * Wraps [ArCoreMeasureBoard] live session stats. RAW COMPLETE.
 */
class CameraArMeshWorldBoard(private val ar: ArCoreMeasureBoard) {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var meshWorldOn = true
    @Volatile var pointCloudOn = true
    @Volatile var planesOn = true
    @Volatile var densityThr = 0.15f
    @Volatile var confThr = 0.25f
    @Volatile var protectOn = true
    @Volatile var protectLv = 0.7f

    // Own processed outputs
    @Volatile var pointCount = 0
    @Volatile var pointConf = 0f
    @Volatile var planeH = 0
    @Volatile var planeV = 0
    @Volatile var planeAll = 0
    @Volatile var pointDensity = 0f
    @Volatile var meshLive = 0f
    @Volatile var meshProtectOut = 0f
    @Volatile var trackingQ = 0f
    @Volatile var status = "AR MESH+POINTS main idle"

    fun tick() {
        if (!enabled) {
            status = "AR MESH OFF"
            return
        }
        ar.meshWorldOn = meshWorldOn
        ar.pointCloudOn = pointCloudOn

        pointCount = ar.pointCloudCount
        pointConf = ar.pointCloudConfidenceAvg
        planeH = ar.horizontalPlanes
        planeV = ar.verticalPlanes
        planeAll = ar.planeCount
        trackingQ = ar.trackingQuality

        // own density: normalize point count (soft scale)
        pointDensity = (pointCount / 800f).coerceIn(0f, 1.5f)
        val confOk = pointConf >= confThr
        val densOk = pointDensity >= densityThr
        meshLive = when {
            !ar.sessionRunning -> 0f
            !meshWorldOn && !pointCloudOn -> 0f
            else -> (
                (if (pointCloudOn && densOk) pointDensity * (0.4f + pointConf * 0.6f) else 0f) +
                (if (planesOn && planeAll > 0) (planeAll / 12f).coerceIn(0f, 1f) * 0.5f else 0f) +
                trackingQ * 0.25f
            ).coerceIn(0f, 1.5f)
        }
        if (rawComplete && ar.sessionRunning) meshLive = maxOf(meshLive, 0.35f + trackingQ * 0.4f)
        meshProtectOut = if (protectOn) (meshLive * protectLv).coerceIn(0f, 1f) else 0f

        status =
            if (!ar.sessionRunning) {
                "AR MAIN · session ${ar.trackingStateName}" +
                    (ar.lastError?.let { " · $it" } ?: " · enable tracking on main")
            } else {
                "AR MAIN mesh pts=$pointCount conf=${(pointConf*100).toInt()}% · " +
                "planes H/V/all=$planeH/$planeV/$planeAll · dens=${(pointDensity*100).toInt()}% · " +
                "live=${(meshLive*100).toInt()}% prot=${(meshProtectOut*100).toInt()}% · " +
                "q=${(trackingQ*100).toInt()}%" + if (rawComplete) " · RAW" else ""
            }
    }

    fun apply(v: VisualShieldView?) {
        if (!enabled || meshProtectOut < 0.02f) return
        val vv = v ?: return
        try {
            vv.fullAmbientMaster.ambientAll = maxOf(vv.fullAmbientMaster.ambientAll, meshLive * 0.25f)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, meshProtectOut * 0.5f)
            vv.anatomy3d.atmosphere = maxOf(vv.anatomy3d.atmosphere, meshLive * 0.2f)
            vv.finalProtectionMain.shield3dOut = maxOf(vv.finalProtectionMain.shield3dOut, meshProtectOut * 0.4f)
        } catch (_: Throwable) {}
    }
}
