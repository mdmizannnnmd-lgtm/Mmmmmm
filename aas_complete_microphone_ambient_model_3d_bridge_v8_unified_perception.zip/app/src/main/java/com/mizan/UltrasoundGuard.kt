package com.mizan

import kotlin.math.sqrt

/** Real low-band 0–50 Hz energy on mic PCM + protection damp. */
class UltrasoundGuard {
    @Volatile var enabled = true
    @Volatile var protectOn = true
    @Volatile var bandHz = 50f
    @Volatile var threshold = 0.35f
    @Volatile var level = 0.70f
    @Volatile var liveBand = 0f
    @Volatile var liveHz = 0f
    @Volatile var fire = false
    @Volatile var protectActive = false
    @Volatile var blockCount = 0
    private var smooth = 0f
    private val sampleRate = 44100

    fun processPcm(buf: ShortArray, n: Int) {
        if (n < 32) return
        val hz = bandHz.coerceIn(1f, 50f)
        val alpha = (2.0 * Math.PI * hz / sampleRate).toFloat().coerceIn(0.001f, 0.25f)
        var lp = 0f
        var energy = 0.0
        var zc = 0
        var prev = 0f
        for (i in 0 until n) {
            val x = buf[i] / 32768f
            lp += alpha * (x - lp)
            energy += (lp * lp).toDouble()
            if (i > 0 && ((prev >= 0 && lp < 0) || (prev < 0 && lp >= 0))) zc++
            prev = lp
        }
        val rms = sqrt(energy / n).toFloat()
        smooth = smooth * 0.85f + rms * 8f * 0.15f
        liveBand = smooth.coerceIn(0f, 1f)
        liveHz = liveHz * 0.9f + (zc * sampleRate / (2f * n)).coerceIn(0f, 50f) * 0.1f
        fire = enabled && liveBand >= threshold
        protectActive = fire && protectOn
        if (protectActive) blockCount++
    }

    fun protectDamp(): Float {
        if (!protectActive) return 0f
        return (level * ((liveBand - threshold) / maxOf(0.001f, 1f - threshold))).coerceIn(0f, 1f)
    }

    fun statusLine(): String {
        val st = when {
            protectActive -> "ULTRA-PROTECT"
            fire -> "ULTRA-FIRE"
            else -> "ultra-idle"
        }
        return "ULTRA 0–${bandHz.toInt()}Hz live=${(liveBand * 100).toInt()}% ~${liveHz.toInt()}Hz thr=${(threshold * 100).toInt()}% · $st · blk=$blockCount"
    }
}
