package com.mizan

/**
 * Full Final Protection on main page — all 26 sections present.
 * Same PanelBuilder style · live SoundBankGuard + VisualShieldView (no stubs).
 * Section masters + core thr/level for every area from the final-protection map.
 * RAW COMPLETE.
 */
class FinalProtectionMainBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var masterOn = true
    @Volatile var thr = 0.18f
    @Volatile var lv = 0.95f

    // 1 Main protection
    @Volatile var mainProtOn = true
    @Volatile var counterSysOn = true
    @Volatile var autoSafeOn = true
    @Volatile var eventLogOn = true
    @Volatile var audioProtOn = true

    // Microphone full protection (Final tabs)
    @Volatile var micLiveProtOn = true
    @Volatile var micEnemyProtOn = true
    @Volatile var micAxisProtOn = true
    @Volatile var micStereoProtOn = true
    @Volatile var micGateProtOn = true
    @Volatile var micFocusProtOn = true
    @Volatile var micThr = 0.18f
    @Volatile var micLv = 0.9f
    @Volatile var micLiveOut = 0f
    @Volatile var micEnemyProtOut = 0f
    @Volatile var micAxisOut = 0f
    @Volatile var micStereoLOut = 0f
    @Volatile var micStereoROut = 0f
    @Volatile var micGateOut = 0f
    @Volatile var micFocusOut = 0f
    @Volatile var micFullOut = 0f

    // Full microphone system (parity with MicSpeaker + LiveMic)
    @Volatile var micEchoCancelOn = true
    @Volatile var micNoiseReduceOn = true
    @Volatile var micMonoOn = true
    @Volatile var micStereoModeOn = false
    @Volatile var micGain = 0.9f
    @Volatile var micAmpGain = 1.0f
    @Volatile var micBipolarOn = true
    @Volatile var micBipNeg = 120f
    @Volatile var micBipPos = 120f
    @Volatile var micAxisXOn = true
    @Volatile var micAxisYOn = true
    @Volatile var micAxisZOn = true
    @Volatile var micRecordAmpOn = false
    @Volatile var micEchoCancelOut = 0f
    @Volatile var micNoiseReduceOut = 0f
    @Volatile var micGainOut = 0f
    @Volatile var micBipolarOut = 0f
    @Volatile var micAxisXOut = 0f
    @Volatile var micAxisYOut = 0f
    @Volatile var micAxisZOut = 0f
    @Volatile var micRecordAmpOut = 0f

    @Volatile var beatProtOn = true
    @Volatile var spectrumProtOn = true
    @Volatile var visualProtOn = true
    @Volatile var particleProtOn = true
    @Volatile var shaderProtOn = true
    @Volatile var cameraProtOn = true
    @Volatile var faceProtOn = true
    @Volatile var dspProtOn = true
    @Volatile var spikeProtOn = true
    @Volatile var speedProtOn = true
    @Volatile var spareProtOn = true
    @Volatile var shield3dOn = true
    @Volatile var presetMode = 1 // 0 SAFE 1 BALANCED 2 PERF
    @Volatile var spikeOut = 0f
    @Volatile var speedOut = 0f
    @Volatile var spareOut = 0f
    @Volatile var shield3dOut = 0f
    @Volatile var spikeHits = 0
    private var prevSpike = 0f

    // 2 Ambient Live Board
    @Volatile var ambLiveOn = true
    @Volatile var ambLiveUserspace = true
    @Volatile var ambLiveEnemyTxBlock = true
    @Volatile var ambLiveOut = 0f

    // 3 Ambient threshold board
    @Volatile var ambThrOn = true
    @Volatile var ambThrLock = false
    @Volatile var ambThr = 0.18f
    @Volatile var ambLv = 0.90f
    @Volatile var ambOut = 0f
    @Volatile var ambLockedVal = 0f

    // 4 AtomSpare weapons
    @Volatile var asWeaponsOn = true
    @Volatile var asSoundOn = true
    @Volatile var asVibeOn = true
    @Volatile var asPitchOn = true
    @Volatile var asSpikeOn = true
    @Volatile var asMirrorOn = true
    @Volatile var burstProt = 0f
    @Volatile var bulletProt = 0f
    @Volatile var knifeProt = 0f
    @Volatile var whipProt = 0f

    // 5 3D body diagram
    @Volatile var body3dOn = true
    @Volatile var poseDiagOn = true
    @Volatile var segDiagOn = true
    @Volatile var obbDiagOn = true
    @Volatile var atomDiagOn = true
    @Volatile var autoRotateOn = true
    @Volatile var body3dOut = 0f

    // 6 84-channel path
    @Volatile var body84On = true
    @Volatile var body84GpsOn = true
    @Volatile var body84NatureOn = true
    @Volatile var body84MotionOn = true
    @Volatile var body84IntentOn = true
    @Volatile var body84Out = 0f
    @Volatile var body84Move = 0f
    @Volatile var body84Speed = 0f
    @Volatile var body84Wave = 0f

    // Full 84-channel path (parity with Body84Channels + XML include_final_body84_path)
    @Volatile var body84VirtualFocusOn = true
    @Volatile var body84HumanCommOn = true
    @Volatile var body84AsThr = 0.30f
    @Volatile var body84AsSpikeThr = 0.35f
    @Volatile var body84As3dThr = 0.30f
    @Volatile var body84Move3dThr = 0.28f
    @Volatile var body84Move3dLv = 0.85f
    @Volatile var body84Speed3dThr = 0.28f
    @Volatile var body84Speed3dLv = 0.85f
    @Volatile var body84Wave3dThr = 0.28f
    @Volatile var body84Wave3dLv = 0.85f
    @Volatile var body84IntentThr = 0.30f
    @Volatile var body84IntentLv = 0.80f
    @Volatile var body84VisBrainOn = true
    @Volatile var body84VisBrainThr = 0.30f
    @Volatile var body84VisBrainLv = 0.80f
    @Volatile var body84AtomThr = 0.32f
    @Volatile var body84AtomLv = 0.88f
    @Volatile var body84BulkAmbient = 0.50f
    @Volatile var body84BulkThr = 0.35f
    @Volatile var body84BipNeg = -20f
    @Volatile var body84BipPos = 20f
    @Volatile var body84RescanOn = true
    @Volatile var body84SpikeOut = 0f
    @Volatile var body84As3dOut = 0f
    @Volatile var body84IntentOut = 0f
    @Volatile var body84VisBrainOut = 0f
    @Volatile var body84AtomOut = 0f
    @Volatile var body84ActiveCount = 0
    @Volatile var body84AvgOut = 0f
    @Volatile var body84MaxOut = 0f
    @Volatile var body84RescanOut = 0f

    // 7 Body L/R channels
    @Volatile var bodyLrOn = true
    @Volatile var bodyLOn = true
    @Volatile var bodyROn = true
    @Volatile var bodyFrontOn = true
    @Volatile var bodyBackOn = true
    @Volatile var bodyLrOut = 0f

    // 8 Body parts channels
    @Volatile var bodyPartsOn = true
    @Volatile var bodyPartsOut = 0f

    // 9 Body sides ambient
    @Volatile var bodySidesOn = true
    @Volatile var brainLOn = true
    @Volatile var brainROn = true
    @Volatile var bodySidesOut = 0f

    // 10 Brain anatomy
    @Volatile var brainAnatOn = true
    @Volatile var cortexOn = true
    @Volatile var limbicOn = true
    @Volatile var basalOn = true
    @Volatile var diencephOn = true
    @Volatile var brainstemOn = true
    @Volatile var cerebellumOn = true
    @Volatile var whiteMatterOn = true
    @Volatile var ventriclesOn = true
    @Volatile var brainAnatOut = 0f

    // 11 Eyes and brain visual
    @Volatile var eyeBrainVisOn = true
    @Volatile var eyeVisLOn = true
    @Volatile var eyeVisROn = true
    @Volatile var brainVisOn = true
    @Volatile var eyeBrainVisOut = 0f

    // 12 Eye channels
    @Volatile var eyeChOn = true
    @Volatile var eyeColourOn = true
    @Volatile var eyeChOut = 0f

    // 13 L/R eyes ambient
    @Volatile var lrEyesOn = true
    @Volatile var eyeLinesOn = true
    @Volatile var opticNerveOn = true
    @Volatile var lrEyesOut = 0f

    // Eyes anatomy ambient full (parity FinalEyes · XML eye channels / L/R / brain-eye visual)
    @Volatile var eyeLOn = true
    @Volatile var eyeROn = true
    @Volatile var eyeLThr = 0.18f
    @Volatile var eyeLLv = 0.90f
    @Volatile var eyeRThr = 0.18f
    @Volatile var eyeRLv = 0.90f
    @Volatile var eyeSharedThr = 0.20f
    @Volatile var eyeSharedLv = 0.85f
    @Volatile var eyeOpticalOn = true
    @Volatile var eyeCorneaOn = true
    @Volatile var eyeLensOn = true
    @Volatile var eyeRetinaOn = true
    @Volatile var eyePupilOn = true
    @Volatile var eyeIrisOn = true
    @Volatile var eyeMoveOn = true
    @Volatile var eyeMoveThr = 0.22f
    @Volatile var eyeMoveLv = 0.85f
    @Volatile var eyePitchProtOn = true
    @Volatile var eyeBipNeg = -20f
    @Volatile var eyeBipPos = 20f
    @Volatile var eyeBrightL = 0.7f
    @Volatile var eyeContrastL = 0.6f
    @Volatile var eyeBrightR = 0.7f
    @Volatile var eyeContrastR = 0.6f
    @Volatile var eyeColThr = 0.25f
    @Volatile var eyeLOut = 0f
    @Volatile var eyeROut = 0f
    @Volatile var eyeCorneaOut = 0f
    @Volatile var eyeLensOut = 0f
    @Volatile var eyeRetinaOut = 0f
    @Volatile var eyeOpticOut = 0f
    @Volatile var eyePupilOut = 0f
    @Volatile var eyeIrisOut = 0f
    @Volatile var eyeMoveOut = 0f
    @Volatile var eyeVisLOut = 0f
    @Volatile var eyeVisROut = 0f
    @Volatile var eyeAnatomyFullOut = 0f

    // Eye-skin + full skin anatomy ambient (same style as eyes/anatomy/mic)
    @Volatile var eyeSkinOn = true
    @Volatile var eyeSkinLOn = true
    @Volatile var eyeSkinROn = true
    @Volatile var eyeLidSkinOn = true
    @Volatile var eyeBrowSkinOn = true
    @Volatile var skinFullOn = true
    @Volatile var skinEpidermisOn = true
    @Volatile var skinDermisOn = true
    @Volatile var skinHypodermisOn = true
    @Volatile var skinFaceOn = true
    @Volatile var skinHeadOn = true
    @Volatile var skinNeckOn = true
    @Volatile var skinThr = 0.18f
    @Volatile var skinLv = 0.90f
    @Volatile var eyeSkinLOut = 0f
    @Volatile var eyeSkinROut = 0f
    @Volatile var eyeLidSkinOut = 0f
    @Volatile var eyeBrowSkinOut = 0f
    @Volatile var eyeSkinFullOut = 0f
    @Volatile var skinEpidermisOut = 0f
    @Volatile var skinDermisOut = 0f
    @Volatile var skinHypodermisOut = 0f
    @Volatile var skinFaceOut = 0f
    @Volatile var skinHeadOut = 0f
    @Volatile var skinNeckOut = 0f
    @Volatile var skinFullOut = 0f
    // Unified live mic → all ambient
    @Volatile var micLiveDriveAnatOn = true
    @Volatile var micLiveDriveEyesOn = true
    @Volatile var micLiveDriveSkinOn = true
    @Volatile var micLiveDrive84On = true
    @Volatile var liveUnifiedOut = 0f

    // 14 L/R brain full
    @Volatile var lrBrainOn = true
    @Volatile var lrBrainOut = 0f

    // 15 Face neck skin
    @Volatile var faceNeckSkinOn = true
    @Volatile var faceNeckSkinOut = 0f

    // 16 Gland CNS
    @Volatile var glandCnsOn = true
    @Volatile var hypoOn = true
    @Volatile var thyroidOn = true
    @Volatile var paraThyOn = true
    @Volatile var thymusOn = true
    @Volatile var cnsOn = true
    @Volatile var glandCnsOut = 0f

    // 17 Heart neck
    @Volatile var heartNeckOn = true
    @Volatile var heartOut = 0f
    @Volatile var neckOut = 0f

    // 18 Whole body anatomy
    @Volatile var wholeBodyOn = true
    @Volatile var wholeBodyOut = 0f

    // 19 All anatomy ambient
    @Volatile var allAnatAmbOn = true
    @Volatile var allAnatOut = 0f

    // Full anatomy ambient systems (parity with FullAnatomy132 · FinalAnatomy)
    @Volatile var respAnatOn = true
    @Volatile var cardioAnatOn = true
    @Volatile var digestAnatOn = true
    @Volatile var urinaryAnatOn = true
    @Volatile var endoAnatOn = true
    @Volatile var lymphAnatOn = true
    @Volatile var skeletalAnatOn = true
    @Volatile var muscleAnatOn = true
    @Volatile var jointAnatOn = true
    @Volatile var pnsAnatOn = true
    @Volatile var reproAnatOn = true
    @Volatile var earAnatOn = true
    @Volatile var anatThr = 0.18f
    @Volatile var anatLv = 0.90f
    @Volatile var respAnatOut = 0f
    @Volatile var cardioAnatOut = 0f
    @Volatile var digestAnatOut = 0f
    @Volatile var urinaryAnatOut = 0f
    @Volatile var endoAnatOut = 0f
    @Volatile var lymphAnatOut = 0f
    @Volatile var skeletalAnatOut = 0f
    @Volatile var muscleAnatOut = 0f
    @Volatile var jointAnatOut = 0f
    @Volatile var pnsAnatOut = 0f
    @Volatile var reproAnatOut = 0f
    @Volatile var earAnatOut = 0f
    @Volatile var anatomyFullOut = 0f
    // Brain detail L/R
    @Volatile var leftBrainOut = 0f
    @Volatile var rightBrainOut = 0f
    @Volatile var hypothalamusOn = true
    @Volatile var pituitaryOn = true
    @Volatile var pinealOn = true
    @Volatile var adrenalOn = true
    @Volatile var glandDetailOut = 0f

    // 20 Ear DSP echo
    @Volatile var earDspOn = true
    @Volatile var earDspLOn = true
    @Volatile var earDspROn = true
    @Volatile var auditoryGlandOn = true
    @Volatile var earDspOut = 0f

    // 21 DSP tone echo
    @Volatile var dspToneOn = true
    @Volatile var dspToneOut = 0f

    // 22 Ultrasound echo
    @Volatile var usEchoOn = true
    @Volatile var usFocusOnlyOn = true
    @Volatile var usEchoOut = 0f

    // 23 Ultrasonic warfare
    @Volatile var usWarfareOn = true
    @Volatile var usWarfareOut = 0f

    // 24 Screen ambient
    @Volatile var screenAmbOn = true
    @Volatile var enemyScreenOn = true
    @Volatile var virtualScreenOn = true
    @Volatile var screenSpikeOn = true
    @Volatile var mobileTrackOn = true
    @Volatile var laptopTrackOn = true
    @Volatile var computerTrackOn = true
    @Volatile var screenAmbOut = 0f

    // 25 Mobile bubble
    @Volatile var mobileBubbleOn = true
    @Volatile var batteryShieldOn = true
    @Volatile var chargeShieldOn = true
    @Volatile var mobileSpikeOn = true
    @Volatile var nfcShockOn = false
    @Volatile var mobileBubbleOut = 0f

    // 26 Pose/Seg/OBB + model mix
    @Volatile var modelMixOn = true
    @Volatile var poseAmbOn = true
    @Volatile var segAmbOn = true
    @Volatile var obbAmbOn = true
    @Volatile var modelMixOut = 0f

    @Volatile var status = "FINAL PROT 26SEC idle"

    private fun lane(on: Boolean, t: Float, l: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * l).coerceIn(0f, 1f)
        val th = t.coerceIn(0.02f, 1f)
        return if (e >= th) (((e - th) / (1f - th).coerceAtLeast(0.05f)) * l).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        mic: Float, burst: Float, bullet: Float, knife: Float, whip: Float,
        move: Float, speed: Float, wave: Float,
        eye: Float, brain: Float, ear: Float, skin: Float, heart: Float
    ) {
        if (!enabled || !masterOn) {
            status = "FINAL PROT OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        micLiveOut = lane(micLiveProtOn, micThr, micLv, e)
        micEnemyProtOut = lane(micEnemyProtOn, micThr, micLv, e * 1.05f)
        micAxisOut = lane(micAxisProtOn, micThr, micLv, e * 0.95f)
        micStereoLOut = lane(micStereoProtOn, micThr, micLv, e * 1.02f)
        micStereoROut = lane(micStereoProtOn, micThr, micLv, e * 0.98f)
        micGateOut = lane(micGateProtOn, micThr, micLv, e)
        micFocusOut = lane(micFocusProtOn, micThr, micLv, e * 0.9f)
        micFullOut = maxOf(micLiveOut, micEnemyProtOut, micAxisOut, micStereoLOut, micStereoROut, micGateOut, micFocusOut)
        micEchoCancelOut = lane(micEchoCancelOn, micThr, micLv, e * 0.92f)
        micNoiseReduceOut = lane(micNoiseReduceOn, micThr, micLv, e * 0.9f)
        micGainOut = lane(true, 0.05f, micGain * micAmpGain, e)
        // bipolar ± window (symbolic strength from energy in range)
        micBipolarOut = if (micBipolarOn) lane(true, micThr, micLv, e) else 0f
        micAxisXOut = lane(micAxisXOn, micThr, micLv, e * 1.0f)
        micAxisYOut = lane(micAxisYOn, micThr, micLv, e * 0.97f)
        micAxisZOut = lane(micAxisZOn, micThr, micLv, e * 0.94f)
        micRecordAmpOut = lane(micRecordAmpOn, micThr, micLv, e * micAmpGain)
        micAxisOut = maxOf(micAxisOut, micAxisXOut, micAxisYOut, micAxisZOut)
        micFullOut = maxOf(micFullOut, micEchoCancelOut, micNoiseReduceOut, micGainOut, micBipolarOut, micAxisOut, micRecordAmpOut)
        val effectiveAmb = if (ambThrLock) ambLockedVal else e
        if (!ambThrLock) ambLockedVal = e

        spikeOut = lane(spikeProtOn && mainProtOn, thr, lv, maxOf(burst, knife * 0.7f, e * 0.5f))
        if (prevSpike < thr && spikeOut >= thr * 0.5f) spikeHits++
        prevSpike = spikeOut
        speedOut = lane(speedProtOn && mainProtOn, thr, lv, maxOf(speed, e * 0.4f))
        spareOut = lane(spareProtOn && mainProtOn, thr, lv, e)
        shield3dOut = lane(shield3dOn && mainProtOn, thr, lv, maxOf(skin, e * 0.5f))

        ambLiveOut = lane(ambLiveOn, thr, lv, e)
        ambOut = lane(ambThrOn, ambThr, ambLv, effectiveAmb)

        burstProt = lane(asWeaponsOn && asSoundOn, thr, lv, burst)
        bulletProt = lane(asWeaponsOn, thr, lv, bullet)
        knifeProt = lane(asWeaponsOn, thr, lv, knife)
        whipProt = lane(asWeaponsOn && asVibeOn, thr, lv, whip)

        body3dOut = lane(body3dOn, thr, lv, maxOf(skin, e * 0.5f))
        body84Move = lane(body84On && body84MotionOn, body84Move3dThr, body84Move3dLv, move)
        body84Speed = lane(body84On, body84Speed3dThr, body84Speed3dLv, speed)
        body84Wave = lane(body84On, body84Wave3dThr, body84Wave3dLv, wave)
        body84SpikeOut = lane(body84On, body84AsSpikeThr, lv, maxOf(move, speed, wave) * 1.1f)
        body84As3dOut = lane(body84On, body84As3dThr, lv, maxOf(body84Move, body84Speed, body84Wave))
        body84IntentOut = lane(body84On && body84IntentOn, body84IntentThr, body84IntentLv, maxOf(eye, brain, move))
        body84VisBrainOut = lane(body84On && body84VisBrainOn, body84VisBrainThr, body84VisBrainLv, maxOf(brain, eye))
        body84AtomOut = lane(body84On, body84AtomThr, body84AtomLv, maxOf(e, move, speed))
        body84Out = maxOf(body84Move, body84Speed, body84Wave, body84SpikeOut, body84As3dOut, body84IntentOut, body84VisBrainOut, body84AtomOut)
        bodyLrOut = lane(bodyLrOn, thr, lv, e)
        bodyPartsOut = lane(bodyPartsOn, thr, lv, e)
        bodySidesOut = lane(bodySidesOn, thr, lv, e)

        brainAnatOut = lane(brainAnatOn && cortexOn, thr, lv, brain)
        eyeBrainVisOut = lane(eyeBrainVisOn, thr, lv, maxOf(eye, brain))
        eyeChOut = lane(eyeChOn, thr, lv, eye)
        lrEyesOut = lane(lrEyesOn, thr, lv, eye)
        eyeLOut = lane(eyeLOn && lrEyesOn, eyeLThr, eyeLLv, eye * 1.02f)
        eyeROut = lane(eyeROn && lrEyesOn, eyeRThr, eyeRLv, eye)
        val eyeShared = lane(lrEyesOn, eyeSharedThr, eyeSharedLv, eye)
        eyeLOut = maxOf(eyeLOut, eyeShared * 0.5f)
        eyeROut = maxOf(eyeROut, eyeShared * 0.5f)
        eyeCorneaOut = lane(eyeOpticalOn && eyeCorneaOn, eyeLThr, eyeLLv, eyeLOut * 0.9f)
        eyeLensOut = lane(eyeOpticalOn && eyeLensOn, eyeLThr, eyeLLv, eyeLOut * 0.85f)
        eyeRetinaOut = lane(eyeOpticalOn && eyeRetinaOn, eyeRThr, eyeRLv, eyeROut * 0.9f)
        eyeOpticOut = lane(opticNerveOn && eyeOpticalOn, thr, lv, maxOf(eyeLOut, eyeROut))
        eyePupilOut = lane(eyePupilOn, thr, lv, (eyeLOut + eyeROut) * 0.5f)
        eyeIrisOut = lane(eyeIrisOn, thr, lv, eyePupilOut * 0.9f)
        eyeMoveOut = lane(eyeMoveOn, eyeMoveThr, eyeMoveLv, maxOf(move, eye * 0.8f))
        eyeVisLOut = lane(eyeVisLOn && eyeBrainVisOn, eyeLThr, eyeBrightL * eyeLLv, eye * 1.01f)
        eyeVisROut = lane(eyeVisROn && eyeBrainVisOn, eyeRThr, eyeBrightR * eyeRLv, eye)
        if (eyePitchProtOn) {
            eyeLOut *= (1f - 0.12f)
            eyeROut *= (1f - 0.12f)
        }
        lrEyesOut = maxOf(lrEyesOut, eyeLOut, eyeROut)
        eyeChOut = maxOf(eyeChOut, eyeOpticOut, eyeCorneaOut, eyeRetinaOut)
        eyeBrainVisOut = maxOf(eyeBrainVisOut, eyeVisLOut, eyeVisROut)
        eyeAnatomyFullOut = maxOf(
            lrEyesOut, eyeLOut, eyeROut, eyeCorneaOut, eyeLensOut, eyeRetinaOut,
            eyeOpticOut, eyePupilOut, eyeIrisOut, eyeMoveOut, eyeVisLOut, eyeVisROut
        )
        lrBrainOut = lane(lrBrainOn, thr, lv, brain)
        faceNeckSkinOut = lane(faceNeckSkinOn, thr, lv, skin)
        // Eye-skin + skin layers driven by live mic + skin energy
        val skinE = maxOf(skin, if (micLiveDriveSkinOn) e else 0f)
        val eyeE = maxOf(eye, if (micLiveDriveEyesOn) e else 0f)
        val anatE = maxOf(brain, heart, skin, if (micLiveDriveAnatOn) e else 0f)
        eyeSkinLOut = lane(eyeSkinOn && eyeSkinLOn, skinThr, skinLv, maxOf(eyeE, eyeLOut) * 0.95f)
        eyeSkinROut = lane(eyeSkinOn && eyeSkinROn, skinThr, skinLv, maxOf(eyeE, eyeROut) * 0.95f)
        eyeLidSkinOut = lane(eyeSkinOn && eyeLidSkinOn, skinThr, skinLv, maxOf(eyeSkinLOut, eyeSkinROut) * 0.9f)
        eyeBrowSkinOut = lane(eyeSkinOn && eyeBrowSkinOn, skinThr, skinLv, maxOf(eyeSkinLOut, eyeSkinROut) * 0.85f)
        eyeSkinFullOut = maxOf(eyeSkinLOut, eyeSkinROut, eyeLidSkinOut, eyeBrowSkinOut)
        skinEpidermisOut = lane(skinFullOn && skinEpidermisOn, skinThr, skinLv, skinE)
        skinDermisOut = lane(skinFullOn && skinDermisOn, skinThr, skinLv, skinE * 0.95f)
        skinHypodermisOut = lane(skinFullOn && skinHypodermisOn, skinThr, skinLv, skinE * 0.9f)
        skinFaceOut = lane(skinFullOn && skinFaceOn, skinThr, skinLv, maxOf(skinE, faceNeckSkinOut))
        skinHeadOut = lane(skinFullOn && skinHeadOn, skinThr, skinLv, skinE * 0.92f)
        skinNeckOut = lane(skinFullOn && skinNeckOn, skinThr, skinLv, maxOf(skinE * 0.88f, neckOut))
        skinFullOut = maxOf(skinEpidermisOut, skinDermisOut, skinHypodermisOut, skinFaceOut, skinHeadOut, skinNeckOut, faceNeckSkinOut, eyeSkinFullOut)
        faceNeckSkinOut = maxOf(faceNeckSkinOut, skinFaceOut, eyeSkinFullOut * 0.8f)
        liveUnifiedOut = maxOf(
            if (micLiveDriveAnatOn) micLiveOut else 0f,
            if (micLiveDriveEyesOn) maxOf(eyeAnatomyFullOut, eyeSkinFullOut) else 0f,
            if (micLiveDriveSkinOn) skinFullOut else 0f,
            if (micLiveDrive84On) body84Out else 0f,
            micFullOut * 0.5f
        )
        glandCnsOut = lane(glandCnsOn && cnsOn, thr, lv, brain)
        heartOut = lane(heartNeckOn, thr, lv, heart)
        neckOut = lane(heartNeckOn, thr, lv, skin * 0.8f)
        wholeBodyOut = lane(wholeBodyOn, thr, lv, maxOf(skin, e))
        allAnatOut = lane(allAnatAmbOn, thr, lv, maxOf(brain, skin, heart))
        respAnatOut = lane(respAnatOn && allAnatAmbOn, anatThr, anatLv, maxOf(e, skin * 0.5f))
        cardioAnatOut = lane(cardioAnatOn && allAnatAmbOn, anatThr, anatLv, maxOf(heart, e * 0.6f))
        digestAnatOut = lane(digestAnatOn && allAnatAmbOn, anatThr, anatLv, e * 0.85f)
        urinaryAnatOut = lane(urinaryAnatOn && allAnatAmbOn, anatThr, anatLv, e * 0.8f)
        endoAnatOut = lane(endoAnatOn && allAnatAmbOn, anatThr, anatLv, maxOf(brain * 0.5f, e * 0.7f))
        lymphAnatOut = lane(lymphAnatOn && allAnatAmbOn, anatThr, anatLv, e * 0.75f)
        skeletalAnatOut = lane(skeletalAnatOn && allAnatAmbOn, anatThr, anatLv, maxOf(skin, e * 0.55f))
        muscleAnatOut = lane(muscleAnatOn && allAnatAmbOn, anatThr, anatLv, maxOf(move, e * 0.6f))
        jointAnatOut = lane(jointAnatOn && allAnatAmbOn, anatThr, anatLv, maxOf(move * 0.8f, speed * 0.5f))
        pnsAnatOut = lane(pnsAnatOn && allAnatAmbOn, anatThr, anatLv, maxOf(brain * 0.4f, e * 0.65f))
        reproAnatOut = lane(reproAnatOn && allAnatAmbOn, anatThr, anatLv, e * 0.7f)
        earAnatOut = lane(earAnatOn && allAnatAmbOn, anatThr, anatLv, maxOf(ear, e * 0.5f))
        leftBrainOut = lane(brainLOn && brainAnatOn, anatThr, anatLv, brain * 1.02f)
        rightBrainOut = lane(brainROn && brainAnatOn, anatThr, anatLv, brain)
        glandDetailOut = lane(glandCnsOn, anatThr, anatLv, maxOf(brain, e * 0.5f))
        anatomyFullOut = maxOf(
            allAnatOut, wholeBodyOut, brainAnatOut, heartOut, glandCnsOut, faceNeckSkinOut,
            respAnatOut, cardioAnatOut, digestAnatOut, urinaryAnatOut, endoAnatOut, lymphAnatOut,
            skeletalAnatOut, muscleAnatOut, jointAnatOut, pnsAnatOut, reproAnatOut, earAnatOut,
            leftBrainOut, rightBrainOut, glandDetailOut
        )
        allAnatOut = maxOf(allAnatOut, anatomyFullOut * 0.85f)
        earDspOut = lane(earDspOn, thr, lv, ear)
        dspToneOut = lane(dspToneOn && dspProtOn, thr, lv, e * 0.7f)
        usEchoOut = lane(usEchoOn, thr, lv, e * 0.6f)
        usWarfareOut = lane(usWarfareOn, thr, lv, maxOf(burst, e * 0.5f))
        screenAmbOut = lane(screenAmbOn, thr, lv, e * 0.55f)
        mobileBubbleOut = lane(mobileBubbleOn, thr, lv, e * 0.5f)
        modelMixOut = lane(modelMixOn && (poseAmbOn || segAmbOn || obbAmbOn), thr, lv, maxOf(body84Out, body3dOut))

        status =
            "FINAL26 amb=${(ambOut*100).toInt()}% spike/spd=${(spikeOut*100).toInt()}/${(speedOut*100).toInt()} · " +
            "B84=${(body84Out*100).toInt()}% act=$body84ActiveCount avg=${(body84AvgOut*100).toInt()}% 3D=${(body3dOut*100).toInt()}% · " +
            "eye/brain/ear=${(lrEyesOut*100).toInt()}/${(brainAnatOut*100).toInt()}/${(earDspOut*100).toInt()} · " +
            "WPN=${(maxOf(burstProt,bulletProt,knifeProt)*100).toInt()}% SCR/MOB=${(screenAmbOut*100).toInt()}/${(mobileBubbleOut*100).toInt()} · " +
            "hits=$spikeHits" + if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled || !masterOn) return
        val damp = maxOf(spikeOut, burstProt, bulletProt, knifeProt, whipProt, usWarfareOut)
        if (damp > 0.02f) {
            val k = (1f - damp * 0.95f).coerceIn(0.02f, 1f)
            if (burstProt > 0.02f) sb.burstOut *= (1f - burstProt * 0.96f).coerceIn(0.02f, 1f)
            if (bulletProt > 0.02f) sb.bulletOut *= (1f - bulletProt * 0.96f).coerceIn(0.02f, 1f)
            if (knifeProt > 0.02f) sb.knifeOut *= (1f - knifeProt * 0.96f).coerceIn(0.02f, 1f)
            if (whipProt > 0.02f) sb.whipOut *= (1f - whipProt * 0.95f).coerceIn(0.02f, 1f)
            if (ambLiveEnemyTxBlock) {
                sb.enemyBodyOut *= k
                sb.micEnemyOut *= k
            }
        }
        val vv = v ?: return
        try {
            vv.fullAmbientMaster.ambientAll = maxOf(vv.fullAmbientMaster.ambientAll, ambOut, ambLiveOut)
            vv.fullAmbientMaster.spikeOut = maxOf(vv.fullAmbientMaster.spikeOut, spikeOut)
            vv.fullAmbientMaster.speedOut = maxOf(vv.fullAmbientMaster.speedOut * (1f - speedOut * 0.5f), 0f)
            // Full 84-channel system → Body84Channels bulk + live stats
            try {
                val ch = vv.body84
                ch.masterOn = body84On
                ch.bulkAmbient = body84BulkAmbient
                ch.bulkThr = body84BulkThr
                ch.bulkBipNeg = body84BipNeg
                ch.bulkBipPos = body84BipPos
                ch.rescanOn = body84RescanOn
                try { ch.applyBulkToAll() } catch (_: Throwable) {}
                // push motion levels into bulk move/speed if fields exist
                try { ch.bulkMove = body84Move3dLv } catch (_: Throwable) {}
                try { ch.bulkSpeed = body84Speed3dLv } catch (_: Throwable) {}
                body84ActiveCount = ch.activeCount

            // Full anatomy ambient → FullAnatomy132 + FinalAnatomy
            try {
                val a = vv.fullAnatomy132
                a.brainOn = brainAnatOn; a.eyesOn = lrEyesOn; a.earOn = earAnatOn
                a.faceOn = faceNeckSkinOn; a.neckOn = heartNeckOn; a.heartOn = heartNeckOn
                a.glandsOn = glandCnsOn; a.bodyPartsOn = bodyPartsOn
                a.respOn = respAnatOn; a.cardioOn = cardioAnatOn; a.digestOn = digestAnatOn
                a.urinaryOn = urinaryAnatOn; a.endoOn = endoAnatOn; a.lymphOn = lymphAnatOn
                a.skeletalOn = skeletalAnatOn; a.muscleOn = muscleAnatOn; a.jointOn = jointAnatOn
                a.pnsOn = pnsAnatOn; a.reproOn = reproAnatOn
                a.brainOut = maxOf(a.brainOut, brainAnatOut, leftBrainOut, rightBrainOut)
                a.eyesOut = maxOf(a.eyesOut, lrEyesOut, eyeChOut, eyeAnatomyFullOut)

            // Eyes anatomy ambient full → FinalEyes · CNS · eyeBody · lock
            try {
                val fe = vv.finalEyes
                fe.leftOut = maxOf(fe.leftOut, eyeLOut)
                fe.rightOut = maxOf(fe.rightOut, eyeROut)
                fe.leftVisOut = maxOf(fe.leftVisOut, eyeVisLOut)
                fe.rightVisOut = maxOf(fe.rightVisOut, eyeVisROut)
                fe.cornea = maxOf(fe.cornea, eyeCorneaOut)
                fe.lens = maxOf(fe.lens, eyeLensOut)
                fe.retina = maxOf(fe.retina, eyeRetinaOut)
                fe.opticNerve = maxOf(fe.opticNerve, eyeOpticOut)
                fe.pupil = maxOf(fe.pupil, eyePupilOut)
                fe.iris = maxOf(fe.iris, eyeIrisOut)
                fe.opticalOn = eyeOpticalOn
                fe.leftBright = eyeBrightL
                fe.rightBright = eyeBrightR
                fe.leftContrast = eyeContrastL
                fe.rightContrast = eyeContrastR
            } catch (_: Throwable) {}
            try {
                vv.cnsEyesHeart.eyeLOut = maxOf(vv.cnsEyesHeart.eyeLOut, eyeLOut)
                vv.cnsEyesHeart.eyeROut = maxOf(vv.cnsEyesHeart.eyeROut, eyeROut)
            } catch (_: Throwable) {}
            try {
                vv.eyeBodyAtomSurface.eyeLOut = maxOf(vv.eyeBodyAtomSurface.eyeLOut, eyeLOut)
                vv.eyeBodyAtomSurface.eyeROut = maxOf(vv.eyeBodyAtomSurface.eyeROut, eyeROut)
                vv.eyeBodyAtomSurface.eyeVisionOut = maxOf(vv.eyeBodyAtomSurface.eyeVisionOut, maxOf(eyeVisLOut, eyeVisROut))
                vv.eyeBodyAtomSurface.eyeMoveOut = maxOf(vv.eyeBodyAtomSurface.eyeMoveOut, eyeMoveOut)
            } catch (_: Throwable) {}
            try {
                vv.eyesCompleteLock.eyeLockOut = maxOf(vv.eyesCompleteLock.eyeLockOut, eyeAnatomyFullOut)
            } catch (_: Throwable) {}
            try {
                vv.fullAnatomy132.eyesOut = maxOf(vv.fullAnatomy132.eyesOut, eyeAnatomyFullOut)
            } catch (_: Throwable) {}

                a.earOut = maxOf(a.earOut, earAnatOut)
                a.faceOut = maxOf(a.faceOut, faceNeckSkinOut)
                a.neckOut = maxOf(a.neckOut, neckOut)
                a.heartOut = maxOf(a.heartOut, heartOut, cardioAnatOut)
                a.glandsOut = maxOf(a.glandsOut, glandCnsOut, glandDetailOut, endoAnatOut)
                a.bodyPartsOut = maxOf(a.bodyPartsOut, bodyPartsOut, wholeBodyOut)
                a.respOut = maxOf(a.respOut, respAnatOut)
                a.cardioOut = maxOf(a.cardioOut, cardioAnatOut)
                a.digestOut = maxOf(a.digestOut, digestAnatOut)
                a.urinaryOut = maxOf(a.urinaryOut, urinaryAnatOut)
                a.endoOut = maxOf(a.endoOut, endoAnatOut)
                a.lymphOut = maxOf(a.lymphOut, lymphAnatOut)
                a.skeletalOut = maxOf(a.skeletalOut, skeletalAnatOut)
                a.muscleOut = maxOf(a.muscleOut, muscleAnatOut)
                a.jointOut = maxOf(a.jointOut, jointAnatOut)
                a.pnsOut = maxOf(a.pnsOut, pnsAnatOut)
                a.reproOut = maxOf(a.reproOut, reproAnatOut)
                a.anatomyFullOut = maxOf(a.anatomyFullOut, anatomyFullOut)
                vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, anatomyFullOut * 0.4f)
            } catch (_: Throwable) {}

                body84AvgOut = ch.avgOut
                body84MaxOut = ch.maxOut
                body84RescanOut = ch.rescanOut
                vv.body84FullHuman.atomOut = maxOf(vv.body84FullHuman.atomOut, body84AtomOut, body84AvgOut)
                vv.body84FullHuman.moveOut = maxOf(vv.body84FullHuman.moveOut, body84Move)
                vv.body84FullHuman.speedOut = maxOf(vv.body84FullHuman.speedOut, body84Speed)
                vv.body84FullHuman.waveOut = maxOf(vv.body84FullHuman.waveOut, body84Wave)
                vv.body84FullHuman.visualOut = maxOf(vv.body84FullHuman.visualOut, body84VisBrainOut)
            } catch (_: Throwable) {}
            vv.eyesCompleteLock.eyeLockOut = maxOf(vv.eyesCompleteLock.eyeLockOut, lrEyesOut, eyeChOut, eyeBrainVisOut)
            vv.earAuditoryLine.earLineFull = maxOf(vv.earAuditoryLine.earLineFull, earDspOut)
            vv.bodyChemBrain.brainFullOut = maxOf(vv.bodyChemBrain.brainFullOut, brainAnatOut, lrBrainOut, glandCnsOut)
            vv.allBodySkinAnatomy.allSkinOut = maxOf(vv.allBodySkinAnatomy.allSkinOut, faceNeckSkinOut, wholeBodyOut, skinFullOut, eyeSkinFullOut)
            try {
                vv.allBodySkinAnatomy.faceSkin = maxOf(vv.allBodySkinAnatomy.faceSkin, skinFaceOut)
                vv.allBodySkinAnatomy.headSkin = maxOf(vv.allBodySkinAnatomy.headSkin, skinHeadOut)
                vv.allBodySkinAnatomy.neckSkin = maxOf(vv.allBodySkinAnatomy.neckSkin, skinNeckOut)
                // eye skin regions if present
                try { vv.allBodySkinAnatomy.faceSkin = maxOf(vv.allBodySkinAnatomy.faceSkin, eyeSkinFullOut) } catch (_: Throwable) {}
                try {
                    vv.eyeLSkinOut = maxOf(vv.eyeLSkinOut, eyeSkinLOut)
                    vv.eyeRSkinOut = maxOf(vv.eyeRSkinOut, eyeSkinROut)
                    vv.skinAll = maxOf(vv.skinAll, skinFullOut)
                } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            try {
                vv.bioSkinCell.epidermisOut = maxOf(vv.bioSkinCell.epidermisOut, skinEpidermisOut)
                vv.bioSkinCell.dermisOut = maxOf(vv.bioSkinCell.dermisOut, skinDermisOut)
                vv.bioSkinCell.hypodermisOut = maxOf(vv.bioSkinCell.hypodermisOut, skinHypodermisOut)
            } catch (_: Throwable) {}
            try {
                vv.finalEyes.leftOut = maxOf(vv.finalEyes.leftOut, eyeSkinLOut * 0.5f)
                vv.finalEyes.rightOut = maxOf(vv.finalEyes.rightOut, eyeSkinROut * 0.5f)
            } catch (_: Throwable) {}
            try {
                vv.micLiveAmbientMixer.micLiveOut = maxOf(vv.micLiveAmbientMixer.micLiveOut, liveUnifiedOut)
                vv.micLiveAmbientMixer.routeSkin = maxOf(vv.micLiveAmbientMixer.routeSkin, skinFullOut)
                try { vv.micLiveAmbientMixer.routeAll = maxOf(vv.micLiveAmbientMixer.routeAll, maxOf(eyeAnatomyFullOut, eyeSkinFullOut)) } catch (_: Throwable) {}
                vv.micLiveAmbientMixer.routeProtect = maxOf(vv.micLiveAmbientMixer.routeProtect, liveUnifiedOut * 0.6f)
            } catch (_: Throwable) {}
            try {
                vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, maxOf(skinFullOut, eyeSkinFullOut, anatomyFullOut, micFullOut) * 0.35f)
            } catch (_: Throwable) {}
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, spareOut, shield3dOut)
            vv.bodyRegionEnemyProtect.protectOut = maxOf(vv.bodyRegionEnemyProtect.protectOut, damp, bodyLrOut)
            vv.fullBodyMotionLock.lockOut = maxOf(vv.fullBodyMotionLock.lockOut, speedOut, body84Speed)
            vv.enemySoundCounters.antiBurstOut = maxOf(vv.enemySoundCounters.antiBurstOut, burstProt)
            vv.enemySoundCounters.antiBulletOut = maxOf(vv.enemySoundCounters.antiBulletOut, bulletProt)
            vv.enemySoundCounters.antiKnifeOut = maxOf(vv.enemySoundCounters.antiKnifeOut, knifeProt)
            vv.anatomy3d.atmosphere = maxOf(vv.anatomy3d.atmosphere, body3dOut * 0.4f, modelMixOut * 0.3f)
            if (poseDiagOn || poseAmbOn) try { vv.anatomy3d.poseRigOn = true } catch (_: Throwable) {}
            if (vv.anatomy3d.layerOn.size > 2 && shield3dOn) {
                vv.anatomy3d.layerOn[2] = true
                vv.anatomy3d.layerLevel[2] = maxOf(vv.anatomy3d.layerLevel[2], shield3dOut)
            }
            vv.micLiveAmbientMixer.micLiveOut = maxOf(vv.micLiveAmbientMixer.micLiveOut, maxOf(ambLiveOut, micLiveOut, micFullOut))
            try { vv.liveMicEnemyAll.liveMicAllOut = maxOf(vv.liveMicEnemyAll.liveMicAllOut, micLiveOut) } catch (_: Throwable) {}
            try { vv.liveMicEnemyAll.antiOwnOut = maxOf(vv.liveMicEnemyAll.antiOwnOut, micEnemyProtOut) } catch (_: Throwable) {}
            try {
                vv.micSpeaker.outL = maxOf(vv.micSpeaker.outL, micStereoLOut * micGainOut.coerceAtLeast(0.2f))
                vv.micSpeaker.outR = maxOf(vv.micSpeaker.outR, micStereoROut * micGainOut.coerceAtLeast(0.2f))
                vv.micSpeaker.echoCancelOn = micEchoCancelOn
                vv.micSpeaker.noiseReduceOn = micNoiseReduceOn
                vv.micSpeaker.monoOn = micMonoOn
                vv.micSpeaker.stereoOn = micStereoModeOn
                vv.micSpeaker.micGain = micGain
                vv.micSpeaker.ampGain = micAmpGain
                if (micEchoCancelOn) vv.micSpeaker.echoCancelLv = maxOf(vv.micSpeaker.echoCancelLv, micEchoCancelOut)
                if (micNoiseReduceOn) vv.micSpeaker.noiseReduceLv = maxOf(vv.micSpeaker.noiseReduceLv, micNoiseReduceOut)
            } catch (_: Throwable) {}
            if (micEnemyProtOut > 0.05f) {
                sb.micEnemyOut *= (1f - micEnemyProtOut * 0.9f).coerceIn(0.05f, 1f)
                sb.enemyBodyOut *= (1f - micEnemyProtOut * 0.5f).coerceIn(0.1f, 1f)
            }
            // cleaned path strength
            try { sb.liveAudioEnergy } catch (_: Throwable) {}
            vv.antiAtomspareSounds.antiOut = maxOf(vv.antiAtomspareSounds.antiOut, spareOut)
        } catch (_: Throwable) {}
    }
}
