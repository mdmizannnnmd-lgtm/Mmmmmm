package com.mizan

/**
 * Microphone-derived event. These events describe signal features only; they are
 * not speech/identity recognition and do not claim that a person or object exists.
 */
data class MicSignalEvent(
    val type: Type,
    val sequence: Long,
    val timestampMs: Long,
    val level: Float,
    val dbfs: Float,
    val rms: Float,
    val peak: Float,
    val dominantHz: Float,
    val centroidHz: Float,
    val sampleRate: Int,
    val channels: Int
) {
    enum class Type {
        FRAME,
        SILENCE,
        ACTIVE,
        BURST,
        LOW_FREQUENCY,
        MID_FREQUENCY,
        HIGH_FREQUENCY,
        TONE_LIKE
    }
}
