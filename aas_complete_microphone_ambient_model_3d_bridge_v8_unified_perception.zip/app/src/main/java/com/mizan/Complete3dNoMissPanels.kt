package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object Complete3dNoMissPanels {
    fun build(ctx: Context, root: LinearLayout, b: Complete3dNoMissBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFCE93D8.toInt()
        p.title("COMPLETE 3D · NO MISSING", c)
        p.note("Forces all 7 layers · brain structures · body systems · sides · 84 · skin in/out · shell · eyes · atomspare")
        p.switch("3D no-miss master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Force all 7 layers", b.forceAllLayers) { b.forceAllLayers = it }
        p.switch("Force brain structures", b.forceBrainStructures) { b.forceBrainStructures = it }
        p.switch("Force body systems", b.forceBodySystems) { b.forceBodySystems = it }
        p.switch("Force F/B/L/R/Up/Down sides", b.forceSides) { b.forceSides = it }
        p.switch("Force 84 + pose/seg/obb", b.force84) { b.force84 = it }
        p.switch("Force skin inside/outside", b.forceSkinInOut) { b.forceSkinInOut = it }
        p.switch("Force anatomy shell", b.forceShell) { b.forceShell = it }
        p.switch("Force eyes gaze", b.forceEyes) { b.forceEyes = it }
        p.switch("Force complete atomspare", b.forceAtomspare) { b.forceAtomspare = it }
        val st = p.status("3D NO-MISS —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 300) }
        })
    }
}
