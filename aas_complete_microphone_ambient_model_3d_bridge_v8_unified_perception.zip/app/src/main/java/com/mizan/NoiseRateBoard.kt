package com.mizan

/**
 * Noise rate: threshold + level.
 * Estimates how quickly noise energy is changing (rate) and gates on threshold.
 */
class NoiseRateBoard {
    @Volatile var enabled = true
    @Volatile var thr = 0.40f
    @Volatile var level = 0.65f
    @Volatile var rate = 0f
    @Volatile var active = false
    @Volatile var out = 0f

    private var prev = 0f
    private var lastTs = System.currentTimeMillis()

    fun tick(energy: Float) {
        val now = System.currentTimeMillis()
        val dt = ((now - lastTs).coerceIn(1L, 100L)).toFloat() / 1000f
        lastTs = now
        val e = energy.coerceIn(0f, 1f)
        val delta = kotlin.math.abs(e - prev)
        prev = e
        // rate ~ change per second, soft-scaled
        rate = (delta / dt.coerceAtLeast(0.001f) * 0.15f).coerceIn(0f, 1f)

        if (!enabled) {
            active = false
            out = 0f
            return
        }
        val t = thr.coerceIn(0.05f, 1f)
        active = rate >= t
        out = if (active) {
            (((rate - t) / (1f - t).coerceAtLeast(0.05f)) * level.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else rate * 0.12f
    }

    fun statusLine(): String {
        if (!enabled) return "NOISE-RATE off"
        val st = if (active) "HOT" else "ok"
        return "NOISE-RATE $st rate=${(rate*100).toInt()}% thr=${(thr*100).toInt()}% lv=${(level*100).toInt()}% out=${(out*100).toInt()}%"
    }
    fun apply(v: VisualShieldView?) { /* noise rate telemetry */ }

}
