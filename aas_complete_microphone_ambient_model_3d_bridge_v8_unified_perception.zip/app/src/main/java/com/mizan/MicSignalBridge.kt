package com.mizan

import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs

/**
 * Single fan-out bridge from RawMicBus to ambient, model, 3D, camera and UI
 * consumers. It never opens a microphone and never removes/replaces existing paths.
 */
object MicSignalBridge {
    private val listeners = CopyOnWriteArrayList<(MicSignalEvent) -> Unit>()

    fun subscribe(listener: (MicSignalEvent) -> Unit): AutoCloseable {
        listeners += listener
        return AutoCloseable { listeners -= listener }
    }

    internal fun onFrame(frame: RawMicFrame) {
        if (!MicSignalSettings.enabled) return
        val s = MicSignalSettings
        val events = ArrayList<MicSignalEvent>(3)
        val base = MicSignalEvent(
            MicSignalEvent.Type.FRAME, frame.sequence, frame.timestampMs,
            frame.rms, frame.dbfs, frame.rms, frame.peak, frame.dominantHz,
            frame.centroidHz, frame.sampleRate, frame.channels
        )
        events += base
        when {
            frame.dbfs <= s.silenceDbfs -> events += base.copy(type = MicSignalEvent.Type.SILENCE)
            frame.peak >= s.burstPeak -> events += base.copy(type = MicSignalEvent.Type.BURST)
            frame.dbfs >= s.activeDbfs -> events += base.copy(type = MicSignalEvent.Type.ACTIVE)
        }
        when {
            frame.dominantHz > 0f && frame.dominantHz < s.lowHzMax -> events += base.copy(type = MicSignalEvent.Type.LOW_FREQUENCY)
            frame.dominantHz >= s.highHzMin -> events += base.copy(type = MicSignalEvent.Type.HIGH_FREQUENCY)
            else -> events += base.copy(type = MicSignalEvent.Type.MID_FREQUENCY)
        }
        if (frame.dominantHz > 0f && frame.centroidHz > 0f) {
            val relative = abs(frame.centroidHz - frame.dominantHz) / frame.dominantHz
            if (relative <= s.toneCentroidTolerance) {
                events += base.copy(type = MicSignalEvent.Type.TONE_LIKE)
            }
        }
        for (event in events) {
            for (listener in listeners) {
                try { listener(event) } catch (_: Throwable) { RawMicDiagnostics.onListenerError() }
            }
        }
    }
}
