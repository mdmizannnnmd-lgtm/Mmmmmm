package com.mizan

import kotlin.math.ln

/**
 * SCREEN ECHO · CENTROID · VERTICAL + LIVE MICROPHONE ECHO · MICROPHONE CENTROID · VERTICAL.
 *
 * Five channels, each with ON · LEVEL · THRESHOLD · RAW and a live readout:
 *   SCREEN ECHO CENTROID  — where the body centroid sits (left ↔ right), remembered by the echo: it follows the live
 *                           centroid while the echo is loud and is HELD (echoed) while it fades.
 *   SCREEN ECHO VERTICAL  — the same for the vertical level (feet → head).
 *   MIC ECHO              — the LIVE MICROPHONE level through its own echo (decayed residual), own threshold + level.
 *   MIC CENTROID          — spectral centroid of the live microphone (dark → bright, log-Hz), echoed by the mic echo.
 *   MIC VERTICAL          — pitch height of the live microphone (dominant Hz, low → high, log scale), echoed.
 *
 * The microphone also joins the screen echo itself: [micMix] 0..1 blends the live mic level into the screen echo's input.
 *
 * RAW COMPLETE ([rawComplete], the per-channel RAW switches, or ONENESS "RAW EVERYTHING" via [rawEverything]):
 * no level, no threshold, no smoothing and no echo decay — the live value goes straight to the output.
 */
class ScreenEchoMic {

    class Ch(val key: String, var lv: Float, var thr: Float) {
        @Volatile var on = true
        @Volatile var raw = false
        @Volatile var active = false
        @Volatile var out = 0f
        @Volatile var norm = 0f
        /** signed −1..+1 around the threshold (bipolar) */
        @Volatile var bip = 0f
    }

    val screenCen = Ch("cen", 0.60f, 0.30f)
    val screenVer = Ch("ver", 0.55f, 0.28f)
    val micEcho = Ch("mic", 0.60f, 0.25f)
    val micCen = Ch("miccen", 0.60f, 0.30f)
    val micVer = Ch("micver", 0.55f, 0.28f)
    val all = listOf(screenCen, screenVer, micEcho, micCen, micVer)

    @Volatile var rawComplete = true
    @Volatile var rawEverything = false
    /** Set by the Screen Ambient board's own RAW COMPLETE switch. */
    @Volatile var rawScreen = false
    /** How much of the live microphone level joins the screen echo input (0 = screen only, 1 = microphone only). */
    @Volatile var micMix = 0.35f
    /** Echo memory of the mic echo: higher = the tail lasts longer (0 … 0.95). */
    @Volatile var micDecay = 0.45f
    /** The live microphone is really delivering audio. */
    @Volatile var micLive = false
        private set

    // live inputs (set every frame by VisualShieldView)
    @Volatile var micEnergy = 0f
        private set
    @Volatile var micCenFeed = 0f
        private set
    @Volatile var micVerFeed = 0f
        private set
    @Volatile var micDbfs = -90.0
        private set
    @Volatile var micHz = 0f
        private set
    @Volatile var micDomHz = 0f
        private set
    @Volatile var micEchoMix = 0f
        private set
    @Volatile var screenCenFeed = 0.5f
        private set
    @Volatile var screenVerFeed = 0.5f
        private set

    private var micPrev = 0f

    fun isRaw(ch: Ch? = null): Boolean = rawComplete || rawEverything || rawScreen || (ch?.raw == true)

    /** Live microphone → energy / centroid / vertical (0..1). Call every frame, before [tick]. */
    fun feedMic(ab: AmbientThresholdBoard?, live: Boolean) {
        micLive = live && ab != null
        if (ab == null || !live) {
            micEnergy = 0f; micCenFeed = 0f; micVerFeed = 0f; micDbfs = -90.0; micHz = 0f; micDomHz = 0f
            return
        }
        micDbfs = ab.micDbfs
        micHz = ab.centroidHz
        micDomHz = ab.domHz
        micEnergy = if (isRaw()) ((ab.micDbfs + 90.0) / 90.0).coerceIn(0.0, 1.0).toFloat()
        else ((ab.micDbfs - ab.noiseFloorDb) / 40.0).coerceIn(0.0, 1.0).toFloat()
        micCenFeed = logNorm(ab.centroidHz)
        micVerFeed = logNorm(ab.domHz)
    }

    /** Body centroid (x in body units, left −0.7 … right +0.7) and vertical (0 feet … 1 head) that the screen echo remembers. */
    fun feedScreen(centroidX: Float, vertical01: Float) {
        screenCenFeed = ((centroidX + 0.7f) / 1.4f).coerceIn(0f, 1f)
        screenVerFeed = vertical01.coerceIn(0f, 1f)
    }

    private fun logNorm(hz: Float): Float {
        if (hz <= 0f) return 0f
        val h = hz.coerceIn(LiveSpectrumAnalyzer.F_MIN, LiveSpectrumAnalyzer.F_MAX)
        return (ln(h / LiveSpectrumAnalyzer.F_MIN) / ln(LiveSpectrumAnalyzer.F_MAX / LiveSpectrumAnalyzer.F_MIN)).toFloat().coerceIn(0f, 1f)
    }

    /** The energy the screen echo listens to: the screen blended with the live microphone. */
    fun echoInput(screenEnergy: Float): Float {
        val m = if (micLive) micMix.coerceIn(0f, 1f) else 0f
        return (screenEnergy * (1f - m) + micEnergy * m).coerceIn(0f, 1f)
    }

    private fun shape(ch: Ch, x: Float, gate: Boolean) {
        val raw = isRaw(ch)
        val s = x.coerceIn(0f, 1f)
        if (!ch.on) { ch.active = false; ch.out = 0f; ch.bip = 0f; ch.norm = s; return }
        if (raw) {
            ch.active = true; ch.out = s; ch.bip = s * 2f - 1f; ch.norm = s
            return
        }
        val t = ch.thr.coerceIn(0.02f, 0.98f)
        val lv = ch.lv.coerceIn(0f, 1.5f)
        val signed = if (s >= t) ((s - t) / (1f - t)) else -((t - s) / t)
        ch.bip = (signed * lv).coerceIn(-1f, 1f)
        ch.active = gate && s >= t
        ch.out = if (ch.active) (((s - t) / (1f - t)) * lv).coerceIn(0f, 1f) else 0f
        ch.norm = s
    }

    /**
     * Per frame. [echoMix] / [echoActive] = the screen echo's own state; the screen centroid / vertical are held by it.
     * Returns the ambient-dampen contribution of the five channels (0 when nothing is active).
     */
    fun tick(echoMix: Float, echoActive: Boolean): Float {
        val rawAny = isRaw()
        // ── screen echo centroid / vertical: follow the live value while the echo is loud, hold it while it fades ──
        val w = if (rawAny) 1f else (echoMix.coerceIn(0f, 1f) * 0.5f)
        val cn = if (isRaw(screenCen)) screenCenFeed else screenCen.norm + (screenCenFeed - screenCen.norm) * w
        val vn = if (isRaw(screenVer)) screenVerFeed else screenVer.norm + (screenVerFeed - screenVer.norm) * w
        shape(screenCen, cn, echoActive)
        shape(screenVer, vn, echoActive)

        // ── live microphone echo: decayed residual of the mic level ──
        val dec = micDecay.coerceIn(0f, 0.95f)
        val mix = if (isRaw(micEcho)) micEnergy else micEnergy * (1f - dec) + micPrev * dec
        micPrev = mix
        micEchoMix = mix
        shape(micEcho, mix, true)

        // ── mic centroid / vertical, echoed by the mic echo ──
        val mw = if (rawAny) 1f else (mix.coerceIn(0f, 1f) * 0.5f)
        val mc = if (isRaw(micCen)) micCenFeed else micCen.norm + (micCenFeed - micCen.norm) * mw
        val mv = if (isRaw(micVer)) micVerFeed else micVer.norm + (micVerFeed - micVer.norm) * mw
        shape(micCen, mc, micEcho.active)
        shape(micVer, mv, micEcho.active)

        var d = 0f
        if (screenCen.active) d = maxOf(d, 0.22f + screenCen.out * 0.30f)
        if (screenVer.active) d = maxOf(d, 0.22f + screenVer.out * 0.30f)
        if (micEcho.active) d = maxOf(d, 0.26f + micEcho.out * 0.36f)
        if (micCen.active) d = maxOf(d, 0.22f + micCen.out * 0.28f)
        if (micVer.active) d = maxOf(d, 0.22f + micVer.out * 0.28f)
        return d
    }

    fun reset() {
        for (c in all) { c.active = false; c.out = 0f; c.bip = 0f }
        micPrev = 0f; micEchoMix = 0f
    }

    fun statusLine(): String {
        val r = if (rawComplete || rawEverything || rawScreen) " · RAW COMPLETE" else ""
        fun p(c: Ch) = "${(c.out * 100).toInt()}%" + (if (c.raw && r.isEmpty()) "r" else "")
        return "ECHO · scr-cen ${p(screenCen)} scr-vert ${p(screenVer)} · MIC " +
            (if (micLive) "${"%.0f".format(micDbfs)}dBFS echo ${p(micEcho)} cen ${micHz.toInt()}Hz ${p(micCen)} vert ${micDomHz.toInt()}Hz ${p(micVer)}"
            else "not live") + " · mic→echo ${(micMix * 100).toInt()}%$r"
    }

}
