package com.mizan

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * 3D GAME · ENEMY SELECTION + CONTROL.
 *
 * Pick any figure of the 3D game world — YOU (the selected human), an enemy body, mic / mag / pose / camera body, a device —
 * by tapping it on the game board or with the floating SEL buttons, then control that ONE figure:
 *
 *   INSIDE ROTATION   the inside layers (skeleton · organs · vessels · brain) turn about the body's vertical axis, inside the skin
 *   HEAD PITCH        the head + neck nod up / down about the shoulders
 *
 * Each one has LEVEL · THRESHOLD · BIPOLAR · RAW · RANGE and is driven by the figure's own tracked energy
 * (below the threshold it goes the other way, exactly like the ambient board). Touch gives a manual offset on top:
 * drag sideways on the selected figure = inside rotation, drag up / down = head pitch, long press = reset.
 *
 * SUPER mode applies the selected figure's settings to EVERY tracked figure at once (each still follows its own energy).
 * RAW COMPLETE: no level, no threshold, no smoothing — the live energy goes straight to the angles.
 *
 * Everything is OFF by default (no figure is selected, no drive is on, the manual offsets are 0), so the original game
 * world draws exactly as before until the user selects a figure and turns a control on. It only changes how a figure is
 * DRAWN; it never writes to any audio, sensor or anatomy board.
 */
class GameEnemyControl {

    private companion object { const val P = "gec_" }

    class Cfg(val key: String) {
        // INSIDE ROTATION
        @Volatile var inRotOn = false
        @Volatile var inRotLevel = 0.85f      // 0..1.5
        @Volatile var inRotThr = 0.15f        // 0..0.98
        @Volatile var inRotRaw = false
        @Volatile var inRotBipolar = true
        @Volatile var inRotRange = 1.57f      // rad (0..π)
        @Volatile var inRotManual = 0f        // rad, from touch
        // HEAD PITCH
        @Volatile var pitchOn = false
        @Volatile var pitchLevel = 0.85f
        @Volatile var pitchThr = 0.15f
        @Volatile var pitchRaw = false
        @Volatile var pitchBipolar = true
        @Volatile var pitchRange = 0.70f      // rad (0..1.2)
        @Volatile var pitchManual = 0f        // rad, from touch
        // freeze both at the manual offsets
        @Volatile var locked = false
    }

    @Volatile var enabled = true
    /** Selected figure's settings apply to every tracked figure. */
    @Volatile var superMode = false
    /** RAW COMPLETE for every figure. */
    @Volatile var rawAll = false
    @Volatile var selectedKey: String? = null
    @Volatile var touchOn = true

    private val cfgs = HashMap<String, Cfg>()
    fun cfg(key: String): Cfg = cfgs.getOrPut(key) { Cfg(key).also { load(it) } }

    /** Settings used for [key]: the selected figure's in SUPER mode, otherwise its own. */
    fun effective(key: String): Cfg {
        val sel = selectedKey
        return if (superMode && sel != null) cfg(sel) else cfg(key)
    }

    fun selected(): Cfg? = selectedKey?.let { cfg(it) }

    /** True while any figure is being driven (so the renderer can skip all of this when nothing is on). */
    fun anyActive(): Boolean {
        if (!enabled) return false
        for (c in cfgs.values) if (c.inRotOn || c.pitchOn || c.inRotManual != 0f || c.pitchManual != 0f) return true
        return false
    }

    // ───────────────────────────────────────────────────────── per-frame
    private fun shape(e: Float, thr: Float, level: Float, bipolar: Boolean, raw: Boolean): Float {
        val s = e.coerceIn(0f, 1f)
        if (raw) return s * 2f - 1f
        val t = thr.coerceIn(0.02f, 0.98f)
        val signed = when {
            s >= t -> (s - t) / (1f - t)
            bipolar -> -(t - s) / t
            else -> 0f
        }
        return (signed * level.coerceIn(0f, 1.5f)).coerceIn(-1f, 1f)
    }

    fun tick(world: GameWorld3D) {
        if (!enabled) {
            for (b in world.allBodies()) { b.inRotAngle = 0f; b.pitchAngle = 0f }
            return
        }
        val rawWorld = world.raw || rawAll
        for (b in world.allBodies()) {
            val c = effective(b.key)
            val raw = rawWorld
            var yawT = 0f
            var pitT = 0f
            if (c.locked) {
                yawT = c.inRotManual; pitT = c.pitchManual
            } else {
                val e = b.energy
                if (c.inRotOn) yawT = shape(e, c.inRotThr, c.inRotLevel, c.inRotBipolar, raw || c.inRotRaw) * c.inRotRange.coerceIn(0f, PI.toFloat())
                if (c.pitchOn) pitT = shape(e, c.pitchThr, c.pitchLevel, c.pitchBipolar, raw || c.pitchRaw) * c.pitchRange.coerceIn(0f, 1.2f)
                yawT += c.inRotManual
                pitT += c.pitchManual
            }
            val snap = raw || (c.inRotRaw && c.pitchRaw)
            if (snap) { b.inRotAngle = yawT; b.pitchAngle = pitT }
            else {
                b.inRotAngle += (yawT - b.inRotAngle) * 0.25f
                b.pitchAngle += (pitT - b.pitchAngle) * 0.25f
            }
        }
    }

    // ───────────────────────────────────────────────────────── selection
    /** Figures that can be selected right now: YOU first, then every one that is on the board. */
    fun selectable(world: GameWorld3D): List<GameWorld3D.Body> {
        val l = ArrayList<GameWorld3D.Body>()
        l.add(world.you)
        for (b in world.bodies) if (b.on && (b.shown > 0.25f || b.tracked)) l.add(b)
        return l
    }

    fun select(key: String?) { selectedKey = key }

    /** Next / previous figure in [selectable]; with nothing selected the first press picks YOU. */
    fun cycle(world: GameWorld3D, dir: Int) {
        val l = selectable(world)
        if (l.isEmpty()) return
        val i = l.indexOfFirst { it.key == selectedKey }
        selectedKey = if (i < 0) l[0].key else l[((i + dir) % l.size + l.size) % l.size].key
    }

    fun labelOf(world: GameWorld3D, key: String?): String =
        if (key == null) "none" else if (key == world.you.key) "YOU" else world.bodies.firstOrNull { it.key == key }?.label ?: key

    fun resetManual(key: String? = selectedKey) {
        val k = key ?: return
        val c = cfg(k)
        c.inRotManual = 0f; c.pitchManual = 0f
        save(c)
    }

    // ───────────────────────────────────────────────────────── touch
    private var dragKey: String? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downMs = 0L
    private var moved = false

    /**
     * Touch on the game board. Returns true only when the touch started on a figure (so every other touch on the view
     * behaves exactly as before). Tap = select · drag sideways = inside rotation · drag up / down = head pitch ·
     * long press without moving = reset the manual offsets.
     */
    fun onTouch(ev: MotionEvent, world: GameWorld3D): Boolean {
        if (!enabled || !touchOn || !world.enabled) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!world.boardContains(ev.x, ev.y)) return false
                val hit = world.hitTest(ev.x, ev.y)
                if (hit == null) {
                    // tap on the empty board clears the selection but lets the view see the touch too
                    selectedKey = null
                    return false
                }
                selectedKey = hit.key
                dragKey = hit.key
                downX = ev.x; downY = ev.y; lastX = ev.x; lastY = ev.y
                downMs = System.currentTimeMillis(); moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val k = dragKey ?: return false
                val dx = ev.x - lastX
                val dy = ev.y - lastY
                lastX = ev.x; lastY = ev.y
                if (hypot(ev.x - downX, ev.y - downY) > 12f) moved = true
                if (!moved) return true
                val c = cfg(k)
                if (abs(dx) >= abs(dy)) {
                    c.inRotManual = (c.inRotManual + dx * 0.012f).coerceIn(-PI.toFloat(), PI.toFloat())
                } else {
                    c.pitchManual = (c.pitchManual - dy * 0.008f).coerceIn(-1.2f, 1.2f)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val k = dragKey ?: return false
                dragKey = null
                if (ev.actionMasked == MotionEvent.ACTION_UP && !moved && System.currentTimeMillis() - downMs > 600L) resetManual(k)
                else save(cfg(k))
                return true
            }
        }
        return false
    }

    // ───────────────────────────────────────────────────────── overlay (selection ring + readout)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; textAlign = Paint.Align.CENTER }

    fun drawOverlay(canvas: Canvas, world: GameWorld3D, phase: Float) {
        if (!enabled) return
        val key = selectedKey ?: return
        val b = if (key == world.you.key) world.you else world.bodies.firstOrNull { it.key == key } ?: return
        val r = world.viewRect()
        val unit = world.unitPx()
        if (b.scrOn) {
            val pulse = 0.5f + 0.5f * sin(phase * 0.12f)
            line.strokeWidth = max(2f, unit * 0.025f)
            line.color = Color.argb((150 + 100 * pulse).toInt(), 0xFF, 0xEB, 0x3B)
            canvas.drawCircle(b.scrX, b.scrY, b.hitR * (1.05f + 0.06f * pulse), line)
        }
        val c = effective(key)
        val deg = { rad: Float -> Math.toDegrees(rad.toDouble()).toInt() }
        txt.textAlign = Paint.Align.CENTER
        txt.textSize = unit * 0.115f
        txt.color = Color.argb(235, 0xFF, 0xEB, 0x3B)
        val s = buildString {
            append("SEL ").append(labelOf(world, key))
            if (superMode) append(" · SUPER")
            if (rawAll || world.raw) append(" · RAW")
            if (c.locked) append(" · LOCK")
            append(" · IN-ROT ").append(if (c.inRotOn) "on" else "off").append(' ').append(deg(b.inRotAngle)).append('°')
            append(" · PITCH ").append(if (c.pitchOn) "on" else "off").append(' ').append(deg(b.pitchAngle)).append('°')
        }
        canvas.drawText(s, r.centerX(), r.bottom - unit * 0.08f, txt)
    }

    // ───────────────────────────────────────────────────────── memory
    fun save(c: Cfg) {
        val p = "$P${c.key}_"
        MemoryPaths.putBool(p + "ir_on", c.inRotOn); MemoryPaths.putFloat(p + "ir_lv", c.inRotLevel)
        MemoryPaths.putFloat(p + "ir_thr", c.inRotThr); MemoryPaths.putBool(p + "ir_raw", c.inRotRaw)
        MemoryPaths.putBool(p + "ir_bip", c.inRotBipolar); MemoryPaths.putFloat(p + "ir_rng", c.inRotRange)
        MemoryPaths.putBool(p + "pt_on", c.pitchOn); MemoryPaths.putFloat(p + "pt_lv", c.pitchLevel)
        MemoryPaths.putFloat(p + "pt_thr", c.pitchThr); MemoryPaths.putBool(p + "pt_raw", c.pitchRaw)
        MemoryPaths.putBool(p + "pt_bip", c.pitchBipolar); MemoryPaths.putFloat(p + "pt_rng", c.pitchRange)
        MemoryPaths.putBool(p + "lock", c.locked)
    }

    private fun load(c: Cfg) {
        val p = "$P${c.key}_"
        c.inRotOn = MemoryPaths.getBool(p + "ir_on", c.inRotOn); c.inRotLevel = MemoryPaths.getFloat(p + "ir_lv", c.inRotLevel)
        c.inRotThr = MemoryPaths.getFloat(p + "ir_thr", c.inRotThr); c.inRotRaw = MemoryPaths.getBool(p + "ir_raw", c.inRotRaw)
        c.inRotBipolar = MemoryPaths.getBool(p + "ir_bip", c.inRotBipolar); c.inRotRange = MemoryPaths.getFloat(p + "ir_rng", c.inRotRange)
        c.pitchOn = MemoryPaths.getBool(p + "pt_on", c.pitchOn); c.pitchLevel = MemoryPaths.getFloat(p + "pt_lv", c.pitchLevel)
        c.pitchThr = MemoryPaths.getFloat(p + "pt_thr", c.pitchThr); c.pitchRaw = MemoryPaths.getBool(p + "pt_raw", c.pitchRaw)
        c.pitchBipolar = MemoryPaths.getBool(p + "pt_bip", c.pitchBipolar); c.pitchRange = MemoryPaths.getFloat(p + "pt_rng", c.pitchRange)
        c.locked = MemoryPaths.getBool(p + "lock", c.locked)
    }

    /** Loads the global switches (super / raw / touch). Call once when the floating panel is built. */
    fun loadGlobals() {
        superMode = MemoryPaths.getBool("gec_super", superMode)
        rawAll = MemoryPaths.getBool("gec_rawall", rawAll)
        touchOn = MemoryPaths.getBool("gec_touch", touchOn)
    }

    fun saveGlobals() {
        MemoryPaths.putBool("gec_super", superMode)
        MemoryPaths.putBool("gec_rawall", rawAll)
        MemoryPaths.putBool("gec_touch", touchOn)
    }
}
