package com.mizan

/**
 * Reproductive anatomy ambient — medical inside/outside channels only.
 * Symbolic ambient for complete human model coverage. RAW COMPLETE.
 */
class ReproAnatomyAmbientBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.30f
    @Volatile var levelAmt = 0.85f

    // Male structures (medical)
    @Volatile var penisExternal = 0f
    @Volatile var scrotum = 0f
    @Volatile var testis = 0f
    @Volatile var epididymis = 0f
    @Volatile var vasDeferens = 0f
    @Volatile var prostate = 0f
    @Volatile var seminalVesicle = 0f
    // Female structures (medical)
    @Volatile var vulvaExternal = 0f
    @Volatile var vagina = 0f
    @Volatile var cervix = 0f
    @Volatile var uterus = 0f
    @Volatile var ovary = 0f
    @Volatile var fallopian = 0f
    // Shared
    @Volatile var gonads = 0f
    @Volatile var externalGenitalia = 0f
    @Volatile var internalDucts = 0f
    @Volatile var reproFull = 0f
    @Volatile var status = "REPRO idle"

    private fun lane(e: Float): Float {
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * levelAmt).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * levelAmt).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, body: Float) {
        if (!enabled) { status = "REPRO OFF"; return }
        val e = maxOf(mic * 0.4f, body).coerceIn(0f, 1.5f)
        penisExternal = lane(e * 0.88f)
        scrotum = lane(e * 0.86f)
        testis = lane(e * 0.90f)
        epididymis = lane(e * 0.84f)
        vasDeferens = lane(e * 0.83f)
        prostate = lane(e * 0.87f)
        seminalVesicle = lane(e * 0.82f)
        vulvaExternal = lane(e * 0.88f)
        vagina = lane(e * 0.87f)
        cervix = lane(e * 0.85f)
        uterus = lane(e * 0.89f)
        ovary = lane(e * 0.90f)
        fallopian = lane(e * 0.84f)
        gonads = maxOf(testis, ovary)
        externalGenitalia = maxOf(penisExternal, vulvaExternal)
        internalDucts = maxOf(vasDeferens, fallopian, vagina, uterus)
        reproFull = maxOf(gonads, externalGenitalia, internalDucts, prostate, uterus)
        if (rawComplete) reproFull = maxOf(reproFull, 0.25f + e * 0.3f)
        status = "REPRO full=${(reproFull*100).toInt()}% · gonad=${(gonads*100).toInt()}% · ext=${(externalGenitalia*100).toInt()}% · int=${(internalDucts*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView?) {
        if (!enabled || reproFull < 0.02f) return
        val vv = v ?: return
        try {
            vv.fullAnatomy132.bodyPartsOut = maxOf(vv.fullAnatomy132.bodyPartsOut, reproFull * 0.6f)
            vv.anatomy3d.layerLevel[2] = maxOf(vv.anatomy3d.layerLevel[2], reproFull * 0.5f)
        } catch (_: Throwable) {}
    }
}
