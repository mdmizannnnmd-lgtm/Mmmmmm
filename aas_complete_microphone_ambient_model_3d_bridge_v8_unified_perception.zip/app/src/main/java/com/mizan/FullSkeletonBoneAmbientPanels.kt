package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object FullSkeletonBoneAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: FullSkeletonBoneAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFB0BEC5.toInt()
        p.title("FULL SKELETON · SKULL/FACE/OCCIPUT/LIMBS · ENEMY BONE LOCK · NEURO SPIKE · MIC dB", c)
        p.note("Symbolic ambient only. Does not control real people. 3D skeleton layer + protect stack.")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Skeleton ambient ON", b.skeletonOn) { b.skeletonOn = it }
        p.seek("Bone thr", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Bone level", 0f, 1.5f, b.lv) { b.lv = it }
        p.switch("Enemy bone/skeleton thr ON", b.enemyBoneOn) { b.enemyBoneOn = it }
        p.seek("Enemy bone thr", 0.05f, 0.98f, b.enemyBoneThr) { b.enemyBoneThr = it }
        p.seek("Enemy bone level", 0f, 1.5f, b.enemyBoneLv) { b.enemyBoneLv = it }
        p.switch("Neural spike protect ON", b.neuroSpikeOn) { b.neuroSpikeOn = it }
        p.seek("Neuro spike thr", 0.05f, 0.98f, b.neuroSpikeThr) { b.neuroSpikeThr = it }
        p.seek("Neuro spike level", 0f, 1.5f, b.neuroSpikeLv) { b.neuroSpikeLv = it }
        p.seek("Mic dB thr LO", -80f, 0f, b.micDbThrLo) { b.micDbThrLo = it }
        p.seek("Mic dB thr HI", -80f, 0f, b.micDbThrHi) { b.micDbThrHi = it }
        p.switch("Eye pitching protect ON", b.eyePitchProtectOn) { b.eyePitchProtectOn = it }
        p.seek("Eye pitch thr", 0.05f, 0.98f, b.eyePitchThr) { b.eyePitchThr = it }
        p.seek("Eye pitch level", 0f, 1.5f, b.eyePitchLv) { b.eyePitchLv = it }
        val st = p.status("SKELETON —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 200) }
        })
    }
}
