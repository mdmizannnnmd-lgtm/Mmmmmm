package com.mizan

/**
 * All ambient systems — unified centroid · vertical · Hz · dB · inside · outside · RAW COMPLETE.
 *
 * Systems:
 *  1. AmbientThresholdBoard (mic spectrum centroid + body vertical)
 *  2. CentroidDrive (move · speed · wave · ambient · eyes · body84)
 *  3. BodyAtmosphere3D atomspare
 *  4. ScreenAmbientBoard
 *  5. PoseSurfaceBoard ambient
 *  6. YoloSeg / body surface dampen path
 *  7. OnenessHub RAW COMPLETE EVERYTHING
 */
object AmbientSystems {

    data class Snapshot(
        val cenHz: Float,
        val db: Double,
        val verPct: Float,
        val cenOut: Float,
        val verOut: Float,
        val inCen: Float,
        val inVer: Float,
        val outCen: Float,
        val outVer: Float,
        val inHz: Float,
        val outHz: Float,
        val raw: Boolean
    )

    fun snapshot(board: AmbientThresholdBoard): Snapshot {
        return Snapshot(
            cenHz = board.centroidHz,
            db = board.micDb(),
            verPct = board.verticalNorm,
            cenOut = board.centroidOut,
            verOut = board.verticalOut,
            inCen = board.insideCenOut,
            inVer = board.insideVerOut,
            outCen = board.outsideCenOut,
            outVer = board.outsideVerOut,
            inHz = board.insideHz,
            outHz = board.outsideHz,
            raw = board.rawEverything
        )
    }

    fun line(s: Snapshot): String =
        "ALL AMBIENT · CEN ${s.cenHz.toInt()}Hz ${"%+.0f".format(s.db)}dB · VERT ${(s.verPct*100).toInt()}% · " +
        "IN ${s.inHz.toInt()}Hz C${(s.inCen*100).toInt()}% V${(s.inVer*100).toInt()}% · " +
        "OUT ${s.outHz.toInt()}Hz C${(s.outCen*100).toInt()}% V${(s.outVer*100).toInt()}%" +
        (if (s.raw) " · RAW COMPLETE" else "")

    /**
     * RAW COMPLETE on every ambient path (threshold board · centroid drive · atomspare · pose · yolo · oneness).
     */
    fun enableRawCompleteAll(v: VisualShieldView) {
        v.oneness.setRawEverything(v, true)
        val ab = v.ambientBoard
        ab.rawEverything = true
        ab.centroidRaw = true
        ab.verticalRaw = true
        ab.centroidOn = true
        ab.verticalOn = true
        v.cenDrive.enableRawComplete()
        v.bodyAtmo3d.enableAtomRawComplete()
        v.poseSurface.enabled = true
        v.poseSurface.ambientOn = true
        runCatching { v.yoloSeg.enableRawCompleteSeg() }
        v.insideAmbient.enableRawComplete()
        ab.movement.enableRawComplete()
        v.yoloObbTrack.enableRawComplete()
        v.ensureCompleteBodySkin()
    }
}
