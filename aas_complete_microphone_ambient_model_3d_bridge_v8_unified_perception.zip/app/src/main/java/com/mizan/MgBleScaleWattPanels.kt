package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object MgBleScaleWattPanels {
    fun build(ctx: Context, root: LinearLayout, b: MgBleScaleWattBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFB0BEC5.toInt()
        p.title("Mg AMBIENT · BLE WEIGHT/HEIGHT SCALE · CHEM TRACK · VIBE/AXIS · WATT", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("MAGNESIUM (model-driven)", c)
        p.switch("Mg ambient ON", b.mgOn) { b.mgOn = it }
        p.seek("Mg thr", 0.05f, 0.98f, b.mgThr) { b.mgThr = it }
        p.seek("Mg level", 0f, 1.5f, b.mgLv) { b.mgLv = it }

        p.title("BLE DIGITAL SCALE", c)
        p.switch("Scale ON", b.scaleOn) { b.scaleOn = it }
        p.switch("Auto maintain scale", b.scaleMaintain) { b.scaleMaintain = it }
        p.seek("Weight kg", 30f, 200f, b.weightKg) {
            b.weightKg = it
            b.lastWeightKg = it
        }
        p.seek("Height cm", 100f, 220f, b.heightCm) {
            b.heightCm = it
            b.lastHeightCm = it
        }

        p.title("CHEMICAL TRACKING", c)
        p.switch("Chem track ON", b.chemTrackOn) { b.chemTrackOn = it }

        p.title("BLE VIBRATION", c)
        p.switch("Vibration ON", b.vibeOn) { b.vibeOn = it }
        p.seek("Vibe thr", 0.05f, 0.98f, b.vibeThr) { b.vibeThr = it }
        p.seek("Vibe level", 0f, 1.5f, b.vibeLv) { b.vibeLv = it }

        p.title("AXIS THRESHOLD / LEVEL", c)
        p.switch("Axis ON", b.axisOn) { b.axisOn = it }
        p.seek("Axis thr", 0.05f, 0.98f, b.axisThr) { b.axisThr = it }
        p.seek("Axis level", 0f, 1.5f, b.axisLv) { b.axisLv = it }

        p.title("WATT API TRACKING", c)
        p.switch("Watt track ON", b.wattOn) { b.wattOn = it }
        p.seek("Watt thr", 0.05f, 0.98f, b.wattThr) { b.wattThr = it }
        p.seek("Watt level", 0f, 1.5f, b.wattLv) { b.wattLv = it }

        val st = p.status("Mg·SCALE·WATT —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 250) }
        })
    }
}
