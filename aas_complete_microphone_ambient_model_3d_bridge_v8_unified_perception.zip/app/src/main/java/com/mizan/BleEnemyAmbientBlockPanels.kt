package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object BleEnemyAmbientBlockPanels {
    fun build(ctx: Context, root: LinearLayout, b: BleEnemyAmbientBlockBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF80CBC4.toInt()
        p.title("BLE SENSOR THR · ENEMY BLE BLOCK · AUDIO SAME-EFFECT BLOCK", c)
        p.note("Own BLE keep · enemy BLE ambient block · enemies cannot mirror same audio/BLE effect")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Enemy BLE block", b.enemyBleBlockOn) { b.enemyBleBlockOn = it }
        p.switch("Audio mirror block", b.audioMirrorBlockOn) { b.audioMirrorBlockOn = it }
        p.seek("Own BLE thr", 0.05f, 0.9f, b.ownBleThr) { b.ownBleThr = it }
        p.seek("Own BLE level", 0.2f, 1.5f, b.ownBleLv) { b.ownBleLv = it }
        p.seek("Enemy BLE thr", 0.05f, 0.9f, b.enemyBleThr) { b.enemyBleThr = it }
        p.seek("Enemy BLE block lv", 0.3f, 1.2f, b.enemyBleBlockLv) { b.enemyBleBlockLv = it }
        p.seek("Audio mirror thr", 0.05f, 0.9f, b.audioMirrorThr) { b.audioMirrorThr = it }
        p.seek("Audio block lv", 0.3f, 1.2f, b.audioMirrorBlockLv) { b.audioMirrorBlockLv = it }
        val st = p.status("BLE-BLOCK —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() {
                st.text = b.status
                Handler(Looper.getMainLooper()).postDelayed(this, 280)
            }
        })
    }
}
