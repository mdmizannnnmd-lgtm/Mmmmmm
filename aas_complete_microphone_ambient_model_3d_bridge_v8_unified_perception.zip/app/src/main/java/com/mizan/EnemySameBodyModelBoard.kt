package com.mizan

/**
 * Tracked enemies use the SAME 3D human body model as the user (pose/seg/obb 84).
 * Games-style shared mesh · threshold · motion lock feed. RAW COMPLETE.
 */
class EnemySameBodyModelBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var sameMeshOn = true
    @Volatile var thr = 0.30f
    @Volatile var levelAmt = 0.90f
    @Volatile var enemyBodyOut = 0f
    @Volatile var sharedPose = 0f
    @Volatile var sharedSeg = 0f
    @Volatile var sharedObb = 0f
    @Volatile var status = "ENEMY-SAME-BODY idle"

    fun tick(mic: Float, pose: Float, seg: Float, obb: Float, enemy3d: Float) {
        if (!enabled) { status = "ENEMY-SAME-BODY OFF"; return }
        val e = maxOf(mic * 0.5f, enemy3d, pose * 0.8f).coerceIn(0f, 1.5f)
        sharedPose = if (sameMeshOn) (pose * levelAmt).coerceIn(0f, 1f) else 0f
        sharedSeg = if (sameMeshOn) (seg * levelAmt).coerceIn(0f, 1f) else 0f
        sharedObb = if (sameMeshOn) (obb * levelAmt).coerceIn(0f, 1f) else 0f
        enemyBodyOut = if (e >= thr) maxOf(sharedPose, sharedSeg, sharedObb, (e - thr) * levelAmt) else 0f
        if (rawComplete) enemyBodyOut = maxOf(enemyBodyOut, 0.3f + e * 0.3f)
        status = "ENEMY-SAME-BODY out=${(enemyBodyOut*100).toInt()}% · pose/seg/obb=${(sharedPose*100).toInt()}/${(sharedSeg*100).toInt()}/${(sharedObb*100).toInt()}" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView?) {
        if (!enabled || enemyBodyOut < 0.02f) return
        val vv = v ?: return
        try {
            vv.enemy3dProtect.enemyModelOut = maxOf(vv.enemy3dProtect.enemyModelOut, enemyBodyOut)
            try { /* shared mesh intensity */ } catch (_: Throwable) {}
            vv.anatomy3d.atmosphere = maxOf(vv.anatomy3d.atmosphere, enemyBodyOut * 0.25f)
            try { vv.anatomy3d.layerLevel[1] = maxOf(vv.anatomy3d.layerLevel[1], enemyBodyOut * 0.4f) } catch (_: Throwable) {}
            try { vv.fullModel3d.enabled = vv.fullModel3d.enabled } catch (_: Throwable) {}
        } catch (_: Throwable) {}
    }
}
