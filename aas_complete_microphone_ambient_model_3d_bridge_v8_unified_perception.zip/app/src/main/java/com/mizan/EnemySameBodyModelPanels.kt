package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object EnemySameBodyModelPanels {
    fun build(ctx: Context, root: LinearLayout, b: EnemySameBodyModelBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFFAB91.toInt()
        p.title("ENEMY · SAME 3D BODY MODEL", c)
        p.note("Tracked enemies share user pose/seg/obb human mesh")
        p.switch("Same body ON", b.enabled) { b.enabled = it }
        p.switch("Shared mesh", b.sameMeshOn) { b.sameMeshOn = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.seek("Threshold", 0.05f, 1f, b.thr) { b.thr = it }
        p.seek("Level", 0.1f, 1.5f, b.levelAmt) { b.levelAmt = it }
        val st = p.status("ENEMY-BODY —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 300) }
        })
    }
}
