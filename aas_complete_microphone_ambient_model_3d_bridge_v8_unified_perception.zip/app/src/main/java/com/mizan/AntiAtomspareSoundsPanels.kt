package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object AntiAtomspareSoundsPanels {
    fun build(ctx: Context, root: LinearLayout, b: AntiAtomspareSoundsBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF80CBC4.toInt()
        p.title("ANTI-ATOMSPARE SOUNDS · OUT/IN · SPIKE · COLLIDE · RIPPLE · ENEMY ATOM", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Anti-atomspare ON", b.antiOn) { b.antiOn = it }
        p.seek("Anti thr", 0.05f, 0.98f, b.antiThr) { b.antiThr = it }
        p.seek("Anti level", 0f, 1.5f, b.antiLv) { b.antiLv = it }
        val st = p.status("ANTI-ATOM —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 200) }
        })
    }
}
