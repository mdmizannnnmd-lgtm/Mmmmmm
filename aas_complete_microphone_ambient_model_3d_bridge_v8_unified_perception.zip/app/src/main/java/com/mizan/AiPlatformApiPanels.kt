package com.mizan

import android.content.Context
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object AiPlatformApiPanels {
    fun build(ctx: Context, root: LinearLayout, b: AiPlatformApiBoard) {
        val c = 0xFF80CBC4.toInt()
        root.addView(TextView(ctx).apply {
            text = "AI PLATFORM API · ChatGPT / OpenAI-compatible · YOUR KEY"
            setTextColor(c)
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setPadding(8, 12, 8, 4)
        })
        root.addView(TextView(ctx).apply {
            text = "Use only API keys you own and endpoints you are allowed to call."
            setTextColor(0xFF90A4AE.toInt())
            textSize = 11f
            setPadding(8, 0, 8, 8)
        })

        fun label(s: String) = TextView(ctx).apply {
            text = s; setTextColor(0xFFB0BEC5.toInt()); textSize = 12f; setPadding(8, 6, 8, 2)
        }
        fun edit(hint: String, multi: Boolean = false, password: Boolean = false) = EditText(ctx).apply {
            this.hint = hint
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0x88FFFFFF.toInt())
            setBackgroundColor(0x33FFFFFF)
            setPadding(12, 10, 12, 10)
            if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else if (multi) {
                minLines = 2; maxLines = 5
                gravity = android.view.Gravity.TOP or android.view.Gravity.START
            } else setSingleLine(true)
        }

        val platRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            AiPlatformApiBoard.Platform.OPENAI,
            AiPlatformApiBoard.Platform.OPENAI_COMPAT,
            AiPlatformApiBoard.Platform.CUSTOM
        ).forEach { p ->
            platRow.addView(Button(ctx).apply {
                text = p.label.take(12)
                textSize = 10f
                setOnClickListener { b.selectPlatform(p) }
            })
        }
        root.addView(label("Base URL"))
        val baseEdit = edit("https://api.openai.com/v1").apply { setText(b.baseUrl) }
        root.addView(baseEdit)
        root.addView(label("Platform"))
        root.addView(platRow)

        root.addView(label("API key"))
        val keyEdit = edit("sk-…", password = true).apply { setText(b.apiKey) }
        root.addView(keyEdit)

        root.addView(label("Model"))
        val modelEdit = edit("gpt-4o-mini").apply { setText(b.model) }
        root.addView(modelEdit)

        root.addView(label("System prompt"))
        val sysEdit = edit("system", multi = true).apply { setText(b.systemPrompt) }
        root.addView(sysEdit)

        root.addView(label("User prompt"))
        val userEdit = edit("user message", multi = true).apply { setText(b.userPrompt) }
        root.addView(userEdit)

        val statusTv = TextView(ctx).apply {
            text = b.status; setTextColor(c); textSize = 12f; setPadding(8, 8, 8, 4)
        }
        root.addView(statusTv)

        val respBox = edit("response", multi = true).apply {
            isFocusable = false; minLines = 5; maxLines = 12
            setTextColor(0xFFE0E0E0.toInt())
        }
        root.addView(label("Response"))
        root.addView(respBox)

        root.addView(Button(ctx).apply {
            text = "Send chat completion"
            setOnClickListener {
                b.apiKey = keyEdit.text?.toString().orEmpty()
                b.baseUrl = baseEdit.text?.toString().orEmpty()
                b.model = modelEdit.text?.toString().orEmpty()
                b.systemPrompt = sysEdit.text?.toString().orEmpty()
                b.userPrompt = userEdit.text?.toString().orEmpty()
                b.sendChat {
                    statusTv.text = b.status
                    respBox.setText(
                        if (b.lastError.isNotEmpty()) "ERROR: ${b.lastError}\n${b.lastResponse}"
                        else b.lastResponse
                    )
                }
            }
        })

        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                statusTv.text = b.status
                h.postDelayed(this, 400)
            }
        })
    }
}
