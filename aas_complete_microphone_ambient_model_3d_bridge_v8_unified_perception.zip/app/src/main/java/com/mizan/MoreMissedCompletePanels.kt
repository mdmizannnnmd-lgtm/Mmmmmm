package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object MoreMissedCompletePanels {
    fun build(ctx: Context, root: LinearLayout, b: MoreMissedCompleteBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFB0BEC5.toInt()
        p.title("MORE MISSED · EAR · ORAL · HAND/FOOT · SKIN LAYERS · JOINT · LYMPH", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.seek("Shared thr", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Shared level", 0f, 1.5f, b.lv) { b.lv = it }
        p.switch("Ears / auditory ON", b.earOn) { b.earOn = it }
        p.switch("Oral (teeth tongue throat) ON", b.oralOn) { b.oralOn = it }
        p.switch("Hands / feet ON", b.extremitiesOn) { b.extremitiesOn = it }
        p.switch("Skin layers ON", b.skinLayersOn) { b.skinLayersOn = it }
        p.switch("Pelvic / reproductive ON", b.pelvicOn) { b.pelvicOn = it }
        p.switch("Joints / tendons / fascia ON", b.jointOn) { b.jointOn = it }
        p.switch("Lymph ON", b.lymphOn) { b.lymphOn = it }
        val st = p.status("MORE-MISSED —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
