package com.mizan

/**
 * Anti-atomspare sounds — cancel enemy atomspare / atmospheric SFX ·
 * with thr · level · stacks body-region + enemy cancel. RAW COMPLETE.
 */
class AntiAtomspareSoundsBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    @Volatile var antiOn = true
    @Volatile var antiThr = 0.20f
    @Volatile var antiLv = 0.95f
    @Volatile var antiOut = 0f

    @Volatile var antiOutside = 0f
    @Volatile var antiInside = 0f
    @Volatile var antiSpike = 0f
    @Volatile var antiCollide = 0f
    @Volatile var antiRipple = 0f
    @Volatile var antiEnemyAtom = 0f

    @Volatile var status = "ANTI-ATOMSPARE SFX idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        mic: Float,
        atomOut: Float,
        atomIn: Float,
        spike: Float,
        collide: Float,
        ripple: Float,
        enemyAtom: Float
    ) {
        if (!enabled) {
            status = "ANTI-ATOMSPARE OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        antiOutside = lane(antiOn, antiThr, antiLv, maxOf(atomOut, e * 0.5f))
        antiInside = lane(antiOn, antiThr, antiLv, maxOf(atomIn, e * 0.45f))
        antiSpike = lane(antiOn, antiThr, antiLv, spike)
        antiCollide = lane(antiOn, antiThr, antiLv, collide)
        antiRipple = lane(antiOn, antiThr, antiLv, ripple)
        antiEnemyAtom = lane(antiOn, antiThr, antiLv, enemyAtom)
        antiOut = maxOf(antiOutside, antiInside, antiSpike, antiCollide, antiRipple, antiEnemyAtom)

        status =
            "ANTI-ATOM=${(antiOut*100).toInt()}% out/in=${(antiOutside*100).toInt()}/${(antiInside*100).toInt()} · " +
            "spk/col/rip=${(antiSpike*100).toInt()}/${(antiCollide*100).toInt()}/${(antiRipple*100).toInt()} · " +
            "enemyAtom=${(antiEnemyAtom*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled) return
        if (antiOut > 0.02f) {
            val k = (1f - antiOut * 0.96f).coerceIn(0.02f, 1f)
            sb.collideOut *= (1f - antiCollide * 0.95f).coerceIn(0.02f, 1f)
            sb.rippleOut *= (1f - antiRipple * 0.95f).coerceIn(0.02f, 1f)
            sb.burstOut *= (1f - antiSpike * 0.9f).coerceIn(0.05f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
            sb.whipOut *= k
        }
        val vv = v ?: return
        try {
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, antiOut)
            // strengthen shield presence without wiping user's atom levels entirely
            vv.completeAtomProtect.atomOutsideOut = maxOf(vv.completeAtomProtect.atomOutsideOut, antiOutside * 0.4f)
            vv.completeAtomProtect.atomInsideOut = maxOf(vv.completeAtomProtect.atomInsideOut, antiInside * 0.4f)
        } catch (_: Throwable) {}
        try {
            vv.enemySoundCancel.atomEnemyCancelOut = maxOf(vv.enemySoundCancel.atomEnemyCancelOut, antiEnemyAtom, antiOut)
            vv.bodyRegionEnemyProtect.protectOut = maxOf(vv.bodyRegionEnemyProtect.protectOut, antiOut * 0.8f)
            vv.skinSoundsProtect.atomSpikeProt = maxOf(vv.skinSoundsProtect.atomSpikeProt, antiSpike)
            vv.fullAmbientMaster.atomFull = maxOf(vv.fullAmbientMaster.atomFull, antiOut * 0.35f)
        } catch (_: Throwable) {}
        try {
            vv.anatomy3d.atmosphere = maxOf(vv.anatomy3d.atmosphere, antiOut * 0.3f)
        } catch (_: Throwable) {}
    }
}
