package com.mizan

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

/**
 * Prank-app style sensor-gated SFX detect (Android SensorManager pattern).
 * Accel impact + mic transient + cooldown → bullet/knife/burst-like gates.
 * Symbolic SFX / prank architecture only — not real weapons.
 * RAW COMPLETE.
 */
class SensorGatedSfxDetectBoard : SensorEventListener {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var sensorOn = true
    @Volatile var micGateOn = true
    @Volatile var requireBoth = false // if true need accel AND mic

    @Volatile var accelSens = 2.8f   // delta-g threshold (prank apps ~2.5–4)
    @Volatile var micThr = 0.22f
    @Volatile var cooldownMs = 450L
    @Volatile var impactG = 0f
    @Volatile var micTransient = 0f

    @Volatile var slapHit = 0f
    @Volatile var bulletLike = 0f
    @Volatile var knifeLike = 0f
    @Volatile var burstLike = 0f
    @Volatile var whipLike = 0f
    @Volatile var hits = 0
    @Volatile var lastHitMs = 0L

    private var sm: SensorManager? = null
    private var accel: Sensor? = null
    private var lastMag = 9.81f
    private var gravity = floatArrayOf(0f, 0f, 9.81f)
    private val alpha = 0.8f
    private var prevMic = 0f

    @Volatile var status = "SFX-SENSOR idle"

    fun start(ctx: Context) {
        if (sm != null) return
        sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        accel = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        accel?.let {
            sm?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        sm?.unregisterListener(this)
        sm = null
        accel = null
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(event: SensorEvent?) {
        if (!enabled || !sensorOn || event == null) return
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        // low-pass gravity, high-pass linear accel (Android docs pattern)
        gravity[0] = alpha * gravity[0] + (1 - alpha) * x
        gravity[1] = alpha * gravity[1] + (1 - alpha) * y
        gravity[2] = alpha * gravity[2] + (1 - alpha) * z
        val lx = x - gravity[0]
        val ly = y - gravity[1]
        val lz = z - gravity[2]
        val mag = sqrt(lx * lx + ly * ly + lz * lz)
        impactG = mag
        lastMag = mag
    }

    fun tick(mic: Float) {
        if (!enabled) {
            status = "SFX-SENSOR OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val dMic = (e - prevMic).coerceAtLeast(0f)
        prevMic = e
        micTransient = dMic * 4f + e * 0.3f

        val now = System.currentTimeMillis()
        val cooled = now - lastHitMs >= cooldownMs
        val accelHit = sensorOn && impactG >= accelSens
        val micHit = micGateOn && micTransient >= micThr
        val fire = when {
            requireBoth -> accelHit && micHit
            else -> accelHit || micHit
        } && cooled

        if (fire || rawComplete && e > 0.05f) {
            if (fire) {
                hits++
                lastHitMs = now
            }
            val strength = maxOf(
                (impactG / (accelSens * 2f)).coerceIn(0f, 1.5f),
                (micTransient / (micThr * 2f)).coerceIn(0f, 1.5f)
            )
            slapHit = strength.coerceIn(0f, 1f)
            // rough shape: high transient + high mic → bullet-like; mid whoosh → knife; broad → burst
            bulletLike = (strength * (0.5f + e * 0.5f)).coerceIn(0f, 1f)
            knifeLike = (strength * (0.45f + dMic * 2f)).coerceIn(0f, 1f)
            burstLike = (strength * 0.85f).coerceIn(0f, 1f)
            whipLike = if (accelHit) (strength * 0.9f).coerceIn(0f, 1f) else knifeLike * 0.6f
        } else {
            slapHit *= 0.85f
            bulletLike *= 0.88f
            knifeLike *= 0.88f
            burstLike *= 0.88f
            whipLike *= 0.88f
        }

        status =
            "SFX g=${"%.2f".format(impactG)} micT=${"%.2f".format(micTransient)} · " +
            "slap/bu/kn/br=${(slapHit*100).toInt()}/${(bulletLike*100).toInt()}/${(knifeLike*100).toInt()}/${(burstLike*100).toInt()} · " +
            "hits=$hits cd=${cooldownMs}ms" + if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled) return
        // boost detect paths (symbolic) when sensor/mic fires
        if (bulletLike > 0.05f) sb.bulletOut = maxOf(sb.bulletOut, bulletLike * 0.35f)
        if (knifeLike > 0.05f) sb.knifeOut = maxOf(sb.knifeOut, knifeLike * 0.35f)
        if (burstLike > 0.05f) sb.burstOut = maxOf(sb.burstOut, burstLike * 0.3f)
        if (whipLike > 0.05f) sb.whipOut = maxOf(sb.whipOut, whipLike * 0.3f)
        val vv = v ?: return
        try {
            vv.enemySoundCounters.antiBulletOut = maxOf(vv.enemySoundCounters.antiBulletOut, bulletLike * 0.5f)
            vv.enemySoundCounters.antiKnifeOut = maxOf(vv.enemySoundCounters.antiKnifeOut, knifeLike * 0.5f)
            vv.enemySoundCounters.antiBurstOut = maxOf(vv.enemySoundCounters.antiBurstOut, burstLike * 0.45f)
            vv.finalProtectionMain.bulletProt = maxOf(vv.finalProtectionMain.bulletProt, bulletLike * 0.4f)
            vv.finalProtectionMain.knifeProt = maxOf(vv.finalProtectionMain.knifeProt, knifeLike * 0.4f)
            vv.finalProtectionMain.burstProt = maxOf(vv.finalProtectionMain.burstProt, burstLike * 0.4f)
        } catch (_: Throwable) {}
    }
}
