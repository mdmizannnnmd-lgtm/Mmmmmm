package com.mizan

/**
 * Complete Face · Eye · Noise — no more missing.
 * Full face regions · full eye stack · noise ambient/threshold/spike. RAW COMPLETE.
 */
class FaceEyeNoiseCompleteBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Face complete
    @Volatile var faceOn = true
    @Volatile var faceThr = 0.22f
    @Volatile var faceLv = 0.85f
    @Volatile var faceOut = 0f
    @Volatile var forehead = 0f
    @Volatile var browL = 0f; @Volatile var browR = 0f
    @Volatile var cheekL = 0f; @Volatile var cheekR = 0f
    @Volatile var nose = 0f
    @Volatile var nostrilL = 0f; @Volatile var nostrilR = 0f
    @Volatile var lips = 0f
    @Volatile var mouth = 0f
    @Volatile var jaw = 0f
    @Volatile var chin = 0f
    @Volatile var earL = 0f; @Volatile var earR = 0f
    @Volatile var templeL = 0f; @Volatile var templeR = 0f
    @Volatile var faceSkin = 0f

    // Eye complete (on top of prior eye board)
    @Volatile var eyeOn = true
    @Volatile var eyeThr = 0.22f
    @Volatile var eyeLv = 0.85f
    @Volatile var eyeL = 0f; @Volatile var eyeR = 0f
    @Volatile var eyeFull = 0f

    // Noise fully
    @Volatile var noiseOn = true
    @Volatile var noiseThr = 0.28f
    @Volatile var noiseLv = 0.80f
    @Volatile var noiseAutoThr = true
    @Volatile var noiseOut = 0f
    @Volatile var noiseSpike = 0f
    @Volatile var noiseFloor = 0f
    @Volatile var noiseActive = false
    private var noiseEma = 0f

    @Volatile var status = "FACE·EYE·NOISE idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float) {
        if (!enabled) {
            status = "FACE·EYE·NOISE OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)

        // Noise floor + spike
        noiseEma = noiseEma * 0.92f + e * 0.08f
        noiseFloor = noiseEma
        if (noiseAutoThr) {
            noiseThr = (noiseFloor + 0.12f).coerceIn(0.08f, 0.6f)
        }
        noiseOut = lane(noiseOn, noiseThr, noiseLv, e)
        noiseSpike = if (e > noiseFloor + 0.15f) ((e - noiseFloor) / 0.5f).coerceIn(0f, 1f) else 0f
        noiseActive = noiseOut > 0.05f || noiseSpike > 0.1f

        faceOut = lane(faceOn, faceThr, faceLv, e)
        forehead = faceOut * 0.95f
        browL = faceOut * 0.90f; browR = faceOut * 0.90f
        cheekL = faceOut * 0.88f; cheekR = faceOut * 0.88f
        nose = faceOut * 0.92f
        nostrilL = faceOut * 0.85f; nostrilR = faceOut * 0.85f
        lips = faceOut * 0.87f
        mouth = faceOut * 0.86f
        jaw = faceOut * 0.84f
        chin = faceOut * 0.82f
        earL = faceOut * 0.80f; earR = faceOut * 0.80f
        templeL = faceOut * 0.83f; templeR = faceOut * 0.83f
        faceSkin = faceOut * 0.94f

        eyeL = lane(eyeOn, eyeThr, eyeLv, e)
        eyeR = lane(eyeOn, eyeThr, eyeLv, e * 0.98f)
        eyeFull = maxOf(eyeL, eyeR)

        status =
            "FACE=${(faceOut*100).toInt()}% EYE L/R=${(eyeL*100).toInt()}/${(eyeR*100).toInt()} · " +
            "NOISE ${if (noiseActive) "HIT" else "-"} out=${(noiseOut*100).toInt()}% " +
            "spike=${(noiseSpike*100).toInt()}% floor=${"%.2f".format(noiseFloor)}" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView, sb: SoundBankGuard) {
        if (!enabled) return
        try {
            v.face.atmosphere = maxOf(v.face.atmosphere, faceOut, faceSkin)
            v.forehead.atmosphere = maxOf(v.forehead.atmosphere, forehead)
            v.eyeL.atmosphere = maxOf(v.eyeL.atmosphere, eyeL)
            v.eyeR.atmosphere = maxOf(v.eyeR.atmosphere, eyeR)
            v.eyes.atmosphere = maxOf(v.eyes.atmosphere, eyeFull)
            v.cenDrive.eyesOn = true
        } catch (_: Throwable) {}
        try {
            v.eyesHeartBelly.eyeLOut = maxOf(v.eyesHeartBelly.eyeLOut, eyeL)
            v.eyesHeartBelly.eyeROut = maxOf(v.eyesHeartBelly.eyeROut, eyeR)
            v.eyesHeartBelly.eyesFullOut = maxOf(v.eyesHeartBelly.eyesFullOut, eyeFull)
        } catch (_: Throwable) {}
        try {
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, faceOut, eyeFull)
            // Face layer index 6 if present
            if (v.anatomy3d.layerOn.size > 6) {
                v.anatomy3d.layerOn[6] = true
                v.anatomy3d.layerLevel[6] = maxOf(v.anatomy3d.layerLevel[6], 0.85f + faceOut * 0.15f)
            }
        } catch (_: Throwable) {}
        // Noise → sound bank / protect awareness
        if (noiseActive) {
            try {
                sb.audioFocusOut = maxOf(sb.audioFocusOut, noiseOut * 0.6f)
                if (noiseSpike > 0.2f) {
                    // spike counts toward ambient awareness only
                    v.hairBullet.hairOut = maxOf(v.hairBullet.hairOut, noiseSpike * 0.4f)
                }
            } catch (_: Throwable) {}
        }
    }
}
