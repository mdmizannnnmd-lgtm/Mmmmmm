package com.mizan

/**
 * Body-region AtomSpare · bullet effects (audio warfare research-backed):
 * muzzle blast ~3–5 ms N-pattern · shockwave · broadband peaks 100–12 kHz ·
 * underground-style low peak + noise floor. Matches knife/burst/bullet bank.
 * Symbolic SFX / threshold only. RAW COMPLETE.
 */
class BodyRegionBulletAtomspareBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.18f
    @Volatile var levelAmt = 0.95f

    // Acoustic profile (from gunshot literature)
    @Volatile var muzzleBlastOut = 0f      // ~3–5 ms impulse
    @Volatile var shockwaveOut = 0f        // sub-ms for supersonic symbolic
    @Volatile var peakLowOut = 0f          // 100–800 Hz underground-style
    @Volatile var peakMidOut = 0f          // 500–2000 Hz
    @Volatile var peakHighOut = 0f         // 2–12 kHz noise/bullet hiss
    @Volatile var noiseFloorOut = 0f
    @Volatile var bulletRegionOut = 0f

    // Per body-region damp (head/chest/limb…)
    @Volatile var regionHead = 0f
    @Volatile var regionChest = 0f
    @Volatile var regionLimb = 0f
    @Volatile var regionFull = 0f

    // Align with existing bank
    @Volatile var matchKnife = 0f
    @Volatile var matchBurst = 0f
    @Volatile var matchBullet = 0f

    @Volatile var status = "REGION-BULLET idle"

    private fun lane(e: Float, t: Float = thr): Float {
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * levelAmt).coerceIn(0f, 1f)
        return if (x >= t) ((x - t) / (1.2f - t).coerceAtLeast(0.05f) * levelAmt).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, bullet: Float, burst: Float, knife: Float, sharp: Float) {
        if (!enabled) { status = "REGION-BULLET OFF"; return }
        val e = maxOf(mic, bullet, burst * 0.9f).coerceIn(0f, 1.5f)
        muzzleBlastOut = lane(e * 1.05f)
        shockwaveOut = lane(e * 0.75f + sharp * 0.4f)
        peakLowOut = lane(e * 0.7f + burst * 0.5f)   // underground peak
        peakMidOut = lane(e * 0.9f + bullet * 0.6f)
        peakHighOut = lane(e * 0.85f + sharp * 0.5f)
        noiseFloorOut = lane(e * 0.55f)
        bulletRegionOut = maxOf(muzzleBlastOut, shockwaveOut, peakMidOut, peakHighOut)
        regionHead = lane(bulletRegionOut * 1.0f)
        regionChest = lane(bulletRegionOut * 0.95f)
        regionLimb = lane(bulletRegionOut * 0.85f)
        regionFull = maxOf(regionHead, regionChest, regionLimb)
        matchBullet = lane(maxOf(bullet, bulletRegionOut))
        matchBurst = lane(maxOf(burst, peakLowOut))
        matchKnife = lane(maxOf(knife, peakHighOut * 0.8f))
        if (rawComplete) bulletRegionOut = maxOf(bulletRegionOut, 0.25f + e * 0.4f)
        status =
            "BULLET-ATM muzzle=${(muzzleBlastOut*100).toInt()}% shock=${(shockwaveOut*100).toInt()}% · " +
            "L/M/H peaks=${(peakLowOut*100).toInt()}/${(peakMidOut*100).toInt()}/${(peakHighOut*100).toInt()}% · " +
            "region=${(regionFull*100).toInt()}% match B/Br/K=${(matchBullet*100).toInt()}/${(matchBurst*100).toInt()}/${(matchKnife*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!enabled || regionFull < 0.02f) return
        val bank = sb ?: return
        try {
            // Protect: damp enemy bullet/burst into body regions
            bank.bulletOut *= (1f - matchBullet * 0.92f).coerceIn(0.04f, 1f)
            bank.burstOut *= (1f - matchBurst * 0.92f).coerceIn(0.04f, 1f)
            bank.knifeOut *= (1f - matchKnife * 0.88f).coerceIn(0.05f, 1f)
        } catch (_: Throwable) {}
        val vv = v ?: return
        try {
            vv.pointerBulletLinear.bulletProtectOut = maxOf(vv.pointerBulletLinear.bulletProtectOut, matchBullet)
            vv.pointerBulletLinear.burstProtectOut = maxOf(vv.pointerBulletLinear.burstProtectOut, matchBurst)
            vv.bodyRegionEnemyProtect.burstProt = maxOf(vv.bodyRegionEnemyProtect.burstProt, matchBurst)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, regionFull * 0.5f)
        } catch (_: Throwable) {}
    }
}
