package com.mizan

/**
 * Complete Final Tabs settings surface (prior aratombox Final Protection).
 * Additive — runs beside existing ambient/anatomy boards; does not replace them.
 * All major Final sections: master · live · anatomy · brain/eyes · body84 ·
 * sides · glands/CNS · screen · ultrasonic · DSP echo · AS weapons · model mix · RAW.
 */
class FinalTabsCompleteBoard {

    // ── Master ──────────────────────────────────────────────
    @Volatile var systemEnabled = true
    @Volatile var rawComplete = true
    @Volatile var spikeProtectOn = true
    @Volatile var spikeProtectLv = 1.0f
    @Volatile var masterThr = 0.30f
    @Volatile var masterLv = 0.55f

    // ── Ambient live board ──────────────────────────────────
    @Volatile var ambLiveOn = true
    @Volatile var micProtOn = true
    @Volatile var micProtThr = 0.18f
    @Volatile var micProtLv = 0.9f
    @Volatile var micProtOut = 0f

    @Volatile var ambLiveThr = 0.30f
    @Volatile var ambSpikeThr = 0.30f
    @Volatile var ambMoveThr = 0.30f
    @Volatile var ambPitchThr = 0.30f
    @Volatile var ambSpeedThr = 0.30f
    @Volatile var silenceThrDb = -45f
    @Volatile var silenceThrHz = 40f
    @Volatile var userspaceProtect = true
    @Volatile var ambLiveOut = 0f
    @Volatile var ambSpikeOut = 0f
    @Volatile var ambMoveOut = 0f
    @Volatile var ambPitchOut = 0f
    @Volatile var ambSpeedOut = 0f

    // ── All anatomy ambient ─────────────────────────────────
    @Volatile var allAnatomyOn = true
    @Volatile var cortexOn = true
    @Volatile var cortexThr = 0.30f
    @Volatile var cortexLv = 0.55f
    @Volatile var frontalOn = true
    @Volatile var parietalOn = true
    @Volatile var temporalOn = true
    @Volatile var occipitalOn = true
    @Volatile var insularOn = true
    @Volatile var cerebellarOn = true
    @Volatile var lobesThr = 0.30f
    @Volatile var lobesLv = 0.55f
    @Volatile var heartOn = true
    @Volatile var heartThr = 0.30f
    @Volatile var heartLv = 0.55f
    @Volatile var neckOn = true
    @Volatile var neckThr = 0.30f
    @Volatile var neckLv = 0.55f
    @Volatile var cortexOut = 0f
    @Volatile var lobesOut = 0f
    @Volatile var heartOut = 0f
    @Volatile var neckOut = 0f

    // ── Brain L/R · eyes L/R ────────────────────────────────
    @Volatile var leftBrainOn = true
    @Volatile var rightBrainOn = true
    @Volatile var leftBrainThr = 0.30f
    @Volatile var leftBrainLv = 0.55f
    @Volatile var rightBrainThr = 0.30f
    @Volatile var rightBrainLv = 0.55f
    @Volatile var leftEyeOn = true
    @Volatile var rightEyeOn = true
    @Volatile var leftEyeThr = 0.30f
    @Volatile var leftEyeLv = 0.55f
    @Volatile var rightEyeThr = 0.30f
    @Volatile var rightEyeLv = 0.55f
    @Volatile var leftBrainOut = 0f
    @Volatile var rightBrainOut = 0f
    @Volatile var leftEyeOut = 0f
    @Volatile var rightEyeOut = 0f

    // ── Body sides ──────────────────────────────────────────
    @Volatile var leftBodyOn = true
    @Volatile var rightBodyOn = true
    @Volatile var frontBodyOn = true
    @Volatile var backBodyOn = true
    @Volatile var bodySideThr = 0.30f
    @Volatile var bodySideLv = 0.55f
    @Volatile var leftBodyOut = 0f
    @Volatile var rightBodyOut = 0f
    @Volatile var frontBodyOut = 0f
    @Volatile var backBodyOut = 0f

    // ── Glands / CNS ────────────────────────────────────────
    @Volatile var glandsOn = true
    @Volatile var cnsOn = true
    @Volatile var hypothalamusOn = true
    @Volatile var thyroidOn = true
    @Volatile var thymusOn = true
    @Volatile var glandsThr = 0.30f
    @Volatile var glandsLv = 0.55f
    @Volatile var cnsThr = 0.30f
    @Volatile var cnsLv = 0.55f
    @Volatile var glandsOut = 0f
    @Volatile var cnsOut = 0f

    // ── Face / neck / skin ──────────────────────────────────
    @Volatile var faceOn = true
    @Volatile var skinOn = true
    @Volatile var faceThr = 0.30f
    @Volatile var faceLv = 0.55f
    @Volatile var faceOut = 0f
    @Volatile var skinOut = 0f

    // ── Body84 ──────────────────────────────────────────────
    @Volatile var body84On = true
    @Volatile var body84Thr = 0.30f
    @Volatile var body84Lv = 0.55f
    @Volatile var body84Out = 0f
    @Volatile var body84Active = 0

    // ── Pose / Seg / OBB ambient ────────────────────────────
    @Volatile var poseAmbOn = true
    @Volatile var segAmbOn = true
    @Volatile var obbAmbOn = true
    @Volatile var modelAmbThr = 0.30f
    @Volatile var modelAmbLv = 0.55f
    @Volatile var poseOut = 0f
    @Volatile var segOut = 0f
    @Volatile var obbOut = 0f

    // ── Screen ambient ──────────────────────────────────────
    @Volatile var screenAmbOn = true
    @Volatile var screenThr = 0.30f
    @Volatile var screenLv = 0.55f
    @Volatile var screenOut = 0f

    // ── Ultrasonic / DSP / ear ──────────────────────────────
    @Volatile var ultrasonicOn = false
    @Volatile var ultrasonicThr = 0.40f
    @Volatile var ultrasonicLv = 0.50f
    @Volatile var ultrasoundEchoOn = false
    @Volatile var dspToneEchoOn = false
    @Volatile var earDspOn = false
    @Volatile var earDspLv = 0.50f

    // ── AtomSpare weapons / AS ──────────────────────────────
    @Volatile var asWeaponsOn = true
    @Volatile var asThr = 0.35f
    @Volatile var asLv = 0.70f
    @Volatile var asOut = 0f

    // ── Bipolar ─────────────────────────────────────────────
    @Volatile var bipNegDb = 0f
    @Volatile var bipPosDb = 0f

    @Volatile var lastStatus = "FINAL tabs idle"
        private set

    private fun bip01(): Float {
        val n = (bipNegDb.coerceIn(-120f, 0f) / 120f) * 0.5f
        val p = (bipPosDb.coerceIn(0f, 120f) / 120f) * 0.5f
        return (0.5f + p - n).coerceIn(0.05f, 1f)
    }

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float, drive: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv * drive).coerceIn(0f, 1f)
        val t = (thr * drive * bip01()).coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv * drive).coerceIn(0f, 1f) else 0f
    }

    fun tick(micEnergy: Float, modelDrive: Float = 1f, domHz: Float = 0f) {
        if (!systemEnabled) {
            lastStatus = "FINAL system OFF"
            return
        }
        val e = micEnergy.coerceIn(0f, 1f)
        val drive = (0.25f + 0.75f * modelDrive.coerceIn(0f, 1f))
        val master = lane(true, masterThr, masterLv, e, drive)

        ambLiveOut = if (ambLiveOn) lane(true, ambLiveThr, 1f, e, drive) else 0f
        micProtOut = if (micProtOn) lane(true, micProtThr, micProtLv, e, drive) else 0f

        ambSpikeOut = lane(ambLiveOn, ambSpikeThr, 1f, e * 1.1f, drive)
        ambMoveOut = lane(ambLiveOn, ambMoveThr, 1f, e * 0.95f, drive)
        ambPitchOut = lane(ambLiveOn, ambPitchThr, 1f, e * (if (domHz > 100f) 1.05f else 0.9f), drive)
        ambSpeedOut = lane(ambLiveOn, ambSpeedThr, 1f, e * 0.98f, drive)

        cortexOut = if (allAnatomyOn && cortexOn) lane(true, cortexThr, cortexLv, e, drive) * (0.5f + 0.5f * master) else 0f
        val lobeE = e * if (frontalOn || parietalOn || temporalOn || occipitalOn || insularOn || cerebellarOn) 1f else 0f
        lobesOut = if (allAnatomyOn) lane(true, lobesThr, lobesLv, lobeE, drive) * (0.5f + 0.5f * master) else 0f
        heartOut = if (allAnatomyOn && heartOn) lane(true, heartThr, heartLv, e, drive) else 0f
        neckOut = if (allAnatomyOn && neckOn) lane(true, neckThr, neckLv, e, drive) else 0f

        leftBrainOut = lane(leftBrainOn, leftBrainThr, leftBrainLv, e * 1.02f, drive)
        rightBrainOut = lane(rightBrainOn, rightBrainThr, rightBrainLv, e, drive)
        leftEyeOut = lane(leftEyeOn, leftEyeThr, leftEyeLv, e * 1.03f, drive)
        rightEyeOut = lane(rightEyeOn, rightEyeThr, rightEyeLv, e * 1.01f, drive)

        leftBodyOut = lane(leftBodyOn, bodySideThr, bodySideLv, e * 1.02f, drive)
        rightBodyOut = lane(rightBodyOn, bodySideThr, bodySideLv, e, drive)
        frontBodyOut = lane(frontBodyOn, bodySideThr, bodySideLv, e * 1.01f, drive)
        backBodyOut = lane(backBodyOn, bodySideThr, bodySideLv, e * 0.98f, drive)

        glandsOut = if (glandsOn) lane(true, glandsThr, glandsLv, e, drive) else 0f
        cnsOut = if (cnsOn) lane(true, cnsThr, cnsLv, e * 1.05f, drive) else 0f
        faceOut = if (faceOn) lane(true, faceThr, faceLv, e, drive) else 0f
        skinOut = if (skinOn) lane(true, faceThr, faceLv, e * 0.97f, drive) else 0f

        body84Out = if (body84On) lane(true, body84Thr, body84Lv, e, drive) * (0.4f + 0.6f * master) else 0f
        body84Active = if (body84Out > 0.02f) ((body84Out * 84).toInt()).coerceIn(0, 84) else 0

        poseOut = if (poseAmbOn) lane(true, modelAmbThr, modelAmbLv, e * modelDrive, drive) else 0f
        segOut = if (segAmbOn) lane(true, modelAmbThr, modelAmbLv, e * modelDrive * 0.98f, drive) else 0f
        obbOut = if (obbAmbOn) lane(true, modelAmbThr, modelAmbLv, e * modelDrive * 0.96f, drive) else 0f

        screenOut = if (screenAmbOn) lane(true, screenThr, screenLv, e, drive) else 0f
        asOut = if (asWeaponsOn) lane(true, asThr, asLv, e * 1.08f, drive) else 0f

        lastStatus =
            "FINAL ${if (rawComplete) "RAW" else "live"} master=${(master*100).toInt()}% · " +
            "live=${(ambLiveOut*100).toInt()} spike=${(ambSpikeOut*100).toInt()} · " +
            "cortex=${(cortexOut*100).toInt()} heart=${(heartOut*100).toInt()} · " +
            "brain L/R=${(leftBrainOut*100).toInt()}/${(rightBrainOut*100).toInt()} · " +
            "eye L/R=${(leftEyeOut*100).toInt()}/${(rightEyeOut*100).toInt()} · " +
            "84=$body84Active AS=${(asOut*100).toInt()}%"
    }
    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!systemEnabled) return
        val vv = v ?: return
        try {
            vv.cnsEyesHeart.eyeLOut = maxOf(vv.cnsEyesHeart.eyeLOut, leftEyeOut)
            vv.cnsEyesHeart.eyeROut = maxOf(vv.cnsEyesHeart.eyeROut, rightEyeOut)
            try {
                body84Active = vv.body84.activeCount
                body84Out = maxOf(body84Out, vv.body84.avgOut)
            } catch (_: Throwable) {}
            vv.body84FullHuman.atomOut = maxOf(vv.body84FullHuman.atomOut, body84Out)
            vv.body84FullHuman.modelMixOut = maxOf(vv.body84FullHuman.modelMixOut, maxOf(poseOut, segOut, obbOut))
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, maxOf(ambLiveOut, asOut, body84Out, micProtOut) * 0.5f)
            try { vv.micLiveAmbientMixer.micLiveOut = maxOf(vv.micLiveAmbientMixer.micLiveOut, micProtOut) } catch (_: Throwable) {}
            try { vv.finalProtectionMain.micLiveOut = maxOf(vv.finalProtectionMain.micLiveOut, micProtOut) } catch (_: Throwable) {}

            vv.fullAnatomy132.brainOut = maxOf(vv.fullAnatomy132.brainOut, maxOf(leftBrainOut, rightBrainOut, cortexOut))
            try { vv.finalProtectionMain.ambLiveOut = maxOf(vv.finalProtectionMain.ambLiveOut, ambLiveOut) } catch (_: Throwable) {}
            try { vv.finalProtectionMain.body84Out = maxOf(vv.finalProtectionMain.body84Out, body84Out) } catch (_: Throwable) {}
            try { vv.finalProtectionMain.screenAmbOut = maxOf(vv.finalProtectionMain.screenAmbOut, screenOut) } catch (_: Throwable) {}
            try { vv.eyeBodyAtomSurface.eyeLOut = maxOf(vv.eyeBodyAtomSurface.eyeLOut, leftEyeOut) } catch (_: Throwable) {}
            try { vv.eyeBodyAtomSurface.eyeROut = maxOf(vv.eyeBodyAtomSurface.eyeROut, rightEyeOut) } catch (_: Throwable) {}
        } catch (_: Throwable) {}
        try {
            if (sb != null && asOut > 0.05f) {
                val d = (1f - asOut * 0.5f).coerceIn(0.1f, 1f)
                sb.enemyBodyOut *= d
            }
        } catch (_: Throwable) {}
    }

}
