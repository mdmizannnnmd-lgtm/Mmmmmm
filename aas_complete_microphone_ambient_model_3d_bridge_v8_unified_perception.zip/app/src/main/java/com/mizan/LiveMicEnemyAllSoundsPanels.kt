package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object LiveMicEnemyAllSoundsPanels {
    fun build(ctx: Context, root: LinearLayout, b: LiveMicEnemyAllSoundsBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF90CAF9.toInt()
        p.title("LIVE MIC ALL · ENEMY ALL SOUNDS · ANTI OWN · PITCH · BODY ALL PARTS", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("LIVE MICROPHONE ALL SOUNDS", c)
        p.switch("Live mic all ON", b.liveMicAllOn) { b.liveMicAllOn = it }
        p.switch("Live mic auto thr", b.liveMicAllAutoThr) { b.liveMicAllAutoThr = it }
        p.seek("Live mic all thr", 0.05f, 0.98f, b.liveMicAllThr) { b.liveMicAllThr = it }
        p.seek("Live mic all level", 0f, 1.5f, b.liveMicAllLv) { b.liveMicAllLv = it }

        p.title("ENEMIES ALL SOUNDS (knife·bullet·burst·sharp·more)", c)
        p.switch("Enemy all sounds ON", b.enemyAllOn) { b.enemyAllOn = it }
        p.seek("Enemy all thr", 0.05f, 0.98f, b.enemyAllThr) { b.enemyAllThr = it }
        p.seek("Enemy all level", 0f, 1.5f, b.enemyAllLv) { b.enemyAllLv = it }

        p.title("ANTI SOUND OUR OWN", c)
        p.switch("Anti own ON", b.antiOwnOn) { b.antiOwnOn = it }
        p.seek("Anti own thr", 0.05f, 0.98f, b.antiOwnThr) { b.antiOwnThr = it }
        p.seek("Anti own level", 0f, 1.5f, b.antiOwnLv) { b.antiOwnLv = it }

        p.title("PITCH SOUNDS", c)
        p.switch("Pitch sounds ON", b.pitchSoundsOn) { b.pitchSoundsOn = it }
        p.seek("Pitch thr / lv", 0.05f, 0.98f, b.pitchSoundsThr) { b.pitchSoundsThr = it }
        p.seek("Pitch level", 0f, 1.5f, b.pitchSoundsLv) { b.pitchSoundsLv = it }

        p.title("BODY REGION ALL PARTS PROTECTION", c)
        p.switch("Body all parts ON", b.bodyAllPartsOn) { b.bodyAllPartsOn = it }
        p.seek("Body all parts thr", 0.05f, 0.98f, b.bodyAllPartsThr) { b.bodyAllPartsThr = it }
        p.seek("Body all parts level", 0f, 1.5f, b.bodyAllPartsLv) { b.bodyAllPartsLv = it }

        val st = p.status("LIVE·ENEMY —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 220) }
        })
    }
}
