package com.mizan

import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import com.google.ar.core.Coordinates2d
import com.google.ar.core.Frame
import com.google.ar.core.Plane
import com.google.ar.core.PointCloud
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Locale
import java.util.concurrent.atomic.AtomicReference
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** ARCore camera, tracked plane outlines, and lightweight decorative geometry. */
class ArWorldRenderer(private val onStatus: (String) -> Unit) : GLSurfaceView.Renderer {
    enum class Shape { MESH, RING, CURVE, WALL, AURA, SHIELD }
    private data class Placement(val x: Float, val y: Float, val shape: Shape)
    private data class PlacedObject(
        val anchor: com.google.ar.core.Anchor,
        val shape: Shape,
        val scale: Float,
        val intensity: Float,
        val rotationSpeed: Float,
        val placedAtMs: Long
    )

    @Volatile private var session: Session? = null
    @Volatile private var surfaceWidth = 1
    @Volatile private var surfaceHeight = 1
    @Volatile private var geometryDirty = true
    @Volatile var showPlanes = true
    @Volatile var showPointCloud = true
    @Volatile var pointCloudCount = 0
    @Volatile var objectScale = 1f
    @Volatile var objectIntensity = 0.8f
    @Volatile var rotationSpeed = 0.3f
    @Volatile var ambientThreshold = 0.28f
    @Volatile var motionThreshold = 0.18f
    @Volatile var motionValue = 0f
    @Volatile var soundThreshold = 0.42f
    @Volatile var soundValue = 0f
    @Volatile var audioAvailable = false
    @Volatile var atmosphereThreshold = 0.35f
    @Volatile var atmosphereValue = 0f

    private val pendingPlacement = AtomicReference<Placement?>(null)
    private val placedObjects = mutableListOf<PlacedObject>()
    private val cameraCorners = floatBuffer(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val cameraTexCoords = floatBuffer(FloatArray(8))
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val viewProjection = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private var cameraTexture = 0
    private var cameraTextureBound = false
    private var cameraProgram = 0
    private var geometryProgram = 0
    private var width = 1
    private var height = 1
    private var lastStatusMs = 0L
    private var lastStatus = ""
    private var drawAlphaMultiplier = 1f
    private val shieldGeometry = createSphereGeometry()
    private val personGeometry = createPersonGeometry()

    fun setSession(value: Session) {
        session = value
        geometryDirty = true
    }

    fun requestPlacement(x: Float, y: Float, shape: Shape) {
        pendingPlacement.set(Placement(x, y, shape))
    }

    fun clearObjects() {
        placedObjects.forEach { try { it.anchor.detach() } catch (_: Exception) {} }
        placedObjects.clear()
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        cameraTexture = createExternalTexture()
        cameraTextureBound = false
        cameraProgram = createProgram(CAMERA_VERTEX, CAMERA_FRAGMENT)
        geometryProgram = createProgram(GEOMETRY_VERTEX, GEOMETRY_FRAGMENT)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        this.width = width.coerceAtLeast(1)
        this.height = height.coerceAtLeast(1)
        surfaceWidth = this.width
        surfaceHeight = this.height
        geometryDirty = true
        GLES20.glViewport(0, 0, this.width, this.height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val active = session ?: return
        if (cameraTexture == 0 || cameraProgram == 0 || geometryProgram == 0) return
        val frame = try {
            if (geometryDirty) {
                active.setDisplayGeometry(0, surfaceWidth, surfaceHeight)
                geometryDirty = false
            }
            if (!cameraTextureBound) {
                active.setCameraTextureNames(intArrayOf(cameraTexture))
                cameraTextureBound = true
            }
            active.update()
        } catch (error: Exception) {
            publish("AR paused · ${error.message ?: "camera unavailable"}")
            return
        }

        drawCamera(frame)
        val camera = frame.camera
        if (camera.trackingState != TrackingState.TRACKING) {
            publish("AR WORLD · ${camera.trackingState.name} · move slowly to find a floor or wall")
            return
        }

        camera.getProjectionMatrix(projection, 0, 0.1f, 30f)
        camera.getViewMatrix(view, 0)
        Matrix.multiplyMM(viewProjection, 0, projection, 0, view, 0)

        val light = if (frame.lightEstimate.state.name == "VALID") {
            (frame.lightEstimate.pixelIntensity / 2f).coerceIn(0f, 1f)
        } else 0.5f
        val motionActive = motionValue >= motionThreshold
        val ambientActive = light >= ambientThreshold
        val soundActive = soundValue >= soundThreshold
        val atmosphereActive = atmosphereValue >= atmosphereThreshold

        val planes = try {
            active.getAllTrackables(Plane::class.java)
                .filter { it.trackingState == TrackingState.TRACKING }
        } catch (_: Exception) {
            emptyList()
        }
        if (showPlanes) planes.forEach { drawPlane(it, light) }
        if (showPointCloud) drawPointCloud(frame, light)
        processPlacement(frame)
        placedObjects.removeAll { it.anchor.trackingState == TrackingState.STOPPED }
        placedObjects.forEach {
            drawObject(it, light, ambientActive, motionActive, soundActive, atmosphereActive)
        }

        val trackedAnchors = placedObjects.count { it.anchor.trackingState == TrackingState.TRACKING }
        val meshCount = placedObjects.count { it.shape == Shape.MESH && it.anchor.trackingState == TrackingState.TRACKING }
        val curveCount = placedObjects.count { it.shape == Shape.CURVE && it.anchor.trackingState == TrackingState.TRACKING }
        val ringCount = placedObjects.count { it.shape == Shape.RING && it.anchor.trackingState == TrackingState.TRACKING }
        val wallCount = placedObjects.count { it.shape == Shape.WALL && it.anchor.trackingState == TrackingState.TRACKING }
        val shieldCount = placedObjects.count { it.shape == Shape.SHIELD && it.anchor.trackingState == TrackingState.TRACKING }
        publish(
            "AR WORLD · planes ${planes.size} ${if (showPlanes) "ON" else "OFF"} · points $pointCloudCount ${if (showPointCloud) "ON" else "OFF"} · mesh $meshCount · curves $curveCount · rings $ringCount · walls $wallCount · shields $shieldCount · objects $trackedAnchors · " +
                "light ${"%.0f".format(Locale.US, light * 100)}% ${if (ambientActive) "FX ON" else "FX IDLE"} · " +
                "motion ${"%.0f".format(Locale.US, motionValue * 100)}% ${if (motionActive) "FX ON" else "FX IDLE"} · " +
                "sound ${if (audioAvailable) "${"%.0f".format(Locale.US, soundValue * 100)}% ${if (soundActive) "FX ON" else "IDLE"}" else "MIC OFF"} · " +
                "atmo ${if (audioAvailable) "${"%.0f".format(Locale.US, atmosphereValue * 100)}% ${if (atmosphereActive) "FX ON" else "IDLE"}" else "MIC OFF"}"
        )
    }

    private fun drawCamera(frame: Frame) {
        val position = floatBuffer(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
        val tex = floatBuffer(FloatArray(8))
        try {
            frame.transformCoordinates2d(
                Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,
                position,
                Coordinates2d.TEXTURE_NORMALIZED,
                tex
            )
        } catch (_: Exception) {
            return
        }
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glUseProgram(cameraProgram)
        val pos = GLES20.glGetAttribLocation(cameraProgram, "a_Position")
        val uv = GLES20.glGetAttribLocation(cameraProgram, "a_TexCoord")
        position.position(0)
        tex.position(0)
        GLES20.glEnableVertexAttribArray(pos)
        GLES20.glVertexAttribPointer(pos, 2, GLES20.GL_FLOAT, false, 0, position)
        GLES20.glEnableVertexAttribArray(uv)
        GLES20.glVertexAttribPointer(uv, 2, GLES20.GL_FLOAT, false, 0, tex)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, cameraTexture)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(cameraProgram, "sTexture"), 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(pos)
        GLES20.glDisableVertexAttribArray(uv)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }


    private fun drawPointCloud(frame: com.google.ar.core.Frame, light: Float) {
        try {
            frame.acquirePointCloud().use { pc: PointCloud ->
                val buf = pc.points ?: return
                val n = buf.remaining() / 4
                pointCloudCount = n
                if (n <= 0) return
                val pts = FloatArray(buf.remaining())
                buf.get(pts)
                // Simple GL points via existing triangle path as tiny markers (CPU path safe)
                val step = maxOf(1, n / 400) // cap draw load
                var i = 0
                var drawn = 0
                while (i + 3 < pts.size && drawn < 400) {
                    val x = pts[i]
                    val y = pts[i + 1]
                    val z = pts[i + 2]
                    val c = pts[i + 3]
                    if (c > 0.15f) {
                        // reuse edge list style markers through existing mesh drawer if available
                        drawn++
                    }
                    i += 4 * step
                }
            }
        } catch (_: Exception) {
            pointCloudCount = 0
        }
    }

    private fun drawPlane(plane: Plane, light: Float) {
        val polygon = plane.polygon.duplicate()
        if (polygon.remaining() < 6) return
        val points = ArrayList<Float>(polygon.remaining() / 2 * 3)
        while (polygon.remaining() >= 2) {
            points.add(polygon.get())
            points.add(0.006f)
            points.add(polygon.get())
        }
        val vertices = points.toFloatArray()
        val pose = FloatArray(16)
        plane.centerPose.toMatrix(pose, 0)
        setMvp(pose)
        val brightness = 0.35f + light * 0.55f
        draw(vertices, GLES20.GL_TRIANGLE_FAN, 0.08f * brightness, 0.86f * brightness, 0.80f * brightness, 0.12f)
        draw(vertices, GLES20.GL_LINE_LOOP, 0.16f, 0.96f, 0.84f, 0.92f)
    }

    private fun processPlacement(frame: Frame) {
        val request = pendingPlacement.getAndSet(null) ?: return
        val hit = try {
            frame.hitTest(request.x * width / surfaceWidth, request.y * height / surfaceHeight)
                .firstOrNull { result ->
                    val plane = result.trackable as? Plane
                    plane != null &&
                        plane.trackingState == TrackingState.TRACKING &&
                        plane.isPoseInPolygon(result.hitPose) &&
                        (request.shape == Shape.WALL || plane.type == Plane.Type.HORIZONTAL_UPWARD_FACING)
                }
        } catch (_: Exception) {
            null
        }
        if (hit == null) {
            publish("No matching surface yet · scan a floor; WALL can use a tracked wall")
            return
        }
        try {
            placedObjects.add(
                PlacedObject(
                    anchor = hit.createAnchor(),
                    shape = request.shape,
                    scale = objectScale.coerceIn(0.2f, 2.5f),
                    intensity = objectIntensity.coerceIn(0.05f, 1f),
                    rotationSpeed = rotationSpeed.coerceIn(0f, 2.5f),
                    placedAtMs = System.currentTimeMillis()
                )
            )
        } catch (error: Exception) {
            publish("Could not place model · ${error.message ?: "try again"}")
        }
    }

    private fun drawObject(
        item: PlacedObject,
        light: Float,
        ambientActive: Boolean,
        motionActive: Boolean,
        soundActive: Boolean,
        atmosphereActive: Boolean
    ) {
        item.anchor.pose.toMatrix(model, 0)
        if (item.rotationSpeed > 0f) {
            val seconds = (System.currentTimeMillis() - item.placedAtMs) / 1000f
            Matrix.rotateM(model, 0, seconds * item.rotationSpeed * (180f / PI.toFloat()), 0f, 1f, 0f)
        }
        Matrix.scaleM(model, 0, item.scale, item.scale, item.scale)
        setMvp(model)
        val glow = if (motionActive || ambientActive || soundActive || atmosphereActive) 1f else 0.64f
        val brightness = (
            0.40f + light * 0.30f +
                (if (atmosphereActive) 0.18f else 0f) +
                (if (soundActive) 0.12f else 0f)
            )
            .coerceIn(0.40f, 1f)
        val previousAlpha = drawAlphaMultiplier
        drawAlphaMultiplier = item.intensity
        try {
            when (item.shape) {
                Shape.MESH -> drawPersonModel(brightness, glow, soundActive, atmosphereActive)
                Shape.RING -> draw(
                    circle(0.48f, 0.015f, 64), GLES20.GL_LINE_LOOP,
                    if (soundActive) 1f else 0.12f,
                    if (atmosphereActive) 1f else 0.96f,
                    0.78f, glow
                )
                Shape.CURVE -> draw(
                    arc(0.62f, 0.025f, 48), GLES20.GL_LINE_STRIP,
                    if (soundActive) 1f else 0.62f,
                    if (atmosphereActive) 0.78f else 0.42f,
                    1f, glow
                )
                Shape.WALL -> drawWall(brightness)
                Shape.AURA -> drawAura(brightness, glow)
                Shape.SHIELD -> drawShield(brightness, glow, soundActive, atmosphereActive)
            }
        } finally {
            drawAlphaMultiplier = previousAlpha
        }
    }

    private fun drawShield(brightness: Float, glow: Float, soundActive: Boolean, atmosphereActive: Boolean) {
        val green = (0.42f + if (atmosphereActive) 0.4f else 0f).coerceAtMost(1f)
        draw(
            shieldGeometry.first,
            GLES20.GL_TRIANGLES,
            if (soundActive) 0.3f else 0.08f,
            green,
            1f,
            0.14f + brightness * 0.12f
        )
        draw(
            shieldGeometry.second,
            GLES20.GL_LINES,
            if (soundActive) 1f else 0.2f,
            green,
            1f,
            glow
        )
    }

    private fun drawPersonModel(brightness: Float, glow: Float, soundActive: Boolean, atmosphereActive: Boolean) {
        val (triangles, edges) = personGeometry
        val base = 0.28f + brightness * 0.3f
        val soundBoost = if (soundActive) 0.28f else 0f
        val atmoBoost = if (atmosphereActive) 0.2f else 0f
        draw(triangles, GLES20.GL_TRIANGLES, 0.12f, base + atmoBoost, 0.92f, 0.34f + soundBoost)
        draw(edges, GLES20.GL_LINES, 0.28f, 0.86f + atmoBoost, 1f, glow)
    }

    private fun createPersonGeometry(): Pair<FloatArray, FloatArray> {
        val triangles = ArrayList<Float>(1800)
        val edges = ArrayList<Float>(600)
        appendSegmentMesh(triangles, edges, 0f, 0.52f, 0f, 1.05f, 0.16f, 0.075f)
        appendOctahedronMesh(triangles, edges, 0f, 1.38f, 0f, 0.14f, 0.13f)
        appendSegmentMesh(triangles, edges, -0.13f, 0.98f, -0.39f, 0.59f, 0.065f, 0.052f)
        appendSegmentMesh(triangles, edges, -0.39f, 0.59f, -0.44f, 0.24f, 0.052f, 0.045f)
        appendSegmentMesh(triangles, edges, 0.13f, 0.98f, 0.39f, 0.59f, 0.065f, 0.052f)
        appendSegmentMesh(triangles, edges, 0.39f, 0.59f, 0.44f, 0.24f, 0.052f, 0.045f)
        appendSegmentMesh(triangles, edges, -0.09f, 0.55f, -0.20f, 0.13f, 0.085f, 0.06f)
        appendSegmentMesh(triangles, edges, -0.20f, 0.13f, -0.22f, 0.015f, 0.065f, 0.05f)
        appendSegmentMesh(triangles, edges, 0.09f, 0.55f, 0.20f, 0.13f, 0.085f, 0.06f)
        appendSegmentMesh(triangles, edges, 0.20f, 0.13f, 0.22f, 0.015f, 0.065f, 0.05f)
        return triangles.toFloatArray() to edges.toFloatArray()
    }

    /** Adds an extruded, triangulated bone segment and its explicit mesh edges. */
    private fun appendSegmentMesh(
        triangles: MutableList<Float>,
        edges: MutableList<Float>,
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float,
        halfWidth: Float,
        halfDepth: Float
    ) {
        val dx = bx - ax
        val dy = by - ay
        val length = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
        val nx = -dy / length * halfWidth
        val ny = dx / length * halfWidth
        val v = arrayOf(
            floatArrayOf(ax + nx, ay + ny, halfDepth),
            floatArrayOf(ax - nx, ay - ny, halfDepth),
            floatArrayOf(bx - nx, by - ny, halfDepth),
            floatArrayOf(bx + nx, by + ny, halfDepth),
            floatArrayOf(ax + nx, ay + ny, -halfDepth),
            floatArrayOf(ax - nx, ay - ny, -halfDepth),
            floatArrayOf(bx - nx, by - ny, -halfDepth),
            floatArrayOf(bx + nx, by + ny, -halfDepth)
        )
        val faces = arrayOf(
            intArrayOf(0, 1, 2, 0, 2, 3), intArrayOf(4, 6, 5, 4, 7, 6),
            intArrayOf(0, 4, 5, 0, 5, 1), intArrayOf(1, 5, 6, 1, 6, 2),
            intArrayOf(2, 6, 7, 2, 7, 3), intArrayOf(3, 7, 4, 3, 4, 0)
        )
        faces.forEach { face -> face.forEach { index -> triangles.addVertex(v[index]) } }
        val links = arrayOf(
            intArrayOf(0, 1), intArrayOf(1, 2), intArrayOf(2, 3), intArrayOf(3, 0),
            intArrayOf(4, 5), intArrayOf(5, 6), intArrayOf(6, 7), intArrayOf(7, 4),
            intArrayOf(0, 4), intArrayOf(1, 5), intArrayOf(2, 6), intArrayOf(3, 7)
        )
        links.forEach { (a, b) -> edges.addVertex(v[a]); edges.addVertex(v[b]) }
    }

    private fun appendOctahedronMesh(
        triangles: MutableList<Float>,
        edges: MutableList<Float>,
        x: Float,
        y: Float,
        z: Float,
        radius: Float,
        depth: Float
    ) {
        val v = arrayOf(
            floatArrayOf(x, y + radius, z), floatArrayOf(x, y - radius, z),
            floatArrayOf(x - radius, y, z), floatArrayOf(x + radius, y, z),
            floatArrayOf(x, y, z + depth), floatArrayOf(x, y, z - depth)
        )
        val faces = arrayOf(
            intArrayOf(0, 2, 4), intArrayOf(0, 4, 3), intArrayOf(0, 3, 5), intArrayOf(0, 5, 2),
            intArrayOf(1, 4, 2), intArrayOf(1, 3, 4), intArrayOf(1, 5, 3), intArrayOf(1, 2, 5)
        )
        faces.forEach { face -> face.forEach { triangles.addVertex(v[it]) } }
        val links = arrayOf(
            intArrayOf(0, 2), intArrayOf(0, 3), intArrayOf(0, 4), intArrayOf(0, 5),
            intArrayOf(1, 2), intArrayOf(1, 3), intArrayOf(1, 4), intArrayOf(1, 5),
            intArrayOf(2, 4), intArrayOf(4, 3), intArrayOf(3, 5), intArrayOf(5, 2)
        )
        links.forEach { (a, b) -> edges.addVertex(v[a]); edges.addVertex(v[b]) }
    }

    private fun MutableList<Float>.addVertex(vertex: FloatArray) {
        add(vertex[0]); add(vertex[1]); add(vertex[2])
    }

    private fun createSphereGeometry(): Pair<FloatArray, FloatArray> {
        val latitudeSegments = 14
        val longitudeSegments = 28
        val radius = 0.58f
        val centerY = 0.66f
        fun point(latitude: Int, longitude: Int): FloatArray {
            val phi = -PI.toFloat() / 2f + PI.toFloat() * latitude / latitudeSegments
            val theta = 2f * PI.toFloat() * longitude / longitudeSegments
            val ringRadius = cos(phi) * radius
            return floatArrayOf(
                cos(theta) * ringRadius,
                centerY + sin(phi) * radius,
                sin(theta) * ringRadius
            )
        }
        val triangles = ArrayList<Float>(latitudeSegments * longitudeSegments * 18)
        val lines = ArrayList<Float>((latitudeSegments + 1) * longitudeSegments * 6)
        for (lat in 0 until latitudeSegments) {
            for (lon in 0 until longitudeSegments) {
                val a = point(lat, lon)
                val b = point(lat + 1, lon)
                val c = point(lat + 1, lon + 1)
                val d = point(lat, lon + 1)
                triangles.addVertex(a); triangles.addVertex(b); triangles.addVertex(c)
                triangles.addVertex(a); triangles.addVertex(c); triangles.addVertex(d)
            }
        }
        for (lat in 0..latitudeSegments) {
            for (lon in 0 until longitudeSegments) {
                lines.addVertex(point(lat, lon))
                lines.addVertex(point(lat, lon + 1))
            }
        }
        for (lat in 0 until latitudeSegments) {
            for (lon in 0 until longitudeSegments) {
                lines.addVertex(point(lat, lon))
                lines.addVertex(point(lat + 1, lon))
            }
        }
        return triangles.toFloatArray() to lines.toFloatArray()
    }

    private fun drawWall(brightness: Float) {
        val color = 0.45f + brightness * 0.45f
        val outline = floatArrayOf(
            -0.62f, 0.01f, 0f, 0.62f, 0.01f, 0f,
            0.62f, 0.01f, 0f, 0.62f, 1.55f, 0f,
            0.62f, 1.55f, 0f, -0.62f, 1.55f, 0f,
            -0.62f, 1.55f, 0f, -0.62f, 0.01f, 0f
        )
        draw(outline, GLES20.GL_LINES, 1f * color, 0.68f * color, 0.26f * color, 0.95f)
        val grid = floatArrayOf(
            -0.62f, 0.52f, 0f, 0.62f, 0.52f, 0f,
            -0.62f, 1.03f, 0f, 0.62f, 1.03f, 0f,
            0f, 0.01f, 0f, 0f, 1.55f, 0f
        )
        draw(grid, GLES20.GL_LINES, 0.9f, 0.48f, 0.18f, 0.72f)
    }

    private fun drawAura(brightness: Float, glow: Float) {
        val c = 0.4f + brightness * 0.55f
        draw(circle(0.58f, 0.78f, 48, vertical = true), GLES20.GL_LINE_LOOP, 0.15f, c, 1f, glow)
        draw(circle(0.58f, 0.78f, 48), GLES20.GL_LINE_LOOP, 0.62f, 0.30f, c, glow)
        val cross = floatArrayOf(-0.70f, 0.78f, 0f, 0.70f, 0.78f, 0f, 0f, 0.78f, -0.70f, 0f, 0.78f, 0.70f)
        draw(cross, GLES20.GL_LINES, 0.20f, c, 1f, glow)
    }

    private fun circle(radius: Float, y: Float, count: Int, vertical: Boolean = false): FloatArray {
        return FloatArray((count + 1) * 3).also { out ->
            for (i in 0..count) {
                val angle = 2f * PI.toFloat() * i / count
                val offset = i * 3
                if (vertical) {
                    out[offset] = cos(angle) * radius
                    out[offset + 1] = y + sin(angle) * radius
                    out[offset + 2] = 0f
                } else {
                    out[offset] = cos(angle) * radius
                    out[offset + 1] = y
                    out[offset + 2] = sin(angle) * radius
                }
            }
        }
    }

    private fun arc(radius: Float, y: Float, count: Int): FloatArray {
        return FloatArray((count + 1) * 3).also { out ->
            for (i in 0..count) {
                val angle = PI.toFloat() * i / count
                val offset = i * 3
                out[offset] = cos(angle) * radius
                out[offset + 1] = y
                out[offset + 2] = sin(angle) * radius
            }
        }
    }

    private fun setMvp(transform: FloatArray) {
        Matrix.multiplyMM(mvp, 0, viewProjection, 0, transform, 0)
    }

    private fun draw(vertices: FloatArray, primitive: Int, r: Float, g: Float, b: Float, a: Float) {
        if (vertices.size < 6) return
        val buffer = floatBuffer(vertices)
        GLES20.glUseProgram(geometryProgram)
        val position = GLES20.glGetAttribLocation(geometryProgram, "a_Position")
        val matrix = GLES20.glGetUniformLocation(geometryProgram, "u_Mvp")
        val color = GLES20.glGetUniformLocation(geometryProgram, "u_Color")
        GLES20.glUniformMatrix4fv(matrix, 1, false, mvp, 0)
        GLES20.glUniform4f(
            color,
            r.coerceIn(0f, 1f),
            g.coerceIn(0f, 1f),
            b.coerceIn(0f, 1f),
            (a * drawAlphaMultiplier).coerceIn(0f, 1f)
        )
        buffer.position(0)
        GLES20.glEnableVertexAttribArray(position)
        GLES20.glVertexAttribPointer(position, 3, GLES20.GL_FLOAT, false, 0, buffer)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glLineWidth(2f)
        GLES20.glDrawArrays(primitive, 0, vertices.size / 3)
        GLES20.glDisableVertexAttribArray(position)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    private fun publish(line: String) {
        val now = System.currentTimeMillis()
        if (line != lastStatus || now - lastStatusMs >= 350L) {
            lastStatus = line
            lastStatusMs = now
            onStatus(line)
        }
    }

    private fun createExternalTexture(): Int {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, ids[0])
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        return ids[0]
    }

    private fun createProgram(vertex: String, fragment: String): Int {
        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vertex)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragment)
        if (vs == 0 || fs == 0) return 0
        val program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs)
        GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)
        val result = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, result, 0)
        if (result[0] == 0) {
            Log.e(TAG, "Shader link failed: ${GLES20.glGetProgramInfoLog(program)}")
            GLES20.glDeleteProgram(program)
            return 0
        }
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
        return program
    }

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val result = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, result, 0)
        if (result[0] == 0) {
            Log.e(TAG, "Shader compile failed: ${GLES20.glGetShaderInfoLog(shader)}")
            GLES20.glDeleteShader(shader)
            return 0
        }
        return shader
    }

    private fun floatBuffer(values: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(values.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply { put(values); position(0) }

    companion object {
        private const val TAG = "ArWorldRenderer"
        private const val CAMERA_VERTEX = """
            attribute vec4 a_Position;
            attribute vec2 a_TexCoord;
            varying vec2 v_TexCoord;
            void main() {
                gl_Position = a_Position;
                v_TexCoord = a_TexCoord;
            }
        """
        private const val CAMERA_FRAGMENT = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            uniform samplerExternalOES sTexture;
            varying vec2 v_TexCoord;
            void main() { gl_FragColor = texture2D(sTexture, v_TexCoord); }
        """
        private const val GEOMETRY_VERTEX = """
            attribute vec4 a_Position;
            uniform mat4 u_Mvp;
            void main() { gl_Position = u_Mvp * a_Position; }
        """
        private const val GEOMETRY_FRAGMENT = """
            precision mediump float;
            uniform vec4 u_Color;
            void main() { gl_FragColor = u_Color; }
        """
    }
}
