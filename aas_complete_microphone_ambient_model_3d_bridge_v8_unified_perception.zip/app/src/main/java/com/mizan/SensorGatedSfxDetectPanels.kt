package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object SensorGatedSfxDetectPanels {
    fun build(ctx: Context, root: LinearLayout, b: SensorGatedSfxDetectBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFFAB91.toInt()
        p.title("SENSOR-GATED SFX · PRANK-APP STYLE · ACCEL+MIC", c)
        p.note("Android SensorManager accel impact + mic transient + cooldown. Symbolic SFX gates only.")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Accelerometer gate", b.sensorOn) { b.sensorOn = it }
        p.switch("Mic transient gate", b.micGateOn) { b.micGateOn = it }
        p.switch("Require BOTH accel+mic", b.requireBoth) { b.requireBoth = it }
        p.seek("Accel sensitivity (g)", 1.2f, 8f, b.accelSens) { b.accelSens = it }
        p.seek("Mic transient thr", 0.05f, 0.9f, b.micThr) { b.micThr = it }
        p.seek("Cooldown ms", 100f, 2000f, b.cooldownMs.toFloat()) { b.cooldownMs = it.toLong() }
        val st = p.status("SFX-SENSOR —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 150) }
        })
    }
}
