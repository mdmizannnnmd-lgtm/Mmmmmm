package com.mizan

import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import javax.net.ssl.HttpsURLConnection

/**
 * Dev testing system — HTTPS API request · response · body modification.
 * Runs off main thread. RAW COMPLETE.
 */
class DevHttpsApiTester {

    @Volatile var enabled = true
    @Volatile var lastUrl = "https://httpbin.org/get"
    @Volatile var method = "GET"
    @Volatile var requestHeaders = "Accept: application/json\nContent-Type: application/json"
    @Volatile var requestBody = ""
    @Volatile var connectTimeoutMs = 15000
    @Volatile var readTimeoutMs = 20000

    @Volatile var responseCode = 0
    @Volatile var responseHeaders = ""
    @Volatile var responseBody = ""
    @Volatile var responseMs = 0L
    @Volatile var error = ""
    @Volatile var status = "API idle"
    @Volatile var busy = false

    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun setMethodGet() { method = "GET" }
    fun setMethodPost() { method = "POST" }
    fun setMethodPut() { method = "PUT" }
    fun setMethodDelete() { method = "DELETE" }
    fun setMethodPatch() { method = "PATCH" }

    /** Modify request body before send (dev testing). */
    fun modifyBody(transform: (String) -> String) {
        requestBody = transform(requestBody)
    }

    fun clearResponse() {
        responseCode = 0
        responseHeaders = ""
        responseBody = ""
        responseMs = 0L
        error = ""
        status = "API cleared"
    }

    fun send(onDone: (() -> Unit)? = null) {
        if (!enabled) {
            status = "API OFF"
            onDone?.let { main.post(it) }
            return
        }
        if (busy) {
            status = "API busy…"
            return
        }
        busy = true
        status = "API ${method} → sending…"
        val urlSnap = lastUrl
        val methodSnap = method.uppercase()
        val headersSnap = requestHeaders
        val bodySnap = requestBody
        val cto = connectTimeoutMs
        val rto = readTimeoutMs

        exec.execute {
            val t0 = System.currentTimeMillis()
            var code = 0
            var hdrs = ""
            var body = ""
            var err = ""
            try {
                val url = URL(urlSnap)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = methodSnap
                    connectTimeout = cto
                    readTimeout = rto
                    doInput = true
                    instanceFollowRedirects = true
                    if (this is HttpsURLConnection) {
                        // default system SSL — production trust store
                    }
                    // headers
                    headersSnap.lines().forEach { line ->
                        val t = line.trim()
                        if (t.isEmpty() || !t.contains(":")) return@forEach
                        val i = t.indexOf(':')
                        val k = t.substring(0, i).trim()
                        val v = t.substring(i + 1).trim()
                        if (k.isNotEmpty()) setRequestProperty(k, v)
                    }
                    if (methodSnap == "POST" || methodSnap == "PUT" || methodSnap == "PATCH") {
                        doOutput = true
                        if (bodySnap.isNotEmpty()) {
                            OutputStreamWriter(outputStream, Charsets.UTF_8).use { it.write(bodySnap); it.flush() }
                        }
                    }
                }
                code = try { conn.responseCode } catch (_: Throwable) { -1 }
                val hdrMap = conn.headerFields
                hdrs = hdrMap?.entries?.joinToString("\n") { (k, v) ->
                    "${k ?: "(status)"}: ${v?.joinToString("; ") ?: ""}"
                } ?: ""
                val stream = try {
                    if (code in 200..299) conn.inputStream else conn.errorStream
                } catch (_: Throwable) { null }
                body = if (stream != null) {
                    BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
                } else ""
                conn.disconnect()
            } catch (t: Throwable) {
                err = t.javaClass.simpleName + ": " + (t.message ?: "")
            }
            val ms = System.currentTimeMillis() - t0
            main.post {
                responseCode = code
                responseHeaders = hdrs
                responseBody = body.take(200_000) // cap UI
                responseMs = ms
                error = err
                busy = false
                status = if (err.isNotEmpty()) {
                    "API ERR $err (${ms}ms)"
                } else {
                    "API $methodSnap $code · ${ms}ms · ${body.length}b"
                }
                onDone?.invoke()
            }
        }
    }
}
