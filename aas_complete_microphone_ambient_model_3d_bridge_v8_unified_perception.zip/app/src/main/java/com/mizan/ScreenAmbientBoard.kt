package com.mizan

/**
 * Device display ambient: level + bipolar ±120 dB threshold.
 * Own-device display path only.
 */
class ScreenAmbientBoard {
    @Volatile var enabled = true
    @Volatile var ambientLv = 0.55f
    @Volatile var bipNeg = -40f
    @Volatile var bipPos = 40f
    @Volatile var thrOn = true
    @Volatile var liveDb = -80.0
    @Volatile var overThr = false
    @Volatile var dampen = 0f

    /** RAW COMPLETE — pure ambient/centroid/vertical path */
    @Volatile var rawComplete = true

    // Screen centroid (horizontal / spectral center of screen ambient energy)
    @Volatile var centroidOn = true
    @Volatile var centroidLv = 0.60f
    @Volatile var centroidThr = 0.30f
    @Volatile var centroidActive = false
    @Volatile var centroidOut = 0f
    @Volatile var centroidNorm = 0f
    private val cenHist = FloatArray(24)
    private var cenIdx = 0
    private var cenN = 0

    // Screen vertical (vertical body/screen height rail)
    @Volatile var verticalOn = true
    @Volatile var verticalLv = 0.55f
    @Volatile var verticalThr = 0.28f
    @Volatile var verticalActive = false
    @Volatile var verticalOut = 0f
    @Volatile var verticalNorm = 0f
    /** External vertical feed 0..1 (from centroid drive / body) */
    @Volatile var verticalFeed = 0.5f

    // Screen domination Hz (dominant frequency energy on screen ambient path)
    @Volatile var dominationOn = true
    @Volatile var dominationLv = 0.60f
    @Volatile var dominationThr = 0.30f
    @Volatile var dominationRaw = false
    @Volatile var dominationHzMin = 20f
    @Volatile var dominationHzMax = 8000f
    @Volatile var dominationActive = false
    @Volatile var dominationOut = 0f
    @Volatile var dominationNorm = 0f
    @Volatile var dominationHz = 0f
    /** External dominant-Hz feed (Hz) from live mic / analysis */
    @Volatile var dominationHzFeed = 0f


    /** Screen ambient spike */
    @Volatile var spikeOn = true
    @Volatile var spikeThr = 0.55f
    @Volatile var spikeLv = 0.70f
    @Volatile var spikeActive = false

    /** Intensity + visuals mode (0=soft 1=normal 2=hard 3=block) */
    @Volatile var intensityOn = true
    @Volatile var intensityLv = 0.65f
    @Volatile var intensityThr = 0.40f
    @Volatile var intensityActive = false
    @Volatile var visualsMode = 1
    @Volatile var visualBlockOn = true
    @Volatile var visualBlockThr = 0.55f
    @Volatile var visualBlockLv = 0.70f
    @Volatile var visualBlockActive = false

    /** Left / Right pitch protection */
    @Volatile var pitchLrOn = true
    @Volatile var pitchLrThr = 0.40f
    @Volatile var pitchLrLv = 0.60f
    @Volatile var pitchLrActive = false
    @Volatile var pitchLr = 0f

    /** Up / Down pitch protection */
    @Volatile var pitchUdOn = true
    @Volatile var pitchUdThr = 0.40f
    @Volatile var pitchUdLv = 0.60f
    @Volatile var pitchUdActive = false
    @Volatile var pitchUd = 0f

    /** Battery box tracking protection (own device path) */
    @Volatile var battBoxTrackOn = true
    @Volatile var battBoxTrackThr = 0.50f
    @Volatile var battBoxTrackLv = 0.65f
    @Volatile var battBoxTrackActive = false

    /** Battery box intensity block */
    @Volatile var battBoxIntOn = true
    @Volatile var battBoxIntThr = 0.55f
    @Volatile var battBoxIntLv = 0.70f
    @Volatile var battBoxIntActive = false

    /** Battery box master threshold + decay protection */
    @Volatile var battBoxOn = true
    @Volatile var battBoxThr = 0.45f
    @Volatile var battBoxLv = 0.60f
    @Volatile var battBoxActive = false
    @Volatile var battBoxOut = 0f
    @Volatile var battBoxDecayOn = true
    @Volatile var battBoxDecayThr = 0.40f
    @Volatile var battBoxDecayLv = 0.55f
    @Volatile var battBoxDecayMs = 800L
    @Volatile var battBoxDecayActive = false
    @Volatile var battBoxDecayOut = 0f
    private var battBoxDecayUntil = 0L

    /** Battery box texture threshold */
    @Volatile var battBoxTexOn = true
    @Volatile var battBoxTexThr = 0.42f
    @Volatile var battBoxTexLv = 0.50f
    @Volatile var battBoxTexActive = false
    @Volatile var battBoxTexOut = 0f

    /** Battery box colour (R/G/B 0..255 style as 0..1) + colour threshold */
    @Volatile var battBoxColorOn = true
    @Volatile var battBoxColorThr = 0.40f
    @Volatile var battBoxColorR = 0.55f
    @Volatile var battBoxColorG = 0.75f
    @Volatile var battBoxColorB = 0.45f
    @Volatile var battBoxColorActive = false
    @Volatile var battBoxColorOut = 0f

    /** Battery box visual (screen visual path) */
    @Volatile var battBoxVisOn = true
    @Volatile var battBoxVisThr = 0.38f
    @Volatile var battBoxVisLv = 0.55f
    @Volatile var battBoxVisActive = false
    @Volatile var battBoxVisOut = 0f

    /** Battery box charge level (0..1 = 0..100%) — own device */
    @Volatile var battBoxChargeOn = true
    @Volatile var battBoxChargePct = 0.50f
    @Volatile var battBoxChargeThr = 0.25f
    @Volatile var battBoxChargeLv = 0.60f
    @Volatile var battBoxChargeLow = false
    @Volatile var battBoxChargeActive = false
    @Volatile var battBoxChargeOut = 0f

    /** Charge decay protection — hold after low-charge trip */
    @Volatile var battBoxChargeDecayOn = true
    @Volatile var battBoxChargeDecayThr = 0.30f
    @Volatile var battBoxChargeDecayLv = 0.55f
    @Volatile var battBoxChargeDecayMs = 900L
    @Volatile var battBoxChargeDecayActive = false
    @Volatile var battBoxChargeDecayOut = 0f
    private var battBoxChargeDecayUntil = 0L

    /** Fully charged threshold (high %) */
    @Volatile var battBoxFullOn = true
    @Volatile var battBoxFullThr = 0.90f
    @Volatile var battBoxFullLv = 0.40f
    @Volatile var battBoxFullActive = false
    @Volatile var battBoxFullOut = 0f

    /** Screen body surface (threshold + level) — adjustable */
    @Volatile var bodySurfaceOn = true
    @Volatile var bodySurfaceThr = 0.45f
    @Volatile var bodySurfaceLv = 0.60f
    @Volatile var bodySurfaceActive = false
    @Volatile var bodySurfaceOut = 0f

    /** Screen body atmosphere (atomspare) surface */
    @Volatile var bodyAtmoSurfOn = true
    @Volatile var bodyAtmoSurfThr = 0.40f
    @Volatile var bodyAtmoSurfLv = 0.55f
    @Volatile var bodyAtmoSurfActive = false
    @Volatile var bodyAtmoSurfOut = 0f

    /** Screen body atmosphere spike protection */
    @Volatile var bodyAtmoSpikeOn = true
    @Volatile var bodyAtmoSpikeThr = 0.50f
    @Volatile var bodyAtmoSpikeLv = 0.70f
    @Volatile var bodyAtmoSpikeActive = false

    /** Screen body motion: movement */
    @Volatile var bodyMoveOn = true
    @Volatile var bodyMoveThr = 0.35f
    @Volatile var bodyMoveLv = 0.55f
    @Volatile var bodyMoveActive = false
    @Volatile var bodyMoveOut = 0f

    /** Screen body motion: speed */
    @Volatile var bodySpeedOn = true
    @Volatile var bodySpeedThr = 0.35f
    @Volatile var bodySpeedLv = 0.55f
    @Volatile var bodySpeedActive = false
    @Volatile var bodySpeedOut = 0f

    /** Screen body motion: waves */
    @Volatile var bodyWaveOn = true
    @Volatile var bodyWaveThr = 0.35f
    @Volatile var bodyWaveLv = 0.55f
    @Volatile var bodyWaveActive = false
    @Volatile var bodyWaveOut = 0f

    /** Screen body wavespare */
    @Volatile var bodyWaveSpareOn = true
    @Volatile var bodyWaveSpareThr = 0.40f
    @Volatile var bodyWaveSpareLv = 0.55f
    @Volatile var bodyWaveSpareActive = false
    @Volatile var bodyWaveSpareOut = 0f

    /** Screen body motion bipolar dB rails */
    @Volatile var bodyMotionBipOn = true
    @Volatile var bodyMotionBipNeg = -40f
    @Volatile var bodyMotionBipPos = 40f
    @Volatile var bodyMotionBipHit = false

    /** Screen echo controller */
    @Volatile var echoOn = true
    @Volatile var echoThr = 0.40f
    @Volatile var echoLv = 0.60f
    @Volatile var echoActive = false
    @Volatile var echoOut = 0f
    private var echoPrev = 0f

    /** Echo motion controls */
    @Volatile var echoMoveOn = true
    @Volatile var echoMoveThr = 0.35f
    @Volatile var echoMoveLv = 0.50f
    @Volatile var echoMoveActive = false
    @Volatile var echoSpeedOn = true
    @Volatile var echoSpeedThr = 0.35f
    @Volatile var echoSpeedLv = 0.50f
    @Volatile var echoSpeedActive = false
    @Volatile var echoWaveOn = true
    @Volatile var echoWaveThr = 0.35f
    @Volatile var echoWaveLv = 0.50f
    @Volatile var echoWaveActive = false

    /** Screen echo centroid · vertical + live microphone echo (+ mic centroid · vertical), all with RAW COMPLETE. */
    val echoX = ScreenEchoMic()

    /** Echo atmosphere (atomspare) controller */
    @Volatile var echoAtmoOn = true
    @Volatile var echoAtmoThr = 0.40f
    @Volatile var echoAtmoLv = 0.55f
    @Volatile var echoAtmoActive = false
    @Volatile var echoAtmoOut = 0f

    /** Echo wavespare */
    @Volatile var echoWaveSpareOn = true
    @Volatile var echoWaveSpareThr = 0.40f
    @Volatile var echoWaveSpareLv = 0.55f
    @Volatile var echoWaveSpareActive = false
    @Volatile var echoWaveSpareOut = 0f

    /** Screen tracking + motion + atmosphere */
    @Volatile var trackOn = true
    @Volatile var trackThr = 0.40f
    @Volatile var trackLv = 0.60f
    @Volatile var trackActive = false
    @Volatile var trackOut = 0f
    @Volatile var trackMoveOn = true
    @Volatile var trackMoveThr = 0.35f
    @Volatile var trackMoveLv = 0.50f
    @Volatile var trackMoveActive = false
    @Volatile var trackSpeedOn = true
    @Volatile var trackSpeedThr = 0.35f
    @Volatile var trackSpeedLv = 0.50f
    @Volatile var trackSpeedActive = false
    @Volatile var trackWaveOn = true
    @Volatile var trackWaveThr = 0.35f
    @Volatile var trackWaveLv = 0.50f
    @Volatile var trackWaveActive = false
    @Volatile var trackAtmoOn = true
    @Volatile var trackAtmoThr = 0.40f
    @Volatile var trackAtmoLv = 0.55f
    @Volatile var trackAtmoActive = false
    @Volatile var trackAtmoOut = 0f
    @Volatile var trackWaveSpareOn = true
    @Volatile var trackWaveSpareThr = 0.40f
    @Volatile var trackWaveSpareLv = 0.55f
    @Volatile var trackWaveSpareActive = false
    @Volatile var trackWaveSpareOut = 0f

    /** Screen enemies body surface + motion + atmosphere (local UI only) */
    @Volatile var enemyBodySurfOn = true
    @Volatile var enemyBodySurfThr = 0.50f
    @Volatile var enemyBodySurfLv = 0.65f
    @Volatile var enemyBodySurfActive = false
    @Volatile var enemyBodySurfOut = 0f
    @Volatile var enemyMoveOn = true
    @Volatile var enemyMoveThr = 0.40f
    @Volatile var enemyMoveLv = 0.55f
    @Volatile var enemyMoveActive = false
    @Volatile var enemySpeedOn = true
    @Volatile var enemySpeedThr = 0.40f
    @Volatile var enemySpeedLv = 0.55f
    @Volatile var enemySpeedActive = false
    @Volatile var enemyWaveOn = true
    @Volatile var enemyWaveThr = 0.40f
    @Volatile var enemyWaveLv = 0.55f
    @Volatile var enemyWaveActive = false
    @Volatile var enemyAtmoOn = true
    @Volatile var enemyAtmoThr = 0.45f
    @Volatile var enemyAtmoLv = 0.60f
    @Volatile var enemyAtmoActive = false
    @Volatile var enemyAtmoOut = 0f
    @Volatile var enemyWaveSpareOn = true
    @Volatile var enemyWaveSpareThr = 0.40f
    @Volatile var enemyWaveSpareLv = 0.55f
    @Volatile var enemyWaveSpareActive = false
    @Volatile var enemyWaveSpareOut = 0f

    /** Trans-communication surface + motion + atmosphere + bipolar */
    @Volatile var commSurfOn = true
    @Volatile var commSurfThr = 0.45f
    @Volatile var commSurfLv = 0.55f
    @Volatile var commSurfActive = false
    @Volatile var commSurfOut = 0f
    @Volatile var commBipOn = true
    @Volatile var commBipNeg = -40f
    @Volatile var commBipPos = 40f
    @Volatile var commBipHit = false
    @Volatile var commMoveOn = true
    @Volatile var commMoveThr = 0.35f
    @Volatile var commMoveLv = 0.50f
    @Volatile var commMoveActive = false
    @Volatile var commSpeedOn = true
    @Volatile var commSpeedThr = 0.35f
    @Volatile var commSpeedLv = 0.50f
    @Volatile var commSpeedActive = false
    @Volatile var commWaveOn = true
    @Volatile var commWaveThr = 0.35f
    @Volatile var commWaveLv = 0.50f
    @Volatile var commWaveActive = false
    @Volatile var commAtmoOn = true
    @Volatile var commAtmoThr = 0.40f
    @Volatile var commAtmoLv = 0.55f
    @Volatile var commAtmoActive = false
    @Volatile var commAtmoOut = 0f
    @Volatile var commWaveSpareOn = true
    @Volatile var commWaveSpareThr = 0.40f
    @Volatile var commWaveSpareLv = 0.55f
    @Volatile var commWaveSpareActive = false
    @Volatile var commWaveSpareOut = 0f

    /** Screen 3D humanoid body-84 channel surface */
    @Volatile var body84SurfOn = true
    @Volatile var body84SurfThr = 0.40f
    @Volatile var body84SurfLv = 0.60f
    @Volatile var body84SurfActive = false
    @Volatile var body84SurfOut = 0f
    /** Optional link energy from Body84Channels.avgOut (0..1) */
    @Volatile var body84Link = 0f

    /** Screen atmospheric intensity / intention gate */
    @Volatile var atmoIntGateOn = true
    @Volatile var atmoIntGateThr = 0.45f
    @Volatile var atmoIntGateLv = 0.65f
    @Volatile var atmoIntGateActive = false
    @Volatile var atmoIntGateOut = 0f
    @Volatile var atmoIntBipOn = true
    @Volatile var atmoIntBipNeg = -40f
    @Volatile var atmoIntBipPos = 40f
    @Volatile var atmoIntBipHit = false

    /** Screen visualisation gate */
    @Volatile var visualGateOn = true
    @Volatile var visualGateThr = 0.40f
    @Volatile var visualGateLv = 0.60f
    @Volatile var visualGateActive = false
    @Volatile var visualGateOut = 0f
    @Volatile var visualBipOn = true
    @Volatile var visualBipNeg = -40f
    @Volatile var visualBipPos = 40f
    @Volatile var visualBipHit = false

    /** Screen imagination gate */
    @Volatile var imagineGateOn = true
    @Volatile var imagineGateThr = 0.42f
    @Volatile var imagineGateLv = 0.58f
    @Volatile var imagineGateActive = false
    @Volatile var imagineGateOut = 0f
    @Volatile var imagineBipOn = true
    @Volatile var imagineBipNeg = -40f
    @Volatile var imagineBipPos = 40f
    @Volatile var imagineBipHit = false

    /** Screen animation gate */
    @Volatile var animGateOn = true
    @Volatile var animGateThr = 0.38f
    @Volatile var animGateLv = 0.55f
    @Volatile var animGateActive = false
    @Volatile var animGateOut = 0f
    @Volatile var animBipOn = true
    @Volatile var animBipNeg = -40f
    @Volatile var animBipPos = 40f
    @Volatile var animBipHit = false

    fun tick(energy: Float, db: Double, motionLr: Float = 0f, motionUd: Float = 0f, battEnergy: Float = 0f, domHz: Float = 0f) {
        if (domHz > 1f) dominationHzFeed = domHz
        processDomination(if (domHz > 1f) domHz else dominationHzFeed)
        liveDb = db
        if (!enabled) {
            overThr = false
            centroidActive = false; centroidOut = 0f; centroidNorm = 0f
            verticalActive = false; verticalOut = 0f; verticalNorm = 0f
            dominationActive = false; dominationOut = 0f; dominationNorm = 0f; dominationHz = 0f
            spikeActive = false
            intensityActive = false
            visualBlockActive = false
            pitchLrActive = false
            pitchUdActive = false
            battBoxTrackActive = false
            battBoxIntActive = false
            battBoxActive = false
            battBoxOut = 0f
            battBoxDecayActive = false
            battBoxDecayOut = 0f
            battBoxTexActive = false
            battBoxTexOut = 0f
            battBoxColorActive = false
            battBoxColorOut = 0f
            battBoxVisActive = false
            battBoxVisOut = 0f
            battBoxChargeLow = false
            battBoxChargeActive = false
            battBoxChargeOut = 0f
            battBoxChargeDecayActive = false
            battBoxChargeDecayOut = 0f
            battBoxFullActive = false
            battBoxFullOut = 0f
            bodySurfaceActive = false
            bodySurfaceOut = 0f
            bodyAtmoSurfActive = false
            bodyAtmoSurfOut = 0f
            bodyAtmoSpikeActive = false
            bodyMoveActive = false
            bodyMoveOut = 0f
            bodySpeedActive = false
            bodySpeedOut = 0f
            bodyWaveActive = false
            bodyWaveOut = 0f
            bodyWaveSpareActive = false
            bodyWaveSpareOut = 0f
            bodyMotionBipHit = false
            echoActive = false
            echoOut = 0f
            echoX.reset()
            echoMoveActive = false
            echoSpeedActive = false
            echoWaveActive = false
            echoAtmoActive = false
            echoAtmoOut = 0f
            echoWaveSpareActive = false
            echoWaveSpareOut = 0f
            trackActive = false
            trackOut = 0f
            trackMoveActive = false
            trackSpeedActive = false
            trackWaveActive = false
            trackAtmoActive = false
            trackAtmoOut = 0f
            trackWaveSpareActive = false
            trackWaveSpareOut = 0f
            enemyBodySurfActive = false
            enemyBodySurfOut = 0f
            enemyMoveActive = false
            enemySpeedActive = false
            enemyWaveActive = false
            enemyAtmoActive = false
            enemyAtmoOut = 0f
            enemyWaveSpareActive = false
            enemyWaveSpareOut = 0f
            commSurfActive = false
            commSurfOut = 0f
            commBipHit = false
            commMoveActive = false
            commSpeedActive = false
            commWaveActive = false
            commAtmoActive = false
            commAtmoOut = 0f
            commWaveSpareActive = false
            commWaveSpareOut = 0f
            body84SurfActive = false
            body84SurfOut = 0f
            atmoIntGateActive = false
            atmoIntGateOut = 0f
            atmoIntBipHit = false
            visualGateActive = false
            visualGateOut = 0f
            visualBipHit = false
            imagineGateActive = false
            imagineGateOut = 0f
            imagineBipHit = false
            animGateActive = false
            animGateOut = 0f
            animBipHit = false
            dampen = 0f
            return
        }
        val lo = bipNeg.coerceIn(-120f, 0f).toDouble()
        val hi = bipPos.coerceIn(0f, 120f).toDouble()
        overThr = thrOn && (db <= lo || db >= hi || energy >= ambientLv.coerceIn(0.05f, 1f))
        spikeActive = spikeOn && energy >= spikeThr.coerceIn(0.05f, 1f)
        intensityActive = intensityOn && energy >= intensityThr.coerceIn(0.05f, 1f)
        visualBlockActive = visualBlockOn && energy >= visualBlockThr.coerceIn(0.05f, 1f)
        pitchLr = motionLr.coerceIn(0f, 1f)
        pitchUd = motionUd.coerceIn(0f, 1f)
        pitchLrActive = pitchLrOn && pitchLr >= pitchLrThr.coerceIn(0.05f, 1f)
        pitchUdActive = pitchUdOn && pitchUd >= pitchUdThr.coerceIn(0.05f, 1f)
        val be = battEnergy.coerceIn(0f, 1f).let { if (it > 0f) it else energy }
        battBoxTrackActive = battBoxTrackOn && be >= battBoxTrackThr.coerceIn(0.05f, 1f)
        battBoxIntActive = battBoxIntOn && be >= battBoxIntThr.coerceIn(0.05f, 1f)

        // Battery box master threshold
        val bbThr = battBoxThr.coerceIn(0.05f, 1f)
        battBoxActive = battBoxOn && be >= bbThr
        battBoxOut = if (battBoxActive) {
            (((be - bbThr) / (1f - bbThr).coerceAtLeast(0.05f)) * battBoxLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Decay protection — hold after trip
        val now = System.currentTimeMillis()
        if (battBoxActive && battBoxDecayOn) {
            battBoxDecayUntil = now + battBoxDecayMs.coerceIn(50L, 5000L)
        }
        val dThr = battBoxDecayThr.coerceIn(0.05f, 1f)
        val inDecay = battBoxDecayOn && now < battBoxDecayUntil
        battBoxDecayActive = inDecay || (battBoxDecayOn && be >= dThr)
        battBoxDecayOut = if (battBoxDecayActive) {
            val hold = if (inDecay) {
                ((battBoxDecayUntil - now).toFloat() / battBoxDecayMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
            } else {
                (((be - dThr) / (1f - dThr).coerceAtLeast(0.05f))).coerceIn(0f, 1f)
            }
            (hold * battBoxDecayLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Texture threshold
        val bbTexThr = battBoxTexThr.coerceIn(0.05f, 1f)
        battBoxTexActive = battBoxTexOn && be >= bbTexThr
        battBoxTexOut = if (battBoxTexActive) {
            (((be - bbTexThr) / (1f - bbTexThr).coerceAtLeast(0.05f)) * battBoxTexLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Colour threshold
        val bbColThr = battBoxColorThr.coerceIn(0.05f, 1f)
        battBoxColorActive = battBoxColorOn && be >= bbColThr
        battBoxColorOut = if (battBoxColorActive) {
            val col = (battBoxColorR + battBoxColorG + battBoxColorB) / 3f
            (((be - bbColThr) / (1f - bbColThr).coerceAtLeast(0.05f)) * col.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Visual
        val vThr = battBoxVisThr.coerceIn(0.05f, 1f)
        battBoxVisActive = battBoxVisOn && be >= vThr
        battBoxVisOut = if (battBoxVisActive) {
            (((be - vThr) / (1f - vThr).coerceAtLeast(0.05f)) * battBoxVisLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Charge level — low charge trips protection harder
        val pct = battBoxChargePct.coerceIn(0f, 1f)
        val cThrPct = battBoxChargeThr.coerceIn(0.05f, 0.95f)
        battBoxChargeLow = battBoxChargeOn && pct <= cThrPct
        battBoxChargeActive = battBoxChargeLow
        battBoxChargeOut = if (battBoxChargeActive) {
            val depth = ((cThrPct - pct) / cThrPct.coerceAtLeast(0.05f)).coerceIn(0f, 1f)
            (depth * battBoxChargeLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (battBoxChargeActive) {
            battBoxOut = maxOf(battBoxOut, battBoxChargeOut * 0.85f)
            if (battBoxOn) battBoxActive = true
        }

        // Charge decay protection — hold after low-charge trip
        val nowChg = System.currentTimeMillis()
        if (battBoxChargeActive && battBoxChargeDecayOn) {
            battBoxChargeDecayUntil = nowChg + battBoxChargeDecayMs.coerceIn(50L, 5000L)
        }
        val cdThr = battBoxChargeDecayThr.coerceIn(0.05f, 1f)
        val inChgDecay = battBoxChargeDecayOn && nowChg < battBoxChargeDecayUntil
        battBoxChargeDecayActive = inChgDecay || (battBoxChargeDecayOn && battBoxChargeLow)
        battBoxChargeDecayOut = if (battBoxChargeDecayActive) {
            val hold = if (inChgDecay) {
                ((battBoxChargeDecayUntil - nowChg).toFloat() /
                    battBoxChargeDecayMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
            } else {
                (battBoxChargeOut * (1f - pct)).coerceIn(0f, 1f)
            }
            (hold * battBoxChargeDecayLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Fully charged threshold
        val fThr = battBoxFullThr.coerceIn(0.50f, 1f)
        battBoxFullActive = battBoxFullOn && pct >= fThr
        battBoxFullOut = if (battBoxFullActive) {
            (((pct - fThr) / (1f - fThr).coerceAtLeast(0.05f)) * battBoxFullLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        val bst = bodySurfaceThr.coerceIn(0.05f, 1f)
        bodySurfaceActive = bodySurfaceOn && energy >= bst
        bodySurfaceOut = if (bodySurfaceActive) {
            (((energy - bst) / (1f - bst).coerceAtLeast(0.05f)) * bodySurfaceLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        fun gatedOut(on: Boolean, thr: Float, lv: Float): Pair<Boolean, Float> {
            val t = thr.coerceIn(0.05f, 1f)
            val act = on && energy >= t
            val o = if (act) {
                (((energy - t) / (1f - t).coerceAtLeast(0.05f)) * lv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
            } else 0f
            return act to o
        }
        val (asAct, asOut) = gatedOut(bodyAtmoSurfOn, bodyAtmoSurfThr, bodyAtmoSurfLv)
        bodyAtmoSurfActive = asAct
        bodyAtmoSurfOut = asOut
        bodyAtmoSpikeActive = bodyAtmoSpikeOn && energy >= bodyAtmoSpikeThr.coerceIn(0.05f, 1f)

        val motionE = maxOf(energy, maxOf(pitchLr, pitchUd))
        val (mvAct, mvOut) = gatedOut(bodyMoveOn, bodyMoveThr, bodyMoveLv)
        bodyMoveActive = mvAct && motionE >= bodyMoveThr.coerceIn(0.05f, 1f)
        bodyMoveOut = if (bodyMoveActive) mvOut else 0f
        val (spAct, spOut) = gatedOut(bodySpeedOn, bodySpeedThr, bodySpeedLv)
        bodySpeedActive = spAct
        bodySpeedOut = spOut
        val (wvAct, wvOut) = gatedOut(bodyWaveOn, bodyWaveThr, bodyWaveLv)
        bodyWaveActive = wvAct
        bodyWaveOut = wvOut

        val mLo = bodyMotionBipNeg.coerceIn(-120f, 0f).toDouble()
        val mHi = bodyMotionBipPos.coerceIn(0f, 120f).toDouble()
        bodyMotionBipHit = bodyMotionBipOn && (db <= mLo || db >= mHi)

        var d = 0f
        if (overThr) d = maxOf(d, 0.40f + ambientLv * 0.45f)
        if (spikeActive) d = maxOf(d, 0.50f + spikeLv * 0.40f)
        if (intensityActive) d = maxOf(d, 0.30f + intensityLv * 0.45f)
        if (visualBlockActive) d = maxOf(d, 0.45f + visualBlockLv * 0.50f)
        if (pitchLrActive) d = maxOf(d, 0.35f + pitchLrLv * 0.40f)
        if (pitchUdActive) d = maxOf(d, 0.35f + pitchUdLv * 0.40f)
        if (battBoxTrackActive) d = maxOf(d, 0.40f + battBoxTrackLv * 0.35f)
        if (battBoxIntActive) d = maxOf(d, 0.45f + battBoxIntLv * 0.40f)
        if (battBoxActive) d = maxOf(d, 0.36f + battBoxOut * 0.38f)
        if (battBoxDecayActive) d = maxOf(d, 0.32f + battBoxDecayOut * 0.36f)
        if (battBoxTexActive) d = maxOf(d, 0.28f + battBoxTexOut * 0.30f)
        if (battBoxColorActive) d = maxOf(d, 0.26f + battBoxColorOut * 0.28f)
        if (battBoxVisActive) d = maxOf(d, 0.30f + battBoxVisOut * 0.34f)
        if (battBoxChargeActive) d = maxOf(d, 0.34f + battBoxChargeOut * 0.40f)
        if (battBoxChargeDecayActive) d = maxOf(d, 0.30f + battBoxChargeDecayOut * 0.36f)
        if (battBoxFullActive) d = maxOf(d, 0.18f + battBoxFullOut * 0.22f)
        if (bodySurfaceActive) d = maxOf(d, 0.35f + bodySurfaceOut * 0.45f)
        if (bodyAtmoSurfActive) d = maxOf(d, 0.32f + bodyAtmoSurfOut * 0.40f)
        if (bodyAtmoSpikeActive) d = maxOf(d, 0.48f + bodyAtmoSpikeLv * 0.42f)
        if (bodyMoveActive) d = maxOf(d, 0.30f + bodyMoveOut * 0.38f)
        if (bodySpeedActive) d = maxOf(d, 0.30f + bodySpeedOut * 0.38f)
        if (bodyWaveActive) d = maxOf(d, 0.30f + bodyWaveOut * 0.38f)
        val bwsThr = bodyWaveSpareThr.coerceIn(0.05f, 1f)
        bodyWaveSpareActive = bodyWaveSpareOn && energy >= bwsThr
        bodyWaveSpareOut = if (bodyWaveSpareActive) {
            (((energy - bwsThr) / (1f - bwsThr).coerceAtLeast(0.05f)) * bodyWaveSpareLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (bodyWaveSpareActive) d = maxOf(d, 0.28f + bodyWaveSpareOut * 0.36f)
        if (bodyMotionBipHit) d = maxOf(d, 0.42f)

        // Screen echo: decayed residual of energy
        echoX.rawScreen = rawComplete
        // the live microphone joins the screen echo input; RAW COMPLETE = no decay at all
        val echoIn = echoX.echoInput(energy)
        val echoMix = if (echoX.isRaw()) echoIn else echoIn * 0.55f + echoPrev * 0.45f
        echoPrev = echoMix
        val eThr = echoThr.coerceIn(0.05f, 1f)
        echoActive = echoOn && echoMix >= eThr
        echoOut = if (echoActive) {
            (((echoMix - eThr) / (1f - eThr).coerceAtLeast(0.05f)) * echoLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        echoMoveActive = echoMoveOn && echoActive && echoMix >= echoMoveThr.coerceIn(0.05f, 1f)
        echoSpeedActive = echoSpeedOn && echoActive && echoMix >= echoSpeedThr.coerceIn(0.05f, 1f)
        echoWaveActive = echoWaveOn && echoActive && echoMix >= echoWaveThr.coerceIn(0.05f, 1f)
        val eaThr = echoAtmoThr.coerceIn(0.05f, 1f)
        echoAtmoActive = echoAtmoOn && echoMix >= eaThr
        echoAtmoOut = if (echoAtmoActive) {
            (((echoMix - eaThr) / (1f - eaThr).coerceAtLeast(0.05f)) * echoAtmoLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (echoActive) d = maxOf(d, 0.28f + echoOut * 0.40f)
        if (echoMoveActive) d = maxOf(d, 0.25f + echoMoveLv * 0.30f)
        if (echoSpeedActive) d = maxOf(d, 0.25f + echoSpeedLv * 0.30f)
        if (echoWaveActive) d = maxOf(d, 0.25f + echoWaveLv * 0.30f)
        if (echoAtmoActive) d = maxOf(d, 0.30f + echoAtmoOut * 0.38f)
        val ewsThr = echoWaveSpareThr.coerceIn(0.05f, 1f)
        echoWaveSpareActive = echoWaveSpareOn && echoMix >= ewsThr
        echoWaveSpareOut = if (echoWaveSpareActive) {
            (((echoMix - ewsThr) / (1f - ewsThr).coerceAtLeast(0.05f)) * echoWaveSpareLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (echoWaveSpareActive) d = maxOf(d, 0.26f + echoWaveSpareOut * 0.34f)
        // echo centroid · vertical + live microphone echo · mic centroid · vertical
        d = maxOf(d, echoX.tick(echoMix, echoActive || echoX.isRaw()))

        // Screen tracking + move/speed/wave + atmosphere
        val trkThr = trackThr.coerceIn(0.05f, 1f)
        trackActive = trackOn && energy >= trkThr
        trackOut = if (trackActive) {
            (((energy - trkThr) / (1f - trkThr).coerceAtLeast(0.05f)) * trackLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        trackMoveActive = trackMoveOn && trackActive && energy >= trackMoveThr.coerceIn(0.05f, 1f)
        trackSpeedActive = trackSpeedOn && trackActive && energy >= trackSpeedThr.coerceIn(0.05f, 1f)
        trackWaveActive = trackWaveOn && trackActive && energy >= trackWaveThr.coerceIn(0.05f, 1f)
        val taThr = trackAtmoThr.coerceIn(0.05f, 1f)
        trackAtmoActive = trackAtmoOn && energy >= taThr
        trackAtmoOut = if (trackAtmoActive) {
            (((energy - taThr) / (1f - taThr).coerceAtLeast(0.05f)) * trackAtmoLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (trackActive) d = maxOf(d, 0.30f + trackOut * 0.40f)
        if (trackMoveActive) d = maxOf(d, 0.24f + trackMoveLv * 0.28f)
        if (trackSpeedActive) d = maxOf(d, 0.24f + trackSpeedLv * 0.28f)
        if (trackWaveActive) d = maxOf(d, 0.24f + trackWaveLv * 0.28f)
        if (trackAtmoActive) d = maxOf(d, 0.30f + trackAtmoOut * 0.36f)
        val twsThr = trackWaveSpareThr.coerceIn(0.05f, 1f)
        trackWaveSpareActive = trackWaveSpareOn && energy >= twsThr
        trackWaveSpareOut = if (trackWaveSpareActive) {
            (((energy - twsThr) / (1f - twsThr).coerceAtLeast(0.05f)) * trackWaveSpareLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (trackWaveSpareActive) d = maxOf(d, 0.26f + trackWaveSpareOut * 0.34f)

        // Enemy body + motion + atmosphere (local dampen only)
        val ebThr = enemyBodySurfThr.coerceIn(0.05f, 1f)
        enemyBodySurfActive = enemyBodySurfOn && energy >= ebThr
        enemyBodySurfOut = if (enemyBodySurfActive) {
            (((energy - ebThr) / (1f - ebThr).coerceAtLeast(0.05f)) * enemyBodySurfLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        enemyMoveActive = enemyMoveOn && enemyBodySurfActive && energy >= enemyMoveThr.coerceIn(0.05f, 1f)
        enemySpeedActive = enemySpeedOn && enemyBodySurfActive && energy >= enemySpeedThr.coerceIn(0.05f, 1f)
        enemyWaveActive = enemyWaveOn && enemyBodySurfActive && energy >= enemyWaveThr.coerceIn(0.05f, 1f)
        val ea2 = enemyAtmoThr.coerceIn(0.05f, 1f)
        enemyAtmoActive = enemyAtmoOn && energy >= ea2
        enemyAtmoOut = if (enemyAtmoActive) {
            (((energy - ea2) / (1f - ea2).coerceAtLeast(0.05f)) * enemyAtmoLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (enemyBodySurfActive) d = maxOf(d, 0.38f + enemyBodySurfOut * 0.42f)
        if (enemyMoveActive) d = maxOf(d, 0.26f + enemyMoveLv * 0.30f)
        if (enemySpeedActive) d = maxOf(d, 0.26f + enemySpeedLv * 0.30f)
        if (enemyWaveActive) d = maxOf(d, 0.26f + enemyWaveLv * 0.30f)
        if (enemyAtmoActive) d = maxOf(d, 0.32f + enemyAtmoOut * 0.38f)
        val enwsThr = enemyWaveSpareThr.coerceIn(0.05f, 1f)
        enemyWaveSpareActive = enemyWaveSpareOn && energy >= enwsThr
        enemyWaveSpareOut = if (enemyWaveSpareActive) {
            (((energy - enwsThr) / (1f - enwsThr).coerceAtLeast(0.05f)) * enemyWaveSpareLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (enemyWaveSpareActive) d = maxOf(d, 0.28f + enemyWaveSpareOut * 0.36f)

        // Communication surface + bipolar + motion + atmosphere
        val cLo = commBipNeg.coerceIn(-120f, 0f).toDouble()
        val cHi = commBipPos.coerceIn(0f, 120f).toDouble()
        commBipHit = commBipOn && (db <= cLo || db >= cHi)
        val commThrV = commSurfThr.coerceIn(0.05f, 1f)
        commSurfActive = commSurfOn && (energy >= commThrV || commBipHit)
        commSurfOut = if (commSurfActive) {
            val base = if (energy >= commThrV) {
                (((energy - commThrV) / (1f - commThrV).coerceAtLeast(0.05f)) * commSurfLv.coerceIn(0f, 1f))
            } else 0f
            (base + if (commBipHit) 0.25f else 0f).coerceIn(0f, 1f)
        } else 0f
        commMoveActive = commMoveOn && commSurfActive && energy >= commMoveThr.coerceIn(0.05f, 1f)
        commSpeedActive = commSpeedOn && commSurfActive && energy >= commSpeedThr.coerceIn(0.05f, 1f)
        commWaveActive = commWaveOn && commSurfActive && energy >= commWaveThr.coerceIn(0.05f, 1f)
        val caThr = commAtmoThr.coerceIn(0.05f, 1f)
        commAtmoActive = commAtmoOn && energy >= caThr
        commAtmoOut = if (commAtmoActive) {
            (((energy - caThr) / (1f - caThr).coerceAtLeast(0.05f)) * commAtmoLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (commSurfActive) d = maxOf(d, 0.34f + commSurfOut * 0.40f)
        if (commMoveActive) d = maxOf(d, 0.24f + commMoveLv * 0.28f)
        if (commSpeedActive) d = maxOf(d, 0.24f + commSpeedLv * 0.28f)
        if (commWaveActive) d = maxOf(d, 0.24f + commWaveLv * 0.28f)
        if (commAtmoActive) d = maxOf(d, 0.30f + commAtmoOut * 0.36f)
        val cwsThr = commWaveSpareThr.coerceIn(0.05f, 1f)
        commWaveSpareActive = commWaveSpareOn && energy >= cwsThr
        commWaveSpareOut = if (commWaveSpareActive) {
            (((energy - cwsThr) / (1f - cwsThr).coerceAtLeast(0.05f)) * commWaveSpareLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (commWaveSpareActive) d = maxOf(d, 0.26f + commWaveSpareOut * 0.34f)

        // Screen 3D humanoid body-84 surface (energy + optional body84 link)
        val b84e = maxOf(energy, body84Link.coerceIn(0f, 1f))
        val b84Thr = body84SurfThr.coerceIn(0.05f, 1f)
        body84SurfActive = body84SurfOn && b84e >= b84Thr
        body84SurfOut = if (body84SurfActive) {
            (((b84e - b84Thr) / (1f - b84Thr).coerceAtLeast(0.05f)) * body84SurfLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (body84SurfActive) d = maxOf(d, 0.36f + body84SurfOut * 0.42f)

        // Atmospheric intensity / intention gate + bipolar
        val aiLo = atmoIntBipNeg.coerceIn(-120f, 0f).toDouble()
        val aiHi = atmoIntBipPos.coerceIn(0f, 120f).toDouble()
        atmoIntBipHit = atmoIntBipOn && (db <= aiLo || db >= aiHi)
        val aiThr = atmoIntGateThr.coerceIn(0.05f, 1f)
        atmoIntGateActive = atmoIntGateOn && (energy >= aiThr || atmoIntBipHit)
        atmoIntGateOut = if (atmoIntGateActive) {
            val base = if (energy >= aiThr) {
                (((energy - aiThr) / (1f - aiThr).coerceAtLeast(0.05f)) * atmoIntGateLv.coerceIn(0f, 1f))
            } else 0f
            (base + if (atmoIntBipHit) 0.22f else 0f).coerceIn(0f, 1f)
        } else 0f
        if (atmoIntGateActive) d = maxOf(d, 0.38f + atmoIntGateOut * 0.44f)

        // Visualisation gate + bipolar
        val vgLo = visualBipNeg.coerceIn(-120f, 0f).toDouble()
        val vgHi = visualBipPos.coerceIn(0f, 120f).toDouble()
        visualBipHit = visualBipOn && (db <= vgLo || db >= vgHi)
        val vgThr = visualGateThr.coerceIn(0.05f, 1f)
        visualGateActive = visualGateOn && (energy >= vgThr || visualBipHit)
        visualGateOut = if (visualGateActive) {
            val base = if (energy >= vgThr) {
                (((energy - vgThr) / (1f - vgThr).coerceAtLeast(0.05f)) * visualGateLv.coerceIn(0f, 1f))
            } else 0f
            (base + if (visualBipHit) 0.22f else 0f).coerceIn(0f, 1f)
        } else 0f
        if (visualGateActive) d = maxOf(d, 0.40f + visualGateOut * 0.46f)

        // Imagination gate + bipolar
        val iLo = imagineBipNeg.coerceIn(-120f, 0f).toDouble()
        val iHi = imagineBipPos.coerceIn(0f, 120f).toDouble()
        imagineBipHit = imagineBipOn && (db <= iLo || db >= iHi)
        val igThr = imagineGateThr.coerceIn(0.05f, 1f)
        imagineGateActive = imagineGateOn && (energy >= igThr || imagineBipHit)
        imagineGateOut = if (imagineGateActive) {
            val base = if (energy >= igThr) {
                (((energy - igThr) / (1f - igThr).coerceAtLeast(0.05f)) * imagineGateLv.coerceIn(0f, 1f))
            } else 0f
            (base + if (imagineBipHit) 0.22f else 0f).coerceIn(0f, 1f)
        } else 0f
        if (imagineGateActive) d = maxOf(d, 0.36f + imagineGateOut * 0.42f)

        // Animation gate + bipolar
        val aLo = animBipNeg.coerceIn(-120f, 0f).toDouble()
        val aHi = animBipPos.coerceIn(0f, 120f).toDouble()
        animBipHit = animBipOn && (db <= aLo || db >= aHi)
        val agThr = animGateThr.coerceIn(0.05f, 1f)
        animGateActive = animGateOn && (energy >= agThr || animBipHit)
        animGateOut = if (animGateActive) {
            val base = if (energy >= agThr) {
                (((energy - agThr) / (1f - agThr).coerceAtLeast(0.05f)) * animGateLv.coerceIn(0f, 1f))
            } else 0f
            (base + if (animBipHit) 0.22f else 0f).coerceIn(0f, 1f)
        } else 0f
        if (animGateActive) d = maxOf(d, 0.34f + animGateOut * 0.40f)

        // visuals mode scales dampen
        val modeMul = when (visualsMode.coerceIn(0, 3)) {
            0 -> 0.55f
            1 -> 1f
            2 -> 1.25f
            else -> 1.45f
        }
        dampen = (d * modeMul).coerceIn(0f, 0.98f)
    }

    
    /** Domination Hz: map dominant frequency to 0..1 (20Hz..8kHz log), gate by thr, scale by level. */
    fun processDomination(domHz: Float) {
        if (!dominationOn && !rawComplete) {
            dominationActive = false; dominationOut = 0f; dominationNorm = 0f
            if (domHz > 1f) dominationHz = domHz
            return
        }
        val hz = if (domHz > 1f) domHz else dominationHzFeed
        dominationHz = hz.coerceIn(0f, 20000f)
        val fMin = dominationHzMin.coerceIn(20f, 19000f)
        val fMax = dominationHzMax.coerceIn(fMin + 50f, 20000f)
        val n = if (hz <= fMin) 0f else {
            val logMin = kotlin.math.ln(fMin.toDouble())
            val logMax = kotlin.math.ln(fMax.toDouble())
            ((kotlin.math.ln(hz.toDouble().coerceIn(fMin.toDouble(), fMax.toDouble())) - logMin) / (logMax - logMin)).toFloat().coerceIn(0f, 1f)
        }
        dominationNorm = n
        val thr = dominationThr.coerceIn(0.05f, 0.98f)
        val lv = dominationLv.coerceIn(0f, 1f)
        if (rawComplete || dominationRaw) {
            dominationOut = n
            dominationActive = n > 0.01f
        } else {
            dominationActive = n >= thr
            dominationOut = if (dominationActive) {
                (((n - thr) / (1f - thr).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f)
            } else 0f
        }
    }

    fun statusLine(): String {
        val st = if (!enabled) "off" else if (overThr) "OVER" else "ok"
        val tags = buildList {
            if (spikeActive) add("SPIKE")
            if (intensityActive) add("INT")
            if (visualBlockActive) add("V-BLOCK")
            if (pitchLrActive) add("PITCH-LR")
            if (pitchUdActive) add("PITCH-UD")
            if (battBoxTrackActive) add("BATT-BOX-TRK")
            if (battBoxIntActive) add("BATT-BOX-INT")
            if (battBoxActive) add("BATT-BOX")
            if (battBoxDecayActive) add("BATT-DEC")
            if (battBoxTexActive) add("BATT-TEX")
            if (battBoxColorActive) add("BATT-COL")
            if (battBoxVisActive) add("BATT-VIS")
            if (battBoxChargeActive) add("BATT-CHG")
            if (battBoxChargeDecayActive) add("BATT-CHG-DEC")
            if (battBoxFullActive) add("BATT-FULL")
            if (bodySurfaceActive) add("BODY-SURF")
            if (bodyAtmoSurfActive) add("BODY-ATMO")
            if (bodyAtmoSpikeActive) add("BODY-ATMO-SPIKE")
            if (bodyMoveActive) add("MOVE")
            if (bodySpeedActive) add("SPEED")
            if (bodyWaveActive) add("WAVE")
            if (bodyWaveSpareActive) add("BODY-WSP")
            if (bodyMotionBipHit) add("MOTION-BIP")
            if (echoActive) add("ECHO")
            if (echoMoveActive) add("ECHO-MV")
            if (echoSpeedActive) add("ECHO-SP")
            if (echoWaveActive) add("ECHO-WV")
            if (echoAtmoActive) add("ECHO-ATMO")
            if (echoWaveSpareActive) add("ECHO-WSP")
            if (trackActive) add("TRACK")
            if (trackMoveActive) add("TRK-MV")
            if (trackSpeedActive) add("TRK-SP")
            if (trackWaveActive) add("TRK-WV")
            if (trackAtmoActive) add("TRK-ATMO")
            if (trackWaveSpareActive) add("TRK-WSP")
            if (enemyBodySurfActive) add("E-BODY")
            if (enemyMoveActive) add("E-MV")
            if (enemySpeedActive) add("E-SP")
            if (enemyWaveActive) add("E-WV")
            if (enemyAtmoActive) add("E-ATMO")
            if (enemyWaveSpareActive) add("E-WSP")
            if (commSurfActive) add("COMM")
            if (commBipHit) add("COMM-BIP")
            if (commMoveActive) add("C-MV")
            if (commSpeedActive) add("C-SP")
            if (commWaveActive) add("C-WV")
            if (commAtmoActive) add("C-ATMO")
            if (commWaveSpareActive) add("C-WSP")
            if (body84SurfActive) add("B84-SURF")
            if (atmoIntGateActive) add("ATMO-INT")
            if (atmoIntBipHit) add("AI-BIP")
            if (visualGateActive) add("VIS-GATE")
            if (visualBipHit) add("VIS-BIP")
            if (imagineGateActive) add("IMAGINE")
            if (imagineBipHit) add("IMG-BIP")
            if (animGateActive) add("ANIM")
            if (animBipHit) add("ANIM-BIP")
            if (rawComplete) add("RAW")
            if (centroidActive) add("SCR-CEN")
            if (verticalActive) add("SCR-VERT")
            if (dominationActive) add("SCR-DOM")
            if (echoX.screenCen.active) add("ECHO-CEN")
            if (echoX.screenVer.active) add("ECHO-VERT")
            if (echoX.micEcho.active) add("MIC-ECHO")
            if (echoX.micCen.active) add("MIC-CEN")
            if (echoX.micVer.active) add("MIC-VERT")
            if (isEmpty()) add("-")
        }.joinToString("+")
        val mode = when (visualsMode) { 0 -> "SOFT"; 1 -> "NORM"; 2 -> "HARD"; else -> "BLOCK" }
        return "SCR-AMB lv=${(ambientLv*100).toInt()}% bip=${"%.0f".format(bipNeg)}/+" +
            "${"%.0f".format(bipPos)} dB · $st $tags mode=$mode " +
            "IMG=${(imagineGateOut*100).toInt()}% ANIM=${(animGateOut*100).toInt()}% " +
            "cen=${(centroidOut*100).toInt()}% vert=${(verticalOut*100).toInt()}% dom=${(dominationOut*100).toInt()}% (${dominationHz.toInt()}Hz) damp=${(dampen*100).toInt()}%"
    }
    fun apply(v: VisualShieldView?) {
        val vv = v ?: return
        try {
            vv.finalProtectionMain.screenAmbOut = maxOf(vv.finalProtectionMain.screenAmbOut, try { centroidOut } catch (_: Throwable) { 0f })
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, try { centroidOut } catch (_: Throwable) { 0f } * 0.25f)
        } catch (_: Throwable) {}
    }

}
