package com.mizan

/**
 * 3D model body: my body interacts only with AI.
 * Our model thr vs Enemies model thr · enemy model motion thr · AR motion thr.
 * Inside ↔ outside interconnected · atomspare + wavespare on 3D body screens.
 * RAW COMPLETE.
 */
class Body3dModelInteractBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // My body ↔ AI only
    @Volatile var myBodyAiOnly = true
    @Volatile var blockNonAiInteract = true

    // Our model
    @Volatile var ourModelOn = true
    @Volatile var ourModelThr = 0.28f
    @Volatile var ourModelLv = 0.75f
    @Volatile var ourModelOut = 0f
    @Volatile var ourModelMotionThr = 0.30f
    @Volatile var ourModelMotionOut = 0f

    // Enemies model
    @Volatile var enemyModelOn = true
    @Volatile var enemyModelThr = 0.40f
    @Volatile var enemyModelLv = 0.70f
    @Volatile var enemyModelOut = 0f
    @Volatile var enemyModelMotionThr = 0.42f
    @Volatile var enemyModelMotionOut = 0f
    @Volatile var enemyTransCommThr = 0.38f
    @Volatile var enemyTransCommOut = 0f

    // AR motion threshold
    @Volatile var arMotionOn = true
    @Volatile var arMotionThr = 0.35f
    @Volatile var arMotionLv = 0.70f
    @Volatile var arMotionOut = 0f

    // Inside ↔ outside body interconnect
    @Volatile var interconnectOn = true
    @Volatile var interconnectStrength = 0.80f
    @Volatile var insideOut = 0f
    @Volatile var outsideOut = 0f

    // Atomspare + wavespare on 3D body screens
    @Volatile var atomSpareOn = true
    @Volatile var atomSpareThr = 0.30f
    @Volatile var atomSpareLv = 0.70f
    @Volatile var atomSpareOut = 0f
    @Volatile var waveSpareOn = true
    @Volatile var waveSpareThr = 0.30f
    @Volatile var waveSpareLv = 0.70f
    @Volatile var waveSpareOut = 0f

    @Volatile var status = "3D MODEL BODY idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float, drive: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv * drive).coerceIn(0f, 1f)
        val t = (thr * drive).coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv * drive).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        mic: Float,
        modelDrive: Float,
        enemyThreat: Float,
        arMotionEnergy: Float = 0f
    ) {
        if (!enabled) {
            ourModelOut = 0f; enemyModelOut = 0f; arMotionOut = 0f
            status = "3D MODEL BODY OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val drive = 0.25f + 0.75f * modelDrive.coerceIn(0f, 1f)
        val enemy = enemyThreat.coerceIn(0f, 1f)

        // Our model (AI path when myBodyAiOnly)
        val ourE = if (myBodyAiOnly) e * (0.85f + 0.15f * drive) else e
        ourModelOut = lane(ourModelOn, ourModelThr, ourModelLv, ourE, drive)
        ourModelMotionOut = lane(ourModelOn, ourModelMotionThr, ourModelLv, ourE * 1.02f, drive)

        // Enemy model + trans-comm
        enemyModelOut = lane(enemyModelOn, enemyModelThr, enemyModelLv, enemy * 1.05f, drive)
        enemyModelMotionOut = lane(enemyModelOn, enemyModelMotionThr, enemyModelLv, enemy, drive)
        enemyTransCommOut = lane(enemyModelOn, enemyTransCommThr, enemyModelLv, enemy * 1.08f, drive)

        // AR motion
        arMotionOut = lane(arMotionOn, arMotionThr, arMotionLv, maxOf(arMotionEnergy, e * 0.5f), drive)

        // Inside / outside interconnect
        outsideOut = ourModelOut
        insideOut = if (interconnectOn) {
            maxOf(ourModelOut * interconnectStrength.coerceIn(0f, 1.5f), ourModelMotionOut * 0.7f)
        } else ourModelOut * 0.5f

        atomSpareOut = lane(atomSpareOn, atomSpareThr, atomSpareLv, maxOf(ourModelOut, insideOut), drive)
        waveSpareOut = lane(waveSpareOn, waveSpareThr, waveSpareLv, maxOf(ourModelOut, outsideOut, ourModelMotionOut), drive)

        status =
            "OUR mdl=${(ourModelOut*100).toInt()}% mot=${(ourModelMotionOut*100).toInt()}% · " +
            "ENEMY mdl=${(enemyModelOut*100).toInt()}% mot=${(enemyModelMotionOut*100).toInt()}% tx=${(enemyTransCommOut*100).toInt()}% · " +
            "AR mot=${(arMotionOut*100).toInt()}% · in/out ${(insideOut*100).toInt()}/${(outsideOut*100).toInt()}% · " +
            "atom=${(atomSpareOut*100).toInt()} wave=${(waveSpareOut*100).toInt()}%" +
            (if (myBodyAiOnly) " · AI-ONLY" else "") +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(shield: VisualShieldView, sb: SoundBankGuard) {
        if (!enabled) return

        // 3D anatomy inside/outside
        if (shield.anatomy3d.enabled) {
            shield.anatomy3d.inside.level = maxOf(shield.anatomy3d.inside.level, insideOut)
            shield.anatomy3d.outside.level = maxOf(shield.anatomy3d.outside.level, outsideOut)
            shield.anatomy3d.atmosphere = maxOf(shield.anatomy3d.atmosphere, atomSpareOut)
        }

        // Skin body screens — atomspare / wavespare
        val at = atomSpareOut
        val wv = waveSpareOut
        shield.skinAll.atmosphere = maxOf(shield.skinAll.atmosphere, at)
        shield.skinAll.waveSpare = maxOf(shield.skinAll.waveSpare, wv)
        shield.skinAll.ambient = maxOf(shield.skinAll.ambient, ourModelOut * 0.6f)
        listOf(
            shield.skinHead, shield.skinChest, shield.skinAbdomen, shield.skinBack,
            shield.skinArmL, shield.skinArmR, shield.skinLegL, shield.skinLegR
        ).forEach { r ->
            r.atmosphere = maxOf(r.atmosphere, at * 0.9f)
            r.waveSpare = maxOf(r.waveSpare, wv * 0.9f)
            if (myBodyAiOnly) {
                // only our model energy on body, not enemy
                r.ambient = maxOf(r.ambient, ourModelOut * 0.5f)
            }
        }

        // Full model groups feed from our model
        if (shield.fullModel3d.enabled) {
            shield.fullModel3d.fullBodyOut = maxOf(shield.fullModel3d.fullBodyOut, ourModelOut)
            shield.fullModel3d.headGroupOut = maxOf(shield.fullModel3d.headGroupOut, ourModelOut * 0.95f)
        }

        // Enemy model / motion / TX — keep off my body when AI-only or isolation
        if (myBodyAiOnly || blockNonAiInteract) {
            val k = (1f - enemyModelOut * 0.9f).coerceIn(0.05f, 1f)
            val km = (1f - enemyModelMotionOut * 0.9f).coerceIn(0.05f, 1f)
            val kt = (1f - enemyTransCommOut * 0.9f).coerceIn(0.05f, 1f)
            sb.enemyBodyOut *= minOf(k, km, kt)
            sb.enemyBodyMove *= km
            sb.enemyBodySpeed *= km
            sb.enemyBodyWave *= km
            sb.micEnemyOut *= kt
            sb.enemyCommBlockOut = maxOf(sb.enemyCommBlockOut, enemyTransCommOut)
        }

        // AR motion couples to measure board quality path via status only (session owns AR)
        if (arMotionOut > 0.05f && shield.arMeasure.sessionRunning) {
            // slight intensity bias when AR motion above thr
            shield.arMeasure.intensity = maxOf(shield.arMeasure.intensity, 0.5f + arMotionOut * 0.4f)
        }
    }
}
