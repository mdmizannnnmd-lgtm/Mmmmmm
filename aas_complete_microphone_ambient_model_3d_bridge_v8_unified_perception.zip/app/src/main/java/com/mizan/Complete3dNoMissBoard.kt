package com.mizan

/**
 * Complete 3D — no missing layers / systems / sides / models.
 * Forces full human 3D stack ON every frame when enabled. RAW COMPLETE.
 */
class Complete3dNoMissBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    @Volatile var forceAllLayers = true
    @Volatile var forceBrainStructures = true
    @Volatile var forceBodySystems = true
    @Volatile var forceSides = true
    @Volatile var force84 = true
    @Volatile var forceSkinInOut = true
    @Volatile var forceShell = true
    @Volatile var forcePoseSegObb = true
    @Volatile var forceEyes = true
    @Volatile var forceAtomspare = true
    @Volatile var forceContinuousSkin = true
    @Volatile var forceAllAmbientBoards = true

    @Volatile var completeness = 0f
    @Volatile var layersOn = 0
    @Volatile var status = "3D NO-MISS idle"

    fun tick() {
        if (!enabled) {
            status = "3D NO-MISS OFF"
            return
        }
        // completeness filled in apply after probing
        status =
            "3D NO-MISS ${(completeness*100).toInt()}% layers=$layersOn/7 · " +
            "brain·body·sides·84·skin·shell·pose/seg/obb·eyes·atom" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        var score = 0
        var max = 0

        // 7 anatomy layers
        max += 7
        try {
            val a = v.anatomy3d
            a.enabled = true
            a.enableCompleteHumanLayers()
            if (forceAllLayers || rawComplete) {
                for (i in a.layerOn.indices) {
                    a.layerOn[i] = true
                    if (a.layerLevel[i] < 0.7f) a.layerLevel[i] = 0.9f
                }
                a.gpuOn = true
                a.poseRigOn = true
                a.setRawAll(true)
                a.layerOn[0] = true
                a.layerLevel[0] = maxOf(a.layerLevel[0], 0.95f)
                try { a.outside.level = maxOf(a.outside.level, 0.9f) } catch (_: Throwable) {}

            }
            layersOn = a.layerOn.count { it }
            score += layersOn
        } catch (_: Throwable) {}

        // Brain + body systems from frequency board
        max += 2
        try {
            val f = v.bodyFreqRegen
            f.enabled = true
            if (forceBrainStructures) {
                f.brainStructuresOn = true
                f.brainDeltaOn = true; f.brainThetaOn = true; f.brainAlphaOn = true
                f.brainBetaOn = true; f.brainGammaOn = true; f.brainSmrOn = true
                f.neuronRegenOn = true
            }
            if (forceBodySystems) {
                f.bodySystemsOn = true
                f.repairOn = true; f.healingOn = true; f.regenOn = true; f.ownRegenOn = true
            }
            score += 2
        } catch (_: Throwable) {}

        // Sides front/back/L/R/up/down
        max += 1
        try {
            val s = v.frontSideAmbient
            s.enabled = true
            if (forceSides || rawComplete) {
                s.eyeFrontOn = true; s.eyeBackOn = true
                s.bodyFrontOn = true; s.bodyBackOn = true
                s.bodyLeftOn = true; s.bodyRightOn = true
                s.bodyUpOn = true; s.bodyDownOn = true
            }
            score += 1
        } catch (_: Throwable) {}

        // 84 full human
        max += 1
        try {
            val h = v.body84FullHuman
            h.enabled = true
            if (force84 || rawComplete) {
                h.outsideOn = true; h.insideOn = true
                h.poseOn = true; h.segmentOn = true; h.obbOn = true
            }
            score += 1
        } catch (_: Throwable) {}

        // Skin in/out
        max += 1
        try {
            val sk = v.skinAtomspare
            sk.enabled = true
            if (forceSkinInOut || rawComplete) {
                sk.atomSpareOn = true; sk.skinOutsideOn = true; sk.skinInsideOn = true
            }
            score += 1
        } catch (_: Throwable) {}

        // Shell
        max += 1
        try {
            val sh = v.anatomyShell
            sh.enabled = true
            if (forceShell || rawComplete) {
                sh.atomSpareShellOn = true
                sh.enemyCannotBreakOut = true
            }
            score += 1
        } catch (_: Throwable) {}

        // Pose / seg eye body
        max += 1
        try {
            val p = v.poseSegEyeBody
            p.enabled = true
            score += 1
        } catch (_: Throwable) {
            try {
                // alternate name
            } catch (_: Throwable) {}
        }

        // Eyes + gaze
        max += 1
        try {
            v.cenDrive.eyesOn = true
            score += 1
        } catch (_: Throwable) {}

        // Complete atomspare
        max += 1
        try {
            val c = v.completeAtomProtect
            c.enabled = true
            if (forceAtomspare || rawComplete) {
                c.atomOn = true
                c.allPreviousAtmospheric = true
                c.protectOn = true
            }
            score += 1
        } catch (_: Throwable) {}

        // Hair + head sides
        max += 1
        try {
            val h = v.hairBullet
            h.enabled = true
            h.hairOn = true
            h.headFrontOn = true; h.headUpOn = true; h.headDownOn = true
            h.headLeftOn = true; h.headRightOn = true
            score += 1
        } catch (_: Throwable) {}

        try {
            val e = v.eyesHeartBelly
            e.enabled = true
            e.eyesOn = true; e.heartOn = true; e.bellyOn = true; e.extraOn = true
            try {
                val n = v.faceEyeNoise
                n.enabled = true; n.faceOn = true; n.eyeOn = true; n.noiseOn = true
            try {
                val mm = v.moreMissed
                mm.enabled = true
                mm.earOn = true; mm.oralOn = true; mm.extremitiesOn = true
                mm.skinLayersOn = true; mm.pelvicOn = true; mm.jointOn = true; mm.lymphOn = true
            try {
                val fb = v.fullBodyAnatomy
                fb.enabled = true
                fb.outsideOn = true
                fb.insideOn = true
                fb.rawComplete = true
            try {
                val sk = v.allBodySkinAnatomy
                sk.enabled = true
                sk.allSkinOn = true
                sk.brainOn = true
                sk.eyesSkinOn = true
                sk.noseSkinOn = true
                sk.neckSkinOn = true
                sk.missingSkinOn = true
                sk.forceFullBodySkin = true
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            score += 1; max += 1
        } catch (_: Throwable) { max += 1 }
        if (forceAllAmbientBoards || rawComplete) {
            try { v.allBodySkinAnatomy.enabled = true; v.allBodySkinAnatomy.allSkinOn = true; v.allBodySkinAnatomy.missingSkinOn = true } catch (_: Throwable) {}
            try { v.fullBodyAnatomy.enabled = true; v.fullBodyAnatomy.outsideOn = true; v.fullBodyAnatomy.insideOn = true } catch (_: Throwable) {}
            try { v.body84FullHuman.enableFullHuman() } catch (_: Throwable) {}
            try { v.eyesHeartBelly.enabled = true } catch (_: Throwable) {}
            try { v.faceEyeNoise.enabled = true } catch (_: Throwable) {}
            try { v.moreMissed.enabled = true } catch (_: Throwable) {}
            try { v.bodyFreqRegen.enabled = true } catch (_: Throwable) {}
            try {
                val sm = v.skinMultiMotion
                sm.enabled = true
                sm.poseOn = true; sm.segmentOn = true; sm.obbOn = true
                sm.skinAmbientOn = true; sm.moveOn = true; sm.speedOn = true; sm.waveOn = true
            try { v.skinSoundsProtect.enabled = true; v.skinSoundsProtect.protectOn = true } catch (_: Throwable) {}
            try {
                val bio = v.bioSkinCell
                bio.enabled = true
                bio.skinLayersOn = true; bio.glandsOn = true; bio.membranesOn = true
                bio.cellOn = true; bio.dnaRnaOn = true; bio.bloodOn = true
            try {
                val ch = v.bodyChemBrain
                ch.enabled = true
                ch.chemOn = true
                ch.brainOn = true
            try {
                val ca = v.caMgProtectChem
                ca.enabled = true
                ca.caOn = true
                ca.protectOn = true
                ca.enemyDestroyOn = true
                ca.chemThrOn = true
                ca.skinThrOn = true
                ca.cellsThrOn = true
            try {
                val sk = v.skeletonWaterAstro
                sk.enabled = true
                sk.skeletonOn = true
                sk.waterOn = true
                sk.astroOn = true
            try {
                val br = v.bodyRegionEnemyProtect
                br.enabled = true
                br.protectOn = true
                br.insideOn = true
                br.micDbOn = true
            } catch (_: Throwable) {}
            try {
                v.antiAtomspareSounds.enabled = true
                v.antiAtomspareSounds.antiOn = true
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            score += 1; max += 1
        }
        completeness = if (max > 0) score.toFloat() / max else 0f
        tick()
    }
}
