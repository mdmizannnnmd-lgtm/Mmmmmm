package com.mizan

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Canvas 3D renderer for the brain and the full human anatomy. Every part is an ellipsoid that is rotated
 * (yaw + tilt), projected with perspective, depth-sorted and shaded. Works everywhere (no OpenGL / ARCore needed).
 */
class Soft3DRenderer {
    /** Body oils ambient draw intensity 0..1 (from BodyOilsChemicalFullBoard). */
    @Volatile var oilsLayer: Float = 0f
    @Volatile var waterChemLayer: Float = 0f
    @Volatile var neuroCellLayer: Float = 0f
    @Volatile var nonNerveCellLayer: Float = 0f
    @Volatile var glandLayer: Float = 0f
    @Volatile var eyeSkinWaterLayer: Float = 0f
    @Volatile var anatomy360Layer: Float = 0f
    @Volatile var channelLayer: Float = 0f
    @Volatile var quantumLayer: Float = 0f
    @Volatile var eyeIctLayer: Float = 0f
    @Volatile var eyeBodyLinkLayer: Float = 0f
    @Volatile var kopalSurfaceLayer: Float = 0f
    @Volatile var whiteSurfaceLayer: Float = 0f
    @Volatile var dualSelfLayer: Float = 0f
    @Volatile var bodyAtomSurfaceLayer: Float = 0f
    @Volatile var bulletDrawLayer: Float = 0f
    @Volatile var knifeDrawLayer: Float = 0f
    @Volatile var whipDrawLayer: Float = 0f
    @Volatile var burstDrawLayer: Float = 0f
    @Volatile var arrowDrawLayer: Float = 0f
    @Volatile var eyeOtherSelfLayer: Float = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val oval = RectF()
    private class ProjectedSkinTriangle {
        var depth = 0f
        var ax = 0f; var ay = 0f
        var bx = 0f; var by = 0f
        var cx = 0f; var cy = 0f
        var color = 0

        fun set(d: Float, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, c: Int) {
            depth = d
            ax = x1; ay = y1
            bx = x2; by = y2
            cx = x3; cy = y3
            color = c
        }
    }
    private val projectedSkinTriangles = ArrayList<ProjectedSkinTriangle>()
    private val projectedSkinPool = ArrayList<ProjectedSkinTriangle>()

    // current rotation
    private var cY = 1f
    private var sY = 0f
    private var cT = 1f
    private var sT = 0f
    // rotation result
    private var ox = 0f
    private var oy = 0f
    private var oz = 0f

    private fun setRotation(yaw: Float, tilt: Float) {
        cY = cos(yaw); sY = sin(yaw); cT = cos(tilt); sT = sin(tilt)
    }

    private fun rot(x: Float, y: Float, z: Float) {
        val x1 = x * cY + z * sY
        val z1 = -x * sY + z * cY
        ox = x1
        oy = y * cT - z1 * sT
        oz = y * sT + z1 * cT
    }

    private fun persp(z: Float): Float = FOCAL / (FOCAL - z).coerceAtLeast(0.5f)

    /** Colour pipeline: lighting → colour level (saturation) → contrast / brightness / thresholds (or RAW). */
    private fun shade(
        argb: Int, alpha: Int, light: Float, colourLevel: Float,
        tuning: VisualShieldView.EyeTuning, rawVisual: Boolean, ambient: Float
    ): Int {
        var r = Color.red(argb) * light
        var g = Color.green(argb) * light
        var b = Color.blue(argb) * light
        val gray = 0.299f * r + 0.587f * g + 0.114f * b
        val cl = colourLevel.coerceIn(0f, 2f)
        r = (gray + (r - gray) * cl).coerceIn(0f, 255f)
        g = (gray + (g - gray) * cl).coerceIn(0f, 255f)
        b = (gray + (b - gray) * cl).coerceIn(0f, 255f)
        val a = alpha.coerceIn(0, 255)
        return if (rawVisual) Color.argb(a, r.toInt(), g.toInt(), b.toInt())
        else tuning.apply(a, r.toInt(), g.toInt(), b.toInt(), ambient)
    }

    /** Draws one rotated + projected ellipsoid. Returns false when it is fully off screen. */
    private fun ellipsoid(
        canvas: Canvas, cx: Float, cy: Float, unit: Float, yOffset: Float,
        x: Float, y: Float, z: Float, rx: Float, ry: Float, rz: Float, rotZ: Float,
        color: Int, alpha: Int, light: Float
    ) {
        rot(x, y - yOffset, z)
        val s = persp(oz)
        val px = cx + ox * unit * s
        val py = cy - oy * unit * s
        val halfW = sqrt((rx * cY) * (rx * cY) + (rz * sY) * (rz * sY)) * unit * s
        val depthExt = sqrt((rx * sY) * (rx * sY) + (rz * cY) * (rz * cY))
        val halfH = sqrt((ry * cT) * (ry * cT) + (depthExt * sT) * (depthExt * sT)) * unit * s
        if (halfW < 0.5f || halfH < 0.5f) return
        canvas.save()
        if (rotZ != 0f) canvas.rotate(-rotZ, px, py)
        oval.set(px - halfW, py - halfH, px + halfW, py + halfH)
        fill.style = Paint.Style.FILL
        fill.shader = null
        fill.color = color
        canvas.drawOval(oval, fill)
        // soft highlight (upper left)
        val hl = (alpha * 0.30f * light).toInt().coerceIn(0, 120)
        if (hl > 6) {
            fill.color = Color.argb(hl, 255, 255, 255)
            oval.set(px - halfW * 0.62f, py - halfH * 0.72f, px + halfW * 0.10f, py - halfH * 0.05f)
            canvas.drawOval(oval, fill)
        }
        canvas.restore()
    }

    private fun halo(canvas: Canvas, cx: Float, cy: Float, radius: Float, rgb: Int, alpha: Int) {
        if (alpha < 3 || radius < 2f) return
        val c0 = Color.argb(alpha.coerceIn(0, 255), Color.red(rgb), Color.green(rgb), Color.blue(rgb))
        val c1 = Color.argb(0, Color.red(rgb), Color.green(rgb), Color.blue(rgb))
        glow.shader = RadialGradient(cx, cy, radius, c0, c1, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, radius, glow)
        glow.shader = null
    }

    // ─────────────────────────────────────────────────────────────────────────────── BRAIN
    fun drawBrain(canvas: Canvas, cx: Float, cy: Float, viewW: Float, b: BrainBoard, phase: Float) {
        if (!b.enabled) return
        val unit = viewW * b.size.coerceIn(0.15f, 0.9f) * 0.5f
        val avgOut = (b.left.out + b.right.out) * 0.5f
        val sway = sin(phase * 0.03f) * 0.30f * (b.left.moveOut + b.right.moveOut) * 0.5f
        val spin = (b.left.speedOut + b.right.speedOut) * 0.5f
        val yaw = if (b.yawAuto) {
            phase * 0.010f * (0.25f + b.yawSpeed * 2.5f) * (1f + spin * 2f) + sway
        } else b.yaw + sway
        // swing ±70° so both hemispheres stay readable instead of a full spin
        val yawView = if (b.yawAuto) sin(yaw) * 1.15f else yaw
        setRotation(yawView + motionYaw, b.tilt + motionTilt)

        // 3D atmosphere halo: left cool, right warm
        if (b.haloOn) {
            halo(canvas, cx - unit * 0.40f, cy, unit * 1.45f, 0x4FC3F7,
                (b.left.atmoOut * b.left.intensity * 150f).toInt())
            halo(canvas, cx + unit * 0.40f, cy, unit * 1.45f, 0xFFB74D,
                (b.right.atmoOut * b.right.intensity * 150f).toInt())
            // wave rings
            val wv = (b.left.waveOut + b.right.waveOut) * 0.5f
            if (wv > 0.02f) {
                line.strokeWidth = max(1f, unit * 0.010f)
                for (k in 0 until 3) {
                    val rr = unit * (1.05f + k * 0.16f + 0.08f * sin(phase * 0.05f + k * 1.4f) * wv)
                    line.color = Color.argb((wv * 120f / (k + 1)).toInt().coerceIn(0, 140), 128, 222, 234)
                    canvas.drawCircle(cx, cy, rr, line)
                }
            }
        }

        // depth sort (far → near)
        val glandKinds = setOf(BrainModel.PITUITARY, BrainModel.PINEAL, BrainModel.HYPOTHALAMUS,
            BrainModel.THALAMUS, BrainModel.VENTRICLE)
        val all = BrainModel.lobes.filter { l ->
            val okInner = !l.inner || b.innerOn
            val okGland = l.kind !in glandKinds || b.glandsOn
            okInner && okGland
        }
        val order = all.sortedBy { l ->
            rot(l.x, l.y, l.z); oz
        }
        for (l in order) {
            val hemi = if (l.side > 0) b.right else b.left
            val o = b.lobeOut(l.kind, l.side)
            val wv = hemi.waveOut
            val pulse = 1f + 0.05f * wv * sin(phase * 0.09f + l.x * 4f + l.z * 3f)
            val dim = if (b.innerOn && !l.inner) 0.42f else 1f
            val a = ((60f + 175f * (0.20f + 0.80f * o)) * hemi.intensity.coerceIn(0f, 1f) * dim).toInt()
            val light = 0.55f + 0.55f * o
            val col = shade(BrainModel.baseColor(l), a, light, hemi.colourLevel, hemi.tuning, hemi.rawVisual, o)
            ellipsoid(
                canvas, cx, cy, unit, 0f, l.x, l.y, l.z,
                l.rx * pulse, l.ry * pulse, l.rz * pulse, l.rotZ, col, Color.alpha(col), light
            )
            if (b.sulciOn && !l.inner && l.kind <= BrainModel.CEREBELLUM) {
                drawSulci(canvas, cx, cy, unit, l, o, wv, phase, hemi, dim)
            }
        }
    }

    /** Curved fold lines (gyri / sulci) laid on the front-facing side of an outer lobe. */
    private fun drawSulci(
        canvas: Canvas, cx: Float, cy: Float, unit: Float, l: BrainModel.Lobe,
        out: Float, wave: Float, phase: Float, hemi: BrainBoard.Hemi, dim: Float
    ) {
        val n = if (l.kind == BrainModel.CEREBELLUM) 5 else 3
        line.strokeWidth = max(1f, unit * 0.011f)
        val a = ((40f + 120f * out) * hemi.intensity * dim).toInt().coerceIn(12, 200)
        line.color = Color.argb(a, 10, 30, 50)
        for (j in 0 until n) {
            path.reset()
            var pen = false
            val phi0 = (j - (n - 1) / 2f) * 0.75f
            val steps = 14
            for (i in 0..steps) {
                val t = i / steps.toFloat() * 2f - 1f
                val theta = t * 1.30f
                val phi = phi0 + 0.45f * sin(3.1f * t + j * 1.7f + phase * 0.03f * (0.3f + wave * 3f))
                val lx = cos(theta) * sin(phi)
                val ly = sin(theta)
                val lz = cos(theta) * cos(phi)
                // normal (rotation only) → front-facing test
                rot(lx / l.rx.coerceAtLeast(0.01f), ly / l.ry.coerceAtLeast(0.01f), lz / l.rz.coerceAtLeast(0.01f))
                val facing = oz
                rot(l.x + lx * l.rx, l.y + ly * l.ry, l.z + lz * l.rz)
                val s = persp(oz)
                val px = cx + ox * unit * s
                val py = cy - oy * unit * s
                if (facing > 0.15f) {
                    if (!pen) { path.moveTo(px, py); pen = true } else path.lineTo(px, py)
                } else pen = false
            }
            canvas.drawPath(path, line)
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────── ANATOMY
    private var order = IntArray(0)
    private var zs = FloatArray(0)
    private var wx = FloatArray(0)
    private var wy = FloatArray(0)
    private var wz = FloatArray(0)
    private val fxTmp = FloatArray(3)



    /** Optic nerve / chiasm lines from occipital → eyes (optical path). */
    fun drawOpticalLines(
        canvas: Canvas, cx: Float, cy: Float, viewW: Float, b: BrainBoard, phase: Float
    ) {
        if (!b.enabled || !b.opticalOn) return
        val unit = viewW * b.size.coerceIn(0.15f, 0.9f) * 0.22f
        val e = max(b.left.out, b.right.out).coerceIn(0.2f, 1f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.2f + e * 2.5f
            color = Color.argb((90 + e * 120).toInt(), 0x80, 0xDE, 0xEA)
        }
        // chiasm centre just in front of brainstem
        val chX = cx
        val chY = cy + unit * 0.15f
        // left / right optic to approximate eye sockets
        val eyeY = cy - unit * 0.55f
        val eyeXL = cx - unit * 0.85f
        val eyeXR = cx + unit * 0.85f
        val wave = sin(phase * 0.08f) * unit * 0.04f * e
        canvas.drawLine(chX, chY, eyeXL + wave, eyeY, p)
        canvas.drawLine(chX, chY, eyeXR - wave, eyeY, p)
        // short nerve stubs at eyes
        p.strokeWidth = 3.5f
        canvas.drawCircle(eyeXL, eyeY, 4f + e * 3f, p)
        canvas.drawCircle(eyeXR, eyeY, 4f + e * 3f, p)
        canvas.drawCircle(chX, chY, 5f + e * 2f, p)
    }

    /** 3D face contour lines (jaw · cheek · brow) when faceLinesOn. */
    fun drawFaceLines(
        canvas: Canvas, cx: Float, cy: Float, viewH: Float, a: Anatomy3DBoard, phase: Float,
        modelSize: Float = a.size
    ) {
        if (!a.enabled) return
        // driven via brain board faceLinesOn if present — always light face frame
        val unit = viewH * modelSize.coerceIn(0.2f, 1.2f) / 2.7f
        val yOff = 0.40f
        val headY = 1.52f
        val e = max(a.outside.out, 0.35f)
        setRotation(anatomyYaw(a, phase), a.tilt + motionTilt)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.8f + e * 1.5f
            color = Color.argb((70 + e * 100).toInt(), 0xB2, 0xEB, 0xF2)
        }
        // oval face outline
        rot(0f, headY - yOff, 0.12f)
        val hx = cx + ox * unit
        val hy = cy - oy * unit
        canvas.drawOval(hx - unit * 0.16f, hy - unit * 0.20f, hx + unit * 0.16f, hy + unit * 0.20f, p)
        // brow line
        p.strokeWidth = 2.2f
        canvas.drawLine(hx - unit * 0.10f, hy - unit * 0.06f, hx + unit * 0.10f, hy - unit * 0.06f, p)
        // nose bridge
        canvas.drawLine(hx, hy - unit * 0.02f, hx, hy + unit * 0.08f, p)
        // mouth line
        canvas.drawLine(hx - unit * 0.05f, hy + unit * 0.12f, hx + unit * 0.05f, hy + unit * 0.12f, p)
    }

    /**
     * Full human silhouette (outside surface) — continuous figure like medical 3D body,
     * not a single blob: head · neck · torso · arms · hands · legs · feet.
     */
    fun drawBodySilhouette(
        canvas: Canvas, cx: Float, cy: Float, viewH: Float,
        a: Anatomy3DBoard, phase: Float, modelSize: Float = a.size
    ) {
        if (!a.enabled || (!a.rawAll && !a.layerOn[AnatomyModel3D.SKIN])) return
        val e = max(a.outside.out, 0.35f)
        val unit = viewH * modelSize.coerceIn(0.2f, 1.2f) / 2.7f
        val yOff = 0.40f
        setRotation(anatomyYaw(a, phase), a.tilt + motionTilt)

        val skinE = a.outFor(AnatomyModel3D.SKIN).coerceIn(0.25f, 1f)
        val alpha = if (a.rawAll) 210 else
            (170f * a.layerLevel[AnatomyModel3D.SKIN] * (0.55f + 0.45f * skinE) *
                (1f - a.xray * 0.35f)).toInt().coerceIn(40, 210)
        val baseCol = 0x26C6DA  // cyan medical body (screenshot style)
        // Continuous smooth-union mesh replaces the old separated skin ellipsoids.
        halo(canvas, cx, cy, unit * 1.85f, baseCol, (a.atmosphere * e * 90f).toInt().coerceIn(0, 120))
        drawContinuousSkinMesh(canvas, cx, cy, unit, yOff, a, baseCol, alpha, skinE)
    }

    private fun drawContinuousSkinMesh(
        canvas: Canvas, cx: Float, cy: Float, unit: Float, yOffset: Float,
        a: Anatomy3DBoard, baseColor: Int, alpha: Int, energy: Float
    ) {
        val mesh = ContinuousBodySurface.triangles
        if (mesh.isEmpty()) return
        val projected = projectedSkinTriangles
        projected.clear()
        var poolIndex = 0
        for (tri in mesh) {
            rot(tri.ax, tri.ay - yOffset, tri.az)
            val ax = cx + ox * unit * persp(oz)
            val ay = cy - oy * unit * persp(oz)
            val za = oz
            rot(tri.bx, tri.by - yOffset, tri.bz)
            val bx = cx + ox * unit * persp(oz)
            val by = cy - oy * unit * persp(oz)
            val zb = oz
            rot(tri.cx, tri.cy - yOffset, tri.cz)
            val px = cx + ox * unit * persp(oz)
            val py = cy - oy * unit * persp(oz)
            val zc = oz

            // Rotate the mesh normal for stable directional lighting as the viewer turns around it.
            rot(tri.nx, tri.ny, tri.nz)
            val diffuse = max(0f, ox * 0.30f + oy * 0.56f + oz * 0.77f)
            val light = 0.50f + 0.52f * diffuse
            val color = shade(
                baseColor or (0xFF shl 24), alpha, light, a.colourLevel,
                a.tuning, a.rawVisual, energy
            )
            val projectedTri = if (poolIndex < projectedSkinPool.size) projectedSkinPool[poolIndex]
            else ProjectedSkinTriangle().also { projectedSkinPool.add(it) }
            projectedTri.set((za + zb + zc) / 3f, ax, ay, bx, by, px, py, color)
            projected.add(projectedTri)
            poolIndex++
        }
        fill.style = Paint.Style.FILL
        fill.shader = null
        projected.sortBy { it.depth }
        for (tri in projected) {
            path.reset()
            path.moveTo(tri.ax, tri.ay)
            path.lineTo(tri.bx, tri.by)
            path.lineTo(tri.cx, tri.cy)
            path.close()
            fill.color = tri.color
            canvas.drawPath(path, fill)
        }
    }

    /** Body-motion offsets (radians), set every frame by VisualShieldView from [BodyMotionHub]. */
    @Volatile var motionYaw = 0f
    @Volatile var motionTilt = 0f

    /** Keep the silhouette, anatomy layers, and pose guide on the same shared turntable. */
    private fun anatomyYaw(a: Anatomy3DBoard, phase: Float): Float {
        val off = motionYaw
        if (!a.yawAuto) return a.yaw + off
        val sway = sin(phase * 0.04f) * 0.25f * a.moveEff() * max(a.inside.out, a.outside.out)
        return sin(phase * 0.008f * (0.25f + a.speedEff() * 3f)) * 1.1f + sway + off
    }

    private fun drawPoseLink(
        canvas: Canvas, cx: Float, cy: Float, unit: Float, yOffset: Float,
        from: FloatArray, to: FloatArray, color: Int, width: Float
    ) {
        rot(from[0], from[1] - yOffset, from[2])
        val x1 = cx + ox * unit * persp(oz)
        val y1 = cy - oy * unit * persp(oz)
        val z1 = oz
        rot(to[0], to[1] - yOffset, to[2])
        val x2 = cx + ox * unit * persp(oz)
        val y2 = cy - oy * unit * persp(oz)
        val depthScale = (persp((z1 + oz) * 0.5f)).coerceIn(0.5f, 3f)
        line.style = Paint.Style.STROKE
        line.strokeCap = Paint.Cap.ROUND
        line.strokeWidth = max(1f, width * depthScale)
        line.color = color
        canvas.drawLine(x1, y1, x2, y2, line)
    }

    /** Major articulated links clarify the trunk, limbs, and L/R pose even with the skin visible. */
    private fun drawPoseRig(
        canvas: Canvas, cx: Float, cy: Float, unit: Float, yOffset: Float,
        a: Anatomy3DBoard, phase: Float
    ) {
        if (!a.poseRigOn || (!a.rawAll && !a.layerOn[AnatomyModel3D.SKELETON])) return
        val alpha = if (a.rawAll) 200f else
            (105f + 95f * a.inside.out.coerceIn(0f, 1f)) *
                a.layerLevel[AnatomyModel3D.SKELETON].coerceIn(0f, 1f)
        if (alpha < 8f) return
        val color = Color.argb(alpha.toInt().coerceIn(0, 210), 238, 232, 211)
        val w = max(1.2f, unit * 0.012f)
        val points = listOf(
            // Head and axial spine.
            floatArrayOf(0f, 1.48f, 0.0f) to floatArrayOf(0f, 1.28f, 0.0f),
            floatArrayOf(0f, 1.28f, 0.0f) to floatArrayOf(0f, 1.05f, -0.02f),
            floatArrayOf(0f, 1.05f, -0.02f) to floatArrayOf(0f, 0.84f, -0.02f),
            floatArrayOf(0f, 0.84f, -0.02f) to floatArrayOf(0f, 0.55f, -0.03f),
            floatArrayOf(0f, 0.55f, -0.03f) to floatArrayOf(0f, 0.22f, -0.04f),
            // Bilateral shoulder → elbow → wrist → palm links.
            floatArrayOf(-0.16f, 1.12f, 0f) to floatArrayOf(-0.38f, 1.02f, 0f),
            floatArrayOf(-0.38f, 1.02f, 0f) to floatArrayOf(-0.51f, 0.43f, 0f),
            floatArrayOf(-0.51f, 0.43f, 0f) to floatArrayOf(-0.56f, 0.02f, 0f),
            floatArrayOf(-0.56f, 0.02f, 0f) to floatArrayOf(-0.56f, -0.10f, 0.01f),
            floatArrayOf(0.16f, 1.12f, 0f) to floatArrayOf(0.38f, 1.02f, 0f),
            floatArrayOf(0.38f, 1.02f, 0f) to floatArrayOf(0.51f, 0.43f, 0f),
            floatArrayOf(0.51f, 0.43f, 0f) to floatArrayOf(0.56f, 0.02f, 0f),
            floatArrayOf(0.56f, 0.02f, 0f) to floatArrayOf(0.56f, -0.10f, 0.01f),
            // Hip → knee → ankle → foot.
            floatArrayOf(-0.10f, 0.16f, 0f) to floatArrayOf(-0.16f, -0.40f, 0.01f),
            floatArrayOf(-0.16f, -0.40f, 0.01f) to floatArrayOf(-0.16f, -0.80f, 0f),
            floatArrayOf(-0.16f, -0.80f, 0f) to floatArrayOf(-0.16f, -0.87f, 0.15f),
            floatArrayOf(0.10f, 0.16f, 0f) to floatArrayOf(0.16f, -0.40f, 0.01f),
            floatArrayOf(0.16f, -0.40f, 0.01f) to floatArrayOf(0.16f, -0.80f, 0f),
            floatArrayOf(0.16f, -0.80f, 0f) to floatArrayOf(0.16f, -0.87f, 0.15f)
        )
        for ((from, to) in points) {
            drawPoseLink(canvas, cx, cy, unit, yOffset, from, to, color, w)
        }
    }

    // ── eye gaze: the eye ball contents (iris · pupil · cornea · lens · retina …) rotate toward the centroid ──
    private val gz = FloatArray(4)
    private var gzX = 0f
    private var gzY = 0f
    private var gzZ = 0f
    private var gzScale = 1f

    /** Sets [gzX]/[gzY]/[gzZ] (turned position) and [gzScale] (pupil size) for an eye-ball part; false for every other part. */
    private fun gazePos(a: Anatomy3DBoard, p: AnatomyModel3D.Part): Boolean {
        if (!a.bodyLocked && !EyeGazeMath.turn(p, a.gazeLx, a.gazeLy, a.gazeRx, a.gazeRy, a.pupilScale, gz)) return false
        gzX = gz[0]; gzY = gz[1]; gzZ = gz[2]; gzScale = gz[3]
        return true
    }

    fun drawAnatomy(
        canvas: Canvas, cx: Float, cy: Float, viewH: Float,
        a: Anatomy3DBoard, brain: BrainBoard, phase: Float, modelSize: Float = a.size
    ) {
        if (!a.enabled) return
        // Complete human on screen: all layers + continuous skin (not single-part)
        try {
            a.enableCompleteHumanLayers()
            a.setRawAll(true)
            for (i in a.layerOn.indices) {
                a.layerOn[i] = true
                if (a.layerLevel[i] < 0.75f) a.layerLevel[i] = 0.9f
            }
            a.poseRigOn = true
            a.gpuOn = true
            a.layerOn[0] = true
            a.layerLevel[0] = maxOf(a.layerLevel[0], 0.95f)
        } catch (_: Throwable) {}
        // fullBodySkinShell
        val parts = AnatomyModel3D.parts
        val unit = viewH * modelSize.coerceIn(0.2f, 1.2f) / 2.7f
        setRotation(anatomyYaw(a, phase), a.tilt + motionTilt)
        val yOff = 0.40f   // body centre

        // Full continuous human silhouette (outside) — medical cyan body style
        drawBodySilhouette(canvas, cx, cy, viewH, a, phase, modelSize)
        // cells on skin volume
        try {
            val ce = maxOf(if (a.layerLevel.isNotEmpty()) a.layerLevel[0] else 0.5f, a.atmosphere * 0.8f, a.outFor(AnatomyModel3D.SKIN) * 0.7f)
            drawCellField3D(canvas, cx, cy, viewH, a, ce, phase, modelSize)
            if (oilsLayer > 0.05f) drawBodyOils3D(canvas, cx, cy, viewH, oilsLayer, phase, modelSize)
            if (waterChemLayer > 0.05f) drawWaterChem3D(canvas, cx, cy, viewH, waterChemLayer, phase, modelSize)
            if (neuroCellLayer > 0.05f) drawNeuroCells3D(canvas, cx, cy, viewH, neuroCellLayer, phase, modelSize)
            if (nonNerveCellLayer > 0.05f) drawNonNerveCells3D(canvas, cx, cy, viewH, nonNerveCellLayer, phase, modelSize)
            if (glandLayer > 0.05f) drawGlands3D(canvas, cx, cy, viewH, glandLayer, phase, modelSize)
            if (eyeSkinWaterLayer > 0.05f) drawEyeSkinWater3D(canvas, cx, cy, viewH, eyeSkinWaterLayer, phase, modelSize)
            if (anatomy360Layer > 0.05f) drawAnatomy360(canvas, cx, cy, viewH, anatomy360Layer, phase, modelSize)
            if (channelLayer > 0.05f) drawChannels3D(canvas, cx, cy, viewH, channelLayer, phase, modelSize)
            if (quantumLayer > 0.05f) drawQuantumDots3D(canvas, cx, cy, viewH, quantumLayer, phase, modelSize)
            if (eyeIctLayer > 0.05f) drawEyeIctPoint3D(canvas, cx, cy, viewH, eyeIctLayer, phase, modelSize)
            if (eyeBodyLinkLayer > 0.05f) drawEyeBodyLink3D(canvas, cx, cy, viewH, eyeBodyLinkLayer, phase, modelSize)
            if (kopalSurfaceLayer > 0.05f) drawKopalSurface(canvas, cx, cy, viewH, kopalSurfaceLayer, phase, modelSize)
            if (whiteSurfaceLayer > 0.05f) drawWhiteSurface(canvas, cx, cy, viewH, whiteSurfaceLayer, phase, modelSize)
            if (dualSelfLayer > 0.05f) drawDualSelf(canvas, cx, cy, viewH, dualSelfLayer, phase, modelSize)
            if (bodyAtomSurfaceLayer > 0.05f) drawBodyAtomSurface(canvas, cx, cy, viewH, bodyAtomSurfaceLayer, phase, modelSize)
            if (bulletDrawLayer > 0.05f) drawBulletWeapon3D(canvas, cx, cy, viewH, bulletDrawLayer, phase, modelSize)
            if (knifeDrawLayer > 0.05f) drawKnifeWeapon3D(canvas, cx, cy, viewH, knifeDrawLayer, phase, modelSize)
            if (whipDrawLayer > 0.05f) drawWhipWeapon3D(canvas, cx, cy, viewH, whipDrawLayer, phase, modelSize)
            if (burstDrawLayer > 0.05f) drawBurstWeapon3D(canvas, cx, cy, viewH, burstDrawLayer, phase, modelSize)
            if (arrowDrawLayer > 0.05f) drawArrowWeapon3D(canvas, cx, cy, viewH, arrowDrawLayer, phase, modelSize)
            if (eyeOtherSelfLayer > 0.05f) drawEyeOtherSelfComm(canvas, cx, cy, viewH, eyeOtherSelfLayer, phase, modelSize)
        } catch (_: Throwable) {}

        // atmosphere halo behind the body
        val e = max(a.inside.out, a.outside.out)
        halo(canvas, cx, cy, unit * 1.9f, 0x26C6DA, (a.atmosphere * e * 80f).toInt())
        // Place the articulated guide before the detailed parts so nearer anatomy can occlude it.
        drawPoseRig(canvas, cx, cy, unit, yOff, a, phase)

        // depth order (far → near)
        if (order.size != parts.size) {
            order = IntArray(parts.size); zs = FloatArray(parts.size)
            wx = FloatArray(parts.size); wy = FloatArray(parts.size); wz = FloatArray(parts.size)
        }
        // INSIDE WARP + INSIDE ROTATION: only the inside layers (skeleton · organs · vessels · brain) are transformed
        val fx = a.insideFx
        val fxOn = fx.active()
        val mv = a.moveFx
        val mvOn = mv != null && mv.on && mv.insideOn
        for (i in parts.indices) {
            val p = parts[i]
            if (fxOn && AnatomyModel3D.isInside(p.layer)) {
                fx.apply(p.x, p.y, p.z, phase, fxTmp)
                wx[i] = fxTmp[0]; wy[i] = fxTmp[1]; wz[i] = fxTmp[2]
            } else { wx[i] = p.x; wy[i] = p.y; wz[i] = p.z }
            // AMBIENT MOVEMENT (inside): the inside layers move on top of the body, lagging it like soft tissue
            if (mvOn && mv != null && AnatomyModel3D.isInside(p.layer)) {
                wx[i] += mv.insideDx + mv.insideLean * (wy[i] - 0.70f)
                wy[i] += mv.insideDy
                wz[i] += mv.insideDz
            }
            rot(wx[i], wy[i] - yOff, wz[i])
            zs[i] = oz
            order[i] = i
        }
        val sorted = order.sortedBy { zs[it] }

        val breath = 1f + 0.035f * sin(phase * 0.05f) * (0.4f + a.waveEff() * e)
        val beat = 1f + 0.12f * a.waveEff() * max(0f, sin(phase * 0.22f)).pow(3f) * (0.4f + e)

        for (idx in sorted) {
            val p = parts[idx]
            // RAW COMPLETE is an all-anatomy inspection view: reveal every saved layer,
            // while retaining the user's layer switches for when RAW mode is turned off.
            if (!a.rawAll && !a.layerOn[p.layer]) continue
            // The continuous shell now provides the main skin volume. Keep only small outside
            // details that are not part of that shell, such as digits and stylized shells.
            if (p.layer == AnatomyModel3D.SKIN &&
                !p.name.contains("finger", ignoreCase = true) &&
                !p.name.startsWith("Toe ") &&
                !p.name.endsWith("shell", ignoreCase = true)
            ) continue
            if (p.layer == AnatomyModel3D.BRAIN) {
                val bl = BrainModel.lobes.firstOrNull { it.kind == p.lobe && it.side == p.side }
                if (!a.rawAll && bl != null && bl.inner && !brain.innerOn) continue
            }
            val out = if (a.rawAll) 1f else if (p.layer == AnatomyModel3D.BRAIN)
                brain.lobeOut(p.lobe, p.side).let { max(it, 0.15f * a.inside.out) }
            else a.outFor(p.layer)
            val base = if (a.rawAll) 1f else when (p.layer) {
                AnatomyModel3D.SKIN -> (1f - a.xray) * 0.60f + 0.06f
                AnatomyModel3D.FACE -> (1f - a.xray * 0.6f) * 0.60f + 0.10f
                AnatomyModel3D.MUSCLE -> (1f - a.xray * 0.75f) * 0.55f + 0.10f
                else -> 0.50f + 0.40f * out
            }
            val layerLevel = if (a.rawAll) 1f else a.layerLevel[p.layer].coerceIn(0f, 1f)
            val alpha = (255f * base * layerLevel *
                (0.45f + 0.55f * out.coerceIn(0f, 1f))).toInt()
            if (alpha < 6) continue
            val light = 0.60f + 0.60f * out
            val col = shade(p.color, alpha, light, a.colourLevel, a.tuning, a.rawVisual, out)
            var sx = p.sx; var sy = p.sy; var sz = p.sz
            if (p.name.startsWith("Lung") || p.name == "Diaphragm") { sx *= breath; sy *= breath; sz *= breath }
            if (p.name.startsWith("Heart")) { sx *= beat; sy *= beat; sz *= beat }
            if (gazePos(a, p)) {
                ellipsoid(canvas, cx, cy, unit, yOff, gzX, gzY, gzZ, sx * gzScale, sy * gzScale, sz, p.rotZ, col, Color.alpha(col), light)
            } else {
                ellipsoid(canvas, cx, cy, unit, yOff, wx[idx], wy[idx], wz[idx], sx, sy, sz, p.rotZ, col, Color.alpha(col), light)
            }
        }
        drawAudioFxTarget(canvas, cx, cy, unit, a, phase)
    }

    /** Draw a visible, explicitly illustrative FX marker at the selected model segment. */
    private fun drawAudioFxTarget(
        canvas: Canvas, cx: Float, cy: Float, unit: Float,
        a: Anatomy3DBoard, phase: Float
    ) {
        val level = a.audioFxLevel.coerceIn(0f, 1f)
        if (level < 0.015f) return

        var x = 0f
        var y = 0.80f
        var z = 0.08f
        when (a.audioFxTargetPart) {
            HumanDetection.PART_HEAD -> { y = 1.52f; z = 0.12f }
            HumanDetection.PART_TORSO -> { y = 0.80f; z = 0.10f }
            HumanDetection.PART_ARM_L -> { x = -0.46f; y = 0.58f }
            HumanDetection.PART_ARM_R -> { x = 0.46f; y = 0.58f }
            HumanDetection.PART_LEG_L -> { x = -0.16f; y = -0.40f }
            HumanDetection.PART_LEG_R -> { x = 0.16f; y = -0.40f }
            HumanDetection.PART_HAND_L -> { x = -0.56f; y = 0.02f }
            HumanDetection.PART_HAND_R -> { x = 0.56f; y = 0.02f }
            HumanDetection.PART_FOOT_L -> { x = -0.16f; y = -0.87f; z = 0.15f }
            HumanDetection.PART_FOOT_R -> { x = 0.16f; y = -0.87f; z = 0.15f }
        }
        project(cx, cy, unit, x, y, z)
        val rgb = when (a.audioFxKind) {
            1 -> Color.rgb(75, 220, 255)       // generic knife-like FX channel
            2 -> Color.rgb(205, 130, 255)      // ripple FX channel
            else -> Color.rgb(255, 155, 75)    // generic impulse-like FX channel
        }
        val pulse = 0.82f + 0.18f * sin(phase * 0.16f)
        val radius = unit * (0.045f + 0.055f * level) * pulse
        halo(canvas, prX, prY, radius * 1.8f, rgb, (level * 75f).toInt())
        val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = (unit * 0.012f).coerceIn(2f, 7f)
            color = Color.argb((90f + level * 165f).toInt().coerceIn(0, 255),
                Color.red(rgb), Color.green(rgb), Color.blue(rgb))
        }
        canvas.drawCircle(prX, prY, radius, marker)
        canvas.drawCircle(prX, prY, radius * 0.48f, marker)
    }


    /** 3D noise grain cloud (near / mid / far layers) around body centre. */
    
    /** Symbolic cell field over full body skin volume — nucleus dots + membrane rings. */
    fun drawCellField3D(
        canvas: Canvas, cx: Float, cy: Float, viewH: Float,
        a: Anatomy3DBoard, cellEnergy: Float, phase: Float, modelSize: Float = a.size
    ) {
        if (!a.enabled || cellEnergy < 0.02f) return
        val unit = viewH * modelSize.coerceIn(0.2f, 1.2f) / 2.7f
        val yOff = 0.40f
        setRotation(anatomyYaw(a, phase), a.tilt + motionTilt)
        val e = cellEnergy.coerceIn(0f, 1f)
        val n = (12 + (e * 28f).toInt()).coerceIn(12, 40)
        val seed = (phase * 10f).toInt()
        for (i in 0 until n) {
            // distribute over torso / limbs / head in model space
            val t = (i * 37 + seed) % 100 / 100f
            val side = if (i % 2 == 0) -1f else 1f
            val x = when {
                i % 5 == 0 -> side * 0.12f * (0.4f + t)      // near spine
                i % 5 == 1 -> side * 0.42f * (0.5f + t * 0.5f) // arms
                i % 5 == 2 -> side * 0.18f                      // legs
                i % 5 == 3 -> side * 0.08f                       // head
                else -> side * 0.28f * t
            }
            // regionCellBias: 0 head/eyes, 1 face/neck, 2 belly, 3 arms, 4 legs
            val y = when {
                i % 7 == 0 -> 1.42f + (t - 0.5f) * 0.08f   // crown / head-up
                i % 7 == 1 -> 1.28f + (t - 0.5f) * 0.12f   // face / eyes
                i % 7 == 2 -> 1.05f + (t - 0.5f) * 0.1f    // neck
                i % 7 == 3 -> 0.05f + (t - 0.5f) * 0.25f   // belly front
                i % 7 == 4 -> 0.55f - t * 0.35f            // arms
                i % 7 == 5 -> -0.35f - t * 0.4f            // legs
                else -> 0.2f + (t - 0.5f) * 0.7f
            }
            val z = 0.05f + (i % 7) * 0.02f
            rot(x, y - yOff, z)
            val px = cx + ox * unit * persp(oz)
            val py = cy - oy * unit * persp(oz)
            val sc = unit * (0.018f + 0.012f * e) * (0.85f + 0.15f * sin(phase * 0.2f + i))
            val alpha = (40 + e * 120f).toInt().coerceIn(20, 160)
            // membrane ring
            val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = (unit * 0.004f).coerceIn(1f, 3f)
                color = Color.argb(alpha, 120, 220, 180)
            }
            canvas.drawCircle(px, py, sc, ring)
            // nucleus
            val nuc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = Color.argb((alpha * 1.2f).toInt().coerceIn(0, 200), 80, 180, 255)
            }
            canvas.drawCircle(px, py, sc * 0.35f, nuc)
        }
    }

    fun drawNoise3D(
        canvas: Canvas, cx: Float, cy: Float, viewH: Float,
        n: Noise3DBoard, phase: Float
    ) {
        if (!n.enabled || n.out < 0.02f) return
        val e = n.out.coerceIn(0f, 1f)
        val dens = (12 + (n.density * e * 48).toInt()).coerceIn(8, 64)
        val baseR = viewH * 0.28f * (0.6f + n.size * 0.8f)
        val spd = 0.4f + n.speed * 2.2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val depth = n.depth.coerceIn(0.2f, 1f)
        for (layer in 0 until 3) {
            val zFac = 0.55f + layer * 0.22f * depth
            val alpha = (28 + e * (40 + layer * 18)).toInt().coerceIn(12, 140)
            val r = ((n.colour shr 16) and 0xFF)
            val g = ((n.colour shr 8) and 0xFF)
            val b = (n.colour and 0xFF)
            p.color = Color.argb(alpha, r, g, b)
            val count = dens / (layer + 1)
            for (i in 0 until count) {
                val a = i * 2.399f + phase * spd * (0.7f + layer * 0.15f) + layer * 1.7f
                val rad = baseR * zFac * (0.35f + (i % 7) * 0.09f)
                val x = cx + kotlin.math.cos(a) * rad * (1f + 0.15f * kotlin.math.sin(phase * 0.05f + i))
                val y = cy + kotlin.math.sin(a * 1.15f) * rad * 0.85f * (1f + 0.1f * kotlin.math.cos(phase * 0.04f + i))
                val pr = (1.2f + e * 2.8f * zFac) * (0.7f + n.size)
                canvas.drawCircle(x, y, pr, p)
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────── RINGS + BALLS ON THE 3D BODY
    private var ringOrder = IntArray(0)
    private var ringZ = FloatArray(0)
    private val ringPath = Path()
    private var prX = 0f
    private var prY = 0f
    private var chColors = IntArray(0)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    /** Rotates + projects one body-space point; result in [prX] / [prY]. */
    private fun project(cx: Float, cy: Float, unit: Float, x: Float, y: Float, z: Float) {
        rot(x, y - 0.40f, z)
        val s = persp(oz)
        prX = cx + ox * unit * s
        prY = cy - oy * unit * s
    }

    private fun smooth01(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /**
     * Every ring and ball of the body regions, placed ON the 3D anatomy body ([AnatomyRingBoard]): an OUTSIDE ring +
     * ball on the skin / face and an INSIDE ring + ball on the organ / bone under it, plus the 84 body-channel balls.
     * Same turntable, perspective and depth order as [drawAnatomy]. RAW COMPLETE draws everything on both layers at the
     * live signal level with no fades, switches or colour tuning.
     */
    fun drawAnatomyRings(
        canvas: Canvas, cx: Float, cy: Float, viewH: Float,
        a: Anatomy3DBoard, rb: AnatomyRingBoard, phase: Float, modelSize: Float = a.size
    ) {
        if (!a.enabled || !rb.enabled) return
        val raw = rb.rawComplete || a.rawAll
        val unit = viewH * modelSize.coerceIn(0.2f, 1.2f) / 2.7f
        setRotation(anatomyYaw(a, phase), a.tilt + motionTilt)
        val rings = rb.rings
        val total = rings.size * 2
        if (ringOrder.size != total) {
            ringOrder = IntArray(total)
            ringZ = FloatArray(total)
        }

        // 84 body-channel balls (behind the rings)
        if (rb.channelBallsOn) {
            val anchors = rb.channelAnchors
            if (chColors.size != anchors.size) {
                chColors = IntArray(anchors.size) { i ->
                    Color.HSVToColor(floatArrayOf(i * 360f / anchors.size, 0.55f, 1f))
                }
            }
            for (i in anchors.indices) {
                val o = rb.channelOut[i]
                if (!raw && o < 0.12f) continue
                val oo = if (raw) max(o, 0.35f) else o
                val an = anchors[i]
                val rad = (0.010f + 0.020f * oo) * rb.channelScale
                val alpha = ((50f + 150f * oo) * rb.ballLevel).toInt().coerceIn(0, 220)
                val light = 0.70f + 0.50f * oo
                val col = shade(chColors[i], alpha, light, a.colourLevel, rb.tuning, raw, oo)
                ellipsoid(canvas, cx, cy, unit, 0.40f, an[0], an[1], an[2], rad, rad, rad, 0f, col, Color.alpha(col), light)
            }
        }

        // connectors: outside ring ↔ inside organ
        if (rb.connectorsOn) {
            line.style = Paint.Style.STROKE
            for (r in rings) {
                if (!raw && (!r.on || !rb.groupOn[r.group] || !rb.insideOn || !rb.outsideOn)) continue
                val o = max(r.inOut, r.outOut)
                if (!raw && o < 0.05f) continue
                project(cx, cy, unit, r.outside.x, r.outside.y, r.outside.z)
                val x1 = prX
                val y1 = prY
                project(cx, cy, unit, r.inside.x, r.inside.y, r.inside.z)
                line.strokeWidth = max(1f, unit * 0.004f)
                line.color = Color.argb(
                    ((22f + 85f * o) * rb.ringLevel).toInt().coerceIn(0, 130),
                    Color.red(r.color), Color.green(r.color), Color.blue(r.color)
                )
                canvas.drawLine(x1, y1, prX, prY, line)
            }
        }

        // collect visible items (ring k, layer 0 = outside / 1 = inside), then sort far → near
        var count = 0
        for (i in 0 until total) {
            val r = rings[i / 2]
            val inside = (i % 2) == 1
            if (!raw) {
                val layerOn = if (inside) rb.insideOn else rb.outsideOn
                val o0 = if (inside) r.inOut else r.outOut
                if (!r.on || !layerOn || !rb.groupOn[r.group] || o0 < 0.01f) continue
            }
            val an = if (inside) r.inside else r.outside
            rot(an.x, an.y - 0.40f, an.z)
            ringZ[i] = oz
            ringOrder[count] = i
            count++
        }
        for (p1 in 1 until count) {
            val key = ringOrder[p1]
            val kz = ringZ[key]
            var j = p1 - 1
            while (j >= 0 && ringZ[ringOrder[j]] > kz) {
                ringOrder[j + 1] = ringOrder[j]
                j--
            }
            ringOrder[j + 1] = key
        }

        val steps = 28
        for (q in 0 until count) {
            val idx = ringOrder[q]
            val r = rings[idx / 2]
            val inside = (idx % 2) == 1
            val an = if (inside) r.inside else r.outside
            val oRaw = if (inside) r.inOut else r.outOut
            val o = if (raw) max(oRaw, 0.35f) else oRaw.coerceIn(0f, 1f)

            // position + perspective scale
            rot(an.x, an.y - 0.40f, an.z)
            val s = persp(oz)
            val px = cx + ox * unit * s
            val py = cy - oy * unit * s
            // front-facing test: rotate the surface normal only
            val nl = sqrt(an.nx * an.nx + an.ny * an.ny + an.nz * an.nz).coerceAtLeast(1e-4f)
            rot(an.nx, an.ny, an.nz)
            val facing = oz / nl
            val vis = when {
                raw -> 1f
                inside -> 0.55f + 0.45f * max(0f, facing)
                else -> smooth01((facing + 0.2f) / 0.6f)
            }
            if (vis < 0.02f) continue
            val base = (if (inside) r.inColor else r.color) or (0xFF shl 24)

            val reg = r.region
            val wv = reg?.wave ?: 1f
            val mag = reg?.moveMag() ?: 0f
            val swX = sin(phase * 0.04f * wv) * 0.010f * mag
            val swY = cos(phase * 0.03f * wv) * 0.008f * mag

            // ── rings: concentric circles lying on the body surface (plane ⟂ normal) ──
            if (rb.ringsOn) {
                val nRing = (2 + ((reg?.centerFilt ?: 0.5f) * 3f).toInt()).coerceIn(2, 5)
                val nx = an.nx / nl
                val ny = an.ny / nl
                val nz = an.nz / nl
                val hx: Float
                val hy: Float
                val hz: Float
                if (abs(ny) < 0.9f) { hx = 0f; hy = 1f; hz = 0f } else { hx = 1f; hy = 0f; hz = 0f }
                var ux = ny * hz - nz * hy
                var uy = nz * hx - nx * hz
                var uz = nx * hy - ny * hx
                val ul = sqrt(ux * ux + uy * uy + uz * uz).coerceAtLeast(1e-4f)
                ux /= ul; uy /= ul; uz /= ul
                val vx = ny * uz - nz * uy
                val vy = nz * ux - nx * uz
                val vz = nx * uy - ny * ux
                line.style = Paint.Style.STROKE
                line.strokeWidth = max(1.2f, unit * 0.0055f * rb.ringWidth) * (0.8f + 0.2f * s)
                for (k in 0 until nRing) {
                    val rad = an.r * rb.ringScale *
                        (1f + k * 0.42f + 0.12f * sin(phase * 0.05f * wv + k * 1.3f) * o)
                    ringPath.reset()
                    for (st in 0..steps) {
                        val th = st * (2f * PI.toFloat() / steps)
                        val c = cos(th) * rad
                        val sn = sin(th) * rad
                        project(
                            cx, cy, unit,
                            an.x + swX + ux * c + vx * sn,
                            an.y + swY + uy * c + vy * sn,
                            an.z + uz * c + vz * sn
                        )
                        if (st == 0) ringPath.moveTo(prX, prY) else ringPath.lineTo(prX, prY)
                    }
                    ringPath.close()
                    val alpha = ((30f + 190f * o) * vis * (1f - k * 0.16f) * rb.ringLevel).toInt().coerceIn(0, 235)
                    line.color = shade(base, alpha, 0.95f + 0.25f * o, a.colourLevel, rb.tuning, raw, o)
                    canvas.drawPath(ringPath, line)
                }
            }

            // ── ball: a shaded sphere at the anchor (heart beats, eyes get iris + pupil) ──
            if (rb.ballsOn) {
                var br = an.r * rb.ballScale * 0.55f * (0.85f + 0.30f * o)
                if (r.heart && inside) {
                    br *= 1f + 0.12f * a.waveEff() * max(0f, sin(phase * 0.22f)).pow(3f) * (0.4f + o)
                }
                val alpha = ((45f + 200f * o) * vis * rb.ballLevel).toInt().coerceIn(0, 240)
                val light = 0.60f + 0.60f * o
                val col = shade(base, alpha, light, a.colourLevel, rb.tuning, raw, o)
                ellipsoid(
                    canvas, cx, cy, unit, 0.40f, an.x + swX, an.y + swY, an.z,
                    br, br, br, 0f, col, Color.alpha(col), light
                )
                if (r.eye && !inside && rb.eyeDetailOn) {
                    // the iris + pupil turn toward the centroid (left / right eye each with its own gaze)
                    val left = r.key == "eyeL"
                    val th = (if (left) a.gazeLx else a.gazeRx).coerceIn(-0.85f, 0.85f) * 0.38f
                    val ph = (if (left) a.gazeLy else a.gazeRy).coerceIn(-0.75f, 0.75f) * 0.32f
                    val fx = sin(th)
                    val fy = cos(th) * sin(ph)
                    val fz = cos(th) * cos(ph)
                    val iris = shade(0xFF29B6F6.toInt(), alpha, light, a.colourLevel, rb.tuning, raw, o)
                    val ri = br * 0.72f
                    ellipsoid(
                        canvas, cx, cy, unit, 0.40f, an.x + swX + ri * fx, an.y + swY + ri * fy, an.z + ri * fz,
                        br * 0.52f, br * 0.52f, br * 0.30f, 0f, iris, Color.alpha(iris), light
                    )
                    val pupil = shade(0xFF101010.toInt(), alpha, 0.9f, a.colourLevel, rb.tuning, raw, o)
                    val rp = br * 0.92f
                    val ps = a.pupilScale.coerceIn(0.5f, 1.6f)
                    // Complete eye layers (beyond iris/pupil): sclera rim · cornea gleam · lens ring · retina glow
                    val sclera = shade(0xFFECEFF1.toInt(), (alpha * 0.55f).toInt().coerceIn(20, 180), light * 0.7f, a.colourLevel, rb.tuning, raw, o)
                    ellipsoid(canvas, cx, cy, unit, 0.40f, an.x + swX, an.y + swY, an.z, br * 1.02f, br * 1.02f, br * 0.55f, 0f, sclera, Color.alpha(sclera).coerceAtMost(90), light * 0.6f)
                    val cornea = shade(0xFFB3E5FC.toInt(), (alpha * 0.35f).toInt().coerceIn(15, 120), light * 1.1f, a.colourLevel, rb.tuning, raw, o)
                    ellipsoid(canvas, cx, cy, unit, 0.40f, an.x + swX, an.y + swY, an.z + br * 0.08f, br * 0.48f, br * 0.48f, br * 0.22f, 0f, cornea, Color.alpha(cornea), light * 1.05f)
                    val lens = shade(0xFFE1F5FE.toInt(), (alpha * 0.40f).toInt().coerceIn(15, 140), light, a.colourLevel, rb.tuning, raw, o)
                    ellipsoid(canvas, cx, cy, unit, 0.40f, an.x + swX, an.y + swY, an.z - br * 0.02f, br * 0.30f, br * 0.30f, br * 0.18f, 0f, lens, Color.alpha(lens), light)
                    val retinaG = shade(0xFFE57373.toInt(), (alpha * 0.22f).toInt().coerceIn(10, 90), light * 0.5f, a.colourLevel, rb.tuning, raw, o)
                    ellipsoid(canvas, cx, cy, unit, 0.40f, an.x + swX, an.y + swY, an.z - br * 0.12f, br * 0.38f, br * 0.38f, br * 0.12f, 0f, retinaG, Color.alpha(retinaG), light * 0.5f)
                    ellipsoid(
                        canvas, cx, cy, unit, 0.40f, an.x + swX + rp * fx, an.y + swY + rp * fy, an.z + rp * fz,
                        br * 0.26f * ps, br * 0.26f * ps, br * 0.16f, 0f, pupil, Color.alpha(pupil), 0.9f
                    )
                }
            }

            if (rb.labelsOn && !inside) {
                textPaint.textSize = max(9f, unit * 0.045f)
                textPaint.color = Color.argb((210f * vis).toInt().coerceIn(0, 230), 255, 255, 255)
                canvas.drawText(r.label, px + an.r * unit * s * 1.4f, py, textPaint)
            }
        }
    }

    /** Project an eye socket through the exact anatomy turntable/perspective. */
    fun projectEyePosition(
        cx: Float,
        cy: Float,
        viewH: Float,
        a: Anatomy3DBoard,
        phase: Float,
        side: Float,
        separation: Float,
        verticalOffset: Float,
        modelSize: Float = a.size
    ): Pair<Float, Float> {
        val unit = viewH * modelSize.coerceIn(0.2f, 1.2f) / 2.7f
        setRotation(anatomyYaw(a, phase), a.tilt + motionTilt)
        val x = if (side == 0f) 0f else side * 0.062f * (separation / 0.12f)
        rot(x, 1.555f + verticalOffset - 0.40f, 0.141f)
        val scale = persp(oz)
        return (cx + ox * unit * scale) to (cy - oy * unit * scale)
    }

    companion object {
        private const val FOCAL = 4.2f
    }
    /** One extra HUD line for the ambient MOVEMENT output (drawn once, under the existing centroid lines). */
    fun drawMovementHud(canvas: Canvas, viewH: Float, board: AmbientThresholdBoard?) {
        val m = board?.movement ?: return
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        p.textSize = 28f
        p.color = 0xCCFFAB91.toInt()
        canvas.drawText(m.line(), 24f, viewH * 0.08f + 158f, p)
    }

    fun drawCentroidHud(canvas: Canvas, viewW: Float, viewH: Float, board: AmbientThresholdBoard?) {
        val b = board ?: return
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        p.textSize = 28f
        p.color = 0xCCE0F7FA.toInt()
        val x = 24f
        var y = viewH * 0.08f
        canvas.drawText("3D CEN ${b.centroidHz.toInt()}Hz ${"%+.0f".format(b.micDb())}dB", x, y, p)
        y += 34f
        p.color = 0xCCFFD54F.toInt()
        canvas.drawText(
            "DOM ${b.dominationHz.toInt()}Hz out=${(b.dominationOut*100).toInt()}% thr=${(b.dominationThr*100).toInt()}% lv=${(b.dominationLevel*100).toInt()}% ${if (b.dominationHit) "HIT" else "idle"}",
            x, y, p
        )
        y += 32f
        p.color = 0xCC80CBC4.toInt()
        canvas.drawText("IN  C${(b.insideCenOut*100).toInt()}% V${(b.insideVerOut*100).toInt()}%", x, y, p)
        y += 32f
        p.color = 0xCCFFCC80.toInt()
        canvas.drawText("OUT C${(b.outsideCenOut*100).toInt()}% V${(b.outsideVerOut*100).toInt()}%", x, y, p)
        y += 32f
        p.color = 0xCCB39DDB.toInt()
        canvas.drawText("IN-AMB ${b.insideHz.toInt()}Hz C${(b.insideCenOut*100).toInt()}% V${(b.insideVerOut*100).toInt()}%", x, y, p)
        y += 30f
        p.color = 0xCCA5D6A7.toInt()
        canvas.drawText(
            "ATOM ${b.centroidHz.toInt()}Hz DOM ${b.dominationHz.toInt()}Hz ${"%+.0f".format(b.micDb())}dB RAW ${if (b.rawEverything) "ON" else "off"}",
            x, y, p
        )
        // vertical marker on right
        val gx = viewW - 36f
        val top = viewH * 0.15f
        val bot = viewH * 0.85f
        p.strokeWidth = 4f
        p.color = 0x6680CBC4.toInt()
        canvas.drawLine(gx, top, gx, bot, p)
        val vy = bot - (bot - top) * b.verticalNorm.coerceIn(0f, 1f)
        p.color = 0xFFE0F7FA.toInt()
        canvas.drawCircle(gx, vy, 10f, p)
    }

    /** Inside-of-heart schematic (chambers + valves) driven by HeartInsideFullAmbientBoard. */
    fun drawHeartInside(canvas: Canvas, cx: Float, cy: Float, viewH: Float, b: HeartInsideFullAmbientBoard, phase: Float) {
        if (!b.enabled || b.heartFullOut < 0.02f) return
        val u = viewH * 0.12f * (0.7f + b.heartFullOut * 0.5f)
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        val hx = cx + u * 0.8f
        val hy = cy + u * 0.3f
        // myocardium body
        p.style = android.graphics.Paint.Style.FILL
        p.color = (0x55E57373.toInt())
        canvas.drawOval(hx - u * 1.1f, hy - u * 0.9f, hx + u * 1.1f, hy + u * 1.0f, p)
        // LV / RV chambers
        p.color = (0x88EF9A9A.toInt())
        canvas.drawOval(hx - u * 0.15f, hy - u * 0.2f, hx + u * 0.85f, hy + u * 0.75f, p) // LV
        p.color = (0x66FFCDD2.toInt())
        canvas.drawOval(hx - u * 0.95f, hy - u * 0.15f, hx - u * 0.05f, hy + u * 0.7f, p) // RV
        // atria
        p.color = (0x77FFAB91.toInt())
        canvas.drawCircle(hx + u * 0.35f, hy - u * 0.55f, u * 0.35f * (0.6f + b.leftAtrium), p)
        canvas.drawCircle(hx - u * 0.45f, hy - u * 0.5f, u * 0.32f * (0.6f + b.rightAtrium), p)
        // valves as arcs
        p.style = android.graphics.Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = 0xCCFFFFFF.toInt()
        canvas.drawLine(hx - u * 0.3f, hy + u * 0.1f, hx + u * 0.1f, hy + u * 0.15f, p) // tricuspid zone
        canvas.drawLine(hx + u * 0.1f, hy + u * 0.05f, hx + u * 0.5f, hy + u * 0.1f, p) // mitral
        // aorta / pulmonary trunk
        p.color = 0xAAEF5350.toInt()
        canvas.drawLine(hx + u * 0.2f, hy - u * 0.7f, hx + u * 0.25f, hy - u * 1.35f, p)
        p.color = 0xAA42A5F5.toInt()
        canvas.drawLine(hx - u * 0.1f, hy - u * 0.65f, hx + u * 0.05f, hy - u * 1.25f, p)
        // label
        p.style = android.graphics.Paint.Style.FILL
        p.textSize = 22f
        p.color = 0xEEFFCDD2.toInt()
        canvas.drawText("HEART-IN ${(b.heartFullOut*100).toInt()}%", hx - u, hy + u * 1.25f, p)
    }

    /** Neuron field particles over brain region. */
    fun drawNeuronField(canvas: Canvas, cx: Float, cy: Float, viewH: Float, b: NeuralNeurotransmitterAmbientBoard, phase: Float) {
        if (!b.enabled || b.neuronField < 0.02f) return
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        p.style = android.graphics.Paint.Style.FILL
        val n = (12 + (b.synapseDensity * 20).toInt()).coerceIn(8, 40)
        val r0 = viewH * 0.08f
        for (i in 0 until n) {
            val a = phase * 1.7f + i * 0.55f
            val rr = r0 * (0.4f + (i % 5) * 0.12f) * (0.6f + b.neuronField)
            val x = cx + kotlin.math.cos(a) * rr * 1.4f
            val y = cy - viewH * 0.28f + kotlin.math.sin(a * 1.3f) * rr
            val alpha = (80 + b.neuronField * 140).toInt().coerceIn(40, 220)
            p.color = (alpha shl 24) or 0x00CE93D8
            canvas.drawCircle(x, y, 4f + b.axonSignal * 3f, p)
        }
        p.textSize = 20f
        p.color = 0xEECE93D8.toInt()
        canvas.drawText("NEURON ${(b.neuronField*100).toInt()}% safe=${(b.safeNeuronOut*100).toInt()}%", cx - viewH * 0.12f, cy - viewH * 0.38f, p)
    }


    fun drawBodyOils3D(
        canvas: android.graphics.Canvas,
        cx: Float,
        cy: Float,
        viewH: Float,
        intensity: Float,
        phase: Float,
        modelSize: Float
    ) {
        val i = intensity.coerceIn(0f, 1f)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.FILL
        val n = (8 + (i * 12).toInt()).coerceIn(8, 20)
        for (k in 0 until n) {
            val ang = phase * 0.7f + k * (6.2832f / n)
            val rr = modelSize * (0.18f + 0.22f * i) * (0.7f + 0.3f * kotlin.math.sin(phase + k))
            val x = cx + kotlin.math.cos(ang) * rr * 0.55f
            val y = cy + kotlin.math.sin(ang) * rr * 0.9f - viewH * 0.05f
            val rad = modelSize * (0.03f + 0.04f * i) * (0.8f + 0.2f * kotlin.math.sin(phase * 1.3f + k))
            val alpha = (70 + (i * 120).toInt()).coerceIn(40, 200)
            // warm oil amber
            paint.color = android.graphics.Color.argb(alpha, 255, 180, 60)
            canvas.drawCircle(x, y, rad, paint)
            paint.color = android.graphics.Color.argb(alpha / 2, 255, 220, 120)
            canvas.drawCircle(x - rad * 0.2f, y - rad * 0.2f, rad * 0.45f, paint)
        }
    }

    fun drawWaterChem3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.FILL
        val n = (10 + (i * 14).toInt()).coerceIn(10, 24)
        for (k in 0 until n) {
            val ang = phase * 0.5f + k * (6.2832f / n)
            val rr = modelSize * (0.15f + 0.35f * i) * (0.75f + 0.25f * kotlin.math.sin(phase + k * 0.7f))
            val x = cx + kotlin.math.cos(ang) * rr * 0.5f
            val y = cy + kotlin.math.sin(ang) * rr * 0.95f
            val rad = modelSize * (0.025f + 0.03f * i)
            val a = (50 + (i * 140).toInt()).coerceIn(30, 200)
            // water cyan
            paint.color = android.graphics.Color.argb(a, 80, 200, 255)
            canvas.drawCircle(x, y, rad, paint)
            // chem tint magenta dots
            if (k % 3 == 0) {
                paint.color = android.graphics.Color.argb(a / 2, 255, 100, 200)
                canvas.drawCircle(x + rad, y - rad, rad * 0.4f, paint)
            }
        }
    }
    fun drawNeuroCells3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 2f + i * 3f
        val n = (6 + (i * 8).toInt()).coerceIn(6, 14)
        for (k in 0 until n) {
            val ang = phase * 0.9f + k * (6.2832f / n)
            val rr = modelSize * 0.12f
            val hx = cx + kotlin.math.cos(ang) * modelSize * 0.2f
            val hy = cy - viewH * 0.28f + kotlin.math.sin(ang) * modelSize * 0.12f
            val a = (90 + (i * 120).toInt()).coerceIn(50, 220)
            paint.color = android.graphics.Color.argb(a, 180, 120, 255)
            canvas.drawCircle(hx, hy, rr * (0.3f + 0.2f * i), paint)
            // dendrite lines
            for (d in 0 until 3) {
                val da = ang + d * 2.1f
                canvas.drawLine(hx, hy, hx + kotlin.math.cos(da) * rr, hy + kotlin.math.sin(da) * rr, paint)
            }
        }
    }
    fun drawNonNerveCells3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.FILL
        val n = (12 + (i * 10).toInt()).coerceIn(12, 22)
        for (k in 0 until n) {
            val ang = phase * 0.4f + k * (6.2832f / n)
            val x = cx + kotlin.math.cos(ang) * modelSize * 0.28f * (0.6f + 0.4f * i)
            val y = cy + kotlin.math.sin(ang) * modelSize * 0.5f
            val rad = modelSize * 0.02f * (1f + i)
            val a = (40 + (i * 100).toInt()).coerceIn(25, 160)
            paint.color = android.graphics.Color.argb(a, 120, 220, 140)
            canvas.drawCircle(x, y, rad, paint)
        }
    }
    fun drawGlands3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.FILL
        // pituitary / thyroid / adrenal symbolic positions
        val pts = floatArrayOf(
            0f, -0.32f,   // pituitary
            0f, -0.18f,   // thyroid
            -0.12f, 0.05f, // adrenal L
            0.12f, 0.05f,  // adrenal R
            0f, 0.15f      // pancreas area
        )
        for (k in 0 until 5) {
            val x = cx + pts[k * 2] * modelSize
            val y = cy + pts[k * 2 + 1] * viewH * 0.9f
            val rad = modelSize * (0.035f + 0.02f * i) * (0.9f + 0.1f * kotlin.math.sin(phase + k))
            val a = (70 + (i * 130).toInt()).coerceIn(40, 210)
            paint.color = android.graphics.Color.argb(a, 255, 160, 80)
            canvas.drawCircle(x, y, rad, paint)
        }
    }
    fun drawEyeSkinWater3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.FILL
        val eyeY = cy - viewH * 0.30f
        for (side in floatArrayOf(-1f, 1f)) {
            val ex = cx + side * modelSize * 0.12f
            val a = (80 + (i * 120).toInt()).coerceIn(40, 210)
            // eye wet / tear film
            paint.color = android.graphics.Color.argb(a, 100, 210, 255)
            canvas.drawCircle(ex, eyeY, modelSize * 0.04f * (0.8f + 0.2f * i), paint)
            // skin ring
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = 2f + i * 2f
            paint.color = android.graphics.Color.argb(a, 255, 200, 180)
            canvas.drawCircle(ex, eyeY, modelSize * 0.06f, paint)
            paint.style = android.graphics.Paint.Style.FILL
        }
    }

    fun drawAnatomy360(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 1.5f + i * 2f
        val a = (50 + (i * 120).toInt()).coerceIn(30, 180)
        paint.color = android.graphics.Color.argb(a, 100, 255, 180)
        // silhouette rings front/back emphasis
        canvas.drawCircle(cx, cy, modelSize * (0.35f + 0.1f * i), paint)
        canvas.drawCircle(cx, cy - viewH * 0.05f, modelSize * (0.22f + 0.08f * i), paint)
        canvas.drawOval(cx - modelSize * 0.2f, cy + viewH * 0.15f, cx + modelSize * 0.2f, cy + viewH * 0.45f, paint)
    }
    fun drawChannels3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 2f + i * 2f
        val a = (60 + (i * 130).toInt()).coerceIn(40, 200)
        // vertical channel (spine/nerve/blood)
        paint.color = android.graphics.Color.argb(a, 255, 80, 80)
        canvas.drawLine(cx, cy - viewH * 0.35f, cx, cy + viewH * 0.4f, paint)
        paint.color = android.graphics.Color.argb(a, 80, 180, 255)
        canvas.drawLine(cx - modelSize * 0.08f, cy - viewH * 0.3f, cx - modelSize * 0.08f, cy + viewH * 0.35f, paint)
        paint.color = android.graphics.Color.argb(a, 180, 255, 100)
        canvas.drawLine(cx + modelSize * 0.08f, cy - viewH * 0.3f, cx + modelSize * 0.08f, cy + viewH * 0.35f, paint)
    }
    fun drawQuantumDots3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.FILL
        val n = (15 + (i * 20).toInt()).coerceIn(15, 40)
        for (k in 0 until n) {
            val ang = phase * 1.2f + k * 0.7f
            val r = modelSize * (0.05f + 0.4f * ((k % 7) / 7f)) * i
            val x = cx + kotlin.math.cos(ang) * r
            val y = cy + kotlin.math.sin(ang * 1.3f) * r * 1.2f
            val a = (40 + (i * 100).toInt()).coerceIn(20, 160)
            paint.color = android.graphics.Color.argb(a, 200, 200, 255)
            canvas.drawCircle(x, y, 2f + i * 3f, paint)
        }
    }
    fun drawEyeIctPoint3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.FILL
        val a = (100 + (i * 120).toInt()).coerceIn(60, 230)
        val eyeY = cy - viewH * 0.30f
        for (side in floatArrayOf(-1f, 1f)) {
            val ex = cx + side * modelSize * 0.12f
            paint.color = android.graphics.Color.argb(a, 0, 255, 200)
            canvas.drawCircle(ex, eyeY, modelSize * 0.025f * (1f + i), paint)
            // ICT ray toward camera center
            paint.strokeWidth = 1.5f
            paint.style = android.graphics.Paint.Style.STROKE
            paint.color = android.graphics.Color.argb(a / 2, 0, 255, 180)
            canvas.drawLine(ex, eyeY, cx, cy - viewH * 0.05f, paint)
            paint.style = android.graphics.Paint.Style.FILL
        }
    }

    fun drawEyeBodyLink3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 2f + i * 3f
        val a = (70 + (i * 140).toInt()).coerceIn(40, 220)
        paint.color = android.graphics.Color.argb(a, 0, 220, 255)
        val eyeY = cy - viewH * 0.30f
        canvas.drawLine(cx - modelSize * 0.12f, eyeY, cx, cy, paint)
        canvas.drawLine(cx + modelSize * 0.12f, eyeY, cx, cy, paint)
        paint.color = android.graphics.Color.argb(a / 2, 100, 255, 200)
        canvas.drawCircle(cx, cy, modelSize * (0.2f + 0.15f * i), paint)
    }
    fun drawKopalSurface(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.FILL
        val a = (60 + (i * 130).toInt()).coerceIn(30, 200)
        paint.color = android.graphics.Color.argb(a, 255, 200, 120)
        val kopalY = cy - viewH * 0.36f
        canvas.drawOval(cx - modelSize * 0.14f * (0.8f + 0.2f * i), kopalY - modelSize * 0.05f, cx + modelSize * 0.14f * (0.8f + 0.2f * i), kopalY + modelSize * 0.06f, paint)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 1.5f + i * 2f
        paint.color = android.graphics.Color.argb(a, 255, 240, 180)
        canvas.drawCircle(cx, kopalY, modelSize * (0.12f + 0.05f * kotlin.math.sin(phase)), paint)
    }
    fun drawWhiteSurface(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.FILL
        val a = (40 + (i * 150).toInt()).coerceIn(25, 200)
        paint.color = android.graphics.Color.argb(a, 255, 255, 255)
        canvas.drawCircle(cx - modelSize * 0.08f, cy, modelSize * (0.28f + 0.1f * i), paint)
        canvas.drawCircle(cx + modelSize * 0.08f, cy, modelSize * (0.28f + 0.1f * i), paint)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 2f + i * 2.5f
        paint.color = android.graphics.Color.argb(minOf(255, a + 40), 255, 255, 255)
        canvas.drawCircle(cx, cy, modelSize * (0.38f + 0.08f * kotlin.math.sin(phase * 2f)), paint)
    }
    fun drawDualSelf(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 2f + i * 2f
        val a = (80 + (i * 120).toInt()).coerceIn(50, 210)
        paint.color = android.graphics.Color.argb(a, 80, 220, 255)
        canvas.drawCircle(cx - modelSize * 0.1f, cy - viewH * 0.02f, modelSize * 0.18f * i, paint)
        paint.color = android.graphics.Color.argb(a, 255, 200, 80)
        canvas.drawCircle(cx + modelSize * 0.1f, cy + viewH * 0.02f, modelSize * 0.18f * i, paint)
        paint.color = android.graphics.Color.argb(a, 255, 255, 255)
        canvas.drawLine(cx - modelSize * 0.1f, cy, cx + modelSize * 0.1f, cy, paint)
    }
    fun drawBodyAtomSurface(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 1.5f + i * 2.5f
        val a = (50 + (i * 130).toInt()).coerceIn(30, 200)
        paint.color = android.graphics.Color.argb(a, 120, 255, 180)
        val n = (6 + (i * 6).toInt()).coerceIn(6, 12)
        for (k in 0 until n) {
            val ang = phase * 0.6f + k * (6.2832f / n)
            val rr = modelSize * (0.3f + 0.15f * i)
            canvas.drawCircle(cx + kotlin.math.cos(ang) * rr * 0.15f, cy + kotlin.math.sin(ang) * rr * 0.4f, rr * (0.85f + 0.1f * kotlin.math.sin(phase + k)), paint)
        }
    }
    fun drawBulletWeapon3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.FILL
        val a = (90 + (i * 140).toInt()).coerceIn(50, 230)
        paint.color = android.graphics.Color.argb(a, 255, 220, 60)
        val n = (4 + (i * 6).toInt()).coerceIn(4, 10)
        for (k in 0 until n) {
            val ang = phase * 2.5f + k * (6.2832f / n)
            val rr = modelSize * (0.15f + 0.35f * i)
            val x = cx + kotlin.math.cos(ang) * rr
            val y = cy + kotlin.math.sin(ang) * rr * 0.8f
            // bullet oval
            canvas.drawOval(x - 4f * i, y - 2f, x + 8f * i, y + 2f, paint)
            // trail
            paint.color = android.graphics.Color.argb(a / 2, 255, 180, 40)
            canvas.drawLine(x, y, x - kotlin.math.cos(ang) * 12f * i, y - kotlin.math.sin(ang) * 8f * i, paint)
            paint.color = android.graphics.Color.argb(a, 255, 220, 60)
        }
    }
    fun drawKnifeWeapon3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 2f + i * 3f
        val a = (90 + (i * 140).toInt()).coerceIn(50, 230)
        paint.color = android.graphics.Color.argb(a, 200, 220, 255)
        val n = (3 + (i * 4).toInt()).coerceIn(3, 7)
        for (k in 0 until n) {
            val ang = phase * 1.8f + k * (6.2832f / n)
            val rr = modelSize * (0.2f + 0.25f * i)
            val x = cx + kotlin.math.cos(ang) * rr
            val y = cy + kotlin.math.sin(ang) * rr * 0.9f
            val len = modelSize * 0.12f * i
            // blade line
            canvas.drawLine(x, y, x + kotlin.math.cos(ang + 0.5f) * len, y + kotlin.math.sin(ang + 0.5f) * len, paint)
            // edge flash
            paint.color = android.graphics.Color.argb(a / 2, 255, 255, 255)
            canvas.drawLine(x, y, x + kotlin.math.cos(ang - 0.3f) * len * 0.6f, y + kotlin.math.sin(ang - 0.3f) * len * 0.6f, paint)
            paint.color = android.graphics.Color.argb(a, 200, 220, 255)
        }
    }
    fun drawWhipWeapon3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 1.5f + i * 2.5f
        val a = (80 + (i * 130).toInt()).coerceIn(40, 210)
        paint.color = android.graphics.Color.argb(a, 255, 140, 80)
        val path = android.graphics.Path()
        val segs = 12
        path.moveTo(cx, cy - viewH * 0.1f)
        for (k in 1..segs) {
            val t = k / segs.toFloat()
            val wave = kotlin.math.sin(phase * 3f + t * 8f) * modelSize * 0.12f * i
            path.lineTo(cx + wave, cy - viewH * 0.1f + t * modelSize * 0.55f)
        }
        canvas.drawPath(path, paint)
        // tip crack
        paint.style = android.graphics.Paint.Style.FILL
        paint.color = android.graphics.Color.argb(a, 255, 200, 100)
        val tipY = cy - viewH * 0.1f + modelSize * 0.55f
        val tipX = cx + kotlin.math.sin(phase * 3f + 8f) * modelSize * 0.12f * i
        canvas.drawCircle(tipX, tipY, 3f + i * 4f, paint)
    }
    fun drawBurstWeapon3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 2f + i * 2f
        val a = (70 + (i * 140).toInt()).coerceIn(40, 220)
        paint.color = android.graphics.Color.argb(a, 255, 80, 40)
        val rings = (2 + (i * 3).toInt()).coerceIn(2, 5)
        for (r in 0 until rings) {
            val rad = modelSize * (0.1f + 0.12f * r + 0.15f * i) * (0.9f + 0.1f * kotlin.math.sin(phase * 4f + r))
            canvas.drawCircle(cx, cy, rad, paint)
        }
        // radial spokes
        paint.color = android.graphics.Color.argb(a / 2, 255, 180, 60)
        for (k in 0 until 8) {
            val ang = phase + k * (6.2832f / 8f)
            canvas.drawLine(cx, cy, cx + kotlin.math.cos(ang) * modelSize * 0.4f * i, cy + kotlin.math.sin(ang) * modelSize * 0.4f * i, paint)
        }
    }
    fun drawArrowWeapon3D(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 2f + i * 2f
        val a = (80 + (i * 130).toInt()).coerceIn(40, 210)
        paint.color = android.graphics.Color.argb(a, 100, 255, 120)
        val n = (2 + (i * 3).toInt()).coerceIn(2, 5)
        for (k in 0 until n) {
            val ang = phase * 1.2f + k * (6.2832f / n)
            val x0 = cx + kotlin.math.cos(ang) * modelSize * 0.1f
            val y0 = cy + kotlin.math.sin(ang) * modelSize * 0.1f
            val x1 = cx + kotlin.math.cos(ang) * modelSize * (0.35f + 0.15f * i)
            val y1 = cy + kotlin.math.sin(ang) * modelSize * (0.35f + 0.15f * i)
            canvas.drawLine(x0, y0, x1, y1, paint)
            // arrowhead
            paint.style = android.graphics.Paint.Style.FILL
            canvas.drawCircle(x1, y1, 3f + i * 3f, paint)
            paint.style = android.graphics.Paint.Style.STROKE
        }
    }

    fun drawEyeOtherSelfComm(canvas: android.graphics.Canvas, cx: Float, cy: Float, viewH: Float, i: Float, phase: Float, modelSize: Float) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 2f + i * 3f
        val a = (90 + (i * 140).toInt()).coerceIn(50, 230)
        val eyeY = cy - viewH * 0.30f
        // This-self eyes
        paint.color = android.graphics.Color.argb(a, 0, 255, 220)
        canvas.drawCircle(cx - modelSize * 0.12f, eyeY, modelSize * 0.03f * (1f + i), paint)
        canvas.drawCircle(cx + modelSize * 0.12f, eyeY, modelSize * 0.03f * (1f + i), paint)
        // Other-self eyes (offset mirror)
        val ox = cx + modelSize * 0.35f * kotlin.math.sin(phase * 0.5f)
        val oy = cy + viewH * 0.05f
        paint.color = android.graphics.Color.argb(a, 255, 180, 80)
        canvas.drawCircle(ox - modelSize * 0.1f, oy - viewH * 0.12f, modelSize * 0.025f * (1f + i), paint)
        canvas.drawCircle(ox + modelSize * 0.1f, oy - viewH * 0.12f, modelSize * 0.025f * (1f + i), paint)
        // Visual communication beams eye → other self
        paint.color = android.graphics.Color.argb(a / 2, 255, 255, 255)
        canvas.drawLine(cx - modelSize * 0.12f, eyeY, ox - modelSize * 0.1f, oy - viewH * 0.12f, paint)
        canvas.drawLine(cx + modelSize * 0.12f, eyeY, ox + modelSize * 0.1f, oy - viewH * 0.12f, paint)
        // Return path (dashed feel via second thinner line)
        paint.strokeWidth = 1f + i
        paint.color = android.graphics.Color.argb(a / 3, 180, 255, 255)
        canvas.drawLine(ox, oy - viewH * 0.12f, cx, eyeY, paint)
        // Other-self body outline
        paint.strokeWidth = 1.5f + i * 2f
        paint.color = android.graphics.Color.argb(a / 2, 255, 200, 100)
        canvas.drawCircle(ox, oy, modelSize * (0.2f + 0.1f * i), paint)
    }

}
