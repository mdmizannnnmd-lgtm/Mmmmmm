package com.mizan

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView

/**
 * Native control surface for the Atmospheric Audio Studio screenshot features.
 * Every control below writes to the live renderer/audio/camera/model engines.
 */
object AtmosphericAudioStudioPanel {

    private const val PREF = "atmo_studio_"
    private val cyan = Color.rgb(0x26, 0xC6, 0xDA)
    private val violet = Color.rgb(0xCE, 0x93, 0xD8)
    private val amber = Color.rgb(0xFF, 0xCA, 0x28)
    private var handler: Handler? = null
    private var updater: Runnable? = null

    fun build(
        activity: MainActivity,
        root: LinearLayout,
        view: VisualShieldView,
        audio: AudioProcessor
    ) {
        stop()
        root.removeAllViews()
        val feedback = view.videoFeedbackBoard
        val colour = view.audioColourBoard
        val movement = view.virtualMovementBoards
        feedback.audioColourRef = colour
        restore(feedback, colour, movement, view)

        val p = PanelBuilder(activity, root)
        p.title("ATMOSPHERIC AUDIO STUDIO", cyan)
        p.note("Audio-reactive colour, feedback trails, camera motion and model controls. Mic/camera measurements are processed on-device.")

        val engineButton = p.button("Initialize Effects Engine") {
            feedback.enabled = !feedback.enabled
            MemoryPaths.putBool(PREF + "engine", feedback.enabled)
            if (!feedback.enabled) feedback.releaseLoop()
            view.invalidate()
        }
        val presetStatus = p.status(
            "Preset · ${MemoryPaths.getString(PREF + "preset", "Custom") ?: "Custom"}",
            violet
        )

        p.title("FEEDBACK PRESETS", violet)
        buttonGrid(activity, root, listOf(
            "Tunnel", "Spiral", "Glitch", "Pulse",
            "Freeze", "Burn", "Mirror", "RAW*"
        )) { name ->
            applyFeedbackPreset(name, feedback, colour)
            MemoryPaths.putString(PREF + "preset", name)
            presetStatus.text = "Preset · $name · RAW keeps safety caps"
            view.invalidate()
        }

        bindSwitch(p, "feedback_loop", "Video feedback loop", feedback.vfOn) {
            feedback.vfOn = it
            if (!it && !feedback.cfOn) feedback.releaseLoop()
            view.invalidate()
        }
        bindSwitch(p, "freeze_frame", "Freeze current feedback frame", feedback.freezeFrame) {
            feedback.freezeFrame = it
            view.invalidate()
        }
        bindSwitch(p, "camera_feedback", "Camera feedback modulation", feedback.cfOn) {
            feedback.cfOn = it
            view.invalidate()
        }
        bindSeek(p, "camera_mix", "Camera feedback mix", 0f, 1f, feedback.cfMix, 2) { feedback.cfMix = it }
        bindSwitch(p, "camera_exposure_follow", "Follow safe brightness on camera exposure", feedback.camExposureFollow) {
            feedback.camExposureFollow = it
        }
        bindSwitch(p, "invert", "Invert image colours", feedback.invertColors) {
            feedback.invertColors = it
            view.invalidate()
        }

        p.title("BRIGHTNESS / CONTRAST", violet)
        bindSeek(p, "brightness", "Brightness · 1 = neutral", 0f, 2f, feedback.brightness + 1f, 2) {
            feedback.brightness = (it - 1f).coerceIn(-1f, 1f)
            view.invalidate()
        }
        bindSeek(p, "contrast", "Contrast", 0f, 2.5f, feedback.contrast, 2) {
            feedback.contrast = it
            view.invalidate()
        }
        bindSeek(p, "saturation", "Saturation", 0f, 2.5f, feedback.colour, 2) {
            feedback.colour = it
            view.invalidate()
        }
        bindSeek(p, "hue", "Hue rotate · degrees", -180f, 180f, feedback.hue, 0) {
            feedback.hue = it
            view.invalidate()
        }

        p.title("FEEDBACK LOOP", violet)
        bindSeek(p, "strength", "Strength", 0f, 1f, feedback.vfGain, 2) { feedback.vfGain = it }
        bindSeek(p, "zoom", "Zoom / frame", 0f, 1f, feedback.vfZoom, 2) { feedback.vfZoom = it }
        bindSeek(p, "rotation", "Rotation / frame", 0f, 1f, feedback.vfRotate, 2) { feedback.vfRotate = it }
        bindSeek(p, "trail", "Trail decay", 0f, 0.98f, feedback.trailDecay, 2) { feedback.trailDecay = it }
        addSpinner(activity, root, "Blend mode", arrayOf(
            "Screen", "Overlay", "Multiply", "Lighter", "Difference",
            "Exclusion", "Hard light", "Soft light", "Color dodge"
        ), feedback.blendMode.coerceIn(0, 8)) { index ->
            feedback.blendMode = index
            MemoryPaths.putFloat(PREF + "blend", index.toFloat())
        }
        bindSwitch(p, "pixel_wave", "Glitch wave displacement", feedback.pixelWaveOn) {
            feedback.pixelWaveOn = it
        }
        bindSeek(p, "pixel_wave_amp", "Wave amplitude · limited", 0f, 0.08f, feedback.pixelWaveAmp, 3) {
            feedback.pixelWaveAmp = it.coerceIn(0f, 0.08f)
        }
        p.title("RAW TOWS · LOOP SAFETY REMAINS ACTIVE", Color.rgb(0xEF, 0x6A, 0x6A))
        bindSwitch(p, "raw_tows", "RAW overdrive mode · hard gain ceiling stays on", feedback.rawTowsOn) {
            feedback.rawTowsOn = it
        }
        bindSwitch(p, "raw_pass", "RAW pass · bypass colour filters only", feedback.rawPass) {
            feedback.rawPass = it
            view.invalidate()
        }
        bindSeek(p, "overdrive", "Overdrive · capped at the safe gain ceiling", 1f, 6f, feedback.overdrive, 2) {
            feedback.overdrive = it
        }

        p.title("AUDIO-REACTIVE · LIVE MICROPHONE", cyan)
        val micButton = p.button(if (audio.microphoneConnected) "Disconnect Mic" else "Connect Mic") {
            if (audio.microphoneConnected) {
                audio.stopListening()
            } else {
                audio.startListening(activity)
            }
        }
        bindSwitch(p, "audio_reactive", "Audio-reactive effects", feedback.audioReactiveOn) {
            feedback.audioReactiveOn = it
        }
        bindSeek(p, "audio_brightness", "RMS → brightness", 0f, 1f, feedback.audioBrightnessMix, 2) {
            feedback.audioBrightnessMix = it
        }
        bindSeek(p, "audio_zoom", "Bass → zoom", 0f, 1f, feedback.audioZoomMix, 2) {
            feedback.audioZoomMix = it
        }
        bindSeek(p, "audio_strength", "Bass → strength", 0f, 1f, feedback.audioStrengthMix, 2) {
            feedback.audioStrengthMix = it
        }
        bindSeek(p, "audio_rotation", "Mid → rotation", 0f, 1f, feedback.audioRotateMix, 2) {
            feedback.audioRotateMix = it
        }
        bindSeek(p, "audio_hue", "High → hue", 0f, 1f, feedback.audioHueMix, 2) {
            feedback.audioHueMix = it
        }

        p.title("AUDIO COLOUR", violet)
        bindSwitch(p, "audio_colour", "Microphone drives brightness / contrast / saturation", colour.enabled) {
            colour.enabled = it
        }
        bindSwitch(p, "audio_colour_invert", "Invert audio response", colour.invert) {
            colour.invert = it
        }
        bindSwitch(p, "audio_colour_raw", "RAW response · bypass threshold/smoothing only", colour.rawComplete) {
            colour.rawComplete = it
        }
        bindSeek(p, "audio_colour_threshold", "Audio threshold", 0f, 0.95f, colour.thr, 2) { colour.thr = it }
        bindSeek(p, "audio_colour_sensitivity", "Input sensitivity", 0f, 3f, colour.sens, 2) { colour.sens = it }
        bindSeek(p, "audio_colour_brightness", "Brightness amount", 0f, 1f, colour.brightnessAmt, 2) {
            colour.brightnessAmt = it
        }
        bindSeek(p, "audio_colour_contrast", "Contrast amount", 0f, 1f, colour.contrastAmt, 2) {
            colour.contrastAmt = it
        }
        bindSeek(p, "audio_colour_saturation", "Saturation amount", 0f, 1f, colour.levelAmt, 2) {
            colour.levelAmt = it
        }
        p.note("Flash limiter is always enabled; RAW does not bypass it.")

        p.title("VISUAL PROTECTION", amber)
        bindSwitch(p, "protection", "Visual protection enabled", feedback.protectionOn) {
            feedback.protectionOn = it
            view.invalidate()
        }
        buttonGrid(activity, root, listOf("Off", "Safe", "Soft", "Medium", "Hard", "Blackout")) { name ->
            applyProtectionPreset(name, feedback)
            MemoryPaths.putString(PREF + "protection_preset", name)
            view.invalidate()
        }
        bindSeek(p, "max_brightness", "Maximum brightness", 0f, 2f, feedback.maxBrightness, 2) {
            feedback.maxBrightness = it
        }
        bindSeek(p, "max_contrast", "Maximum contrast", 0f, 2.5f, feedback.maxContrast, 2) {
            feedback.maxContrast = it
        }
        bindSeek(p, "max_strength", "Maximum feedback strength", 0f, VideoFeedbackBoard.MAX_GAIN, feedback.maxStrength, 2) {
            feedback.maxStrength = it
        }
        bindSwitch(p, "feedback_gate_on", "Feedback threshold gate", feedback.fbThrOn) {
            feedback.fbThrOn = it
        }
        bindSeek(p, "feedback_threshold", "Feedback gate threshold", 0.05f, 1f, feedback.fbThr, 2) {
            feedback.fbThr = it
        }
        bindSeek(p, "feedback_rail", "Feedback gate rail", 0f, 1f, feedback.fbRail / 255f, 2) {
            feedback.fbRail = (it * 255f).toInt().coerceIn(0, 255)
        }

        p.title("MOTION DETECTION", cyan)
        bindSwitch(p, "motion_detection", "Camera motion drives effects", feedback.motionDetectionOn) {
            feedback.motionDetectionOn = it
            view.invalidate()
        }
        bindSeek(p, "camera_power", "Camera power · multiplier", 0f, 2f, feedback.cameraPower, 2) {
            feedback.cameraPower = it
        }
        bindSeek(p, "motion_sensitivity", "Sensitivity · ×", 0f, 2f, feedback.motionSensitivity, 2) {
            feedback.motionSensitivity = it
        }
        bindSeek(p, "move_gate", "Movement gate", 0f, 1f, feedback.motionMoveGate, 2) {
            feedback.motionMoveGate = it
        }
        bindSeek(p, "speed_gate", "Speed gate", 0f, 1f, feedback.motionSpeedGate, 2) {
            feedback.motionSpeedGate = it
        }
        bindSeek(p, "wave_gate", "Wave gate", 0f, 1f, feedback.motionWaveGate, 2) {
            feedback.motionWaveGate = it
        }
        bindSeek(p, "motion_strength", "Motion → strength", 0f, 2f, feedback.motionStrengthMix, 2) {
            feedback.motionStrengthMix = it
        }
        bindSeek(p, "motion_zoom", "Motion → zoom", 0f, 0.5f, feedback.motionZoomMix, 2) {
            feedback.motionZoomMix = it
        }
        bindSeek(p, "motion_rotation", "Motion → rotation · degrees", 0f, 10f, feedback.motionRotateMix, 2) {
            feedback.motionRotateMix = it
        }
        bindSeek(p, "motion_hue", "Motion → hue", 0f, 120f, feedback.motionHueMix, 0) {
            feedback.motionHueMix = it
        }

        p.title("MOVE SETTINGS · 3D MODEL")
        bindSeek(p, "movement_speed", "Movement speed", 0.1f, 2f, movement.movementSpeed, 2) {
            movement.movementSpeed = it
        }
        addSpinner(activity, root, "Direction", VirtualMovementControlBoard.DIRECTION_NAMES,
            movement.movementDirection.coerceIn(0, 3)) {
            movement.movementDirection = it
            MemoryPaths.putFloat(PREF + "direction", it.toFloat())
        }
        addSpinner(activity, root, "Easing function", VirtualMovementControlBoard.EASING_NAMES,
            movement.easing.coerceIn(0, 3)) {
            movement.easing = it
            MemoryPaths.putFloat(PREF + "easing", it.toFloat())
        }

        p.title("ATOMSPARE SPEED CONTROLLER", violet)
        buttonGrid(activity, root, listOf("Freeze", "Drift", "Unit", "Surge", "Hyper", "Max")) { preset ->
            movement.manualAtomSpeed = when (preset) {
                "Freeze" -> 0f
                "Drift" -> 0.25f
                "Surge" -> 8f
                "Hyper" -> 50f
                "Max" -> 100f
                else -> 1f
            }
            MemoryPaths.putFloat(PREF + "atom_speed", movement.manualAtomSpeed)
        }
        bindSeek(p, "atom_speed", "Virtual Atom Speed · 0–100×", 0f, 100f, movement.manualAtomSpeed, 2) {
            movement.manualAtomSpeed = it
        }
        bindSeek(p, "warp_factor", "Warp factor · 0–2", 0f, 2f, movement.manualWarpFactor, 2) {
            movement.manualWarpFactor = it
        }
        bindSeek(p, "resonance", "Resonance", 0f, 1f, movement.resonance, 2) { movement.resonance = it }
        bindSeek(p, "inertia", "Inertia", 0f, 1f, movement.inertia, 2) { movement.inertia = it }
        bindSeek(p, "hover_speed", "Hover speed", 0f, 8f, movement.manualHoverSpeed, 2) {
            movement.manualHoverSpeed = it
        }
        bindSwitch(p, "phase_sync", "Phase sync", movement.phaseSync) { movement.phaseSync = it }
        bindSwitch(p, "stutter_gate", "Stutter gate", movement.stutterGate) { movement.stutterGate = it }
        bindSwitch(p, "virtual_overdrive", "Virtual overdrive · speed capped at 100×", movement.virtualOverdrive) {
            movement.virtualOverdrive = it
        }

        p.title("VIRTUAL MOVEMENT CONTROL BOARD", cyan)
        p.note("Each board maps one live source to model speed, warp, position, rotation or hover. Start with three; add or remove boards as needed.")
        bindSwitch(p, "movement_boards_enabled", "Boards enabled", movement.enabled) {
            movement.enabled = it
            view.invalidate()
        }
        val boardCount = p.status("${movement.boardsSnapshot().size} boards", cyan)
        val movementOutput = p.status("X 0.000 · Y 0.000", cyan)
        val cards = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        root.addView(cards, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        fun renderBoardCards() {
            cards.removeAllViews()
            val snapshot = movement.boardsSnapshot()
            boardCount.text = "${snapshot.size} boards"
            snapshot.forEachIndexed { index, board ->
                val card = LinearLayout(activity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(activity, 8), dp(activity, 4), dp(activity, 8), dp(activity, 8))
                    setBackgroundColor(Color.rgb(0x16, 0x1B, 0x26))
                }
                cards.addView(card, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(activity, 8) })
                val cp = PanelBuilder(activity, card)
                cp.title("Board ${index + 1}", cyan)
                cp.switch("Board active", board.enabled) {
                    board.enabled = it
                    MemoryPaths.putBool(boardKey(board, "enabled"), it)
                }
                addSpinner(activity, card, "Drive mode", VirtualMovementControlBoard.DRIVE_NAMES,
                    board.driveMode.coerceIn(0, 3)) {
                    board.driveMode = it
                    MemoryPaths.putFloat(boardKey(board, "drive"), it.toFloat())
                }
                addSpinner(activity, card, "X axis", VirtualMovementControlBoard.AXIS_NAMES,
                    board.xAxis.coerceIn(0, 5)) {
                    board.xAxis = it
                    MemoryPaths.putFloat(boardKey(board, "xaxis"), it.toFloat())
                }
                addSpinner(activity, card, "Y axis", VirtualMovementControlBoard.AXIS_NAMES,
                    board.yAxis.coerceIn(0, 5)) {
                    board.yAxis = it
                    MemoryPaths.putFloat(boardKey(board, "yaxis"), it.toFloat())
                }
                cp.seek("Smoothing", 0f, 0.95f, board.smoothing) {
                    board.smoothing = it
                    MemoryPaths.putFloat(boardKey(board, "smoothing"), it)
                }
                cp.seek("X range · 0–100", 0f, 100f, board.xRange, 0) {
                    board.xRange = it
                    MemoryPaths.putFloat(boardKey(board, "xrange"), it)
                }
                cp.seek("Y range · 0–2", 0f, 2f, board.yRange) {
                    board.yRange = it
                    MemoryPaths.putFloat(boardKey(board, "yrange"), it)
                }
                cp.seek("Manual X", 0f, 1f, board.manualX) {
                    board.manualX = it
                    MemoryPaths.putFloat(boardKey(board, "manual_x"), it)
                }
                cp.seek("Manual Y", 0f, 1f, board.manualY) {
                    board.manualY = it
                    MemoryPaths.putFloat(boardKey(board, "manual_y"), it)
                }
                cp.switch("RAW · unsmoothed input only", board.raw) {
                    board.raw = it
                    MemoryPaths.putBool(boardKey(board, "raw"), it)
                }
                cp.button("Remove board") {
                    if (movement.removeBoard(board.id)) {
                        MemoryPaths.putFloat(PREF + "board_count", movement.boardsSnapshot().size.toFloat())
                        renderBoardCards()
                    }
                }
            }
        }
        p.button("＋ Add Board · maximum 8") {
            if (movement.addBoard() != null) {
                MemoryPaths.putFloat(PREF + "board_count", movement.boardsSnapshot().size.toFloat())
                renderBoardCards()
            }
        }
        renderBoardCards()

        p.title("3D MODEL · AMBIENT LINK", amber)
        val world = view.gameWorld
        bindSwitch(p, "model_enabled", "3D model board enabled", world.enabled) {
            world.enabled = it
            view.invalidate()
        }
        bindSwitch(p, "ambient_link", "Ambient link", movement.ambientLink) {
            movement.ambientLink = it
            view.invalidate()
        }
        bindSeek(p, "model_pos_y", "Model position Y", 0.30f, 0.95f, world.posY, 2) { world.posY = it }
        bindSeek(p, "model_z", "Camera distance / Z", 2f, 12f, world.camDist, 2) { world.camDist = it }
        bindSeek(p, "model_scale", "Model scale", 0.15f, 0.90f, world.size, 2) { world.size = it }
        bindSeek(p, "model_threshold", "Model threshold", 0f, 0.98f, world.thr, 2) { world.thr = it }
        bindSeek(p, "model_level", "Model output level", 0f, 1.5f, world.level, 2) { world.level = it }
        bindSeek(p, "model_spike_threshold", "Visual spike gate", 0.05f, 1f, view.regionFx.spikeThr, 2) {
            view.regionFx.spikeThr = it
        }
        bindSwitch(p, "model_inside", "Inside-layer overlay", world.anatomyInside) {
            world.anatomyInside = it
            view.invalidate()
        }
        bindSwitch(p, "model_scan", "Scan / radar overlay", world.radarOn) {
            world.radarOn = it
            view.invalidate()
        }
        val modelMotion = world.ctl.cfg("you")
        bindSwitch(p, "model_pitch_on", "Model head-pitch drive", modelMotion.pitchOn) {
            modelMotion.pitchOn = it
            world.ctl.save(modelMotion)
        }
        bindSeek(p, "model_eye_pitch", "Eye / head pitch threshold", 0f, 0.98f, modelMotion.pitchThr, 2) {
            modelMotion.pitchThr = it
            world.ctl.save(modelMotion)
        }
        bindSwitch(p, "model_body_rotate", "Model body rotation drive", modelMotion.inRotOn) {
            modelMotion.inRotOn = it
            world.ctl.save(modelMotion)
        }
        bindSeek(p, "model_body_pitch", "Body rotation threshold", 0f, 0.98f, modelMotion.inRotThr, 2) {
            modelMotion.inRotThr = it
            world.ctl.save(modelMotion)
        }

        val soundAlert = audio.soundAlert
        p.title("AMBIENT SOUND ALERT · UNCLASSIFIED", amber)
        p.note(
            "Optional on-device cue from microphone peak dBFS + spectral centroid. It cannot identify a knife, bullet, electric shock, " +
                "injury, or sound source; dBFS is not calibrated sound-pressure level."
        )
        bindSwitch(p, "sound_alert_on", "Enable generic high-frequency sound alert", soundAlert.enabled) {
            soundAlert.enabled = it
        }
        bindSeek(p, "sound_alert_peak", "Minimum microphone peak · dBFS", -90f, -3f, soundAlert.minimumPeakDbfs, 0) {
            soundAlert.minimumPeakDbfs = it
        }
        bindSeek(p, "sound_alert_centroid", "Minimum spectral centroid · Hz", 250f, 10000f, soundAlert.minimumCentroidHz, 0) {
            soundAlert.minimumCentroidHz = it
        }
        val soundAlertStatus = p.status("MIC waiting · sound alert off", amber)

        val soundChannels = view.soundBank
        p.title("SHARP / BURST · SOUND-REACTIVE VISUAL CHANNELS", violet)
        p.note(
            "Sharpness is mic energy × spectral-centroid proxy; burst is a positive block-to-block peak rise. " +
                "These are unclassified visuals, not blade/gunshot detection or physical protection. " +
                "Their output has an always-on 45% cap and damping; RAW bypasses their thresholds, not that cap."
        )
        bindSwitch(p, "sharp_sound_on", "Enable sharpness-like visual channel", soundChannels.sharpOn) {
            soundChannels.sharpOn = it
        }
        bindSeek(p, "sharp_sound_threshold", "Sharp channel threshold", 0.05f, 1f, soundChannels.sharpThr, 2) {
            soundChannels.sharpThr = it
        }
        bindSeek(p, "sharp_sound_level", "Sharp channel level", 0f, 1f, soundChannels.sharpLv, 2) {
            soundChannels.sharpLv = it
        }
        bindSwitch(p, "burst_sound_on", "Enable burst channel attack (mic peak rise)", soundChannels.burstOn) {
            soundChannels.burstOn = it
        }
        bindSeek(p, "burst_sound_threshold", "Burst channel threshold", 0.05f, 1f, soundChannels.burstThr, 2) {
            soundChannels.burstThr = it
        }
        bindSwitch(p, "sharp_sound_protect", "Sharp channel protection", soundChannels.sharpProtect) {
            soundChannels.sharpProtect = it
        }
        bindSwitch(p, "burst_sound_protect", "Burst channel protection", soundChannels.burstProtect) {
            soundChannels.burstProtect = it
        }
        bindSeek(p, "burst_sound_level", "Burst channel level", 0f, 1f, soundChannels.burstLv, 2) {
            soundChannels.burstLv = it
        }
        val soundChannelsStatus = p.status("Sharp + burst channels · FULL functional · RAW", violet)

        p.title("SAFE EFFECT PREVIEW · SIMULATION ONLY", violet)
        p.note(
            "Manual screen-label preview only. No electrical output, camera LED, weapon effect, or automatic camera/mic trigger. " +
                "Optional Android UI haptics are one brief system feedback cue, not an electric shock."
        )
        var demoHaptics = MemoryPaths.getBool(PREF + "demo_haptics", false)
        p.switch("Allow optional single system haptic on preview", demoHaptics) {
            demoHaptics = it
            MemoryPaths.putBool(PREF + "demo_haptics", it)
        }
        val demoStatus = p.status("DEMO READY · no shock simulation", violet)
        p.button("Preview safe screen cue") { button ->
            if (demoHaptics) button.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            demoStatus.text = "SIMULATION ONLY · no shock, flash, or injury"
            demoStatus.setTextColor(amber)
            demoStatus.postDelayed({
                demoStatus.text = "DEMO READY · no shock simulation"
                demoStatus.setTextColor(violet)
            }, 1000L)
        }

        val eventFx = view.soundBank
        val bodyFx = view.bodySoundFx
        p.title("BODY-PART AUDIO FX · GENERIC VISUAL TRIGGERS", amber)
        p.note(
            "These are adjustable sound-reactive visuals, not weapon classifiers or physical protection. " +
                "Hz is the dominant FFT peak; dBFS is digital mic level, not calibrated sound-pressure dB. " +
                "A camera-visible selected segment is only the 3D marker destination; the phone mic cannot localize sound to a person or body part."
        )
        bindSwitch(p, "event_fx_raw", "RAW mode · full functional · no simulator caps", eventFx.rawComplete) {
            eventFx.rawComplete = it
        }
        bindSwitch(p, "event_fx_part_gate", "Require selected body segment to be visible", eventFx.bodyPartGateOn) {
            eventFx.bodyPartGateOn = it
        }
        bindSeek(p, "event_fx_part_threshold", "Visible-part confidence threshold", 0f, 0.95f, eventFx.bodyPartGateThr, 2) {
            eventFx.bodyPartGateThr = it
        }
        addSpinner(
            activity, root, "3D visual target segment",
            HumanDetection.PART_NAMES.toTypedArray(), bodyFx.selectedPart
        ) { bodyFx.selectedPart = it }

        p.title("BULLET / IMPULSE ATTACK · LIVE MIC", violet)
        bindSwitch(p, "event_bullet_on", "Enable bullet / impulse attack channel", eventFx.bulletOn) {
            eventFx.bulletOn = it
        }
        bindSeek(p, "event_bullet_thr", "Bullet attack threshold", 0.05f, 1f, eventFx.bulletThr, 2) {
            eventFx.bulletThr = it
        }
        bindSeek(p, "event_bullet_lv", "Bullet attack level", 0f, 1f, eventFx.bulletLv, 2) {
            eventFx.bulletLv = it
        }
        bindSwitch(p, "event_bullet_gate", "Bullet Hz/dBFS gate (live mic)", eventFx.bulletHzDbGateOn) {
            eventFx.bulletHzDbGateOn = it
        }
        bindSeek(p, "event_bullet_hz_min", "Bullet minimum Hz", 20f, 20000f, eventFx.bulletHzMin, 0) {
            eventFx.bulletHzMin = it
        }
        bindSeek(p, "event_bullet_hz_max", "Bullet maximum Hz", 20f, 20000f, eventFx.bulletHzMax, 0) {
            eventFx.bulletHzMax = it
        }
        bindSeek(p, "event_bullet_dbfs", "Bullet minimum dBFS", -90f, 0f, eventFx.bulletDbfsThr, 1) {
            eventFx.bulletDbfsThr = it
        }

        bindSwitch(p, "event_bullet_protect", "Bullet protection (dampen enemy bullet attack)", eventFx.bulletProtect) {
            eventFx.bulletProtect = it
        }
        bindSeek(p, "event_fx_protect_lv", "Gun/knife protection level", 0f, 1f, eventFx.enemyFxProtectLv, 2) {
            eventFx.enemyFxProtectLv = it
        }

        p.title("KNIFE / SHARP-BAND ATTACK · LIVE MIC", violet)
        bindSwitch(p, "event_knife_on", "Enable knife / sharp-band attack channel", eventFx.knifeOn) {
            eventFx.knifeOn = it
        }
        bindSeek(p, "event_knife_thr", "Knife attack threshold", 0.05f, 1f, eventFx.knifeThr, 2) {
            eventFx.knifeThr = it
        }
        bindSeek(p, "event_knife_lv", "Knife attack level", 0f, 1f, eventFx.knifeLv, 2) {
            eventFx.knifeLv = it
        }
        bindSwitch(p, "event_knife_gate", "Knife Hz/dBFS gate (live mic)", eventFx.knifeHzDbGateOn) {
            eventFx.knifeHzDbGateOn = it
        }
        bindSeek(p, "event_knife_hz_min", "Knife minimum Hz", 20f, 20000f, eventFx.knifeHzMin, 0) {
            eventFx.knifeHzMin = it
        }
        bindSeek(p, "event_knife_hz_max", "Knife maximum Hz", 20f, 20000f, eventFx.knifeHzMax, 0) {
            eventFx.knifeHzMax = it
        }
        bindSeek(p, "event_knife_dbfs", "Knife minimum dBFS", -90f, 0f, eventFx.knifeDbfsThr, 1) {
            eventFx.knifeDbfsThr = it
        }

        bindSwitch(p, "event_knife_protect", "Knife protection (dampen enemy knife attack)", eventFx.knifeProtect) {
            eventFx.knifeProtect = it
        }

        p.title("AR / ARGUMENT REALITY MIXER PROTECTION", violet)
        p.note("Use main layout switches: AR mixer protection ON + level. BodyModelMixer dampen scales with protect level.")
        p.title("WHIP EFFECT · MIC × MODEL DRIVEN", violet)
        bindSwitch(p, "event_whip_on", "Enable whip effect attack", eventFx.whipOn) {
            eventFx.whipOn = it
        }
        bindSeek(p, "event_whip_thr", "Whip threshold", 0.05f, 1f, eventFx.whipThr, 2) {
            eventFx.whipThr = it
        }
        bindSeek(p, "event_whip_lv", "Whip level", 0f, 1f, eventFx.whipLv, 2) {
            eventFx.whipLv = it
        }
        bindSwitch(p, "event_whip_protect", "Whip protection (dampen enemy whip)", eventFx.whipProtect) {
            eventFx.whipProtect = it
        }
        bindSwitch(p, "event_whip_model", "Mic model-driven whip (body/model scale)", eventFx.whipModelDrive) {
            eventFx.whipModelDrive = it
        }

        p.title("RIPPLE VISUAL FX", violet)
        bindSwitch(p, "event_ripple_on", "Enable ripple FX channel", eventFx.rippleOn) {
            eventFx.rippleOn = it
        }
        bindSeek(p, "event_ripple_thr", "Ripple energy threshold", 0.05f, 1f, eventFx.rippleThr, 2) {
            eventFx.rippleThr = it
        }
        bindSeek(p, "event_ripple_lv", "Ripple visual level", 0f, 1f, eventFx.rippleLv, 2) {
            eventFx.rippleLv = it
        }
        bindSwitch(p, "event_ripple_gate", "Use ripple Hz/dBFS gate", eventFx.rippleHzDbGateOn) {
            eventFx.rippleHzDbGateOn = it
        }
        bindSeek(p, "event_ripple_hz_min", "Ripple minimum Hz", 20f, 20000f, eventFx.rippleHzMin, 0) {
            eventFx.rippleHzMin = it
        }
        bindSeek(p, "event_ripple_hz_max", "Ripple maximum Hz", 20f, 20000f, eventFx.rippleHzMax, 0) {
            eventFx.rippleHzMax = it
        }
        bindSeek(p, "event_ripple_dbfs", "Ripple minimum dBFS", -90f, 0f, eventFx.rippleDbfsThr, 1) {
            eventFx.rippleDbfsThr = it
        }

        val feedbackStatus = p.status("Effects idle", cyan)
        val audioStatus = p.status("MIC waiting · spectrum idle", cyan)
        val eventFxStatus = p.status("Audio event FX waiting", amber)
        val motionStatus = p.status("CAM motion waiting", amber)
        handler = Handler(Looper.getMainLooper())
        updater = object : Runnable {
            override fun run() {
                engineButton.text = if (feedback.enabled) "Effects Engine · ON" else "Initialize Effects Engine"
                micButton.text = if (audio.microphoneConnected) "Disconnect Mic" else "Connect Mic"
                feedbackStatus.text = feedback.statusLine()
                audioStatus.text = if (audio.microphoneConnected) {
                    val live = audio.analyzer
                    "MIC RMS ${"%.1f".format(live.rmsDbfs)} dBFS · peak ${"%.1f".format(live.peakDbfs)} dBFS" +
                        " · dominant ${live.domHz.toInt()} Hz · centroid ${live.centroidHz.toInt()} Hz"
                } else "MIC disconnected · connect to drive audio effects"
                soundAlertStatus.text = if (audio.microphoneConnected) soundAlert.statusLine()
                    else "MIC disconnected · sound alert unavailable"
                soundChannelsStatus.text =
                    "Sharp ${if (soundChannels.sharpActive) "ON" else "idle"} ${(soundChannels.sharpOut * 100).toInt()}% thr=${(soundChannels.sharpThr*100).toInt()} · " +
                        "Burst ${if (soundChannels.burstActive) "ON" else "idle"} ${(soundChannels.burstOut * 100).toInt()}% thr=${(soundChannels.burstThr*100).toInt()} · FULL · " +
                        (if (soundChannels.rawComplete) "RAW thresholds bypassed · 45% cap active"
                        else "thresholded · 45% cap active")
                val targetName = HumanDetection.PART_NAMES.getOrNull(bodyFx.selectedPart) ?: "—"
                val mode = if (eventFx.rawComplete) "RAW bypass" else "thresholded"
                val gates = listOf(
                    if (eventFx.bulletHzDbGateOn) "impulse Hz/dB" else "impulse level",
                    if (eventFx.knifeHzDbGateOn) "high-frequency Hz/dB" else "high-frequency level",
                    if (eventFx.rippleHzDbGateOn) "ripple Hz/dB" else "ripple level"
                ).joinToString(" · ")
                eventFxStatus.text =
                    "FX $mode · $gates · 3D target $targetName (${(bodyFx.targetPartConfidence * 100).toInt()}% visible)"
                motionStatus.text = "CAM move ${(feedback.camMotion * 100).toInt()}% · speed ${(feedback.camSpeed * 100).toInt()}% · wave ${(feedback.camWave * 100).toInt()}%"
                val output = movement.output
                movementOutput.text = "X ${"%.3f".format(output.modelX)} · Y ${"%.3f".format(output.modelY)} · speed ${"%.2f".format(output.atomSpeed)}× · warp ${"%.2f".format(output.warpFactor)}"
                handler?.postDelayed(this, 200L)
            }
        }
        handler?.post(updater!!)
    }

    fun stop() {
        updater?.let { handler?.removeCallbacks(it) }
        updater = null
        handler = null
    }

    private fun restore(
        feedback: VideoFeedbackBoard,
        colour: AudioColourBoard,
        movement: VirtualMovementControlBoard,
        view: VisualShieldView
    ) {
        fun bool(key: String, current: Boolean) = MemoryPaths.getBool(PREF + key, current)
        fun float(key: String, current: Float, min: Float, max: Float) =
            MemoryPaths.getFloat(PREF + key, current).coerceIn(min, max)

        feedback.enabled = bool("engine", feedback.enabled)
        feedback.vfOn = bool("feedback_loop", feedback.vfOn)
        feedback.freezeFrame = bool("freeze_frame", feedback.freezeFrame)
        feedback.cfOn = bool("camera_feedback", feedback.cfOn)
        feedback.cfMix = float("camera_mix", feedback.cfMix, 0f, 1f)
        feedback.camExposureFollow = bool("camera_exposure_follow", feedback.camExposureFollow)
        feedback.rawPass = bool("raw_pass", feedback.rawPass)
        feedback.invertColors = bool("invert", feedback.invertColors)
        feedback.brightness = float("brightness", feedback.brightness + 1f, 0f, 2f) - 1f
        feedback.contrast = float("contrast", feedback.contrast, 0f, 2.5f)
        feedback.colour = float("saturation", feedback.colour, 0f, 2.5f)
        feedback.hue = float("hue", feedback.hue, -180f, 180f)
        feedback.vfGain = float("strength", feedback.vfGain, 0f, 1f)
        feedback.vfZoom = float("zoom", feedback.vfZoom, 0f, 1f)
        feedback.vfRotate = float("rotation", feedback.vfRotate, 0f, 1f)
        feedback.trailDecay = float("trail", feedback.trailDecay, 0f, 0.98f)
        feedback.blendMode = float("blend", feedback.blendMode.toFloat(), 0f, 8f).toInt()
        feedback.pixelWaveOn = bool("pixel_wave", feedback.pixelWaveOn)
        feedback.pixelWaveAmp = float("pixel_wave_amp", feedback.pixelWaveAmp, 0f, 0.08f)
        feedback.rawTowsOn = bool("raw_tows", feedback.rawTowsOn)
        feedback.overdrive = float("overdrive", feedback.overdrive, 1f, 6f)
        feedback.audioReactiveOn = bool("audio_reactive", feedback.audioReactiveOn)
        feedback.audioBrightnessMix = float("audio_brightness", feedback.audioBrightnessMix, 0f, 1f)
        feedback.audioZoomMix = float("audio_zoom", feedback.audioZoomMix, 0f, 1f)
        feedback.audioStrengthMix = float("audio_strength", feedback.audioStrengthMix, 0f, 1f)
        feedback.audioRotateMix = float("audio_rotation", feedback.audioRotateMix, 0f, 1f)
        feedback.audioHueMix = float("audio_hue", feedback.audioHueMix, 0f, 1f)
        feedback.protectionOn = bool("protection", feedback.protectionOn)
        feedback.maxBrightness = float("max_brightness", feedback.maxBrightness, 0f, 2f)
        feedback.maxContrast = float("max_contrast", feedback.maxContrast, 0f, 2.5f)
        feedback.maxStrength = float("max_strength", feedback.maxStrength, 0f, VideoFeedbackBoard.MAX_GAIN)
        feedback.fbThrOn = bool("feedback_gate_on", feedback.fbThrOn)
        feedback.protectionPreset = when (MemoryPaths.getString(PREF + "protection_preset", "Safe")) {
            "Off" -> VideoFeedbackBoard.PRESET_OFF
            "Soft" -> VideoFeedbackBoard.PRESET_SOFT
            "Medium" -> VideoFeedbackBoard.PRESET_MEDIUM
            "Hard" -> VideoFeedbackBoard.PRESET_HARD
            "Blackout" -> VideoFeedbackBoard.PRESET_BLACKOUT
            else -> VideoFeedbackBoard.PRESET_SAFE
        }
        feedback.fbThr = float("feedback_threshold", feedback.fbThr, 0.05f, 1f)
        feedback.fbRail = (float("feedback_rail", feedback.fbRail / 255f, 0f, 1f) * 255f).toInt()
        feedback.motionDetectionOn = bool("motion_detection", feedback.motionDetectionOn)
        feedback.cameraPower = float("camera_power", feedback.cameraPower, 0f, 2f)
        feedback.motionSensitivity = float("motion_sensitivity", feedback.motionSensitivity, 0f, 2f)
        feedback.motionMoveGate = float("move_gate", feedback.motionMoveGate, 0f, 1f)
        feedback.motionSpeedGate = float("speed_gate", feedback.motionSpeedGate, 0f, 1f)
        feedback.motionWaveGate = float("wave_gate", feedback.motionWaveGate, 0f, 1f)
        feedback.motionStrengthMix = float("motion_strength", feedback.motionStrengthMix, 0f, 2f)
        feedback.motionZoomMix = float("motion_zoom", feedback.motionZoomMix, 0f, 0.5f)
        feedback.motionRotateMix = float("motion_rotation", feedback.motionRotateMix, 0f, 10f)
        feedback.motionHueMix = float("motion_hue", feedback.motionHueMix, 0f, 120f)

        colour.enabled = bool("audio_colour", colour.enabled)
        colour.invert = bool("audio_colour_invert", colour.invert)
        colour.rawComplete = bool("audio_colour_raw", colour.rawComplete)
        colour.thr = float("audio_colour_threshold", colour.thr, 0f, 0.95f)
        colour.sens = float("audio_colour_sensitivity", colour.sens, 0f, 3f)
        colour.brightnessAmt = float("audio_colour_brightness", colour.brightnessAmt, 0f, 1f)
        colour.contrastAmt = float("audio_colour_contrast", colour.contrastAmt, 0f, 1f)
        colour.levelAmt = float("audio_colour_saturation", colour.levelAmt, 0f, 1f)
        colour.flashLimitOn = true

        movement.enabled = bool("movement_boards_enabled", movement.enabled)
        movement.ambientLink = bool("ambient_link", movement.ambientLink)
        movement.movementSpeed = float("movement_speed", movement.movementSpeed, 0.1f, 2f)
        movement.movementDirection = float("direction", movement.movementDirection.toFloat(), 0f, 3f).toInt()
        movement.easing = float("easing", movement.easing.toFloat(), 0f, 3f).toInt()
        movement.manualAtomSpeed = float("atom_speed", movement.manualAtomSpeed, 0f, 100f)
        movement.manualWarpFactor = float("warp_factor", movement.manualWarpFactor, 0f, 2f)
        movement.resonance = float("resonance", movement.resonance, 0f, 1f)
        movement.inertia = float("inertia", movement.inertia, 0f, 1f)
        movement.manualHoverSpeed = float("hover_speed", movement.manualHoverSpeed, 0f, 8f)
        movement.phaseSync = bool("phase_sync", movement.phaseSync)
        movement.stutterGate = bool("stutter_gate", movement.stutterGate)
        movement.virtualOverdrive = bool("virtual_overdrive", movement.virtualOverdrive)

        val count = float("board_count", movement.boardsSnapshot().size.toFloat(), 1f, 8f).toInt()
        while (movement.boardsSnapshot().size < count) movement.addBoard()
        while (movement.boardsSnapshot().size > count) {
            val last = movement.boardsSnapshot().lastOrNull() ?: break
            movement.removeBoard(last.id)
        }
        movement.boardsSnapshot().forEach { board ->
            board.enabled = MemoryPaths.getBool(boardKey(board, "enabled"), board.enabled)
            board.driveMode = MemoryPaths.getFloat(boardKey(board, "drive"), board.driveMode.toFloat()).toInt().coerceIn(0, 3)
            board.xAxis = MemoryPaths.getFloat(boardKey(board, "xaxis"), board.xAxis.toFloat()).toInt().coerceIn(0, 5)
            board.yAxis = MemoryPaths.getFloat(boardKey(board, "yaxis"), board.yAxis.toFloat()).toInt().coerceIn(0, 5)
            board.smoothing = MemoryPaths.getFloat(boardKey(board, "smoothing"), board.smoothing).coerceIn(0f, 0.95f)
            board.xRange = MemoryPaths.getFloat(boardKey(board, "xrange"), board.xRange).coerceIn(0f, 100f)
            board.yRange = MemoryPaths.getFloat(boardKey(board, "yrange"), board.yRange).coerceIn(0f, 2f)
            board.manualX = MemoryPaths.getFloat(boardKey(board, "manual_x"), board.manualX).coerceIn(0f, 1f)
            board.manualY = MemoryPaths.getFloat(boardKey(board, "manual_y"), board.manualY).coerceIn(0f, 1f)
            board.raw = MemoryPaths.getBool(boardKey(board, "raw"), board.raw)
        }

        val world = view.gameWorld
        world.enabled = bool("model_enabled", world.enabled)
        world.posY = float("model_pos_y", world.posY, 0.30f, 0.95f)
        world.camDist = float("model_z", world.camDist, 2f, 12f)
        world.size = float("model_scale", world.size, 0.15f, 0.90f)
        world.thr = float("model_threshold", world.thr, 0f, 0.98f)
        world.level = float("model_level", world.level, 0f, 1.5f)
        view.regionFx.spikeThr = float("model_spike_threshold", view.regionFx.spikeThr, 0.05f, 1f)
        world.anatomyInside = bool("model_inside", world.anatomyInside)
        world.radarOn = bool("model_scan", world.radarOn)
        val modelMotion = world.ctl.cfg("you")
        modelMotion.pitchOn = bool("model_pitch_on", modelMotion.pitchOn)
        modelMotion.pitchThr = float("model_eye_pitch", modelMotion.pitchThr, 0f, 0.98f)
        modelMotion.inRotOn = bool("model_body_rotate", modelMotion.inRotOn)
        modelMotion.inRotThr = float("model_body_pitch", modelMotion.inRotThr, 0f, 0.98f)
        world.ctl.save(modelMotion)
    }

    private fun bindSwitch(
        panel: PanelBuilder,
        key: String,
        title: String,
        initial: Boolean,
        action: (Boolean) -> Unit
    ) {
        val value = MemoryPaths.getBool(PREF + key, initial)
        action(value)
        panel.switch(title, value) {
            action(it)
            MemoryPaths.putBool(PREF + key, it)
        }
    }

    private fun bindSeek(
        panel: PanelBuilder,
        key: String,
        title: String,
        min: Float,
        max: Float,
        initial: Float,
        decimals: Int = 2,
        action: (Float) -> Unit
    ) {
        val value = MemoryPaths.getFloat(PREF + key, initial).coerceIn(min, max)
        action(value)
        panel.seek(title, min, max, value, decimals) {
            action(it)
            MemoryPaths.putFloat(PREF + key, it)
        }
    }

    private fun boardKey(board: VirtualMovementControlBoard.Board, suffix: String) =
        PREF + "board_${board.id}_$suffix"

    private fun applyFeedbackPreset(name: String, board: VideoFeedbackBoard, colour: AudioColourBoard) {
        board.enabled = true
        board.vfOn = true
        board.freezeFrame = false
        board.pixelWaveOn = false
        board.invertColors = false
        board.rawPass = false
        when (name) {
            "Tunnel" -> {
                board.vfGain = 0.68f; board.vfZoom = 0.78f; board.vfRotate = 0.55f
                board.trailDecay = 0.88f; board.blendMode = VideoFeedbackBoard.BLEND_SCREEN
            }
            "Spiral" -> {
                board.vfGain = 0.62f; board.vfZoom = 0.72f; board.vfRotate = 0.88f
                board.trailDecay = 0.86f; board.blendMode = VideoFeedbackBoard.BLEND_OVERLAY
            }
            "Glitch" -> {
                board.vfGain = 0.56f; board.vfZoom = 0.58f; board.vfRotate = 0.52f
                board.trailDecay = 0.78f; board.pixelWaveOn = true; board.pixelWaveAmp = 0.035f
                board.blendMode = VideoFeedbackBoard.BLEND_DIFFERENCE
            }
            "Pulse" -> {
                board.vfGain = 0.55f; board.trailDecay = 0.75f
                board.audioReactiveOn = true; board.audioBrightnessMix = 0.18f
                board.audioStrengthMix = 0.25f; board.blendMode = VideoFeedbackBoard.BLEND_SCREEN
            }
            "Freeze" -> {
                board.vfGain = 0.78f; board.trailDecay = 0.96f
                board.vfZoom = 0.50f; board.blendMode = VideoFeedbackBoard.BLEND_SCREEN
                board.freezeFrame = true
            }
            "Burn" -> {
                board.vfGain = 0.54f; board.trailDecay = 0.82f
                board.blendMode = VideoFeedbackBoard.BLEND_COLOR_DODGE
            }
            "Mirror" -> {
                board.vfGain = 0.62f; board.trailDecay = 0.88f
                board.invertColors = true; board.blendMode = VideoFeedbackBoard.BLEND_DIFFERENCE
            }
            else -> {
                board.vfGain = 0.58f; board.trailDecay = 0.88f
                board.rawPass = true
            }
        }
        colour.flashLimitOn = true
        MemoryPaths.putBool(PREF + "engine", board.enabled)
        MemoryPaths.putBool(PREF + "feedback_loop", board.vfOn)
        MemoryPaths.putBool(PREF + "freeze_frame", board.freezeFrame)
        MemoryPaths.putBool(PREF + "pixel_wave", board.pixelWaveOn)
        MemoryPaths.putBool(PREF + "invert", board.invertColors)
        MemoryPaths.putBool(PREF + "raw_pass", board.rawPass)
        MemoryPaths.putFloat(PREF + "strength", board.vfGain)
        MemoryPaths.putFloat(PREF + "zoom", board.vfZoom)
        MemoryPaths.putFloat(PREF + "rotation", board.vfRotate)
        MemoryPaths.putFloat(PREF + "trail", board.trailDecay)
        MemoryPaths.putFloat(PREF + "blend", board.blendMode.toFloat())
        MemoryPaths.putFloat(PREF + "pixel_wave_amp", board.pixelWaveAmp)
        MemoryPaths.putBool(PREF + "audio_reactive", board.audioReactiveOn)
        MemoryPaths.putFloat(PREF + "audio_brightness", board.audioBrightnessMix)
        MemoryPaths.putFloat(PREF + "audio_strength", board.audioStrengthMix)
        MemoryPaths.putBool(PREF + "raw_tows", board.rawTowsOn)
        MemoryPaths.putFloat(PREF + "overdrive", board.overdrive)
    }

    private fun applyProtectionPreset(name: String, board: VideoFeedbackBoard) {
        when (name) {
            "Off" -> {
                board.protectionPreset = VideoFeedbackBoard.PRESET_OFF
                board.maxBrightness = 2.0f; board.maxContrast = 2.5f
                board.maxStrength = VideoFeedbackBoard.MAX_GAIN
            }
            "Soft" -> {
                board.protectionPreset = VideoFeedbackBoard.PRESET_SOFT
                board.maxBrightness = 0.8f; board.maxContrast = 1.8f; board.maxStrength = 0.72f
            }
            "Medium" -> {
                board.protectionPreset = VideoFeedbackBoard.PRESET_MEDIUM
                board.maxBrightness = 1.0f; board.maxContrast = 2.0f; board.maxStrength = 0.82f
            }
            "Hard" -> {
                board.protectionPreset = VideoFeedbackBoard.PRESET_HARD
                board.maxBrightness = 1.2f; board.maxContrast = 2.2f; board.maxStrength = 0.90f
            }
            "Blackout" -> {
                board.protectionPreset = VideoFeedbackBoard.PRESET_BLACKOUT
                board.maxBrightness = 0f; board.maxContrast = 0f; board.maxStrength = 0f
            }
            else -> {
                board.protectionPreset = VideoFeedbackBoard.PRESET_SAFE
                board.maxBrightness = 0.6f; board.maxContrast = 1.5f; board.maxStrength = 0.60f
            }
        }
        MemoryPaths.putFloat(PREF + "max_brightness", board.maxBrightness)
        MemoryPaths.putFloat(PREF + "max_contrast", board.maxContrast)
        MemoryPaths.putFloat(PREF + "max_strength", board.maxStrength)
    }

    private fun buttonGrid(
        context: Context,
        root: LinearLayout,
        labels: List<String>,
        onClick: (String) -> Unit
    ) {
        val columns = 4
        val buttonHeight = dp(context, 40)
        labels.chunked(columns).forEach { rowLabels ->
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            root.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
            rowLabels.forEach { label ->
                val button = Button(context).apply {
                    text = label
                    textSize = 10f
                    isAllCaps = false
                    setTextColor(Color.rgb(0xE6, 0xE6, 0xEA))
                    setBackgroundColor(Color.rgb(0x1A, 0x23, 0x32))
                    setOnClickListener { onClick(label) }
                }
                row.addView(button, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply {
                    marginEnd = dp(context, 4)
                    bottomMargin = dp(context, 4)
                })
            }
            repeat(columns - rowLabels.size) {
                row.addView(TextView(context), LinearLayout.LayoutParams(0, buttonHeight, 1f))
            }
        }
    }

    private fun addSpinner(
        context: Context,
        root: LinearLayout,
        label: String,
        options: Array<String>,
        selected: Int,
        onSelected: (Int) -> Unit
    ) {
        root.addView(TextView(context).apply {
            text = label
            setTextColor(Color.rgb(0xB0, 0xBE, 0xC5))
            textSize = 10f
            setPadding(0, dp(context, 6), 0, dp(context, 1))
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        val spinner = Spinner(context)
        val adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, options).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinner.adapter = adapter
        spinner.setSelection(selected.coerceIn(options.indices))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                onSelected(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        root.addView(spinner, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(context, 44)
        ))
    }

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}
