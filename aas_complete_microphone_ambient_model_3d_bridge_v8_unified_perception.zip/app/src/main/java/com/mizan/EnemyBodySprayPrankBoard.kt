package com.mizan

/**
 * Enemy body-spray prank lanes (AUDIO + BLE proximity + model track ONLY):
 * armpit spray SFX · buttocks/odor SFX tags for enemy regions.
 * Not real chemical sprays or biological agents — mic/BLE/model driven ambient.
 * RAW COMPLETE.
 */
class EnemyBodySprayPrankBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.28f
    @Volatile var levelAmt = 0.88f

    @Volatile var armpitSprayOut = 0f
    @Volatile var buttocksSprayOut = 0f
    @Volatile var odorTagOut = 0f
    @Volatile var bleProx = 0f
    @Volatile var micDrive = 0f
    @Volatile var modelDrive = 0f
    @Volatile var sprayFull = 0f
    @Volatile var status = "SPRAY-PRANK idle"

    private fun lane(e: Float): Float {
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * levelAmt).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * levelAmt).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, ble: Float, model: Float, enemyBody: Float) {
        if (!enabled) { status = "SPRAY-PRANK OFF"; return }
        micDrive = lane(mic)
        bleProx = lane(ble)
        modelDrive = lane(model)
        armpitSprayOut = lane(maxOf(mic * 0.7f, ble * 0.8f, enemyBody * 0.9f))
        buttocksSprayOut = lane(maxOf(mic * 0.65f, model * 0.85f, enemyBody * 0.88f))
        odorTagOut = maxOf(armpitSprayOut, buttocksSprayOut) * 0.9f
        sprayFull = maxOf(armpitSprayOut, buttocksSprayOut, odorTagOut)
        if (rawComplete) sprayFull = maxOf(sprayFull, 0.22f + enemyBody * 0.3f)
        status =
            "SPRAY armpit=${(armpitSprayOut*100).toInt()}% butt=${(buttocksSprayOut*100).toInt()}% · " +
            "ble/mic/model=${(bleProx*100).toInt()}/${(micDrive*100).toInt()}/${(modelDrive*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!enabled || sprayFull < 0.02f) return
        try {
            if (sb != null) {
                sb.enemyBodyOut = maxOf(sb.enemyBodyOut, sprayFull * 0.4f)
            }
        } catch (_: Throwable) {}
        val vv = v ?: return
        try {
            vv.enemy3dProtect.enemyModelOut = maxOf(vv.enemy3dProtect.enemyModelOut, sprayFull * 0.3f)
            vv.bodyRegionEnemyProtect.protectOut = maxOf(vv.bodyRegionEnemyProtect.protectOut, sprayFull * 0.25f)
        } catch (_: Throwable) {}
    }
}
