package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object FullBodyAnatomyInterconnectPanels {
    fun build(ctx: Context, root: LinearLayout, b: FullBodyAnatomyInterconnectBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF80CBC4.toInt()
        p.title("FULL BODY ANATOMY · OUTSIDE ↔ INSIDE INTERCONNECTED", c)
        p.note("Not single parts — shell→skin→muscle ↔ bone→vessel→organ→CNS as one system")
        p.switch("Full body anatomy ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Outside chain ON", b.outsideOn) { b.outsideOn = it }
        p.switch("Inside chain ON", b.insideOn) { b.insideOn = it }
        p.seek("Interconnect level", 0.1f, 1f, b.interconnectLv) { b.interconnectLv = it }
        p.seek("Threshold", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Level", 0f, 1.5f, b.lv) { b.lv = it }
        val st = p.status("FULL ANATOMY —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
