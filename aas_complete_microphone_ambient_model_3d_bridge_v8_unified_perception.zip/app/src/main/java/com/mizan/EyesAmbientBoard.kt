package com.mizan

/**
 * Mono + Final tabs eyes ambient logic (from prior aratombox EyeAmbientChannelsRole / AF eyes).
 * Left/right independent ambient · thr · level · bipolar · move/wave/speed · colour · model×mic.
 */
class EyesAmbientBoard {

    @Volatile var enabled = true
    @Volatile var thr = 0.30f
    @Volatile var level = 0.55f

    @Volatile var leftOn = true
    @Volatile var leftThr = 0.30f
    @Volatile var leftLv = 0.55f
    @Volatile var rightOn = true
    @Volatile var rightThr = 0.30f
    @Volatile var rightLv = 0.55f

    @Volatile var leftLive = 0f
    @Volatile var rightLive = 0f
    @Volatile var leftFire = false
    @Volatile var rightFire = false

    @Volatile var bipNegDb = 0f
    @Volatile var bipPosDb = 0f
    @Volatile var bipolarNet = 0f

    @Volatile var moveLv = 0.50f
    @Volatile var moveThr = 0.30f
    @Volatile var waveLv = 0.50f
    @Volatile var waveThr = 0.30f
    @Volatile var speedLv = 0.50f
    @Volatile var speedThr = 0.30f
    @Volatile var liveMove = 0f
    @Volatile var liveWave = 0f
    @Volatile var liveSpeed = 0f
    @Volatile var fireMove = false
    @Volatile var fireWave = false
    @Volatile var fireSpeed = false

    @Volatile var colourOn = true
    @Volatile var colourThr = 0.30f
    @Volatile var colourLv = 0.55f
    @Volatile var colourR = 0.50f
    @Volatile var colourG = 0.50f
    @Volatile var colourB = 0.50f
    @Volatile var bright = 0.50f
    @Volatile var contrast = 0.50f
    @Volatile var colourLive = 0f
    @Volatile var colourFire = false

    @Volatile var protectL = true
    @Volatile var protectR = true
    @Volatile var pitchThrL = 0.30f
    @Volatile var pitchThrR = 0.30f
    @Volatile var pitchLvL = 0.70f
    @Volatile var pitchLvR = 0.70f

    /** Mic energy 0..1 + model drive 0..1 → L/R ambient outs. */
    fun tick(micEnergy: Float, modelDrive: Float = 1f, motion: Float = 0f, wave: Float = 0f, speed: Float = 0f) {
        if (!enabled) {
            leftLive = 0f; rightLive = 0f
            leftFire = false; rightFire = false
            return
        }
        val drive = (0.25f + 0.75f * modelDrive.coerceIn(0f, 1f))
        val e = micEnergy.coerceIn(0f, 1f)
        val bip01 = ((bipPosDb - bipNegDb).coerceIn(-120f, 120f) / 240f + 0.5f).coerceIn(0.05f, 1f)
        bipolarNet = bipPosDb - bipNegDb

        fun lane(on: Boolean, thr: Float, lv: Float, sideBoost: Float): Pair<Float, Boolean> {
            if (!on) return 0f to false
            val t = (thr * drive * bip01).coerceIn(0.05f, 1f)
            val live = (e * sideBoost * drive).coerceIn(0f, 1f)
            val fire = live >= t
            val out = if (fire) ((live - t) / (1f - t).coerceAtLeast(0.05f) * lv * drive).coerceIn(0f, 1f) else 0f
            return out to fire
        }

        val (l, lf) = lane(leftOn, leftThr, leftLv, 1.05f)
        val (r, rf) = lane(rightOn, rightThr, rightLv, 1.0f)
        leftLive = l; rightLive = r
        leftFire = lf; rightFire = rf

        liveMove = motion.coerceIn(0f, 1f)
        liveWave = wave.coerceIn(0f, 1f)
        liveSpeed = speed.coerceIn(0f, 1f)
        fireMove = liveMove >= moveThr * drive
        fireWave = liveWave >= waveThr * drive
        fireSpeed = liveSpeed >= speedThr * drive

        colourLive = ((colourR + colourG + colourB) / 3f * e * drive).coerceIn(0f, 1f)
        colourFire = colourOn && colourLive >= colourThr * drive

        // Protection: damp live when protect ON and energy below pitch thr (hold stable)
        if (protectL && leftLive > 0f && e < pitchThrL) {
            leftLive *= (1f - pitchLvL * 0.35f).coerceIn(0.2f, 1f)
        }
        if (protectR && rightLive > 0f && e < pitchThrR) {
            rightLive *= (1f - pitchLvR * 0.35f).coerceIn(0.2f, 1f)
        }
    }

    fun statusLine(): String =
        "EYES L=${(leftLive * 100).toInt()}%${if (leftFire) "*" else ""} " +
        "R=${(rightLive * 100).toInt()}%${if (rightFire) "*" else ""} " +
        "M/W/S ${if (fireMove) "M" else "-"}${if (fireWave) "W" else "-"}${if (fireSpeed) "S" else "-"} " +
        "bip=${"%.0f".format(bipolarNet)}dB " +
        "prot L${if (protectL) "ON" else "off"}/R${if (protectR) "ON" else "off"}"
    fun apply(v: VisualShieldView?) {
        val vv = v ?: return
        try {
            val l = leftLive
            val r = rightLive
            vv.cnsEyesHeart.eyeLOut = maxOf(vv.cnsEyesHeart.eyeLOut, l)
            vv.cnsEyesHeart.eyeROut = maxOf(vv.cnsEyesHeart.eyeROut, r)
        } catch (_: Throwable) {}
    }

}
