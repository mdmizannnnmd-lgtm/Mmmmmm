package com.mizan

/**
 * Symbolic enemy "food / dustbin / spray" ambient prank lanes —
 * AUDIO + BLE + model tags only. Does NOT implement real chemical,
 * biological, food-force, or virus transfer into any person.
 * RAW COMPLETE.
 */
class EnemyFoodDustbinPrankBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.28f
    @Volatile var levelAmt = 0.85f

    @Volatile var dustbinWaterOut = 0f
    @Volatile var dustbinSprayNoseOut = 0f
    @Volatile var cookedFoodTagOut = 0f
    @Volatile var curryTagOut = 0f
    @Volatile var animalTrackOut = 0f
    @Volatile var virusTagOut = 0f   // symbolic tag only
    @Volatile var vectorTagOut = 0f
    @Volatile var bleFoodTrack = 0f
    @Volatile var prankFull = 0f
    @Volatile var status = "FOOD-DUSTBIN-PRANK idle"

    private fun lane(e: Float): Float {
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * levelAmt).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * levelAmt).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, ble: Float, model: Float, enemy: Float) {
        if (!enabled) { status = "FOOD-DUSTBIN OFF"; return }
        val e = maxOf(mic * 0.6f, enemy, model * 0.5f)
        dustbinWaterOut = lane(e * 0.9f + ble * 0.4f)
        dustbinSprayNoseOut = lane(e * 0.85f + mic * 0.4f)
        cookedFoodTagOut = lane(e * 0.8f + model * 0.4f)
        curryTagOut = lane(e * 0.75f)
        animalTrackOut = lane(model * 0.9f + e * 0.4f)
        virusTagOut = lane(e * 0.7f) // tag energy only
        vectorTagOut = lane(model * 0.8f + ble * 0.3f)
        bleFoodTrack = lane(ble * 0.95f + cookedFoodTagOut * 0.5f)
        prankFull = maxOf(dustbinWaterOut, dustbinSprayNoseOut, cookedFoodTagOut, curryTagOut, animalTrackOut, bleFoodTrack)
        if (rawComplete) prankFull = maxOf(prankFull, 0.2f + enemy * 0.3f)
        status =
            "DUSTBIN water/spray=${(dustbinWaterOut*100).toInt()}/${(dustbinSprayNoseOut*100).toInt()}% · " +
            "food/curry=${(cookedFoodTagOut*100).toInt()}/${(curryTagOut*100).toInt()}% · " +
            "BLE food=${(bleFoodTrack*100).toInt()}% (symbolic SFX only)" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!enabled || prankFull < 0.02f) return
        try {
            if (sb != null) sb.enemyBodyOut = maxOf(sb.enemyBodyOut, prankFull * 0.35f)
        } catch (_: Throwable) {}
        val vv = v ?: return
        try {
            vv.enemy3dProtect.enemyModelOut = maxOf(vv.enemy3dProtect.enemyModelOut, prankFull * 0.25f)
            vv.enemyBodySprayPrank.sprayFull = maxOf(vv.enemyBodySprayPrank.sprayFull, dustbinSprayNoseOut * 0.5f)
        } catch (_: Throwable) {}
    }
}
