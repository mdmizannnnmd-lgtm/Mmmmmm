package com.mizan

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Camera-axis motion + raw X/Y/Z + pitch L/R/up/down.
 * Driven by accelerometer / gyroscope when available; audio RMS optional mix.
 */
class MotionSensorHub(context: Context) : SensorEventListener {

    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    @Volatile var enabled = true

    // Motion master
    @Volatile var moveLv = 0.55f
    @Volatile var moveThr = 0.30f
    @Volatile var waveLv = 0.55f
    @Volatile var waveThr = 0.30f
    @Volatile var motionSpeed = 1.0f
    @Volatile var motionThr = 0.25f

    // Raw axis levels (generated from sensors)
    @Volatile var axisX = 0f
    @Volatile var axisY = 0f
    @Volatile var axisZ = 0f
    @Volatile var axisXLv = 0.50f
    @Volatile var axisYLv = 0.50f
    @Volatile var axisZLv = 0.50f
    @Volatile var axisXThr = 0.30f
    @Volatile var axisYThr = 0.30f
    @Volatile var axisZThr = 0.30f

    // Pitch L R up down
    @Volatile var pitchL = 0f
    @Volatile var pitchR = 0f
    @Volatile var pitchUp = 0f
    @Volatile var pitchDown = 0f
    @Volatile var pitchLLv = 0.50f
    @Volatile var pitchRLv = 0.50f
    @Volatile var pitchUpLv = 0.50f
    @Volatile var pitchDownLv = 0.50f
    @Volatile var pitchLThr = 0.30f
    @Volatile var pitchRThr = 0.30f
    @Volatile var pitchUpThr = 0.30f
    @Volatile var pitchDownThr = 0.30f

    // Audio sensor mix (0 = motion only, 1 = full audio influence)
    @Volatile var audioMix = 0.35f
    @Volatile var lastAudio = 0f

    @Volatile var liveMove = 0f
    @Volatile var liveWave = 0f
    @Volatile var liveSpeed = 0f
    @Volatile var fireMove = false
    @Volatile var fireWave = false
    @Volatile var fireMotion = false

    @Volatile private var rawAx = 0f
    @Volatile private var rawAy = 0f
    @Volatile private var rawAz = 0f
    @Volatile private var rawGx = 0f
    @Volatile private var rawGy = 0f
    @Volatile private var rawGz = 0f

    val rawAccelX: Float get() = rawAx
    val rawAccelY: Float get() = rawAy
    val rawAccelZ: Float get() = rawAz
    val rawGyroX: Float get() = rawGx
    val rawGyroY: Float get() = rawGy
    val rawGyroZ: Float get() = rawGz

    fun start() {
        accel?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        gyro?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    fun stop() {
        sm.unregisterListener(this)
    }

    fun setAudioLevel(rms: Float) {
        lastAudio = rms.coerceIn(0f, 1f)
        tick()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || !enabled) return
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                rawAx = event.values[0]
                rawAy = event.values[1]
                rawAz = event.values[2]
            }
            Sensor.TYPE_GYROSCOPE -> {
                rawGx = event.values[0]
                rawGy = event.values[1]
                rawGz = event.values[2]
            }
        }
        tick()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun tick() {
        // Normalize accel ~ ±10 m/s² → 0…1 magnitude per axis
        fun n(v: Float) = (abs(v) / 12f).coerceIn(0f, 1f)
        val ax = n(rawAx)
        val ay = n(rawAy)
        val az = n(rawAz)
        val gx = (abs(rawGx) / 5f).coerceIn(0f, 1f)
        val gy = (abs(rawGy) / 5f).coerceIn(0f, 1f)
        val gz = (abs(rawGz) / 5f).coerceIn(0f, 1f)

        axisX = (ax * 0.7f + gx * 0.3f) * axisXLv
        axisY = (ay * 0.7f + gy * 0.3f) * axisYLv
        axisZ = (az * 0.7f + gz * 0.3f) * axisZLv

        // Pitch from gyro/tilt: L/R from X, up/down from Y
        val lr = (rawAx / 10f).coerceIn(-1f, 1f)
        val ud = (rawAy / 10f).coerceIn(-1f, 1f)
        pitchL = if (lr < 0) (-lr) * pitchLLv else 0f
        pitchR = if (lr > 0) lr * pitchRLv else 0f
        pitchUp = if (ud > 0) ud * pitchUpLv else 0f
        pitchDown = if (ud < 0) (-ud) * pitchDownLv else 0f

        val motionMag = sqrt(axisX * axisX + axisY * axisY + axisZ * axisZ).coerceIn(0f, 1f)
        val audio = lastAudio * audioMix
        liveMove = ((motionMag * 0.75f + audio * 0.25f) * moveLv).coerceIn(0f, 1f)
        liveWave = ((gx + gy + gz) / 3f * waveLv).coerceIn(0f, 1f)
        liveSpeed = (motionMag * motionSpeed).coerceIn(0f, 4f)

        fireMove = liveMove >= moveThr
        fireWave = liveWave >= waveThr
        fireMotion = motionMag >= motionThr
    }

    fun statusLine(): String {
        return "MOTION xyz ${"%.0f".format(axisX*100)}/${"%.0f".format(axisY*100)}/${"%.0f".format(axisZ*100)} " +
            "mv ${"%.0f".format(liveMove*100)}${if (fireMove) "!" else ""} " +
            "wv ${"%.0f".format(liveWave*100)}${if (fireWave) "!" else ""} " +
            "spd ${"%.1f".format(liveSpeed)} " +
            "P L${"%.0f".format(pitchL*100)} R${"%.0f".format(pitchR*100)} " +
            "U${"%.0f".format(pitchUp*100)} D${"%.0f".format(pitchDown*100)}"
    }

    /**
     * Signed sensor vectors and their scalar magnitudes, in the Android sensor
     * units. Kept separate from the existing normalized motion channels so
     * adding physics-style vector readouts does not alter existing behavior.
     */
    fun vectorStatusLine(): String {
        val accelMagnitude = sqrt(rawAx * rawAx + rawAy * rawAy + rawAz * rawAz)
        val gyroMagnitude = sqrt(rawGx * rawGx + rawGy * rawGy + rawGz * rawGz)
        return "ACCEL VECTOR <${"%.2f".format(rawAx)}, ${"%.2f".format(rawAy)}, ${"%.2f".format(rawAz)}> m/s² · " +
            "SCALAR |a|=${"%.2f".format(accelMagnitude)} m/s² · " +
            "GYRO VECTOR <${"%.2f".format(rawGx)}, ${"%.2f".format(rawGy)}, ${"%.2f".format(rawGz)}> rad/s · " +
            "SCALAR |ω|=${"%.2f".format(gyroMagnitude)} rad/s"
    }
}
