package com.mizan

/**
 * Bullet burst Hz + dB · Knife sharp Hz + dB · 0–50 Hz ultrasound · up to 300 dB SPL.
 * Outputs + thresholds · RAW COMPLETE.
 */
class UltrasoundWeaponOutBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Bullet burst
    @Volatile var bulletBurstOn = true
    @Volatile var bulletHz = 0f          // live Hz out
    @Volatile var bulletHzMin = 0f
    @Volatile var bulletHzMax = 50f      // ultrasound band default
    @Volatile var bulletDb = -120f       // live dB out
    @Volatile var bulletDbThr = -40f
    @Volatile var bulletDbLv = 0.80f
    @Volatile var bulletHzThr = 12f
    @Volatile var bulletOut = 0f
    @Volatile var bulletActive = false

    // Knife sharp
    @Volatile var knifeSharpOn = true
    @Volatile var knifeHz = 0f
    @Volatile var knifeHzMin = 0f
    @Volatile var knifeHzMax = 50f
    @Volatile var knifeDb = -120f
    @Volatile var knifeDbThr = -35f
    @Volatile var knifeDbLv = 0.80f
    @Volatile var knifeHzThr = 15f
    @Volatile var knifeOut = 0f
    @Volatile var knifeActive = false

    // Ultrasound 0–50 Hz · up to 300 dB SPL (display / control scale)
    @Volatile var ultraOn = true
    @Volatile var ultraHz = 0f
    @Volatile var ultraHzMin = 0f
    @Volatile var ultraHzMax = 50f
    @Volatile var ultraDbSpl = 0f        // 0..300 dB SPL scale
    @Volatile var ultraDbSplMax = 300f
    @Volatile var ultraThrHz = 5f
    @Volatile var ultraThrDb = 40f
    @Volatile var ultraLv = 0.85f
    @Volatile var ultraOut = 0f
    @Volatile var ultraActive = false

    // Shared live feed
    @Volatile var liveCentroidHz = 0f
    @Volatile var liveRmsDb = -90f
    @Volatile var livePeakDb = -90f

    @Volatile var status = "ULTRA·BULLET·KNIFE idle"

    private fun mapHz(e: Float, lo: Float, hi: Float): Float {
        return (lo + e.coerceIn(0f, 1f) * (hi - lo).coerceAtLeast(0.01f)).coerceIn(lo, hi)
    }

    private fun mapDb(e: Float, floor: Float = -120f, ceil: Float = 0f): Float {
        return (floor + e.coerceIn(0f, 1f) * (ceil - floor)).coerceIn(floor, ceil)
    }

    /** energy 0..1 → dB SPL 0..300 */
    private fun mapDbSpl(e: Float, maxSpl: Float = 300f): Float {
        return (e.coerceIn(0f, 1f) * maxSpl.coerceIn(1f, 300f)).coerceIn(0f, 300f)
    }

    fun tick(
        micEnergy: Float,
        centroidHz: Float = 0f,
        rmsDb: Float = -90f,
        peakDb: Float = -90f
    ) {
        if (!enabled) {
            status = "ULTRA·BULLET·KNIFE OFF"
            return
        }
        val e = micEnergy.coerceIn(0f, 1f)
        liveCentroidHz = centroidHz
        liveRmsDb = rmsDb
        livePeakDb = peakDb

        // Prefer live centroid when in 0–50 band; else energy-mapped
        val hzFromLive = if (centroidHz in 0f..50f) centroidHz else mapHz(e, 0f, 50f)
        val dbFromLive = if (rmsDb > -119f) rmsDb else mapDb(e)

        // —— Bullet burst ——
        if (bulletBurstOn || rawComplete) {
            bulletHz = hzFromLive.coerceIn(bulletHzMin, bulletHzMax.coerceAtMost(50f))
            bulletDb = dbFromLive
            val hzOk = bulletHz >= bulletHzThr.coerceIn(0f, 50f)
            val dbOk = bulletDb >= bulletDbThr.coerceIn(-120f, 0f)
            bulletActive = rawComplete || (hzOk && dbOk)
            bulletOut = if (bulletActive) {
                val h = ((bulletHz - bulletHzThr) / (50f - bulletHzThr).coerceAtLeast(1f)).coerceIn(0f, 1f)
                val d = ((bulletDb - bulletDbThr) / (0f - bulletDbThr).coerceAtLeast(1f)).coerceIn(0f, 1f)
                (maxOf(h, d, e) * bulletDbLv).coerceIn(0f, 1f)
            } else 0f
        } else {
            bulletActive = false; bulletOut = 0f; bulletHz = 0f; bulletDb = -120f
        }

        // —— Knife sharp ——
        if (knifeSharpOn || rawComplete) {
            knifeHz = hzFromLive.coerceIn(knifeHzMin, knifeHzMax.coerceAtMost(50f))
            knifeDb = dbFromLive
            val hzOk = knifeHz >= knifeHzThr.coerceIn(0f, 50f)
            val dbOk = knifeDb >= knifeDbThr.coerceIn(-120f, 0f)
            knifeActive = rawComplete || (hzOk && dbOk)
            knifeOut = if (knifeActive) {
                val h = ((knifeHz - knifeHzThr) / (50f - knifeHzThr).coerceAtLeast(1f)).coerceIn(0f, 1f)
                val d = ((knifeDb - knifeDbThr) / (0f - knifeDbThr).coerceAtLeast(1f)).coerceIn(0f, 1f)
                (maxOf(h, d, e) * knifeDbLv).coerceIn(0f, 1f)
            } else 0f
        } else {
            knifeActive = false; knifeOut = 0f; knifeHz = 0f; knifeDb = -120f
        }

        // —— Ultrasound 0–50 Hz · 0–300 dB SPL ——
        if (ultraOn || rawComplete) {
            ultraHz = hzFromLive.coerceIn(ultraHzMin, ultraHzMax.coerceIn(1f, 50f))
            ultraDbSpl = mapDbSpl(e, ultraDbSplMax)
            val hzOk = ultraHz >= ultraThrHz.coerceIn(0f, 50f)
            val dbOk = ultraDbSpl >= ultraThrDb.coerceIn(0f, 300f)
            ultraActive = rawComplete || hzOk || dbOk
            ultraOut = if (ultraActive) {
                val h = (ultraHz / 50f).coerceIn(0f, 1f)
                val d = (ultraDbSpl / ultraDbSplMax.coerceAtLeast(1f)).coerceIn(0f, 1f)
                (maxOf(h, d, e) * ultraLv).coerceIn(0f, 1f)
            } else 0f
        } else {
            ultraActive = false; ultraOut = 0f; ultraHz = 0f; ultraDbSpl = 0f
        }

        status =
            "BULLET ${"%.1f".format(bulletHz)}Hz ${"%.1f".format(bulletDb)}dB out=${(bulletOut*100).toInt()}% " +
            (if (bulletActive) "HIT" else "-") + " · " +
            "KNIFE ${"%.1f".format(knifeHz)}Hz ${"%.1f".format(knifeDb)}dB out=${(knifeOut*100).toInt()}% " +
            (if (knifeActive) "HIT" else "-") + " · " +
            "ULTRA ${"%.1f".format(ultraHz)}Hz ${"%.0f".format(ultraDbSpl)}dBSPL/300 out=${(ultraOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard) {
        if (!enabled) return
        // Always keep Hz/dB gate aligned with 0–50 ultrasound band
        sb.bulletHzDbGateOn = true
        sb.bulletHzMin = 0f
        sb.bulletHzMax = 50f
        sb.bulletDbfsThr = minOf(sb.bulletDbfsThr, -50f)
        if (bulletBurstOn) {
            sb.bulletOn = true
            if (bulletOut > 0.01f || rawComplete) {
                sb.bulletOut = maxOf(sb.bulletOut, bulletOut.coerceAtLeast(if (rawComplete) sb.liveAudioEnergy * bulletDbLv else 0f))
                sb.bulletActive = sb.bulletOut > 0.02f
                sb.burstOut = maxOf(sb.burstOut, sb.bulletOut * 0.9f)
                sb.burstActive = sb.burstOut > 0.02f
            }
        }
        if (knifeSharpOn) {
            sb.knifeOn = true
            if (knifeOut > 0.01f || rawComplete) {
                sb.knifeOut = maxOf(sb.knifeOut, knifeOut.coerceAtLeast(if (rawComplete) sb.liveAudioEnergy * knifeDbLv else 0f))
                sb.knifeActive = sb.knifeOut > 0.02f
                sb.sharpOut = maxOf(sb.sharpOut, sb.knifeOut * 0.9f)
            }
        }
        if (ultraOn && ultraOut > 0.01f) {
            // ultrasound feeds bullet+burst detection energy
            sb.bulletOut = maxOf(sb.bulletOut, ultraOut * 0.85f)
            sb.burstOut = maxOf(sb.burstOut, ultraOut * 0.80f)
            if (sb.bulletOut > 0.02f) sb.bulletActive = true
            if (sb.burstOut > 0.02f) sb.burstActive = true
        }
    }
}
