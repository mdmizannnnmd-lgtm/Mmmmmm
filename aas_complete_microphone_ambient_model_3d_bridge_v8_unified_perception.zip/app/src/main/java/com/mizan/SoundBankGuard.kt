package com.mizan

import kotlin.math.abs
import kotlin.math.max

/**
 * Full-app Sound Bank (own bank) — atmosphere + body-surface communication.
 *
 * - Audio focus level / movement / speed / waves
 * - Bipolar ±1000 dB threshold rails
 * - Enemy-body auto-trigger when energy crosses threshold
 * - RAW COMPLETE: pure path, no soft gates
 * - Feeds model mixer via [mixEnergy]
 */
class SoundBankGuard {
    @Volatile var enabled = true
    /** RAW COMPLETE — pure energy / dB path, no thr soft mix */
    @Volatile var rawComplete = true

    // ── Tracking ──────────────────────────────────────────────
    @Volatile var trackOn = true
    @Volatile var trackThr = 0.45f
    @Volatile var trackActive = false
    @Volatile var trackLevel = 0f
    @Volatile var thrTrackOn = true
    @Volatile var thrTrackThr = 0.40f
    @Volatile var thrTrackActive = false

    @Volatile var ambientTrackOn = true
    @Volatile var ambientTrackThr = 0.30f
    @Volatile var ambientTrackLv = 0.55f
    @Volatile var ambientTrackActive = false
    @Volatile var ambientTrackOut = 0f

    // ── Atmosphere (atomspare) as sound bank ───────────────────
    @Volatile var atmoSpikeProtOn = true
    @Volatile var atmoSpikeProtThr = 0.50f
    @Volatile var atmoSpikeProtLv = 0.70f
    @Volatile var atmoSpikeProtActive = false

    @Volatile var optHardGate = false
    @Volatile var optSoftFade = true
    @Volatile var optLinkAmbient = true

    @Volatile var detectOn = true
    @Volatile var detectThr = 0.35f
    @Volatile var detectOut = 0f
    @Volatile var detectActive = false

    @Volatile var silenceOn = true
    @Volatile var silenceThr = 0.08f
    @Volatile var silenceActive = false

    @Volatile var blockOn = true
    @Volatile var blockThr = 0.55f
    @Volatile var blockActive = false
    @Volatile var blockFactor = 1f

    @Volatile var atmoSpikeBankOn = true
    @Volatile var atmoSpikeThr = 0.60f
    @Volatile var atmoSpikeLv = 0.70f
    @Volatile var atmoSpikeActive = false

    @Volatile var atmoSpeedOn = true
    @Volatile var atmoSpeedLv = 0.50f
    @Volatile var atmoSpeedThr = 0.30f
    @Volatile var atmoMoveOn = true
    @Volatile var atmoMoveLv = 0.50f
    @Volatile var atmoMoveThr = 0.30f
    @Volatile var atmoWaveOn = true
    @Volatile var atmoWaveLv = 0.50f
    @Volatile var atmoWaveThr = 0.30f

    /** Atmosphere bipolar ±1000 dB */
    @Volatile var atmoBipNeg = -1000f
    @Volatile var atmoBipPos = 1000f
    @Volatile var atmoBipOn = true
    @Volatile var atmoBipHit = false

    @Volatile var atmoSpeedActive = false
    @Volatile var atmoMoveActive = false
    @Volatile var atmoWaveActive = false

    @Volatile var atmoTrackOn = true
    @Volatile var atmoTrackThr = 0.40f
    @Volatile var atmoTrackLv = 0.55f
    @Volatile var atmoTrackActive = false
    @Volatile var atmoTrackOut = 0f

    @Volatile var moveTrackOn = true
    @Volatile var moveTrackThr = 0.35f
    @Volatile var moveTrackLv = 0.50f
    @Volatile var moveTrackActive = false
    @Volatile var moveTrackOut = 0f

    // ── dB limiter (tracking-driven) ──────────────────────────
    @Volatile var dbLimitOn = true
    @Volatile var dbLimitCeil = -12f
    @Volatile var dbLimitFloor = -80f
    @Volatile var dbLimitLv = 0.70f
    @Volatile var dbLimitActive = false
    @Volatile var dbLimitOut = 0f
    @Volatile var dbLimitedDb = -80.0

    @Volatile var ambLimitOn = true
    @Volatile var ambLimitThr = 0.55f
    @Volatile var ambLimitCeil = 0.70f
    @Volatile var ambLimitLv = 0.65f
    @Volatile var ambLimitActive = false
    @Volatile var ambLimitOut = 0f

    // ── Audio focus (own bank) ────────────────────────────────
    @Volatile var audioFocusOn = true
    @Volatile var audioFocusLv = 0.70f
    @Volatile var audioFocusThr = 0.25f
    @Volatile var audioFocusActive = false
    @Volatile var audioFocusOut = 0f

    @Volatile var focusMoveOn = true
    @Volatile var focusMoveLv = 0.55f
    @Volatile var focusMoveThr = 0.30f
    @Volatile var focusMoveActive = false
    @Volatile var focusMoveOut = 0f

    @Volatile var focusSpeedOn = true
    @Volatile var focusSpeedLv = 0.55f
    @Volatile var focusSpeedThr = 0.30f
    @Volatile var focusSpeedActive = false
    @Volatile var focusSpeedOut = 0f

    @Volatile var focusWaveOn = true
    @Volatile var focusWaveLv = 0.55f
    @Volatile var focusWaveThr = 0.30f
    @Volatile var focusWaveActive = false
    @Volatile var focusWaveOut = 0f

    /** Master bipolar ±1000 dB for focused audio bank */
    @Volatile var bipDbOn = true
    @Volatile var bipDbNeg = -1000f
    @Volatile var bipDbPos = 1000f
    @Volatile var bipDbHit = false
    @Volatile var bipDbOut = 0f

    // ── Enemy-body communication bank ─────────────────────────
    /** Auto-trigger when enemy-body energy crosses threshold */
    @Volatile var enemyBodyOn = true
    @Volatile var enemyBodyThr = 0.40f
    @Volatile var enemyBodyLv = 0.75f
    @Volatile var enemyBodyActive = false
    @Volatile var enemyBodyOut = 0f
    /** Live enemy-body energy from pose / seg / mixer (0..1) */
    @Volatile var enemyBodyEnergy = 0f
    @Volatile var enemyBodyMove = 0f
    @Volatile var enemyBodySpeed = 0f
    @Volatile var enemyBodyWave = 0f

    /** Body-surface communication rail */
    @Volatile var bodySurfCommOn = true
    @Volatile var bodySurfCommThr = 0.35f
    @Volatile var bodySurfCommLv = 0.60f
    @Volatile var bodySurfCommActive = false
    @Volatile var bodySurfCommOut = 0f

    // ── Microphone-driven enemy sounds threshold ──────────────
    /** Mic / audio energy drives enemy sound bank (true mic path) */
    @Volatile var micDrivenOn = true
    @Volatile var micEnemyThr = 0.42f
    @Volatile var micEnemyLv = 0.80f
    @Volatile var micEnemyActive = false
    @Volatile var micEnemyOut = 0f
    @Volatile var micDb = -80.0

    // ── Protection: MY body move / speed / wave vs enemy sounds ─
    @Volatile var protectBodyOn = true
    @Volatile var protectMoveOn = true
    @Volatile var protectSpeedOn = true
    @Volatile var protectWaveOn = true
    @Volatile var protectLv = 0.90f
    @Volatile var protectThr = 0.35f
    @Volatile var protectActive = false
    /** 1 = full motion; lower = protected (damp enemy influence on me) */
    @Volatile var protectMoveFactor = 1f
    @Volatile var protectSpeedFactor = 1f
    @Volatile var protectWaveFactor = 1f

    // ── Enemy communication blocker ───────────────────────────
    @Volatile var enemyCommBlockOn = true
    @Volatile var enemyCommBlockThr = 0.40f
    @Volatile var enemyCommBlockLv = 0.85f
    @Volatile var enemyCommBlockActive = false
    @Volatile var enemyCommBlockOut = 0f
    /** Scale applied to enemy-side communication (0 = fully blocked) */
    @Volatile var enemyCommScale = 1f

    // ── Anti-audio focused bank (mic-driven counter) ─────────
    @Volatile var antiAudioOn = true
    @Volatile var antiAudioThr = 0.40f
    @Volatile var antiAudioLv = 0.80f
    @Volatile var antiAudioActive = false
    @Volatile var antiAudioOut = 0f
    @Volatile var antiAudioCount = 0

    // ── Anti-body sounds bank + counters ──────────────────────
    @Volatile var antiBodyOn = true
    @Volatile var antiBodyThr = 0.38f
    @Volatile var antiBodyLv = 0.75f
    @Volatile var antiBodyActive = false
    @Volatile var antiBodyOut = 0f
    @Volatile var antiBodyCount = 0
    @Volatile var antiBodyMoveCount = 0
    @Volatile var antiBodySpeedCount = 0
    @Volatile var antiBodyWaveCount = 0

    // ── Atmosphere (atomspare) fire bank ± bipolar dB ─────────
    @Volatile var atmoFireOn = true
    @Volatile var atmoFireThr = 0.45f
    @Volatile var atmoFireLv = 0.85f
    @Volatile var atmoFireActive = false
    @Volatile var atmoFireOut = 0f
    @Volatile var atmoFireBipNeg = -1000f
    @Volatile var atmoFireBipPos = 1000f
    @Volatile var atmoFireBipHit = false
    /** Manual / floating-button latch (0..1) */
    @Volatile var atmoFireLatch = 0f

    // ── Eye fire / Head fire (audio-focus driven + manual) ────
    @Volatile var eyeFireOn = true
    @Volatile var eyeFireThr = 0.40f
    @Volatile var eyeFireLv = 0.80f
    @Volatile var eyeFireActive = false
    @Volatile var eyeFireOut = 0f
    @Volatile var eyeFireLatch = 0f

    @Volatile var bodyFireOn = true
    @Volatile var asFireOn = true
    @Volatile var gunFireOn = true
    @Volatile var collapseFireOn = true
    /** LHC · live mic collapse/collide · axis collapse · echo-cancel couple */
    @Volatile var ambSysCollapseOn = true
    @Volatile var enemyBankCollapseOn = true
    @Volatile var soundsBankCollideOn = true
    @Volatile var ambSysCollapseOut = 0f
    @Volatile var enemyBankCollapseOut = 0f
    @Volatile var soundsBankCollideOut = 0f
    @Volatile var ambSysCollapseLatch = 0f
    @Volatile var enemyBankCollapseLatch = 0f
    @Volatile var lhcColliderOn = true
    @Volatile var lhcEchoCancelOn = true
    @Volatile var lhcAxisCollapseOn = true
    @Volatile var lhcEnergy = 0.75f
    @Volatile var lhcThr = 0.40f
    @Volatile var lhcDbThr = 45f
    @Volatile var lhcOut = 0f
    @Volatile var lhcOurDb = 0f
    @Volatile var lhcEnemyDb = 0f
    @Volatile var lhcBeam = 0f
    @Volatile var lhcCollide = false
    @Volatile var lhcAxisX = 0f
    @Volatile var lhcAxisY = 0f
    @Volatile var lhcAxisZ = 0f
    var lhcFireLatch = 0f
    @Volatile var antiFireOn = true
    @Volatile var headFireOn = true
    @Volatile var headFireThr = 0.40f
    @Volatile var headFireLv = 0.80f
    @Volatile var headFireActive = false
    @Volatile var headFireOut = 0f
    @Volatile var bodyFireLatch = 0f
    var asFireLatch = 0f
    var gunFireLatch = 0f
    var collapseFireLatch = 0f
    var antiFireLatch = 0f
    var bodyFireOut = 0f
    var asFireOut = 0f
    var gunFireOut = 0f
    var collapseFireOut = 0f
    var antiFireOut = 0f
    var headFireLatch = 0f

    // ── Enemy sounds bank FX thresholds + protection ─────────
    @Volatile var bulletOn = true
    @Volatile var bulletThr = 0.28f
    @Volatile var bulletLv = 0.70f
    @Volatile var bulletActive = false
    @Volatile var bulletOut = 0f
    @Volatile var bulletProtect = true
    /** Enemy bullets / prank burst — audio+camera focused protection */
    @Volatile var enemyBulletPrankProtect = true
    @Volatile var enemyBulletPrankThr = 0.25f
    @Volatile var enemyBulletPrankLv = 0.92f
    @Volatile var enemyBulletPrankOut = 0f
    @Volatile var cameraFocusOn = true
    @Volatile var cameraFocusThr = 0.20f
    @Volatile var cameraFocusLv = 0.75f
    @Volatile var cameraFocusOut = 0f
    @Volatile var cameraFocusEnergy = 0f

    @Volatile var knifeOn = true
    @Volatile var knifeThr = 0.45f
    @Volatile var knifeLv = 0.65f
    @Volatile var knifeActive = false
    @Volatile var knifeOut = 0f
    @Volatile var knifeProtect = true

    // Whip effect — fast transient attack (model × mic driven)
    @Volatile var whipOn = true
    @Volatile var whipThr = 0.40f
    @Volatile var whipLv = 0.70f
    @Volatile var whipActive = false
    @Volatile var whipOut = 0f
    @Volatile var whipProtect = true
    @Volatile var whipModelDrive = true
    @Volatile var whipModelScale = 1f

    @Volatile var rippleOn = true
    @Volatile var rippleThr = 0.30f
    @Volatile var rippleLv = 0.55f
    @Volatile var rippleActive = false
    @Volatile var rippleOut = 0f
    @Volatile var rippleProtect = true

    // Sharp channel attack (spectral brightness × mic energy) + burst channel (peak rise).
    // Fully functional audio-reactive attack paths — not simulator/visual-only.
    @Volatile var sharpOn = true
    @Volatile var sharpThr = 0.35f
    @Volatile var sharpLv = 0.70f
    @Volatile var sharpActive = false
    @Volatile var sharpOut = 0f
    @Volatile var sharpProtect = true
    @Volatile var burstOn = true
    @Volatile var burstThr = 0.22f
    @Volatile var burstLv = 0.70f
    @Volatile var burstActive = false
    @Volatile var burstOut = 0f
    @Volatile var burstProtect = true
    /** Mobile-specific burst/knife protection — enemy cannot land SFX on our mobile / body / head */
    @Volatile var mobileBurstProtect = true
    @Volatile var mobileBurstProtectLv = 0.92f
    @Volatile var mobileKnifeProtect = true
    @Volatile var mobileKnifeProtectLv = 0.92f
    @Volatile var blockEnemyBurstOnBody = true
    @Volatile var blockEnemyBurstOnHead = true
    @Volatile var blockEnemyBurstOnMobile = true
    @Volatile var mobileBurstBlockOut = 0f
    @Volatile var mobileKnifeBlockOut = 0f
    /** Full functional sharp/burst channel output 0..1 (no visual-only simulator cap). */
    private val sharpBurstFullScale = 1.0f

    // Optional FFT/dBFS gates for generic visual FX. Off by default so legacy
    // threshold behavior is unchanged. These gates do not classify real events.
    @Volatile var bulletHzDbGateOn = true
    @Volatile var bulletHzMin = 0f
    @Volatile var bulletHzMax = 50f
    @Volatile var bulletDbfsThr = -55f
    @Volatile var knifeHzDbGateOn = false
    @Volatile var knifeHzMin = 400f
    @Volatile var knifeHzMax = 10000f
    @Volatile var knifeDbfsThr = -52f
    @Volatile var rippleHzDbGateOn = false
    @Volatile var rippleHzMin = 20f
    @Volatile var rippleHzMax = 1200f
    @Volatile var rippleDbfsThr = -54f

    // Camera pose/mask confidence can gate an FX to a selected model segment.
    // This is a visual destination, never a microphone source-localization claim.
    @Volatile var bodyPartGateOn = false
    @Volatile var bodyPartGateThr = 0.18f
    @Volatile var bodyPartTarget = HumanDetection.PART_TORSO
    @Volatile var bodyPartConfidence = 0f

    @Volatile var axisX = 0f
    @Volatile var axisY = 0f
    @Volatile var axisZ = 0f
    @Volatile var vibeOut = 0f
    @Volatile var liveAudioEnergy = 0f
        private set
    @Volatile var liveDominantHz = 0f
    /** Unclamped detected Hz for meter boards (0 → unlimited analysis) */
    @Volatile var liveDetectedHzUnlimited = 0f
        private set
    @Volatile var liveCentroidHz = 0f
        private set
    @Volatile var liveRmsDbfs = -90.0
        private set
    @Volatile var livePeakDbfs = -90.0
        private set
    @Volatile var liveBurstRiseDb = 0f
        private set
    @Volatile private var liveAudioAtMs = 0L

    /** Cache measurements from the live microphone for optional visual FX gates. */
    fun feedAudioAnalysis(
        energy: Float,
        dominantHz: Float,
        centroidHz: Float,
        rmsDbfs: Double,
        peakDbfs: Double
    ) {
        liveAudioEnergy = energy.coerceIn(0f, 1f)
        liveDetectedHzUnlimited = dominantHz.coerceAtLeast(0f)
        liveDominantHz = dominantHz.coerceIn(0f, 20000f)
        liveCentroidHz = centroidHz.coerceIn(0f, 20000f)
        liveRmsDbfs = rmsDbfs.coerceIn(-120.0, 0.0)
        val nextPeak = peakDbfs.coerceIn(-120.0, 0.0)
        liveBurstRiseDb = if (liveAudioAtMs > 0L) {
            (nextPeak - livePeakDbfs).toFloat().coerceIn(0f, 60f)
        } else 0f
        livePeakDbfs = nextPeak
        liveAudioAtMs = System.currentTimeMillis()
    }

    fun feedBodyPartTarget(partIndex: Int, confidence: Float) {
        bodyPartTarget = partIndex.coerceIn(0, HumanDetection.PART_NAMES.lastIndex)
        bodyPartConfidence = confidence.coerceIn(0f, 1f)
    }

    private fun passesHzDbGate(enabled: Boolean, lowHz: Float, highHz: Float, minDbfs: Float): Boolean {
        if (!enabled) return true
        val age = System.currentTimeMillis() - liveAudioAtMs
        if (liveAudioAtMs <= 0L || age !in 0..2000L) return false
        val low = lowHz.coerceIn(0f, 20000f)
        val high = highHz.coerceIn(low, 20000f)
        return liveAudioEnergy >= 0.005f &&
            liveDominantHz in low..high &&
            liveRmsDbfs >= minDbfs.coerceIn(-120f, 0f)
    }

    private fun hasFreshAudioAnalysis(): Boolean {
        val age = System.currentTimeMillis() - liveAudioAtMs
        return liveAudioAtMs > 0L && age in 0..1200L
    }

    /** Full functional path — no simulator/visual-only ceiling. */
    private fun scaleSharpBurst(value: Float): Float =
        value.coerceIn(0f, sharpBurstFullScale)

    @Volatile var whistleOn = true
    @Volatile var whistleThr = 0.48f
    @Volatile var whistleLv = 0.60f
    @Volatile var whistleActive = false
    @Volatile var whistleOut = 0f
    @Volatile var whistleProtect = true

    @Volatile var ambitiousOn = true
    @Volatile var ambitiousThr = 0.42f
    @Volatile var ambitiousLv = 0.65f
    @Volatile var ambitiousActive = false
    @Volatile var ambitiousOut = 0f
    @Volatile var ambitiousProtect = true

    // Live mic scan: collide + collapsing system
    @Volatile var collideOn = true
    @Volatile var collideThr = 0.50f
    @Volatile var collideLv = 0.75f
    @Volatile var collideActive = false
    @Volatile var collideOut = 0f
    @Volatile var collapseOn = true
    @Volatile var collapseThr = 0.60f
    @Volatile var collapseLv = 0.80f
    @Volatile var collapseActive = false
    @Volatile var collapseOut = 0f
    @Volatile var micScanLive = 0f

    /** Protection scale against enemy FX (1 = full protect damp) */
    @Volatile var enemyFxProtectLv = 0.90f
    @Volatile var enemyFxProtectOut = 0f
    /** Master shield: damp ALL enemy effect channels when threat high */
    @Volatile var enemyMasterShieldOn = true
    @Volatile var enemyMasterShieldLv = 0.85f
    @Volatile var enemyMasterShieldOut = 0f
    @Volatile var arRealityShieldOn = true
    @Volatile var arRealityShieldLv = 0.80f
    @Volatile var arRealityShieldOut = 0f

    // ── Atmosphere centroid sounds (nature) + ANC level ─────
    /** Atomspare/atmosphere centroid — live nature-style ambient centroid */
    @Volatile var atmoCentroidOn = true
    @Volatile var atmoCentroidThr = 0.28f
    @Volatile var atmoCentroidLv = 0.65f
    @Volatile var atmoCentroidActive = false
    @Volatile var atmoCentroidOut = 0f
    /** Rolling centroid of ambient/mic energy (nature rail) */
    private val atmoHist = FloatArray(32)
    private var atmoHistIdx = 0
    private var atmoHistN = 0
    @Volatile var atmoCentroidNorm = 0f

    /** ANC level sounds — for collide system in nature */
    @Volatile var ancOn = true
    @Volatile var ancLv = 0.70f
    @Volatile var ancThr = 0.35f
    @Volatile var ancActive = false
    @Volatile var ancOut = 0f
    /** ANC protect: damp enemy FX when nature centroid / collide is hot */
    @Volatile var ancProtectOn = true
    @Volatile var ancProtectLv = 0.90f
    @Volatile var ancProtectOut = 0f

    /** Own nature motion sound rail (any motion/sound into ANC·centroid) */
    @Volatile var natureMotionOn = true
    @Volatile var natureMotionOut = 0f

    /** Device-linked enemy energy (same enemy body system — for 3D game device figures) */
    @Volatile var deviceEnemyOut = 0f
        private set

    /** Mix energy for model mixer (0..1) */
    @Volatile var mixEnergy = 0f
        private set

    /**
     * @param energy normalized ambient/render energy 0..1
     * @param db live level dB (may be outside −1000..+1000; clamped for bipolar)
     * @param peak peak energy 0..1
     * @param enemyE optional enemy-body energy 0..1 (pose/seg)
     * @param enemyMove optional enemy movement 0..1
     * @param enemySpeed optional enemy speed 0..1
     * @param enemyWave optional enemy wave 0..1
     */
    fun tick(
        energy: Float,
        db: Double = -80.0,
        peak: Float = energy,
        enemyE: Float = 0f,
        enemyMove: Float = 0f,
        enemySpeed: Float = 0f,
        enemyWave: Float = 0f
    ) {
        val e = energy.coerceIn(0f, 1f)
        val pk = peak.coerceIn(0f, 1f)
        enemyBodyEnergy = enemyE.coerceIn(0f, 1f)
        enemyBodyMove = enemyMove.coerceIn(0f, 1f)
        enemyBodySpeed = enemySpeed.coerceIn(0f, 1f)
        enemyBodyWave = enemyWave.coerceIn(0f, 1f)

        if (!enabled) {
            trackActive = false; blockActive = false; atmoSpikeActive = false
            atmoSpeedActive = false; atmoMoveActive = false; atmoWaveActive = false
            atmoTrackActive = false; atmoTrackOut = 0f
            moveTrackActive = false; moveTrackOut = 0f
            dbLimitActive = false; dbLimitOut = 0f; dbLimitedDb = db
            ambLimitActive = false; ambLimitOut = 0f
            audioFocusActive = false; audioFocusOut = 0f
            focusMoveActive = false; focusMoveOut = 0f
            focusSpeedActive = false; focusSpeedOut = 0f
            focusWaveActive = false; focusWaveOut = 0f
            enemyBodyActive = false; enemyBodyOut = 0f
            bodySurfCommActive = false; bodySurfCommOut = 0f
            micEnemyActive = false; micEnemyOut = 0f
            protectActive = false
            protectMoveFactor = 1f; protectSpeedFactor = 1f; protectWaveFactor = 1f
            enemyCommBlockActive = false; enemyCommBlockOut = 0f; enemyCommScale = 1f
            antiAudioActive = false; antiAudioOut = 0f
            antiBodyActive = false; antiBodyOut = 0f
            atmoFireActive = false; atmoFireOut = 0f; atmoFireBipHit = false
            eyeFireActive = false; eyeFireOut = 0f
            headFireActive = false; headFireOut = 0f
            bulletActive = false; knifeActive = false; rippleActive = false
            sharpActive = false; sharpOut = 0f
            burstActive = false; burstOut = 0f
            whistleActive = false; ambitiousActive = false
            collideActive = false; collapseActive = false
            enemyFxProtectOut = 0f
            atmoCentroidActive = false; atmoCentroidOut = 0f
            ancActive = false; ancOut = 0f; ancProtectOut = 0f
            natureMotionOut = 0f
            bipDbHit = false; bipDbOut = 0f; atmoBipHit = false
            blockFactor = 1f; mixEnergy = 0f
            return
        }

        // RAW COMPLETE: pure path
        if (rawComplete) {
            trackLevel = e
            trackActive = true
            thrTrackActive = true
            ambientTrackActive = true
            ambientTrackOut = e
            detectActive = true
            detectOut = e
            silenceActive = false
            blockActive = false
            blockFactor = 1f
            atmoSpikeActive = e > 0.5f
            atmoSpeedActive = true
            atmoMoveActive = true
            atmoWaveActive = true
            atmoTrackActive = true
            atmoTrackOut = e
            moveTrackActive = true
            moveTrackOut = e
            audioFocusActive = true
            audioFocusOut = e * audioFocusLv.coerceIn(0f, 1f)
            focusMoveActive = true
            focusMoveOut = e * focusMoveLv.coerceIn(0f, 1f)
            focusSpeedActive = true
            focusSpeedOut = e * focusSpeedLv.coerceIn(0f, 1f)
            focusWaveActive = true
            focusWaveOut = e * focusWaveLv.coerceIn(0f, 1f)
            // bipolar RAW: map db into ±1000
            val dbClamped = db.coerceIn(-1000.0, 1000.0)
            bipDbHit = true
            bipDbOut = ((dbClamped + 1000.0) / 2000.0).toFloat().coerceIn(0f, 1f)
            atmoBipHit = true
            dbLimitActive = false
            dbLimitOut = e
            dbLimitedDb = dbClamped
            ambLimitActive = false
            ambLimitOut = e
            // enemy body auto
            enemyBodyActive = enemyBodyOn && enemyBodyEnergy >= 0.01f
            enemyBodyOut = if (enemyBodyActive) enemyBodyEnergy * enemyBodyLv.coerceIn(0f, 1f) else 0f
            bodySurfCommActive = bodySurfCommOn
            bodySurfCommOut = e * bodySurfCommLv.coerceIn(0f, 1f)
            micDb = db
            micEnemyActive = micDrivenOn
            micEnemyOut = e * micEnemyLv.coerceIn(0f, 1f)
            protectActive = protectBodyOn
            // RAW protect: still damp enemy influence on my body channels
            val pRaw = if (protectBodyOn) (1f - protectLv.coerceIn(0f, 1f) * maxOf(micEnemyOut, enemyBodyOut, enemyMasterShieldOut, arRealityShieldOut) * 0.95f).coerceIn(0.05f, 1f) else 1f
            protectMoveFactor = if (protectMoveOn) pRaw else 1f
            protectSpeedFactor = if (protectSpeedOn) pRaw else 1f
            protectWaveFactor = if (protectWaveOn) pRaw else 1f
            enemyCommBlockActive = enemyCommBlockOn
            enemyCommBlockOut = maxOf(micEnemyOut, enemyBodyOut)
            enemyCommScale = if (enemyCommBlockOn) (1f - enemyCommBlockLv.coerceIn(0f, 1f) * enemyCommBlockOut).coerceIn(0.05f, 1f) else 1f
            antiAudioActive = antiAudioOn
            antiAudioOut = e * antiAudioLv.coerceIn(0f, 1f)
            antiBodyActive = antiBodyOn
            antiBodyOut = e * antiBodyLv.coerceIn(0f, 1f)
            atmoFireActive = atmoFireOn
            atmoFireOut = maxOf(e, atmoFireLatch) * atmoFireLv.coerceIn(0f, 1f)
            atmoFireBipHit = true
            eyeFireActive = eyeFireOn
            eyeFireOut = maxOf(e, eyeFireLatch) * eyeFireLv.coerceIn(0f, 1f)
            headFireActive = headFireOn
            headFireOut = maxOf(e, headFireLatch) * headFireLv.coerceIn(0f, 1f)
            bulletActive = true; bulletOut = e * bulletLv
            knifeActive = true; knifeOut = e * knifeLv
            rippleActive = true; rippleOut = e * rippleLv
            whistleActive = true; whistleOut = e * whistleLv
            ambitiousActive = true; ambitiousOut = e * ambitiousLv
            collideActive = true; collideOut = e * collideLv
            collapseActive = true; collapseOut = e * collapseLv
            micScanLive = e
            enemyFxProtectOut = e * enemyFxProtectLv
            deviceEnemyOut = e
            atmoCentroidActive = true
            atmoCentroidOut = e * atmoCentroidLv
            atmoCentroidNorm = e
            ancActive = true
            ancOut = e * ancLv
            ancProtectOut = e * ancProtectLv
            val rawAudioFresh = hasFreshAudioAnalysis()
            val rawSharpSrc = if (rawAudioFresh) {
                (liveAudioEnergy * (liveCentroidHz / 10000f).coerceIn(0f, 1f)).coerceIn(0f, 1f)
            } else 0f
            val rawBurstSrc = if (rawAudioFresh) (liveBurstRiseDb / 30f).coerceIn(0f, 1f) else 0f
            sharpActive = sharpOn && rawSharpSrc > 0.005f
            burstActive = burstOn && rawBurstSrc > 0.005f
            val rawVisualDamp = (1f - maxOf(enemyFxProtectOut, ancProtectOut) * 0.85f).coerceIn(0.1f, 1f)
            sharpOut = if (sharpActive) scaleSharpBurst(rawSharpSrc * sharpLv.coerceIn(0f, 1f) * rawVisualDamp) else 0f
            burstOut = if (burstActive) scaleSharpBurst(rawBurstSrc * burstLv.coerceIn(0f, 1f) * rawVisualDamp) else 0f
            natureMotionOut = e
            mixEnergy = maxOf(e, audioFocusOut, enemyBodyOut, bodySurfCommOut, micEnemyOut,
                antiAudioOut, antiBodyOut, atmoFireOut, eyeFireOut, headFireOut, bipDbOut * 0.5f,
                bulletOut, knifeOut, rippleOut, sharpOut, burstOut, whistleOut, ambitiousOut, collideOut, collapseOut,
                atmoCentroidOut, ancOut, natureMotionOut)
            return
        }

        trackLevel = e
        trackActive = trackOn && e >= trackThr.coerceIn(0.05f, 1f)
        thrTrackActive = thrTrackOn && e >= thrTrackThr.coerceIn(0.05f, 1f)

        ambientTrackOut = if (ambientTrackOn) {
            val t = ambientTrackThr.coerceIn(0.05f, 1f)
            if (e >= t) (e * ambientTrackLv.coerceIn(0f, 1f)).coerceIn(0f, 1f) else e * 0.15f
        } else 0f
        ambientTrackActive = ambientTrackOn && e >= ambientTrackThr.coerceIn(0.05f, 1f)

        atmoSpikeProtActive = atmoSpikeProtOn && e >= atmoSpikeProtThr.coerceIn(0.05f, 1f)
        if (atmoSpikeProtActive && optLinkAmbient) {
            ambientTrackOut = maxOf(ambientTrackOut, atmoSpikeProtLv * 0.5f)
        }

        detectActive = detectOn && e >= detectThr.coerceIn(0.05f, 1f)
        detectOut = if (detectActive) {
            val t = detectThr.coerceIn(0.05f, 1f)
            (((e - t) / (1f - t).coerceAtLeast(0.05f))).coerceIn(0f, 1f)
        } else 0f

        silenceActive = silenceOn && e <= silenceThr.coerceIn(0f, 0.5f)

        blockActive = blockOn && e >= blockThr.coerceIn(0.05f, 1f)
        blockFactor = when {
            !blockActive -> 1f
            optHardGate -> 0.15f
            optSoftFade -> (1f - ((e - blockThr) / (1f - blockThr).coerceAtLeast(0.05f)).coerceIn(0f, 1f) * 0.7f)
            else -> 0.5f
        }

        atmoSpikeActive = atmoSpikeBankOn && e >= atmoSpikeThr.coerceIn(0.05f, 1f)
        atmoSpeedActive = atmoSpeedOn && e >= atmoSpeedThr.coerceIn(0.05f, 1f)
        atmoMoveActive = atmoMoveOn && e >= atmoMoveThr.coerceIn(0.05f, 1f)
        atmoWaveActive = atmoWaveOn && e >= atmoWaveThr.coerceIn(0.05f, 1f)

        // Atmosphere bipolar ±1000 dB
        val dbF = db.toFloat().coerceIn(-1000f, 1000f)
        atmoBipHit = atmoBipOn && (dbF <= atmoBipNeg.coerceIn(-1000f, 0f) || dbF >= atmoBipPos.coerceIn(0f, 1000f))

        atmoTrackOut = if (atmoTrackOn) {
            val t = atmoTrackThr.coerceIn(0.05f, 1f)
            if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * atmoTrackLv.coerceIn(0f, 1f)).coerceIn(0f, 1f) else 0f
        } else 0f
        atmoTrackActive = atmoTrackOn && e >= atmoTrackThr.coerceIn(0.05f, 1f)

        moveTrackOut = if (moveTrackOn) {
            val t = moveTrackThr.coerceIn(0.05f, 1f)
            if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * moveTrackLv.coerceIn(0f, 1f)).coerceIn(0f, 1f) else 0f
        } else 0f
        moveTrackActive = moveTrackOn && e >= moveTrackThr.coerceIn(0.05f, 1f)

        // dB limiter
        val trackHot = trackActive || thrTrackActive || atmoTrackActive || moveTrackActive || ambientTrackActive
        val ceil = dbLimitCeil.coerceIn(-60f, 0f).toDouble()
        val floor = dbLimitFloor.coerceIn(-120f, -20f).toDouble()
        if (dbLimitOn && trackHot && db > ceil) {
            dbLimitActive = true
            val span = (db - ceil).coerceAtLeast(0.0)
            val depth = (span / (0.0 - ceil + 1e-6)).coerceIn(0.0, 1.0).toFloat()
            dbLimitOut = (depth * dbLimitLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
            dbLimitedDb = ceil + (db - ceil) * (1.0 - dbLimitOut.toDouble())
            if (dbLimitedDb < floor) dbLimitedDb = floor
        } else {
            dbLimitActive = false
            dbLimitOut = 0f
            dbLimitedDb = db
        }

        val ambT = ambLimitThr.coerceIn(0.05f, 1f)
        val ambC = ambLimitCeil.coerceIn(0.10f, 1f)
        if (ambLimitOn && ambientTrackOut > ambT) {
            ambLimitActive = true
            val over = ((ambientTrackOut - ambT) / (1f - ambT).coerceAtLeast(0.05f)).coerceIn(0f, 1f)
            ambLimitOut = (over * ambLimitLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
            ambientTrackOut = ambientTrackOut.coerceAtMost(ambC * (1f - ambLimitOut * 0.5f) + ambT * ambLimitOut)
        } else {
            ambLimitActive = false
            ambLimitOut = 0f
        }

        // Audio focus rails
        audioFocusActive = audioFocusOn && e >= audioFocusThr.coerceIn(0.05f, 1f)
        audioFocusOut = if (audioFocusActive) {
            val t = audioFocusThr.coerceIn(0.05f, 1f)
            (((e - t) / (1f - t).coerceAtLeast(0.05f)) * audioFocusLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        focusMoveActive = focusMoveOn && e >= focusMoveThr.coerceIn(0.05f, 1f)
        focusMoveOut = if (focusMoveActive) {
            val t = focusMoveThr.coerceIn(0.05f, 1f)
            (((e - t) / (1f - t).coerceAtLeast(0.05f)) * focusMoveLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        focusSpeedActive = focusSpeedOn && e >= focusSpeedThr.coerceIn(0.05f, 1f)
        focusSpeedOut = if (focusSpeedActive) {
            val t = focusSpeedThr.coerceIn(0.05f, 1f)
            (((e - t) / (1f - t).coerceAtLeast(0.05f)) * focusSpeedLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        focusWaveActive = focusWaveOn && e >= focusWaveThr.coerceIn(0.05f, 1f)
        focusWaveOut = if (focusWaveActive) {
            val t = focusWaveThr.coerceIn(0.05f, 1f)
            (((e - t) / (1f - t).coerceAtLeast(0.05f)) * focusWaveLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Master bipolar ±1000 dB
        bipDbHit = bipDbOn && (dbF <= bipDbNeg.coerceIn(-1000f, 0f) || dbF >= bipDbPos.coerceIn(0f, 1000f))
        bipDbOut = if (bipDbHit) {
            val neg = bipDbNeg.coerceIn(-1000f, 0f)
            val pos = bipDbPos.coerceIn(0f, 1000f)
            when {
                dbF <= neg -> ((neg - dbF) / 1000f).coerceIn(0f, 1f)
                dbF >= pos -> ((dbF - pos) / 1000f).coerceIn(0f, 1f)
                else -> 0f
            }
        } else 0f

        // Enemy-body auto-trigger (thresholded sounds)
        val eBody = max(enemyBodyEnergy, max(enemyBodyMove, max(enemyBodySpeed, enemyBodyWave)))
        enemyBodyActive = enemyBodyOn && eBody >= enemyBodyThr.coerceIn(0.05f, 1f)
        enemyBodyOut = if (enemyBodyActive) {
            val t = enemyBodyThr.coerceIn(0.05f, 1f)
            (((eBody - t) / (1f - t).coerceAtLeast(0.05f)) * enemyBodyLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Body-surface communication
        bodySurfCommActive = bodySurfCommOn && e >= bodySurfCommThr.coerceIn(0.05f, 1f)
        bodySurfCommOut = if (bodySurfCommActive) {
            val t = bodySurfCommThr.coerceIn(0.05f, 1f)
            (((e - t) / (1f - t).coerceAtLeast(0.05f)) * bodySurfCommLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Microphone-driven enemy thresholded sounds
        micDb = db
        val micE = e  // energy already from mic path when AudioProcessor ticks
        micEnemyActive = micDrivenOn && micE >= micEnemyThr.coerceIn(0.05f, 1f)
        micEnemyOut = if (micEnemyActive) {
            val t = micEnemyThr.coerceIn(0.05f, 1f)
            (((micE - t) / (1f - t).coerceAtLeast(0.05f)) * micEnemyLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Protection: my body move / speed / wave vs enemy + mic enemy sounds
        val threat = maxOf(enemyBodyOut, micEnemyOut, bipDbOut * 0.5f)
        protectActive = protectBodyOn && threat >= protectThr.coerceIn(0.05f, 1f)
        val pDepth = if (protectActive) {
            val t = protectThr.coerceIn(0.05f, 1f)
            (((threat - t) / (1f - t).coerceAtLeast(0.05f)) * protectLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        protectMoveFactor = if (protectMoveOn && protectActive) (1f - pDepth * 0.90f).coerceIn(0.08f, 1f) else 1f
        protectSpeedFactor = if (protectSpeedOn && protectActive) (1f - pDepth * 0.90f).coerceIn(0.08f, 1f) else 1f
        protectWaveFactor = if (protectWaveOn && protectActive) (1f - pDepth * 0.90f).coerceIn(0.08f, 1f) else 1f

        // Enemy communication blocker
        enemyCommBlockActive = enemyCommBlockOn && threat >= enemyCommBlockThr.coerceIn(0.05f, 1f)
        enemyCommBlockOut = if (enemyCommBlockActive) {
            val t = enemyCommBlockThr.coerceIn(0.05f, 1f)
            (((threat - t) / (1f - t).coerceAtLeast(0.05f)) * enemyCommBlockLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        enemyCommScale = if (enemyCommBlockActive) (1f - enemyCommBlockOut).coerceIn(0.05f, 1f) else 1f


        // Anti-audio focused (mic-driven counter to audio focus threat)
        val focusThreat = maxOf(audioFocusOut, micEnemyOut, bipDbOut)
        antiAudioActive = antiAudioOn && focusThreat >= antiAudioThr.coerceIn(0.05f, 1f)
        antiAudioOut = if (antiAudioActive) {
            val t = antiAudioThr.coerceIn(0.05f, 1f)
            (((focusThreat - t) / (1f - t).coerceAtLeast(0.05f)) * antiAudioLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (antiAudioActive) antiAudioCount++

        // Anti-body bank + counters (counter enemy body move/speed/wave)
        val bodyThreat = maxOf(enemyBodyOut, enemyBodyMove, enemyBodySpeed, enemyBodyWave, moveTrackOut)
        antiBodyActive = antiBodyOn && bodyThreat >= antiBodyThr.coerceIn(0.05f, 1f)
        antiBodyOut = if (antiBodyActive) {
            val t = antiBodyThr.coerceIn(0.05f, 1f)
            (((bodyThreat - t) / (1f - t).coerceAtLeast(0.05f)) * antiBodyLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        if (antiBodyActive) {
            antiBodyCount++
            if (enemyBodyMove >= antiBodyThr) antiBodyMoveCount++
            if (enemyBodySpeed >= antiBodyThr) antiBodySpeedCount++
            if (enemyBodyWave >= antiBodyThr) antiBodyWaveCount++
        }

        // Atmosphere fire ± bipolar dB toward enemy body (audio-focus + latch)
        val atmoDbF = db.toFloat().coerceIn(-1000f, 1000f)
        atmoFireBipHit = atmoFireOn && (
            atmoDbF <= atmoFireBipNeg.coerceIn(-1000f, 0f) ||
            atmoDbF >= atmoFireBipPos.coerceIn(0f, 1000f) ||
            atmoFireLatch > 0.05f
        )
        val atmoFuel = maxOf(audioFocusOut, atmoTrackOut, atmoFireLatch, if (atmoFireBipHit) 0.55f else 0f)
        atmoFireActive = atmoFireOn && atmoFuel >= atmoFireThr.coerceIn(0.05f, 1f)
        atmoFireOut = if (atmoFireActive) {
            val t = atmoFireThr.coerceIn(0.05f, 1f)
            (((atmoFuel - t) / (1f - t).coerceAtLeast(0.05f)) * atmoFireLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else atmoFireLatch * atmoFireLv.coerceIn(0f, 1f)
        // decay manual latch
        if (atmoFireLatch > 0f) atmoFireLatch = (atmoFireLatch - 0.02f).coerceAtLeast(0f)

        // Eye fire (audio focus + latch)
        val eyeFuel = maxOf(audioFocusOut, eyeFireLatch, enemyBodyOut * 0.5f)
        eyeFireActive = eyeFireOn && eyeFuel >= eyeFireThr.coerceIn(0.05f, 1f)
        eyeFireOut = if (eyeFireActive) {
            val t = eyeFireThr.coerceIn(0.05f, 1f)
            (((eyeFuel - t) / (1f - t).coerceAtLeast(0.05f)) * eyeFireLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else eyeFireLatch * eyeFireLv.coerceIn(0f, 1f)
        if (eyeFireLatch > 0f) eyeFireLatch = (eyeFireLatch - 0.02f).coerceAtLeast(0f)

        // Head fire
        val headFuel = maxOf(audioFocusOut, headFireLatch, enemyBodyOut * 0.5f, atmoFireOut * 0.4f)
        headFireActive = headFireOn && headFuel >= headFireThr.coerceIn(0.05f, 1f)
        headFireOut = if (headFireActive) {
            val t = headFireThr.coerceIn(0.05f, 1f)
            (((headFuel - t) / (1f - t).coerceAtLeast(0.05f)) * headFireLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else headFireLatch * headFireLv.coerceIn(0f, 1f)
        if (headFireLatch > 0f) headFireLatch = (headFireLatch - 0.02f).coerceAtLeast(0f)
        bodyFireOut = bodyFireLatch * 0.85f
        if (bodyFireLatch > 0f) bodyFireLatch = (bodyFireLatch - 0.02f).coerceAtLeast(0f)
        asFireOut = asFireLatch * 0.85f
        if (asFireLatch > 0f) asFireLatch = (asFireLatch - 0.02f).coerceAtLeast(0f)
        gunFireOut = gunFireLatch * 0.90f
        if (gunFireLatch > 0f) gunFireLatch = (gunFireLatch - 0.02f).coerceAtLeast(0f)
        collapseFireOut = collapseFireLatch * 0.95f
        if (collapseFireLatch > 0f) collapseFireLatch = (collapseFireLatch - 0.02f).coerceAtLeast(0f)
        antiFireOut = antiFireLatch * 0.80f
        if (antiFireLatch > 0f) antiFireLatch = (antiFireLatch - 0.02f).coerceAtLeast(0f)


        // Live mic scan energy
        micScanLive = e

        fun fxGate(on: Boolean, thr: Float, lv: Float, src: Float): Pair<Boolean, Float> {
            if (!on) return false to 0f
            val t = thr.coerceIn(0.05f, 1f)
            if (src < t) return false to 0f
            return true to ((((src - t) / (1f - t).coerceAtLeast(0.05f)) * lv.coerceIn(0f, 1f)).coerceIn(0f, 1f))
        }
        val enemySrc = maxOf(enemyBodyOut, micEnemyOut, e)
        val bodyTargetPass = !bodyPartGateOn ||
            bodyPartConfidence >= bodyPartGateThr.coerceIn(0f, 1f)
        fun eventFxSource(useHzDb: Boolean, lowHz: Float, highHz: Float, minDbfs: Float): Float {
            if (!bodyTargetPass) return 0f
            if (!useHzDb) return enemySrc
            return if (passesHzDbGate(true, lowHz, highHz, minDbfs)) liveAudioEnergy else 0f
        }
        // Bullet: energy path OR Hz/dB path (0–50 ultrasound + spectral) so thresholds work live
        val bulletEnergySrc = maxOf(enemySrc, liveAudioEnergy * (if (audioFocusOn) maxOf(audioFocusOut, 0.35f) else 1f))
        val bulletHzSrc = eventFxSource(bulletHzDbGateOn, bulletHzMin, bulletHzMax, bulletDbfsThr)
        val bulletSrc = maxOf(bulletEnergySrc * 0.85f, bulletHzSrc, liveAudioEnergy * 0.7f)
        var (ba, bo) = fxGate(bulletOn, bulletThr, bulletLv, bulletSrc)
        bulletActive = ba; bulletOut = bo
        // Camera-focused enemy bullet boost into detection (for protect path)
        if (cameraFocusOn) {
            cameraFocusOut = if (cameraFocusEnergy >= cameraFocusThr.coerceIn(0.05f, 1f)) {
                (((cameraFocusEnergy - cameraFocusThr) / (1f - cameraFocusThr).coerceAtLeast(0.05f)) * cameraFocusLv).coerceIn(0f, 1f)
            } else (cameraFocusEnergy * 0.5f * cameraFocusLv).coerceIn(0f, 1f)
            if (cameraFocusOut > 0.05f && bulletOn) {
                bulletOut = maxOf(bulletOut, bulletSrc * cameraFocusOut * bulletLv.coerceIn(0f, 1.5f))
                if (bulletOut > 0.02f) bulletActive = true
            }
        }
        // Enemy bullet prank protect — damp enemy bullet when audio or camera focused
        if (enemyBulletPrankProtect) {
            val threat = maxOf(bulletOut, burstOut * 0.8f, micEnemyOut, enemyBodyOut)
            enemyBulletPrankOut = if (threat >= enemyBulletPrankThr.coerceIn(0.05f, 1f)) {
                (((threat - enemyBulletPrankThr) / (1f - enemyBulletPrankThr).coerceAtLeast(0.05f)) * enemyBulletPrankLv).coerceIn(0f, 1f)
            } else 0f
            if (enemyBulletPrankOut > 0.02f) {
                val damp = (1f - enemyBulletPrankOut * 0.95f).coerceIn(0.03f, 1f)
                // protect OUR body from enemy bullet/prank — scale enemy outs
                enemyBodyOut *= damp
                micEnemyOut *= damp
            }
        }
        var (ka, ko) = fxGate(
            knifeOn, knifeThr, knifeLv,
            eventFxSource(knifeHzDbGateOn, knifeHzMin, knifeHzMax, knifeDbfsThr)
        ); knifeActive = ka; knifeOut = ko
        val whipSrc = (liveAudioEnergy * (if (whipModelDrive) whipModelScale.coerceIn(0.05f, 1.5f) else 1f)).coerceIn(0f, 1f)
        var (wha, who) = fxGate(whipOn, whipThr, whipLv, whipSrc)
        whipActive = wha; whipOut = who
        var (ra, ro) = fxGate(
            rippleOn, rippleThr, rippleLv,
            eventFxSource(rippleHzDbGateOn, rippleHzMin, rippleHzMax, rippleDbfsThr)
        ); rippleActive = ra; rippleOut = ro
        val audioFresh = hasFreshAudioAnalysis()
        val sharpSrc = if (audioFresh) {
            (liveAudioEnergy * (liveCentroidHz / 10000f).coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        val burstSrc = if (audioFresh) (liveBurstRiseDb / 30f).coerceIn(0f, 1f) else 0f
        var (sha, sho) = fxGate(sharpOn, sharpThr, sharpLv, sharpSrc)
        sharpActive = sha; sharpOut = sho
        var (bua, buo) = fxGate(burstOn, burstThr, burstLv, burstSrc)
        burstActive = bua; burstOut = buo
        var (wa, wo) = fxGate(whistleOn, whistleThr, whistleLv, enemySrc); whistleActive = wa; whistleOut = wo
        var (aa, ao) = fxGate(ambitiousOn, ambitiousThr, ambitiousLv, enemySrc); ambitiousActive = aa; ambitiousOut = ao

        // Collide / collapse from live mic tracking
        var (ca, co) = fxGate(collideOn, collideThr, collideLv, micScanLive); collideActive = ca; collideOut = co
        var (cla, clo) = fxGate(collapseOn, collapseThr, collapseLv, micScanLive); collapseActive = cla; collapseOut = clo

        // Protection against enemy FX bank
        val fxThreat = maxOf(bulletOut, knifeOut, whipOut, rippleOut, sharpOut, burstOut, whistleOut, ambitiousOut)
        enemyFxProtectOut = if (fxThreat > 0.05f) (fxThreat * enemyFxProtectLv.coerceIn(0f, 1f)).coerceIn(0f, 1f) else 0f
        val protScale = (1f - enemyFxProtectOut * 0.95f).coerceIn(0.05f, 1f)
        // Master enemy shield (all effects)
        enemyMasterShieldOut = if (enemyMasterShieldOn && fxThreat > 0.04f) {
            (fxThreat * enemyMasterShieldLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        val masterScale = (1f - enemyMasterShieldOut * 0.92f).coerceIn(0.05f, 1f)
        // Argument-reality shield couples into same damp path
        arRealityShieldOut = if (arRealityShieldOn) {
            (maxOf(fxThreat, mixEnergy * 0.5f) * arRealityShieldLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        val arScale = (1f - arRealityShieldOut * 0.88f).coerceIn(0.05f, 1f)
        val fullProtectScale = (protScale * masterScale * arScale).coerceIn(0.05f, 1f)
        val ps = fullProtectScale
        if (bulletProtect) bulletOut *= ps
        if (knifeProtect) knifeOut *= ps
        if (whipProtect) whipOut *= ps
        if (rippleProtect) rippleOut *= ps
        sharpOut = if (sharpProtect) scaleSharpBurst(sharpOut * ps) else scaleSharpBurst(sharpOut)
        burstOut = if (burstProtect) scaleSharpBurst(burstOut * ps) else scaleSharpBurst(burstOut)
        // Mobile burst + knife protection (enemy cannot land on our body / head / mobile)
        if (mobileBurstProtect) {
            val bl = mobileBurstProtectLv.coerceIn(0.1f, 1f)
            mobileBurstBlockOut = (burstOut * bl).coerceIn(0f, 1f)
            burstOut = scaleSharpBurst(burstOut * (1f - bl * 0.97f).coerceIn(0.02f, 1f))
        }
        if (mobileKnifeProtect) {
            val kl = mobileKnifeProtectLv.coerceIn(0.1f, 1f)
            mobileKnifeBlockOut = (knifeOut * kl).coerceIn(0f, 1f)
            knifeOut *= (1f - kl * 0.97f).coerceIn(0.02f, 1f)
        }
        if (blockEnemyBurstOnBody) {
            val b = maxOf(mobileBurstProtectLv, mobileKnifeProtectLv).coerceIn(0.1f, 1f)
            enemyBodyOut *= (1f - b * 0.90f).coerceIn(0.05f, 1f)
            protectMoveFactor = minOf(protectMoveFactor, (1f - b * 0.45f).coerceIn(0.1f, 1f))
            protectSpeedFactor = minOf(protectSpeedFactor, (1f - b * 0.45f).coerceIn(0.1f, 1f))
            protectWaveFactor = minOf(protectWaveFactor, (1f - b * 0.45f).coerceIn(0.1f, 1f))
        }
        if (blockEnemyBurstOnHead) {
            val b = maxOf(mobileBurstProtectLv, mobileKnifeProtectLv).coerceIn(0.1f, 1f)
            headFireOut *= (1f - b * 0.88f).coerceIn(0.05f, 1f)
            eyeFireOut *= (1f - b * 0.85f).coerceIn(0.05f, 1f)
        }
        if (blockEnemyBurstOnMobile) {
            val b = maxOf(mobileBurstProtectLv, mobileKnifeProtectLv).coerceIn(0.1f, 1f)
            micEnemyOut *= (1f - b * 0.90f).coerceIn(0.05f, 1f)
        }
        if (whistleProtect) whistleOut *= ps
        if (ambitiousProtect) ambitiousOut *= ps
        // Always apply master+AR residual damp on enemy outs when shields ON
        if (enemyMasterShieldOn || arRealityShieldOn) {
            val hard = (masterScale * arScale).coerceIn(0.05f, 1f)
            bulletOut *= hard; knifeOut *= hard; whipOut *= hard
            rippleOut *= hard; sharpOut = scaleSharpBurst(sharpOut * hard)
            burstOut = scaleSharpBurst(burstOut * hard)
            whistleOut *= hard; ambitiousOut *= hard
            collideOut *= hard; collapseOut *= hard
            micEnemyOut *= hard; enemyBodyOut *= hard
        }


        // Atmosphere centroid sounds in nature (live rolling centroid)
        atmoHist[atmoHistIdx] = e
        atmoHistIdx = (atmoHistIdx + 1) % atmoHist.size
        if (atmoHistN < atmoHist.size) atmoHistN++
        var atmoSum = 0f
        for (i in 0 until atmoHistN) atmoSum += atmoHist[i]
        atmoCentroidNorm = if (atmoHistN > 0) (atmoSum / atmoHistN).coerceIn(0f, 1f) else 0f
        atmoCentroidActive = atmoCentroidOn && atmoCentroidNorm >= atmoCentroidThr.coerceIn(0.05f, 1f)
        atmoCentroidOut = if (atmoCentroidActive) {
            val t = atmoCentroidThr.coerceIn(0.05f, 1f)
            (((atmoCentroidNorm - t) / (1f - t).coerceAtLeast(0.05f)) * atmoCentroidLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Nature motion rail (any motion/sound energy)
        natureMotionOut = if (natureMotionOn) maxOf(e, moveTrackOut, focusMoveOut, focusWaveOut) * 0.85f else 0f

        // ANC level for collide system in nature
        val ancSrc = maxOf(atmoCentroidOut, collideOut, natureMotionOut, micScanLive * 0.7f)
        ancActive = ancOn && ancSrc >= ancThr.coerceIn(0.05f, 1f)
        ancOut = if (ancActive) {
            val t = ancThr.coerceIn(0.05f, 1f)
            (((ancSrc - t) / (1f - t).coerceAtLeast(0.05f)) * ancLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // ANC live centroid protection → all enemy sounds effects
        ancProtectOut = if (ancProtectOn) {
            maxOf(ancOut, atmoCentroidOut, collideOut) * ancProtectLv.coerceIn(0f, 1f)
        } else 0f
        val ancScale = (1f - ancProtectOut * 0.90f).coerceIn(0.08f, 1f)
        // Apply to every enemy FX rail
        bulletOut *= ancScale
        knifeOut *= ancScale
        rippleOut *= ancScale
        sharpOut = scaleSharpBurst(sharpOut * ancScale)
        burstOut = scaleSharpBurst(burstOut * ancScale)
        whistleOut *= ancScale
        ambitiousOut *= ancScale
        enemyBodyOut *= ancScale
        micEnemyOut *= ancScale
        // Collide gets nature boost from ANC when active (system "in nature")
        if (ancActive && collideActive) {
            collideOut = (collideOut + ancOut * 0.35f).coerceIn(0f, 1f)
        }

        deviceEnemyOut = maxOf(enemyBodyOut, micEnemyOut, bodySurfCommOut * 0.6f)
        mixEnergy = listOf(
            ambientTrackOut * 0.35f,
            audioFocusOut * 0.45f,
            focusMoveOut * 0.25f,
            focusSpeedOut * 0.25f,
            focusWaveOut * 0.25f,
            enemyBodyOut * 0.55f * enemyCommScale,
            micEnemyOut * 0.60f * enemyCommScale,
            bodySurfCommOut * 0.40f,
            bipDbOut * 0.30f,
            atmoTrackOut * 0.30f,
            moveTrackOut * 0.25f,
            antiAudioOut * 0.50f,
            antiBodyOut * 0.50f,
            atmoFireOut * 0.70f * enemyCommScale,
            eyeFireOut * 0.65f * enemyCommScale,
            headFireOut * 0.65f * enemyCommScale,
            bodyFireOut * 0.70f * enemyCommScale,
            asFireOut * 0.75f * enemyCommScale,
            gunFireOut * 0.80f * enemyCommScale,
            collapseFireOut * 0.90f * enemyCommScale,
            lhcOut * 0.95f * enemyCommScale,
            ambSysCollapseOut * 0.88f * enemyCommScale,
            enemyBankCollapseOut * 0.85f * enemyCommScale,
            soundsBankCollideOut * 0.92f * enemyCommScale,
            antiFireOut * 0.55f,
            sharpOut * 0.60f,
            burstOut * 0.60f
        ).maxOrNull()?.coerceIn(0f, 1f) ?: 0f
    }

    /** Floating / manual fire triggers (1 = full latch pulse). */
    fun fireAtmo() { if (atmoFireOn) atmoFireLatch = 1f }
    fun fireEye() { if (eyeFireOn) eyeFireLatch = 1f }
    fun fireHead() { if (headFireOn) headFireLatch = 1f }
    fun fireBody() { if (bodyFireOn) bodyFireLatch = 1f }
    fun fireAs() { if (asFireOn) asFireLatch = 1f }
    fun fireGun() { if (gunFireOn) gunFireLatch = 1f }
    fun fireCollapse() { if (collapseFireOn) collapseFireLatch = 1f }
    fun feedMicModel(model: Float) {
        whipModelScale = model.coerceIn(0.05f, 1.5f)
    }

    fun fireLhc() { if (lhcColliderOn) lhcFireLatch = 1f }

    /**
     * Large Hadron Collider path: OUR live mic vs enemy mic energy collide.
     * Axis collapse from motion hub X/Y/Z. Echo-cancel couples into beam when on.
     * No separate ANC/ENC required — pure collapse/collide.
     */
    fun updateLhc(ourRms: Float, enemyTx: Float, axisX: Float, axisY: Float, axisZ: Float, echoCancelActive: Boolean) {
        if (!lhcColliderOn && lhcFireLatch <= 0f) {
            lhcOut = 0f; lhcCollide = false; lhcBeam = 0f
            return
        }
        lhcOurDb = (ourRms.coerceIn(0f, 1f) * 80f - 40f).coerceIn(-120f, 120f)
        lhcEnemyDb = (enemyTx.coerceIn(0f, 1f) * 80f - 40f).coerceIn(-120f, 120f)
        lhcAxisX = axisX.coerceIn(0f, 1f)
        lhcAxisY = axisY.coerceIn(0f, 1f)
        lhcAxisZ = axisZ.coerceIn(0f, 1f)
        val axisMag = if (lhcAxisCollapseOn) {
            ((lhcAxisX + lhcAxisY + lhcAxisZ) / 3f).coerceIn(0f, 1f)
        } else 0f
        val echoBoost = if (lhcEchoCancelOn && echoCancelActive) 1.25f else 1f
        val collideRaw = ((kotlin.math.abs(lhcOurDb) + kotlin.math.abs(lhcEnemyDb)) * 0.5f) *
            lhcEnergy.coerceIn(0.05f, 1f) * echoBoost
        val axisCollapse = axisMag * lhcEnergy.coerceIn(0.05f, 1f) * 40f
        lhcBeam = (collideRaw + axisCollapse * 0.35f + lhcFireLatch * 50f).coerceIn(0f, 120f)
        lhcCollide = lhcBeam >= lhcDbThr.coerceIn(1f, 120f) * 0.35f ||
            (kotlin.math.abs(lhcOurDb - lhcEnemyDb) < 12f && lhcEnergy > 0.3f)
        val t = lhcThr.coerceIn(0.05f, 1f)
        lhcOut = if (lhcCollide) {
            (((lhcBeam / 120f) - t).coerceAtLeast(0f) / (1f - t).coerceAtLeast(0.05f) *
                lhcEnergy.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else lhcFireLatch * lhcEnergy.coerceIn(0f, 1f)
        if (lhcFireLatch > 0f) lhcFireLatch = (lhcFireLatch - 0.02f).coerceAtLeast(0f)
        updateAmbSystemsCollapse()
        // couple into existing collapse + mic enemy when collide
        if (lhcCollide) {
            collapseFireLatch = maxOf(collapseFireLatch, lhcOut)
            if (micEnemyActive) micEnemyOut = maxOf(micEnemyOut, lhcOut * 0.85f)
        }
    }

    fun fireAmbSysCollapse() { if (ambSysCollapseOn) ambSysCollapseLatch = 1f }
    fun fireEnemyBankCollapse() { if (enemyBankCollapseOn) enemyBankCollapseLatch = 1f }

    /** All ambient systems collapse + OUR bank collide vs enemy bank · RAW */
    fun updateAmbSystemsCollapse() {
        if (!ambSysCollapseOn && !enemyBankCollapseOn && !soundsBankCollideOn &&
            ambSysCollapseLatch <= 0f && enemyBankCollapseLatch <= 0f) {
            ambSysCollapseOut = 0f; enemyBankCollapseOut = 0f; soundsBankCollideOut = 0f
            return
        }
        // Aggregate all ambient outs as OUR ambient system energy
        val ourAmb = maxOf(
            ambientTrackOut, atmoTrackOut, ambLimitOut, audioFocusOut,
            atmoFireOut, bodyFireOut, asFireOut, lhcOut, mixEnergy * 0.5f
        ).coerceIn(0f, 1f)
        val enemyAmb = maxOf(micEnemyOut, enemyBodyOut, bipDbOut * 0.5f).coerceIn(0f, 1f)
        // Collapse: ambient systems fold into one beam when both sides present
        if (ambSysCollapseOn) {
            val c = (ourAmb + enemyAmb) * 0.5f * lhcEnergy.coerceIn(0.05f, 1f)
            ambSysCollapseOut = maxOf(c, ambSysCollapseLatch * lhcEnergy.coerceIn(0f, 1f))
            if (ambSysCollapseOut > lhcThr.coerceIn(0.05f, 1f)) {
                // force ambient paths into collapse coupling
                ambientTrackOut = maxOf(ambientTrackOut, ambSysCollapseOut * 0.9f)
                atmoTrackOut = maxOf(atmoTrackOut, ambSysCollapseOut * 0.9f)
                ambLimitOut = maxOf(ambLimitOut, ambSysCollapseOut * 0.85f)
                atmoTrackActive = true; ambientTrackActive = true; ambLimitActive = true
            }
        } else ambSysCollapseOut = 0f
        // Enemy sounds bank collapse
        if (enemyBankCollapseOn) {
            enemyBankCollapseOut = maxOf(enemyAmb * lhcEnergy.coerceIn(0.05f, 1f), enemyBankCollapseLatch)
            if (enemyBankCollapseOut > 0.05f) {
                micEnemyOut = maxOf(micEnemyOut, enemyBankCollapseOut)
                enemyBodyOut = maxOf(enemyBodyOut, enemyBankCollapseOut * 0.8f)
                micEnemyActive = true
            }
        } else enemyBankCollapseOut = 0f
        // OUR bank vs enemy bank collide
        if (soundsBankCollideOn) {
            val collide = minOf(ourAmb, enemyAmb) * 2f * lhcEnergy.coerceIn(0.05f, 1f)
            val hit = ourAmb > lhcThr * 0.5f && enemyAmb > lhcThr * 0.3f
            soundsBankCollideOut = if (hit) collide.coerceIn(0f, 1f) else (ourAmb * enemyAmb * lhcEnergy)
            if (soundsBankCollideOut > 0.08f) {
                collapseFireOut = maxOf(collapseFireOut, soundsBankCollideOut)
                lhcOut = maxOf(lhcOut, soundsBankCollideOut)
                mixEnergy = maxOf(mixEnergy, soundsBankCollideOut)
            }
        } else soundsBankCollideOut = 0f
        if (ambSysCollapseLatch > 0f) ambSysCollapseLatch = (ambSysCollapseLatch - 0.02f).coerceAtLeast(0f)
        if (enemyBankCollapseLatch > 0f) enemyBankCollapseLatch = (enemyBankCollapseLatch - 0.02f).coerceAtLeast(0f)
    }

    fun ambCollapseStatus(): String {
        return "AMB-SYS ${"%.0f".format(ambSysCollapseOut*100)}% EN-BANK ${"%.0f".format(enemyBankCollapseOut*100)}% " +
            "BANK-HIT ${"%.0f".format(soundsBankCollideOut*100)}% · RAW"
    }

    fun lhcStatus(): String {
        if (!lhcColliderOn) return "LHC off"
        return "LHC beam ${"%.0f".format(lhcBeam)} OUR ${"%.1f".format(lhcOurDb)}dB EN ${"%.1f".format(lhcEnemyDb)}dB " +
            "axis ${"%.0f".format(lhcAxisX*100)}/${"%.0f".format(lhcAxisY*100)}/${"%.0f".format(lhcAxisZ*100)} " +
            "echo=${if (lhcEchoCancelOn) "ON" else "off"} HIT=${if (lhcCollide) "YES" else "no"} · RAW"
    }
    fun fireAnti() { if (antiFireOn) antiFireLatch = 1f }
    // ── SD-card sounds loaded into this bank (see SdSoundBank) ──
    @Volatile var sdLevel = 0f
        private set
    @Volatile var sdPlaying = false
        private set
    @Volatile var sdFocus = false
        private set
    @Volatile var sdLinkOn = true

    /** The loaded SD sound feeds the bank: raises the audio-focus output and the model-mix energy. */
    fun injectSd(level: Float, playing: Boolean, focus: Boolean) {
        sdLevel = level.coerceIn(0f, 1f)
        sdPlaying = playing
        sdFocus = focus
        if (!enabled || !sdLinkOn || !playing) return
        val l = sdLevel * (if (rawComplete) 1f else audioFocusLv.coerceIn(0f, 1f))
        audioFocusOut = max(audioFocusOut, l)
        mixEnergy = max(mixEnergy, l)
    }

    fun fireAll() { fireAtmo(); fireEye(); fireHead(); fireBody(); fireAs(); fireGun(); fireCollapse(); fireAnti(); fireLhc(); fireAmbSysCollapse(); fireEnemyBankCollapse() }


    fun outScale(): Float {
        if (rawComplete) return 1f
        var s = blockFactor
        if (atmoSpikeActive) s *= (1f - atmoSpikeLv * 0.35f)
        if (atmoTrackActive) s *= (1f - atmoTrackOut * 0.28f)
        if (moveTrackActive) s *= (1f - moveTrackOut * 0.22f)
        if (dbLimitActive) s *= (1f - dbLimitOut * 0.40f)
        if (ambLimitActive) s *= (1f - ambLimitOut * 0.30f)
        if (silenceActive) s *= 0.25f
        if (thrTrackActive && detectActive) s *= 0.85f
        if (enemyBodyActive) s *= (1f - enemyBodyOut * 0.15f)
        if (micEnemyActive) s *= (1f - micEnemyOut * 0.12f)
        if (enemyCommBlockActive) s *= (0.55f + 0.45f * enemyCommScale)
        return s.coerceIn(0.10f, 1f)
    }

    fun speedMul(): Float =
        if (rawComplete || atmoSpeedActive || focusSpeedActive)
            (0.7f + max(atmoSpeedLv, focusSpeedLv) * 0.6f) else 1f

    fun moveMul(): Float =
        if (rawComplete || atmoMoveActive || focusMoveActive)
            (0.7f + max(atmoMoveLv, focusMoveLv) * 0.6f) else 1f

    fun waveMul(): Float =
        if (rawComplete || atmoWaveActive || focusWaveActive)
            (0.7f + max(atmoWaveLv, focusWaveLv) * 0.6f) else 1f

    fun statusLine(): String {
        if (!enabled) return "SOUND-BANK off"
        val tags = buildList {
            if (rawComplete) add("RAW")
            if (silenceActive) add("SILENCE")
            if (trackActive) add("TRACK")
            if (thrTrackActive) add("THR-TRACK")
            if (ambientTrackActive) add("AMB")
            if (audioFocusActive) add("FOCUS")
            if (focusMoveActive) add("F-MOV")
            if (focusSpeedActive) add("F-SPD")
            if (focusWaveActive) add("F-WAV")
            if (enemyBodyActive) add("ENEMY-BODY")
            if (micEnemyActive) add("MIC-ENEMY")
            if (lhcCollide) add("LHC-HIT")
            if (ambSysCollapseOut > 0.08f) add("AMB-COL")
            if (enemyBankCollapseOut > 0.08f) add("EN-BANK-COL")
            if (soundsBankCollideOut > 0.08f) add("BANK-HIT")
            if (lhcColliderOn && lhcOut > 0.05f) add("LHC")
            if (protectActive) add("BODY-PROTECT")
            if (enemyCommBlockActive) add("COMM-BLOCK")
            if (antiAudioActive) add("ANTI-AUDIO")
            if (antiBodyActive) add("ANTI-BODY")
            if (atmoFireActive) add("ATMO-FIRE")
            if (eyeFireActive) add("EYE-FIRE")
            if (headFireActive) add("HEAD-FIRE")
            if (bulletActive) add("BULLET")
            if (knifeActive) add("KNIFE")
            if (whipActive) add("WHIP")
            if (enemyMasterShieldOn && enemyMasterShieldOut > 0.05f) add("MASTER-SHIELD")
            if (arRealityShieldOn && arRealityShieldOut > 0.05f) add("AR-SHIELD")
            if (mobileBurstProtect && mobileBurstBlockOut > 0.02f) add("MOBILE-BURST-PROT")
            if (mobileKnifeProtect && mobileKnifeBlockOut > 0.02f) add("MOBILE-KNIFE-PROT")
            if (rippleActive) add("RIPPLE")
            if (sharpActive) add("SHARP-SOUND")
            if (burstActive) add("BURST-SOUND")
            if (whistleActive) add("WHISTLE")
            if (ambitiousActive) add("AMBITIOUS")
            if (collideActive) add("COLLIDE")
            if (collapseActive) add("COLLAPSE")
            if (atmoCentroidActive) add("ATMO-CEN")
            if (ancActive) add("ANC")
            if (ancProtectOut > 0.05f) add("ANC-PROT")
            if (bodySurfCommActive) add("BODY-SURF")
            if (bipDbHit) add("BIP±1000")
            if (atmoBipHit) add("ATMO-BIP")
            if (atmoSpikeActive) add("ATMO-SPIKE")
            if (atmoTrackActive) add("ATMO-TRACK")
            if (moveTrackActive) add("MOVE-TRACK")
            if (dbLimitActive) add("DB-LIM")
            if (blockActive) add("BLOCK")
            if (sdPlaying) add("SD-SOUND")
            if (isEmpty()) add("idle")
        }.joinToString("+")
        return "SOUND-BANK · $tags · mix=${(mixEnergy * 100).toInt()}% " +
            "focus=${(audioFocusOut * 100).toInt()}% enemy=${(enemyBodyOut * 100).toInt()}% mic=${(micEnemyOut * 100).toInt()}% prot=${(protectMoveFactor * 100).toInt()}% " +
            "bip=${(bipDbOut * 100).toInt()}% fire=${(atmoFireOut * 100).toInt()}% eye=${(eyeFireOut * 100).toInt()}% head=${(headFireOut * 100).toInt()}% antiA=#${antiAudioCount} antiB=#${antiBodyCount}"
    }
}
