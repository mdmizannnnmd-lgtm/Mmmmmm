package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

/** Main-page ARCore mesh world + point cloud (no other page required). */
object CameraArMeshWorldPanels {
    fun build(ctx: Context, root: LinearLayout, b: CameraArMeshWorldBoard, ar: ArCoreMeasureBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF80DEEA.toInt()
        p.title("ARCORE MESH WORLD · POINT CLOUD · MAIN APP", c)
        p.note("Own codes on main: density · conf · planes H/V · protect feed. Session via existing ARCore board.")
        p.switch("Mesh+points master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Mesh world ON", b.meshWorldOn) { b.meshWorldOn = it; ar.meshWorldOn = it }
        p.switch("Point cloud ON", b.pointCloudOn) { b.pointCloudOn = it; ar.pointCloudOn = it }
        p.switch("Planes H/V ON", b.planesOn) { b.planesOn = it }
        p.switch("ARCore session enabled", ar.enabled) { ar.enabled = it }
        p.switch("AR tracking ON", ar.trackingOn) { ar.trackingOn = it }
        p.switch("Mesh protect feed", b.protectOn) { b.protectOn = it }
        p.seek("Point density thr", 0.02f, 1f, b.densityThr) { b.densityThr = it }
        p.seek("Point confidence thr", 0.05f, 1f, b.confThr) { b.confThr = it }
        p.seek("Protect level", 0f, 1.5f, b.protectLv) { b.protectLv = it }
        val st = p.status("AR MESH —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                b.tick()
                st.text = b.status
                h.postDelayed(this, 250)
            }
        })
    }
}
