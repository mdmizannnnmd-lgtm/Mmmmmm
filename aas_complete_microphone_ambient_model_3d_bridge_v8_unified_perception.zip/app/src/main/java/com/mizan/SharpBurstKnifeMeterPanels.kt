package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object SharpBurstKnifeMeterPanels {
    fun build(ctx: Context, root: LinearLayout, b: SharpBurstKnifeMeterBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFFAB91.toInt()
        p.title("BURST·KNIFE METERS · Hz 0→∞ · SHARP/PITCH/SPIKE dB · BODY SFX PROT · ANTI-B/K ANC", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("DETECTED Hz (0 → unlimited)", c)
        p.seek("Detected Hz thr (0=any)", 0f, 50000f, b.detectedHzThr) { b.detectedHzThr = it }
        p.seek("Detected Hz max ceiling", 1000f, 1_000_000f, b.detectedHzThrMax) { b.detectedHzThrMax = it }

        p.title("dB THRESHOLDS", c)
        p.seek("Pitch dB thr", -120f, 0f, b.pitchDbThr) { b.pitchDbThr = it }
        p.seek("Spikes dB thr", -120f, 0f, b.spikesDbThr) { b.spikesDbThr = it }
        p.seek("Sharp dB thr", -120f, 0f, b.sharpDbThr) { b.sharpDbThr = it }

        p.title("BODY REGION SFX PROTECTION", c)
        p.switch("Body region protect ON", b.bodyRegionProtectOn) { b.bodyRegionProtectOn = it }
        p.seek("Body region thr", 0.05f, 0.98f, b.bodyRegionThr) { b.bodyRegionThr = it }
        p.seek("Body region level", 0f, 1.5f, b.bodyRegionLv) { b.bodyRegionLv = it }

        p.title("ANTI BULLET · ANTI KNIFE (ANC-style)", c)
        p.switch("Anti bullet ANC ON", b.antiBulletOn) { b.antiBulletOn = it }
        p.seek("Anti bullet thr / lv", 0.05f, 0.98f, b.antiBulletThr) { b.antiBulletThr = it }
        p.seek("Anti bullet level", 0f, 1.5f, b.antiBulletLv) { b.antiBulletLv = it }
        p.switch("Anti knife ANC ON", b.antiKnifeOn) { b.antiKnifeOn = it }
        p.seek("Anti knife thr", 0.05f, 0.98f, b.antiKnifeThr) { b.antiKnifeThr = it }
        p.seek("Anti knife level", 0f, 1.5f, b.antiKnifeLv) { b.antiKnifeLv = it }

        val st = p.status("METERS —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 200) }
        })
    }
}
