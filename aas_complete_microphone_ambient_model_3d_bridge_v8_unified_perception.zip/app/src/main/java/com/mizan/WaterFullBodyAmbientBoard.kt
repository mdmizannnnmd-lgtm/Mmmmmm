package com.mizan

/**
 * Full-body water ambient (55–60% body water symbolic).
 * Intracellular / extracellular / blood plasma · daily scale track · threshold.
 * RAW COMPLETE.
 */
class WaterFullBodyAmbientBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.25f
    @Volatile var levelAmt = 0.88f
    @Volatile var intracellular = 0f
    @Volatile var extracellular = 0f
    @Volatile var plasma = 0f
    @Volatile var lymphWater = 0f
    @Volatile var csfWater = 0f
    @Volatile var waterFull = 0f
    @Volatile var dailyLitersTrack = 2.5f
    @Volatile var status = "WATER idle"

    private fun lane(e: Float): Float {
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * levelAmt).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * levelAmt).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, skin: Float, chem: Float) {
        if (!enabled) { status = "WATER OFF"; return }
        val e = maxOf(mic * 0.5f, skin, chem).coerceIn(0f, 1.5f)
        intracellular = lane(e * 0.95f)
        extracellular = lane(e * 0.90f)
        plasma = lane(e * 0.88f)
        lymphWater = lane(e * 0.84f)
        csfWater = lane(e * 0.86f)
        waterFull = maxOf(intracellular, extracellular, plasma, lymphWater, csfWater)
        if (rawComplete) waterFull = maxOf(waterFull, 0.3f + e * 0.35f)
        status = "WATER full=${(waterFull*100).toInt()}% · IC/EC/plasma=${(intracellular*100).toInt()}/${(extracellular*100).toInt()}/${(plasma*100).toInt()} · track=${"%.1f".format(dailyLitersTrack)}L" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView?) {
        if (!enabled || waterFull < 0.02f) return
        val vv = v ?: return
        try {
            vv.skeletonWaterAstro.waterOut = maxOf(vv.skeletonWaterAstro.waterOut, waterFull)
            vv.completeAtomProtect.atomInsideOut = maxOf(vv.completeAtomProtect.atomInsideOut, waterFull * 0.4f)
            vv.anatomy3d.atmosphere = maxOf(vv.anatomy3d.atmosphere, waterFull * 0.3f)
        } catch (_: Throwable) {}
    }
}
