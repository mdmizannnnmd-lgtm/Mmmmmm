package com.mizan

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.Switch

/** Control panels for the 3D brain and the complete anatomy, built from code. */
object BrainPanels {

    /** Returns the RAW COMPLETE switches so the master raw switch can drive them. */
    class Handles(val brainRaw: Switch?, val anatomyRaw: Switch?)

    fun build(ctx: Context, brainRoot: LinearLayout?, anatomyRoot: LinearLayout?, view: VisualShieldView): Handles {
        val brainRaw = brainRoot?.let { buildBrain(ctx, it, view) }
        val anatomyRaw = anatomyRoot?.let { buildAnatomy(ctx, it, view) }
        return Handles(brainRaw, anatomyRaw)
    }

    // ───────────────────────────────────────────────────────────────────── BRAIN
    private fun buildBrain(ctx: Context, root: LinearLayout, view: VisualShieldView): Switch {
        val b = view.brain3d
        val p = PanelBuilder(ctx, root)
        p.title("3D BRAIN · LEFT / RIGHT HEMISPHERE · ALL SYSTEMS", Color.rgb(0x80, 0xDE, 0xEA))
        p.note("Replaces the old brain ball: 2 hemispheres × frontal / parietal / temporal / occipital + cerebellum + brainstem + deep structures.")
        p.switch("3D brain ON", b.enabled) { b.enabled = it }
        val raw = p.switch("RAW COMPLETE brain (no threshold · gain · rails · smoothing · visual tuning)", false) {
            b.setRawAll(it)
        }

        p.title("Drawing", Color.rgb(0xB0, 0xBE, 0xC5))
        p.switch("Sulci / gyri folds", b.sulciOn) { b.sulciOn = it }
        p.switch("Cut-away (deep brain: callosum · thalamus · hippocampus · basal ganglia · amygdala · insula · cingulate · hypothalamus · ventricles · pituitary · pineal)", b.innerOn) { b.innerOn = it }

        p.switch("Brain glands ON (pituitary · pineal · hypothalamus · thalamus · ventricles)", b.glandsOn) { b.glandsOn = it }
        p.switch("Optical path lines (optic nerve / chiasm → eyes)", b.opticalOn) { b.opticalOn = it }
        p.switch("3D face contour lines", b.faceLinesOn) { b.faceLinesOn = it }
        p.switch("Face RAW COMPLETE", b.rawFace) { b.rawFace = it }
        p.switch("3D atmosphere halo + wave rings", b.haloOn) { b.haloOn = it }
        p.seek("Size", 0.15f, 0.90f, b.size) { b.size = it }
        p.switch("Auto rotate (swing)", b.yawAuto) { b.yawAuto = it }
        p.seek("Rotate speed", 0f, 1f, b.yawSpeed) { b.yawSpeed = it }
        p.seek("Manual yaw", -1.6f, 1.6f, b.yaw) { b.yaw = it }
        p.seek("Tilt", -0.6f, 0.6f, b.tilt) { b.tilt = it }

        p.title("Model mixing (what feeds each side)", Color.rgb(0xB0, 0xBE, 0xC5))
        p.note("LEFT ← ambient + mid/high audio + body model · RIGHT ← camera + motion + bass audio + body model")
        p.seek("Ambient weight", 0f, 1f, b.wAmbient) { b.wAmbient = it }
        p.seek("Audio weight", 0f, 1f, b.wAudio) { b.wAudio = it }
        p.seek("Camera weight", 0f, 1f, b.wCamera) { b.wCamera = it }
        p.seek("Motion weight", 0f, 1f, b.wMotion) { b.wMotion = it }
        p.seek("Body model weight (pose · camera body regions · body mix)", 0f, 1f, b.wModel) { b.wModel = it }
        p.seek("Left ↔ right balance (−1 left · +1 right)", -1f, 1f, b.lrBalance) { b.lrBalance = it }
        p.seek("Left–right coupling (corpus callosum)", 0f, 1f, b.lrCross) { b.lrCross = it }
        p.button("Eyes visual link: off (tap: eyes ← brain / brain ← eyes)") { btn ->
            b.eyeLink = (b.eyeLink + 1) % 3
            btn.text = "Eyes visual link: " + arrayOf("off", "eyes follow brain", "brain follows eyes")[b.eyeLink] + " (tap to change)"
        }

        p.title("Lobes (how strongly each follows its hemisphere)", Color.rgb(0xB0, 0xBE, 0xC5))
        p.seek("Frontal ← ambient", 0f, 1.5f, b.lobeFrontal) { b.lobeFrontal = it }
        p.seek("Parietal ← motion", 0f, 1.5f, b.lobeParietal) { b.lobeParietal = it }
        p.seek("Temporal ← audio", 0f, 1.5f, b.lobeTemporal) { b.lobeTemporal = it }
        p.seek("Occipital ← camera / eyes", 0f, 1.5f, b.lobeOccipital) { b.lobeOccipital = it }
        p.seek("Cerebellum ← motion", 0f, 1.5f, b.lobeCerebellum) { b.lobeCerebellum = it }
        p.seek("Brainstem ← raw", 0f, 1.5f, b.lobeBrainstem) { b.lobeBrainstem = it }

        hemiControls(p, "LEFT HEMISPHERE", b.left, Color.rgb(0x4F, 0xC3, 0xF7))
        hemiControls(p, "RIGHT HEMISPHERE", b.right, Color.rgb(0xFF, 0xB7, 0x4D))
        p.button("Copy LEFT settings → RIGHT") {
            copyHemi(b.left, b.right)
        }
        val status = p.status("BRAIN 3D —")
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                status.text = b.statusLine()
                h.postDelayed(this, 200)
            }
        })
        return raw
    }

    private fun hemiControls(p: PanelBuilder, name: String, h: BrainBoard.Hemi, color: Int) {
        val sp = h.path
        val t = h.tuning
        p.title(name, color)
        p.switch("$name active", sp.on) { sp.on = it }
        p.switch("RAW COMPLETE $name", sp.raw) { sp.raw = it; h.rawVisual = it }
        p.seek("Threshold", 0f, 1f, sp.thr) { sp.thr = it }
        p.seek("Level", 0f, 1f, sp.level) { sp.level = it }
        p.seek("Intensity", 0f, 1f, h.intensity) { h.intensity = it }
        p.seek("3D atmosphere", 0f, 1f, h.atmosphere) { h.atmosphere = it }
        p.seek("Wave", 0f, 1f, h.wave) { h.wave = it }
        p.seek("Wave threshold", 0f, 1f, h.waveThr) { h.waveThr = it }
        p.seek("Speed", 0f, 1f, h.speed) { h.speed = it }
        p.seek("Speed threshold", 0f, 1f, h.speedThr) { h.speedThr = it }
        p.seek("Movement", 0f, 1f, h.move) { h.move = it }
        p.seek("Movement threshold", 0f, 1f, h.moveThr) { h.moveThr = it }
        p.note("Degains: dB gain below / above the threshold")
        p.seek("Gain below threshold (dB)", -300f, 0f, sp.gainNegDb, 0) { sp.gainNegDb = it }
        p.seek("Gain above threshold (dB)", 0f, 300f, sp.gainPosDb, 0) { sp.gainPosDb = it }
        p.switch("Bipolar ±120 dB rails", sp.bipOn) { sp.bipOn = it }
        p.seek("FLOOR rail (dB, relative to threshold)", -120f, 0f, sp.bipNeg, 0) { sp.bipNeg = it }
        p.seek("OVER rail (dB, relative to threshold)", 0f, 120f, sp.bipPos, 0) { sp.bipPos = it }
        p.seek("Attack (ms)", 1f, 500f, sp.attackMs.toFloat(), 0) { sp.attackMs = it.toInt().coerceAtLeast(1) }
        p.seek("Release (ms)", 1f, 2000f, sp.releaseMs.toFloat(), 0) { sp.releaseMs = it.toInt().coerceAtLeast(1) }
        p.note("Brain visual (same tuning as the eyes visual)")
        p.seek("Contrast", 0f, 2f, t.contrast) { t.contrast = it }
        p.seek("Contrast threshold", 0f, 1f, t.contrastThr) { t.contrastThr = it }
        p.seek("Brightness", -1f, 1f, t.brightness) { t.brightness = it }
        p.seek("Brightness threshold", 0f, 1f, t.brightnessThr) { t.brightnessThr = it }
        p.seek("Colour level (saturation)", 0f, 2f, h.colourLevel) { h.colourLevel = it }
        p.seek("Colour threshold R", 0f, 255f, t.thrR.toFloat(), 0) { t.thrR = it.toInt() }
        p.seek("Colour threshold G", 0f, 255f, t.thrG.toFloat(), 0) { t.thrG = it.toInt() }
        p.seek("Colour threshold B", 0f, 255f, t.thrB.toFloat(), 0) { t.thrB = it.toInt() }
        p.seek("Threshold softness", 0f, 1f, t.softness) { t.softness = it }
        p.button("Colour threshold mode: ${VisualShieldView.EyeTuning.MODE_NAMES[t.mode]} (tap to change)") { btn ->
            t.mode = (t.mode + 1) % VisualShieldView.EyeTuning.MODE_COUNT
            btn.text = "Colour threshold mode: ${VisualShieldView.EyeTuning.MODE_NAMES[t.mode]} (tap to change)"
        }
        p.switch("Invert colours", t.invert) { t.invert = it }
    }

    /** Copies one hemisphere's settings onto the other (live objects; sliders keep their shown value). */
    private fun copyHemi(from: BrainBoard.Hemi, to: BrainBoard.Hemi) {
        val a = from.path
        val b = to.path
        b.on = a.on; b.thr = a.thr; b.level = a.level; b.gainNegDb = a.gainNegDb; b.gainPosDb = a.gainPosDb
        b.bipOn = a.bipOn; b.bipNeg = a.bipNeg; b.bipPos = a.bipPos
        b.attackMs = a.attackMs; b.releaseMs = a.releaseMs; b.raw = a.raw
        to.intensity = from.intensity; to.atmosphere = from.atmosphere
        to.wave = from.wave; to.waveThr = from.waveThr; to.speed = from.speed; to.speedThr = from.speedThr
        to.move = from.move; to.moveThr = from.moveThr; to.colourLevel = from.colourLevel
        to.rawVisual = from.rawVisual
        val s = from.tuning
        val d = to.tuning
        d.contrast = s.contrast; d.brightness = s.brightness; d.contrastThr = s.contrastThr
        d.brightnessThr = s.brightnessThr; d.thrR = s.thrR; d.thrG = s.thrG; d.thrB = s.thrB
        d.softness = s.softness; d.mode = s.mode; d.invert = s.invert
    }

    // ───────────────────────────────────────────────────────────────────── ANATOMY
    private fun buildAnatomy(ctx: Context, root: LinearLayout, view: VisualShieldView): Switch {
        val a = view.anatomy3d
        val p = PanelBuilder(ctx, root)
        p.title("COMPLETE 3D HUMAN · INSIDE + OUTSIDE ANATOMY", Color.rgb(0x26, 0xC6, 0xDA))
        p.note("Skin · muscle · skeleton · organs · vessels/nerves · brain. OUTSIDE layers follow the body-mix OUTSIDE path, INSIDE layers the INSIDE path.")
        p.note("The outer skin is a smooth continuous 3D shell; inner structures remain separate anatomical layers for X-ray and RAW inspection.")
        p.switch("3D anatomy ON", a.enabled) { a.enabled = it }
        val raw = p.switch("RAW COMPLETE anatomy (force all layers visible · bypass signal and visual processing)", false) {
            a.setRawAll(it)
        }
        p.note("RAW shows all inside/outside layers at full level; your layer switches are restored when RAW is off.")
        p.note("Heart: chambers, septum, valves, coronary vessels. Neck: throat, thyroid, trachea, cervical spine, carotids and jugulars.")
        p.switch("Also draw inside layers in the ARCore GPU renderer", a.gpuOn) { a.gpuOn = it }

        p.title("Layers", Color.rgb(0xB0, 0xBE, 0xC5))
        for (i in 0 until AnatomyModel3D.LAYER_COUNT) {
            p.switch(AnatomyModel3D.LAYER_NAMES[i], a.layerOn[i]) { a.layerOn[i] = it }
            p.seek("${AnatomyModel3D.LAYER_NAMES[i]} level", 0f, 1f, a.layerLevel[i]) { a.layerLevel[i] = it }
        }
        p.switch("Connected L/R skeleton and pose segments", a.poseRigOn) { a.poseRigOn = it }
        p.seek("X-ray (outer layers see-through)", 0f, 1f, a.xray) { a.xray = it }

        p.title("View", Color.rgb(0xB0, 0xBE, 0xC5))
        p.seek("Size", 0.2f, 1.2f, a.size) { a.size = it }
        p.seek("Position X", 0f, 1f, a.posX) { a.posX = it }
        p.seek("Position Y", 0f, 1f, a.posY) { a.posY = it }
        p.note("Quick views · the whole body, silhouette, and internal layers turn together.")
        val autoRotate = p.switch("Auto rotate (swing)", a.yawAuto) {
            if (it) a.enableAutoView() else {
                a.yawAuto = false
                if (a.viewPreset == "Auto") a.viewPreset = "Manual"
            }
        }
        fun selectView(name: String) {
            a.selectViewPreset(name)
            autoRotate.isChecked = false
        }
        p.button("Front view") { selectView("Front") }
        p.button("Back view") { selectView("Back") }
        p.button("Left profile") { selectView("Left") }
        p.button("Right profile") { selectView("Right") }
        p.button("Resume auto rotation") { autoRotate.isChecked = true }
        p.seek("Rotate speed", 0f, 1f, a.yawSpeed) { a.yawSpeed = it }
        p.seek("Manual yaw", -1.6f, 1.6f, a.yaw) { a.yaw = it }
        p.seek("Tilt", -0.6f, 0.6f, a.tilt) { a.tilt = it }
        p.seek("3D atmosphere", 0f, 1f, a.atmosphere) { a.atmosphere = it }
        p.seek("Wave (breathing · heartbeat)", 0f, 1f, a.wave) { a.wave = it }
        p.seek("Speed", 0f, 1f, a.speed) { a.speed = it }
        p.seek("Movement", 0f, 1f, a.move) { a.move = it }

        pathControls(p, "INSIDE PATH (skeleton · organs · vessels · brain)", a.inside)
        pathControls(p, "OUTSIDE PATH (skin · muscle)", a.outside)

        val t = a.tuning
        p.title("Anatomy visual", Color.rgb(0xB0, 0xBE, 0xC5))
        p.seek("Contrast", 0f, 2f, t.contrast) { t.contrast = it }
        p.seek("Contrast threshold", 0f, 1f, t.contrastThr) { t.contrastThr = it }
        p.seek("Brightness", -1f, 1f, t.brightness) { t.brightness = it }
        p.seek("Brightness threshold", 0f, 1f, t.brightnessThr) { t.brightnessThr = it }
        p.seek("Colour level (saturation)", 0f, 2f, a.colourLevel) { a.colourLevel = it }
        p.seek("Colour threshold R", 0f, 255f, t.thrR.toFloat(), 0) { t.thrR = it.toInt() }
        p.seek("Colour threshold G", 0f, 255f, t.thrG.toFloat(), 0) { t.thrG = it.toInt() }
        p.seek("Colour threshold B", 0f, 255f, t.thrB.toFloat(), 0) { t.thrB = it.toInt() }
        p.button("Colour threshold mode: ${VisualShieldView.EyeTuning.MODE_NAMES[t.mode]} (tap to change)") { btn ->
            t.mode = (t.mode + 1) % VisualShieldView.EyeTuning.MODE_COUNT
            btn.text = "Colour threshold mode: ${VisualShieldView.EyeTuning.MODE_NAMES[t.mode]} (tap to change)"
        }

        val status = p.status("ANATOMY 3D —", Color.rgb(0x80, 0xDE, 0xEA))
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                status.text = a.statusLine()
                h.postDelayed(this, 200)
            }
        })
        return raw
    }

    private fun pathControls(p: PanelBuilder, name: String, sp: SignalPath) {
        p.title(name, Color.rgb(0xB0, 0xBE, 0xC5))
        p.switch("Active", sp.on) { sp.on = it }
        p.seek("Threshold", 0f, 1f, sp.thr) { sp.thr = it }
        p.seek("Level", 0f, 1f, sp.level) { sp.level = it }
        p.seek("Gain below threshold (dB)", -300f, 0f, sp.gainNegDb, 0) { sp.gainNegDb = it }
        p.seek("Gain above threshold (dB)", 0f, 300f, sp.gainPosDb, 0) { sp.gainPosDb = it }
        p.switch("Bipolar ±120 dB rails", sp.bipOn) { sp.bipOn = it }
        p.seek("FLOOR rail (dB)", -120f, 0f, sp.bipNeg, 0) { sp.bipNeg = it }
        p.seek("OVER rail (dB)", 0f, 120f, sp.bipPos, 0) { sp.bipPos = it }
        p.seek("Attack (ms)", 1f, 500f, sp.attackMs.toFloat(), 0) { sp.attackMs = it.toInt().coerceAtLeast(1) }
        p.seek("Release (ms)", 1f, 2000f, sp.releaseMs.toFloat(), 0) { sp.releaseMs = it.toInt().coerceAtLeast(1) }
    }
}
