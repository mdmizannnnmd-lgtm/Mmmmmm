package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object BodyRegionBulletAtomsparePanels {
    fun build(ctx: Context, root: LinearLayout, b: BodyRegionBulletAtomspareBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFF7043.toInt()
        p.title("BODY REGION · BULLET ATOMSPARE · MUZZLE/SHOCK/PEAKS", c)
        p.note("Research: 3–5ms muzzle N-wave · shockwave · L/M/H peaks · matches knife/burst/bullet")
        p.switch("ON", b.enabled) { b.enabled = it }
        p.switch("RAW", b.rawComplete) { b.rawComplete = it }
        p.seek("Thr", 0.05f, 0.8f, b.thr) { b.thr = it }
        p.seek("Level", 0.2f, 1.5f, b.levelAmt) { b.levelAmt = it }
        val st = p.status("REGION-BULLET —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() { st.text = b.status; Handler(Looper.getMainLooper()).postDelayed(this, 280) }
        })
    }
}
