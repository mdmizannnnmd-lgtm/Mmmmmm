package com.mizan

/**
 * All ambient anatomy · body-parts ambient · brain · skin · ear skin · noise skin ·
 * leg skin · ALL body skin ambient system in anatomy. RAW COMPLETE.
 */
class AllBodySkinAnatomyAmbientBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.22f
    @Volatile var lv = 0.85f

    // Master skin ambient
    @Volatile var allSkinOn = true
    @Volatile var allSkinOut = 0f

    // Regional skin
    @Volatile var headSkin = 0f
    @Volatile var faceSkin = 0f
    @Volatile var earSkinL = 0f
    @Volatile var earSkinR = 0f
    @Volatile var noiseSkin = 0f   // nasal / noise-region skin
    @Volatile var noseSkinOn = true
    @Volatile var noseSkin = 0f
    @Volatile var noseBridgeSkin = 0f
    @Volatile var noseTipSkin = 0f
    @Volatile var nostrilSkinL = 0f
    @Volatile var nostrilSkinR = 0f
    @Volatile var neckSkin = 0f
    @Volatile var neckSkinOn = true
    @Volatile var neckFrontSkin = 0f
    @Volatile var neckBackSkin = 0f
    @Volatile var neckSideSkinL = 0f
    @Volatile var neckSideSkinR = 0f
    @Volatile var chestSkin = 0f
    @Volatile var bellySkin = 0f
    @Volatile var backSkin = 0f
    @Volatile var armSkinL = 0f
    @Volatile var armSkinR = 0f
    @Volatile var handSkinL = 0f
    @Volatile var handSkinR = 0f
    @Volatile var legSkinL = 0f
    @Volatile var legSkinR = 0f
    @Volatile var footSkinL = 0f
    @Volatile var footSkinR = 0f

    // Eyes skin ambient L/R
    @Volatile var eyesSkinOn = true
    @Volatile var eyeSkinL = 0f
    @Volatile var eyeSkinR = 0f
    @Volatile var eyesSkinOut = 0f
    @Volatile var eyelidSkinL = 0f
    @Volatile var eyelidSkinR = 0f
    @Volatile var underEyeSkinL = 0f
    @Volatile var underEyeSkinR = 0f

    // Face skins (multiple)
    @Volatile var faceSkinsOn = true
    @Volatile var faceCheekSkinL = 0f
    @Volatile var faceCheekSkinR = 0f
    @Volatile var faceForeheadSkin = 0f
    @Volatile var faceChinSkin = 0f
    @Volatile var faceJawSkinL = 0f
    @Volatile var faceJawSkinR = 0f
    @Volatile var faceFullSkin = 0f

    // Brain 3D skin ambient
    @Volatile var brain3dSkinOn = true
    @Volatile var brain3dSkinOut = 0f

    // Heart sling (screen 3D)
    @Volatile var heartSlingOn = true
    @Volatile var heartSlingOut = 0f

    // Complete missing skin regions
    @Volatile var missingSkinOn = true
    @Volatile var scalpSkin = 0f
    @Volatile var lipSkin = 0f
    @Volatile var shoulderSkinL = 0f
    @Volatile var shoulderSkinR = 0f
    @Volatile var underarmSkinL = 0f
    @Volatile var underarmSkinR = 0f
    @Volatile var upperArmSkinL = 0f
    @Volatile var upperArmSkinR = 0f
    @Volatile var elbowSkinL = 0f
    @Volatile var elbowSkinR = 0f
    @Volatile var forearmSkinL = 0f
    @Volatile var forearmSkinR = 0f
    @Volatile var wristSkinL = 0f
    @Volatile var wristSkinR = 0f
    @Volatile var palmSkinL = 0f
    @Volatile var palmSkinR = 0f
    @Volatile var upperBackSkin = 0f
    @Volatile var lowerBackSkin = 0f
    @Volatile var ribcageSkin = 0f
    @Volatile var hipSkinL = 0f
    @Volatile var hipSkinR = 0f
    @Volatile var pelvisSkin = 0f
    @Volatile var buttockSkinL = 0f
    @Volatile var buttockSkinR = 0f
    @Volatile var groinSkin = 0f
    @Volatile var thighSkinL = 0f
    @Volatile var thighSkinR = 0f
    @Volatile var kneeSkinL = 0f
    @Volatile var kneeSkinR = 0f
    @Volatile var shinSkinL = 0f
    @Volatile var shinSkinR = 0f
    @Volatile var calfSkinL = 0f
    @Volatile var calfSkinR = 0f
    @Volatile var ankleSkinL = 0f
    @Volatile var ankleSkinR = 0f
    @Volatile var soleSkinL = 0f
    @Volatile var soleSkinR = 0f
    @Volatile var completeSkinCoverage = 0f
    @Volatile var forceFullBodySkin = true
    @Volatile var fullBodySkinOut = 0f

    // Brain ambient (linked into anatomy)
    @Volatile var brainOn = true
    @Volatile var brainOut = 0f
    @Volatile var brainL = 0f
    @Volatile var brainR = 0f

    // Anatomy layer drives
    @Volatile var anatomySkinLayer = 0f
    @Volatile var anatomyBrainLayer = 0f
    @Volatile var anatomyFaceLayer = 0f

    @Volatile var status = "ALL SKIN·ANATOMY ambient idle"

    private fun lane(on: Boolean, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float) {
        if (!enabled) {
            status = "ALL SKIN·ANATOMY OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        allSkinOut = lane(allSkinOn, e)

        headSkin = allSkinOut * 1.0f
        faceSkin = allSkinOut * 0.98f
        earSkinL = allSkinOut * 0.92f
        earSkinR = allSkinOut * 0.92f
        noiseSkin = allSkinOut * 0.90f
        neckSkin = allSkinOut * 0.94f
        chestSkin = allSkinOut * 0.96f
        bellySkin = allSkinOut * 0.94f
        backSkin = allSkinOut * 0.93f
        armSkinL = allSkinOut * 0.91f
        armSkinR = allSkinOut * 0.91f
        handSkinL = allSkinOut * 0.88f
        handSkinR = allSkinOut * 0.88f
        legSkinL = allSkinOut * 0.93f
        legSkinR = allSkinOut * 0.93f
        footSkinL = allSkinOut * 0.87f
        footSkinR = allSkinOut * 0.87f

        eyesSkinOut = lane(eyesSkinOn, e * 0.97f)
        eyeSkinL = eyesSkinOut * 1.0f
        eyeSkinR = eyesSkinOut * 0.98f
        eyelidSkinL = eyesSkinOut * 0.92f
        eyelidSkinR = eyesSkinOut * 0.92f
        underEyeSkinL = eyesSkinOut * 0.88f
        underEyeSkinR = eyesSkinOut * 0.88f

        noseSkin = lane(noseSkinOn, e * 0.94f)
        noiseSkin = maxOf(noiseSkin, noseSkin) // keep alias
        noseBridgeSkin = noseSkin * 0.95f
        noseTipSkin = noseSkin * 0.92f
        nostrilSkinL = noseSkin * 0.88f
        nostrilSkinR = noseSkin * 0.88f

        faceFullSkin = lane(faceSkinsOn, e * 0.96f)
        faceCheekSkinL = faceFullSkin * 0.95f
        faceCheekSkinR = faceFullSkin * 0.95f
        faceForeheadSkin = faceFullSkin * 0.97f
        faceChinSkin = faceFullSkin * 0.90f
        faceJawSkinL = faceFullSkin * 0.92f
        faceJawSkinR = faceFullSkin * 0.92f
        faceSkin = maxOf(faceSkin, faceFullSkin)

        brain3dSkinOut = lane(brain3dSkinOn, e * 0.93f)
        brainOut = maxOf(brainOut, brain3dSkinOut)
        heartSlingOut = lane(heartSlingOn, e * 0.94f)

        brainOut = lane(brainOn, e * 0.95f)
        brainL = brainOut * 0.98f
        brainR = brainOut * 0.98f

        
        // Fill all previously missing skin regions
        val ms = lane(missingSkinOn, e)
        scalpSkin = maxOf(headSkin * 0.95f, ms * 0.95f)
        lipSkin = maxOf(faceFullSkin * 0.9f, ms * 0.88f)
        shoulderSkinL = maxOf(armSkinL * 0.95f, ms * 0.93f)
        shoulderSkinR = maxOf(armSkinR * 0.95f, ms * 0.93f)
        underarmSkinL = ms * 0.88f; underarmSkinR = ms * 0.88f
        upperArmSkinL = maxOf(armSkinL * 0.96f, ms * 0.92f)
        upperArmSkinR = maxOf(armSkinR * 0.96f, ms * 0.92f)
        elbowSkinL = ms * 0.90f; elbowSkinR = ms * 0.90f
        forearmSkinL = maxOf(armSkinL * 0.94f, ms * 0.91f)
        forearmSkinR = maxOf(armSkinR * 0.94f, ms * 0.91f)
        wristSkinL = maxOf(handSkinL * 0.95f, ms * 0.89f)
        wristSkinR = maxOf(handSkinR * 0.95f, ms * 0.89f)
        palmSkinL = maxOf(handSkinL * 0.97f, ms * 0.90f)
        palmSkinR = maxOf(handSkinR * 0.97f, ms * 0.90f)
        upperBackSkin = maxOf(backSkin * 0.96f, ms * 0.93f)
        lowerBackSkin = maxOf(backSkin * 0.94f, ms * 0.92f)
        ribcageSkin = maxOf(chestSkin * 0.95f, ms * 0.93f)
        hipSkinL = maxOf(legSkinL * 0.9f, ms * 0.91f)
        hipSkinR = maxOf(legSkinR * 0.9f, ms * 0.91f)
        pelvisSkin = ms * 0.90f
        buttockSkinL = ms * 0.89f; buttockSkinR = ms * 0.89f
        groinSkin = ms * 0.85f
        thighSkinL = maxOf(legSkinL * 0.97f, ms * 0.93f)
        thighSkinR = maxOf(legSkinR * 0.97f, ms * 0.93f)
        kneeSkinL = ms * 0.91f; kneeSkinR = ms * 0.91f
        shinSkinL = maxOf(legSkinL * 0.92f, ms * 0.90f)
        shinSkinR = maxOf(legSkinR * 0.92f, ms * 0.90f)
        calfSkinL = maxOf(legSkinL * 0.93f, ms * 0.90f)
        calfSkinR = maxOf(legSkinR * 0.93f, ms * 0.90f)
        ankleSkinL = maxOf(footSkinL * 0.95f, ms * 0.88f)
        ankleSkinR = maxOf(footSkinR * 0.95f, ms * 0.88f)
        soleSkinL = maxOf(footSkinL * 0.96f, ms * 0.87f)
        soleSkinR = maxOf(footSkinR * 0.96f, ms * 0.87f)
        completeSkinCoverage = maxOf(
            allSkinOut, faceFullSkin, neckSkin, eyesSkinOut, noseSkin,
            scalpSkin, shoulderSkinL, thighSkinL, soleSkinL, ms
        )
        if (forceFullBodySkin || rawComplete) {
            allSkinOn = true
            eyesSkinOn = true
            noseSkinOn = true
            faceSkinsOn = true
            neckSkinOn = true
            brainOn = true
            missingSkinOn = true
            fullBodySkinOut = maxOf(
                completeSkinCoverage, allSkinOut, headSkin, faceSkin,
                earSkinL, earSkinR, noseSkin, neckSkin, chestSkin, bellySkin, backSkin,
                armSkinL, armSkinR, handSkinL, handSkinR, legSkinL, legSkinR,
                footSkinL, footSkinR, eyeSkinL, eyeSkinR, scalpSkin, soleSkinL, soleSkinR
            )
            completeSkinCoverage = maxOf(completeSkinCoverage, fullBodySkinOut)
            allSkinOut = maxOf(allSkinOut, fullBodySkinOut)
        } else {
            fullBodySkinOut = completeSkinCoverage
        }

        anatomySkinLayer = maxOf(allSkinOut, completeSkinCoverage)
        anatomyBrainLayer = brainOut
        anatomyFaceLayer = maxOf(faceSkin, noiseSkin, noseSkin, earSkinL, earSkinR, eyesSkinOut, faceFullSkin)

        status =
            "SKIN-ALL=${(allSkinOut*100).toInt()}% NECK=${(neckSkin*100).toInt()}% EAR=${(earSkinL*100).toInt()}% NOSE=${(noseSkin*100).toInt()}% " +
            "LEG L/R=${(legSkinL*100).toInt()}/${(legSkinR*100).toInt()}% · " +
            "BRAIN3D-SKIN=${(brain3dSkinOut*100).toInt()}% HEART-SLING=${(heartSlingOut*100).toInt()}% FACE-SKIN=${(faceFullSkin*100).toInt()}% EYE-SKIN L/R=${(eyeSkinL*100).toInt()}/${(eyeSkinR*100).toInt()}% FACE=${(anatomyFaceLayer*100).toInt()}%" +
            " · FULL-BODY-SKIN=${(fullBodySkinOut*100).toInt()}% FILL=${(completeSkinCoverage*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        try {
            v.skinAll.atmosphere = maxOf(v.skinAll.atmosphere, allSkinOut, completeSkinCoverage, fullBodySkinOut)
            // Force every major skin region atmosphere for full body
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, headSkin, scalpSkin, fullBodySkinOut * 0.9f)
            v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, chestSkin, ribcageSkin, fullBodySkinOut * 0.9f)
            v.skinAbdomen.atmosphere = maxOf(v.skinAbdomen.atmosphere, bellySkin, fullBodySkinOut * 0.85f)
            v.skinArmL.atmosphere = maxOf(v.skinArmL.atmosphere, armSkinL, fullBodySkinOut * 0.85f)
            v.skinArmR.atmosphere = maxOf(v.skinArmR.atmosphere, armSkinR, fullBodySkinOut * 0.85f)
            v.skinLegL.atmosphere = maxOf(v.skinLegL.atmosphere, legSkinL, thighSkinL, fullBodySkinOut * 0.85f)
            v.skinLegR.atmosphere = maxOf(v.skinLegR.atmosphere, legSkinR, thighSkinR, fullBodySkinOut * 0.85f)
            v.skinFootL.atmosphere = maxOf(v.skinFootL.atmosphere, footSkinL, soleSkinL)
            v.skinFootR.atmosphere = maxOf(v.skinFootR.atmosphere, footSkinR, soleSkinR)
            v.handL.atmosphere = maxOf(v.handL.atmosphere, handSkinL, palmSkinL)
            v.handR.atmosphere = maxOf(v.handR.atmosphere, handSkinR, palmSkinR)
            v.face.atmosphere = maxOf(v.face.atmosphere, faceFullSkin, fullBodySkinOut * 0.9f)
            v.neck.atmosphere = maxOf(v.neck.atmosphere, neckSkin)
            v.eyeL.atmosphere = maxOf(v.eyeL.atmosphere, eyeSkinL)
            v.eyeR.atmosphere = maxOf(v.eyeR.atmosphere, eyeSkinR)
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, headSkin, scalpSkin)
            v.skinArmL.atmosphere = maxOf(v.skinArmL.atmosphere, armSkinL, shoulderSkinL, upperArmSkinL, forearmSkinL, elbowSkinL, wristSkinL)
            v.skinArmR.atmosphere = maxOf(v.skinArmR.atmosphere, armSkinR, shoulderSkinR, upperArmSkinR, forearmSkinR, elbowSkinR, wristSkinR)
            v.handL.atmosphere = maxOf(v.handL.atmosphere, handSkinL, palmSkinL)
            v.handR.atmosphere = maxOf(v.handR.atmosphere, handSkinR, palmSkinR)
            v.skinLegL.atmosphere = maxOf(v.skinLegL.atmosphere, legSkinL, thighSkinL, kneeSkinL, shinSkinL, calfSkinL, hipSkinL)
            v.skinLegR.atmosphere = maxOf(v.skinLegR.atmosphere, legSkinR, thighSkinR, kneeSkinR, shinSkinR, calfSkinR, hipSkinR)
            v.skinFootL.atmosphere = maxOf(v.skinFootL.atmosphere, footSkinL, ankleSkinL, soleSkinL)
            v.skinFootR.atmosphere = maxOf(v.skinFootR.atmosphere, footSkinR, ankleSkinR, soleSkinR)
            v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, chestSkin, ribcageSkin)
            v.skinAbdomen.atmosphere = maxOf(v.skinAbdomen.atmosphere, bellySkin, pelvisSkin, groinSkin * 0.7f)
            v.face.atmosphere = maxOf(v.face.atmosphere, faceFullSkin, lipSkin)
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, headSkin)
            v.face.atmosphere = maxOf(v.face.atmosphere, faceSkin, anatomyFaceLayer)
            v.eyeL.atmosphere = maxOf(v.eyeL.atmosphere, eyeSkinL, eyelidSkinL)
            v.eyeR.atmosphere = maxOf(v.eyeR.atmosphere, eyeSkinR, eyelidSkinR)
            v.eyes.atmosphere = maxOf(v.eyes.atmosphere, eyesSkinOut)
            try { v.cenDrive.eyesOn = true } catch (_: Throwable) {}
            v.forehead.atmosphere = maxOf(v.forehead.atmosphere, headSkin * 0.9f)
            v.neck.atmosphere = maxOf(v.neck.atmosphere, neckSkin, neckFrontSkin, neckBackSkin, neckSideSkinL, neckSideSkinR)
            v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, chestSkin)
            v.skinAbdomen.atmosphere = maxOf(v.skinAbdomen.atmosphere, bellySkin)
            v.belly.atmosphere = maxOf(v.belly.atmosphere, bellySkin)
            v.heart.atmosphere = maxOf(v.heart.atmosphere, heartSlingOut)
            try {
                v.anatomy3d.audioFxTargetPart = HumanDetection.PART_TORSO
                v.anatomy3d.audioFxLevel = maxOf(v.anatomy3d.audioFxLevel, heartSlingOut)
                v.anatomy3d.audioFxKind = 0
            } catch (_: Throwable) {}
            v.forehead.atmosphere = maxOf(v.forehead.atmosphere, faceForeheadSkin)
            v.face.atmosphere = maxOf(v.face.atmosphere, faceFullSkin, faceCheekSkinL, faceCheekSkinR)
            v.skinArmL.atmosphere = maxOf(v.skinArmL.atmosphere, armSkinL)
            v.skinArmR.atmosphere = maxOf(v.skinArmR.atmosphere, armSkinR)
            v.handL.atmosphere = maxOf(v.handL.atmosphere, handSkinL)
            v.handR.atmosphere = maxOf(v.handR.atmosphere, handSkinR)
            v.skinLegL.atmosphere = maxOf(v.skinLegL.atmosphere, legSkinL)
            v.skinLegR.atmosphere = maxOf(v.skinLegR.atmosphere, legSkinR)
            v.skinFootL.atmosphere = maxOf(v.skinFootL.atmosphere, footSkinL)
            v.skinFootR.atmosphere = maxOf(v.skinFootR.atmosphere, footSkinR)
        } catch (_: Throwable) {}
        try {
            v.moreMissed.earL = maxOf(v.moreMissed.earL, earSkinL)
            v.moreMissed.earR = maxOf(v.moreMissed.earR, earSkinR)
            v.faceEyeNoise.nose = maxOf(v.faceEyeNoise.nose, noiseSkin, noseSkin, noseBridgeSkin, noseTipSkin)
            v.faceEyeNoise.earL = maxOf(v.faceEyeNoise.earL, earSkinL)
            v.faceEyeNoise.earR = maxOf(v.faceEyeNoise.earR, earSkinR)
            v.faceEyeNoise.faceSkin = maxOf(v.faceEyeNoise.faceSkin, faceSkin)
            v.faceEyeNoise.eyeL = maxOf(v.faceEyeNoise.eyeL, eyeSkinL)
            v.faceEyeNoise.eyeR = maxOf(v.faceEyeNoise.eyeR, eyeSkinR)
            v.eyesHeartBelly.eyeLOut = maxOf(v.eyesHeartBelly.eyeLOut, eyeSkinL)
            v.eyesHeartBelly.eyeROut = maxOf(v.eyesHeartBelly.eyeROut, eyeSkinR)
            v.eyesHeartBelly.eyesFullOut = maxOf(v.eyesHeartBelly.eyesFullOut, eyesSkinOut)
        } catch (_: Throwable) {}
        try {
            v.bodyFreqRegen.brainFullOut = maxOf(v.bodyFreqRegen.brainFullOut, brainOut)
            v.bodyFreqRegen.brainLHemOut = maxOf(v.bodyFreqRegen.brainLHemOut, brainL)
            v.bodyFreqRegen.brainRHemOut = maxOf(v.bodyFreqRegen.brainRHemOut, brainR)
            v.bodyFreqRegen.bodySkinSysOut = maxOf(v.bodyFreqRegen.bodySkinSysOut, allSkinOut)
        } catch (_: Throwable) {}
        try {
            val a = v.anatomy3d
            a.enabled = true
            if (a.layerOn.isNotEmpty()) {
                a.layerOn[0] = true // skin
                a.layerLevel[0] = maxOf(a.layerLevel[0], anatomySkinLayer)
            }
            if (a.layerOn.size > 5) {
                a.layerOn[5] = true // brain
                a.layerLevel[5] = maxOf(a.layerLevel[5], anatomyBrainLayer)
            }
            if (a.layerOn.size > 6) {
                a.layerOn[6] = true // face
                a.layerLevel[6] = maxOf(a.layerLevel[6], anatomyFaceLayer)
            }
            a.atmosphere = maxOf(a.atmosphere, allSkinOut, brainOut, brain3dSkinOut)
            if (a.layerOn.size > 5) {
                a.layerOn[5] = true
                a.layerLevel[5] = maxOf(a.layerLevel[5], brain3dSkinOut)
            }
            if (a.layerOn.size > 6) {
                a.layerOn[6] = true
                a.layerLevel[6] = maxOf(a.layerLevel[6], faceFullSkin, anatomyFaceLayer)
            }
        } catch (_: Throwable) {}
        try {
            v.skinAtomspare.enabled = true
            v.skinAtomspare.atomSpareOn = true
            v.skinAtomspare.skinOutsideOut = maxOf(v.skinAtomspare.skinOutsideOut, allSkinOut)
            v.skinAtomspare.epidermisOut = maxOf(v.skinAtomspare.epidermisOut, allSkinOut)
        } catch (_: Throwable) {}
        try {
            v.completeAtomProtect.atomOutsideOut = maxOf(v.completeAtomProtect.atomOutsideOut, allSkinOut)
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, allSkinOut * 0.7f, brainOut * 0.6f)
        } catch (_: Throwable) {}
    }
}
