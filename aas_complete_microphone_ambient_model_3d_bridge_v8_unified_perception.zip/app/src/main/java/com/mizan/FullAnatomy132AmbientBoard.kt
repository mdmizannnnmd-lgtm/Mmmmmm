package com.mizan

/**
 * Full anatomy ambient — 11 systems · ~132 structures.
 * Brain/eyes/ear/face/neck/heart/glands/body + respiratory, CV, digestive,
 * urinary, endocrine, lymphatic, skeletal, muscular, joints, PNS, reproductive.
 * Symbolic ambient only — not medical diagnosis. RAW COMPLETE.
 */
class FullAnatomy132AmbientBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.18f
    @Volatile var levelAmt = 0.92f

    // Masters
    @Volatile var brainOn = true
    @Volatile var eyesOn = true
    @Volatile var earOn = true
    @Volatile var faceOn = true
    @Volatile var neckOn = true
    @Volatile var heartOn = true
    @Volatile var glandsOn = true
    @Volatile var bodyPartsOn = true
    @Volatile var respOn = true
    @Volatile var cardioOn = true
    @Volatile var digestOn = true
    @Volatile var urinaryOn = true
    @Volatile var endoOn = true
    @Volatile var lymphOn = true
    @Volatile var skeletalOn = true
    @Volatile var muscleOn = true
    @Volatile var jointOn = true
    @Volatile var pnsOn = true
    @Volatile var reproOn = true

    // Aggregate outs
    @Volatile var brainOut = 0f
    @Volatile var eyesOut = 0f
    @Volatile var earOut = 0f
    @Volatile var faceOut = 0f
    @Volatile var neckOut = 0f
    @Volatile var heartOut = 0f
    @Volatile var glandsOut = 0f
    @Volatile var bodyPartsOut = 0f
    @Volatile var respOut = 0f
    @Volatile var cardioOut = 0f
    @Volatile var digestOut = 0f
    @Volatile var urinaryOut = 0f
    @Volatile var endoOut = 0f
    @Volatile var lymphOut = 0f
    @Volatile var skeletalOut = 0f
    @Volatile var skullBone = 0f
    @Volatile var femurBone = 0f
    @Volatile var osteoblastAmb = 0f
    @Volatile var osteoclastAmb = 0f
    @Volatile var osteocyteAmb = 0f
    @Volatile var muscleOut = 0f
    @Volatile var jointOut = 0f
    @Volatile var pnsOut = 0f
    @Volatile var reproOut = 0f
    @Volatile var anatomyFullOut = 0f

    // Respiratory detail (sample named outs)
    @Volatile var nasalCavity = 0f
    @Volatile var pharynx = 0f
    @Volatile var larynx = 0f
    @Volatile var trachea = 0f
    @Volatile var bronchi = 0f
    @Volatile var alveoli = 0f
    @Volatile var lungL = 0f
    @Volatile var lungR = 0f
    @Volatile var pleura = 0f
    @Volatile var diaphragm = 0f
    @Volatile var intercostals = 0f

    // Cardiovascular
    @Volatile var ra = 0f
    @Volatile var rv = 0f
    @Volatile var la = 0f
    @Volatile var lvChamber = 0f
    @Volatile var valves = 0f
    @Volatile var saNode = 0f
    @Volatile var aorta = 0f
    @Volatile var coronary = 0f
    @Volatile var pericardium = 0f
    @Volatile var avNode = 0f
    @Volatile var venaCava = 0f
    @Volatile var pulmonaryVessels = 0f
    @Volatile var carotid = 0f
    @Volatile var jugular = 0f
    @Volatile var femoral = 0f
    @Volatile var capillaries = 0f

    // Digestive
    @Volatile var oralCavity = 0f
    @Volatile var esophagus = 0f
    @Volatile var stomach = 0f
    @Volatile var intestine = 0f
    @Volatile var liver = 0f
    @Volatile var pancreas = 0f
    @Volatile var gallbladder = 0f
    @Volatile var peritoneum = 0f
    @Volatile var analCanal = 0f

    // Face / oral
    @Volatile var noseAmb = 0f
    @Volatile var mouthAmb = 0f
    @Volatile var teethAmb = 0f
    @Volatile var tongueAmb = 0f
    @Volatile var faceSkinAmb = 0f

    @Volatile var status = "ANATOMY132 idle"

    private fun lane(on: Boolean, t: Float, l: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * l).coerceIn(0f, 1f)
        val th = t.coerceIn(0.02f, 1f)
        return if (e >= th) (((e - th) / (1f - th).coerceAtLeast(0.05f)) * l).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, brain: Float, eye: Float, ear: Float, skin: Float, heartIn: Float) {
        if (!enabled) {
            status = "ANATOMY132 OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val b = maxOf(brain, e * 0.7f)
        val ey = maxOf(eye, e * 0.65f)
        val er = maxOf(ear, e * 0.65f)
        val sk = maxOf(skin, e * 0.6f)
        val h = maxOf(heartIn, e * 0.55f)

        brainOut = lane(brainOn, thr, levelAmt, b)
        eyesOut = lane(eyesOn, thr, levelAmt, ey)
        earOut = lane(earOn, thr, levelAmt, er)
        noseAmb = lane(faceOn, thr, levelAmt, sk * 0.95f)
        mouthAmb = lane(faceOn, thr, levelAmt, sk * 0.92f)
        teethAmb = lane(faceOn, thr, levelAmt, sk * 0.90f)
        tongueAmb = lane(faceOn, thr, levelAmt, sk * 0.88f)
        faceSkinAmb = lane(faceOn, thr, levelAmt, sk)
        faceOut = maxOf(noseAmb, mouthAmb, teethAmb, tongueAmb, faceSkinAmb)
        neckOut = lane(neckOn, thr, levelAmt, sk * 0.93f)
        heartOut = lane(heartOn, thr, levelAmt, h)
        glandsOut = lane(glandsOn, thr, levelAmt, b * 0.9f)
        bodyPartsOut = lane(bodyPartsOn, thr, levelAmt, sk)

        // Respiratory 12
        nasalCavity = lane(respOn, thr, levelAmt, e * 0.94f)
        pharynx = lane(respOn, thr, levelAmt, e * 0.92f)
        larynx = lane(respOn, thr, levelAmt, e * 0.91f)
        trachea = lane(respOn, thr, levelAmt, e * 0.90f)
        bronchi = lane(respOn, thr, levelAmt, e * 0.89f)
        alveoli = lane(respOn, thr, levelAmt, e * 0.88f)
        lungL = lane(respOn, thr, levelAmt, e * 0.93f)
        lungR = lane(respOn, thr, levelAmt, e * 0.93f)
        pleura = lane(respOn, thr, levelAmt, e * 0.87f)
        diaphragm = lane(respOn, thr, levelAmt, e * 0.91f)
        intercostals = lane(respOn, thr, levelAmt, e * 0.86f)
        respOut = maxOf(nasalCavity, lungL, lungR, diaphragm, alveoli, intercostals, trachea, bronchi, pleura)

        // Cardiovascular 22 (core)
        ra = lane(cardioOn, thr, levelAmt, h * 0.95f)
        rv = lane(cardioOn, thr, levelAmt, h * 0.94f)
        la = lane(cardioOn, thr, levelAmt, h * 0.95f)
        lvChamber = lane(cardioOn, thr, levelAmt, h * 0.96f)
        valves = lane(cardioOn, thr, levelAmt, h * 0.92f)
        saNode = lane(cardioOn, thr, levelAmt, h * 0.90f)
        aorta = lane(cardioOn, thr, levelAmt, h * 0.93f)
        coronary = lane(cardioOn, thr, levelAmt, h * 0.91f)
        pericardium = lane(cardioOn, thr, levelAmt, h * 0.88f)
        avNode = lane(cardioOn, thr, levelAmt, h * 0.89f)
        venaCava = lane(cardioOn, thr, levelAmt, h * 0.90f)
        pulmonaryVessels = lane(cardioOn, thr, levelAmt, h * 0.90f)
        carotid = lane(cardioOn, thr, levelAmt, h * 0.87f)
        jugular = lane(cardioOn, thr, levelAmt, h * 0.86f)
        femoral = lane(cardioOn, thr, levelAmt, h * 0.85f)
        capillaries = lane(cardioOn, thr, levelAmt, h * 0.84f)
        cardioOut = maxOf(ra, rv, la, lvChamber, aorta, coronary, pericardium, saNode, avNode, venaCava, pulmonaryVessels)

        // Digestive 15 (core)
        oralCavity = lane(digestOn, thr, levelAmt, sk * 0.9f)
        esophagus = lane(digestOn, thr, levelAmt, e * 0.88f)
        stomach = lane(digestOn, thr, levelAmt, e * 0.90f)
        intestine = lane(digestOn, thr, levelAmt, e * 0.89f)
        liver = lane(digestOn, thr, levelAmt, e * 0.91f)
        pancreas = lane(digestOn, thr, levelAmt, e * 0.87f)
        gallbladder = lane(digestOn, thr, levelAmt, e * 0.86f)
        peritoneum = lane(digestOn, thr, levelAmt, e * 0.85f)
        analCanal = lane(digestOn, thr, levelAmt, e * 0.84f)
        digestOut = maxOf(oralCavity, stomach, liver, intestine, pancreas, gallbladder, esophagus, peritoneum)

        urinaryOut = lane(urinaryOn, thr, levelAmt, e * 0.85f)
        endoOut = lane(endoOn, thr, levelAmt, maxOf(b * 0.8f, glandsOut))
        lymphOut = lane(lymphOn, thr, levelAmt, e * 0.84f)
        skeletalOut = lane(skeletalOn, thr, levelAmt, sk * 0.92f)
        skullBone = lane(skeletalOn, thr, levelAmt, sk * 0.94f)
        femurBone = lane(skeletalOn, thr, levelAmt, sk * 0.91f)
        osteoblastAmb = lane(skeletalOn, thr, levelAmt, sk * 0.88f)
        osteoclastAmb = lane(skeletalOn, thr, levelAmt, sk * 0.86f)
        osteocyteAmb = lane(skeletalOn, thr, levelAmt, sk * 0.87f)
        skeletalOut = maxOf(skeletalOut, skullBone, femurBone, osteoblastAmb)
        muscleOut = lane(muscleOn, thr, levelAmt, sk * 0.90f)
        jointOut = lane(jointOn, thr, levelAmt, sk * 0.88f)
        pnsOut = lane(pnsOn, thr, levelAmt, maxOf(b * 0.7f, e * 0.8f))
        reproOut = lane(reproOn, thr, levelAmt, e * 0.75f)

        anatomyFullOut = maxOf(
            brainOut, eyesOut, earOut, faceOut, neckOut, heartOut, glandsOut, bodyPartsOut,
            respOut, cardioOut, digestOut, urinaryOut, endoOut, lymphOut,
            skeletalOut, muscleOut, jointOut, pnsOut, reproOut
        )

        status =
            "ANAT132 full=${(anatomyFullOut*100).toInt()}% · " +
            "brain/eye/ear/face=${(brainOut*100).toInt()}/${(eyesOut*100).toInt()}/${(earOut*100).toInt()}/${(faceOut*100).toInt()} · " +
            "resp/CV/GI=${(respOut*100).toInt()}/${(cardioOut*100).toInt()}/${(digestOut*100).toInt()} · " +
            "skel/mus/PNS=${(skeletalOut*100).toInt()}/${(muscleOut*100).toInt()}/${(pnsOut*100).toInt()} · " +
            "skull/femur/osteo=${(skullBone*100).toInt()}/${(femurBone*100).toInt()}/${(osteoblastAmb*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        try {
            v.bodyChemBrain.brainFullOut = maxOf(v.bodyChemBrain.brainFullOut, brainOut)
            v.eyesCompleteLock.eyesFullOut = maxOf(v.eyesCompleteLock.eyesFullOut, eyesOut)
            v.earAuditoryLine.earLineFull = maxOf(v.earAuditoryLine.earLineFull, earOut)
            v.allBodySkinAnatomy.faceFullSkin = maxOf(v.allBodySkinAnatomy.faceFullSkin, faceOut)
            v.allBodySkinAnatomy.noseSkin = maxOf(v.allBodySkinAnatomy.noseSkin, noseAmb)
            v.neck.atmosphere = maxOf(v.neck.atmosphere, neckOut)
            v.heart.atmosphere = maxOf(v.heart.atmosphere, heartOut, cardioOut * 0.5f)
            v.bioSkinCell.glandsFullOut = maxOf(v.bioSkinCell.glandsFullOut, glandsOut, endoOut)
            v.fullAmbientMaster.ambientAll = maxOf(v.fullAmbientMaster.ambientAll, anatomyFullOut * 0.5f)
            v.completeAtomProtect.atomInsideOut = maxOf(v.completeAtomProtect.atomInsideOut, cardioOut, digestOut, respOut)
            v.skeletonWaterAstro.skeletonFull = maxOf(v.skeletonWaterAstro.skeletonFull, skeletalOut, skullBone, femurBone)
            try {
                v.skeletonWaterAstro.skullOut = maxOf(v.skeletonWaterAstro.skullOut, skullBone)
                v.skeletonWaterAstro.femurOut = maxOf(v.skeletonWaterAstro.femurOut, femurBone)
                v.skeletonWaterAstro.osteoblast = maxOf(v.skeletonWaterAstro.osteoblast, osteoblastAmb)
                v.fullSkeletonBone.skeletonFull = maxOf(v.fullSkeletonBone.skeletonFull, skeletalOut)
                v.fullSkeletonBone.craniumOut = maxOf(v.fullSkeletonBone.craniumOut, skullBone)
            } catch (_: Throwable) {}
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, anatomyFullOut * 0.35f)
            if (v.anatomy3d.layerOn.size > 3) {
                v.anatomy3d.layerOn[3] = true
                v.anatomy3d.layerLevel[3] = maxOf(v.anatomy3d.layerLevel[3], cardioOut, respOut, digestOut)
            }
            if (v.anatomy3d.layerOn.size > 2) {
                v.anatomy3d.layerOn[2] = true
                v.anatomy3d.layerLevel[2] = maxOf(v.anatomy3d.layerLevel[2], skeletalOut)
            }
            v.finalProtectionMain.brainAnatOut = maxOf(v.finalProtectionMain.brainAnatOut, brainOut)
            v.finalProtectionMain.wholeBodyOut = maxOf(v.finalProtectionMain.wholeBodyOut, anatomyFullOut)
            v.finalProtectionMain.heartOut = maxOf(v.finalProtectionMain.heartOut, heartOut)
                    } catch (_: Throwable) {}
    }
}
