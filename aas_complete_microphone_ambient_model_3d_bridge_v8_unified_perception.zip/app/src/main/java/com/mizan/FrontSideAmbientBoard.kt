package com.mizan

/**
 * Eye front-side ambient + body front-side ambient.
 * Front-facing shell only (not back). Threshold · level · bipolar · RAW COMPLETE.
 */
class FrontSideAmbientBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Eye front side (L/R cornea / sclera front plane)
    @Volatile var eyeFrontOn = true
    @Volatile var eyeFrontThr = 0.28f
    @Volatile var eyeFrontLv = 0.75f
    @Volatile var eyeFrontL = 0f
    @Volatile var eyeFrontR = 0f
    @Volatile var eyeFrontOut = 0f
    @Volatile var eyeFrontBipolarOn = true
    @Volatile var eyeFrontBipNeg = -60f
    @Volatile var eyeFrontBipPos = 60f

    // Body front side (chest / abdomen / face plane)
    @Volatile var bodyFrontOn = true
    @Volatile var bodyFrontThr = 0.28f
    @Volatile var bodyFrontLv = 0.75f
    @Volatile var bodyFrontOut = 0f
    @Volatile var bodyFrontBipolarOn = true
    @Volatile var bodyFrontBipNeg = -60f
    @Volatile var bodyFrontBipPos = 60f

    // Body back side
    @Volatile var bodyBackOn = true
    @Volatile var bodyBackThr = 0.28f
    @Volatile var bodyBackLv = 0.75f
    @Volatile var bodyBackOut = 0f
    @Volatile var bodyBackBipolarOn = true
    @Volatile var bodyBackBipNeg = -60f
    @Volatile var bodyBackBipPos = 60f

    // Body left / right 3D sides
    @Volatile var bodyLeftOn = true
    @Volatile var bodyLeftThr = 0.28f
    @Volatile var bodyLeftLv = 0.75f
    @Volatile var bodyLeftOut = 0f
    @Volatile var bodyRightOn = true
    @Volatile var bodyRightThr = 0.28f
    @Volatile var bodyRightLv = 0.75f
    @Volatile var bodyRightOut = 0f
    @Volatile var bodySideBipolarOn = true
    @Volatile var bodySideBipNeg = -60f
    @Volatile var bodySideBipPos = 60f

    // Body up (head · neck · upper chest) / down (hips · legs · feet)
    @Volatile var bodyUpOn = true
    @Volatile var bodyUpThr = 0.28f
    @Volatile var bodyUpLv = 0.75f
    @Volatile var bodyUpOut = 0f
    @Volatile var bodyDownOn = true
    @Volatile var bodyDownThr = 0.28f
    @Volatile var bodyDownLv = 0.75f
    @Volatile var bodyDownOut = 0f
    @Volatile var bodyUpDownBipolarOn = true
    @Volatile var bodyUpDownBipNeg = -60f
    @Volatile var bodyUpDownBipPos = 60f

    // Eye back (posterior) optional
    @Volatile var eyeBackOn = true
    @Volatile var eyeBackThr = 0.28f
    @Volatile var eyeBackLv = 0.70f
    @Volatile var eyeBackL = 0f
    @Volatile var eyeBackR = 0f
    @Volatile var eyeBackOut = 0f

    @Volatile var status = "FRONT ambient idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    private fun bip(on: Boolean, neg: Float, pos: Float, e: Float): Float {
        if (!on) return e
        val span = (pos.coerceIn(0f, 120f) - neg.coerceIn(-120f, 0f)).coerceAtLeast(1f)
        val mid = (neg + pos) * 0.5f
        val db = neg + e * span
        return (((db - mid) / (span * 0.5f)).coerceIn(-1f, 1f) * 0.5f + 0.5f).coerceIn(0f, 1f)
    }

    fun tick(mic: Float, eyeL: Float = 0f, eyeR: Float = 0f, bodyFrontEnergy: Float = 0f) {
        if (!enabled) {
            status = "FRONT ambient OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val eL = maxOf(e, eyeL).coerceIn(0f, 1f)
        val eR = maxOf(e, eyeR).coerceIn(0f, 1f)
        val eB = maxOf(e, bodyFrontEnergy).coerceIn(0f, 1f)

        eyeFrontL = lane(eyeFrontOn, eyeFrontThr, eyeFrontLv, eL)
        eyeFrontR = lane(eyeFrontOn, eyeFrontThr, eyeFrontLv, eR)
        if (eyeFrontBipolarOn) {
            eyeFrontL = bip(true, eyeFrontBipNeg, eyeFrontBipPos, eyeFrontL)
            eyeFrontR = bip(true, eyeFrontBipNeg, eyeFrontBipPos, eyeFrontR)
        }
        eyeFrontOut = maxOf(eyeFrontL, eyeFrontR)

        bodyFrontOut = lane(bodyFrontOn, bodyFrontThr, bodyFrontLv, eB)
        if (bodyFrontBipolarOn) {
            bodyFrontOut = bip(true, bodyFrontBipNeg, bodyFrontBipPos, bodyFrontOut)
        }

        bodyBackOut = lane(bodyBackOn, bodyBackThr, bodyBackLv, eB)
        if (bodyBackBipolarOn) bodyBackOut = bip(true, bodyBackBipNeg, bodyBackBipPos, bodyBackOut)

        bodyLeftOut = lane(bodyLeftOn, bodyLeftThr, bodyLeftLv, eB * 0.98f)
        bodyRightOut = lane(bodyRightOn, bodyRightThr, bodyRightLv, eB * 0.98f)
        if (bodySideBipolarOn) {
            bodyLeftOut = bip(true, bodySideBipNeg, bodySideBipPos, bodyLeftOut)
            bodyRightOut = bip(true, bodySideBipNeg, bodySideBipPos, bodyRightOut)
        }

        eyeBackL = lane(eyeBackOn, eyeBackThr, eyeBackLv, eL * 0.9f)
        eyeBackR = lane(eyeBackOn, eyeBackThr, eyeBackLv, eR * 0.9f)
        eyeBackOut = maxOf(eyeBackL, eyeBackR)

        bodyUpOut = lane(bodyUpOn, bodyUpThr, bodyUpLv, eB * 1.02f)
        bodyDownOut = lane(bodyDownOn, bodyDownThr, bodyDownLv, eB * 0.96f)
        if (bodyUpDownBipolarOn) {
            bodyUpOut = bip(true, bodyUpDownBipNeg, bodyUpDownBipPos, bodyUpOut)
            bodyDownOut = bip(true, bodyUpDownBipNeg, bodyUpDownBipPos, bodyDownOut)
        }

        status =
            "EYE F L/R=${(eyeFrontL*100).toInt()}/${(eyeFrontR*100).toInt()} B=${(eyeBackOut*100).toInt()}% · " +
            "BODY F=${(bodyFrontOut*100).toInt()} Bk=${(bodyBackOut*100).toInt()} " +
            "L=${(bodyLeftOut*100).toInt()} R=${(bodyRightOut*100).toInt()} " +
            "Up=${(bodyUpOut*100).toInt()} Dn=${(bodyDownOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun headFrontBoost(front: Float, up: Float, down: Float, left: Float, right: Float) {
        bodyUpOut = maxOf(bodyUpOut, up)
        bodyDownOut = maxOf(bodyDownOut, down)
        bodyLeftOut = maxOf(bodyLeftOut, left)
        bodyRightOut = maxOf(bodyRightOut, right)
        bodyFrontOut = maxOf(bodyFrontOut, front)
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        // Eyes front
        try {
            v.eyes.atmosphere = maxOf(v.eyes.atmosphere, eyeFrontOut)
            v.eyeL.atmosphere = maxOf(v.eyeL.atmosphere, eyeFrontL)
            v.eyeR.atmosphere = maxOf(v.eyeR.atmosphere, eyeFrontR)
        } catch (_: Throwable) {}
        // Body front regions
        try {
            v.face.atmosphere = maxOf(v.face.atmosphere, bodyFrontOut * 0.95f)
            v.forehead.atmosphere = maxOf(v.forehead.atmosphere, bodyFrontOut * 0.90f)
            v.heart.atmosphere = maxOf(v.heart.atmosphere, bodyFrontOut * 0.85f)
            v.belly.atmosphere = maxOf(v.belly.atmosphere, bodyFrontOut * 0.88f)
            v.neck.atmosphere = maxOf(v.neck.atmosphere, bodyFrontOut * 0.80f)
        } catch (_: Throwable) {}
        try {
            v.anatomy3d.outside.level = maxOf(v.anatomy3d.outside.level, bodyFrontOut)
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, maxOf(bodyFrontOut, eyeFrontOut))
        } catch (_: Throwable) {}
        try {
            v.skinAtomspare.skinOutsideOut = maxOf(v.skinAtomspare.skinOutsideOut, bodyFrontOut, bodyBackOut, bodyLeftOut, bodyRightOut)
            v.skinAtomspare.epidermisOut = maxOf(v.skinAtomspare.epidermisOut, bodyFrontOut)
        } catch (_: Throwable) {}
        // Back
        try {
            v.skinBack.atmosphere = maxOf(v.skinBack.atmosphere, bodyBackOut)
        } catch (_: Throwable) {}
        // Left / right limbs & sides
        try {
            v.skinArmL.atmosphere = maxOf(v.skinArmL.atmosphere, bodyLeftOut)
            v.skinLegL.atmosphere = maxOf(v.skinLegL.atmosphere, bodyLeftOut)
            v.handL.atmosphere = maxOf(v.handL.atmosphere, bodyLeftOut * 0.9f)
            v.skinArmR.atmosphere = maxOf(v.skinArmR.atmosphere, bodyRightOut)
            v.skinLegR.atmosphere = maxOf(v.skinLegR.atmosphere, bodyRightOut)
            v.handR.atmosphere = maxOf(v.handR.atmosphere, bodyRightOut * 0.9f)
        } catch (_: Throwable) {}
        try {
            v.anatomy3d.outside.level = maxOf(v.anatomy3d.outside.level, bodyFrontOut, bodyBackOut, bodyLeftOut, bodyRightOut)
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, bodyFrontOut, bodyBackOut, bodyLeftOut, bodyRightOut, bodyUpOut, bodyDownOut, eyeFrontOut, eyeBackOut)
        } catch (_: Throwable) {}
        try {
            // Up: head · neck · chest
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, bodyUpOut)
            v.neck.atmosphere = maxOf(v.neck.atmosphere, bodyUpOut * 0.95f)
            v.forehead.atmosphere = maxOf(v.forehead.atmosphere, bodyUpOut * 0.9f)
            v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, bodyUpOut * 0.88f)
            // Down: abdomen · hips · legs · feet
            v.skinAbdomen.atmosphere = maxOf(v.skinAbdomen.atmosphere, bodyDownOut * 0.9f)
            v.belly.atmosphere = maxOf(v.belly.atmosphere, bodyDownOut * 0.92f)
            v.skinLegL.atmosphere = maxOf(v.skinLegL.atmosphere, bodyDownOut)
            v.skinLegR.atmosphere = maxOf(v.skinLegR.atmosphere, bodyDownOut)
            v.skinFootL.atmosphere = maxOf(v.skinFootL.atmosphere, bodyDownOut * 0.95f)
            v.skinFootR.atmosphere = maxOf(v.skinFootR.atmosphere, bodyDownOut * 0.95f)
        } catch (_: Throwable) {}

                // Eye back feeds posterior eye ambient
        try {
            v.eyeL.atmosphere = maxOf(v.eyeL.atmosphere, eyeFrontL, eyeBackL * 0.85f)
            v.eyeR.atmosphere = maxOf(v.eyeR.atmosphere, eyeFrontR, eyeBackR * 0.85f)
        } catch (_: Throwable) {}
    }
}
