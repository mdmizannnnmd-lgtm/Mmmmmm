package com.mizan

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Multi-board movement router for the animated model.
 *
 * Boards only transform microphone, camera and device-motion measurements into
 * visual animation parameters. RAW means unsmoothed input; it never changes the
 * video-feedback gain ceiling or the audio flash limiter.
 */
class VirtualMovementControlBoard {

    companion object {
        const val DRIVE_MIC_CENTROID = 0
        const val DRIVE_DEVICE_MOTION = 1
        const val DRIVE_CAMERA_MOTION = 2
        const val DRIVE_MANUAL = 3

        const val AXIS_ATOM_SPEED = 0
        const val AXIS_WARP_FACTOR = 1
        const val AXIS_MODEL_X = 2
        const val AXIS_MODEL_Y = 3
        const val AXIS_ROTATION = 4
        const val AXIS_HOVER = 5
        const val DIRECTION_HORIZONTAL = 0
        const val DIRECTION_VERTICAL = 1
        const val DIRECTION_CIRCULAR = 2
        const val DIRECTION_RANDOM = 3
        const val EASE_LINEAR = 0
        const val EASE_IN = 1
        const val EASE_OUT = 2
        const val EASE_IN_OUT = 3

        val DRIVE_NAMES = arrayOf("Mic → Centroid", "Device Motion", "Camera Motion", "Manual")
        val AXIS_NAMES = arrayOf("Atom Speed", "Warp Factor", "Model X", "Model Y", "Rotation", "Hover")
        val DIRECTION_NAMES = arrayOf("Horizontal", "Vertical", "Circular", "Random")
        val EASING_NAMES = arrayOf("Linear", "Ease In", "Ease Out", "Ease In-Out")
    }

    class Board(val id: Int) {
        @Volatile var enabled = true
        @Volatile var driveMode = DRIVE_MIC_CENTROID
        @Volatile var xAxis = AXIS_ATOM_SPEED
        @Volatile var yAxis = AXIS_WARP_FACTOR
        @Volatile var smoothing = 0.12f
        @Volatile var xRange = 100f
        @Volatile var yRange = 2f
        @Volatile var raw = false
        @Volatile var manualX = 0.5f
        @Volatile var manualY = 0.5f
        @Volatile var liveX = 0.5f
        @Volatile var liveY = 0.5f
    }

    data class Inputs(
        val micRms: Float = 0f,
        val centroid: Float = 0.5f,
        val deviceMove: Float = 0f,
        val deviceSpeed: Float = 0f,
        val cameraMove: Float = 0f,
        val cameraWave: Float = 0f,
        val timeSeconds: Float = 0f
    )

    data class Output(
        val atomSpeed: Float = 1f,
        val warpFactor: Float = 0f,
        val modelX: Float = 0f,
        val modelY: Float = 0f,
        val rotation: Float = 0f,
        val hoverSpeed: Float = 1f
    )

    @Volatile var enabled = false
    @Volatile var ambientLink = true
    @Volatile var resonance = 0f
    @Volatile var inertia = 0.20f
    @Volatile var phaseSync = false
    @Volatile var stutterGate = false
    @Volatile var virtualOverdrive = false
    @Volatile var movementDirection = DIRECTION_HORIZONTAL
    @Volatile var easing = EASE_LINEAR
    @Volatile var movementSpeed = 1f
    @Volatile var manualAtomSpeed = 1f
    @Volatile var manualWarpFactor = 0f
    @Volatile var manualHoverSpeed = 1f

    private val lock = Any()
    private val boards = mutableListOf(Board(1), Board(2), Board(3))
    private var nextId = 4
    @Volatile var output = Output()
        private set

    fun boardsSnapshot(): List<Board> = synchronized(lock) { boards.toList() }

    fun addBoard(): Board? = synchronized(lock) {
        if (boards.size >= 8) return null
        Board(nextId++).also { boards.add(it) }
    }

    fun removeBoard(id: Int): Boolean = synchronized(lock) {
        if (boards.size <= 1) return false
        boards.removeAll { it.id == id }
    }

    fun tick(inputs: Inputs): Output {
        if (!enabled) {
            val path = movementPath(inputs.timeSeconds)
            output = Output(
                atomSpeed = manualAtomSpeed.coerceIn(0f, 100f),
                warpFactor = manualWarpFactor.coerceIn(0f, 2f),
                modelX = path.first,
                modelY = path.second,
                hoverSpeed = manualHoverSpeed.coerceIn(0f, 8f)
            )
            return output
        }

        val speedValues = mutableListOf<Float>()
        val warpValues = mutableListOf<Float>()
        val xValues = mutableListOf<Float>()
        val yValues = mutableListOf<Float>()
        val rotationValues = mutableListOf<Float>()
        val hoverValues = mutableListOf<Float>()

        for (board in boardsSnapshot()) {
            if (!board.enabled) continue
            val (targetX, targetY) = source(board, inputs)
            val smoothing = board.smoothing.coerceIn(0f, 0.95f)
            val alpha = if (board.raw) 1f else
                ((0.04f + (1f - smoothing) * 0.30f) * (1f - inertia.coerceIn(0f, 1f) * 0.5f))
                    .coerceIn(0.02f, 0.34f)
            board.liveX += (targetX - board.liveX) * alpha
            board.liveY += (targetY - board.liveY) * alpha
            val x = ease(board.liveX.coerceIn(0f, 1f))
            val y = ease(board.liveY.coerceIn(0f, 1f))

            fun collect(axis: Int, signal: Float, range: Float, isY: Boolean) {
                when (axis) {
                    AXIS_ATOM_SPEED -> speedValues += (signal * range.coerceIn(0f, 100f))
                    AXIS_WARP_FACTOR -> warpValues += (signal * range.coerceIn(0f, 2f))
                    AXIS_MODEL_X -> xValues += ((signal - 0.5f) * (range.coerceIn(0f, 100f) / 100f))
                    AXIS_MODEL_Y -> yValues += ((signal - 0.5f) * (range.coerceIn(0f, 100f) / 100f))
                    AXIS_ROTATION -> rotationValues += ((signal - 0.5f) * range.coerceIn(0f, 100f) / 100f * PI.toFloat())
                    AXIS_HOVER -> hoverValues += (signal * range.coerceIn(0f, 8f))
                }
            }
            collect(board.xAxis, x, board.xRange, false)
            collect(board.yAxis, y, board.yRange, true)
        }

        fun mean(values: List<Float>, fallback: Float): Float =
            if (values.isEmpty()) fallback else values.average().toFloat()

        var speed = mean(speedValues, manualAtomSpeed).coerceIn(0f, 100f)
        if (stutterGate && speed < 2f) speed = 0f
        if (virtualOverdrive) speed = (speed * 1.5f).coerceIn(0f, 100f)
        if (phaseSync && speed > 0f) speed = (kotlin.math.round(speed * 4f) / 4f).coerceIn(0f, 100f)

        val resonanceOffset = (resonance.coerceIn(0f, 1f) * 0.10f)
        var modelX = mean(xValues, 0f) * movementSpeed.coerceIn(0f, 2f)
        var modelY = mean(yValues, 0f) * movementSpeed.coerceIn(0f, 2f)
        when (movementDirection.coerceIn(DIRECTION_HORIZONTAL, DIRECTION_RANDOM)) {
            DIRECTION_HORIZONTAL -> modelY = 0f
            DIRECTION_VERTICAL -> modelX = 0f
            DIRECTION_CIRCULAR -> {
                val radius = (kotlin.math.sqrt(modelX * modelX + modelY * modelY) * 0.707f).coerceIn(0f, 1f)
                val angle = inputs.centroid.coerceIn(0f, 1f) * 2f * PI.toFloat()
                modelX = kotlin.math.cos(angle) * radius
                modelY = kotlin.math.sin(angle) * radius
            }
            DIRECTION_RANDOM -> Unit // live sensor variation supplies the changing direction
        }
        val path = movementPath(inputs.timeSeconds)
        output = Output(
            atomSpeed = speed,
            warpFactor = (mean(warpValues, manualWarpFactor) + resonanceOffset).coerceIn(0f, 2f),
            modelX = (modelX + path.first).coerceIn(-1f, 1f),
            modelY = (modelY + path.second).coerceIn(-1f, 1f),
            rotation = mean(rotationValues, 0f).coerceIn(-PI.toFloat(), PI.toFloat()),
            hoverSpeed = mean(hoverValues, manualHoverSpeed).coerceIn(0f, 8f)
        )
        return output
    }

    private fun source(board: Board, inputs: Inputs): Pair<Float, Float> = when (board.driveMode) {
        DRIVE_DEVICE_MOTION -> inputs.deviceMove.coerceIn(0f, 1f) to
            (inputs.deviceSpeed / 4f).coerceIn(0f, 1f)
        DRIVE_CAMERA_MOTION -> inputs.cameraMove.coerceIn(0f, 1f) to inputs.cameraWave.coerceIn(0f, 1f)
        DRIVE_MANUAL -> board.manualX.coerceIn(0f, 1f) to board.manualY.coerceIn(0f, 1f)
        else -> if (ambientLink) {
            inputs.micRms.coerceIn(0f, 1f) to inputs.centroid.coerceIn(0f, 1f)
        } else 0f to 0f
    }

    private fun ease(value: Float): Float = when (easing.coerceIn(EASE_LINEAR, EASE_IN_OUT)) {
        EASE_IN -> value * value
        EASE_OUT -> 1f - (1f - value) * (1f - value)
        EASE_IN_OUT -> if (value < 0.5f) 2f * value * value
            else 1f - (-2f * value + 2f) * (-2f * value + 2f) / 2f
        else -> value
    }

    private fun movementPath(timeSeconds: Float): Pair<Float, Float> {
        val t = timeSeconds.coerceAtLeast(0f) * movementSpeed.coerceIn(0.1f, 2f) * 1.2f
        val a = (ease(((sin(t) + 1f) * 0.5f).coerceIn(0f, 1f)) * 2f - 1f) * 0.08f
        val b = (ease(((sin(t * 0.73f + 1.4f) + 1f) * 0.5f).coerceIn(0f, 1f)) * 2f - 1f) * 0.08f
        return when (movementDirection.coerceIn(DIRECTION_HORIZONTAL, DIRECTION_RANDOM)) {
            DIRECTION_VERTICAL -> 0f to a
            DIRECTION_CIRCULAR -> (cos(t) * 0.08f) to (sin(t) * 0.08f)
            DIRECTION_RANDOM -> a to b
            else -> a to 0f
        }
    }
    fun apply(v: VisualShieldView?) { /* movement control state */ }

}
