package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object CameraExclusiveGuardPanels {
    fun build(ctx: Context, root: LinearLayout, b: CameraExclusiveGuardBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFFCC80.toInt()
        p.title("CAMERA EXCLUSIVE GUARD · ANTI-STUCK", c)
        p.note("Online: one camera client · release Surface · pause ARCore on background · free before switch")
        p.switch("Guard ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Auto-release legacy before AR", b.autoReleaseLegacyBeforeAr) { b.autoReleaseLegacyBeforeAr = it }
        p.switch("Auto-pause AR on background", b.autoPauseArOnBackground) { b.autoPauseArOnBackground = it }
        val st = p.status("CAM-GUARD —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 400) }
        })
    }
}
