package com.mizan

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

/** Controls for [InsideWarpRot]: inside WARP and inside ROTATION of the 3D anatomy body, driven by centroid · vertical. */
object AnatomyInsidePanels {
    private const val P = "inwr_"

    fun build(ctx: Context, root: LinearLayout, f: InsideWarpRot) {
        val p = PanelBuilder(ctx, root)
        val gold = Color.rgb(0xFF, 0xB7, 0x4D)
        val teal = Color.rgb(0x80, 0xCB, 0xC4)
        val violet = Color.rgb(0xCE, 0x93, 0xD8)

        f.rawComplete = MemoryPaths.getBool(P + "raw_all", f.rawComplete)
        f.warpOn = MemoryPaths.getBool(P + "warp_on", f.warpOn)
        f.warpAmt = MemoryPaths.getFloat(P + "warp_amt", f.warpAmt)
        f.ripple = MemoryPaths.getFloat(P + "ripple", f.ripple)
        f.rotOn = MemoryPaths.getBool(P + "rot_on", f.rotOn)
        f.rotRange = MemoryPaths.getFloat(P + "rot_range", f.rotRange)
        f.rotSpeed = MemoryPaths.getFloat(P + "rot_speed", f.rotSpeed)
        for (c in f.all) {
            c.on = MemoryPaths.getBool(P + c.key + "_on", c.on)
            c.lv = MemoryPaths.getFloat(P + c.key + "_lv", c.lv)
            c.thr = MemoryPaths.getFloat(P + c.key + "_thr", c.thr)
            c.raw = MemoryPaths.getBool(P + c.key + "_raw", c.raw)
        }

        p.title("3D ANATOMY · INSIDE WARP + INSIDE ROTATION · CENTROID · VERTICAL", gold)
        p.note("The INSIDE of the body (skeleton · organs · vessels · brain) warps and turns on its own while the skin, muscle and face stay put. Centroid (the sound's brightness) leans / turns it, vertical (body height) stretches / spins it. Threshold is the neutral point: above it the drive pushes one way, below it the other. RAW COMPLETE sends the live centroid and vertical straight through — no level, no threshold. Applies to the anatomy layers, not to the rings.")
        p.switch("RAW COMPLETE — inside warp + rotation", f.rawComplete) { f.rawComplete = it; MemoryPaths.putBool(P + "raw_all", it) }

        fun channel(title: String, c: ScreenEchoMic.Ch, color: Int) {
            p.title(title, color)
            p.switch("$title ON", c.on) { c.on = it; MemoryPaths.putBool(P + c.key + "_on", it) }
            p.seek("Level", 0f, 1.5f, c.lv) { c.lv = it; MemoryPaths.putFloat(P + c.key + "_lv", it) }
            p.seek("Threshold (neutral point)", 0f, 0.98f, c.thr) { c.thr = it; MemoryPaths.putFloat(P + c.key + "_thr", it) }
            p.switch("$title RAW", c.raw) { c.raw = it; MemoryPaths.putBool(P + c.key + "_raw", it) }
        }

        p.title("INSIDE WARP", teal)
        p.switch("Inside warp ON", f.warpOn) { f.warpOn = it; MemoryPaths.putBool(P + "warp_on", it) }
        p.seek("Warp amount", 0f, 2f, f.warpAmt) { f.warpAmt = it; MemoryPaths.putFloat(P + "warp_amt", it) }
        p.seek("Warp ripple up the body", 0f, 1f, f.ripple) { f.ripple = it; MemoryPaths.putFloat(P + "ripple", it) }
        channel("WARP · CENTROID (lean / bend)", f.warpCen, teal)
        channel("WARP · VERTICAL (stretch / squash)", f.warpVer, teal)

        p.title("INSIDE ROTATION", violet)
        p.switch("Inside rotation ON", f.rotOn) { f.rotOn = it; MemoryPaths.putBool(P + "rot_on", it) }
        p.seek("Rotation range (rad)", 0f, 3.14f, f.rotRange) { f.rotRange = it; MemoryPaths.putFloat(P + "rot_range", it) }
        p.seek("Spin speed at full vertical (rad/s)", 0f, 6f, f.rotSpeed) { f.rotSpeed = it; MemoryPaths.putFloat(P + "rot_speed", it) }
        channel("ROTATION · CENTROID (angle)", f.rotCen, violet)
        channel("ROTATION · VERTICAL (spin)", f.rotVer, violet)

        val st = p.status("INSIDE WARP —", teal)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = f.statusLine(); h.postDelayed(this, 250) }
        })
    }
}
