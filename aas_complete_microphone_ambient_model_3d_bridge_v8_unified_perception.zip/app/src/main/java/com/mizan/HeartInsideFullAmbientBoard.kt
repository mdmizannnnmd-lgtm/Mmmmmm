package com.mizan

/**
 * Full heart anatomy ambient (diagram + clinical gaps filled).
 * Chambers · valves · vessels · nodes · layers · septum · papillary · chordae.
 * Level + bipolar-style thr · 3D organ layer feed. Symbolic only. RAW COMPLETE.
 */
class HeartInsideFullAmbientBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.28f
    @Volatile var levelAmt = 0.92f

    // Chambers (diagram)
    @Volatile var rightAtrium = 0f
    @Volatile var rightVentricle = 0f
    @Volatile var leftAtrium = 0f
    @Volatile var leftVentricle = 0f
    // Valves (diagram)
    @Volatile var tricuspid = 0f
    @Volatile var pulmonaryValve = 0f
    @Volatile var mitralBicuspid = 0f
    @Volatile var aorticValve = 0f
    // Great vessels
    @Volatile var aorta = 0f
    @Volatile var pulmonaryTrunk = 0f
    @Volatile var superiorVenaCava = 0f
    @Volatile var inferiorVenaCava = 0f
    @Volatile var pulmonaryVeins = 0f
    // Septum / internal
    @Volatile var ventricularSeptum = 0f
    @Volatile var atrialSeptum = 0f
    @Volatile var chordaeTendineae = 0f
    @Volatile var papillaryMuscles = 0f
    // Layers
    @Volatile var endocardium = 0f
    @Volatile var myocardium = 0f
    @Volatile var epicardium = 0f
    @Volatile var pericardium = 0f
    // Conduction
    @Volatile var saNode = 0f
    @Volatile var avNode = 0f
    @Volatile var bundleOfHis = 0f
    @Volatile var purkinje = 0f
    // Coronary
    @Volatile var coronaryArteries = 0f
    @Volatile var coronaryVeins = 0f

    @Volatile var heartFullOut = 0f
    @Volatile var status = "HEART-INSIDE idle"

    private fun lane(on: Boolean, t: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * lv).coerceIn(0f, 1f)
        return if (x >= t) ((x - t) / (1.2f - t).coerceAtLeast(0.05f) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, heartIn: Float, cardio: Float) {
        if (!enabled) { status = "HEART-INSIDE OFF"; return }
        val e = maxOf(mic, heartIn, cardio * 0.8f).coerceIn(0f, 1.5f)
        val h = maxOf(heartIn, e * 0.9f)
        rightAtrium = lane(true, thr, levelAmt, h * 0.95f)
        rightVentricle = lane(true, thr, levelAmt, h * 0.94f)
        leftAtrium = lane(true, thr, levelAmt, h * 0.95f)
        leftVentricle = lane(true, thr, levelAmt, h * 0.97f)
        tricuspid = lane(true, thr, levelAmt, h * 0.92f)
        pulmonaryValve = lane(true, thr, levelAmt, h * 0.91f)
        mitralBicuspid = lane(true, thr, levelAmt, h * 0.93f)
        aorticValve = lane(true, thr, levelAmt, h * 0.93f)
        aorta = lane(true, thr, levelAmt, h * 0.94f)
        pulmonaryTrunk = lane(true, thr, levelAmt, h * 0.90f)
        superiorVenaCava = lane(true, thr, levelAmt, h * 0.89f)
        inferiorVenaCava = lane(true, thr, levelAmt, h * 0.88f)
        pulmonaryVeins = lane(true, thr, levelAmt, h * 0.87f)
        ventricularSeptum = lane(true, thr, levelAmt, h * 0.90f)
        atrialSeptum = lane(true, thr, levelAmt, h * 0.86f)
        chordaeTendineae = lane(true, thr, levelAmt, h * 0.85f)
        papillaryMuscles = lane(true, thr, levelAmt, h * 0.86f)
        endocardium = lane(true, thr, levelAmt, h * 0.88f)
        myocardium = lane(true, thr, levelAmt, h * 0.96f)
        epicardium = lane(true, thr, levelAmt, h * 0.87f)
        pericardium = lane(true, thr, levelAmt, h * 0.89f)
        saNode = lane(true, thr, levelAmt, h * 0.91f)
        avNode = lane(true, thr, levelAmt, h * 0.90f)
        bundleOfHis = lane(true, thr, levelAmt, h * 0.84f)
        purkinje = lane(true, thr, levelAmt, h * 0.83f)
        coronaryArteries = lane(true, thr, levelAmt, h * 0.92f)
        coronaryVeins = lane(true, thr, levelAmt, h * 0.85f)
        heartFullOut = maxOf(
            rightAtrium, rightVentricle, leftAtrium, leftVentricle,
            tricuspid, pulmonaryValve, mitralBicuspid, aorticValve,
            aorta, myocardium, pericardium, saNode, coronaryArteries
        )
        if (rawComplete) heartFullOut = maxOf(heartFullOut, 0.35f + h * 0.4f)
        status = "HEART-INSIDE full=${(heartFullOut*100).toInt()}% · " +
            "RA/RV/LA/LV=${(rightAtrium*100).toInt()}/${(rightVentricle*100).toInt()}/${(leftAtrium*100).toInt()}/${(leftVentricle*100).toInt()} · " +
            "valves T/P/M/A=${(tricuspid*100).toInt()}/${(pulmonaryValve*100).toInt()}/${(mitralBicuspid*100).toInt()}/${(aorticValve*100).toInt()}" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView?) {
        if (!enabled || heartFullOut < 0.02f) return
        val vv = v ?: return
        try {
            vv.heart.atmosphere = maxOf(vv.heart.atmosphere, heartFullOut)
            vv.fullAnatomy132.heartOut = maxOf(vv.fullAnatomy132.heartOut, heartFullOut)
            vv.fullAnatomy132.cardioOut = maxOf(vv.fullAnatomy132.cardioOut, heartFullOut * 0.9f)
            vv.anatomy3d.layerLevel[3] = maxOf(vv.anatomy3d.layerLevel[3], heartFullOut)
            vv.finalProtectionMain.heartOut = maxOf(vv.finalProtectionMain.heartOut, heartFullOut)
            vv.cnsEyesHeart.heartOut = maxOf(vv.cnsEyesHeart.heartOut, heartFullOut * 0.85f)
        } catch (_: Throwable) {}
    }
}
