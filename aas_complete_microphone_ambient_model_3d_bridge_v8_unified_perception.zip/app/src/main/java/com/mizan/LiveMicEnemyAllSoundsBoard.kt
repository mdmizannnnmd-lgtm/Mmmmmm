package com.mizan

/**
 * Live microphone ALL sounds threshold · enemies ALL sounds threshold ·
 * anti sound our own · enemy SFX (knife/bullet/more) · pitch sounds ·
 * body region ALL parts. RAW COMPLETE.
 */
class LiveMicEnemyAllSoundsBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Live mic — all sounds
    @Volatile var liveMicAllOn = true
    @Volatile var liveMicAllThr = 0.22f
    @Volatile var liveMicAllLv = 0.85f
    @Volatile var liveMicAllOut = 0f
    @Volatile var liveMicAllAutoThr = true

    // Enemies — all sounds
    @Volatile var enemyAllOn = true
    @Volatile var enemyAllThr = 0.25f
    @Volatile var enemyAllLv = 0.90f
    @Volatile var enemyAllOut = 0f
    @Volatile var enemyKnife = 0f
    @Volatile var enemyBullet = 0f
    @Volatile var enemyBurst = 0f
    @Volatile var enemySharp = 0f
    @Volatile var enemyMore = 0f  // any other enemy SFX

    // Anti sound our own (fixed path — protect/cancel our own leakage)
    @Volatile var antiOwnOn = true
    @Volatile var antiOwnThr = 0.28f
    @Volatile var antiOwnLv = 0.88f
    @Volatile var antiOwnOut = 0f

    // Pitch sounds
    @Volatile var pitchSoundsOn = true
    @Volatile var pitchSoundsThr = 0.25f
    @Volatile var pitchSoundsLv = 0.80f
    @Volatile var pitchSoundsOut = 0f
    @Volatile var pitchDb = -90f

    // Body region ALL parts protect from enemy all-sounds
    @Volatile var bodyAllPartsOn = true
    @Volatile var bodyAllPartsThr = 0.25f
    @Volatile var bodyAllPartsLv = 0.90f
    @Volatile var bodyAllPartsOut = 0f
    @Volatile var partHead = 0f
    @Volatile var partFace = 0f
    @Volatile var partNeck = 0f
    @Volatile var partChest = 0f
    @Volatile var partBelly = 0f
    @Volatile var partArmL = 0f; @Volatile var partArmR = 0f
    @Volatile var partHandL = 0f; @Volatile var partHandR = 0f
    @Volatile var partLegL = 0f; @Volatile var partLegR = 0f
    @Volatile var partFootL = 0f; @Volatile var partFootR = 0f
    @Volatile var partSpine = 0f
    @Volatile var partEyes = 0f

    @Volatile var status = "LIVE·ENEMY·ANTI·BODY idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        micE: Float,
        enemyBody: Float,
        micEnemy: Float,
        knife: Float,
        bullet: Float,
        burst: Float,
        sharp: Float,
        moreFx: Float,
        rmsDbfs: Float
    ) {
        if (!enabled) {
            status = "LIVE·ENEMY·ANTI·BODY OFF"
            return
        }
        val e = micE.coerceIn(0f, 1f)
        if (liveMicAllAutoThr) {
            liveMicAllThr = (0.10f + e * 0.20f).coerceIn(0.08f, 0.5f)
        }
        liveMicAllOut = lane(liveMicAllOn, liveMicAllThr, liveMicAllLv, e)

        enemyKnife = knife
        enemyBullet = bullet
        enemyBurst = burst
        enemySharp = sharp
        enemyMore = moreFx
        val enemySrc = maxOf(enemyBody, micEnemy, knife, bullet, burst, sharp, moreFx)
        enemyAllOut = lane(enemyAllOn, enemyAllThr, enemyAllLv, enemySrc)

        // Anti our own — when our live mic is high but we want self-cancel
        antiOwnOut = lane(antiOwnOn, antiOwnThr, antiOwnLv, liveMicAllOut)

        pitchDb = rmsDbfs.coerceIn(-120f, 0f)
        pitchSoundsOut = lane(pitchSoundsOn, pitchSoundsThr, pitchSoundsLv, e)

        val bodyThreat = maxOf(enemyAllOut, enemyKnife, enemyBullet, enemyBurst, enemySharp, enemyMore)
        bodyAllPartsOut = lane(bodyAllPartsOn, bodyAllPartsThr, bodyAllPartsLv, bodyThreat)
        val p = bodyAllPartsOut
        partHead = p; partFace = p * 0.98f; partNeck = p * 0.95f
        partChest = p * 0.96f; partBelly = p * 0.94f
        partArmL = p * 0.92f; partArmR = p * 0.92f
        partHandL = p * 0.90f; partHandR = p * 0.90f
        partLegL = p * 0.90f; partLegR = p * 0.90f
        partFootL = p * 0.88f; partFootR = p * 0.88f
        partSpine = p * 0.93f; partEyes = p * 0.97f

        status =
            "MIC-ALL=${(liveMicAllOut*100).toInt()}% autoT=${"%.2f".format(liveMicAllThr)} · " +
            "ENEMY-ALL=${(enemyAllOut*100).toInt()}% K=${(enemyKnife*100).toInt()} B=${(enemyBullet*100).toInt()} " +
            "Br=${(enemyBurst*100).toInt()} Sh=${(enemySharp*100).toInt()} +=${(enemyMore*100).toInt()} · " +
            "ANTI-OWN=${(antiOwnOut*100).toInt()}% PITCH=${(pitchSoundsOut*100).toInt()}% · " +
            "BODY-ALL=${(bodyAllPartsOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled) return
        // Enemy all-sounds damp
        if (enemyAllOut > 0.02f) {
            val k = (1f - enemyAllOut * 0.94f).coerceIn(0.02f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
            sb.knifeOut *= k
            sb.bulletOut *= k
            sb.burstOut *= (0.4f + 0.6f * k)
            sb.sharpOut *= (0.4f + 0.6f * k)
        }
        // Anti our own — soft gate on runaway self energy into enemy paths
        if (antiOwnOut > 0.02f) {
            // don't wipe mic; reduce false enemy attribution from our own loudness
            val k = (1f - antiOwnOut * 0.5f).coerceIn(0.3f, 1f)
            sb.micEnemyOut *= k
        }
        // Body all parts shield presence
        if (bodyAllPartsOut > 0.02f && v != null) {
            try {
                v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, partHead * 0.35f)
                v.face.atmosphere = maxOf(v.face.atmosphere, partFace * 0.35f)
                v.neck.atmosphere = maxOf(v.neck.atmosphere, partNeck * 0.35f)
                v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, partChest * 0.35f)
                v.belly.atmosphere = maxOf(v.belly.atmosphere, partBelly * 0.35f)
                v.skinArmL.atmosphere = maxOf(v.skinArmL.atmosphere, partArmL * 0.3f)
                v.skinArmR.atmosphere = maxOf(v.skinArmR.atmosphere, partArmR * 0.3f)
                v.handL.atmosphere = maxOf(v.handL.atmosphere, partHandL * 0.3f)
                v.handR.atmosphere = maxOf(v.handR.atmosphere, partHandR * 0.3f)
                v.skinLegL.atmosphere = maxOf(v.skinLegL.atmosphere, partLegL * 0.3f)
                v.skinLegR.atmosphere = maxOf(v.skinLegR.atmosphere, partLegR * 0.3f)
                v.eyeL.atmosphere = maxOf(v.eyeL.atmosphere, partEyes * 0.3f)
                v.eyeR.atmosphere = maxOf(v.eyeR.atmosphere, partEyes * 0.3f)
            } catch (_: Throwable) {}
        }
        // Wire to sharpBurstMeter anti if present
        val vv = v
        if (vv != null) {
            try {
                vv.sharpBurstMeter.antiBulletOut = maxOf(vv.sharpBurstMeter.antiBulletOut, enemyBullet * enemyAllOut)
                vv.sharpBurstMeter.antiKnifeOut = maxOf(vv.sharpBurstMeter.antiKnifeOut, enemyKnife * enemyAllOut)
            } catch (_: Throwable) {}
        }
    }
}
