package com.mizan

import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.exp

/**
 * AUDIO COLOUR board — the microphone drives the colour levels of the own-display video.
 *
 *  - COLOUR THRESHOLD   : audio level below [thr] (+ a per-channel offset) leaves the colour untouched.
 *  - AUDIO CONTRAST     : mid / low-mid energy above threshold adds video contrast.
 *  - AUDIO BRIGHTNESS   : overall RMS above threshold adds video brightness.
 *  - AUDIO COLOUR LEVEL : high / air energy above threshold adds colour level (saturation).
 *
 * The three outputs ([dContrast], [dBrightness], [dColour]) are *additive* offsets that
 * [VideoFeedbackBoard] adds on top of its own manual levels, so the manual sliders stay in charge
 * of the base look and the audio only adds movement.
 *
 * RAW COMPLETE ([rawComplete]) bypasses the threshold, the knee and the attack / release smoothing and
 * passes the complete, unsmoothed signal straight to the colour levels. The flash limiter
 * ([flashLimitOn], default ON) is a separate switch and is NOT turned off by raw mode: it caps how fast
 * the colour can swing (about 3 full swings per second) so that raw audio can't strobe the screen.
 *
 * Defaults: OFF, so nothing changes until you enable it.
 */
class AudioColourBoard {
    @Volatile var enabled = false
    @Volatile var rawComplete = true
    @Volatile var invert = false            // audio pulls levels DOWN instead of up
    @Volatile var flashLimitOn = true

    /** Input sensitivity multiplier (0..3). */
    @Volatile var sens = 1.0f
    /** Master colour threshold 0..1 of the normalised audio level. */
    @Volatile var thr = 0.10f
    /** Extra threshold per output, 0..0.5 — added to [thr]. */
    @Volatile var thrContrast = 0f
    @Volatile var thrBrightness = 0f
    @Volatile var thrLevel = 0f

    /** How far each output may move, 0..1 of its range. */
    @Volatile var contrastAmt = 0.30f
    @Volatile var brightnessAmt = 0.25f
    @Volatile var levelAmt = 0.40f

    @Volatile var attackMs = 40
    @Volatile var releaseMs = 250

    // ---- outputs (read by VideoFeedbackBoard) ----
    @Volatile var dContrast = 0f     // −CONTRAST_RANGE … +CONTRAST_RANGE
    @Volatile var dBrightness = 0f   // −BRIGHT_RANGE … +BRIGHT_RANGE
    @Volatile var dColour = 0f       // −COLOUR_RANGE … +COLOUR_RANGE

    // ---- live inputs / flags for the status line ----
    @Volatile var inLevel = 0f
    @Volatile var inMid = 0f
    @Volatile var inHigh = 0f
    @Volatile var gateContrast = false
    @Volatile var gateBrightness = false
    @Volatile var gateLevel = false

    private var envC = 0f
    private var envB = 0f
    private var envL = 0f
    private var outC = 0f
    private var outB = 0f
    private var outL = 0f
    private var lastMs = 0L

    /**
     * Called by AudioProcessor once per audio buffer.
     * [rms] is the amplified RMS (0..1); [bands] are the five normalised band envelopes
     * (bass, low-mid, mid, high, air) or null when no band analysis ran.
     */
    fun tick(rms: Float, bands: FloatArray?) {
        val now = SystemClock.elapsedRealtime()
        val dt = if (lastMs == 0L) 0.02f else ((now - lastMs) / 1000f).coerceIn(0.001f, 0.2f)
        lastMs = now

        if (!enabled) {
            envC = 0f; envB = 0f; envL = 0f
            outC = 0f; outB = 0f; outL = 0f
            dContrast = 0f; dBrightness = 0f; dColour = 0f
            gateContrast = false; gateBrightness = false; gateLevel = false
            return
        }

        val s = sens.coerceIn(0f, 3f)
        // RMS is small in practice (speech ≈ 0.02–0.2), so it is lifted a little; bands are already boosted.
        val level = (rms * 3f * s).coerceIn(0f, 1f)
        val mid = if (bands != null) (((bands[1] + bands[2]) * 0.5f) * s).coerceIn(0f, 1f) else level
        val high = if (bands != null) (((bands[3] + bands[4]) * 0.5f) * s).coerceIn(0f, 1f) else level
        inLevel = level; inMid = mid; inHigh = high

        val sign = if (invert) -1f else 1f
        val tC = shape(mid, thr + thrContrast)
        val tB = shape(level, thr + thrBrightness)
        val tL = shape(high, thr + thrLevel)
        gateContrast = tC > 0f
        gateBrightness = tB > 0f
        gateLevel = tL > 0f

        envC = follow(envC, tC, dt)
        envB = follow(envB, tB, dt)
        envL = follow(envL, tL, dt)

        val wantC = sign * envC * contrastAmt.coerceIn(0f, 1f) * CONTRAST_RANGE
        val wantB = sign * envB * brightnessAmt.coerceIn(0f, 1f) * BRIGHT_RANGE
        val wantL = sign * envL * levelAmt.coerceIn(0f, 1f) * COLOUR_RANGE

        if (flashLimitOn) {
            // A full swing of the range = 2 * range; allow ~3 full swings per second.
            outC = slew(outC, wantC, CONTRAST_RANGE * 6f * dt)
            outB = slew(outB, wantB, BRIGHT_RANGE * 6f * dt)
            outL = slew(outL, wantL, COLOUR_RANGE * 6f * dt)
        } else {
            outC = wantC; outB = wantB; outL = wantL
        }
        dContrast = outC.coerceIn(-CONTRAST_RANGE, CONTRAST_RANGE)
        dBrightness = outB.coerceIn(-BRIGHT_RANGE, BRIGHT_RANGE)
        dColour = outL.coerceIn(-COLOUR_RANGE, COLOUR_RANGE)
    }

    /** 0 below the threshold; above it the level is re-scaled to 0..1. RAW passes the level unchanged. */
    private fun shape(x: Float, threshold: Float): Float {
        if (rawComplete) return x.coerceIn(0f, 1f)
        val t = threshold.coerceIn(0f, 0.95f)
        if (x < t) return 0f
        return ((x - t) / (1f - t)).coerceIn(0f, 1f)
    }

    /** Attack / release one-pole follower; RAW has no smoothing. */
    private fun follow(prev: Float, target: Float, dt: Float): Float {
        if (rawComplete) return target
        val ms = if (target > prev) attackMs else releaseMs
        val tau = ms.coerceIn(1, 5000) / 1000f
        val k = 1f - exp(-dt / tau)
        return prev + (target - prev) * k
    }

    private fun slew(cur: Float, target: Float, maxStep: Float): Float {
        val d = target - cur
        return if (abs(d) <= maxStep) target else cur + (if (d > 0f) maxStep else -maxStep)
    }

    fun statusLine(): String {
        if (!enabled) return "AUDIO COLOUR off"
        val gates = buildList {
            if (gateContrast) add("C")
            if (gateBrightness) add("B")
            if (gateLevel) add("L")
        }.joinToString("").ifEmpty { "-" }
        val flags = buildList {
            if (rawComplete) add("RAW")
            if (invert) add("INV")
            if (flashLimitOn) add("FLASH-LIM")
        }.joinToString(" ")
        return "AUDIO COLOUR in=${(inLevel * 100).toInt()}% mid=${(inMid * 100).toInt()}% hi=${(inHigh * 100).toInt()}% " +
            "thr=${(thr * 100).toInt()}% gate=$gates · " +
            "con ${"%+.2f".format(dContrast)} bri ${"%+.2f".format(dBrightness)} col ${"%+.2f".format(dColour)} $flags"
    }

    companion object {
        const val CONTRAST_RANGE = 1.0f   // contrast 1.0 → up to 2.0 (video levels clamp to 0..2.5)
        const val BRIGHT_RANGE = 0.5f     // brightness −1..1 scale
        const val COLOUR_RANGE = 1.0f     // saturation 1.0 → up to 2.0
    }
    fun apply(v: VisualShieldView?) { /* colour mapping state */ }

}
