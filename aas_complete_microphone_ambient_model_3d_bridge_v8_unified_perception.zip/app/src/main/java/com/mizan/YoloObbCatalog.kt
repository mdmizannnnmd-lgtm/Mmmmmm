package com.mizan

/**
 * YOLO **OBB** (oriented bounding box) catalog for device / enemy tracking in 3D game.
 *
 * Runtime needs ONNX/TFLite (`yolo26x-obb.onnx`); `.pt` is export-only on Android.
 * DOTA-style vehicle classes + SenseGuard device classes.
 *
 * Output geometry: `xywhr` = center-x, center-y, width, height, rotation (radians)
 * or 4-corner polygon `xyxyxyxy`.
 *
 * @see https://docs.ultralytics.com/tasks/obb/
 */
object YoloObbCatalog {
    /** Preferred on-device asset names (checked in order). */
    val ASSET_CANDIDATES = arrayOf(
        "yolo26x-obb.onnx",
        "yolo11x-obb.onnx",
        "yolo26x-obb.tflite",
        "yolo11n-obb.onnx"
    )

    /** Reference PyTorch weight (not executed on device). */
    const val PT_REFERENCE = "yolo26x-obb.pt"

    /**
     * SenseGuard device + DOTA-like vehicle classes for enemy tracking.
     * Index is the model class id when custom-trained; names are labels only.
     */
    val CLASSES = arrayOf(
        "person",
        "mobile",
        "bike",
        "car",
        "helicopter",
        "airplane",
        "laptop",
        "computer",
        "cycle",
        "rickshaw",
        "device",
        "bus",
        "truck",
        "boat",
        "ship"
    )

    data class ObbBox(
        val cls: Int,
        val conf: Float,
        val cx: Float,
        val cy: Float,
        val w: Float,
        val h: Float,
        val angleRad: Float
    ) {
        fun className(): String =
            if (cls in CLASSES.indices) CLASSES[cls] else "class_$cls"
    }

    /** Map class name → game body key (existing GameWorld3D device enemies). */
    fun toGameBodyKey(className: String): String? = when (className.lowercase()) {
        "person" -> "enemy"
        "mobile", "phone", "cell phone" -> "mobile"
        "bike", "motorcycle" -> "bike"
        "car", "vehicle" -> "car"
        "helicopter" -> "helicopter"
        "airplane", "plane" -> "airplane"
        "laptop" -> "laptop"
        "computer", "monitor", "tv" -> "computer"
        "cycle", "bicycle" -> "cycle"
        "rickshaw", "auto rickshaw" -> "rickshaw"
        "device", "bus", "truck", "boat", "ship" -> "device"
        else -> null
    }
}
