package com.mizan

/**
 * Direct Pose + Segment eye groups (not single parts) + complete body.
 * Sources: COCO-17 / YOLO-pose, MediaPipe Pose-33, Face Mesh eye contours + iris.
 * Additive — does not replace existing eye anatomy or Body84 paths.
 */
class PoseSegEyeBodyBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var poseOn = true
    @Volatile var segOn = true
    @Volatile var faceMeshEyesOn = true
    @Volatile var thr = 0.28f
    @Volatile var level = 0.70f

    // ── Pose eye groups (MediaPipe Pose 33: not a single point) ──
    // L: inner=1, center=2, outer=3 · R: inner=4, center=5, outer=6
    @Volatile var poseEyeLInner = 0f
    @Volatile var poseEyeLCenter = 0f
    @Volatile var poseEyeLOuter = 0f
    @Volatile var poseEyeRInner = 0f
    @Volatile var poseEyeRCenter = 0f
    @Volatile var poseEyeROuter = 0f
    /** Group out = max of inner/center/outer (full eye, not single landmark). */
    @Volatile var poseEyeLGroup = 0f
    @Volatile var poseEyeRGroup = 0f
    // COCO-17 / YOLO: indices 1 left_eye, 2 right_eye (still treated as group anchors)
    @Volatile var cocoEyeL = 0f
    @Volatile var cocoEyeR = 0f

    // ── Face-mesh eye contours + iris (MediaPipe 478) ──
    // Contour indices groups — not single parts
    val leftUpperLid = intArrayOf(246, 161, 160, 159, 158, 157, 173)
    val leftLowerLid = intArrayOf(33, 7, 163, 144, 145, 153, 154, 155, 133)
    val rightUpperLid = intArrayOf(466, 388, 387, 386, 385, 384, 398)
    val rightLowerLid = intArrayOf(263, 249, 390, 373, 374, 380, 381, 382, 362)
    val leftIrisRing = intArrayOf(468, 469, 470, 471, 472)
    val rightIrisRing = intArrayOf(473, 474, 475, 476, 477)
    @Volatile var meshLeftContour = 0f
    @Volatile var meshRightContour = 0f
    @Volatile var meshLeftIris = 0f
    @Volatile var meshRightIris = 0f
    @Volatile var meshLeftEyeGroup = 0f
    @Volatile var meshRightEyeGroup = 0f

    // ── Segment body regions (full body mask regions, not single joints) ──
    @Volatile var segHead = 0f
    @Volatile var segTorso = 0f
    @Volatile var segArmL = 0f
    @Volatile var segArmR = 0f
    @Volatile var segLegL = 0f
    @Volatile var segLegR = 0f
    @Volatile var segFullBody = 0f

    // ── Full body pose outs (MediaPipe 33 names) ──
    companion object {
        val POSE33 = arrayOf(
            "nose", "left_eye_inner", "left_eye", "left_eye_outer",
            "right_eye_inner", "right_eye", "right_eye_outer",
            "left_ear", "right_ear", "mouth_left", "mouth_right",
            "left_shoulder", "right_shoulder", "left_elbow", "right_elbow",
            "left_wrist", "right_wrist", "left_pinky", "right_pinky",
            "left_index", "right_index", "left_thumb", "right_thumb",
            "left_hip", "right_hip", "left_knee", "right_knee",
            "left_ankle", "right_ankle", "left_heel", "right_heel",
            "left_foot_index", "right_foot_index"
        )
        val COCO17 = arrayOf(
            "nose", "left_eye", "right_eye", "left_ear", "right_ear",
            "left_shoulder", "right_shoulder", "left_elbow", "right_elbow",
            "left_wrist", "right_wrist", "left_hip", "right_hip",
            "left_knee", "right_knee", "left_ankle", "right_ankle"
        )
    }
    val pose33Out = FloatArray(33) { 0f }
    val coco17Out = FloatArray(17) { 0f }
    @Volatile var bodyActiveCount = 0
    @Volatile var status = "POSE·SEG·EYE idle"

    private fun lane(e: Float, drive: Float): Float {
        if (rawComplete) return (e * level * drive).coerceIn(0f, 1f)
        val t = (thr * drive).coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * level * drive).coerceIn(0f, 1f) else 0f
    }

    /**
     * @param mic energy 0..1
     * @param modelDrive body mixer / model score
     * @param poseScores optional length 33 confidence array from pose model (null = synthetic from mic)
     * @param segScores optional [head,torso,armL,armR,legL,legR] (null = synthetic)
     */
    fun tick(
        mic: Float,
        modelDrive: Float = 1f,
        poseScores: FloatArray? = null,
        segScores: FloatArray? = null
    ) {
        if (!enabled) {
            status = "POSE·SEG·EYE OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val drive = 0.25f + 0.75f * modelDrive.coerceIn(0f, 1f)

        // Pose full body
        if (poseOn) {
            for (i in 0 until 33) {
                val src = poseScores?.getOrNull(i) ?: (e * (0.85f + (i % 5) * 0.03f))
                pose33Out[i] = lane(src, drive)
            }
            for (i in 0 until 17) {
                val src = poseScores?.getOrNull(
                    when (i) {
                        1 -> 2; 2 -> 5; // COCO left/right eye → pose center eyes
                        3 -> 7; 4 -> 8
                        else -> i.coerceAtMost(32)
                    }
                ) ?: (e * (0.88f + (i % 4) * 0.03f))
                coco17Out[i] = lane(src, drive)
            }
            // Eye groups = max of inner/center/outer (not single)
            poseEyeLInner = pose33Out[1]
            poseEyeLCenter = pose33Out[2]
            poseEyeLOuter = pose33Out[3]
            poseEyeRInner = pose33Out[4]
            poseEyeRCenter = pose33Out[5]
            poseEyeROuter = pose33Out[6]
            poseEyeLGroup = maxOf(poseEyeLInner, poseEyeLCenter, poseEyeLOuter)
            poseEyeRGroup = maxOf(poseEyeRInner, poseEyeRCenter, poseEyeROuter)
            cocoEyeL = coco17Out[1]
            cocoEyeR = coco17Out[2]
        }

        // Face-mesh eye groups from energy (contour + iris rings as groups)
        if (faceMeshEyesOn) {
            meshLeftContour = lane(e * 1.02f, drive)
            meshRightContour = lane(e, drive)
            meshLeftIris = lane(e * 1.05f, drive)
            meshRightIris = lane(e * 1.03f, drive)
            meshLeftEyeGroup = maxOf(meshLeftContour, meshLeftIris, poseEyeLGroup)
            meshRightEyeGroup = maxOf(meshRightContour, meshRightIris, poseEyeRGroup)
        }

        // Segment full-body regions
        if (segOn) {
            segHead = lane(segScores?.getOrNull(0) ?: e * 1.05f, drive)
            segTorso = lane(segScores?.getOrNull(1) ?: e * 1.0f, drive)
            segArmL = lane(segScores?.getOrNull(2) ?: e * 0.95f, drive)
            segArmR = lane(segScores?.getOrNull(3) ?: e * 0.95f, drive)
            segLegL = lane(segScores?.getOrNull(4) ?: e * 0.92f, drive)
            segLegR = lane(segScores?.getOrNull(5) ?: e * 0.92f, drive)
            segFullBody = maxOf(segHead, segTorso, segArmL, segArmR, segLegL, segLegR)
        }

        bodyActiveCount = pose33Out.count { it > 0.02f } + if (segFullBody > 0.02f) 1 else 0
        status =
            "POSE eyes L-group=${(poseEyeLGroup*100).toInt()}% R-group=${(poseEyeRGroup*100).toInt()}% · " +
            "MESH L=${(meshLeftEyeGroup*100).toInt()} R=${(meshRightEyeGroup*100).toInt()} · " +
            "SEG body=${(segFullBody*100).toInt()}% head=${(segHead*100).toInt()} · " +
            "pose33act=$bodyActiveCount" + if (rawComplete) " · RAW" else ""
    }

    /** Feed eye groups into CNS/eyes shield (group energy, not single landmark). */
    fun applyToEyes(cns: CnsEyesHeart3dBoard, shield: VisualShieldView) {
        if (!enabled) return
        val l = maxOf(poseEyeLGroup, meshLeftEyeGroup, cocoEyeL)
        val r = maxOf(poseEyeRGroup, meshRightEyeGroup, cocoEyeR)
        cns.eyeLOut = maxOf(cns.eyeLOut, l)
        cns.eyeROut = maxOf(cns.eyeROut, r)
        cns.leftEyeFull.fill(maxOf(cns.leftEyeFull.total, l), 1.02f)
        cns.rightEyeFull.fill(maxOf(cns.rightEyeFull.total, r), 1f)
        shield.eyeL.ambient = maxOf(shield.eyeL.ambient, l)
        shield.eyeR.ambient = maxOf(shield.eyeR.ambient, r)
        if (segOn) {
            shield.skinHead.ambient = maxOf(shield.skinHead.ambient, segHead)
            shield.skinChest.ambient = maxOf(shield.skinChest.ambient, segTorso)
            shield.skinArmL.ambient = maxOf(shield.skinArmL.ambient, segArmL)
            shield.skinArmR.ambient = maxOf(shield.skinArmR.ambient, segArmR)
            shield.skinLegL.ambient = maxOf(shield.skinLegL.ambient, segLegL)
            shield.skinLegR.ambient = maxOf(shield.skinLegR.ambient, segLegR)
        }
    }
}
