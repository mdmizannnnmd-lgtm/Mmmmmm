package com.mizan

/**
 * Model-driven speaker sounds tracking · microphone bullet sounds ·
 * axis threshold all sounds · enemy ambient detect (burst + previous FX) ·
 * counters · sensor fusion. RAW COMPLETE.
 */
class ModelSpeakerSoundsTrackBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Model → speaker tracking
    @Volatile var modelDriveOn = true
    @Volatile var modelSpeakerOut = 0f
    @Volatile var speakerTrackThr = 0.18f
    @Volatile var speakerTrackLv = 0.90f

    // Mic bullet sounds
    @Volatile var micBulletOn = true
    @Volatile var micBulletThr = 0.22f
    @Volatile var micBulletOut = 0f

    // Axis threshold all sounds
    @Volatile var axisAllOn = true
    @Volatile var axisThr = 0.15f
    @Volatile var axisLv = 0.90f
    @Volatile var axisX = 0.33f
    @Volatile var axisY = 0.33f
    @Volatile var axisZ = 0.34f
    @Volatile var axisAllOut = 0f

    // Enemy ambient detection (burst + previous)
    @Volatile var enemyAmbOn = true
    @Volatile var enemyAmbThr = 0.20f
    @Volatile var enemyBurstDet = 0f
    @Volatile var enemyBulletDet = 0f
    @Volatile var enemyKnifeDet = 0f
    @Volatile var enemySharpDet = 0f
    @Volatile var enemyWhipDet = 0f
    @Volatile var enemyArrowDet = 0f
    @Volatile var enemyAllDet = 0f

    // Counters (edge)
    @Volatile var cntBurst = 0
    @Volatile var cntBullet = 0
    @Volatile var cntKnife = 0
    @Volatile var cntSharp = 0
    @Volatile var cntWhip = 0
    @Volatile var cntArrow = 0
    @Volatile var cntAll = 0

    // Sensor fusion
    @Volatile var sensorOn = true
    @Volatile var sensorOut = 0f

    @Volatile var protectOut = 0f
    @Volatile var status = "MODEL-SPK-SND idle"

    private var prevB = 0f
    private var prevBu = 0f
    private var prevK = 0f
    private var prevS = 0f
    private var prevW = 0f
    private var prevA = 0f

    private fun lane(on: Boolean, e: Float, thr: Float, lv: Float): Float {
        if (!on && !rawComplete) return 0f
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * lv).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * lv).coerceIn(0f, 1f) else 0f
    }

    private fun edge(prev: Float, now: Float, thr: Float): Boolean =
        prev < thr && now >= thr

    fun tick(
        mic: Float,
        model: Float,
        speaker: Float,
        burst: Float,
        bullet: Float,
        knife: Float,
        sharp: Float,
        whip: Float,
        arrow: Float,
        ax: Float,
        ay: Float,
        az: Float,
        sensor: Float
    ) {
        if (!enabled) { status = "MODEL-SPK-SND OFF"; return }

        modelSpeakerOut = lane(modelDriveOn, maxOf(model, speaker) * 1.05f, speakerTrackThr, speakerTrackLv)
        micBulletOut = lane(micBulletOn, maxOf(mic * 0.9f, bullet), micBulletThr, 0.92f)

        axisX = ax.coerceIn(0f, 1f)
        axisY = ay.coerceIn(0f, 1f)
        axisZ = az.coerceIn(0f, 1f)
        val axisE = maxOf(axisX, axisY, axisZ) * maxOf(mic, burst, bullet)
        axisAllOut = lane(axisAllOn, axisE, axisThr, axisLv)

        sensorOut = lane(sensorOn, sensor, 0.12f, 0.88f)

        // Enemy ambient detect — previous effects
        val ambBoost = maxOf(modelSpeakerOut * 0.4f, sensorOut * 0.5f, axisAllOut * 0.3f)
        enemyBurstDet = lane(enemyAmbOn, burst + ambBoost * 0.5f, enemyAmbThr, 0.95f)
        enemyBulletDet = lane(enemyAmbOn, maxOf(bullet, micBulletOut) + ambBoost * 0.4f, enemyAmbThr, 0.95f)
        enemyKnifeDet = lane(enemyAmbOn, knife + ambBoost * 0.35f, enemyAmbThr, 0.95f)
        enemySharpDet = lane(enemyAmbOn, sharp + ambBoost * 0.35f, enemyAmbThr, 0.95f)
        enemyWhipDet = lane(enemyAmbOn, whip + ambBoost * 0.3f, enemyAmbThr, 0.95f)
        enemyArrowDet = lane(enemyAmbOn, arrow + ambBoost * 0.3f, enemyAmbThr, 0.95f)
        enemyAllDet = maxOf(enemyBurstDet, enemyBulletDet, enemyKnifeDet, enemySharpDet, enemyWhipDet, enemyArrowDet)

        // Counters on rising edge
        if (edge(prevB, enemyBurstDet, enemyAmbThr)) { cntBurst++; cntAll++ }
        if (edge(prevBu, enemyBulletDet, enemyAmbThr)) { cntBullet++; cntAll++ }
        if (edge(prevK, enemyKnifeDet, enemyAmbThr)) { cntKnife++; cntAll++ }
        if (edge(prevS, enemySharpDet, enemyAmbThr)) { cntSharp++; cntAll++ }
        if (edge(prevW, enemyWhipDet, enemyAmbThr)) { cntWhip++; cntAll++ }
        if (edge(prevA, enemyArrowDet, enemyAmbThr)) { cntArrow++; cntAll++ }
        prevB = enemyBurstDet; prevBu = enemyBulletDet; prevK = enemyKnifeDet
        prevS = enemySharpDet; prevW = enemyWhipDet; prevA = enemyArrowDet

        protectOut = maxOf(enemyAllDet, micBulletOut * 0.7f, axisAllOut * 0.5f, modelSpeakerOut * 0.4f)
        if (rawComplete) protectOut = maxOf(protectOut, 0.22f + maxOf(mic, model) * 0.3f)

        status =
            "SPK=${(modelSpeakerOut*100).toInt()}% micBu=${(micBulletOut*100).toInt()}% axis=${(axisAllOut*100).toInt()}% · " +
            "EN amb B/Bu/K=${(enemyBurstDet*100).toInt()}/${(enemyBulletDet*100).toInt()}/${(enemyKnifeDet*100).toInt()}% · " +
            "CNT ${cntBurst}/${cntBullet}/${cntKnife}/${cntSharp}/${cntWhip}/${cntArrow} · " +
            "sensor=${(sensorOut*100).toInt()}% prot=${(protectOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun resetCounters() {
        cntBurst = 0; cntBullet = 0; cntKnife = 0; cntSharp = 0; cntWhip = 0; cntArrow = 0; cntAll = 0
    }

    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!enabled || protectOut < 0.02f) return
        try {
            if (sb != null) {
                val d = (1f - protectOut * 0.85f).coerceIn(0.05f, 1f)
                sb.burstOut *= (1f - enemyBurstDet * 0.9f).coerceIn(0.05f, 1f)
                sb.bulletOut *= (1f - enemyBulletDet * 0.9f).coerceIn(0.05f, 1f)
                sb.knifeOut *= (1f - enemyKnifeDet * 0.88f).coerceIn(0.05f, 1f)
                sb.enemyBodyOut *= d
            }
        } catch (_: Throwable) {}
        val vv = v ?: return
        try {
            // Sync counters board
            val c = vv.enemySoundCounters
            c.burstDet = maxOf(c.burstDet, enemyBurstDet)
            c.bulletDet = maxOf(c.bulletDet, enemyBulletDet)
            c.knifeDet = maxOf(c.knifeDet, enemyKnifeDet)
            c.sharpDet = maxOf(c.sharpDet, enemySharpDet)
            c.arrowDet = maxOf(c.arrowDet, enemyArrowDet)
            // axis
            c.micAxisX = axisX; c.micAxisY = axisY; c.micAxisZ = axisZ
            vv.sensorGatedSfx.let { /* sensor path already live */ }
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, protectOut * 0.5f)
            vv.micSpeaker.out = maxOf(vv.micSpeaker.out, modelSpeakerOut * 0.6f)
        } catch (_: Throwable) {}
    }
}
