package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object EnemySoundCancelPanels {
    fun build(ctx: Context, root: LinearLayout, b: EnemySoundCancelBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFEF9A9A.toInt()
        p.title("BURST CANCEL · KNIFE CANCEL · ALL ATOMSPARE ENEMY SOUNDS CANCEL", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("SOUND BURST CANCELLATION", c)
        p.switch("Burst cancel ON", b.burstCancelOn) { b.burstCancelOn = it }
        p.seek("Burst cancel thr", 0.05f, 0.98f, b.burstCancelThr) { b.burstCancelThr = it }
        p.seek("Burst cancel level", 0f, 1.5f, b.burstCancelLv) { b.burstCancelLv = it }

        p.title("SOUND KNIFE CANCELLATION", c)
        p.switch("Knife cancel ON", b.knifeCancelOn) { b.knifeCancelOn = it }
        p.seek("Knife cancel thr", 0.05f, 0.98f, b.knifeCancelThr) { b.knifeCancelThr = it }
        p.seek("Knife cancel level", 0f, 1.5f, b.knifeCancelLv) { b.knifeCancelLv = it }

        p.title("ALL ATOMSPARE ENEMY SOUNDS CANCELLATION", c)
        p.note("Cancels bullet · sharp · whip · ripple · collide · enemy body · mic enemy · burst · knife")
        p.switch("Atom enemy cancel ON", b.atomEnemyCancelOn) { b.atomEnemyCancelOn = it }
        p.seek("Atom enemy cancel thr", 0.05f, 0.98f, b.atomEnemyCancelThr) { b.atomEnemyCancelThr = it }
        p.seek("Atom enemy cancel level", 0f, 1.5f, b.atomEnemyCancelLv) { b.atomEnemyCancelLv = it }

        val st = p.status("SFX CANCEL —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 200) }
        })
    }
}
