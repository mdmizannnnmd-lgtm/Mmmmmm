package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object FaceEyeNoiseCompletePanels {
    fun build(ctx: Context, root: LinearLayout, b: FaceEyeNoiseCompleteBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFFCC80.toInt()
        p.title("FACE COMPLETE · EYE COMPLETE · NOISE FULL", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("FACE (forehead brow cheek nose lips jaw chin ear temple skin)", c)
        p.switch("Face ON", b.faceOn) { b.faceOn = it }
        p.seek("Face thr", 0.05f, 0.98f, b.faceThr) { b.faceThr = it }
        p.seek("Face level", 0f, 1.5f, b.faceLv) { b.faceLv = it }

        p.title("EYE L/R", c)
        p.switch("Eye ON", b.eyeOn) { b.eyeOn = it }
        p.seek("Eye thr", 0.05f, 0.98f, b.eyeThr) { b.eyeThr = it }
        p.seek("Eye level", 0f, 1.5f, b.eyeLv) { b.eyeLv = it }

        p.title("NOISE (floor · auto thr · spike)", c)
        p.switch("Noise ON", b.noiseOn) { b.noiseOn = it }
        p.switch("Noise auto threshold", b.noiseAutoThr) { b.noiseAutoThr = it }
        p.seek("Noise thr", 0.05f, 0.98f, b.noiseThr) { b.noiseThr = it }
        p.seek("Noise level", 0f, 1.5f, b.noiseLv) { b.noiseLv = it }

        val st = p.status("FACE·EYE·NOISE —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
