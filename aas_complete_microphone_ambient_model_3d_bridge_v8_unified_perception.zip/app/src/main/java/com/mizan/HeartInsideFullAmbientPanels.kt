package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object HeartInsideFullAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: HeartInsideFullAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFEF9A9A.toInt()
        p.title("HEART INSIDE · FULL ANATOMY AMBIENT", c)
        p.note("Chambers · 4 valves · vessels · septum · papillary · chordae · layers · SA/AV · coronary")
        p.switch("Heart inside ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.seek("Threshold", 0.05f, 1f, b.thr) { b.thr = it }
        p.seek("Level", 0.1f, 1.5f, b.levelAmt) { b.levelAmt = it }
        val st = p.status("HEART —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 300) }
        })
    }
}
