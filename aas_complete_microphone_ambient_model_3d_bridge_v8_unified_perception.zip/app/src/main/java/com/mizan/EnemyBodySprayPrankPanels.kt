package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object EnemyBodySprayPrankPanels {
    fun build(ctx: Context, root: LinearLayout, b: EnemyBodySprayPrankBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFCE93D8.toInt()
        p.title("ENEMY BODY SPRAY PRANK · ARMPIT / BUTT · MIC·BLE·MODEL", c)
        p.note("Audio/BLE/model ambient only — not real chemical or biological sprays.")
        p.switch("ON", b.enabled) { b.enabled = it }
        p.switch("RAW", b.rawComplete) { b.rawComplete = it }
        p.seek("Thr", 0.05f, 0.9f, b.thr) { b.thr = it }
        p.seek("Level", 0.2f, 1.5f, b.levelAmt) { b.levelAmt = it }
        val st = p.status("SPRAY —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() { st.text = b.status; Handler(Looper.getMainLooper()).postDelayed(this, 300) }
        })
    }
}
