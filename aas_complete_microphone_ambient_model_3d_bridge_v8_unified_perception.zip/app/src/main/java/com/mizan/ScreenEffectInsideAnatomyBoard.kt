package com.mizan

/**
 * All-effect screen tracking protection · inside body bad frequency
 * (cell / organ / neuro / chem / hormone) repair & regeneration · glands ·
 * eyes skin water ambient · drives 3D water/chem/neuro/non-nerve/gland layers.
 * RAW COMPLETE.
 */
class ScreenEffectInsideAnatomyBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // All effect screen tracking
    @Volatile var screenTrackOn = true
    @Volatile var screenTrackThr = 0.18f
    @Volatile var screenBurst = 0f
    @Volatile var screenBullet = 0f
    @Volatile var screenKnife = 0f
    @Volatile var screenAllFx = 0f
    @Volatile var screenProtectOut = 0f

    // Inside bad frequency by system
    @Volatile var badInsideThr = 0.45f
    @Volatile var badCell = 0f
    @Volatile var badOrgan = 0f
    @Volatile var badNeuro = 0f
    @Volatile var badChem = 0f
    @Volatile var badHormone = 0f
    @Volatile var badGland = 0f
    @Volatile var badInsideFull = 0f

    // Repair / regen inside
    @Volatile var repairInside = 0f
    @Volatile var regenInside = 0f
    @Volatile var glandRepair = 0f
    @Volatile var hormoneRepair = 0f
    @Volatile var cellRepair = 0f
    @Volatile var neuroRepair = 0f

    // Eyes skin water
    @Volatile var eyeSkinWaterOut = 0f

    // 3D layer drives
    @Volatile var drawWaterChem = 0f
    @Volatile var drawNeuro = 0f
    @Volatile var drawNonNerve = 0f
    @Volatile var drawGland = 0f
    @Volatile var drawEyeSkinWater = 0f

    @Volatile var systemFull = 0f
    @Volatile var status = "SCREEN-INSIDE idle"

    private fun lane(on: Boolean, e: Float, thr: Float, lv: Float = 0.9f): Float {
        if (!on && !rawComplete) return 0f
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * lv).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        mic: Float,
        burst: Float,
        bullet: Float,
        knife: Float,
        badHz: Float,
        regen: Float,
        repair: Float,
        chem: Float,
        water: Float,
        blood: Float,
        neuro: Float,
        hormone: Float,
        eye: Float,
        skin: Float
    ) {
        if (!enabled) { status = "SCREEN-INSIDE OFF"; return }
        val e = mic.coerceIn(0f, 1.5f)

        screenBurst = lane(screenTrackOn, burst, screenTrackThr)
        screenBullet = lane(screenTrackOn, bullet, screenTrackThr)
        screenKnife = lane(screenTrackOn, knife, screenTrackThr)
        screenAllFx = maxOf(screenBurst, screenBullet, screenKnife, e * 0.5f)
        screenProtectOut = lane(true, screenAllFx, 0.12f, 0.95f)

        // Inside bad freq split
        badCell = lane(true, badHz * 0.95f + chem * 0.3f, badInsideThr)
        badOrgan = lane(true, badHz * 0.9f + blood * 0.3f, badInsideThr)
        badNeuro = lane(true, badHz * 0.92f + neuro * 0.4f, badInsideThr)
        badChem = lane(true, badHz * 0.85f + chem * 0.5f, badInsideThr)
        badHormone = lane(true, badHz * 0.88f + hormone * 0.4f, badInsideThr)
        badGland = lane(true, badHz * 0.87f + hormone * 0.35f, badInsideThr)
        badInsideFull = maxOf(badCell, badOrgan, badNeuro, badChem, badHormone, badGland)

        // Repair / regen oppose bad
        repairInside = lane(true, maxOf(repair, (1f - badInsideFull) * e), 0.12f)
        regenInside = lane(true, maxOf(regen, repairInside * 0.8f), 0.12f)
        cellRepair = lane(true, regenInside * 0.9f + (1f - badCell) * 0.5f, 0.1f)
        neuroRepair = lane(true, regenInside * 0.85f + (1f - badNeuro) * 0.5f, 0.1f)
        hormoneRepair = lane(true, regenInside * 0.8f + (1f - badHormone) * 0.5f, 0.1f)
        glandRepair = lane(true, regenInside * 0.8f + (1f - badGland) * 0.5f, 0.1f)

        eyeSkinWaterOut = lane(true, maxOf(eye, skin, water) * 0.95f, 0.15f)

        // 3D draws
        drawWaterChem = maxOf(water * 0.9f, badChem * 0.4f, chem * 0.6f, 0.25f)
        drawNeuro = maxOf(neuroRepair, badNeuro * 0.5f, neuro * 0.6f, 0.22f)
        drawNonNerve = maxOf(cellRepair, (1f - badCell) * 0.5f, 0.22f)
        drawGland = maxOf(glandRepair, hormoneRepair * 0.7f, 0.2f)
        drawEyeSkinWater = maxOf(eyeSkinWaterOut, 0.2f)
        if (rawComplete) {
            drawWaterChem = maxOf(drawWaterChem, 0.3f)
            drawNeuro = maxOf(drawNeuro, 0.28f)
            drawNonNerve = maxOf(drawNonNerve, 0.28f)
            drawGland = maxOf(drawGland, 0.25f)
            drawEyeSkinWater = maxOf(drawEyeSkinWater, 0.25f)
        }

        systemFull = maxOf(screenProtectOut, regenInside, repairInside, eyeSkinWaterOut, 1f - badInsideFull * 0.5f)
        if (rawComplete) systemFull = maxOf(systemFull, 0.28f)

        status =
            "SCR FX=${(screenAllFx*100).toInt()}% prot=${(screenProtectOut*100).toInt()}% · " +
            "bad cell/org/neu/chem=${(badCell*100).toInt()}/${(badOrgan*100).toInt()}/${(badNeuro*100).toInt()}/${(badChem*100).toInt()}% · " +
            "repair/regen=${(repairInside*100).toInt()}/${(regenInside*100).toInt()}% · " +
            "eyeSkinH2O=${(eyeSkinWaterOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!enabled) return
        val vv = v ?: return
        try {
            vv.soft3d.waterChemLayer = drawWaterChem
            vv.soft3d.neuroCellLayer = drawNeuro
            vv.soft3d.nonNerveCellLayer = drawNonNerve
            vv.soft3d.glandLayer = drawGland
            vv.soft3d.eyeSkinWaterLayer = drawEyeSkinWater

            vv.bodyFreqRegen.regenOut = maxOf(vv.bodyFreqRegen.regenOut, regenInside)
            vv.bodyFreqRegen.repairOut = maxOf(vv.bodyFreqRegen.repairOut, repairInside)
            vv.bodyFreqRegen.hormoneOut = maxOf(vv.bodyFreqRegen.hormoneOut, hormoneRepair)
            vv.neuralNeuroTx.neuralFull = maxOf(vv.neuralNeuroTx.neuralFull, neuroRepair)
            vv.waterFullBody.waterFull = maxOf(vv.waterFullBody.waterFull, eyeSkinWaterOut * 0.6f)
            vv.lifesumBloodBle.bloodRepairOut = maxOf(vv.lifesumBloodBle.bloodRepairOut, cellRepair * 0.5f)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, screenProtectOut * 0.6f)
            vv.modelSpeakerSounds.protectOut = maxOf(vv.modelSpeakerSounds.protectOut, screenProtectOut * 0.4f)
        } catch (_: Throwable) {}
        try {
            if (sb != null && screenProtectOut > 0.05f) {
                val d = (1f - screenProtectOut * 0.85f).coerceIn(0.05f, 1f)
                sb.burstOut *= d
                sb.bulletOut *= d
                sb.knifeOut *= d
                sb.enemyBodyOut *= d
            }
        } catch (_: Throwable) {}
    }
}
