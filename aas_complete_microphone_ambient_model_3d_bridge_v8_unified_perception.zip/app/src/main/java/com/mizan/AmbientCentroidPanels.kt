package com.mizan

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.LinearLayout

/**
 * Panel under the Ambient Threshold board: the live board view (spectrum · CENTROID · VERTICAL · live mic dB · AUTO threshold)
 * and the controls that tie the whole 3D body (movement · speed · waves · 84 body ambient · eye gaze) to centroid + vertical.
 * Every value is remembered in [MemoryPaths].
 */
object AmbientCentroidPanels {

    private const val P = "amb_"

    /** Restore the saved settings into the board and the drive. */
    fun restore(b: AmbientThresholdBoard, d: CentroidDrive) {
        b.autoThr = MemoryPaths.getBool(P + "auto_on", b.autoThr)
        b.autoMarginDb = MemoryPaths.getFloat(P + "auto_margin", b.autoMarginDb)
        b.dbOffset = MemoryPaths.getFloat(P + "db_offset", b.dbOffset)
        b.ambientThrPct = MemoryPaths.getFloat(P + "thr", b.ambientThrPct)
        b.centroidOn = MemoryPaths.getBool(P + "cen_on", b.centroidOn)
        b.centroidBipolar = MemoryPaths.getBool(P + "cen_bip", b.centroidBipolar)
        b.centroidLevel = MemoryPaths.getFloat(P + "cen_lv", b.centroidLevel)
        b.centroidThr = MemoryPaths.getFloat(P + "cen_thr", b.centroidThr)
        b.centroidNegGain = MemoryPaths.getFloat(P + "cen_neg", b.centroidNegGain)
        b.centroidPosGain = MemoryPaths.getFloat(P + "cen_pos", b.centroidPosGain)
        b.verticalOn = MemoryPaths.getBool(P + "ver_on", b.verticalOn)
        b.verticalBipolar = MemoryPaths.getBool(P + "ver_bip", b.verticalBipolar)
        b.verticalLevel = MemoryPaths.getFloat(P + "ver_lv", b.verticalLevel)
        b.verticalThr = MemoryPaths.getFloat(P + "ver_thr", b.verticalThr)
        b.verticalNegGain = MemoryPaths.getFloat(P + "ver_neg", b.verticalNegGain)
        b.verticalPosGain = MemoryPaths.getFloat(P + "ver_pos", b.verticalPosGain)
        b.dominationOn = MemoryPaths.getBool(P + "dom_on", b.dominationOn)
        b.dominationLevel = MemoryPaths.getFloat(P + "dom_lv", b.dominationLevel)
        b.dominationThr = MemoryPaths.getFloat(P + "dom_thr", b.dominationThr)
        b.dominationBipolar = MemoryPaths.getBool(P + "dom_bip", b.dominationBipolar)

        d.enabled = MemoryPaths.getBool(P + "drv_on", d.enabled)
        d.moveOn = MemoryPaths.getBool(P + "drv_move_on", d.moveOn)
        d.speedOn = MemoryPaths.getBool(P + "drv_speed_on", d.speedOn)
        d.waveOn = MemoryPaths.getBool(P + "drv_wave_on", d.waveOn)
        d.channelsOn = MemoryPaths.getBool(P + "drv_ch_on", d.channelsOn)
        d.eyesOn = MemoryPaths.getBool(P + "drv_eyes_on", d.eyesOn)

        d.ambCenOn = MemoryPaths.getBool(P + "amb_cen_on", d.ambCenOn)
        d.ambCenLv = MemoryPaths.getFloat(P + "amb_cen_lv", d.ambCenLv)
        d.ambCenThr = MemoryPaths.getFloat(P + "amb_cen_thr", d.ambCenThr)
        d.ambCenRaw = MemoryPaths.getBool(P + "amb_cen_raw", d.ambCenRaw)
        d.ambVerOn = MemoryPaths.getBool(P + "amb_ver_on", d.ambVerOn)
        d.ambVerLv = MemoryPaths.getFloat(P + "amb_ver_lv", d.ambVerLv)
        d.ambVerThr = MemoryPaths.getFloat(P + "amb_ver_thr", d.ambVerThr)
        d.ambVerRaw = MemoryPaths.getBool(P + "amb_ver_raw", d.ambVerRaw)
        d.moveCenOn = MemoryPaths.getBool(P + "move_cen_on", d.moveCenOn)
        d.moveCenLv = MemoryPaths.getFloat(P + "move_cen_lv", d.moveCenLv)
        d.moveCenThr = MemoryPaths.getFloat(P + "move_cen_thr", d.moveCenThr)
        d.moveCenRaw = MemoryPaths.getBool(P + "move_cen_raw", d.moveCenRaw)
        d.moveVerOn = MemoryPaths.getBool(P + "move_ver_on", d.moveVerOn)
        d.moveVerLv = MemoryPaths.getFloat(P + "move_ver_lv", d.moveVerLv)
        d.moveVerThr = MemoryPaths.getFloat(P + "move_ver_thr", d.moveVerThr)
        d.moveVerRaw = MemoryPaths.getBool(P + "move_ver_raw", d.moveVerRaw)
        d.speedCenOn = MemoryPaths.getBool(P + "spd_cen_on", d.speedCenOn)
        d.speedCenLv = MemoryPaths.getFloat(P + "spd_cen_lv", d.speedCenLv)
        d.speedCenThr = MemoryPaths.getFloat(P + "spd_cen_thr", d.speedCenThr)
        d.speedVerOn = MemoryPaths.getBool(P + "spd_ver_on", d.speedVerOn)
        d.speedVerLv = MemoryPaths.getFloat(P + "spd_ver_lv", d.speedVerLv)
        d.speedVerThr = MemoryPaths.getFloat(P + "spd_ver_thr", d.speedVerThr)
        d.waveCenOn = MemoryPaths.getBool(P + "wav_cen_on", d.waveCenOn)
        d.waveCenLv = MemoryPaths.getFloat(P + "wav_cen_lv", d.waveCenLv)
        d.waveCenThr = MemoryPaths.getFloat(P + "wav_cen_thr", d.waveCenThr)
        d.waveVerOn = MemoryPaths.getBool(P + "wav_ver_on", d.waveVerOn)
        d.waveVerLv = MemoryPaths.getFloat(P + "wav_ver_lv", d.waveVerLv)
        d.waveVerThr = MemoryPaths.getFloat(P + "wav_ver_thr", d.waveVerThr)

        d.moveAmt = MemoryPaths.getFloat(P + "drv_move", d.moveAmt)
        d.speedAmt = MemoryPaths.getFloat(P + "drv_speed", d.speedAmt)
        d.waveAmt = MemoryPaths.getFloat(P + "drv_wave", d.waveAmt)
        d.channelAmt = MemoryPaths.getFloat(P + "drv_ch", d.channelAmt)
        d.gazeRange = MemoryPaths.getFloat(P + "drv_gaze_range", d.gazeRange)
        d.gazeFollow = MemoryPaths.getFloat(P + "drv_gaze_follow", d.gazeFollow)
        d.gazeLRotationLevel = MemoryPaths.getFloat(P + "gaze_l_level", d.gazeLRotationLevel)
        d.gazeRRotationLevel = MemoryPaths.getFloat(P + "gaze_r_level", d.gazeRRotationLevel)
        d.gazeLPositionX = MemoryPaths.getFloat(P + "gaze_l_x", d.gazeLPositionX)
        d.gazeLPositionY = MemoryPaths.getFloat(P + "gaze_l_y", d.gazeLPositionY)
        d.gazeRPositionX = MemoryPaths.getFloat(P + "gaze_r_x", d.gazeRPositionX)
        d.gazeRPositionY = MemoryPaths.getFloat(P + "gaze_r_y", d.gazeRPositionY)
    }

    fun build(ctx: Context, root: LinearLayout, b: AmbientThresholdBoard, d: CentroidDrive, view: VisualShieldView) {
        restore(b, d)
        val cyan = Color.rgb(0x4D, 0xD0, 0xE1)
        val gold = Color.rgb(0xFF, 0xD5, 0x4F)

        // ── the live board (same graphics as the original ambient board) ──
        val board = AmbientCentroidView(ctx, b) { key, v ->
            MemoryPaths.putFloat(P + key, v)
            if (key.endsWith("_on") || key.endsWith("_bip")) MemoryPaths.putBool(P + key, v > 0.5f)
        }
        root.addView(board, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val p = PanelBuilder(ctx, root)
        p.title("LIVE MICROPHONE dB · AUTO THRESHOLD", cyan)
        p.note("The board reads the real microphone: MIC dBFS (0 = full scale) and a readable dB (dBFS + offset — phone microphones are not calibrated, so this is not true SPL). With AUTO on, the threshold is the higher of the Ambient Threshold slider (the minimum) and the room's live noise floor + margin (the floor falls at once and rises over ~10 s, so a loud moment never drags it up).")
        p.seek("dB offset (dBFS → dB)", 0f, 130f, b.dbOffset, 0) { b.dbOffset = it; MemoryPaths.putFloat(P + "db_offset", it) }
        val st = p.status("MIC —", cyan)

        
        p.title("AMBIENT · CENTROID + VERTICAL (all body)", gold)
        p.title("DOMINATION Hz · THRESHOLD · LEVEL · OUTPUT")
        p.switch("Domination Hz ON", b.dominationOn) { b.dominationOn = it; MemoryPaths.putBool(P + "dom_on", it) }
        p.switch("Domination RAW COMPLETE", b.dominationRaw) { b.dominationRaw = it; MemoryPaths.putBool(P + "dom_raw", it) }
        p.seek("Domination threshold", 0.05f, 0.98f, b.dominationThr) { b.dominationThr = it; MemoryPaths.putFloat(P + "dom_thr", it) }
        p.seek("Domination level", 0f, 1.5f, b.dominationLevel) { b.dominationLevel = it; MemoryPaths.putFloat(P + "dom_lv", it) }
        p.switch("Domination bipolar", b.dominationBipolar) { b.dominationBipolar = it; MemoryPaths.putBool(P + "dom_bip", it) }
        p.seek("Domination neg gain (− rail)", 0f, 2f, b.dominationNegGain) { b.dominationNegGain = it; MemoryPaths.putFloat(P + "dom_neg", it) }
        p.seek("Domination pos gain (+ rail)", 0f, 2f, b.dominationPosGain) { b.dominationPosGain = it; MemoryPaths.putFloat(P + "dom_pos", it) }
        p.seek("Domination Hz min", 20f, 5000f, b.dominationHzMin) { b.dominationHzMin = it; MemoryPaths.putFloat(P + "dom_hz_min", it) }
        p.seek("Domination Hz max", 500f, 20000f, b.dominationHzMax) { b.dominationHzMax = it; MemoryPaths.putFloat(P + "dom_hz_max", it) }
        p.seek("Domination smooth", 0.05f, 1f, b.dominationSmooth) { b.dominationSmooth = it; MemoryPaths.putFloat(P + "dom_sm", it) }
        val domStatus = p.status("DOM — Hz · out —% · RAW", 0xFFFFD54F.toInt())
        // refresh hook if view posts
        p.note("Same style as NOSE Ambient·Wave panel: level / threshold for ambient centroid and ambient vertical — drives every body part ambient (not single).")
        p.switch("Ambient centroid ON", d.ambCenOn) { d.ambCenOn = it; MemoryPaths.putBool(P + "amb_cen_on", it) }
        p.seek("Ambient centroid level", 0f, 1.5f, d.ambCenLv) { d.ambCenLv = it; MemoryPaths.putFloat(P + "amb_cen_lv", it) }
        p.seek("Ambient centroid threshold", 0f, 0.98f, d.ambCenThr) { d.ambCenThr = it; MemoryPaths.putFloat(P + "amb_cen_thr", it) }
        p.switch("Ambient centroid RAW", d.ambCenRaw) { d.ambCenRaw = it; MemoryPaths.putBool(P + "amb_cen_raw", it) }
        p.switch("Ambient vertical ON", d.ambVerOn) { d.ambVerOn = it; MemoryPaths.putBool(P + "amb_ver_on", it) }
        p.seek("Ambient vertical level", 0f, 1.5f, d.ambVerLv) { d.ambVerLv = it; MemoryPaths.putFloat(P + "amb_ver_lv", it) }
        p.seek("Ambient vertical threshold", 0f, 0.98f, d.ambVerThr) { d.ambVerThr = it; MemoryPaths.putFloat(P + "amb_ver_thr", it) }
        p.switch("Ambient vertical RAW", d.ambVerRaw) { d.ambVerRaw = it; MemoryPaths.putBool(P + "amb_ver_raw", it) }

        p.title("MOVEMENT · CENTROID + VERTICAL", gold)
        p.switch("Movement centroid ON", d.moveCenOn) { d.moveCenOn = it; MemoryPaths.putBool(P + "move_cen_on", it) }
        p.seek("Movement centroid level", 0f, 1.5f, d.moveCenLv) { d.moveCenLv = it; MemoryPaths.putFloat(P + "move_cen_lv", it) }
        p.seek("Movement centroid threshold", 0f, 0.98f, d.moveCenThr) { d.moveCenThr = it; MemoryPaths.putFloat(P + "move_cen_thr", it) }
        p.switch("Movement centroid RAW", d.moveCenRaw) { d.moveCenRaw = it; MemoryPaths.putBool(P + "move_cen_raw", it) }
        p.switch("Movement vertical ON", d.moveVerOn) { d.moveVerOn = it; MemoryPaths.putBool(P + "move_ver_on", it) }
        p.seek("Movement vertical level", 0f, 1.5f, d.moveVerLv) { d.moveVerLv = it; MemoryPaths.putFloat(P + "move_ver_lv", it) }
        p.seek("Movement vertical threshold", 0f, 0.98f, d.moveVerThr) { d.moveVerThr = it; MemoryPaths.putFloat(P + "move_ver_thr", it) }
        p.switch("Movement vertical RAW", d.moveVerRaw) { d.moveVerRaw = it; MemoryPaths.putBool(P + "move_ver_raw", it) }

        p.title("SPEED · WAVES · CENTROID + VERTICAL", gold)
        p.switch("Speed centroid ON", d.speedCenOn) { d.speedCenOn = it; MemoryPaths.putBool(P + "spd_cen_on", it) }
        p.seek("Speed centroid level / thr", 0f, 1.5f, d.speedCenLv) { d.speedCenLv = it; MemoryPaths.putFloat(P + "spd_cen_lv", it) }
        p.seek("Speed centroid threshold", 0f, 0.98f, d.speedCenThr) { d.speedCenThr = it; MemoryPaths.putFloat(P + "spd_cen_thr", it) }
        p.switch("Speed vertical ON", d.speedVerOn) { d.speedVerOn = it; MemoryPaths.putBool(P + "spd_ver_on", it) }
        p.seek("Speed vertical level", 0f, 1.5f, d.speedVerLv) { d.speedVerLv = it; MemoryPaths.putFloat(P + "spd_ver_lv", it) }
        p.seek("Speed vertical threshold", 0f, 0.98f, d.speedVerThr) { d.speedVerThr = it; MemoryPaths.putFloat(P + "spd_ver_thr", it) }
        p.switch("Waves centroid ON", d.waveCenOn) { d.waveCenOn = it; MemoryPaths.putBool(P + "wav_cen_on", it) }
        p.seek("Waves centroid level", 0f, 1.5f, d.waveCenLv) { d.waveCenLv = it; MemoryPaths.putFloat(P + "wav_cen_lv", it) }
        p.seek("Waves centroid threshold", 0f, 0.98f, d.waveCenThr) { d.waveCenThr = it; MemoryPaths.putFloat(P + "wav_cen_thr", it) }
        p.switch("Waves vertical ON", d.waveVerOn) { d.waveVerOn = it; MemoryPaths.putBool(P + "wav_ver_on", it) }
        p.seek("Waves vertical level", 0f, 1.5f, d.waveVerLv) { d.waveVerLv = it; MemoryPaths.putFloat(P + "wav_ver_lv", it) }
        p.seek("Waves vertical threshold", 0f, 0.98f, d.waveVerThr) { d.waveVerThr = it; MemoryPaths.putFloat(P + "wav_ver_thr", it) }

        p.title("CENTROID + VERTICAL → WHOLE BODY", gold)
        p.note("MOVEMENT follows the VERTICAL level · SPEED follows the CENTROID level · WAVES follow both · every one of the 84 body channels is lifted by how close it is to the live centroid · the LEFT and RIGHT eye balls look at the centroid (vertical lifts the gaze, the bipolar centroid opens / closes the pupils). Level · threshold · bipolar · RAW are the ones set on the board above; RAW COMPLETE passes everything straight through.")
        p.switch("Centroid drive ON", d.enabled) { d.enabled = it; MemoryPaths.putBool(P + "drv_on", it) }
        p.switch("RAW COMPLETE drive (no smoothing)", d.raw) { d.raw = it }
        p.switch("Body MOVEMENT ← vertical", d.moveOn) { d.moveOn = it; MemoryPaths.putBool(P + "drv_move_on", it) }
        p.seek("Movement amount", 0f, 1.5f, d.moveAmt) { d.moveAmt = it; MemoryPaths.putFloat(P + "drv_move", it) }
        p.switch("Body SPEED ← centroid", d.speedOn) { d.speedOn = it; MemoryPaths.putBool(P + "drv_speed_on", it) }
        p.seek("Speed amount", 0f, 1.5f, d.speedAmt) { d.speedAmt = it; MemoryPaths.putFloat(P + "drv_speed", it) }
        p.switch("Body WAVES ← centroid + vertical", d.waveOn) { d.waveOn = it; MemoryPaths.putBool(P + "drv_wave_on", it) }
        p.seek("Waves amount", 0f, 1.5f, d.waveAmt) { d.waveAmt = it; MemoryPaths.putFloat(P + "drv_wave", it) }
        p.switch("All 84 body ambient ← centroid + vertical", d.channelsOn) { d.channelsOn = it; MemoryPaths.putBool(P + "drv_ch_on", it) }
        p.seek("84 body ambient amount", 0f, 1.5f, d.channelAmt) { d.channelAmt = it; MemoryPaths.putFloat(P + "drv_ch", it) }
        p.switch("EYE BALLS L / R look at the centroid", d.eyesOn) { d.eyesOn = it; MemoryPaths.putBool(P + "drv_eyes_on", it) }
        p.seek("Eye turn range", 0.2f, 2f, d.gazeRange) { d.gazeRange = it; MemoryPaths.putFloat(P + "drv_gaze_range", it) }
        p.seek("Eye follow speed", 0.05f, 1f, d.gazeFollow) { d.gazeFollow = it; MemoryPaths.putFloat(P + "drv_gaze_follow", it) }
        p.title("INDEPENDENT EYE GAZE · L / R", cyan)
        p.note("Each eye follows the live body-centroid target. Set its rotation level and gaze-position bias separately; these move gaze, not the eye sockets. Position is normalized X/Y (−1…+1).")
        p.seek("Left eye rotation level", 0f, 2f, d.gazeLRotationLevel) {
            d.gazeLRotationLevel = it; MemoryPaths.putFloat(P + "gaze_l_level", it)
        }
        p.seek("Left eye gaze position X", -1f, 1f, d.gazeLPositionX) {
            d.gazeLPositionX = it; MemoryPaths.putFloat(P + "gaze_l_x", it)
        }
        p.seek("Left eye gaze position Y", -1f, 1f, d.gazeLPositionY) {
            d.gazeLPositionY = it; MemoryPaths.putFloat(P + "gaze_l_y", it)
        }
        p.seek("Right eye rotation level", 0f, 2f, d.gazeRRotationLevel) {
            d.gazeRRotationLevel = it; MemoryPaths.putFloat(P + "gaze_r_level", it)
        }
        p.seek("Right eye gaze position X", -1f, 1f, d.gazeRPositionX) {
            d.gazeRPositionX = it; MemoryPaths.putFloat(P + "gaze_r_x", it)
        }
        p.seek("Right eye gaze position Y", -1f, 1f, d.gazeRPositionY) {
            d.gazeRPositionY = it; MemoryPaths.putFloat(P + "gaze_r_y", it)
        }
        p.button("Center both eye-gaze positions") {
            d.gazeLPositionX = 0f; d.gazeLPositionY = 0f
            d.gazeRPositionX = 0f; d.gazeRPositionY = 0f
            MemoryPaths.putFloat(P + "gaze_l_x", 0f); MemoryPaths.putFloat(P + "gaze_l_y", 0f)
            MemoryPaths.putFloat(P + "gaze_r_x", 0f); MemoryPaths.putFloat(P + "gaze_r_y", 0f)
        }
        val st2 = p.status("CENTROID DRIVE —", gold)

        p.title("3D BODY VIEW · WHOLE MODEL + INSIDE LAYERS", cyan)
        p.note("The silhouette, face/eyes, organs, skeleton, vessels and body channels share one turntable. Mic readings are phone-input levels, not a spatial mic locator or calibrated sound-pressure meter.")
        val a = view.anatomy3d
        a.setRawAll(MemoryPaths.getBool(P + "anatomy_raw", a.rawAll))
        a.posX = MemoryPaths.getFloat(P + "body_x", a.posX).coerceIn(0f, 1f)
        a.posY = MemoryPaths.getFloat(P + "body_y", a.posY).coerceIn(0f, 1f)
        a.tilt = MemoryPaths.getFloat(P + "body_tilt", a.tilt).coerceIn(-0.6f, 0.6f)
        a.yaw = MemoryPaths.getFloat(P + "body_yaw", a.yaw).coerceIn(-3.142f, 3.142f)
        val savedView = MemoryPaths.getString(P + "body_view", a.viewPreset) ?: a.viewPreset
        when (savedView) {
            "Auto" -> a.enableAutoView()
            "Manual" -> { a.yawAuto = false; a.viewPreset = "Manual" }
            else -> a.selectViewPreset(savedView)
        }
        val autoView = p.switch("Automatic body rotation", a.yawAuto) {
            if (it) a.enableAutoView() else {
                a.yawAuto = false
                if (a.viewPreset == "Auto") a.viewPreset = "Manual"
            }
            MemoryPaths.putString(P + "body_view", a.viewPreset)
        }
        fun chooseView(name: String) {
            a.selectViewPreset(name)
            if (autoView.isChecked) autoView.isChecked = false
            MemoryPaths.putString(P + "body_view", name)
        }
        p.button("Front view") { chooseView("Front") }
        p.button("Back view") { chooseView("Back") }
        p.button("Left profile") { chooseView("Left") }
        p.button("Right profile") { chooseView("Right") }
        p.button("Resume automatic rotation") {
            autoView.isChecked = true
            MemoryPaths.putString(P + "body_view", "Auto")
        }
        p.seek("Body yaw", -3.142f, 3.142f, a.yaw) {
            a.yawAuto = false
            a.viewPreset = "Manual"
            if (autoView.isChecked) autoView.isChecked = false
            a.yaw = it
            MemoryPaths.putFloat(P + "body_yaw", it)
            MemoryPaths.putString(P + "body_view", "Manual")
        }
        p.seek("Body tilt", -0.6f, 0.6f, a.tilt) {
            a.tilt = it; MemoryPaths.putFloat(P + "body_tilt", it)
        }
        p.seek("Body rotation speed", 0f, 1f, a.yawSpeed) { a.yawSpeed = it }
        p.seek("Body screen position X", 0f, 1f, a.posX) {
            a.posX = it; MemoryPaths.putFloat(P + "body_x", it)
        }
        p.seek("Body screen position Y", 0f, 1f, a.posY) {
            a.posY = it; MemoryPaths.putFloat(P + "body_y", it)
        }
        p.switch("RAW COMPLETE · reveal inside + outside anatomy", a.rawAll) {
            a.setRawAll(it)
            MemoryPaths.putBool(P + "anatomy_raw", it)
        }

        p.title("3D GAME WORLD · SAME COMPLETE 3D BODY", gold)
        val g = view.gameWorld
        g.anatomyOn = MemoryPaths.getBool(P + "game_anatomy", g.anatomyOn)
        g.anatomyInside = MemoryPaths.getBool(P + "game_inside", g.anatomyInside)
        p.switch("Game figures = the full 3D anatomy body (eyes included)", g.anatomyOn) { g.anatomyOn = it; MemoryPaths.putBool(P + "game_anatomy", it) }
        p.switch("Show inside layers in the game figures", g.anatomyInside) { g.anatomyInside = it; MemoryPaths.putBool(P + "game_inside", it) }

        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                st.text = b.liveLine()
                st2.text = d.statusLine()
                domStatus.text = "DOM ${b.dominationHz.toInt()}Hz out=${(b.dominationOut*100).toInt()}% thr=${(b.dominationThr*100).toInt()}% ${if (b.dominationHit) "HIT" else "idle"}${if (b.dominationRaw) " · RAW" else ""}"
                h.postDelayed(this, 200)
            }
        })
    }
}
