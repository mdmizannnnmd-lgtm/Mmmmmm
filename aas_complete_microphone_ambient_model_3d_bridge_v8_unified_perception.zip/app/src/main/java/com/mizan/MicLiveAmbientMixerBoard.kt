package com.mizan

/**
 * Live microphone ambient mixer — feeds all ambient-related boards.
 * Master mic live ambient · mix levels · routes into skin/bio/atom/protect/master.
 * RAW COMPLETE.
 */
class MicLiveAmbientMixerBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    @Volatile var micLiveOn = true
    @Volatile var micLiveThr = 0.12f
    @Volatile var micLiveLv = 1.0f
    @Volatile var micLiveOut = 0f

    // Mixers (0..1.5)
    @Volatile var mixSkin = 1.0f
    @Volatile var mixBio = 1.0f
    @Volatile var mixGland = 1.0f
    @Volatile var mixChem = 1.0f
    @Volatile var mixAtom = 1.0f
    @Volatile var mixProtect = 1.0f
    @Volatile var mixMaster = 1.0f
    @Volatile var mixEar = 1.0f
    @Volatile var mixEye = 1.0f
    @Volatile var mixMotion = 0.85f

    @Volatile var routeSkin = 0f
    @Volatile var routeBio = 0f
    @Volatile var routeAtom = 0f
    @Volatile var routeProtect = 0f
    @Volatile var routeMaster = 0f
    @Volatile var routeAll = 0f

    @Volatile var status = "MIC LIVE AMBIENT MIX idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1.5f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1.5f) else 0f
    }

    fun tick(mic: Float) {
        if (!enabled) {
            status = "MIC LIVE MIX OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        micLiveOut = lane(micLiveOn, micLiveThr, micLiveLv, e)
        routeSkin = (micLiveOut * mixSkin).coerceIn(0f, 1.5f)
        routeBio = (micLiveOut * mixBio).coerceIn(0f, 1.5f)
        routeAtom = (micLiveOut * mixAtom).coerceIn(0f, 1.5f)
        routeProtect = (micLiveOut * mixProtect).coerceIn(0f, 1.5f)
        routeMaster = (micLiveOut * mixMaster).coerceIn(0f, 1.5f)
        routeAll = maxOf(routeSkin, routeBio, routeAtom, routeProtect, routeMaster,
            micLiveOut * mixGland, micLiveOut * mixChem, micLiveOut * mixEar, micLiveOut * mixEye)

        status =
            "MIC-LIVE=${(micLiveOut*100).toInt()}% · " +
            "MIX skin/bio/atom/prot/mast=${(routeSkin*100).toInt()}/${(routeBio*100).toInt()}/${(routeAtom*100).toInt()}/${(routeProtect*100).toInt()}/${(routeMaster*100).toInt()}% · " +
            "ALL=${(routeAll*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled || micLiveOut < 0.01f) return
        val m = micLiveOut
        try {
            v.allBodySkinAnatomy.allSkinOut = maxOf(v.allBodySkinAnatomy.allSkinOut, routeSkin * 0.5f)
            v.allBodySkinAnatomy.completeSkinCoverage = maxOf(v.allBodySkinAnatomy.completeSkinCoverage, routeSkin * 0.45f)
            v.skinMultiMotion.skinAmbientOut = maxOf(v.skinMultiMotion.skinAmbientOut, routeSkin * 0.4f)
            v.skinAll.atmosphere = maxOf(v.skinAll.atmosphere, routeSkin * 0.35f)
        } catch (_: Throwable) {}
        try {
            v.bioSkinCell.bioFullOut = maxOf(v.bioSkinCell.bioFullOut, routeBio * 0.45f)
            v.bioSkinCell.glandsFullOut = maxOf(v.bioSkinCell.glandsFullOut, m * mixGland * 0.4f)
        } catch (_: Throwable) {}
        try {
            v.bodyChemBrain.chemFullOut = maxOf(v.bodyChemBrain.chemFullOut, m * mixChem * 0.4f)
            v.bodyChemBrain.brainFullOut = maxOf(v.bodyChemBrain.brainFullOut, m * mixChem * 0.35f)
        } catch (_: Throwable) {}
        try {
            v.completeAtomProtect.atomOutsideOut = maxOf(v.completeAtomProtect.atomOutsideOut, routeAtom * 0.4f)
            v.completeAtomProtect.atomInsideOut = maxOf(v.completeAtomProtect.atomInsideOut, routeAtom * 0.4f)
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, routeAtom * 0.45f)
        } catch (_: Throwable) {}
        try {
            v.fullAmbientMaster.ambientAll = maxOf(v.fullAmbientMaster.ambientAll, routeMaster * 0.5f)
            v.fullAmbientMaster.atomFull = maxOf(v.fullAmbientMaster.atomFull, routeAtom * 0.4f)
            v.fullAmbientMaster.skinFullOut = maxOf(v.fullAmbientMaster.skinFullOut, routeSkin * 0.4f)
        } catch (_: Throwable) {}
        try {
            v.earAuditoryLine.earLineFull = maxOf(v.earAuditoryLine.earLineFull, m * mixEar * 0.5f)
            v.eyesCompleteLock.eyesFullOut = maxOf(v.eyesCompleteLock.eyesFullOut, m * mixEye * 0.45f)
        } catch (_: Throwable) {}
        try {
            v.bodyRegionEnemyProtect.protectOut = maxOf(v.bodyRegionEnemyProtect.protectOut, routeProtect * 0.35f)
            v.antiAtomspareSounds.antiOut = maxOf(v.antiAtomspareSounds.antiOut, routeProtect * 0.3f)
            v.enemySoundCounters.liveMic = maxOf(v.enemySoundCounters.liveMic, m)
        } catch (_: Throwable) {}
        try {
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, routeAll * 0.25f)
            val mv = (m * mixMotion).coerceIn(0f, 1f)
            v.skinMultiMotion.moveOut = maxOf(v.skinMultiMotion.moveOut * 0.9f, mv * 0.3f)
        } catch (_: Throwable) {}
        try {
            v.skeletonWaterAstro.waterOut = maxOf(v.skeletonWaterAstro.waterOut, m * 0.25f)
            v.caMgProtectChem.waterOut = maxOf(v.caMgProtectChem.waterOut, m * 0.2f)
        } catch (_: Throwable) {}
    }
}
