package com.mizan

/**
 * Human body chemical composition ambient + brain & meninges ambient.
 * CHON · minerals · water · biomolecules · vitamins · ions ·
 * meninges (dura/arachnoid/pia) · CSF · lobes · brainstem · cranial.
 * Symbolic visualization only — not medical diagnosis. RAW COMPLETE.
 */
class BodyChemBrainAmbientBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.20f
    @Volatile var lv = 0.85f

    // Chemical composition
    @Volatile var chemOn = true
    @Volatile var water = 0f
    @Volatile var protein = 0f
    @Volatile var lipid = 0f
    @Volatile var mineral = 0f
    @Volatile var carb = 0f
    // CHON
    @Volatile var oxygenE = 0f
    @Volatile var carbonE = 0f
    @Volatile var hydrogenE = 0f
    @Volatile var nitrogenE = 0f
    // Macro minerals
    @Volatile var calcium = 0f
    @Volatile var phosphorus = 0f
    @Volatile var potassium = 0f
    @Volatile var sodium = 0f
    @Volatile var magnesium = 0f
    @Volatile var sulfur = 0f
    @Volatile var chlorine = 0f
    // Trace
    @Volatile var iron = 0f
    @Volatile var iodine = 0f
    @Volatile var zinc = 0f
    // Biomolecules
    @Volatile var glycogen = 0f
    @Volatile var phospholipid = 0f
    @Volatile var steroid = 0f
    @Volatile var atp = 0f
    // Vitamins (symbolic)
    @Volatile var vitA = 0f
    @Volatile var vitD = 0f
    @Volatile var vitC = 0f
    @Volatile var vitB12 = 0f
    // Ions / pH path
    @Volatile var ionBalance = 0f

    // Brain & meninges
    @Volatile var brainOn = true
    @Volatile var duraMater = 0f
    @Volatile var arachnoid = 0f
    @Volatile var piaMater = 0f
    @Volatile var csf = 0f
    @Volatile var cerebrum = 0f
    @Volatile var frontalLobe = 0f
    @Volatile var parietalLobe = 0f
    @Volatile var temporalLobe = 0f
    @Volatile var occipitalLobe = 0f
    @Volatile var cerebellum = 0f
    @Volatile var thalamus = 0f
    @Volatile var hypothalamus = 0f
    @Volatile var pineal = 0f
    @Volatile var brainstem = 0f
    @Volatile var medulla = 0f
    @Volatile var pons = 0f
    @Volatile var midbrain = 0f
    @Volatile var greyMatter = 0f
    @Volatile var whiteMatter = 0f
    @Volatile var circleOfWillis = 0f
    @Volatile var bbb = 0f  // blood-brain barrier symbolic

    @Volatile var chemFullOut = 0f
    @Volatile var brainFullOut = 0f
    @Volatile var status = "CHEM·BRAIN ambient idle"

    private fun lane(on: Boolean, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float) {
        if (!enabled) {
            status = "CHEM·BRAIN OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)

        water = lane(chemOn, e)
        protein = lane(chemOn, e * 0.95f)
        lipid = lane(chemOn, e * 0.92f)
        mineral = lane(chemOn, e * 0.88f)
        carb = lane(chemOn, e * 0.85f)
        oxygenE = water * 0.98f
        carbonE = protein * 0.95f
        hydrogenE = water * 0.96f
        nitrogenE = protein * 0.90f
        calcium = mineral * 0.95f
        phosphorus = mineral * 0.92f
        potassium = mineral * 0.90f
        sodium = mineral * 0.88f
        magnesium = mineral * 0.86f
        sulfur = mineral * 0.84f
        chlorine = mineral * 0.85f
        iron = mineral * 0.82f
        iodine = mineral * 0.80f
        zinc = mineral * 0.81f
        glycogen = carb * 0.9f
        phospholipid = lipid * 0.92f
        steroid = lipid * 0.85f
        atp = maxOf(carb, oxygenE) * 0.9f
        vitA = lane(chemOn, e * 0.8f)
        vitD = lane(chemOn, e * 0.78f)
        vitC = lane(chemOn, e * 0.82f)
        vitB12 = lane(chemOn, e * 0.77f)
        ionBalance = maxOf(sodium, potassium, calcium) * 0.9f
        chemFullOut = maxOf(water, protein, lipid, mineral, atp)

        // Meninges outside → in: dura → arachnoid → pia
        duraMater = lane(brainOn, e * 0.94f)
        arachnoid = lane(brainOn, e * 0.92f)
        piaMater = lane(brainOn, e * 0.95f)
        csf = lane(brainOn, e * 0.90f)
        cerebrum = lane(brainOn, e)
        frontalLobe = cerebrum * 0.96f
        parietalLobe = cerebrum * 0.94f
        temporalLobe = cerebrum * 0.93f
        occipitalLobe = cerebrum * 0.92f
        cerebellum = lane(brainOn, e * 0.93f)
        thalamus = lane(brainOn, e * 0.91f)
        hypothalamus = lane(brainOn, e * 0.90f)
        midbrain = lane(brainOn, e * 0.88f)
        pons = lane(brainOn, e * 0.89f)
        medulla = lane(brainOn, e * 0.91f)
        brainstem = maxOf(midbrain, pons, medulla)
        greyMatter = cerebrum * 0.95f
        whiteMatter = cerebrum * 0.92f
        circleOfWillis = lane(brainOn, e * 0.87f)
        bbb = lane(brainOn, e * 0.86f)
        brainFullOut = maxOf(cerebrum, cerebellum, brainstem, piaMater, csf)

        status =
            "H2O/PROT/LIP=${(water*100).toInt()}/${(protein*100).toInt()}/${(lipid*100).toInt()}% · " +
            "CHON O/C=${(oxygenE*100).toInt()}/${(carbonE*100).toInt()} · ATP=${(atp*100).toInt()}% · " +
            "MENINGES D/A/P=${(duraMater*100).toInt()}/${(arachnoid*100).toInt()}/${(piaMater*100).toInt()} · " +
            "CSF=${(csf*100).toInt()}% CEREB=${(cerebrum*100).toInt()}% STEM=${(brainstem*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        try {
            v.bioSkinCell.plasma = maxOf(v.bioSkinCell.plasma, water * 0.5f)
            v.bioSkinCell.hemoglobin = maxOf(v.bioSkinCell.hemoglobin, iron * 0.6f)
            v.bioSkinCell.dnaOut = maxOf(v.bioSkinCell.dnaOut, nitrogenE * 0.5f, carbonE * 0.4f)
            v.bioSkinCell.rnaOut = maxOf(v.bioSkinCell.rnaOut, nitrogenE * 0.45f)
            v.bioSkinCell.meninges = maxOf(v.bioSkinCell.meninges, duraMater, arachnoid, piaMater)
            v.bioSkinCell.nucleus = maxOf(v.bioSkinCell.nucleus, greyMatter * 0.5f)
        } catch (_: Throwable) {}
        try {
            val a = v.anatomy3d
            if (a.layerOn.size > 5) {
                a.layerOn[5] = true
                a.layerLevel[5] = maxOf(a.layerLevel[5], brainFullOut, piaMater)
            }
            if (a.layerOn.size > 2) {
                a.layerOn[2] = true // skeleton — minerals/Ca
                a.layerLevel[2] = maxOf(a.layerLevel[2], calcium, phosphorus * 0.8f)
            }
            a.atmosphere = maxOf(a.atmosphere, brainFullOut * 0.6f, chemFullOut * 0.4f)
        } catch (_: Throwable) {}
        try {
            v.bodyFreqRegen.brainFullOut = maxOf(v.bodyFreqRegen.brainFullOut, brainFullOut)
            v.bodyFreqRegen.brainLHemOut = maxOf(v.bodyFreqRegen.brainLHemOut, frontalLobe * 0.9f)
            v.bodyFreqRegen.brainRHemOut = maxOf(v.bodyFreqRegen.brainRHemOut, parietalLobe * 0.9f)
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, duraMater * 0.4f, cerebrum * 0.3f)
        } catch (_: Throwable) {}
        try {
            v.completeAtomProtect.atomInsideOut = maxOf(v.completeAtomProtect.atomInsideOut, brainFullOut * 0.5f, water * 0.3f)
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, chemFullOut * 0.4f)
        } catch (_: Throwable) {}
    }
}
