package com.mizan

/**
 * Complete **body-part segmentation** catalog for RAW COMPLETE human 3D.
 *
 * SMPL body joints (24) + common human-parse classes used by YOLO-seg /
 * DensePose-style part labels. Not a full 2,900-mesh medical atlas —
 * this is the real-time complete set for SenseGuard.
 *
 * SMPL joints: Meshcapade / SMPL family standard.
 * Parse classes: head · hair · face · torso · arms · hands · legs · feet (+ clothing optional).
 */
object SmplBodyParts {
    /** SMPL 24 joints (body part anchors). */
    val SMPL24 = arrayOf(
        "pelvis", "left_hip", "right_hip", "spine1", "left_knee", "right_knee",
        "spine2", "left_ankle", "right_ankle", "spine3", "left_foot", "right_foot",
        "neck", "left_collar", "right_collar", "head",
        "left_shoulder", "right_shoulder", "left_elbow", "right_elbow",
        "left_wrist", "right_wrist", "left_hand", "right_hand"
    )

    /**
     * Dense / YOLO human-parse style **surface segments** (complete body, not single blob).
     * Aligns with coco_body_part + fashion parse labels.
     */
    val PARSE = arrayOf(
        "person",
        "head",
        "hair",
        "face",
        "neck",
        "torso",
        "chest",
        "abdomen",
        "upper_arm_l", "upper_arm_r",
        "lower_arm_l", "lower_arm_r",
        "hand_l", "hand_r",
        "upper_leg_l", "upper_leg_r",
        "lower_leg_l", "lower_leg_r",
        "foot_l", "foot_r",
        "eye_l", "eye_r",
        "outfit" // optional clothing shell
    )

    /** 15-part mesh recovery style (HPPM / SMPL face groups). */
    val PART15 = arrayOf(
        "head", "chest", "abdomen",
        "left_thigh", "right_thigh", "left_calf", "right_calf",
        "left_foot", "right_foot",
        "left_upper_arm", "right_upper_arm", "left_forearm", "right_forearm",
        "left_hand", "right_hand"
    )

    const val SMPL_COUNT = 24
    const val PARSE_COUNT = 23
    const val PART15_COUNT = 15
}
