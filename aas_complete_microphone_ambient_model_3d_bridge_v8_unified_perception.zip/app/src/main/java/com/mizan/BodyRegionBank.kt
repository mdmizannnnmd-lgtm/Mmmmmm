package com.mizan

/**
 * Body region bank — shared presets / copy for VisualShieldView.Region slots.
 * Fixes unresolved copyFrom used by region bank sync.
 */
class BodyRegionBank {

    val template = VisualShieldView.Region()

    val eyes = VisualShieldView.Region(ambient = 0.70f)
    val face = VisualShieldView.Region(ambient = 0.62f)
    val forehead = VisualShieldView.Region(ambient = 0.60f)
    val nose = VisualShieldView.Region(ambient = 0.58f)
    val brain = VisualShieldView.Region()
    val heart = VisualShieldView.Region()
    val neck = VisualShieldView.Region()
    val belly = VisualShieldView.Region()
    val handL = VisualShieldView.Region()
    val handR = VisualShieldView.Region()
    val pussy = VisualShieldView.Region(ambient = 0.50f)
    val dick = VisualShieldView.Region(ambient = 0.50f)
    val tongue = VisualShieldView.Region(ambient = 0.55f)
    val lipU = VisualShieldView.Region(ambient = 0.58f)
    val lipL = VisualShieldView.Region(ambient = 0.58f)
    val ass = VisualShieldView.Region(ambient = 0.50f)
    val legL = VisualShieldView.Region(ambient = 0.52f)
    val legR = VisualShieldView.Region(ambient = 0.52f)

    fun all(): List<VisualShieldView.Region> = listOf(
        eyes, face, forehead, nose, lipU, lipL, tongue, brain, heart, neck, belly, handL, handR, pussy, dick, ass, legL, legR
    )

    /** Apply template settings onto every region */
    fun applyTemplateToAll() {
        for (r in all()) r.copyFrom(template)
    }

    /** Copy one region onto another */
    fun copyRegion(from: VisualShieldView.Region, to: VisualShieldView.Region) {
        to.copyFrom(from)
    }

    /** Sync bank from live VisualShieldView region objects */
    fun pullFrom(v: VisualShieldView) {
        eyes.copyFrom(v.eyes)
        face.copyFrom(v.face)
        forehead.copyFrom(v.forehead)
        nose.copyFrom(v.nose)
        brain.copyFrom(v.brain)
        heart.copyFrom(v.heart)
        neck.copyFrom(v.neck)
        belly.copyFrom(v.belly)
        handL.copyFrom(v.handL)
        handR.copyFrom(v.handR)
        pussy.copyFrom(v.pussy)
        dick.copyFrom(v.dick)
        tongue.copyFrom(v.tongue)
        lipU.copyFrom(v.lipU)
        lipL.copyFrom(v.lipL)
        ass.copyFrom(v.ass)
        legL.copyFrom(v.legL)
        legR.copyFrom(v.legR)
    }

    /** Push bank settings into live VisualShieldView */
    fun pushTo(v: VisualShieldView) {
        v.eyes.copyFrom(eyes)
        v.face.copyFrom(face)
        v.forehead.copyFrom(forehead)
        v.nose.copyFrom(nose)
        v.brain.copyFrom(brain)
        v.heart.copyFrom(heart)
        v.neck.copyFrom(neck)
        v.belly.copyFrom(belly)
        v.handL.copyFrom(handL)
        v.handR.copyFrom(handR)
        v.pussy.copyFrom(pussy)
        v.dick.copyFrom(dick)
        v.tongue.copyFrom(tongue)
        v.lipU.copyFrom(lipU)
        v.lipL.copyFrom(lipL)
        v.ass.copyFrom(ass)
        v.legL.copyFrom(legL)
        v.legR.copyFrom(legR)
    }

    fun statusLine(): String {
        val avg = all().map { it.effectiveAmbient() }.average().toFloat()
        return "BODY-BANK avgAmb=${(avg * 100).toInt()}% regions=${all().size}"
    }
}
