package com.mizan

/**
 * Body armor — hold · spikes · decay for bullet / knife / fire / missile / boom.
 * EMF · NFC · BLE · physical audio · hardware.
 * Logical raw-mode magnitude gate (on-device). Not physical plate armor.
 */
class BodyArmorShield {

    enum class Kind { BULLET, KNIFE, FIRE, MISSILE, BOOM }

    class Lane(
        var on: Boolean = true,
        var level: Float = 0.85f,
        var holdMs: Long = 400L,
        var decayMs: Long = 600L,
        var spikeThr: Float = 0.45f,
        var holdUntil: Long = 0L,
        var spikes: Int = 0,
        var lastMag: Float = 0f,
        var active: Boolean = false
    )

    val bullet = Lane(level = 0.85f, holdMs = 350, decayMs = 500, spikeThr = 0.45f)
    val knife = Lane(level = 0.85f, holdMs = 300, decayMs = 450, spikeThr = 0.40f)
    val fire = Lane(level = 0.85f, holdMs = 800, decayMs = 1200, spikeThr = 0.50f)
    val missile = Lane(level = 0.90f, holdMs = 500, decayMs = 900, spikeThr = 0.70f)
    val boom = Lane(level = 0.88f, holdMs = 600, decayMs = 1000, spikeThr = 0.60f)

    // legacy switches mirror lanes
    var bulletproofOn: Boolean
        get() = bullet.on
        set(v) { bullet.on = v }
    var knifeProofOn: Boolean
        get() = knife.on
        set(v) { knife.on = v }
    var fireProofOn: Boolean
        get() = fire.on
        set(v) { fire.on = v }
    var missileProofOn: Boolean
        get() = missile.on
        set(v) { missile.on = v }
    var boomProofOn: Boolean
        get() = boom.on
        set(v) { boom.on = v }

    var bulletproofLv: Float
        get() = bullet.level
        set(v) { bullet.level = v.coerceIn(0.05f, 1f) }
    var knifeProofLv: Float
        get() = knife.level
        set(v) { knife.level = v.coerceIn(0.05f, 1f) }
    var fireProofLv: Float
        get() = fire.level
        set(v) { fire.level = v.coerceIn(0.05f, 1f) }
    var missileProofLv: Float
        get() = missile.level
        set(v) { missile.level = v.coerceIn(0.05f, 1f) }
    var boomProofLv: Float
        get() = boom.level
        set(v) { boom.level = v.coerceIn(0.05f, 1f) }

    @Volatile var emfShieldOn = true
    @Volatile var emfLv = 0.70f
    @Volatile var nfcShieldOn = true
    @Volatile var nfcLv = 0.70f
    @Volatile var bleShieldOn = true
    @Volatile var bleLv = 0.70f
    @Volatile var magicShieldOn = true
    @Volatile var magicLv = 0.60f
    @Volatile var audioShieldOn = true
    @Volatile var audioLv = 0.80f
    @Volatile var hardwareShieldOn = true
    @Volatile var hardwareLv = 0.75f
    @Volatile var physicalAudioOn = true
    @Volatile var physicalAudioLv = 0.75f

    @Volatile var lastSpikeMag = 0f
    @Volatile var lastClampedMag = 0f
    @Volatile var blockCount = 0
    @Volatile var lastPhysicalClass = "idle"

    /** Global hold/decay ms applied when user adjusts (all lanes get proportional update). */
    fun setHoldMsAll(ms: Int) {
        val v = ms.coerceIn(50, 5000).toLong()
        bullet.holdMs = v; knife.holdMs = (v * 0.85f).toLong()
        fire.holdMs = (v * 1.6f).toLong(); missile.holdMs = (v * 1.2f).toLong()
        boom.holdMs = (v * 1.3f).toLong()
    }

    fun setDecayMsAll(ms: Int) {
        val v = ms.coerceIn(50, 8000).toLong()
        bullet.decayMs = v; knife.decayMs = (v * 0.9f).toLong()
        fire.decayMs = (v * 1.8f).toLong(); missile.decayMs = (v * 1.4f).toLong()
        boom.decayMs = (v * 1.5f).toLong()
    }

    private fun now() = System.currentTimeMillis()

    /** Update lane: spike detect → hold → decay envelope. Returns absorb factor 0…1. */
    private fun processLane(lane: Lane, mag: Float, kind: Kind): Float {
        if (!lane.on) return 0f
        val t = now()
        lane.lastMag = mag
        if (mag >= lane.spikeThr) {
            lane.spikes++
            lane.holdUntil = t + lane.holdMs
            lane.active = true
            blockCount++
        }
        if (lane.active) {
            if (t <= lane.holdUntil) {
                // full hold absorb
                return lane.level.coerceIn(0.05f, 1f)
            }
            val after = t - lane.holdUntil
            if (after < lane.decayMs) {
                val frac = 1f - (after.toFloat() / lane.decayMs.toFloat())
                return (lane.level * frac).coerceIn(0f, 1f)
            }
            lane.active = false
        }
        // idle light damp
        return lane.level * 0.20f
    }

    fun clampSpikeMagnitude(raw: Float): Float {
        var m = raw.coerceIn(0f, 1f)
        lastSpikeMag = m

        val aMissile = processLane(missile, m, Kind.MISSILE)
        val aBoom = processLane(boom, m, Kind.BOOM)
        val aFire = processLane(fire, m, Kind.FIRE)
        val aBullet = processLane(bullet, m, Kind.BULLET)
        val aKnife = processLane(knife, m, Kind.KNIFE)

        // strongest active absorb wins for classification
        val absorbs = listOf(
            "missile" to aMissile,
            "boom" to aBoom,
            "fire" to aFire,
            "bullet" to aBullet,
            "knife" to aKnife
        )
        val top = absorbs.maxByOrNull { it.second }
        if (top != null && top.second > 0.25f) lastPhysicalClass = top.first

        m *= (1f - aMissile * 0.98f)
        m *= (1f - aBoom * 0.95f)
        m *= (1f - aFire * 0.92f)
        m *= (1f - aBullet * 0.92f)
        m *= (1f - aKnife * 0.90f)

        if (emfShieldOn) m *= (1f - emfLv * 0.25f)
        if (nfcShieldOn) m *= (1f - nfcLv * 0.20f)
        if (bleShieldOn) m *= (1f - bleLv * 0.20f)
        if (magicShieldOn) m *= (1f - magicLv * 0.15f)
        if (audioShieldOn) m *= (1f - audioLv * 0.45f)
        if (hardwareShieldOn) m *= (1f - hardwareLv * 0.40f)

        lastClampedMag = m.coerceIn(0f, 1f)
        if (lastSpikeMag - lastClampedMag < 0.05f) lastPhysicalClass = "idle"
        return lastClampedMag
    }

    fun effectiveThresholdDb(base: Int): Int {
        var t = base
        if (bullet.on) t += (12 * bullet.level).toInt()
        if (knife.on) t += (10 * knife.level).toInt()
        if (missile.on) t += (14 * missile.level).toInt()
        if (boom.on) t += (13 * boom.level).toInt()
        if (fire.on) t += (11 * fire.level).toInt()
        if (audioShieldOn) t += (8 * audioLv).toInt()
        if (emfShieldOn) t += (6 * emfLv).toInt()
        if (physicalAudioOn) t += (5 * physicalAudioLv).toInt()
        // active holds raise thr further
        if (bullet.active) t += 8
        if (knife.active) t += 6
        if (fire.active) t += 10
        if (missile.active) t += 12
        if (boom.active) t += 11
        return t.coerceIn(-100, 120)
    }

    fun physicalAudioLabel(): String {
        if (!physicalAudioOn) return "phys-audio off"
        val gap = (lastSpikeMag - lastClampedMag).coerceIn(0f, 1f)
        val loud = (gap * physicalAudioLv * 100).toInt()
        fun h(l: Lane) = if (l.active) "H" else if (l.on) "·" else "-"
        return "PHYS ${lastPhysicalClass.uppercase()} fx=$loud% " +
            "B${h(bullet)}${bullet.spikes} K${h(knife)}${knife.spikes} " +
            "F${h(fire)}${fire.spikes} M${h(missile)}${missile.spikes} O${h(boom)}${boom.spikes}"
    }

    fun statusLine(): String {
        fun tag(l: Lane, n: String) =
            if (!l.on) "${n.lowercase()}-off"
            else "$n${(l.level * 100).toInt()}${if (l.active) " HOLD" else ""}"
        return "ARMOR " +
            tag(bullet, "BP") + " " + tag(knife, "KN") + " " +
            tag(missile, "MS") + " " + tag(boom, "BM") + " " + tag(fire, "FR") + " " +
            "EMF${if (emfShieldOn) "ON" else "off"} NFC${if (nfcShieldOn) "ON" else "off"} " +
            "BLE${if (bleShieldOn) "ON" else "off"} " +
            "spike ${"%.0f".format(lastSpikeMag * 100)}→${"%.0f".format(lastClampedMag * 100)} " +
            physicalAudioLabel() + " blk=$blockCount"
    }
}
