package com.mizan

/**
 * Body-region enemy sound abuse protect · knife · boom · burst · spike · pitch ·
 * electric vibration · anti-vibration · any enemy SFX · live mic dB out/thr.
 * RAW COMPLETE.
 */
class BodyRegionEnemySoundProtectBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    @Volatile var protectOn = true
    @Volatile var protectThr = 0.20f
    @Volatile var protectLv = 0.95f
    @Volatile var protectOut = 0f

    // Per effect
    @Volatile var knifeProt = 0f
    @Volatile var boomProt = 0f
    @Volatile var burstProt = 0f
    @Volatile var spikeProt = 0f
    @Volatile var pitchProt = 0f
    @Volatile var electricVibeProt = 0f
    @Volatile var antiVibeOut = 0f

    // Body regions
    @Volatile var headProt = 0f
    @Volatile var torsoProt = 0f
    @Volatile var armLProt = 0f
    @Volatile var armRProt = 0f
    @Volatile var legLProt = 0f
    @Volatile var legRProt = 0f
    @Volatile var fullBodyProt = 0f

    // Eye regions
    @Volatile var eyeLProt = 0f
    @Volatile var eyeRProt = 0f
    @Volatile var eyesProt = 0f

    // Inside body regions
    @Volatile var insideOn = true
    @Volatile var insideThr = 0.20f
    @Volatile var insideLv = 0.92f
    @Volatile var insideProt = 0f
    @Volatile var insideHead = 0f
    @Volatile var insideChest = 0f
    @Volatile var insideBelly = 0f
    @Volatile var insideCore = 0f

    // Per-region thresholds (complete system)
    @Volatile var regionThr = 0.20f
    @Volatile var regionLv = 0.90f

    // Live mic dB
    @Volatile var micDbOn = true
    @Volatile var micDbThr = -40f      // dBFS-ish symbolic
    @Volatile var micDbLv = 0.9f
    @Volatile var micDbOut = 0f
    @Volatile var liveDb = -60f

    @Volatile var status = "BODY-REGION ENEMY SFX PROT idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        mic: Float,
        knife: Float,
        boom: Float,
        burst: Float,
        spike: Float,
        pitch: Float,
        vibe: Float,
        enemyAny: Float
    ) {
        if (!enabled) {
            status = "BODY-REGION PROT OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        // symbolic dBFS from energy
        liveDb = if (e < 1e-6f) -80f else (20f * kotlin.math.ln(e.coerceIn(1e-6f, 1f)) / kotlin.math.ln(10f)).coerceIn(-80f, 0f)
        val dbNorm = ((liveDb - (-80f)) / 80f).coerceIn(0f, 1f)
        micDbOut = if (!micDbOn && !rawComplete) 0f
        else if (rawComplete || liveDb >= micDbThr) (dbNorm * micDbLv).coerceIn(0f, 1f)
        else 0f

        knifeProt = lane(protectOn, protectThr, protectLv, knife)
        boomProt = lane(protectOn, protectThr, protectLv, boom)
        burstProt = lane(protectOn, protectThr, protectLv, burst)
        spikeProt = lane(protectOn, protectThr, protectLv, spike)
        pitchProt = lane(protectOn, protectThr, protectLv, pitch)
        electricVibeProt = lane(protectOn, protectThr, protectLv, vibe)
        antiVibeOut = lane(protectOn, protectThr, protectLv, maxOf(vibe, electricVibeProt))

        val anyE = maxOf(knife, boom, burst, spike, pitch, vibe, enemyAny, e * 0.5f)
        protectOut = lane(protectOn, protectThr, protectLv, anyE)

        headProt = protectOut * 1.0f
        torsoProt = protectOut * 0.98f
        armLProt = protectOut * 0.94f
        armRProt = protectOut * 0.94f
        legLProt = protectOut * 0.92f
        legRProt = protectOut * 0.92f
        fullBodyProt = maxOf(headProt, torsoProt, armLProt, armRProt, legLProt, legRProt, protectOut)

        eyeLProt = lane(protectOn, regionThr, regionLv, maxOf(protectOut * 0.95f, e * 0.7f))
        eyeRProt = lane(protectOn, regionThr, regionLv, maxOf(protectOut * 0.95f, e * 0.7f))
        eyesProt = maxOf(eyeLProt, eyeRProt)

        insideProt = lane(insideOn, insideThr, insideLv, maxOf(protectOut, enemyAny, e * 0.75f))
        insideHead = insideProt * 0.98f
        insideChest = insideProt * 0.96f
        insideBelly = insideProt * 0.94f
        insideCore = maxOf(insideHead, insideChest, insideBelly, insideProt)

        fullBodyProt = maxOf(fullBodyProt, eyesProt, insideCore)

        status =
            "PROT=${(protectOut*100).toInt()}% K/Boom/Br/Sp/P=${(knifeProt*100).toInt()}/${(boomProt*100).toInt()}/${(burstProt*100).toInt()}/${(spikeProt*100).toInt()}/${(pitchProt*100).toInt()} · " +
            "eVIBE/anti=${(electricVibeProt*100).toInt()}/${(antiVibeOut*100).toInt()} · " +
            "BODY H/T=${(headProt*100).toInt()}/${(torsoProt*100).toInt()} · " +
            "EYE L/R=${(eyeLProt*100).toInt()}/${(eyeRProt*100).toInt()} · " +
            "INSIDE=${(insideCore*100).toInt()}% · " +
            "MIC ${"%.1f".format(liveDb)} dB (thr ${"%.0f".format(micDbThr)}) out=${(micDbOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled) return
        if (protectOut > 0.02f) {
            val k = (1f - protectOut * 0.95f).coerceIn(0.03f, 1f)
            if (knifeProt > 0.02f) sb.knifeOut *= (1f - knifeProt * 0.96f).coerceIn(0.03f, 1f)
            if (burstProt > 0.02f) sb.burstOut *= (1f - burstProt * 0.96f).coerceIn(0.03f, 1f)
            if (boomProt > 0.02f) {
                sb.bulletOut *= (1f - boomProt * 0.95f).coerceIn(0.03f, 1f)
                sb.collideOut *= (1f - boomProt * 0.9f).coerceIn(0.03f, 1f)
            }
            sb.sharpOut *= (1f - maxOf(spikeProt, pitchProt) * 0.9f).coerceIn(0.05f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
            sb.whipOut *= k
            sb.rippleOut *= k
        }
        val vv = v ?: return
        try {
            vv.skinSoundsProtect.protectOut = maxOf(vv.skinSoundsProtect.protectOut, fullBodyProt)
            vv.skinSoundsProtect.knifeProt = maxOf(vv.skinSoundsProtect.knifeProt, knifeProt)
            vv.skinSoundsProtect.burstProt = maxOf(vv.skinSoundsProtect.burstProt, burstProt)
            vv.skinSoundsProtect.bulletProt = maxOf(vv.skinSoundsProtect.bulletProt, boomProt)
            vv.skinSoundsProtect.pitchProt = maxOf(vv.skinSoundsProtect.pitchProt, pitchProt)
        } catch (_: Throwable) {}
        try {
            vv.enemySoundCancel.knifeCancelOut = maxOf(vv.enemySoundCancel.knifeCancelOut, knifeProt)
            vv.enemySoundCancel.burstCancelOut = maxOf(vv.enemySoundCancel.burstCancelOut, burstProt)
            vv.enemySoundCancel.atomEnemyCancelOut = maxOf(vv.enemySoundCancel.atomEnemyCancelOut, fullBodyProt)
        } catch (_: Throwable) {}
        try {
            vv.sharpBurstMeter.antiKnifeOut = maxOf(vv.sharpBurstMeter.antiKnifeOut, knifeProt)
            vv.sharpBurstMeter.antiBulletOut = maxOf(vv.sharpBurstMeter.antiBulletOut, boomProt)
        } catch (_: Throwable) {}
        try {
            vv.mgBleScaleWatt.vibeOut = maxOf(vv.mgBleScaleWatt.vibeOut * (1f - antiVibeOut * 0.8f), 0f)
            vv.fullAmbientMaster.spikeOut = maxOf(vv.fullAmbientMaster.spikeOut, spikeProt * 0.3f)
            vv.fullAmbientMaster.pitchOut = maxOf(vv.fullAmbientMaster.pitchOut, pitchProt * 0.3f)
        } catch (_: Throwable) {}
        try {
            vv.skinHead.atmosphere = maxOf(vv.skinHead.atmosphere, headProt * 0.35f, insideHead * 0.3f)
            try {
                vv.eyeL.atmosphere = maxOf(vv.eyeL.atmosphere, eyeLProt * 0.4f)
                vv.eyeR.atmosphere = maxOf(vv.eyeR.atmosphere, eyeRProt * 0.4f)
                vv.eyes.atmosphere = maxOf(vv.eyes.atmosphere, eyesProt * 0.4f)
            } catch (_: Throwable) {}
            try {
                vv.belly.atmosphere = maxOf(vv.belly.atmosphere, insideBelly * 0.35f)
                vv.heart.atmosphere = maxOf(vv.heart.atmosphere, insideChest * 0.35f)
            } catch (_: Throwable) {}
            vv.skinChest.atmosphere = maxOf(vv.skinChest.atmosphere, torsoProt * 0.35f)
            vv.skinArmL.atmosphere = maxOf(vv.skinArmL.atmosphere, armLProt * 0.3f)
            vv.skinArmR.atmosphere = maxOf(vv.skinArmR.atmosphere, armRProt * 0.3f)
            vv.skinLegL.atmosphere = maxOf(vv.skinLegL.atmosphere, legLProt * 0.3f)
            vv.skinLegR.atmosphere = maxOf(vv.skinLegR.atmosphere, legRProt * 0.3f)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, fullBodyProt)
            vv.completeAtomProtect.atomInsideOut = maxOf(vv.completeAtomProtect.atomInsideOut, insideCore)
            try {
                vv.antiAtomspareSounds.antiInside = maxOf(vv.antiAtomspareSounds.antiInside, insideCore)
                vv.antiAtomspareSounds.antiOut = maxOf(vv.antiAtomspareSounds.antiOut, fullBodyProt * 0.7f)
            } catch (_: Throwable) {}
            try {
                vv.skinSoundsProtect.protectOut = maxOf(vv.skinSoundsProtect.protectOut, fullBodyProt)
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}
    }
}
