package com.mizan

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

/** Controls for [ScreenEchoMic]: screen echo centroid · vertical and the live microphone echo · centroid · vertical. */
object ScreenEchoPanels {
    private const val P = "secho_"

    fun build(ctx: Context, root: LinearLayout, e: ScreenEchoMic) {
        val p = PanelBuilder(ctx, root)
        val teal = Color.rgb(0x80, 0xCB, 0xC4)
        val gold = Color.rgb(0xFF, 0xB7, 0x4D)
        val blue = Color.rgb(0x40, 0xC4, 0xFF)

        // restore remembered values
        e.rawComplete = MemoryPaths.getBool(P + "raw_all", e.rawComplete)
        e.micMix = MemoryPaths.getFloat(P + "mic_mix", e.micMix)
        e.micDecay = MemoryPaths.getFloat(P + "mic_decay", e.micDecay)
        for (c in e.all) {
            c.on = MemoryPaths.getBool(P + c.key + "_on", c.on)
            c.lv = MemoryPaths.getFloat(P + c.key + "_lv", c.lv)
            c.thr = MemoryPaths.getFloat(P + c.key + "_thr", c.thr)
            c.raw = MemoryPaths.getBool(P + c.key + "_raw", c.raw)
        }

        p.title("SCREEN ECHO · CENTROID · VERTICAL · LIVE MICROPHONE", gold)
        p.note("Screen echo now remembers the body CENTROID (left ↔ right) and the VERTICAL level (feet → head): they follow the live value while the echo is loud and are held while it fades. The LIVE MICROPHONE joins the screen echo and has its own echo, centroid (dark → bright sound) and vertical (low → high pitch). Level · threshold · RAW on every channel; RAW COMPLETE passes every live value straight through — no level, no threshold, no smoothing, no echo decay.")
        p.switch("RAW COMPLETE — echo · centroid · vertical · microphone", e.rawComplete) {
            e.rawComplete = it; MemoryPaths.putBool(P + "raw_all", it)
        }

        fun channel(title: String, c: ScreenEchoMic.Ch, color: Int, lvMax: Float = 1.5f) {
            p.title(title, color)
            p.switch("$title ON", c.on) { c.on = it; MemoryPaths.putBool(P + c.key + "_on", it) }
            p.seek("Level", 0f, lvMax, c.lv) { c.lv = it; MemoryPaths.putFloat(P + c.key + "_lv", it) }
            p.seek("Threshold", 0f, 0.98f, c.thr) { c.thr = it; MemoryPaths.putFloat(P + c.key + "_thr", it) }
            p.switch("$title RAW", c.raw) { c.raw = it; MemoryPaths.putBool(P + c.key + "_raw", it) }
        }

        channel("SCREEN ECHO CENTROID", e.screenCen, teal)
        channel("SCREEN ECHO VERTICAL", e.screenVer, teal)

        p.title("LIVE MICROPHONE → SCREEN ECHO", blue)
        p.seek("Microphone share of the screen echo input", 0f, 1f, e.micMix) { e.micMix = it; MemoryPaths.putFloat(P + "mic_mix", it) }
        p.seek("Microphone echo memory (tail length)", 0f, 0.95f, e.micDecay) { e.micDecay = it; MemoryPaths.putFloat(P + "mic_decay", it) }
        channel("MICROPHONE ECHO", e.micEcho, blue)
        channel("MICROPHONE CENTROID", e.micCen, blue)
        channel("MICROPHONE VERTICAL", e.micVer, blue)

        val st = p.status("ECHO —", teal)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = e.statusLine(); h.postDelayed(this, 250) }
        })
    }
}
