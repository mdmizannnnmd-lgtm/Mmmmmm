package com.mizan


import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.view.WindowManager
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {


    private lateinit var cameraPreview: SurfaceView
    private var floatingWeb: FloatingWebController? = null
    val devHttpsApi = DevHttpsApiTester()
    val aiPlatformApi = AiPlatformApiBoard()
    lateinit var visualShield: VisualShieldView
    private var cameraManager: CameraManager? = null
    private var audioProcessor: AudioProcessor? = null
    private var motionHub: MotionSensorHub? = null
    private var gameSensors: GameSensorsHub? = null
    private var systemGuard: SystemGuardEngine? = null
    private lateinit var tvAudio: TextView
    private lateinit var humanDetector: HumanCameraDetector
    private val PERMISSION_REQUEST = 1001
    private val GAME_LOCATION_PERMISSION_REQUEST = 1002
    private var sdSound: SdSoundBank? = null
    private val gameSensorUiHandler = Handler(Looper.getMainLooper())
    private var gameSensorControlsReady = false
    private var gameSensorUiRunning = false
    private val gameSensorUiUpdater = object : Runnable {
        override fun run() {
            val sensorText = gameSensors?.status ?: "MAG off · GPS off"
            findViewById<TextView>(R.id.txt_emf_reading)?.text = visualShield.emfReading.statusLine()
            val micGain = visualShield.gameWorld.micGain
            findViewById<TextView>(R.id.tv_game_sensor_status)?.text =
                "$sensorText · 3D mic ×${"%.1f".format(micGain)}"
            findViewById<TextView>(R.id.tv_motion_vector)?.text =
                motionHub?.vectorStatusLine() ?: "ACCEL VECTOR unavailable · SCALAR magnitude unavailable"
            gameSensorUiHandler.postDelayed(this, 250L)
        }
    }

    private val REQ_SOUND_FOLDER = 4107

    /** System folder picker (SD card / USB / internal) — no extra library needed. */
    private fun launchSoundFolderPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_SOUND_FOLDER)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SOUND_FOLDER && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            MemoryPaths.soundTreeUri = uri.toString()
            sdSound?.scan()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MemoryPaths.init(applicationContext)
        setContentView(R.layout.activity_main)
        floatingWeb = FloatingWebController(this)
        floatingWeb?.ensureAttached()

        enterImmersiveFullscreen()
        cameraPreview = findViewById(R.id.camera_preview)
        visualShield = findViewById(R.id.visual_shield)
        tvAudio = findViewById(R.id.tv_audio_power)
        cameraPreview.holder.addCallback(this)
        humanDetector = HumanCameraDetector(applicationContext) { detection ->
            visualShield.updateCameraDetection(detection)
        }
        visualShield.yoloSeg.setDetectorReady(humanDetector.ready)
        audioProcessor = AudioProcessor()
        audioProcessor?.bodySoundFxRef = visualShield.bodySoundFx
        audioProcessor?.videoFeedbackRef = visualShield.videoFeedbackBoard
        audioProcessor?.audioColourRef = visualShield.audioColourBoard
        visualShield.videoFeedbackBoard.audioColourRef = visualShield.audioColourBoard
        visualShield.pitchGuard = audioProcessor?.pitch
        motionHub = MotionSensorHub(this)
        visualShield.motionHub = motionHub
        gameSensors = GameSensorsHub(this)
        visualShield.gameSensors = gameSensors
        systemGuard = SystemGuardEngine(applicationContext)
        visualShield.systemGuard = systemGuard
        audioProcessor?.systemGuardRef = systemGuard
        audioProcessor?.screenAmbientRef = visualShield.screenAmbient
        audioProcessor?.soundBankRef = visualShield.soundBank
        requestPermissions()
    }

    private fun requestPermissions() {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.CAMERA)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, need.toTypedArray(), PERMISSION_REQUEST)
        } else startSystems()
    }

    private fun startSystems() {
        // 1) Foreground service FIRST (required before camera use on modern Android)
        startFgSense()
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // 2) Camera after FG is up
        cameraPreview.post { tryStartCamera() }
        audioProcessor?.startListening(this)
        motionHub?.start()
        systemGuard?.start()
        visualShield.setShieldActive(true)
        visualShield.setMode(VisualShieldView.MODE_UBR)
        setupSeekBars()
        setupGameSensorControls()
        findViewById<android.widget.LinearLayout>(R.id.panel_atmospheric_audio)?.let { panel ->
            audioProcessor?.let { AtmosphericAudioStudioPanel.build(this, panel, visualShield, it) }
        }
        gameSensors?.resumeSensors()
        findViewById<TextView>(R.id.tv_build_stamp)?.text = "SENSEGUARD FG COMPLETE · CAM+AUDIO+ULTRA"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == GAME_LOCATION_PERMISSION_REQUEST) {
            val fineOk = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
            val coarseOk = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
            if (fineOk || coarseOk) {
                gameSensors?.enableLocation()
            } else {
                findViewById<Switch>(R.id.switch_game_gps)?.isChecked = false
            }
            return
        }
        if (requestCode != PERMISSION_REQUEST) return
        val camOk = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (camOk && micOk) {
            startSystems()
        } else {
            findViewById<TextView>(R.id.txt_fg_status)?.text = "Need CAMERA + MIC permissions"
        }
    }

    private fun setupGameSensorControls() {
        if (gameSensorControlsReady) return
        gameSensorControlsReady = true

        
        findViewById<Switch>(R.id.switch_emf_reading)?.setOnCheckedChangeListener { _, c ->
            visualShield.setEmfReadingEnabled(c)
        }
        findViewById<Switch>(R.id.switch_emf_reading_raw)?.setOnCheckedChangeListener { _, c ->
            visualShield.setEmfReadingRaw(c)
        }
        findViewById<Switch>(R.id.switch_emf_track)?.setOnCheckedChangeListener { _, c ->
            visualShield.setEmfTrackOn(c)
        }
        bindSeekBar(R.id.seek_emf_track_thr) {
            // 0..100 → 0.5..50.5 µT
            visualShield.setEmfTrackThrUt(0.5f + it * 0.5f)
        }
        bindSeekBar(R.id.seek_emf_gain) {
            visualShield.setEmfGain(0.1f + it / 100f * 4.9f)
        }
        findViewById<Switch>(R.id.switch_game_world_hi)?.setOnCheckedChangeListener { _, c ->
            visualShield.gameWorld.enabled = c
        }

        bindSeekBar(R.id.seek_emf_ambient_thr) { visualShield.setEmfAmbientThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_emf_ambient_lv) { visualShield.setEmfAmbientLv(it / 100f) }
        bindSeekBar(R.id.seek_emf_centroid_thr) { visualShield.setEmfCentroidThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_emf_spike_thr) { visualShield.setEmfSpikeThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_emf_spike_lv) { visualShield.setEmfSpikeLv(it / 100f) }
        bindSeekBar(R.id.seek_emf_spike_ut) { visualShield.setEmfSpikeThrUt(1f + it.toFloat()) }
        findViewById<Switch>(R.id.switch_bullet)?.setOnCheckedChangeListener { _, c -> visualShield.setBulletOn(c) }
        bindSeekBar(R.id.seek_bullet_thr) { visualShield.setBulletThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_bullet_lv) { visualShield.setBulletLv(it / 100f) }
        findViewById<Switch>(R.id.switch_knife)?.setOnCheckedChangeListener { _, c -> visualShield.setKnifeOn(c) }
        findViewById<Switch>(R.id.switch_whip)?.setOnCheckedChangeListener { _, c -> visualShield.setWhipOn(c) }
        bindSeekBar(R.id.seek_whip_thr) { visualShield.setWhipThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_whip_lv) { visualShield.setWhipLv(it / 100f) }
        findViewById<Switch>(R.id.switch_whip_protect)?.setOnCheckedChangeListener { _, c -> visualShield.setWhipProtect(c) }
        findViewById<Switch>(R.id.switch_whip_model)?.setOnCheckedChangeListener { _, c -> visualShield.setWhipModelDrive(c) }
        findViewById<Switch>(R.id.switch_ar_mixer_protect)?.setOnCheckedChangeListener { _, c -> visualShield.setArMixerProtectOn(c) }
        findViewById<Switch>(R.id.switch_enemy_master_shield)?.setOnCheckedChangeListener { _, c -> visualShield.setEnemyMasterShieldOn(c) }
        
        findViewById<Switch>(R.id.switch_final_anatomy)?.setOnCheckedChangeListener { _, c -> visualShield.setFinalAnatomyEnabled(c) }
        findViewById<Switch>(R.id.switch_final_anatomy_raw)?.setOnCheckedChangeListener { _, c -> visualShield.setFinalAnatomyRaw(c) }
        bindSeekBar(R.id.seek_final_anatomy_thr) { visualShield.setFinalAnatomyGlobalThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_final_anatomy_lv) { visualShield.setFinalAnatomyGlobalLv(it / 100f) }
        findViewById<Switch>(R.id.switch_final_left_body)?.setOnCheckedChangeListener { _, c -> visualShield.setFinalLeftBody(c) }
        findViewById<Switch>(R.id.switch_final_right_body)?.setOnCheckedChangeListener { _, c -> visualShield.setFinalRightBody(c) }
        findViewById<Switch>(R.id.switch_final_front_body)?.setOnCheckedChangeListener { _, c -> visualShield.setFinalFrontBody(c) }
        findViewById<Switch>(R.id.switch_final_back_body)?.setOnCheckedChangeListener { _, c -> visualShield.setFinalBackBody(c) }
        findViewById<Switch>(R.id.switch_final_left_brain)?.setOnCheckedChangeListener { _, c -> visualShield.setFinalLeftBrain(c) }
        findViewById<Switch>(R.id.switch_final_right_brain)?.setOnCheckedChangeListener { _, c -> visualShield.setFinalRightBrain(c) }
        bindSeekBar(R.id.seek_final_left_body_thr) { visualShield.setFinalLeftBodyThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_final_right_body_thr) { visualShield.setFinalRightBodyThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_final_left_body_lv) { visualShield.setFinalLeftBodyLv(it / 100f) }
        bindSeekBar(R.id.seek_final_right_body_lv) { visualShield.setFinalRightBodyLv(it / 100f) }
        bindSeekBar(R.id.seek_final_anat_bip_neg) { visualShield.setFinalAnatomyBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_final_anat_bip_pos) { visualShield.setFinalAnatomyBipPos(it.toFloat()) }
        findViewById<Switch>(R.id.switch_echo_master_anti)?.setOnCheckedChangeListener { _, c -> visualShield.setEchoMasterAntiOn(c) }
        bindSeekBar(R.id.seek_echo_master_anti_lv) { visualShield.setEchoMasterAntiLv(it / 100f) }
        findViewById<Switch>(R.id.switch_echo_body_as)?.setOnCheckedChangeListener { _, c -> visualShield.setEchoBodyAsShield(c) }
        findViewById<Switch>(R.id.switch_echo_body_ws)?.setOnCheckedChangeListener { _, c -> visualShield.setEchoBodyWsShield(c) }
        findViewById<Switch>(R.id.switch_echo_knife_shield)?.setOnCheckedChangeListener { _, c -> visualShield.setEchoKnifeShield(c) }
        findViewById<Switch>(R.id.switch_echo_any_effect)?.setOnCheckedChangeListener { _, c -> visualShield.setEchoAnyEffectProtect(c) }
        bindSeekBar(R.id.seek_echo_any_effect_lv) { visualShield.setEchoAnyEffectLv(it / 100f) }
        bindSeekBar(R.id.seek_enemy_master_shield_lv) { visualShield.setEnemyMasterShieldLv(it / 100f) }
        findViewById<Switch>(R.id.switch_ar_reality_shield)?.setOnCheckedChangeListener { _, c -> visualShield.setArRealityShieldOn(c) }
        bindSeekBar(R.id.seek_ar_reality_shield_lv) { visualShield.setArRealityShieldLv(it / 100f) }
        bindSeekBar(R.id.seek_ar_mixer_protect_lv) { visualShield.setArMixerProtectLv(it / 100f) }
        findViewById<Switch>(R.id.switch_sharp_on)?.setOnCheckedChangeListener { _, c -> visualShield.soundBank.sharpOn = c }
        bindSeekBar(R.id.seek_sharp_thr) { visualShield.soundBank.sharpThr = 0.05f + it / 100f * 0.95f }
        bindSeekBar(R.id.seek_sharp_lv) { visualShield.soundBank.sharpLv = it / 100f }
        findViewById<Switch>(R.id.switch_burst_on)?.setOnCheckedChangeListener { _, c -> visualShield.soundBank.burstOn = c }
        findViewById<Switch>(R.id.switch_mobile_burst_protect)?.setOnCheckedChangeListener { _, c -> visualShield.setMobileBurstProtect(c) }
        bindSeekBar(R.id.seek_mobile_burst_protect_lv) { visualShield.setMobileBurstProtectLv(it / 100f) }
        findViewById<Switch>(R.id.switch_mobile_knife_protect)?.setOnCheckedChangeListener { _, c -> visualShield.setMobileKnifeProtect(c) }
        bindSeekBar(R.id.seek_mobile_knife_protect_lv) { visualShield.setMobileKnifeProtectLv(it / 100f) }
        findViewById<Switch>(R.id.switch_block_burst_body)?.setOnCheckedChangeListener { _, c -> visualShield.setBlockEnemyBurstOnBody(c) }
        findViewById<Switch>(R.id.switch_block_burst_head)?.setOnCheckedChangeListener { _, c -> visualShield.setBlockEnemyBurstOnHead(c) }
        findViewById<Switch>(R.id.switch_block_burst_mobile)?.setOnCheckedChangeListener { _, c -> visualShield.setBlockEnemyBurstOnMobile(c) }
        bindSeekBar(R.id.seek_burst_thr) { visualShield.soundBank.burstThr = 0.05f + it / 100f * 0.95f }
        bindSeekBar(R.id.seek_burst_lv) { visualShield.soundBank.burstLv = it / 100f }
        bindSeekBar(R.id.seek_knife_thr) { visualShield.setKnifeThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_knife_lv) { visualShield.setKnifeLv(it / 100f) }
        findViewById<Switch>(R.id.switch_ripple)?.setOnCheckedChangeListener { _, c -> visualShield.setRippleOn(c) }
        bindSeekBar(R.id.seek_ripple_thr) { visualShield.setRippleThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_ripple_lv) { visualShield.setRippleLv(it / 100f) }
        findViewById<Switch>(R.id.switch_whistle)?.setOnCheckedChangeListener { _, c -> visualShield.setWhistleOn(c) }
        bindSeekBar(R.id.seek_whistle_thr) { visualShield.setWhistleThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_whistle_lv) { visualShield.setWhistleLv(it / 100f) }
        findViewById<Switch>(R.id.switch_ambitious)?.setOnCheckedChangeListener { _, c -> visualShield.setAmbitiousOn(c) }
        bindSeekBar(R.id.seek_ambitious_thr) { visualShield.setAmbitiousThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_ambitious_lv) { visualShield.setAmbitiousLv(it / 100f) }
        bindSeekBar(R.id.seek_enemy_fx_protect) { visualShield.setEnemyFxProtectLv(it / 100f) }
        bindSeekBar(R.id.seek_collide_thr) { visualShield.setCollideThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_collide_lv) { visualShield.setCollideLv(it / 100f) }
        bindSeekBar(R.id.seek_collapse_thr) { visualShield.setCollapseThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_collapse_lv) { visualShield.setCollapseLv(it / 100f) }

        findViewById<Switch>(R.id.switch_atmo_centroid)?.setOnCheckedChangeListener { _, c ->
            visualShield.setAtmoCentroidOn(c)
        }
        bindSeekBar(R.id.seek_atmo_centroid_thr) { visualShield.setAtmoCentroidThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_atmo_centroid_lv) { visualShield.setAtmoCentroidLv(it / 100f) }
        findViewById<Switch>(R.id.switch_anc)?.setOnCheckedChangeListener { _, c ->
            visualShield.setAncOn(c)
        }
        bindSeekBar(R.id.seek_anc_thr) { visualShield.setAncThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_anc_lv) { visualShield.setAncLv(it / 100f) }
        findViewById<Switch>(R.id.switch_anc_protect)?.setOnCheckedChangeListener { _, c ->
            visualShield.setAncProtectOn(c)
        }
        bindSeekBar(R.id.seek_anc_protect_lv) { visualShield.setAncProtectLv(it / 100f) }
        findViewById<Switch>(R.id.switch_nature_motion)?.setOnCheckedChangeListener { _, c ->
            visualShield.setNatureMotionOn(c)
        }



        findViewById<Switch>(R.id.switch_game_magnetic)?.setOnCheckedChangeListener { _, enabled ->
            gameSensors?.setMagneticEnabled(enabled)
        }
        findViewById<Switch>(R.id.switch_game_raw)?.setOnCheckedChangeListener { _, enabled ->
            visualShield.gameWorld.raw = enabled
        }
        findViewById<Switch>(R.id.switch_game_gps)?.setOnCheckedChangeListener { _, enabled ->
            if (enabled) requestGameLocationPermission()
            else gameSensors?.disableLocation()
        }

        bindSeekBar(R.id.seek_game_magnetic_gain) {
            visualShield.gameWorld.magneticGain = it / 100f
        }
        bindSeekBar(R.id.seek_game_magnetic_threshold) {
            visualShield.gameWorld.magneticThresholdUt = (it.coerceAtLeast(1) * 0.5f)
        }
        bindSeekBar(R.id.seek_game_mic_gain) {
            visualShield.gameWorld.micGain = it / 100f
        }
        bindSeekBar(R.id.seek_game_gps_scale) {
            visualShield.gameWorld.gpsPathScale = 0.01f + it / 1000f
        }
        bindSeekBar(R.id.seek_game_gps_accuracy) {
            gameSensors?.maxGpsAccuracyMeters = it.coerceAtLeast(1).toFloat()
        }

        startGameSensorUiUpdates()
    }

    private fun requestGameLocationPermission() {
        val fineOk = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        val coarseOk = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (fineOk || coarseOk) {
            gameSensors?.enableLocation()
            return
        }
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            GAME_LOCATION_PERMISSION_REQUEST
        )
    }

    private fun startGameSensorUiUpdates() {
        if (gameSensorUiRunning || !gameSensorControlsReady) return
        gameSensorUiRunning = true
        gameSensorUiHandler.post(gameSensorUiUpdater)
    }

    private fun stopGameSensorUiUpdates() {
        gameSensorUiHandler.removeCallbacks(gameSensorUiUpdater)
        gameSensorUiRunning = false
    }

    private fun syncArmor() {
        val a = visualShield.armor
        audioProcessor?.armor?.let { oa ->
            oa.bulletproofOn = a.bulletproofOn; oa.knifeProofOn = a.knifeProofOn
            oa.bulletproofLv = a.bulletproofLv; oa.knifeProofLv = a.knifeProofLv
            oa.missileProofOn = a.missileProofOn; oa.missileProofLv = a.missileProofLv
            oa.boomProofOn = a.boomProofOn; oa.boomProofLv = a.boomProofLv
            oa.fireProofOn = a.fireProofOn; oa.fireProofLv = a.fireProofLv
            oa.emfShieldOn = a.emfShieldOn; oa.emfLv = a.emfLv
            oa.nfcShieldOn = a.nfcShieldOn; oa.nfcLv = a.nfcLv
            oa.bleShieldOn = a.bleShieldOn; oa.bleLv = a.bleLv
            oa.magicShieldOn = a.magicShieldOn; oa.magicLv = a.magicLv
            oa.audioShieldOn = a.audioShieldOn; oa.audioLv = a.audioLv
            oa.hardwareShieldOn = a.hardwareShieldOn; oa.hardwareLv = a.hardwareLv
            oa.physicalAudioOn = a.physicalAudioOn; oa.physicalAudioLv = a.physicalAudioLv
        }
        findViewById<TextView>(R.id.tv_armor_status)?.text = visualShield.armor.statusLine()
    }

    private fun setupSeekBars() {
        
        findViewById<Switch>(R.id.switch_eye_l)?.setOnCheckedChangeListener { _, c -> visualShield.setEyesAmbLeftOn(c) }
        findViewById<Switch>(R.id.switch_eye_r)?.setOnCheckedChangeListener { _, c -> visualShield.setEyesAmbRightOn(c) }
        bindSeekBar(R.id.seek_eye_l_amb) { visualShield.setEyesAmbLeftLv(it / 100f) }
        bindSeekBar(R.id.seek_eye_r_amb) { visualShield.setEyesAmbRightLv(it / 100f) }
        bindSeekBar(R.id.seek_eye_l_move_thr) { visualShield.setEyesAmbLeftThr(it / 100f) }
        bindSeekBar(R.id.seek_eye_r_move_thr) { visualShield.setEyesAmbRightThr(it / 100f) }
        bindSeekBar(R.id.seek_eye_wave) { visualShield.setEyeWaveSpeed(it / 50f) }
        bindSeekBar(R.id.seek_eye_move) { visualShield.setEyeMove(it / 100f) }
        bindSeekBar(R.id.seek_eye_move_thr) { visualShield.setEyeMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_eye_speed) { visualShield.setEyeSpeed(it / 100f) }
        bindSeekBar(R.id.seek_eye_speed_thr) { visualShield.setEyeSpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_eye_lr_filter) { visualShield.setEyeLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_eye_ud_filter) { visualShield.setEyeUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_eye_random_filter) { visualShield.setEyeRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_eye_center_filter) { visualShield.setEyeCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_eye_corner_filter) { visualShield.setEyeCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_eye_vib_filter) { visualShield.setEyeVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_eye_bip_neg) { visualShield.setEyeBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_eye_bip_pos) { visualShield.setEyeBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_eye_atmosphere) { visualShield.setEyeAtmosphere(it / 100f) }
        bindSeekBar(R.id.seek_eye_wavespare) { visualShield.setEyeWaveSpare(it / 100f) }
        bindSeekBar(R.id.seek_eye_atmo_bip_neg) { visualShield.setEyeAtmoBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_eye_atmo_bip_pos) { visualShield.setEyeAtmoBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_eye_particles) { visualShield.setEyeParticles(it / 100f) }

        bindSeekBar(R.id.seek_eye_l_skin_out) { visualShield.setEyeLSkinOut(it / 100f) }
        bindSeekBar(R.id.seek_eye_r_skin_out) { visualShield.setEyeRSkinOut(it / 100f) }
        bindSeekBar(R.id.seek_eye_l_skin_in) { visualShield.setEyeLSkinIn(it / 100f) }
        bindSeekBar(R.id.seek_eye_r_skin_in) { visualShield.setEyeRSkinIn(it / 100f) }
        bindSeekBar(R.id.seek_eye_atmo_full) { visualShield.setEyeAtmoAmb(it / 100f) }
        findViewById<Switch>(R.id.switch_body_particles)?.setOnCheckedChangeListener { _, c ->
            visualShield.bodyParticlesOn = c
        }
        findViewById<Switch>(R.id.switch_body_particles_raw)?.setOnCheckedChangeListener { _, c ->
            visualShield.bodyParticlesRaw = c
        }
        bindSeekBar(R.id.seek_body_particles_thr) { visualShield.bodyParticlesThr = (0.05f + it / 100f * 0.95f).coerceIn(0.05f, 1f) }
        bindSeekBar(R.id.seek_body_particles_lv) { visualShield.bodyParticlesLv = (it / 100f).coerceIn(0f, 1f) }
        bindSeekBar(R.id.seek_body_particles_bip_neg) { visualShield.bodyParticlesBipNeg = (-it.toFloat()).coerceIn(-120f, 0f) }
        bindSeekBar(R.id.seek_body_particles_bip_pos) { visualShield.bodyParticlesBipPos = it.toFloat().coerceIn(0f, 120f) }

        bindSeekBar(R.id.seek_eye_bip_thr_neg) { visualShield.setEyeBipThrNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_eye_bip_thr_pos) { visualShield.setEyeBipThrPos(it.toFloat()) }
        bindSeekBar(R.id.seek_eye_pigpong) { visualShield.setEyePigPong(it / 100f) }
        bindSeekBar(R.id.seek_eye_pigpong_thr) { visualShield.setEyePigPongThr(it / 100f) }
        findViewById<Switch>(R.id.switch_eye_l)?.setOnCheckedChangeListener { _, c -> visualShield.eyeLOn = c }
        findViewById<Switch>(R.id.switch_eye_r)?.setOnCheckedChangeListener { _, c -> visualShield.eyeROn = c }

        findViewById<Switch>(R.id.switch_eye_mix)?.setOnCheckedChangeListener { _, c -> visualShield.eyeMixOn = c }
        findViewById<SeekBar>(R.id.seek_eyeball_sep)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                visualShield.eyeBallSep = (0.08f + (p / 100f) * 0.14f).coerceIn(0.08f, 0.22f)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_eyeball_y)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                visualShield.eyeBallY = (((p - 50) / 100f) * 0.16f).coerceIn(-0.08f, 0.08f)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_eyeball_size)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                visualShield.eyeBallSize = (0.4f + (p / 100f) * 1.6f).coerceIn(0.4f, 2f)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_eye_mix_w) { visualShield.eyeMixW = it / 100f }
        findViewById<Switch>(R.id.switch_brow_l)?.setOnCheckedChangeListener { _, c -> visualShield.browLOn = c }
        findViewById<Switch>(R.id.switch_brow_r)?.setOnCheckedChangeListener { _, c -> visualShield.browROn = c }
        findViewById<Switch>(R.id.switch_brow_sync)?.setOnCheckedChangeListener { _, c -> visualShield.browSyncEyes = c }
        bindSeekBar(R.id.seek_brow_l_amb) { visualShield.setBrowLAmbient(it / 100f) }
        bindSeekBar(R.id.seek_brow_r_amb) { visualShield.setBrowRAmbient(it / 100f) }

        findViewById<Switch>(R.id.switch_lip_u)?.setOnCheckedChangeListener { _, c -> visualShield.lipUOn = c }
        findViewById<Switch>(R.id.switch_lip_l)?.setOnCheckedChangeListener { _, c -> visualShield.lipLOn = c }
        findViewById<Switch>(R.id.switch_lip_sync)?.setOnCheckedChangeListener { _, c -> visualShield.lipSyncFace = c }
        findViewById<Switch>(R.id.switch_lip_mix)?.setOnCheckedChangeListener { _, c -> visualShield.lipMixOn = c }
        bindSeekBar(R.id.seek_lip_u_amb) { visualShield.setLipUAmbient(it / 100f) }
        bindSeekBar(R.id.seek_lip_l_amb) { visualShield.setLipLAmbient(it / 100f) }
        findViewById<SeekBar>(R.id.seek_lip_y)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                visualShield.lipY = (0.02f + (p / 100f) * 0.20f).coerceIn(0.02f, 0.22f)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_lip_sep)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                visualShield.lipSep = ((p / 100f) * 0.06f).coerceIn(0f, 0.06f)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_lip_size)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                visualShield.lipSize = (0.5f + (p / 100f) * 1.5f).coerceIn(0.5f, 2f)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_lip_mix_w) { visualShield.lipMixW = it / 100f }
        bindSeekBar(R.id.seek_eye_l_amb) { visualShield.setEyeLAmbient(it / 100f) }
        bindSeekBar(R.id.seek_eye_r_amb) { visualShield.setEyeRAmbient(it / 100f) }
        bindSeekBar(R.id.seek_eye_l_move) { visualShield.setEyeLMove(it / 100f) }
        bindSeekBar(R.id.seek_eye_r_move) { visualShield.setEyeRMove(it / 100f) }
        bindSeekBar(R.id.seek_eye_l_move_thr) { visualShield.setEyeLMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_eye_r_move_thr) { visualShield.setEyeRMoveThr(it / 100f) }
        // Keep L/R in sync with shared eyes when shared ambient changes
        bindSeekBar(R.id.seek_eye_ambient) {
            visualShield.setEyeAmbientLevel(it / 100f)
            visualShield.syncEyesToLr()
        }
        setupEyeTuning()
        setupFgUltra()
        setupUiBlock()
        setupSystemGuard()
        setupEcho()
        setupAmbientBoard()
        setupRegionFx()
        setupScreenAmbientAndSoundBank()

        findViewById<Switch>(R.id.switch_soundbank_on)?.setOnCheckedChangeListener { _, c ->
            visualShield.setSoundBankEnabled(c)
        }
        findViewById<Switch>(R.id.switch_soundbank_raw)?.setOnCheckedChangeListener { _, c ->
            visualShield.setSoundBankRaw(c)
        }
        bindSeekBar(R.id.seek_audio_focus_lv) { visualShield.setAudioFocusLv(it / 100f) }
        bindSeekBar(R.id.seek_audio_focus_thr) { visualShield.setAudioFocusThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_focus_move_lv) { visualShield.setFocusMoveLv(it / 100f) }
        bindSeekBar(R.id.seek_focus_speed_lv) { visualShield.setFocusSpeedLv(it / 100f) }
        bindSeekBar(R.id.seek_focus_wave_lv) { visualShield.setFocusWaveLv(it / 100f) }
        // bipolar: progress 0..1000 → −1000..0 and 0..+1000
        bindSeekBar(R.id.seek_bip_db_neg) { visualShield.setBipDbNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_bip_db_pos) { visualShield.setBipDbPos(it.toFloat()) }
        findViewById<Switch>(R.id.switch_enemy_body_on)?.setOnCheckedChangeListener { _, c ->
            visualShield.setEnemyBodyOn(c)
        }
        bindSeekBar(R.id.seek_enemy_body_thr) { visualShield.setEnemyBodyThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_enemy_body_lv) { visualShield.setEnemyBodyLv(it / 100f) }
        findViewById<Switch>(R.id.switch_body_surf_comm)?.setOnCheckedChangeListener { _, c ->
            visualShield.setBodySurfCommOn(c)
        }

        findViewById<Switch>(R.id.switch_mic_enemy)?.setOnCheckedChangeListener { _, c ->
            visualShield.setMicDrivenOn(c)
        }
        bindSeekBar(R.id.seek_mic_enemy_thr) { visualShield.setMicEnemyThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_mic_enemy_lv) { visualShield.setMicEnemyLv(it / 100f) }
        findViewById<Switch>(R.id.switch_protect_body)?.setOnCheckedChangeListener { _, c ->
            visualShield.setProtectBodyOn(c)
        }
        bindSeekBar(R.id.seek_protect_thr) { visualShield.setProtectThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_protect_lv) { visualShield.setProtectLv(it / 100f) }
        findViewById<Switch>(R.id.switch_enemy_comm_block)?.setOnCheckedChangeListener { _, c ->
            visualShield.setEnemyCommBlockOn(c)
        }
        bindSeekBar(R.id.seek_enemy_comm_thr) { visualShield.setEnemyCommBlockThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_enemy_comm_lv) { visualShield.setEnemyCommBlockLv(it / 100f) }

        findViewById<Switch>(R.id.switch_anti_audio)?.setOnCheckedChangeListener { _, c ->
            visualShield.setAntiAudioOn(c)
        }
        bindSeekBar(R.id.seek_anti_audio_thr) { visualShield.setAntiAudioThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_anti_audio_lv) { visualShield.setAntiAudioLv(it / 100f) }
        findViewById<Switch>(R.id.switch_anti_body)?.setOnCheckedChangeListener { _, c ->
            visualShield.setAntiBodyOn(c)
        }
        bindSeekBar(R.id.seek_anti_body_thr) { visualShield.setAntiBodyThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_anti_body_lv) { visualShield.setAntiBodyLv(it / 100f) }
        findViewById<Switch>(R.id.switch_atmo_fire)?.setOnCheckedChangeListener { _, c ->
            visualShield.setAtmoFireOn(c)
        }
        bindSeekBar(R.id.seek_atmo_fire_thr) { visualShield.setAtmoFireThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_atmo_fire_lv) { visualShield.setAtmoFireLv(it / 100f) }
        bindSeekBar(R.id.seek_atmo_fire_bip_neg) { visualShield.setAtmoFireBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_atmo_fire_bip_pos) { visualShield.setAtmoFireBipPos(it.toFloat()) }
        findViewById<Switch>(R.id.switch_eye_fire)?.setOnCheckedChangeListener { _, c ->
            visualShield.setEyeFireOn(c)
        }
        findViewById<Switch>(R.id.switch_head_fire)?.setOnCheckedChangeListener { _, c ->
            visualShield.setHeadFireOn(c)
        }
        findViewById<Button>(R.id.btn_float_atmo_fire)?.setOnClickListener { visualShield.fireAtmo() }
        findViewById<Button>(R.id.btn_float_eye_fire)?.setOnClickListener { visualShield.fireEye() }
        findViewById<Button>(R.id.btn_float_head_fire)?.setOnClickListener { visualShield.fireHead() }
        findViewById<Button>(R.id.btn_float_body_fire)?.setOnClickListener { visualShield.fireBody() }
        findViewById<Button>(R.id.btn_float_as_fire)?.setOnClickListener { visualShield.fireAs() }
        findViewById<Button>(R.id.btn_float_gun_fire)?.setOnClickListener { visualShield.fireGun() }
        findViewById<Button>(R.id.btn_float_collapse_fire)?.setOnClickListener { visualShield.fireCollapse() }
        findViewById<Button>(R.id.btn_float_lhc_fire)?.setOnClickListener { visualShield.fireLhc() }
        findViewById<Button>(R.id.btn_float_amb_fire)?.setOnClickListener { visualShield.fireAmbSysCollapse() }
        findViewById<Button>(R.id.btn_float_bank_fire)?.setOnClickListener { visualShield.fireEnemyBankCollapse() }
        findViewById<Switch>(R.id.switch_amb_sys_collapse)?.setOnCheckedChangeListener { _, c -> visualShield.setAmbSysCollapseOn(c) }
        findViewById<Switch>(R.id.switch_enemy_bank_collapse)?.setOnCheckedChangeListener { _, c -> visualShield.setEnemyBankCollapseOn(c) }
        findViewById<Switch>(R.id.switch_sounds_bank_collide)?.setOnCheckedChangeListener { _, c -> visualShield.setSoundsBankCollideOn(c) }
        // LHC live ticker
        val lhcHandler = android.os.Handler(android.os.Looper.getMainLooper())
        val lhcTick = object : Runnable {
            override fun run() {
                runCatching {
                    val our = audioProcessor?.let { 0.5f } ?: 0.3f
                    val ax = motionHub?.axisX ?: 0f
                    val ay = motionHub?.axisY ?: 0f
                    val az = motionHub?.axisZ ?: 0f
                    visualShield.updateLhc(our.coerceIn(0f, 1f), 0.2f, ax, ay, az,
                        findViewById<Switch>(R.id.switch_echo_cancel)?.isChecked == true)
                    findViewById<TextView>(R.id.txt_lhc_status)?.text = visualShield.lhcStatus()
                    findViewById<TextView>(R.id.txt_amb_collapse_status)?.text = visualShield.ambCollapseStatus()
                }
                lhcHandler.postDelayed(this, 100L)
            }
        }
        lhcHandler.post(lhcTick)
        findViewById<Switch>(R.id.switch_lhc_collider)?.setOnCheckedChangeListener { _, c -> visualShield.setLhcColliderOn(c) }
        findViewById<Switch>(R.id.switch_lhc_echo_cancel)?.setOnCheckedChangeListener { _, c -> visualShield.setLhcEchoCancelOn(c) }
        findViewById<Switch>(R.id.switch_lhc_axis_collapse)?.setOnCheckedChangeListener { _, c -> visualShield.setLhcAxisCollapseOn(c) }
        bindSeekBar(R.id.seek_lhc_energy) {
            visualShield.setLhcEnergy(it / 100f)
            findViewById<TextView>(R.id.val_lhc_energy)?.text = "LHC energy ${it}%"
        }
        bindSeekBar(R.id.seek_lhc_thr) {
            visualShield.setLhcThr(0.05f + it / 100f * 0.95f)
            findViewById<TextView>(R.id.val_lhc_thr)?.text = "LHC thr ${it}%"
        }
        bindSeekBar(R.id.seek_lhc_db_thr) {
            visualShield.setLhcDbThr(it.toFloat().coerceIn(1f, 120f))
            findViewById<TextView>(R.id.val_lhc_db_thr)?.text = "LHC dB thr $it"
        }
        findViewById<Button>(R.id.btn_float_anti_fire)?.setOnClickListener { visualShield.fireAnti() }
        findViewById<Button>(R.id.btn_float_fire_all)?.setOnClickListener { visualShield.fireAll() }
        // 3D game: enemy selection · inside rotation · head pitch · SUPER · RAW (floating buttons + touch)
        findViewById<View>(R.id.float_fire_panel)?.parent?.let { par ->
            if (par is android.view.ViewGroup) GameEnemyFloatPanel.install(this, par, visualShield)
        }

        findViewById<Switch>(R.id.switch_mic_speaker)?.setOnCheckedChangeListener { _, c ->
            visualShield.setMicSpeakerEnabled(c)
        }
        findViewById<Switch>(R.id.switch_mic_speaker_raw)?.setOnCheckedChangeListener { _, c ->
            visualShield.setMicSpeakerRaw(c)
        }
        findViewById<android.widget.CheckBox>(R.id.check_mic1)?.setOnCheckedChangeListener { _, c ->
            visualShield.setMic1On(c)
        }
        findViewById<android.widget.CheckBox>(R.id.check_mic2)?.setOnCheckedChangeListener { _, c ->
            visualShield.setMic2On(c)
        }
        findViewById<Switch>(R.id.switch_mic_mono)?.setOnCheckedChangeListener { _, c ->
            visualShield.setMicMono(c)
            if (c) findViewById<Switch>(R.id.switch_mic_stereo)?.isChecked = false
        }
        findViewById<Switch>(R.id.switch_mic_stereo)?.setOnCheckedChangeListener { _, c ->
            visualShield.setMicStereoOn(c)
            if (c) findViewById<Switch>(R.id.switch_mic_mono)?.isChecked = false
        }
        findViewById<android.widget.CheckBox>(R.id.check_mic_l)?.setOnCheckedChangeListener { _, c ->
            visualShield.setMicLOn(c)
        }
        findViewById<android.widget.CheckBox>(R.id.check_mic_r)?.setOnCheckedChangeListener { _, c ->
            visualShield.setMicROn(c)
        }
        bindSeekBar(R.id.seek_stereo_balance) {
            visualShield.setStereoBalance(it / 100f)
            findViewById<TextView>(R.id.val_stereo_balance)?.text =
                "stereo balance L${100 - it} / R$it"
        }
        bindSeekBar(R.id.seek_stereo_lv_l) {
            visualShield.setStereoLvL(it / 100f)
            findViewById<TextView>(R.id.val_stereo_lv_l)?.text = "stereo L level ${it}%"
        }
        bindSeekBar(R.id.seek_stereo_lv_r) {
            visualShield.setStereoLvR(it / 100f)
            findViewById<TextView>(R.id.val_stereo_lv_r)?.text = "stereo R level ${it}%"
        }
        bindSeekBar(R.id.seek_stereo_thr_l) {
            visualShield.setStereoThrL(0.05f + it / 100f * 0.95f)
            findViewById<TextView>(R.id.val_stereo_thr_l)?.text = "stereo L thr ${it}%"
        }
        bindSeekBar(R.id.seek_stereo_thr_r) {
            visualShield.setStereoThrR(0.05f + it / 100f * 0.95f)
            findViewById<TextView>(R.id.val_stereo_thr_r)?.text = "stereo R thr ${it}%"
        }
        findViewById<Switch>(R.id.switch_echo_cancel)?.setOnCheckedChangeListener { _, c ->
            visualShield.setEchoCancelOn(c)
        }
        findViewById<Switch>(R.id.switch_noise_reduce)?.setOnCheckedChangeListener { _, c ->
            visualShield.setNoiseReduceOn(c)
        }
        bindSeekBar(R.id.seek_karaoke_effect) { visualShield.setKaraokeEffectId(it) }
        bindSeekBar(R.id.seek_effect_level) { visualShield.setEffectLevel(it / 100f) }
        bindSeekBar(R.id.seek_speaker_gain) { visualShield.setSpeakerGain(it / 50f) }
        bindSeekBar(R.id.seek_mic_gain) { visualShield.setMicGain(it / 50f) }
        bindSeekBar(R.id.seek_amp_gain) { visualShield.setAmpGain(0.5f + it / 50f) }
        findViewById<Switch>(R.id.switch_eye_l)?.setOnCheckedChangeListener { _, c ->
            visualShield.eyeLOn = c
        }
        findViewById<Switch>(R.id.switch_eye_r)?.setOnCheckedChangeListener { _, c ->
            visualShield.eyeROn = c
        }
        findViewById<Button>(R.id.btn_rescan_eyes_lr)?.setOnClickListener {
            visualShield.rescanEyesLr()
        }




        setupCameraVhs()

        findViewById<Switch>(R.id.switch_body_locked)?.setOnCheckedChangeListener { _, c ->
            visualShield.bodyLocked = c
            visualShield.anatomy3d.bodyLocked = c
            visualShield.gameWorld.bodyLocked = c
        }
        setupInsideRotationLock()


        // Motion centroid · vertical rails
        val cd = visualShield.cenDrive
        fun bindCdSwitch(id: Int, set: (Boolean) -> Unit) {
            findViewById<Switch>(id)?.setOnCheckedChangeListener { _, c -> set(c) }
        }
        fun bindCdSeek(id: Int, set: (Float) -> Unit) {
            bindSeekBar(id) { set(it / 100f) }
        }
        bindCdSwitch(R.id.switch_move_cen) { cd.moveCenOn = it }
        bindCdSwitch(R.id.switch_move_cen_raw) { cd.moveCenRaw = it }
        bindSeekBar(R.id.seek_move_cen_thr) { cd.moveCenThr = (0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_move_cen_lv) { cd.moveCenLv = it / 100f * 1.5f }
        bindCdSwitch(R.id.switch_move_ver) { cd.moveVerOn = it }
        bindCdSwitch(R.id.switch_move_ver_raw) { cd.moveVerRaw = it }
        bindSeekBar(R.id.seek_move_ver_thr) { cd.moveVerThr = (0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_move_ver_lv) { cd.moveVerLv = it / 100f * 1.5f }
        bindCdSwitch(R.id.switch_speed_cen) { cd.speedCenOn = it }
        bindCdSwitch(R.id.switch_speed_cen_raw) { cd.speedCenRaw = it }
        bindSeekBar(R.id.seek_speed_cen_thr) { cd.speedCenThr = (0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_speed_cen_lv) { cd.speedCenLv = it / 100f * 1.5f }
        bindCdSwitch(R.id.switch_speed_ver) { cd.speedVerOn = it }
        bindCdSwitch(R.id.switch_speed_ver_raw) { cd.speedVerRaw = it }
        bindSeekBar(R.id.seek_speed_ver_thr) { cd.speedVerThr = (0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_speed_ver_lv) { cd.speedVerLv = it / 100f * 1.5f }
        bindCdSwitch(R.id.switch_wave_cen) { cd.waveCenOn = it }
        bindCdSwitch(R.id.switch_wave_cen_raw) { cd.waveCenRaw = it }
        bindSeekBar(R.id.seek_wave_cen_thr) { cd.waveCenThr = (0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_wave_cen_lv) { cd.waveCenLv = it / 100f * 1.5f }
        bindCdSwitch(R.id.switch_wave_ver) { cd.waveVerOn = it }
        bindCdSwitch(R.id.switch_wave_ver_raw) { cd.waveVerRaw = it }
        bindSeekBar(R.id.seek_wave_ver_thr) { cd.waveVerThr = (0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_wave_ver_lv) { cd.waveVerLv = it / 100f * 1.5f }
        bindCdSwitch(R.id.switch_amb_cen) { cd.ambCenOn = it }
        bindCdSwitch(R.id.switch_amb_cen_raw) { cd.ambCenRaw = it }
        bindSeekBar(R.id.seek_amb_cen_thr) { cd.ambCenThr = (0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_amb_cen_lv) { cd.ambCenLv = it / 100f * 1.5f }
        bindCdSwitch(R.id.switch_amb_ver) { cd.ambVerOn = it }
        bindCdSwitch(R.id.switch_amb_ver_raw) { cd.ambVerRaw = it }
        bindSeekBar(R.id.seek_amb_ver_thr) { cd.ambVerThr = (0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_amb_ver_lv) { cd.ambVerLv = it / 100f * 1.5f }

        setupNoiseRate()
        setupArMeasure()
        setupPoseSurface()
        setupYoloSeg()
        setupBodyMixer()
        setupBrainAnatomyPanels()

        
        findViewById<Switch>(R.id.switch_noise3d)?.setOnCheckedChangeListener { _, c ->
            visualShield.setNoise3dEnabled(c)
        }
        findViewById<Switch>(R.id.switch_noise3d_raw)?.setOnCheckedChangeListener { _, c ->
            visualShield.setNoise3dRaw(c)
        }
        bindSeekBar(R.id.seek_noise3d_density) { visualShield.setNoise3dDensity(it / 100f) }
        bindSeekBar(R.id.seek_noise3d_size) { visualShield.setNoise3dSize(it / 100f) }
        bindSeekBar(R.id.seek_noise3d_speed) { visualShield.setNoise3dSpeed(it / 100f) }
        bindSeekBar(R.id.seek_noise3d_depth) { visualShield.setNoise3dDepth(it / 100f) }
        bindSeekBar(R.id.seek_noise3d_level) { visualShield.setNoise3dLevel(it / 100f) }
        findViewById<Switch>(R.id.switch_body_atmo3d)?.setOnCheckedChangeListener { _, c ->
            visualShield.setBodyAtmo3dEnabled(c)
        }

        
        bindSeekBar(R.id.seek_tongue_amb) { visualShield.setTongueAmbient(it / 100f) }
        bindSeekBar(R.id.seek_tongue_wave) { visualShield.setTongueWave(0.05f + it / 100f * 3.95f) }
        findViewById<Switch>(R.id.switch_tongue_raw)?.setOnCheckedChangeListener { _, c ->
            visualShield.setTongueRaw(c)
        }
        findViewById<Switch>(R.id.switch_all_regions_raw)?.setOnCheckedChangeListener { _, c ->
            visualShield.setAllRegionsRaw(c)
        }

        bindSeekBar(R.id.seek_neck_amb) { visualShield.setNeckAmbient(it / 100f) }
        bindSeekBar(R.id.seek_heart_amb) { visualShield.setHeartAmbient(it / 100f) }
        bindSeekBar(R.id.seek_belly_amb) { visualShield.setBellyAmbient(it / 100f) }
        bindSeekBar(R.id.seek_leg_l_amb) { visualShield.setLegLAmbient(it / 100f) }
        bindSeekBar(R.id.seek_leg_r_amb) { visualShield.setLegRAmbient(it / 100f) }
        bindSeekBar(R.id.seek_ass_amb) { visualShield.setAssAmbient(it / 100f) }
        bindSeekBar(R.id.seek_pussy_amb) { visualShield.setPussyAmbient(it / 100f) }
        bindSeekBar(R.id.seek_dick_amb) { visualShield.setDickAmbient(it / 100f) }

        bindSeekBar(R.id.seek_brain_ambient) { visualShield.setBrainAmbient(it / 100f) }
        bindSeekBar(R.id.seek_brain_wave) { visualShield.setBrainWave(it / 50f) }
        bindSeekBar(R.id.seek_brain_move) { visualShield.setBrainMove(it / 100f) }
        bindSeekBar(R.id.seek_brain_move_thr) { visualShield.setBrainMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_brain_speed) { visualShield.setBrainSpeed(it / 100f) }
        bindSeekBar(R.id.seek_brain_speed_thr) { visualShield.setBrainSpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_brain_lr_filter) { visualShield.setBrainLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_brain_ud_filter) { visualShield.setBrainUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_brain_random_filter) { visualShield.setBrainRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_brain_center_filter) { visualShield.setBrainCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_brain_corner_filter) { visualShield.setBrainCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_brain_vib_filter) { visualShield.setBrainVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_brain_bip_neg) { visualShield.setBrainBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_brain_bip_pos) { visualShield.setBrainBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_brain_atmosphere) { visualShield.setBrainAtmosphere(it / 100f) }
        bindSeekBar(R.id.seek_brain_wavespare) { visualShield.setBrainWaveSpare(it / 100f) }
        bindSeekBar(R.id.seek_brain_atmo_bip_neg) { visualShield.setBrainAtmoBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_brain_atmo_bip_pos) { visualShield.setBrainAtmoBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_brain_particles) { visualShield.setBrainParticles(it / 100f) }
        bindSeekBar(R.id.seek_brain_bip_thr_neg) { visualShield.setBrainBipThrNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_brain_bip_thr_pos) { visualShield.setBrainBipThrPos(it.toFloat()) }
        bindSeekBar(R.id.seek_brain_atmo_spike_prot) { visualShield.setBrainAtmoSpikeProt(it / 100f) }
        bindSeekBar(R.id.seek_brain_atmo_spike_prot_thr) { visualShield.setBrainAtmoSpikeProtThr(it / 100f) }

        bindSeekBar(R.id.seek_face_ambient) { visualShield.setFaceAmbient(it / 100f) }
        bindSeekBar(R.id.seek_face_wave) { visualShield.setFaceWave(it / 50f) }
        bindSeekBar(R.id.seek_face_move) { visualShield.setFaceMove(it / 100f) }
        bindSeekBar(R.id.seek_face_move_thr) { visualShield.setFaceMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_face_speed) { visualShield.setFaceSpeed(it / 100f) }
        bindSeekBar(R.id.seek_face_speed_thr) { visualShield.setFaceSpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_face_lr_filter) { visualShield.setFaceLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_face_ud_filter) { visualShield.setFaceUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_face_random_filter) { visualShield.setFaceRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_face_center_filter) { visualShield.setFaceCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_face_corner_filter) { visualShield.setFaceCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_face_vib_filter) { visualShield.setFaceVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_face_bip_neg) { visualShield.setFaceBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_face_bip_pos) { visualShield.setFaceBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_dick_atmosphere) { visualShield.setDickAtmosphere(it / 100f) }
        bindSeekBar(R.id.seek_dick_wavespare) { visualShield.setDickWaveSpare(it / 100f) }
        bindSeekBar(R.id.seek_dick_atmo_bip_neg) { visualShield.setDickAtmoBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_dick_atmo_bip_pos) { visualShield.setDickAtmoBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_dick_particles) { visualShield.setDickParticles(it / 100f) }
        bindSeekBar(R.id.seek_dick_bip_thr_neg) { visualShield.setDickBipThrNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_dick_bip_thr_pos) { visualShield.setDickBipThrPos(it.toFloat()) }
        bindSeekBar(R.id.seek_pussy_atmosphere) { visualShield.setPussyAtmosphere(it / 100f) }
        bindSeekBar(R.id.seek_pussy_wavespare) { visualShield.setPussyWaveSpare(it / 100f) }
        bindSeekBar(R.id.seek_pussy_atmo_bip_neg) { visualShield.setPussyAtmoBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_pussy_atmo_bip_pos) { visualShield.setPussyAtmoBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_pussy_particles) { visualShield.setPussyParticles(it / 100f) }
        bindSeekBar(R.id.seek_pussy_bip_thr_neg) { visualShield.setPussyBipThrNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_pussy_bip_thr_pos) { visualShield.setPussyBipThrPos(it.toFloat()) }
        bindSeekBar(R.id.seek_face_atmosphere) { visualShield.setFaceAtmosphere(it / 100f) }
        bindSeekBar(R.id.seek_face_wavespare) { visualShield.setFaceWaveSpare(it / 100f) }
        bindSeekBar(R.id.seek_face_atmo_bip_neg) { visualShield.setFaceAtmoBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_face_atmo_bip_pos) { visualShield.setFaceAtmoBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_face_particles) { visualShield.setFaceParticles(it / 100f) }
        bindSeekBar(R.id.seek_face_bip_thr_neg) { visualShield.setFaceBipThrNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_face_bip_thr_pos) { visualShield.setFaceBipThrPos(it.toFloat()) }

        bindSeekBar(R.id.seek_forehead_ambient) { visualShield.setForeheadAmbient(it / 100f) }
        bindSeekBar(R.id.seek_forehead_wave) { visualShield.setForeheadWave(it / 50f) }
        bindSeekBar(R.id.seek_forehead_move) { visualShield.setForeheadMove(it / 100f) }
        bindSeekBar(R.id.seek_forehead_move_thr) { visualShield.setForeheadMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_forehead_speed) { visualShield.setForeheadSpeed(it / 100f) }
        bindSeekBar(R.id.seek_forehead_speed_thr) { visualShield.setForeheadSpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_forehead_lr_filter) { visualShield.setForeheadLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_forehead_ud_filter) { visualShield.setForeheadUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_forehead_random_filter) { visualShield.setForeheadRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_forehead_center_filter) { visualShield.setForeheadCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_forehead_corner_filter) { visualShield.setForeheadCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_forehead_vib_filter) { visualShield.setForeheadVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_forehead_bip_neg) { visualShield.setForeheadBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_forehead_bip_pos) { visualShield.setForeheadBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_forehead_atmosphere) { visualShield.setForeheadAtmosphere(it / 100f) }
        bindSeekBar(R.id.seek_forehead_wavespare) { visualShield.setForeheadWaveSpare(it / 100f) }
        bindSeekBar(R.id.seek_forehead_atmo_bip_neg) { visualShield.setForeheadAtmoBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_forehead_atmo_bip_pos) { visualShield.setForeheadAtmoBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_forehead_particles) { visualShield.setForeheadParticles(it / 100f) }
        bindSeekBar(R.id.seek_forehead_bip_thr_neg) { visualShield.setForeheadBipThrNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_forehead_bip_thr_pos) { visualShield.setForeheadBipThrPos(it.toFloat()) }

        bindSeekBar(R.id.seek_nose_ambient) { visualShield.setNoseAmbient(it / 100f) }
        bindSeekBar(R.id.seek_nose_wave) { visualShield.setNoseWave(it / 50f) }
        bindSeekBar(R.id.seek_nose_move) { visualShield.setNoseMove(it / 100f) }
        bindSeekBar(R.id.seek_nose_move_thr) { visualShield.setNoseMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_nose_speed) { visualShield.setNoseSpeed(it / 100f) }
        bindSeekBar(R.id.seek_nose_speed_thr) { visualShield.setNoseSpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_nose_lr_filter) { visualShield.setNoseLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_nose_ud_filter) { visualShield.setNoseUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_nose_random_filter) { visualShield.setNoseRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_nose_center_filter) { visualShield.setNoseCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_nose_corner_filter) { visualShield.setNoseCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_nose_vib_filter) { visualShield.setNoseVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_nose_bip_neg) { visualShield.setNoseBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_nose_bip_pos) { visualShield.setNoseBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_nose_atmosphere) { visualShield.setNoseAtmosphere(it / 100f) }
        bindSeekBar(R.id.seek_nose_wavespare) { visualShield.setNoseWaveSpare(it / 100f) }
        bindSeekBar(R.id.seek_nose_atmo_bip_neg) { visualShield.setNoseAtmoBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_nose_atmo_bip_pos) { visualShield.setNoseAtmoBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_nose_particles) { visualShield.setNoseParticles(it / 100f) }
        bindSeekBar(R.id.seek_nose_bip_thr_neg) { visualShield.setNoseBipThrNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_nose_bip_thr_pos) { visualShield.setNoseBipThrPos(it.toFloat()) }
        bindSeekBar(R.id.seek_heart_ambient) { visualShield.setHeartAmbient(it / 100f) }
        bindSeekBar(R.id.seek_heart_wave) { visualShield.setHeartWave(it / 50f) }
        bindSeekBar(R.id.seek_heart_move) { visualShield.setHeartMove(it / 100f) }
        bindSeekBar(R.id.seek_heart_move_thr) { visualShield.setHeartMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_heart_speed) { visualShield.setHeartSpeed(it / 100f) }
        bindSeekBar(R.id.seek_heart_speed_thr) { visualShield.setHeartSpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_heart_lr_filter) { visualShield.setHeartLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_heart_ud_filter) { visualShield.setHeartUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_heart_random_filter) { visualShield.setHeartRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_heart_center_filter) { visualShield.setHeartCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_heart_corner_filter) { visualShield.setHeartCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_heart_vib_filter) { visualShield.setHeartVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_heart_bip_neg) { visualShield.setHeartBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_heart_bip_pos) { visualShield.setHeartBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_heart_atmosphere) { visualShield.setHeartAtmosphere(it / 100f) }
        bindSeekBar(R.id.seek_heart_wavespare) { visualShield.setHeartWaveSpare(it / 100f) }
        bindSeekBar(R.id.seek_heart_atmo_bip_neg) { visualShield.setHeartAtmoBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_heart_atmo_bip_pos) { visualShield.setHeartAtmoBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_heart_particles) { visualShield.setHeartParticles(it / 100f) }
        bindSeekBar(R.id.seek_heart_bip_thr_neg) { visualShield.setHeartBipThrNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_heart_bip_thr_pos) { visualShield.setHeartBipThrPos(it.toFloat()) }
        bindSeekBar(R.id.seek_neck_ambient) { visualShield.setNeckAmbient(it / 100f) }
        bindSeekBar(R.id.seek_neck_wave) { visualShield.setNeckWave(it / 50f) }
        bindSeekBar(R.id.seek_neck_move) { visualShield.setNeckMove(it / 100f) }
        bindSeekBar(R.id.seek_neck_move_thr) { visualShield.setNeckMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_neck_speed) { visualShield.setNeckSpeed(it / 100f) }
        bindSeekBar(R.id.seek_neck_speed_thr) { visualShield.setNeckSpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_neck_lr_filter) { visualShield.setNeckLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_neck_ud_filter) { visualShield.setNeckUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_neck_random_filter) { visualShield.setNeckRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_neck_center_filter) { visualShield.setNeckCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_neck_corner_filter) { visualShield.setNeckCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_neck_vib_filter) { visualShield.setNeckVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_neck_bip_neg) { visualShield.setNeckBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_neck_bip_pos) { visualShield.setNeckBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_neck_atmosphere) { visualShield.setNeckAtmosphere(it / 100f) }
        bindSeekBar(R.id.seek_neck_wavespare) { visualShield.setNeckWaveSpare(it / 100f) }
        bindSeekBar(R.id.seek_neck_atmo_bip_neg) { visualShield.setNeckAtmoBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_neck_atmo_bip_pos) { visualShield.setNeckAtmoBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_neck_particles) { visualShield.setNeckParticles(it / 100f) }
        bindSeekBar(R.id.seek_neck_bip_thr_neg) { visualShield.setNeckBipThrNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_neck_bip_thr_pos) { visualShield.setNeckBipThrPos(it.toFloat()) }
        bindSeekBar(R.id.seek_belly_ambient) { visualShield.setBellyAmbient(it / 100f) }
        bindSeekBar(R.id.seek_belly_wave) { visualShield.setBellyWave(it / 50f) }
        bindSeekBar(R.id.seek_belly_move) { visualShield.setBellyMove(it / 100f) }
        bindSeekBar(R.id.seek_belly_move_thr) { visualShield.setBellyMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_belly_speed) { visualShield.setBellySpeed(it / 100f) }
        bindSeekBar(R.id.seek_belly_speed_thr) { visualShield.setBellySpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_belly_lr_filter) { visualShield.setBellyLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_belly_ud_filter) { visualShield.setBellyUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_belly_random_filter) { visualShield.setBellyRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_belly_center_filter) { visualShield.setBellyCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_belly_corner_filter) { visualShield.setBellyCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_belly_vib_filter) { visualShield.setBellyVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_belly_bip_neg) { visualShield.setBellyBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_belly_bip_pos) { visualShield.setBellyBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_belly_atmosphere) { visualShield.setBellyAtmosphere(it / 100f) }
        bindSeekBar(R.id.seek_belly_wavespare) { visualShield.setBellyWaveSpare(it / 100f) }
        bindSeekBar(R.id.seek_belly_atmo_bip_neg) { visualShield.setBellyAtmoBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_belly_atmo_bip_pos) { visualShield.setBellyAtmoBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_belly_particles) { visualShield.setBellyParticles(it / 100f) }
        bindSeekBar(R.id.seek_belly_bip_thr_neg) { visualShield.setBellyBipThrNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_belly_bip_thr_pos) { visualShield.setBellyBipThrPos(it.toFloat()) }
        bindSeekBar(R.id.seek_hand_l_ambient) { visualShield.setHandLAmbient(it / 100f) }
        bindSeekBar(R.id.seek_hand_l_wave) { visualShield.setHandLWave(it / 50f) }
        bindSeekBar(R.id.seek_hand_l_move) { visualShield.setHandLMove(it / 100f) }
        bindSeekBar(R.id.seek_hand_l_move_thr) { visualShield.setHandLMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_hand_l_speed) { visualShield.setHandLSpeed(it / 100f) }
        bindSeekBar(R.id.seek_hand_l_speed_thr) { visualShield.setHandLSpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_hand_l_lr_filter) { visualShield.setHandLLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_l_ud_filter) { visualShield.setHandLUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_l_random_filter) { visualShield.setHandLRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_l_center_filter) { visualShield.setHandLCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_l_corner_filter) { visualShield.setHandLCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_l_vib_filter) { visualShield.setHandLVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_l_bip_neg) { visualShield.setHandLBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_hand_l_bip_pos) { visualShield.setHandLBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_hand_r_ambient) { visualShield.setHandRAmbient(it / 100f) }
        bindSeekBar(R.id.seek_hand_r_wave) { visualShield.setHandRWave(it / 50f) }
        bindSeekBar(R.id.seek_hand_r_move) { visualShield.setHandRMove(it / 100f) }
        bindSeekBar(R.id.seek_hand_r_move_thr) { visualShield.setHandRMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_hand_r_speed) { visualShield.setHandRSpeed(it / 100f) }
        bindSeekBar(R.id.seek_hand_r_speed_thr) { visualShield.setHandRSpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_hand_r_lr_filter) { visualShield.setHandRLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_r_ud_filter) { visualShield.setHandRUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_r_random_filter) { visualShield.setHandRRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_r_center_filter) { visualShield.setHandRCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_r_corner_filter) { visualShield.setHandRCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_r_vib_filter) { visualShield.setHandRVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_hand_r_bip_neg) { visualShield.setHandRBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_hand_r_bip_pos) { visualShield.setHandRBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_pussy_ambient) { visualShield.setPussyAmbient(it / 100f) }
        bindSeekBar(R.id.seek_pussy_wave) { visualShield.setPussyWave(it / 50f) }
        bindSeekBar(R.id.seek_pussy_move) { visualShield.setPussyMove(it / 100f) }
        bindSeekBar(R.id.seek_pussy_move_thr) { visualShield.setPussyMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_pussy_speed) { visualShield.setPussySpeed(it / 100f) }
        bindSeekBar(R.id.seek_pussy_speed_thr) { visualShield.setPussySpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_pussy_lr_filter) { visualShield.setPussyLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_pussy_ud_filter) { visualShield.setPussyUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_pussy_random_filter) { visualShield.setPussyRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_pussy_center_filter) { visualShield.setPussyCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_pussy_corner_filter) { visualShield.setPussyCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_pussy_vib_filter) { visualShield.setPussyVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_pussy_bip_neg) { visualShield.setPussyBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_pussy_bip_pos) { visualShield.setPussyBipPos(it.toFloat()) }
        bindSeekBar(R.id.seek_dick_ambient) { visualShield.setDickAmbient(it / 100f) }
        bindSeekBar(R.id.seek_dick_wave) { visualShield.setDickWave(it / 50f) }
        bindSeekBar(R.id.seek_dick_move) { visualShield.setDickMove(it / 100f) }
        bindSeekBar(R.id.seek_dick_move_thr) { visualShield.setDickMoveThr(it / 100f) }
        bindSeekBar(R.id.seek_dick_speed) { visualShield.setDickSpeed(it / 100f) }
        bindSeekBar(R.id.seek_dick_speed_thr) { visualShield.setDickSpeedThr(it / 100f) }
        bindSeekBar(R.id.seek_dick_lr_filter) { visualShield.setDickLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_dick_ud_filter) { visualShield.setDickUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_dick_random_filter) { visualShield.setDickRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_dick_center_filter) { visualShield.setDickCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_dick_corner_filter) { visualShield.setDickCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_dick_vib_filter) { visualShield.setDickVibFilter(it / 100f) }
        bindSeekBar(R.id.seek_dick_bip_neg) { visualShield.setDickBipNeg(-it.toFloat()) }
        bindSeekBar(R.id.seek_dick_bip_pos) { visualShield.setDickBipPos(it.toFloat()) }

        findViewById<Switch>(R.id.switch_motion)?.setOnCheckedChangeListener { _, c ->
            motionHub?.enabled = c
            if (c) motionHub?.start() else systemGuard?.stop()
        motionHub?.stop()
        }
        bindSeekBar(R.id.seek_motion_speed) { motionHub?.motionSpeed = it / 100f }
        bindSeekBar(R.id.seek_motion_thr) { motionHub?.motionThr = it / 100f }
        bindSeekBar(R.id.seek_motion_move_lv) { motionHub?.moveLv = it / 100f }
        bindSeekBar(R.id.seek_motion_move_thr) { motionHub?.moveThr = it / 100f }
        bindSeekBar(R.id.seek_motion_wave_lv) { motionHub?.waveLv = it / 100f }
        bindSeekBar(R.id.seek_motion_wave_thr) { motionHub?.waveThr = it / 100f }
        bindSeekBar(R.id.seek_axis_x_lv) { motionHub?.axisXLv = it / 100f }
        bindSeekBar(R.id.seek_axis_y_lv) { motionHub?.axisYLv = it / 100f }
        bindSeekBar(R.id.seek_axis_z_lv) { motionHub?.axisZLv = it / 100f }
        bindSeekBar(R.id.seek_axis_x_thr) { motionHub?.axisXThr = it / 100f }
        bindSeekBar(R.id.seek_axis_y_thr) { motionHub?.axisYThr = it / 100f }
        bindSeekBar(R.id.seek_axis_z_thr) { motionHub?.axisZThr = it / 100f }
        bindSeekBar(R.id.seek_pitch_l_lv) { motionHub?.pitchLLv = it / 100f }
        bindSeekBar(R.id.seek_pitch_r_lv) { motionHub?.pitchRLv = it / 100f }
        bindSeekBar(R.id.seek_pitch_l_thr) { motionHub?.pitchLThr = it / 100f }
        bindSeekBar(R.id.seek_pitch_r_thr) { motionHub?.pitchRThr = it / 100f }
        bindSeekBar(R.id.seek_pitch_up_lv) { motionHub?.pitchUpLv = it / 100f }
        bindSeekBar(R.id.seek_pitch_down_lv) { motionHub?.pitchDownLv = it / 100f }
        bindSeekBar(R.id.seek_pitch_up_thr) { motionHub?.pitchUpThr = it / 100f }
        bindSeekBar(R.id.seek_pitch_down_thr) { motionHub?.pitchDownThr = it / 100f }
        bindSeekBar(R.id.seek_motion_audio_mix) { motionHub?.audioMix = it / 100f }

        findViewById<Switch>(R.id.switch_attraction)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.enabled = c }
        findViewById<Switch>(R.id.switch_magic_attr)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.magicOn = c }
        findViewById<Switch>(R.id.switch_like_attract)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.attractOn = c }
        findViewById<Switch>(R.id.switch_gravity_magic)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.gravityOn = c }
        findViewById<Switch>(R.id.switch_send_energy)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.sendOn = c }
        findViewById<Switch>(R.id.switch_receive_energy)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.receiveOn = c }
        findViewById<Switch>(R.id.switch_accept_energy)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.acceptOn = c }
        findViewById<Switch>(R.id.switch_return_energy)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.returnBackOn = c }
        findViewById<Switch>(R.id.switch_teleport)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.teleportOn = c }
        findViewById<Switch>(R.id.switch_universe)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.universeTransportOn = c }
        findViewById<Switch>(R.id.switch_time_travel)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.timeTravelOn = c }
        findViewById<Switch>(R.id.switch_grav_waves)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.gravWavesOn = c }
        findViewById<Switch>(R.id.switch_intention)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.intentionOn = c }
        findViewById<Switch>(R.id.switch_visualise)?.setOnCheckedChangeListener { _, c -> visualShield.attraction.visualiseOn = c }
        bindSeekBar(R.id.seek_teleport_lv) { visualShield.attraction.teleportLv = it / 100f }
        bindSeekBar(R.id.seek_universe_lv) { visualShield.attraction.universeLv = it / 100f }
        bindSeekBar(R.id.seek_time_travel_lv) { visualShield.attraction.timeTravelLv = it / 100f }
        bindSeekBar(R.id.seek_grav_wave_lv) { visualShield.attraction.gravWaveLv = it / 100f }
        bindSeekBar(R.id.seek_intention_lv) { visualShield.attraction.intentionLv = it / 100f }
        bindSeekBar(R.id.seek_visualise_lv) { visualShield.attraction.visualiseLv = it / 100f }
        bindSeekBar(R.id.seek_mind_energy) { visualShield.attraction.mindEnergy = it / 100f }
        bindSeekBar(R.id.seek_body_energy) { visualShield.attraction.bodyEnergy = it / 100f }
        bindSeekBar(R.id.seek_attract_lv) { visualShield.attraction.attractLv = it / 100f }
        bindSeekBar(R.id.seek_gravity_lv) { visualShield.attraction.gravityLv = it / 100f }
        bindSeekBar(R.id.seek_magic_lv_attr) { visualShield.attraction.magicLv = it / 100f }
        bindSeekBar(R.id.seek_send_lv) { visualShield.attraction.sendLv = it / 100f }
        bindSeekBar(R.id.seek_receive_lv) { visualShield.attraction.receiveLv = it / 100f }
        bindSeekBar(R.id.seek_accept_lv) { visualShield.attraction.acceptLv = it / 100f }
        bindSeekBar(R.id.seek_return_lv) { visualShield.attraction.returnLv = it / 100f }

        findViewById<Switch>(R.id.switch_bulletproof)?.setOnCheckedChangeListener { _, c -> visualShield.armor.bulletproofOn = c; syncArmor() }
        findViewById<Switch>(R.id.switch_knife_proof)?.setOnCheckedChangeListener { _, c -> visualShield.armor.knifeProofOn = c; syncArmor() }
        findViewById<Switch>(R.id.switch_missile_proof)?.setOnCheckedChangeListener { _, c -> visualShield.armor.missileProofOn = c; syncArmor() }
        findViewById<Switch>(R.id.switch_boom_proof)?.setOnCheckedChangeListener { _, c -> visualShield.armor.boomProofOn = c; syncArmor() }
        findViewById<Switch>(R.id.switch_fire_proof)?.setOnCheckedChangeListener { _, c -> visualShield.armor.fireProofOn = c; syncArmor() }
        findViewById<Switch>(R.id.switch_physical_audio)?.setOnCheckedChangeListener { _, c -> visualShield.armor.physicalAudioOn = c; syncArmor() }
        findViewById<Switch>(R.id.switch_emf_shield)?.setOnCheckedChangeListener { _, c -> visualShield.armor.emfShieldOn = c; syncArmor() }
        findViewById<Switch>(R.id.switch_nfc_shield)?.setOnCheckedChangeListener { _, c -> visualShield.armor.nfcShieldOn = c; syncArmor() }
        findViewById<Switch>(R.id.switch_ble_shield)?.setOnCheckedChangeListener { _, c -> visualShield.armor.bleShieldOn = c; syncArmor() }
        findViewById<Switch>(R.id.switch_magic_shield)?.setOnCheckedChangeListener { _, c -> visualShield.armor.magicShieldOn = c; syncArmor() }
        findViewById<Switch>(R.id.switch_audio_shield)?.setOnCheckedChangeListener { _, c -> visualShield.armor.audioShieldOn = c; syncArmor() }
        findViewById<Switch>(R.id.switch_hardware_shield)?.setOnCheckedChangeListener { _, c -> visualShield.armor.hardwareShieldOn = c; syncArmor() }
        bindSeekBar(R.id.seek_bulletproof_lv) { visualShield.armor.bulletproofLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_knife_proof_lv) { visualShield.armor.knifeProofLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_missile_proof_lv) { visualShield.armor.missileProofLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_boom_proof_lv) { visualShield.armor.boomProofLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_fire_proof_lv) { visualShield.armor.fireProofLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_physical_audio_lv) { visualShield.armor.physicalAudioLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_emf_lv) { visualShield.armor.emfLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_nfc_lv) { visualShield.armor.nfcLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_ble_lv) { visualShield.armor.bleLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_magic_lv) { visualShield.armor.magicLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_audio_shield_lv) { visualShield.armor.audioLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_hardware_shield_lv) { visualShield.armor.hardwareLv = it / 100f; syncArmor() }
        bindSeekBar(R.id.seek_armor_hold) { visualShield.armor.setHoldMsAll(it); syncArmor() }
        bindSeekBar(R.id.seek_armor_decay) { visualShield.armor.setDecayMsAll(it); syncArmor() }
        syncArmor()

        bindSeekBar(R.id.seek_hardware) { visualShield.setHardwareIntensity(it / 100f) }
        bindSeekBar(R.id.seek_color_threshold) { visualShield.setColorThreshold(it) }
        bindSeekBar(R.id.seek_lr_filter) { visualShield.setLrFilter(it / 100f) }
        bindSeekBar(R.id.seek_ud_filter) { visualShield.setUdFilter(it / 100f) }
        bindSeekBar(R.id.seek_random_filter) { visualShield.setRandomFilter(it / 100f) }
        bindSeekBar(R.id.seek_center_filter) { visualShield.setCenterFilter(it / 100f) }
        bindSeekBar(R.id.seek_corner_filter) { visualShield.setCornerFilter(it / 100f) }
        bindSeekBar(R.id.seek_vib_freq_filter) { visualShield.setVibFreqFilter(it / 100f) }
        bindSeekBar(R.id.seek_texture_shift) { visualShield.setTextureShift(it / 100f) }
        bindSeekBar(R.id.seek_camera_feedback) { visualShield.setCameraFeedback(it / 100f) }
        bindSeekBar(R.id.seek_threshold_db) { audioProcessor?.setThresholdDb(it) }
        bindSeekBar(R.id.seek_feedback_gain) { audioProcessor?.setFeedbackGain(it) }
        bindSeekBar(R.id.seek_decay_time) { audioProcessor?.setDecayTimeMs(it) }
    }

    private fun setupEyeTuning() {
        bindSeekBar(R.id.seek_eye_contrast) { visualShield.setEyeContrast(it / 100f) }
        bindSeekBar(R.id.seek_eye_contrast_thr) { visualShield.setEyeContrastThr(it / 100f) }
        bindSeekBar(R.id.seek_eye_brightness) { visualShield.setEyeBrightness((it - 100) / 100f) }
        bindSeekBar(R.id.seek_eye_brightness_thr) { visualShield.setEyeBrightnessThr(it / 100f) }
        bindSeekBar(R.id.seek_eye_thr_r) { visualShield.setEyeColorThrR(it) }
        bindSeekBar(R.id.seek_eye_thr_g) { visualShield.setEyeColorThrG(it) }
        bindSeekBar(R.id.seek_eye_thr_b) { visualShield.setEyeColorThrB(it) }
        bindSeekBar(R.id.seek_eye_thr_soft) { visualShield.setEyeThrSoftness(it / 100f) }
        findViewById<Switch>(R.id.switch_eye_contrast)?.setOnCheckedChangeListener { _, c -> visualShield.setEyeContrastOn(c) }
        findViewById<Switch>(R.id.switch_eye_brightness)?.setOnCheckedChangeListener { _, c -> visualShield.setEyeBrightnessOn(c) }
        findViewById<Switch>(R.id.switch_eye_threshold)?.setOnCheckedChangeListener { _, c -> visualShield.setEyeThresholdOn(c) }
        findViewById<Switch>(R.id.switch_eye_invert)?.setOnCheckedChangeListener { _, c -> visualShield.setEyeInvert(c) }
        val modeBtn = findViewById<Button>(R.id.btn_eye_thr_mode)
        modeBtn?.setOnClickListener {
            visualShield.setEyeThrMode(visualShield.eyeTuning.mode + 1)
            modeBtn.text = "Threshold mode: ${VisualShieldView.EyeTuning.MODE_NAMES[visualShield.eyeTuning.mode]} (tap to change)"
        }
        findViewById<Button>(R.id.btn_eye_reset)?.setOnClickListener {
            visualShield.resetEyeTuning()
            val t = visualShield.eyeTuning
            findViewById<SeekBar>(R.id.seek_eye_contrast)?.progress = 100
            findViewById<SeekBar>(R.id.seek_eye_contrast_thr)?.progress = 0
            findViewById<SeekBar>(R.id.seek_eye_brightness)?.progress = 100
            findViewById<SeekBar>(R.id.seek_eye_brightness_thr)?.progress = 0
            findViewById<SeekBar>(R.id.seek_eye_thr_r)?.progress = 0
            findViewById<SeekBar>(R.id.seek_eye_thr_g)?.progress = 0
            findViewById<SeekBar>(R.id.seek_eye_thr_b)?.progress = 0
            findViewById<SeekBar>(R.id.seek_eye_thr_soft)?.progress = 25
            findViewById<Switch>(R.id.switch_eye_contrast)?.isChecked = t.contrastOn
            findViewById<Switch>(R.id.switch_eye_brightness)?.isChecked = t.brightnessOn
            findViewById<Switch>(R.id.switch_eye_threshold)?.isChecked = t.thresholdOn
            findViewById<Switch>(R.id.switch_eye_invert)?.isChecked = t.invert
            modeBtn?.text = "Threshold mode: FLOOR (tap to change)"
        }
    }

    
    
    
    
    
    
    
    

    


    private fun setupBrainAnatomyPanels() {
        try {
            BrainPanels.build(
                this,
                findViewById(R.id.panel_brain3d),
                findViewById(R.id.panel_anatomy3d),
                visualShield
            )
            findViewById<android.widget.LinearLayout>(R.id.panel_rings3d)?.let {
                AnatomyRingPanels.build(this, it, visualShield)
            }
            sdSound = SdSoundBank(this, visualShield.soundBank).also { sd ->
                visualShield.sdSound = sd
                visualShield.bodySoundFx.onPlayEffect = { track, intensity, rate, _ ->
                    sd.playEffect(track, intensity, rate)
                }
                findViewById<android.widget.LinearLayout>(R.id.panel_sdsound)?.let {
                    OnenessSdPanels.buildSd(this, it, sd, visualShield.bodySoundFx) { launchSoundFolderPicker() }
                }
                sd.scan()
            }
            findViewById<android.widget.LinearLayout>(R.id.panel_oneness)?.let {
                OnenessSdPanels.buildOneness(this, it, visualShield)
            }
            audioProcessor?.pitch?.let { g ->
                findViewById<android.widget.LinearLayout>(R.id.panel_pitch)?.let { PitchGuardPanels.build(this, it, g) }
            }
        } catch (e: Exception) {
            android.util.Log.w("SenseGuard", "BrainPanels: ${e.message}")
        }
        findViewById<Switch>(R.id.switch_body_region_rescan)?.setOnCheckedChangeListener { _, c ->
            visualShield.bodyRegionRescanOn = c
        }
        bindSeekBar(R.id.seek_body_region_amb_boost) { visualShield.bodyRegionAmbientBoost = it / 100f }
        findViewById<Switch>(R.id.switch_brain_contrast)?.setOnCheckedChangeListener { _, c ->
            visualShield.setBrainContrastOn(c)
        }
        findViewById<SeekBar>(R.id.seek_brain_contrast)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                visualShield.setBrainContrast(p / 100f)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_brain_contrast_thr) { visualShield.setBrainContrastThr(it / 100f) }
        findViewById<Switch>(R.id.switch_brain_brightness)?.setOnCheckedChangeListener { _, c ->
            visualShield.setBrainBrightnessOn(c)
        }
        findViewById<SeekBar>(R.id.seek_brain_brightness)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                visualShield.setBrainBrightness((p - 100) / 100f)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_brain_brightness_thr) { visualShield.setBrainBrightnessThr(it / 100f) }
        val h = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                val n = visualShield.bodyRegionActiveN
                val o = (visualShield.bodyRegionRescanOut * 100).toInt()
                findViewById<TextView>(R.id.txt_noise3d)?.text = visualShield.noise3d.statusLine()
                findViewById<TextView>(R.id.txt_body_region_rescan)?.text =
                    "REGIONS active=$n/18 rescan=$o% · brain L=${(visualShield.brain3d.left.out*100).toInt()}% R=${(visualShield.brain3d.right.out*100).toInt()}%"
                h.postDelayed(this, 250)
            }
        }
        h.post(tick)
    }

    private fun setupBodyMixer() {
        val bm = visualShield.bodyMixer
        findViewById<Switch>(R.id.switch_body_mix)?.setOnCheckedChangeListener { _, c -> bm.enabled = c }
        findViewById<Switch>(R.id.switch_bm_b84)?.setOnCheckedChangeListener { _, c -> bm.srcBody84On = c }
        bindSeekBar(R.id.seek_bm_b84_w) { bm.srcBody84W = it / 100f }
        findViewById<Switch>(R.id.switch_bm_pose)?.setOnCheckedChangeListener { _, c -> bm.srcPoseOn = c }
        bindSeekBar(R.id.seek_bm_pose_w) { bm.srcPoseW = it / 100f }
        findViewById<Switch>(R.id.switch_bm_yolo)?.setOnCheckedChangeListener { _, c -> bm.srcYoloOn = c }
        bindSeekBar(R.id.seek_bm_yolo_w) { bm.srcYoloW = it / 100f }
        findViewById<Switch>(R.id.switch_bm_armor)?.setOnCheckedChangeListener { _, c -> bm.srcArmorOn = c }
        bindSeekBar(R.id.seek_bm_armor_w) { bm.srcArmorW = it / 100f }
        findViewById<Switch>(R.id.switch_bm_region)?.setOnCheckedChangeListener { _, c -> bm.srcRegionOn = c }
        bindSeekBar(R.id.seek_bm_region_w) { bm.srcRegionW = it / 100f }
        findViewById<Switch>(R.id.switch_bm_inside)?.setOnCheckedChangeListener { _, c -> bm.insideOn = c }
        bindSeekBar(R.id.seek_bm_in_thr) { bm.insideThr = it / 100f }
        bindSeekBar(R.id.seek_bm_in_lv) { bm.insideLv = it / 100f }
        bindSeekBar(R.id.seek_bm_in_move_thr) { bm.insideMoveThr = it / 100f }
        bindSeekBar(R.id.seek_bm_in_move_lv) { bm.insideMoveLv = it / 100f }
        bindSeekBar(R.id.seek_bm_in_wave_thr) { bm.insideWaveThr = it / 100f }
        bindSeekBar(R.id.seek_bm_in_wave_lv) { bm.insideWaveLv = it / 100f }
        bindSeekBar(R.id.seek_bm_in_speed_thr) { bm.insideSpeedThr = it / 100f }
        bindSeekBar(R.id.seek_bm_in_speed_lv) { bm.insideSpeedLv = it / 100f }
        bindSeekBar(R.id.seek_bm_in_atmo_thr) { bm.insideAtmoThr = it / 100f }
        bindSeekBar(R.id.seek_bm_in_atmo_lv) { bm.insideAtmoLv = it / 100f }
        bindSeekBar(R.id.seek_bm_in_wsp_thr) { bm.insideWspThr = it / 100f }
        bindSeekBar(R.id.seek_bm_in_wsp_lv) { bm.insideWspLv = it / 100f }
        findViewById<Switch>(R.id.switch_bm_outside)?.setOnCheckedChangeListener { _, c -> bm.outsideOn = c }
        bindSeekBar(R.id.seek_bm_out_thr) { bm.outsideThr = it / 100f }
        bindSeekBar(R.id.seek_bm_out_lv) { bm.outsideLv = it / 100f }
        bindSeekBar(R.id.seek_bm_out_move_thr) { bm.outsideMoveThr = it / 100f }
        bindSeekBar(R.id.seek_bm_out_move_lv) { bm.outsideMoveLv = it / 100f }
        bindSeekBar(R.id.seek_bm_out_wave_thr) { bm.outsideWaveThr = it / 100f }
        bindSeekBar(R.id.seek_bm_out_wave_lv) { bm.outsideWaveLv = it / 100f }
        bindSeekBar(R.id.seek_bm_out_speed_thr) { bm.outsideSpeedThr = it / 100f }
        bindSeekBar(R.id.seek_bm_out_speed_lv) { bm.outsideSpeedLv = it / 100f }
        bindSeekBar(R.id.seek_bm_out_atmo_thr) { bm.outsideAtmoThr = it / 100f }
        bindSeekBar(R.id.seek_bm_out_atmo_lv) { bm.outsideAtmoLv = it / 100f }
        bindSeekBar(R.id.seek_bm_out_wsp_thr) { bm.outsideWspThr = it / 100f }
        bindSeekBar(R.id.seek_bm_out_wsp_lv) { bm.outsideWspLv = it / 100f }

        findViewById<Switch>(R.id.switch_bm_seg_inside)?.setOnCheckedChangeListener { _, c -> bm.segInsideOn = c }
        findViewById<Switch>(R.id.switch_bm_seg_multi)?.setOnCheckedChangeListener { _, c -> bm.segInsideMulti = c }
        findViewById<SeekBar>(R.id.seek_bm_seg_count)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { bm.segInsideCount = p.coerceIn(1, 10) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        fun bulkSeg() { bm.applyBulkSeg() }
        bindSeekBar(R.id.seek_bm_seg_thr) { bm.bulkSegThr = it / 100f; bulkSeg() }
        bindSeekBar(R.id.seek_bm_seg_lv) { bm.bulkSegLv = it / 100f; bulkSeg() }
        bindSeekBar(R.id.seek_bm_seg_atmo_thr) { bm.bulkSegAtmoThr = it / 100f; bulkSeg() }
        bindSeekBar(R.id.seek_bm_seg_atmo_lv) { bm.bulkSegAtmoLv = it / 100f; bulkSeg() }
        bindSeekBar(R.id.seek_bm_seg_move_thr) { bm.bulkSegMoveThr = it / 100f; bulkSeg() }
        bindSeekBar(R.id.seek_bm_seg_move_lv) { bm.bulkSegMoveLv = it / 100f; bulkSeg() }
        bindSeekBar(R.id.seek_bm_seg_wave_thr) { bm.bulkSegWaveThr = it / 100f; bulkSeg() }
        bindSeekBar(R.id.seek_bm_seg_wave_lv) { bm.bulkSegWaveLv = it / 100f; bulkSeg() }

        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_body_mix)?.text = bm.statusLine()
                handler.postDelayed(this, 200)
            }
        }
        handler.post(tick)
    }

    private fun setupYoloSeg() {
        val ys = visualShield.yoloSeg
        findViewById<Switch>(R.id.switch_yolo_seg)?.setOnCheckedChangeListener { _, c -> ys.enabled = c }
        findViewById<Switch>(R.id.switch_camera_body_track)?.let { switch ->
            switch.isChecked = visualShield.cameraBodyTrackOn
            switch.setOnCheckedChangeListener { _, c ->
                visualShield.cameraBodyTrackOn = c
                MemoryPaths.putBool("camera_body_track", c)
            }
        }
        findViewById<Switch>(R.id.switch_camera_gaze)?.let { switch ->
            switch.isChecked = visualShield.cameraGazeOn
            switch.setOnCheckedChangeListener { _, c -> visualShield.setCameraGazeEnabled(c) }
        }
        findViewById<Switch>(R.id.switch_yolo_multi)?.setOnCheckedChangeListener { _, c -> ys.multiSeg = c }
        findViewById<SeekBar>(R.id.seek_yolo_seg_count)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { ys.segCount = p.coerceIn(1, 10) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_yolo_pose)?.setOnCheckedChangeListener { _, c -> ys.poseLinkOn = c }
        bindSeekBar(R.id.seek_yolo_pose_thr) { ys.poseThr = it / 100f }
        bindSeekBar(R.id.seek_yolo_pose_lv) { ys.poseLv = it / 100f }
        findViewById<Switch>(R.id.switch_yolo_in_atmo)?.setOnCheckedChangeListener { _, c -> ys.insideAtmoOn = c }
        bindSeekBar(R.id.seek_yolo_in_atmo_thr) { ys.insideAtmoThr = it / 100f }
        bindSeekBar(R.id.seek_yolo_in_atmo_lv) { ys.insideAtmoLv = it / 100f }
        findViewById<Switch>(R.id.switch_yolo_out_atmo)?.setOnCheckedChangeListener { _, c -> ys.outsideAtmoOn = c }
        bindSeekBar(R.id.seek_yolo_out_atmo_thr) { ys.outsideAtmoThr = it / 100f }
        bindSeekBar(R.id.seek_yolo_out_atmo_lv) { ys.outsideAtmoLv = it / 100f }
        // Bulk → all segments (same pose/motion/atmo set)
        fun bulk() { ys.applyBulkToAll() }
        bindSeekBar(R.id.seek_yolo_bulk_thr) { ys.bulkThr = it / 100f; bulk() }
        bindSeekBar(R.id.seek_yolo_bulk_lv) { ys.bulkLv = it / 100f; bulk() }
        bindSeekBar(R.id.seek_yolo_bulk_move_thr) { ys.bulkMoveThr = it / 100f; bulk() }
        bindSeekBar(R.id.seek_yolo_bulk_move_lv) { ys.bulkMoveLv = it / 100f; bulk() }
        bindSeekBar(R.id.seek_yolo_bulk_wave_thr) { ys.bulkWaveThr = it / 100f; bulk() }
        bindSeekBar(R.id.seek_yolo_bulk_wave_lv) { ys.bulkWaveLv = it / 100f; bulk() }
        bindSeekBar(R.id.seek_yolo_bulk_speed_thr) { ys.bulkSpeedThr = it / 100f; bulk() }
        bindSeekBar(R.id.seek_yolo_bulk_speed_lv) { ys.bulkSpeedLv = it / 100f; bulk() }
        bindSeekBar(R.id.seek_yolo_bulk_atmo_thr) { ys.bulkAtmoThr = it / 100f; bulk() }
        bindSeekBar(R.id.seek_yolo_bulk_atmo_lv) { ys.bulkAtmoLv = it / 100f; bulk() }
        bindSeekBar(R.id.seek_yolo_bulk_wsp_thr) { ys.bulkWspThr = it / 100f; bulk() }
        bindSeekBar(R.id.seek_yolo_bulk_wsp_lv) { ys.bulkWspLv = it / 100f; bulk() }
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_yolo_seg)?.text = ys.statusLine()
                findViewById<TextView>(R.id.txt_camera_body_feedback)?.text = ys.statusLine()
                findViewById<TextView>(R.id.txt_human_detector)?.text =
                    "LIVE CAMERA · ${visualShield.cameraDetection.status}"
                handler.postDelayed(this, 200)
            }
        }
        handler.post(tick)
    }

    private fun setupPoseSurface() {
        val ps = visualShield.poseSurface
        findViewById<Switch>(R.id.switch_pose_surface)?.setOnCheckedChangeListener { _, c -> ps.enabled = c }
        findViewById<Switch>(R.id.switch_pose_body)?.setOnCheckedChangeListener { _, c -> ps.bodyOn = c }
        bindSeekBar(R.id.seek_pose_body_thr) { ps.bodyThr = it / 100f }
        bindSeekBar(R.id.seek_pose_body_lv) { ps.bodyLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_body_move)?.setOnCheckedChangeListener { _, c -> ps.bodyMoveOn = c }
        bindSeekBar(R.id.seek_pose_body_move_thr) { ps.bodyMoveThr = it / 100f }
        bindSeekBar(R.id.seek_pose_body_move_lv) { ps.bodyMoveLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_body_wave)?.setOnCheckedChangeListener { _, c -> ps.bodyWaveOn = c }
        bindSeekBar(R.id.seek_pose_body_wave_thr) { ps.bodyWaveThr = it / 100f }
        bindSeekBar(R.id.seek_pose_body_wave_lv) { ps.bodyWaveLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_body_speed)?.setOnCheckedChangeListener { _, c -> ps.bodySpeedOn = c }
        bindSeekBar(R.id.seek_pose_body_speed_thr) { ps.bodySpeedThr = it / 100f }
        bindSeekBar(R.id.seek_pose_body_speed_lv) { ps.bodySpeedLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_body_atmo)?.setOnCheckedChangeListener { _, c -> ps.bodyAtmoOn = c }
        bindSeekBar(R.id.seek_pose_body_atmo_thr) { ps.bodyAtmoThr = it / 100f }
        bindSeekBar(R.id.seek_pose_body_atmo_lv) { ps.bodyAtmoLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_body_wsp)?.setOnCheckedChangeListener { _, c -> ps.bodyWaveSpareOn = c }
        bindSeekBar(R.id.seek_pose_body_wsp_thr) { ps.bodyWaveSpareThr = it / 100f }
        bindSeekBar(R.id.seek_pose_body_wsp_lv) { ps.bodyWaveSpareLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_body_bip)?.setOnCheckedChangeListener { _, c -> ps.bodyBipOn = c }
        findViewById<SeekBar>(R.id.seek_pose_body_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { ps.bodyBipNeg = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_pose_body_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { ps.bodyBipPos = p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_pose_enemy)?.setOnCheckedChangeListener { _, c -> ps.enemyOn = c }
        bindSeekBar(R.id.seek_pose_enemy_thr) { ps.enemyThr = it / 100f }
        bindSeekBar(R.id.seek_pose_enemy_lv) { ps.enemyLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_enemy_move)?.setOnCheckedChangeListener { _, c -> ps.enemyMoveOn = c }
        bindSeekBar(R.id.seek_pose_enemy_move_thr) { ps.enemyMoveThr = it / 100f }
        bindSeekBar(R.id.seek_pose_enemy_move_lv) { ps.enemyMoveLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_enemy_wave)?.setOnCheckedChangeListener { _, c -> ps.enemyWaveOn = c }
        bindSeekBar(R.id.seek_pose_enemy_wave_thr) { ps.enemyWaveThr = it / 100f }
        bindSeekBar(R.id.seek_pose_enemy_wave_lv) { ps.enemyWaveLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_enemy_speed)?.setOnCheckedChangeListener { _, c -> ps.enemySpeedOn = c }
        bindSeekBar(R.id.seek_pose_enemy_speed_thr) { ps.enemySpeedThr = it / 100f }
        bindSeekBar(R.id.seek_pose_enemy_speed_lv) { ps.enemySpeedLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_enemy_atmo)?.setOnCheckedChangeListener { _, c -> ps.enemyAtmoOn = c }
        bindSeekBar(R.id.seek_pose_enemy_atmo_thr) { ps.enemyAtmoThr = it / 100f }
        bindSeekBar(R.id.seek_pose_enemy_atmo_lv) { ps.enemyAtmoLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_enemy_wsp)?.setOnCheckedChangeListener { _, c -> ps.enemyWaveSpareOn = c }
        bindSeekBar(R.id.seek_pose_enemy_wsp_thr) { ps.enemyWaveSpareThr = it / 100f }
        bindSeekBar(R.id.seek_pose_enemy_wsp_lv) { ps.enemyWaveSpareLv = it / 100f }
        findViewById<Switch>(R.id.switch_pose_enemy_bip)?.setOnCheckedChangeListener { _, c -> ps.enemyBipOn = c }
        findViewById<SeekBar>(R.id.seek_pose_enemy_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { ps.enemyBipNeg = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_pose_enemy_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { ps.enemyBipPos = p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_pose_ambient)?.setOnCheckedChangeListener { _, c -> ps.ambientOn = c }
        bindSeekBar(R.id.seek_pose_ambient_thr) { ps.ambientThr = it / 100f }
        bindSeekBar(R.id.seek_pose_ambient_lv) { ps.ambientLv = it / 100f }
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_pose_surface)?.text = ps.statusLine()
                handler.postDelayed(this, 200)
            }
        }
        handler.post(tick)
    }

    private fun setupArMeasure() {
        val ar = visualShield.arMeasure
        ar.attach(this)
        findViewById<Button>(R.id.btn_ar_world)?.setOnClickListener {
            // ARCore and AudioRecord need exclusive device ownership here.
            // Release the studio camera/mic before entering the separate ARWorld activity.
            try {
            visualShield.cameraExclusiveGuard.onBackground(
                arPause = { visualShield.arMeasure.pauseSession() },
                legacyStop = {
                    try { cameraManager?.stopCamera() } catch (_: Throwable) {}
                }
            )
        } catch (_: Throwable) {
            visualShield.arMeasure.pauseSession()
        }
        // also keep explicit pause
        visualShield.arMeasure.pauseSession()
            cameraManager?.stopCamera()
            audioProcessor?.stopListening()
            startActivity(Intent(this, ArWorldActivity::class.java))
            /* Camera AR mesh world panel attached below */
        }
        findViewById<Switch>(R.id.switch_ar_measure)?.setOnCheckedChangeListener { _, c ->
            ar.enabled = c
            if (c) startArCoreSession() else {
                ar.stopSession()
                // restore app camera when AR stops
                cameraPreview.post { tryStartCamera() }
            }
        }
        findViewById<Switch>(R.id.switch_ar_tracking)?.setOnCheckedChangeListener { _, c ->
            ar.trackingOn = c
            if (c && ar.enabled) startArCoreSession() else if (!c) {
                ar.pauseSession()
                cameraPreview.post { tryStartCamera() }
            }
        }
        bindSeekBar(R.id.seek_ar_track_thr) { ar.trackThr = it / 100f }
        bindSeekBar(R.id.seek_ar_intensity) { ar.intensity = it / 100f }
        bindSeekBar(R.id.seek_ar_intensity_thr) { ar.intensityThr = it / 100f }
        bindSeekBar(R.id.seek_ar_measure_thr) { ar.measureThr = it / 100f }
        findViewById<SeekBar>(R.id.seek_ar_scale_type)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                ar.setScaleTypeId(p.coerceIn(0, 4))
                findViewById<TextView>(R.id.txt_ar_scale_label)?.text =
                    "Scale: ${ar.scaleType.label}"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // ARCore frame loop (real Session.update)
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                if (ar.enabled && ar.trackingOn) {
                    if (ar.sessionRunning) {
                        ar.updateFromArCore()
                    }
                }
                findViewById<TextView>(R.id.txt_ar_measure)?.text = ar.statusLine()
                handler.postDelayed(this, 33) // ~30 Hz AR update
            }
        }
        handler.post(tick)
    }

    /** Start real Google ARCore session (stops legacy Camera first — ARCore needs exclusive camera). */
    /**
     * Hand exclusive camera ownership to ARCore.
     * Legacy Camera API must be fully released first or Session.resume()
     * throws CameraNotAvailableException.
     */
    private fun startArCoreSession() {
        try {
            visualShield.cameraExclusiveGuard.beforeStartAr {
                try { cameraManager?.stopCamera() } catch (_: Throwable) {}
                try { cameraManager?.forceReleaseForArCore() } catch (_: Throwable) {}
            }
            visualShield.cameraExclusiveGuard.onArStarted()
        } catch (_: Throwable) {}

        try {
            cameraManager?.stopCamera()
        } catch (_: Exception) {}
        humanDetector.reset("ARCore owns camera · human detector paused")
        // Give the camera HAL time to fully free the device after release()
        cameraPreview.postDelayed({
            tryStartArCoreWithRetries(attempt = 0)
        }, 280)
    }

    private fun tryStartArCoreWithRetries(attempt: Int) {
        val ar = visualShield.arMeasure
        val ok = ar.startSession()
        val txt = findViewById<TextView>(R.id.txt_ar_measure)
        if (ok) {
            txt?.text = ar.statusLine()
            return
        }
        val err = ar.lastError ?: "start failed"
        // If camera still busy, stop again and retry a few times
        val busy = err.contains("Camera", ignoreCase = true) ||
            err.contains("busy", ignoreCase = true) ||
            err.contains("not available", ignoreCase = true)
        if (busy && attempt < 4) {
            try { cameraManager?.stopCamera() } catch (_: Exception) {}
            val delay = 200L + attempt * 150L
            cameraPreview.postDelayed({
                tryStartArCoreWithRetries(attempt + 1)
            }, delay)
            txt?.text = "ARCore: retrying ($attempt) — $err"
        } else {
            txt?.text = "ARCore: $err"
        }
    }

    
    
    private fun setupNoiseRate() {
        val nr = visualShield.noiseRate
        findViewById<Switch>(R.id.switch_noise_rate)?.setOnCheckedChangeListener { _, c -> nr.enabled = c }
        bindSeekBar(R.id.seek_noise_rate_thr) { nr.thr = it / 100f }
        bindSeekBar(R.id.seek_noise_rate_lv) { nr.level = it / 100f }
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_noise_rate)?.text =
                    visualShield.noiseRate.statusLine()
                handler.postDelayed(this, 200)
            }
        }
        handler.post(tick)
    }

        /** INSIDE ROTATION LOCKED — lives next to the existing LOCKED MODE switch and is remembered between runs. */
    private fun setupInsideRotationLock() {
        val fx = visualShield.anatomy3d.insideFx
        val key = "inlock_"
        fx.locked = MemoryPaths.getBool(key + "on", fx.locked)
        fx.followBodyLock = MemoryPaths.getBool(key + "follow", fx.followBodyLock)
        fx.lockWarp = MemoryPaths.getBool(key + "warp", fx.lockWarp)
        fx.lockRaw = MemoryPaths.getBool(key + "raw", fx.lockRaw)
        fx.lockedYaw = MemoryPaths.getFloat(key + "yaw", fx.lockedYaw)

        val txt = findViewById<TextView>(R.id.txt_inside_lock_yaw)
        val seek = findViewById<SeekBar>(R.id.seek_inside_lock_yaw)
        fun showYaw() {
            val deg = Math.toDegrees(fx.lockedYaw.toDouble()).toInt()
            txt?.text = "Locked inside angle · ${deg}°"
            seek?.progress = (deg + 180).coerceIn(0, 360)
        }
        fun bind(id: Int, get: () -> Boolean, set: (Boolean) -> Unit, k: String) {
            findViewById<Switch>(id)?.let { sw ->
                sw.isChecked = get()
                sw.setOnCheckedChangeListener { _, c -> set(c); MemoryPaths.putBool(key + k, c) }
            }
        }
        bind(R.id.switch_inside_rot_locked, { fx.locked }, { fx.locked = it }, "on")
        bind(R.id.switch_inside_lock_follow, { fx.followBodyLock }, { fx.followBodyLock = it }, "follow")
        bind(R.id.switch_inside_lock_warp, { fx.lockWarp }, { fx.lockWarp = it }, "warp")
        bind(R.id.switch_inside_lock_raw, { fx.lockRaw }, { fx.lockRaw = it }, "raw")
        showYaw()
        seek?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                fx.lockedYaw = Math.toRadians((p - 180).toDouble()).toFloat()
                MemoryPaths.putFloat(key + "yaw", fx.lockedYaw)
                txt?.text = "Locked inside angle · ${p - 180}°"
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        findViewById<Button>(R.id.btn_inside_lock_here)?.setOnClickListener {
            fx.lockHere()
            MemoryPaths.putBool(key + "on", true)
            MemoryPaths.putFloat(key + "yaw", fx.lockedYaw)
            findViewById<Switch>(R.id.switch_inside_rot_locked)?.isChecked = true
            showYaw()
        }
    }

    private fun setupCameraVhs() {
        val cv = visualShield.cameraVhs
        findViewById<Switch>(R.id.switch_camera_vhs)?.setOnCheckedChangeListener { _, c -> cv.enabled = c }
        findViewById<Switch>(R.id.switch_cam_thr)?.setOnCheckedChangeListener { _, c -> cv.camThrOn = c }
        bindSeekBar(R.id.seek_cam_thr) { cv.camThr = it / 100f }
        findViewById<Switch>(R.id.switch_vhs_track)?.setOnCheckedChangeListener { _, c ->
            cv.vhsOn = c
            cv.vhsTrackOn = c
        }
        bindSeekBar(R.id.seek_vhs_thr) { cv.vhsThr = it / 100f }
        bindSeekBar(R.id.seek_vhs_lv) { cv.vhsLv = it / 100f }
        findViewById<Switch>(R.id.switch_cam_contrast)?.setOnCheckedChangeListener { _, c -> cv.contrastOn = c }
        findViewById<SeekBar>(R.id.seek_cam_contrast)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { cv.contrast = p / 100f }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_cam_contrast_thr) { cv.contrastThr = it / 100f }
        findViewById<Switch>(R.id.switch_cam_brightness)?.setOnCheckedChangeListener { _, c -> cv.brightnessOn = c }
        findViewById<SeekBar>(R.id.seek_cam_brightness)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { cv.brightness = (p - 100) / 100f }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_cam_brightness_thr) { cv.brightnessThr = it / 100f }
        findViewById<Switch>(R.id.switch_cam_color_thr)?.setOnCheckedChangeListener { _, c -> cv.colorThrOn = c }
        bindSeekBar(R.id.seek_cam_color_thr) { cv.colorThr = it / 100f }
        findViewById<Switch>(R.id.switch_cam_ch_raw)?.setOnCheckedChangeListener { _, c -> cv.chRawOn = c }
        bindSeekBar(R.id.seek_cam_ch_r) { cv.chR = it / 100f }
        bindSeekBar(R.id.seek_cam_ch_g) { cv.chG = it / 100f }
        bindSeekBar(R.id.seek_cam_ch_b) { cv.chB = it / 100f }
        bindSeekBar(R.id.seek_cam_ch_r_thr) { cv.chRThr = it / 100f }
        bindSeekBar(R.id.seek_cam_ch_g_thr) { cv.chGThr = it / 100f }
        bindSeekBar(R.id.seek_cam_ch_b_thr) { cv.chBThr = it / 100f }
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_camera_vhs)?.text =
                    visualShield.cameraVhs.statusLine()
                handler.postDelayed(this, 200)
            }
        }
        handler.post(tick)
    }


    private fun setupScreenAmbientAndSoundBank() {
        val sa = visualShield.screenAmbient
        findViewById<android.widget.LinearLayout>(R.id.panel_screen_echo_mic)?.let {
            ScreenEchoPanels.build(this, it, sa.echoX)
        }

        findViewById<Switch>(R.id.switch_screen_amb_raw)?.setOnCheckedChangeListener { _, c ->
            visualShield.setScreenAmbientRaw(c)
        }
        findViewById<Switch>(R.id.switch_screen_centroid)?.setOnCheckedChangeListener { _, c ->
            visualShield.setScreenCentroidOn(c)
        }
        bindSeekBar(R.id.seek_screen_centroid_thr) { visualShield.setScreenCentroidThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_screen_centroid_lv) { visualShield.setScreenCentroidLv(it / 100f) }
        findViewById<Switch>(R.id.switch_screen_domination)?.setOnCheckedChangeListener { _, c ->
            visualShield.setScreenDominationOn(c)
        }
        bindSeekBar(R.id.seek_screen_domination_thr) {
            visualShield.setScreenDominationThr(0.05f + it / 100f * 0.95f)
            findViewById<TextView>(R.id.val_screen_domination_thr)?.text = "domination thr ${it}%"
        }
        bindSeekBar(R.id.seek_screen_domination_lv) {
            visualShield.setScreenDominationLv(it / 100f)
            findViewById<TextView>(R.id.val_screen_domination_lv)?.text = "domination level ${it}%"
        }
        findViewById<Switch>(R.id.switch_screen_domination_raw)?.setOnCheckedChangeListener { _, c ->
            visualShield.setScreenDominationRaw(c)
        }
        bindSeekBar(R.id.seek_screen_domination_hz_min) {
            val hz = 20f + it.toFloat()
            visualShield.setScreenDominationHzMin(hz)
            findViewById<TextView>(R.id.val_screen_domination_hz_min)?.text = "dom Hz min ${hz.toInt()}"
        }
        bindSeekBar(R.id.seek_screen_domination_hz_max) {
            val hz = it.toFloat().coerceAtLeast(100f)
            visualShield.setScreenDominationHzMax(hz)
            findViewById<TextView>(R.id.val_screen_domination_hz_max)?.text = "dom Hz max ${hz.toInt()}"
        }
        findViewById<Switch>(R.id.switch_screen_vertical)?.setOnCheckedChangeListener { _, c ->
            visualShield.setScreenVerticalOn(c)
        }
        bindSeekBar(R.id.seek_screen_vertical_thr) { visualShield.setScreenVerticalThr(0.05f + it / 100f * 0.95f) }
        bindSeekBar(R.id.seek_screen_vertical_lv) { visualShield.setScreenVerticalLv(it / 100f) }

        val sb = visualShield.soundBank
        findViewById<Switch>(R.id.switch_screen_ambient)?.setOnCheckedChangeListener { _, c -> sa.enabled = c }
        bindSeekBar(R.id.seek_screen_ambient_lv) { sa.ambientLv = it / 100f }
        findViewById<Switch>(R.id.switch_screen_ambient_thr)?.setOnCheckedChangeListener { _, c -> sa.thrOn = c }
        findViewById<SeekBar>(R.id.seek_screen_amb_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.bipNeg = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_screen_amb_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.bipPos = p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_screen_amb_spike)?.setOnCheckedChangeListener { _, c -> sa.spikeOn = c }
        bindSeekBar(R.id.seek_screen_amb_spike_thr) { sa.spikeThr = it / 100f }
        bindSeekBar(R.id.seek_screen_amb_spike_lv) { sa.spikeLv = it / 100f }
        findViewById<Switch>(R.id.switch_screen_amb_intensity)?.setOnCheckedChangeListener { _, c -> sa.intensityOn = c }
        bindSeekBar(R.id.seek_screen_amb_intensity_thr) { sa.intensityThr = it / 100f }
        bindSeekBar(R.id.seek_screen_amb_intensity_lv) { sa.intensityLv = it / 100f }
        findViewById<SeekBar>(R.id.seek_screen_visuals_mode)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.visualsMode = p.coerceIn(0, 3) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_visual_blocker)?.setOnCheckedChangeListener { _, c -> sa.visualBlockOn = c }
        bindSeekBar(R.id.seek_visual_block_thr) { sa.visualBlockThr = it / 100f }
        bindSeekBar(R.id.seek_visual_block_lv) { sa.visualBlockLv = it / 100f }
        findViewById<Switch>(R.id.switch_scr_pitch_lr)?.setOnCheckedChangeListener { _, c -> sa.pitchLrOn = c }
        bindSeekBar(R.id.seek_scr_pitch_lr_thr) { sa.pitchLrThr = it / 100f }
        bindSeekBar(R.id.seek_scr_pitch_lr_lv) { sa.pitchLrLv = it / 100f }
        findViewById<Switch>(R.id.switch_scr_pitch_ud)?.setOnCheckedChangeListener { _, c -> sa.pitchUdOn = c }
        bindSeekBar(R.id.seek_scr_pitch_ud_thr) { sa.pitchUdThr = it / 100f }
        bindSeekBar(R.id.seek_scr_pitch_ud_lv) { sa.pitchUdLv = it / 100f }
        findViewById<Switch>(R.id.switch_batt_box_track)?.setOnCheckedChangeListener { _, c -> sa.battBoxTrackOn = c }
        bindSeekBar(R.id.seek_batt_box_track_thr) { sa.battBoxTrackThr = it / 100f }
        bindSeekBar(R.id.seek_batt_box_track_lv) { sa.battBoxTrackLv = it / 100f }
        findViewById<Switch>(R.id.switch_batt_box_int)?.setOnCheckedChangeListener { _, c -> sa.battBoxIntOn = c }
        bindSeekBar(R.id.seek_batt_box_int_thr) { sa.battBoxIntThr = it / 100f }
        bindSeekBar(R.id.seek_batt_box_int_lv) { sa.battBoxIntLv = it / 100f }
        findViewById<Switch>(R.id.switch_batt_box)?.setOnCheckedChangeListener { _, c -> sa.battBoxOn = c }
        bindSeekBar(R.id.seek_batt_box_thr) { sa.battBoxThr = it / 100f }
        bindSeekBar(R.id.seek_batt_box_lv) { sa.battBoxLv = it / 100f }
        findViewById<Switch>(R.id.switch_batt_box_decay)?.setOnCheckedChangeListener { _, c -> sa.battBoxDecayOn = c }
        bindSeekBar(R.id.seek_batt_box_decay_thr) { sa.battBoxDecayThr = it / 100f }
        bindSeekBar(R.id.seek_batt_box_decay_lv) { sa.battBoxDecayLv = it / 100f }
        findViewById<SeekBar>(R.id.seek_batt_box_decay_ms)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.battBoxDecayMs = p.coerceIn(50, 5000).toLong() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_batt_box_tex)?.setOnCheckedChangeListener { _, c -> sa.battBoxTexOn = c }
        bindSeekBar(R.id.seek_batt_box_tex_thr) { sa.battBoxTexThr = it / 100f }
        bindSeekBar(R.id.seek_batt_box_tex_lv) { sa.battBoxTexLv = it / 100f }
        findViewById<Switch>(R.id.switch_batt_box_color)?.setOnCheckedChangeListener { _, c -> sa.battBoxColorOn = c }
        bindSeekBar(R.id.seek_batt_box_color_thr) { sa.battBoxColorThr = it / 100f }
        bindSeekBar(R.id.seek_batt_box_color_r) { sa.battBoxColorR = it / 100f }
        bindSeekBar(R.id.seek_batt_box_color_g) { sa.battBoxColorG = it / 100f }
        bindSeekBar(R.id.seek_batt_box_color_b) { sa.battBoxColorB = it / 100f }
        findViewById<Switch>(R.id.switch_batt_box_vis)?.setOnCheckedChangeListener { _, c -> sa.battBoxVisOn = c }
        bindSeekBar(R.id.seek_batt_box_vis_thr) { sa.battBoxVisThr = it / 100f }
        bindSeekBar(R.id.seek_batt_box_vis_lv) { sa.battBoxVisLv = it / 100f }
        findViewById<Switch>(R.id.switch_batt_box_charge)?.setOnCheckedChangeListener { _, c -> sa.battBoxChargeOn = c }
        bindSeekBar(R.id.seek_batt_box_charge_pct) { sa.battBoxChargePct = it / 100f }
        bindSeekBar(R.id.seek_batt_box_charge_thr) { sa.battBoxChargeThr = it / 100f }
        bindSeekBar(R.id.seek_batt_box_charge_lv) { sa.battBoxChargeLv = it / 100f }
        findViewById<Switch>(R.id.switch_batt_box_charge_decay)?.setOnCheckedChangeListener { _, c -> sa.battBoxChargeDecayOn = c }
        bindSeekBar(R.id.seek_batt_box_charge_decay_thr) { sa.battBoxChargeDecayThr = it / 100f }
        bindSeekBar(R.id.seek_batt_box_charge_decay_lv) { sa.battBoxChargeDecayLv = it / 100f }
        findViewById<SeekBar>(R.id.seek_batt_box_charge_decay_ms)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                sa.battBoxChargeDecayMs = p.coerceIn(50, 5000).toLong()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_batt_box_full)?.setOnCheckedChangeListener { _, c -> sa.battBoxFullOn = c }
        bindSeekBar(R.id.seek_batt_box_full_thr) { sa.battBoxFullThr = it / 100f }
        bindSeekBar(R.id.seek_batt_box_full_lv) { sa.battBoxFullLv = it / 100f }
        findViewById<Switch>(R.id.switch_body_surface)?.setOnCheckedChangeListener { _, c -> sa.bodySurfaceOn = c }
        bindSeekBar(R.id.seek_body_surface_thr) { sa.bodySurfaceThr = it / 100f }
        bindSeekBar(R.id.seek_body_surface_lv) { sa.bodySurfaceLv = it / 100f }
        findViewById<Switch>(R.id.switch_body_atmo_surf)?.setOnCheckedChangeListener { _, c -> sa.bodyAtmoSurfOn = c }
        bindSeekBar(R.id.seek_body_atmo_surf_thr) { sa.bodyAtmoSurfThr = it / 100f }
        bindSeekBar(R.id.seek_body_atmo_surf_lv) { sa.bodyAtmoSurfLv = it / 100f }
        findViewById<Switch>(R.id.switch_body_atmo_spike)?.setOnCheckedChangeListener { _, c -> sa.bodyAtmoSpikeOn = c }
        bindSeekBar(R.id.seek_body_atmo_spike_thr) { sa.bodyAtmoSpikeThr = it / 100f }
        bindSeekBar(R.id.seek_body_atmo_spike_lv) { sa.bodyAtmoSpikeLv = it / 100f }
        findViewById<Switch>(R.id.switch_body_move)?.setOnCheckedChangeListener { _, c -> sa.bodyMoveOn = c }
        bindSeekBar(R.id.seek_body_move_thr) { sa.bodyMoveThr = it / 100f }
        bindSeekBar(R.id.seek_body_move_lv) { sa.bodyMoveLv = it / 100f }
        findViewById<Switch>(R.id.switch_body_speed)?.setOnCheckedChangeListener { _, c -> sa.bodySpeedOn = c }
        bindSeekBar(R.id.seek_body_speed_thr) { sa.bodySpeedThr = it / 100f }
        bindSeekBar(R.id.seek_body_speed_lv) { sa.bodySpeedLv = it / 100f }
        findViewById<Switch>(R.id.switch_body_wave)?.setOnCheckedChangeListener { _, c -> sa.bodyWaveOn = c }
        bindSeekBar(R.id.seek_body_wave_thr) { sa.bodyWaveThr = it / 100f }
        bindSeekBar(R.id.seek_body_wave_lv) { sa.bodyWaveLv = it / 100f }
        findViewById<Switch>(R.id.switch_body_motion_bip)?.setOnCheckedChangeListener { _, c -> sa.bodyMotionBipOn = c }
        findViewById<SeekBar>(R.id.seek_body_motion_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.bodyMotionBipNeg = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_body_motion_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.bodyMotionBipPos = p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_echo)?.setOnCheckedChangeListener { _, c -> sa.echoOn = c }
        bindSeekBar(R.id.seek_echo_thr) { sa.echoThr = it / 100f }
        bindSeekBar(R.id.seek_echo_lv) { sa.echoLv = it / 100f }
        findViewById<Switch>(R.id.switch_echo_move)?.setOnCheckedChangeListener { _, c -> sa.echoMoveOn = c }
        bindSeekBar(R.id.seek_echo_move_thr) { sa.echoMoveThr = it / 100f }
        bindSeekBar(R.id.seek_echo_move_lv) { sa.echoMoveLv = it / 100f }
        findViewById<Switch>(R.id.switch_echo_speed)?.setOnCheckedChangeListener { _, c -> sa.echoSpeedOn = c }
        bindSeekBar(R.id.seek_echo_speed_thr) { sa.echoSpeedThr = it / 100f }
        bindSeekBar(R.id.seek_echo_speed_lv) { sa.echoSpeedLv = it / 100f }
        findViewById<Switch>(R.id.switch_echo_wave)?.setOnCheckedChangeListener { _, c -> sa.echoWaveOn = c }
        bindSeekBar(R.id.seek_echo_wave_thr) { sa.echoWaveThr = it / 100f }
        bindSeekBar(R.id.seek_echo_wave_lv) { sa.echoWaveLv = it / 100f }
        findViewById<Switch>(R.id.switch_echo_atmo)?.setOnCheckedChangeListener { _, c -> sa.echoAtmoOn = c }
        bindSeekBar(R.id.seek_echo_atmo_thr) { sa.echoAtmoThr = it / 100f }
        bindSeekBar(R.id.seek_echo_atmo_lv) { sa.echoAtmoLv = it / 100f }
        findViewById<Switch>(R.id.switch_scr_track)?.setOnCheckedChangeListener { _, c -> sa.trackOn = c }
        bindSeekBar(R.id.seek_scr_track_thr) { sa.trackThr = it / 100f }
        bindSeekBar(R.id.seek_scr_track_lv) { sa.trackLv = it / 100f }
        findViewById<Switch>(R.id.switch_scr_track_move)?.setOnCheckedChangeListener { _, c -> sa.trackMoveOn = c }
        bindSeekBar(R.id.seek_scr_track_move_thr) { sa.trackMoveThr = it / 100f }
        bindSeekBar(R.id.seek_scr_track_move_lv) { sa.trackMoveLv = it / 100f }
        findViewById<Switch>(R.id.switch_scr_track_speed)?.setOnCheckedChangeListener { _, c -> sa.trackSpeedOn = c }
        bindSeekBar(R.id.seek_scr_track_speed_thr) { sa.trackSpeedThr = it / 100f }
        bindSeekBar(R.id.seek_scr_track_speed_lv) { sa.trackSpeedLv = it / 100f }
        findViewById<Switch>(R.id.switch_scr_track_wave)?.setOnCheckedChangeListener { _, c -> sa.trackWaveOn = c }
        bindSeekBar(R.id.seek_scr_track_wave_thr) { sa.trackWaveThr = it / 100f }
        bindSeekBar(R.id.seek_scr_track_wave_lv) { sa.trackWaveLv = it / 100f }
        findViewById<Switch>(R.id.switch_scr_track_atmo)?.setOnCheckedChangeListener { _, c -> sa.trackAtmoOn = c }
        bindSeekBar(R.id.seek_scr_track_atmo_thr) { sa.trackAtmoThr = it / 100f }
        bindSeekBar(R.id.seek_scr_track_atmo_lv) { sa.trackAtmoLv = it / 100f }
        findViewById<Switch>(R.id.switch_enemy_body_surf)?.setOnCheckedChangeListener { _, c -> sa.enemyBodySurfOn = c }
        bindSeekBar(R.id.seek_enemy_body_surf_thr) { sa.enemyBodySurfThr = it / 100f }
        bindSeekBar(R.id.seek_enemy_body_surf_lv) { sa.enemyBodySurfLv = it / 100f }
        findViewById<Switch>(R.id.switch_enemy_move)?.setOnCheckedChangeListener { _, c -> sa.enemyMoveOn = c }
        bindSeekBar(R.id.seek_enemy_move_thr) { sa.enemyMoveThr = it / 100f }
        bindSeekBar(R.id.seek_enemy_move_lv) { sa.enemyMoveLv = it / 100f }
        findViewById<Switch>(R.id.switch_enemy_speed)?.setOnCheckedChangeListener { _, c -> sa.enemySpeedOn = c }
        bindSeekBar(R.id.seek_enemy_speed_thr) { sa.enemySpeedThr = it / 100f }
        bindSeekBar(R.id.seek_enemy_speed_lv) { sa.enemySpeedLv = it / 100f }
        findViewById<Switch>(R.id.switch_enemy_wave)?.setOnCheckedChangeListener { _, c -> sa.enemyWaveOn = c }
        bindSeekBar(R.id.seek_enemy_wave_thr) { sa.enemyWaveThr = it / 100f }
        bindSeekBar(R.id.seek_enemy_wave_lv) { sa.enemyWaveLv = it / 100f }
        findViewById<Switch>(R.id.switch_enemy_atmo)?.setOnCheckedChangeListener { _, c -> sa.enemyAtmoOn = c }
        bindSeekBar(R.id.seek_enemy_atmo_thr) { sa.enemyAtmoThr = it / 100f }
        bindSeekBar(R.id.seek_enemy_atmo_lv) { sa.enemyAtmoLv = it / 100f }
        findViewById<Switch>(R.id.switch_comm_surf)?.setOnCheckedChangeListener { _, c -> sa.commSurfOn = c }
        bindSeekBar(R.id.seek_comm_surf_thr) { sa.commSurfThr = it / 100f }
        bindSeekBar(R.id.seek_comm_surf_lv) { sa.commSurfLv = it / 100f }
        findViewById<Switch>(R.id.switch_comm_bip)?.setOnCheckedChangeListener { _, c -> sa.commBipOn = c }
        findViewById<SeekBar>(R.id.seek_comm_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.commBipNeg = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_comm_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.commBipPos = p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_comm_move)?.setOnCheckedChangeListener { _, c -> sa.commMoveOn = c }
        bindSeekBar(R.id.seek_comm_move_thr) { sa.commMoveThr = it / 100f }
        bindSeekBar(R.id.seek_comm_move_lv) { sa.commMoveLv = it / 100f }
        findViewById<Switch>(R.id.switch_comm_speed)?.setOnCheckedChangeListener { _, c -> sa.commSpeedOn = c }
        bindSeekBar(R.id.seek_comm_speed_thr) { sa.commSpeedThr = it / 100f }
        bindSeekBar(R.id.seek_comm_speed_lv) { sa.commSpeedLv = it / 100f }
        findViewById<Switch>(R.id.switch_comm_wave)?.setOnCheckedChangeListener { _, c -> sa.commWaveOn = c }
        bindSeekBar(R.id.seek_comm_wave_thr) { sa.commWaveThr = it / 100f }
        bindSeekBar(R.id.seek_comm_wave_lv) { sa.commWaveLv = it / 100f }
        findViewById<Switch>(R.id.switch_comm_atmo)?.setOnCheckedChangeListener { _, c -> sa.commAtmoOn = c }
        bindSeekBar(R.id.seek_comm_atmo_thr) { sa.commAtmoThr = it / 100f }
        bindSeekBar(R.id.seek_comm_atmo_lv) { sa.commAtmoLv = it / 100f }
        findViewById<Switch>(R.id.switch_body_wavespare)?.setOnCheckedChangeListener { _, c -> sa.bodyWaveSpareOn = c }
        bindSeekBar(R.id.seek_body_wavespare_thr) { sa.bodyWaveSpareThr = it / 100f }
        bindSeekBar(R.id.seek_body_wavespare_lv) { sa.bodyWaveSpareLv = it / 100f }
        findViewById<Switch>(R.id.switch_echo_wavespare)?.setOnCheckedChangeListener { _, c -> sa.echoWaveSpareOn = c }
        bindSeekBar(R.id.seek_echo_wavespare_thr) { sa.echoWaveSpareThr = it / 100f }
        bindSeekBar(R.id.seek_echo_wavespare_lv) { sa.echoWaveSpareLv = it / 100f }
        findViewById<Switch>(R.id.switch_track_wavespare)?.setOnCheckedChangeListener { _, c -> sa.trackWaveSpareOn = c }
        bindSeekBar(R.id.seek_track_wavespare_thr) { sa.trackWaveSpareThr = it / 100f }
        bindSeekBar(R.id.seek_track_wavespare_lv) { sa.trackWaveSpareLv = it / 100f }
        findViewById<Switch>(R.id.switch_enemy_wavespare)?.setOnCheckedChangeListener { _, c -> sa.enemyWaveSpareOn = c }
        bindSeekBar(R.id.seek_enemy_wavespare_thr) { sa.enemyWaveSpareThr = it / 100f }
        bindSeekBar(R.id.seek_enemy_wavespare_lv) { sa.enemyWaveSpareLv = it / 100f }
        findViewById<Switch>(R.id.switch_comm_wavespare)?.setOnCheckedChangeListener { _, c -> sa.commWaveSpareOn = c }
        bindSeekBar(R.id.seek_comm_wavespare_thr) { sa.commWaveSpareThr = it / 100f }
        bindSeekBar(R.id.seek_comm_wavespare_lv) { sa.commWaveSpareLv = it / 100f }
        findViewById<Switch>(R.id.switch_body84_surf)?.setOnCheckedChangeListener { _, c -> sa.body84SurfOn = c }
        bindSeekBar(R.id.seek_body84_surf_thr) { sa.body84SurfThr = it / 100f }
        bindSeekBar(R.id.seek_body84_surf_lv) { sa.body84SurfLv = it / 100f }
        findViewById<Switch>(R.id.switch_atmo_int_gate)?.setOnCheckedChangeListener { _, c -> sa.atmoIntGateOn = c }
        bindSeekBar(R.id.seek_atmo_int_gate_thr) { sa.atmoIntGateThr = it / 100f }
        bindSeekBar(R.id.seek_atmo_int_gate_lv) { sa.atmoIntGateLv = it / 100f }
        findViewById<Switch>(R.id.switch_atmo_int_bip)?.setOnCheckedChangeListener { _, c -> sa.atmoIntBipOn = c }
        findViewById<SeekBar>(R.id.seek_atmo_int_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.atmoIntBipNeg = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_atmo_int_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.atmoIntBipPos = p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_visual_gate)?.setOnCheckedChangeListener { _, c -> sa.visualGateOn = c }
        bindSeekBar(R.id.seek_visual_gate_thr) { sa.visualGateThr = it / 100f }
        bindSeekBar(R.id.seek_visual_gate_lv) { sa.visualGateLv = it / 100f }
        findViewById<Switch>(R.id.switch_visual_bip)?.setOnCheckedChangeListener { _, c -> sa.visualBipOn = c }
        findViewById<SeekBar>(R.id.seek_visual_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.visualBipNeg = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_visual_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.visualBipPos = p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_imagine_gate)?.setOnCheckedChangeListener { _, c -> sa.imagineGateOn = c }
        bindSeekBar(R.id.seek_imagine_gate_thr) { sa.imagineGateThr = it / 100f }
        bindSeekBar(R.id.seek_imagine_gate_lv) { sa.imagineGateLv = it / 100f }
        findViewById<Switch>(R.id.switch_imagine_bip)?.setOnCheckedChangeListener { _, c -> sa.imagineBipOn = c }
        findViewById<SeekBar>(R.id.seek_imagine_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.imagineBipNeg = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_imagine_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.imagineBipPos = p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_anim_gate)?.setOnCheckedChangeListener { _, c -> sa.animGateOn = c }
        bindSeekBar(R.id.seek_anim_gate_thr) { sa.animGateThr = it / 100f }
        bindSeekBar(R.id.seek_anim_gate_lv) { sa.animGateLv = it / 100f }
        findViewById<Switch>(R.id.switch_anim_bip)?.setOnCheckedChangeListener { _, c -> sa.animBipOn = c }
        findViewById<SeekBar>(R.id.seek_anim_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.animBipNeg = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_anim_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sa.animBipPos = p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // Body 84 bank — same options as original body regions; bulk → all 84
        val b84 = visualShield.body84
        b84.applyBulkToAll()
        fun b84Apply() = b84.applyBulkToAll()
        findViewById<Switch>(R.id.switch_body84)?.setOnCheckedChangeListener { _, c -> b84.masterOn = c }
        bindSeekBar(R.id.seek_body84_lv) { b84.bulkAmbient = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_thr) { b84.bulkThr = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_wave) { b84.bulkWave = (it / 100f).coerceIn(0.05f, 4f); b84Apply() }
        bindSeekBar(R.id.seek_body84_atmo) { b84.bulkAtmo = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_wavespare) { b84.bulkWaveSpare = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_particles) { b84.bulkParticles = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_move) { b84.bulkMove = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_move_thr) { b84.bulkMoveThr = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_speed) { b84.bulkSpeed = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_speed_thr) { b84.bulkSpeedThr = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_lr) { b84.bulkLr = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_ud) { b84.bulkUd = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_random) { b84.bulkRandom = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_center) { b84.bulkCenter = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_corner) { b84.bulkCorner = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_vib) { b84.bulkVib = it / 100f; b84Apply() }
        findViewById<SeekBar>(R.id.seek_body84_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { b84.bulkBipNeg = -p.toFloat(); b84Apply() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_body84_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { b84.bulkBipPos = p.toFloat(); b84Apply() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_body84_pig) { b84.bulkPigPong = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_pig_thr) { b84.bulkPigPongThr = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_atmo_spike) { b84.bulkAtmoSpike = it / 100f; b84Apply() }
        bindSeekBar(R.id.seek_body84_atmo_spike_thr) { b84.bulkAtmoSpikeThr = it / 100f; b84Apply() }
        findViewById<Switch>(R.id.switch_body84_rescan)?.setOnCheckedChangeListener { _, c -> b84.rescanOn = c }
        bindSeekBar(R.id.seek_body84_rescan_thr) { b84.rescanThr = it / 100f }
        bindSeekBar(R.id.seek_body84_rescan_lv) { b84.rescanLv = it / 100f }
        val h84 = android.os.Handler(android.os.Looper.getMainLooper())
        val t84 = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_body84)?.text = visualShield.body84.statusLine()
                h84.postDelayed(this, 250)
            }
        }
        h84.post(t84)

        findViewById<Switch>(R.id.switch_sound_bank)?.setOnCheckedChangeListener { _, c -> sb.enabled = c }
        findViewById<Switch>(R.id.switch_sb_track)?.setOnCheckedChangeListener { _, c -> sb.trackOn = c }
        bindSeekBar(R.id.seek_sb_track_thr) { sb.trackThr = it / 100f }
        findViewById<Switch>(R.id.switch_sb_thr_track)?.setOnCheckedChangeListener { _, c -> sb.thrTrackOn = c }
        bindSeekBar(R.id.seek_sb_thr_track_thr) { sb.thrTrackThr = it / 100f }
        findViewById<Switch>(R.id.switch_sb_amb_track)?.setOnCheckedChangeListener { _, c -> sb.ambientTrackOn = c }
        bindSeekBar(R.id.seek_sb_amb_track_thr) { sb.ambientTrackThr = it / 100f }
        bindSeekBar(R.id.seek_sb_amb_track_lv) { sb.ambientTrackLv = it / 100f }
        findViewById<Switch>(R.id.switch_sb_detect)?.setOnCheckedChangeListener { _, c -> sb.detectOn = c }
        bindSeekBar(R.id.seek_sb_detect_thr) { sb.detectThr = it / 100f }
        findViewById<Switch>(R.id.switch_sb_silence)?.setOnCheckedChangeListener { _, c -> sb.silenceOn = c }
        bindSeekBar(R.id.seek_sb_silence_thr) { sb.silenceThr = it / 100f }
        findViewById<Switch>(R.id.switch_sb_block)?.setOnCheckedChangeListener { _, c -> sb.blockOn = c }
        bindSeekBar(R.id.seek_sb_block_thr) { sb.blockThr = it / 100f }
        findViewById<Switch>(R.id.switch_atmo_spike_bank)?.setOnCheckedChangeListener { _, c -> sb.atmoSpikeBankOn = c }
        bindSeekBar(R.id.seek_atmo_spike_thr) { sb.atmoSpikeThr = it / 100f }
        findViewById<Switch>(R.id.switch_atmo_spike_prot)?.setOnCheckedChangeListener { _, c -> sb.atmoSpikeProtOn = c }
        bindSeekBar(R.id.seek_atmo_spike_prot_thr) { sb.atmoSpikeProtThr = it / 100f }
        bindSeekBar(R.id.seek_atmo_spike_prot_lv) { sb.atmoSpikeProtLv = it / 100f }
        findViewById<Switch>(R.id.switch_sb_opt_hard)?.setOnCheckedChangeListener { _, c -> sb.optHardGate = c }
        findViewById<Switch>(R.id.switch_sb_opt_soft)?.setOnCheckedChangeListener { _, c -> sb.optSoftFade = c }
        findViewById<Switch>(R.id.switch_sb_opt_link_amb)?.setOnCheckedChangeListener { _, c -> sb.optLinkAmbient = c }
        bindSeekBar(R.id.seek_atmo_spike_lv) { sb.atmoSpikeLv = it / 100f }
        findViewById<Switch>(R.id.switch_atmo_speed)?.setOnCheckedChangeListener { _, c -> sb.atmoSpeedOn = c }
        bindSeekBar(R.id.seek_atmo_speed_thr) { sb.atmoSpeedThr = it / 100f }
        bindSeekBar(R.id.seek_atmo_speed_lv) { sb.atmoSpeedLv = it / 100f }
        findViewById<Switch>(R.id.switch_atmo_move)?.setOnCheckedChangeListener { _, c -> sb.atmoMoveOn = c }
        bindSeekBar(R.id.seek_atmo_move_thr) { sb.atmoMoveThr = it / 100f }
        bindSeekBar(R.id.seek_atmo_move_lv) { sb.atmoMoveLv = it / 100f }
        findViewById<Switch>(R.id.switch_atmo_wave)?.setOnCheckedChangeListener { _, c -> sb.atmoWaveOn = c }
        bindSeekBar(R.id.seek_atmo_wave_thr) { sb.atmoWaveThr = it / 100f }
        bindSeekBar(R.id.seek_atmo_wave_lv) { sb.atmoWaveLv = it / 100f }
        findViewById<Switch>(R.id.switch_atmo_bip)?.setOnCheckedChangeListener { _, c -> sb.atmoBipOn = c }
        findViewById<SeekBar>(R.id.seek_atmo_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sb.atmoBipNeg = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_sb_atmo_track)?.setOnCheckedChangeListener { _, c -> sb.atmoTrackOn = c }
        bindSeekBar(R.id.seek_sb_atmo_track_thr) { sb.atmoTrackThr = it / 100f }
        bindSeekBar(R.id.seek_sb_atmo_track_lv) { sb.atmoTrackLv = it / 100f }
        findViewById<Switch>(R.id.switch_sb_move_track)?.setOnCheckedChangeListener { _, c -> sb.moveTrackOn = c }
        bindSeekBar(R.id.seek_sb_move_track_thr) { sb.moveTrackThr = it / 100f }
        bindSeekBar(R.id.seek_sb_move_track_lv) { sb.moveTrackLv = it / 100f }
        findViewById<Switch>(R.id.switch_sb_db_limit)?.setOnCheckedChangeListener { _, c -> sb.dbLimitOn = c }
        findViewById<SeekBar>(R.id.seek_sb_db_limit_ceil)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sb.dbLimitCeil = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_sb_db_limit_floor)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sb.dbLimitFloor = -p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_sb_db_limit_lv) { sb.dbLimitLv = it / 100f }
        findViewById<Switch>(R.id.switch_sb_amb_limit)?.setOnCheckedChangeListener { _, c -> sb.ambLimitOn = c }
        bindSeekBar(R.id.seek_sb_amb_limit_thr) { sb.ambLimitThr = it / 100f }
        bindSeekBar(R.id.seek_sb_amb_limit_ceil) { sb.ambLimitCeil = it / 100f }
        bindSeekBar(R.id.seek_sb_amb_limit_lv) { sb.ambLimitLv = it / 100f }
        findViewById<SeekBar>(R.id.seek_atmo_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sb.atmoBipPos = p.toFloat() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_screen_ambient)?.text = visualShield.screenAmbient.statusLine()
                findViewById<TextView>(R.id.txt_sound_bank)?.text = visualShield.soundBank.statusLine()
                findViewById<TextView>(R.id.txt_mic_speaker)?.text = visualShield.micSpeaker.statusLine()
                findViewById<TextView>(R.id.txt_sound_bank_focus)?.text = visualShield.soundBank.statusLine()
                handler.postDelayed(this, 200)
            }
        }
        handler.post(tick)
    }

    private fun setupRegionFx() {
        val fx = visualShield.regionFx
        findViewById<Switch>(R.id.switch_region_fx)?.setOnCheckedChangeListener { _, c -> fx.enabled = c }
        findViewById<Switch>(R.id.switch_region_spike)?.setOnCheckedChangeListener { _, c -> fx.spikeOn = c }
        bindSeekBar(R.id.seek_region_spike_thr) { fx.spikeThr = it / 100f }
        bindSeekBar(R.id.seek_region_spike_lv) { fx.spikeLv = it / 100f }
        findViewById<Switch>(R.id.switch_region_knife)?.setOnCheckedChangeListener { _, c -> fx.knifeOn = c }
        bindSeekBar(R.id.seek_region_knife_thr) { fx.knifeThr = it / 100f }
        bindSeekBar(R.id.seek_region_knife_lv) { fx.knifeLv = it / 100f }
        findViewById<Switch>(R.id.switch_region_ripple)?.setOnCheckedChangeListener { _, c -> fx.rippleOn = c }
        bindSeekBar(R.id.seek_region_ripple_thr) { fx.rippleThr = it / 100f }
        bindSeekBar(R.id.seek_region_ripple_lv) { fx.rippleLv = it / 100f }
        findViewById<Switch>(R.id.switch_region_whistle)?.setOnCheckedChangeListener { _, c -> fx.whistleOn = c }
        bindSeekBar(R.id.seek_region_whistle_thr) { fx.whistleThr = it / 100f }
        bindSeekBar(R.id.seek_region_whistle_lv) { fx.whistleLv = it / 100f }
        bindSeekBar(R.id.seek_region_master_thr) { fx.masterThr = it / 100f }
        bindSeekBar(R.id.seek_region_fx_level) { fx.level = it / 100f }
        findViewById<Switch>(R.id.switch_region_protect)?.setOnCheckedChangeListener { _, c -> fx.protectOn = c }
        bindSeekBar(R.id.seek_region_protect_thr) { fx.protectThr = it / 100f }
        bindSeekBar(R.id.seek_region_protect_lv) { fx.protectLv = it / 100f }
        findViewById<Switch>(R.id.switch_any_effect_protect)?.setOnCheckedChangeListener { _, c -> fx.anyEffectProtectOn = c }
        bindSeekBar(R.id.seek_any_effect_protect_thr) { fx.anyEffectProtectThr = it / 100f }
        bindSeekBar(R.id.seek_any_effect_protect_lv) { fx.anyEffectProtectLv = it / 100f }

        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_region_fx)?.text = visualShield.regionFx.statusLine()
                handler.postDelayed(this, 200)
            }
        }
        handler.post(tick)
    }

    private fun setupAmbientBoard() {
        val ap = audioProcessor
        // live mic dB · CENTROID · VERTICAL board + centroid-driven body (movement · speed · waves · 84 ambient · eyes)
        ap?.let { proc ->
            visualShield.ambientBoardRef = proc.ambientBoard
            findViewById<android.widget.LinearLayout>(R.id.panel_ambient_centroid)?.let {
                visualShield.loadPtModels(this)
                AmbientCentroidPanels.build(this, it, proc.ambientBoard, visualShield.cenDrive, visualShield)
                // Complete Final Tabs (prior Final Protection · all settings)
                FinalTabsPanels.build(this, it, visualShield.finalTabs, visualShield)
            EyesCompletePanels.buildMono(this, it, visualShield.monoEyes)
            EyesCompletePanels.buildFinal(this, it, visualShield.finalEyes)
            CnsEyesHeart3dPanels.build(this, it, visualShield.cnsEyesHeart)
            PoseSegEyeBodyPanels.build(this, it, visualShield.poseSegEyeBody)
            FullModel3dBodyPanels.build(this, it, visualShield.fullModel3d)
            // Camera AR · mesh world · point cloud (uses activity AR board)
            CameraArMeshWorldPanels.build(this, it, visualShield.cameraArMeshWorld, visualShield.arMeasure)
            CameraExclusiveGuardPanels.build(this, it, visualShield.cameraExclusiveGuard)
            HeartInsideFullAmbientPanels.build(this, it, visualShield.heartInsideFull)
            NeuralNeurotransmitterAmbientPanels.build(this, it, visualShield.neuralNeuroTx)
            EnemySameBodyModelPanels.build(this, it, visualShield.enemySameBody)
            WaterFullBodyAmbientPanels.build(this, it, visualShield.waterFullBody)
            ReproAnatomyAmbientPanels.build(this, it, visualShield.reproAnatomy)
            PointerBulletLinearFreqPanels.build(this, it, visualShield.pointerBulletLinear)
            BodyRegionBulletAtomsparePanels.build(this, it, visualShield.bodyRegionBulletAtom)
            EyeCanthusHeartBrainGapPanels.build(this, it, visualShield.eyeCanthusHeartBrain)
            EnemyBleScaleTrackPanels.build(this, it, visualShield.enemyBleScaleTrack)
            WaterWarfareAmbientPanels.build(this, it, visualShield.waterWarfareAmbient)
            EnemyBodySprayPrankPanels.build(this, it, visualShield.enemyBodySprayPrank)
            BleEnemyAmbientBlockPanels.build(this, it, visualShield.bleEnemyAmbientBlock)
            if (visualShield.bleScaleLibrary == null) {
                visualShield.bleScaleLibrary = BleScaleLibrary(this.applicationContext).also { it.init() }
            }
            FullProtectionBlePanels.build(this, it, visualShield.fullProtectionBle, visualShield.bleScaleLibrary)
            LifesumBloodBleSystemPanels.build(this, it, visualShield.lifesumBloodBle)
            BodyOilsChemicalFullPanels.build(this, it, visualShield.bodyOilsChemical)
            ModelSpeakerSoundsTrackPanels.build(this, it, visualShield.modelSpeakerSounds)
            ScreenEffectInsideAnatomyPanels.build(this, it, visualShield.screenEffectInside)
            CompleteHumanAnatomy360Panels.build(this, it, visualShield.completeHuman360, visualShield.enemyFoodDustbinPrank)
            EyeBodyAtomspareSurfacePanels.build(this, it, visualShield.eyeBodyAtomSurface)
            BodyIsolationPanels.build(this, it, visualShield.bodyIsolation)
            Body3dModelInteractPanels.build(this, it, visualShield.body3dModelInteract)
            SkinAtomspare3dPanels.build(this, it, visualShield.skinAtomspare)
            BodyAnatomyShellPanels.build(this, it, visualShield.anatomyShell)
            Enemy3dModelProtectPanels.build(this, it, visualShield.enemy3dProtect)
            Body84FullHumanPanels.build(this, it, visualShield.body84FullHuman)
            UltrasoundWeaponOutPanels.build(this, it, visualShield.ultraWeapon)
            FrontSideAmbientPanels.build(this, it, visualShield.frontSideAmbient)
            HairAmbientBulletCollapsePanels.build(this, it, visualShield.hairBullet)
            CompleteAtomspareProtectPanels.build(this, it, visualShield.completeAtomProtect)
            BodyFrequencyRegenPanels.build(this, it, visualShield.bodyFreqRegen)
            Complete3dNoMissPanels.build(this, it, visualShield.complete3dNoMiss)
            EyesHeartBellyCompletePanels.build(this, it, visualShield.eyesHeartBelly)
            FaceEyeNoiseCompletePanels.build(this, it, visualShield.faceEyeNoise)
            MoreMissedCompletePanels.build(this, it, visualShield.moreMissed)
            FullBodyAnatomyInterconnectPanels.build(this, it, visualShield.fullBodyAnatomy)
            SharpBurstKnifeMeterPanels.build(this, it, visualShield.sharpBurstMeter)
            LiveMicEnemyAllSoundsPanels.build(this, it, visualShield.liveMicEnemyAll)
            EnemySoundCancelPanels.build(this, it, visualShield.enemySoundCancel)
            AllBodySkinAnatomyAmbientPanels.build(this, it, visualShield.allBodySkinAnatomy)
            SkinMultiModelMotionPanels.build(this, it, visualShield.skinMultiMotion)
            SkinSoundsProtectPanels.build(this, it, visualShield.skinSoundsProtect)
            BioSkinCellAmbientPanels.build(this, it, visualShield.bioSkinCell)
            BodyChemBrainAmbientPanels.build(this, it, visualShield.bodyChemBrain)
            MgBleScaleWattPanels.build(this, it, visualShield.mgBleScaleWatt)
            CaMgProtectChemPanels.build(this, it, visualShield.caMgProtectChem)
            SkeletonWaterAstroAmbientPanels.build(this, it, visualShield.skeletonWaterAstro)
            FullAmbientMasterPanels.build(this, it, visualShield.fullAmbientMaster)
            BodyRegionEnemySoundProtectPanels.build(this, it, visualShield.bodyRegionEnemyProtect)
            AntiAtomspareSoundsPanels.build(this, it, visualShield.antiAtomspareSounds)
            EarAuditoryLineAmbientPanels.build(this, it, visualShield.earAuditoryLine)
            EyesCompleteEnemyLockPanels.build(this, it, visualShield.eyesCompleteLock)
            FullBodyMotionLockPanels.build(this, it, visualShield.fullBodyMotionLock)
            EnemySoundCountersPanels.build(this, it, visualShield.enemySoundCounters)
            SoundDetectBodyRegionTrackPanels.build(this, it, visualShield.soundDetectBodyTrack)
            MicLiveAmbientMixerPanels.build(this, it, visualShield.micLiveAmbientMixer)
            FullSkeletonBoneAmbientPanels.build(this, it, visualShield.fullSkeletonBone)
            FinalProtectionMainPanels.build(this, it, visualShield.finalProtectionMain)
            FullAnatomy132AmbientPanels.build(this, it, visualShield.fullAnatomy132)
            SensorGatedSfxDetectPanels.build(this, it, visualShield.sensorGatedSfx)
            AnatomyInsidePanels.build(this, it, visualShield.insideWarpRot)
            try { visualShield.sensorGatedSfx.start(this) } catch (_: Throwable) {}
            AiPlatformApiPanels.build(this, it, aiPlatformApi)
            DevHttpsApiPanels.build(this, it, devHttpsApi)
            // Floating website
            run {
                val box = android.widget.LinearLayout(this).apply {
                    orientation = android.widget.LinearLayout.VERTICAL
                    setPadding(16, 12, 16, 12)
                }
                val title = android.widget.TextView(this).apply {
                    text = "FLOATING WEB · URL BAR · LOAD WEBSITE"
                    setTextColor(0xFF80DEEA.toInt())
                    textSize = 14f
                }
                val openBtn = android.widget.Button(this).apply {
                    text = "Open floating WebView"
                    setOnClickListener { floatingWeb?.show(floatingWeb?.lastUrl) }
                }
                val urlEdit = android.widget.EditText(this).apply {
                    hint = "https://example.com"
                    setText("https://www.google.com")
                    setTextColor(0xFFFFFFFF.toInt())
                    setHintTextColor(0x88FFFFFF.toInt())
                }
                val goBtn = android.widget.Button(this).apply {
                    text = "Load URL in floating view"
                    setOnClickListener {
                        val u = urlEdit.text?.toString()?.trim().orEmpty()
                        floatingWeb?.show(if (u.isEmpty()) null else u)
                    }
                }
                val labBtn = android.widget.Button(this).apply {
                    text = "Open Dev API Lab (JS frontend)"
                    setOnClickListener {
                        floatingWeb?.show("file:///android_asset/dev/index.html")
                    }
                }
                box.addView(title)
                box.addView(openBtn)
                box.addView(labBtn)
                box.addView(urlEdit)
                box.addView(goBtn)
                it.addView(box)
            }
                AmbientMovementPanel.build(this, it, proc.ambientBoard.movement)
            }
        }
        findViewById<Switch>(R.id.switch_ambient_board)?.setOnCheckedChangeListener { _, c ->
            ap?.setAmbientBoardEnabled(c)
        }
        findViewById<Switch>(R.id.switch_ambient_live)?.setOnCheckedChangeListener { _, c ->
            ap?.setAmbientLive(c)
        }
        findViewById<SeekBar>(R.id.seek_ambient_thr_pct)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                // 0–1000 → 0.0–100.0%
                ap?.setAmbientThrPct(p / 10f)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_ambient_bip_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                ap?.setAmbientBipolarNeg(-p.toFloat())
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_ambient_bip_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                ap?.setAmbientBipolarPos(p.toFloat())
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_thr_gain_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                ap?.setThrGainNegDb(-p.toFloat().coerceIn(0f, 300f))
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_thr_gain_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                ap?.setThrGainPosDb(p.toFloat().coerceIn(0f, 300f))
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<Switch>(R.id.switch_limiter_on)?.setOnCheckedChangeListener { _, c ->
            ap?.setLimiterOn(c)
        }
        findViewById<SeekBar>(R.id.seek_limiter_db)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                ap?.setLimiterDb(p.toFloat())
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_ambient_decay_fast)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { ap?.setAmbientDecayFastMs(p.coerceIn(10, 5000)) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_ambient_decay_mid)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { ap?.setAmbientDecayMidMs(p.coerceIn(10, 5000)) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_ambient_decay_slow)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { ap?.setAmbientDecaySlowMs(p.coerceIn(10, 5000)) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_decay_w_fast) { ap?.setAmbientDecayWFast(it / 100f) }
        bindSeekBar(R.id.seek_decay_w_mid) { ap?.setAmbientDecayWMid(it / 100f) }
        bindSeekBar(R.id.seek_decay_w_slow) { ap?.setAmbientDecayWSlow(it / 100f) }
        findViewById<Switch>(R.id.switch_ambient_mirror)?.setOnCheckedChangeListener { _, c ->
            ap?.setAmbientMirror(c)
        }

        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_ambient_board)?.text =
                    audioProcessor?.ambientBoard?.statusLine() ?: "AMBIENT —"
                handler.postDelayed(this, 150)
            }
        }
        handler.post(tick)
    }

    private fun setupEcho() {
        val ap = audioProcessor
        findViewById<Switch>(R.id.switch_echo_on)?.setOnCheckedChangeListener { _, c ->
            ap?.setEchoEnabled(c)
        }
        bindSeekBar(R.id.seek_echo_thr) { ap?.setEchoThreshold(it / 100f) }
        findViewById<SeekBar>(R.id.seek_echo_decay)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                ap?.setEchoDecayMs(p.coerceIn(20, 5000))
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_echo_feedback) { ap?.setEchoFeedback(it / 100f) }

        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                val e = audioProcessor?.echo
                findViewById<TextView>(R.id.txt_echo_status)?.text = e?.statusLine() ?: "ECHO —"
                visualShield.echoLevel = e?.echoLevel ?: 0f
                handler.postDelayed(this, 200)
            }
        }
        handler.post(tick)
    }

    private fun setupSystemGuard() {
        val g = systemGuard ?: return
        visualShield.systemGuard = g
        findViewById<Switch>(R.id.switch_color_guard)?.setOnCheckedChangeListener { _, c -> g.colorGuardOn = c }
        findViewById<Switch>(R.id.switch_batt_guard)?.setOnCheckedChangeListener { _, c -> g.battGuardOn = c }
        findViewById<Switch>(R.id.switch_gpu_guard)?.setOnCheckedChangeListener { _, c -> g.gpuGuardOn = c }
        bindSeekBar(R.id.seek_color_guard_thr) { g.colorThr = it / 100f }
        findViewById<SeekBar>(R.id.seek_color_rail)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) { g.colorRail = p.coerceIn(0, 255) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_batt_floor)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) { g.battFloorPct = p.coerceIn(5, 95) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_batt_disch_ma)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) { g.battDischargeThrMa = p.coerceIn(50, 2000) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_gpu_thr) { g.gpuThr = it / 100f }

        // Screen + AV intensity protect + spike→discharge ±120 dB (own device)
        findViewById<Switch>(R.id.switch_screen_thr)?.setOnCheckedChangeListener { _, c -> g.screenThrOn = c }
        findViewById<Switch>(R.id.switch_av_intensity)?.setOnCheckedChangeListener { _, c -> g.avIntensityOn = c }
        findViewById<Switch>(R.id.switch_spike_disch)?.setOnCheckedChangeListener { _, c -> g.spikeDischProtectOn = c }
        bindSeekBar(R.id.seek_screen_thr) { g.screenThr = it / 100f }
        bindSeekBar(R.id.seek_av_intensity_thr) { g.avIntensityThr = it / 100f }

        findViewById<Switch>(R.id.switch_batt_intensity)?.setOnCheckedChangeListener { _, c -> g.battIntensityOn = c }
        bindSeekBar(R.id.seek_batt_intensity_thr) { g.battIntensityThr = it / 100f }
        bindSeekBar(R.id.seek_batt_intensity_lv) { g.battIntensityLv = it / 100f }
        findViewById<Switch>(R.id.switch_charge_intensity)?.setOnCheckedChangeListener { _, c -> g.chargeIntensityOn = c }
        bindSeekBar(R.id.seek_charge_intensity_thr) { g.chargeIntensityThr = it / 100f }
        bindSeekBar(R.id.seek_charge_intensity_lv) { g.chargeIntensityLv = it / 100f }
        findViewById<Switch>(R.id.switch_discharge_intensity)?.setOnCheckedChangeListener { _, c -> g.dischargeIntensityOn = c }
        bindSeekBar(R.id.seek_discharge_intensity_thr) { g.dischargeIntensityThr = it / 100f }
        bindSeekBar(R.id.seek_discharge_intensity_lv) { g.dischargeIntensityLv = it / 100f }
        findViewById<Switch>(R.id.switch_screen_disch)?.setOnCheckedChangeListener { _, c -> g.screenDischOn = c }
        bindSeekBar(R.id.seek_screen_disch_thr) { g.screenDischThr = it / 100f }
        findViewById<Switch>(R.id.switch_enemy_screen_disch)?.setOnCheckedChangeListener { _, c -> g.enemyScreenDischOn = c }
        bindSeekBar(R.id.seek_enemy_screen_disch_thr) { g.enemyScreenDischThr = it / 100f }
        findViewById<SeekBar>(R.id.seek_disch_db_neg)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) { g.dischDbNeg = -p.toFloat().coerceIn(0f, 120f) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.seek_disch_db_pos)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) { g.dischDbPos = p.toFloat().coerceIn(0f, 120f) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Interconnect: enemy stuck thr + GPS tracking protection
        findViewById<Switch>(R.id.switch_enemy_stuck)?.setOnCheckedChangeListener { _, c -> g.enemyStuckOn = c }
        bindSeekBar(R.id.seek_enemy_stuck_thr) { g.enemyStuckThr = it / 100f }
        findViewById<Switch>(R.id.switch_gps_protect)?.setOnCheckedChangeListener { _, c -> g.gpsProtectOn = c }
        bindSeekBar(R.id.seek_gps_threat_thr) { g.gpsThreatThr = it / 100f }

        findViewById<Switch>(R.id.switch_discharge_thr)?.setOnCheckedChangeListener { _, c ->
            g.spikeDischProtectOn = c
        }
        bindSeekBar(R.id.seek_discharge_thr) { g.dischargeThr = it / 100f }
        findViewById<Switch>(R.id.switch_app_stuck)?.setOnCheckedChangeListener { _, c ->
            g.enemyStuckOn = c
        }
        findViewById<Switch>(R.id.switch_enemy_app_stuck)?.setOnCheckedChangeListener { _, c -> g.enemyAppStuckOn = c }
        bindSeekBar(R.id.seek_enemy_app_stuck_thr) { g.enemyAppStuckThr = it / 100f }
        findViewById<Switch>(R.id.switch_enemy_intensity)?.setOnCheckedChangeListener { _, c -> g.enemyIntensityOn = c }
        bindSeekBar(R.id.seek_enemy_intensity_thr) { g.enemyIntensityThr = it / 100f }
        bindSeekBar(R.id.seek_enemy_intensity_lv) { g.enemyIntensityLv = it / 100f }
        findViewById<Switch>(R.id.switch_enemy_batt_disch)?.setOnCheckedChangeListener { _, c -> g.enemyBattDischOn = c }
        bindSeekBar(R.id.seek_enemy_batt_disch_thr) { g.enemyBattDischThr = it / 100f }
        bindSeekBar(R.id.seek_enemy_batt_disch_lv) { g.enemyBattDischLv = it / 100f }
        findViewById<Switch>(R.id.switch_display_spike)?.setOnCheckedChangeListener { _, c -> g.displaySpikeOn = c }
        bindSeekBar(R.id.seek_display_spike_thr) { g.displaySpikeThr = it / 100f }
        bindSeekBar(R.id.seek_display_spike_lv) { g.displaySpikeLv = it / 100f }
        findViewById<Switch>(R.id.switch_app_stuck_disp_spike)?.setOnCheckedChangeListener { _, c -> g.appStuckDisplaySpikeOn = c }
        bindSeekBar(R.id.seek_app_stuck_thr) {
            g.appStuckThr = it / 100f
            g.enemyStuckThr = it / 100f
        }

        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_guard_status)?.text = systemGuard?.statusLine() ?: "GUARD —"
                val g2 = systemGuard
                val ds = buildString {
                    append("DISCH thr=${((g2?.dischargeThr ?: 0f)*100).toInt()}% ")
                    append(if (g2?.spikeDischActive == true) "ACTIVE" else "idle")
                    append(" · STUCK thr=${((g2?.appStuckThr ?: 0f)*100).toInt()}% ")
                    append(if (g2?.enemyStuckActive == true) "ACTIVE" else "idle")
                }
                findViewById<TextView>(R.id.txt_disch_stuck_status)?.text = ds
                handler.postDelayed(this, 300)
            }
        }
        handler.post(tick)
    }

    private fun setupUiBlock() {
        val ub = audioProcessor?.uiBlock
        visualShield.uiBlocker = ub
        findViewById<Switch>(R.id.switch_ui_block_master)?.setOnCheckedChangeListener { _, c ->
            ub?.enabled = c
        }
        findViewById<Switch>(R.id.switch_ui_intensity_block)?.setOnCheckedChangeListener { _, c ->
            ub?.blockOn = c
        }
        bindSeekBar(R.id.seek_ui_thr) { ub?.uiThr = it / 100f }
        bindSeekBar(R.id.seek_ui_lv) { ub?.uiLevel = it / 100f }
        bindSeekBar(R.id.seek_enemy_ui_thr) { ub?.enemyUiThr = it / 100f }
        bindSeekBar(R.id.seek_enemy_ui_lv) { ub?.enemyUiLevel = it / 100f }
        bindSeekBar(R.id.seek_ui_block_thr) { ub?.blockThr = it / 100f }
        bindSeekBar(R.id.seek_ui_block_lv) { ub?.blockLevel = it / 100f }

        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_ui_block_status)?.text =
                    audioProcessor?.uiBlock?.statusLine() ?: "UI —"
                visualShield.uiBlocker = audioProcessor?.uiBlock
                handler.postDelayed(this, 200)
            }
        }
        handler.post(tick)
    }

    private fun setupFgUltra() {
        val ap = audioProcessor
        findViewById<Switch>(R.id.switch_fg_sense)?.setOnCheckedChangeListener { _, on ->
            if (on) startFgSense() else stopFgSense()
        }
        startFgSense()

        findViewById<Switch>(R.id.switch_ultra_on)?.setOnCheckedChangeListener { _, c ->
            ap?.ultrasound?.enabled = c
        }
        findViewById<Switch>(R.id.switch_ultra_prot)?.setOnCheckedChangeListener { _, c ->
            ap?.ultrasound?.protectOn = c
        }
        findViewById<SeekBar>(R.id.seek_ultra_hz)?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                ap?.ultrasound?.bandHz = p.coerceIn(1, 50).toFloat()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        bindSeekBar(R.id.seek_ultra_thr) { ap?.ultrasound?.threshold = it / 100f }
        bindSeekBar(R.id.seek_ultra_lv) { ap?.ultrasound?.level = it / 100f }

        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.txt_ultra_status)?.text =
                    audioProcessor?.ultrasound?.statusLine() ?: "ULTRA —"
                handler.postDelayed(this, 200)
            }
        }
        handler.post(tick)
    }

    private val fgHandler = Handler(Looper.getMainLooper())
    private var fgStartRequestedMs = 0L
    private var fgStopTries = 0

    private fun startFgSense() {
        // FG feature removed — no-op
        try { findViewById<TextView>(R.id.txt_fg_status)?.text = "FG removed" } catch (_: Throwable) {}
    }

    private fun stopFgSense() {
        // FG feature removed — best-effort stop if leftover
        try {
            stopService(Intent(this, ForegroundSenseService::class.java))
        } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.txt_fg_status)?.text = "FG removed" } catch (_: Throwable) {}
    }


    private fun bindSeekBar(id: Int, action: (Int) -> Unit) {
        val seekBar = findViewById<SeekBar>(id) ?: return
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { action(progress) }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun tryStartCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            findViewById<TextView>(R.id.txt_fg_status)?.text = "FG: waiting CAMERA permission"
            return
        }
        // Do not open legacy camera while ARCore holds it
        if (visualShield.arMeasure.enabled && visualShield.arMeasure.trackingOn && visualShield.arMeasure.sessionRunning) {
            findViewById<TextView>(R.id.txt_fg_status)?.text = "FG · ARCore holds camera"
            return
        }
        if (cameraManager == null) {
            cameraManager = CameraManager(this, cameraPreview, humanDetector, visualShield.videoFeedbackBoard)
        }
        val ok = cameraManager?.startCamera() == true
        val fg = findViewById<TextView>(R.id.txt_fg_status)
        if (ok) {
            fg?.text = "FG ACTIVE · camera preview ON"
        } else {
            fg?.text = "FG on · camera fail: ${cameraManager?.lastError ?: "unknown"}"
            // one retry after surface is ready
            cameraPreview.postDelayed({
                if (cameraManager?.running != true) {
                    val ok2 = cameraManager?.startCamera() == true
                    fg?.text = if (ok2) "FG ACTIVE · camera preview ON"
                    else "FG on · camera fail: ${cameraManager?.lastError}"
                }
            }, 400)
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        cameraManager = CameraManager(this, cameraPreview, humanDetector, visualShield.videoFeedbackBoard)
        // Only open camera if already permitted (else startSystems will call tryStartCamera)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            tryStartCamera()
        }
    }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (cameraManager?.running != true &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            tryStartCamera()
        }
    }
    override fun surfaceDestroyed(holder: SurfaceHolder) { cameraManager?.stopCamera() }

    fun updateAudioStatus(status: String) {
        motionHub?.let { hub ->
            hub.setAudioLevel(if (status.contains("HIGH")) 0.8f else 0.2f)
            findViewById<TextView>(R.id.tv_motion_status)?.text = hub.statusLine()
            findViewById<TextView>(R.id.tv_attraction_status)?.text = visualShield.attraction.statusLine()
        }
        runOnUiThread {
            tvAudio.text = status
            if (status.contains("HIGH")) visualShield.triggerSpike()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveFullscreen()
    }

    /** Hide status bar, nav bar, battery, network, clock — full app screen (native API). */
    private fun enterImmersiveFullscreen() {
        try {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            // Draw under system bars / cutout
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                val controller = window.insetsController
                controller?.hide(
                    android.view.WindowInsets.Type.statusBars() or
                        android.view.WindowInsets.Type.navigationBars()
                )
                controller?.systemBarsBehavior =
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    )
            }
        } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            audioProcessor?.startListening(this)
        }
        gameSensors?.resumeSensors()
        startGameSensorUiUpdates()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startFgSense()
            if (visualShield.arMeasure.enabled && visualShield.arMeasure.trackingOn) {
                startArCoreSession()
            } else {
                cameraPreview.post { tryStartCamera() }
            }
        }
    }

    override fun onPause() {
        try { sdSound?.rememberPosition() } catch (_: Exception) {}
        gameSensors?.pauseSensors()
        stopGameSensorUiUpdates()
        visualShield.arMeasure.pauseSession()
        super.onPause()
    }

    override fun onDestroy() {
        try { floatingWeb?.onDestroy() } catch (_: Throwable) {}
        AtmosphericAudioStudioPanel.stop()
        sdSound?.release()
        visualShield.arMeasure.stopSession()
        gameSensors?.close()
        stopFgSense()
        motionHub?.stop()
        audioProcessor?.stopListening()
        cameraManager?.stopCamera()
        humanDetector.close()
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroy()
    }
}
