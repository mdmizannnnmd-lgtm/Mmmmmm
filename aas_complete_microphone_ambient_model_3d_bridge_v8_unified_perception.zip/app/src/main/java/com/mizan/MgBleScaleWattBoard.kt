package com.mizan

/**
 * Magnesium ambient (model-driven) · BLE weight & height · digital scale maintain ·
 * chemical tracking · BLE vibration thr · axis thr/level · watt API tracking.
 * Symbolic / sensor-bus friendly — not medical advice. RAW COMPLETE.
 */
class MgBleScaleWattBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Magnesium ambient
    @Volatile var mgOn = true
    @Volatile var mgThr = 0.22f
    @Volatile var mgLv = 0.85f
    @Volatile var mgOut = 0f
    @Volatile var mgModelDrive = 0f

    // BLE digital scale — weight / height (maintained)
    @Volatile var scaleOn = true
    @Volatile var weightKg = 70f
    @Volatile var heightCm = 170f
    @Volatile var weightThr = 0f      // alert if delta
    @Volatile var heightThr = 0f
    @Volatile var scaleMaintain = true
    @Volatile var lastWeightKg = 70f
    @Volatile var lastHeightCm = 170f
    @Volatile var weightDelta = 0f
    @Volatile var heightDelta = 0f
    @Volatile var bmi = 0f

    // Chemical tracking (auto)
    @Volatile var chemTrackOn = true
    @Volatile var chemMg = 0f
    @Volatile var chemCa = 0f
    @Volatile var chemFe = 0f
    @Volatile var chemTrackOut = 0f

    // BLE sensor vibration
    @Volatile var vibeOn = true
    @Volatile var vibeThr = 0.25f
    @Volatile var vibeLv = 0.80f
    @Volatile var vibeOut = 0f
    @Volatile var vibeAxisX = 0f
    @Volatile var vibeAxisY = 0f
    @Volatile var vibeAxisZ = 0f

    // Axis threshold / level
    @Volatile var axisOn = true
    @Volatile var axisThr = 0.20f
    @Volatile var axisLv = 0.85f
    @Volatile var axisX = 0f
    @Volatile var axisY = 0f
    @Volatile var axisZ = 0f
    @Volatile var axisOut = 0f

    // Watt API tracking
    @Volatile var wattOn = true
    @Volatile var wattThr = 0.15f
    @Volatile var wattLv = 0.90f
    @Volatile var wattOut = 0f
    @Volatile var wattEst = 0f  // estimated W from energy mix

    @Volatile var status = "Mg·BLE·SCALE·WATT idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    /**
     * @param mic live energy
     * @param modelE pose/seg/obb mix 0..1
     * @param ax,ay,az normalized axis magnitudes 0..1 (from sensors if available)
     * @param vibeE vibration energy 0..1
     * @param bleWatt optional external watt feed 0..1
     */
    fun tick(
        mic: Float,
        modelE: Float,
        ax: Float,
        ay: Float,
        az: Float,
        vibeE: Float,
        bleWatt: Float = 0f
    ) {
        if (!enabled) {
            status = "Mg·BLE·SCALE·WATT OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        mgModelDrive = modelE.coerceIn(0f, 1f)
        mgOut = lane(mgOn, mgThr, mgLv, maxOf(e, mgModelDrive))

        // Scale maintain — hold last stable when enabled
        if (scaleOn) {
            if (scaleMaintain) {
                // smooth toward last when no new sample; UI can set weightKg/heightCm
                weightKg = (weightKg * 0.92f + lastWeightKg * 0.08f)
                heightCm = (heightCm * 0.92f + lastHeightCm * 0.08f)
            }
            weightDelta = weightKg - lastWeightKg
            heightDelta = heightCm - lastHeightCm
            lastWeightKg = weightKg
            lastHeightCm = heightCm
            val hM = (heightCm / 100f).coerceAtLeast(0.5f)
            bmi = weightKg / (hM * hM)
        }

        // Chemical tracking linked to Mg + body chem board path
        chemMg = mgOut
        chemCa = lane(chemTrackOn, 0.2f, 0.8f, e * 0.9f)
        chemFe = lane(chemTrackOn, 0.2f, 0.8f, e * 0.85f)
        chemTrackOut = if (chemTrackOn) maxOf(chemMg, chemCa, chemFe) else 0f

        vibeAxisX = ax.coerceIn(0f, 1f)
        vibeAxisY = ay.coerceIn(0f, 1f)
        vibeAxisZ = az.coerceIn(0f, 1f)
        val vibeSrc = maxOf(vibeE, vibeAxisX, vibeAxisY, vibeAxisZ)
        vibeOut = lane(vibeOn, vibeThr, vibeLv, vibeSrc)

        axisX = lane(axisOn, axisThr, axisLv, vibeAxisX)
        axisY = lane(axisOn, axisThr, axisLv, vibeAxisY)
        axisZ = lane(axisOn, axisThr, axisLv, vibeAxisZ)
        axisOut = maxOf(axisX, axisY, axisZ)

        // Watt estimate: mic + model + vibe + optional BLE watt feed
        val wMix = maxOf(e, mgModelDrive, vibeOut, bleWatt.coerceIn(0f, 1f))
        wattOut = lane(wattOn, wattThr, wattLv, wMix)
        wattEst = wattOut * 100f  // 0..100 W symbolic scale for UI

        status =
            "Mg=${(mgOut*100).toInt()}% model=${(mgModelDrive*100).toInt()}% · " +
            "WT=${"%.1f".format(weightKg)}kg HT=${"%.0f".format(heightCm)}cm BMI=${"%.1f".format(bmi)} · " +
            "CHEM Mg/Ca/Fe=${(chemMg*100).toInt()}/${(chemCa*100).toInt()}/${(chemFe*100).toInt()} · " +
            "VIBE=${(vibeOut*100).toInt()}% AXIS=${(axisOut*100).toInt()}% · " +
            "WATT=${"%.1f".format(wattEst)}W" +
            if (rawComplete) " · RAW" else ""
    }

    /** Push a new scale sample (from BLE callback or UI). */
    fun setScaleSample(weight: Float, height: Float) {
        weightKg = weight.coerceIn(1f, 400f)
        heightCm = height.coerceIn(30f, 250f)
        lastWeightKg = weightKg
        lastHeightCm = heightCm
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        try {
            v.bodyChemBrain.magnesium = maxOf(v.bodyChemBrain.magnesium, mgOut)
            v.bodyChemBrain.calcium = maxOf(v.bodyChemBrain.calcium, chemCa)
            v.bodyChemBrain.iron = maxOf(v.bodyChemBrain.iron, chemFe)
            v.bodyChemBrain.mineral = maxOf(v.bodyChemBrain.mineral, chemTrackOut)
        } catch (_: Throwable) {}
        try {
            v.bodyFreqRegen.bleWatt = maxOf(v.bodyFreqRegen.bleWatt, wattOut)
            v.bodyFreqRegen.ownRegenOut = maxOf(v.bodyFreqRegen.ownRegenOut, mgOut * 0.4f)
        } catch (_: Throwable) {}
        try {
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, mgOut * 0.3f, wattOut * 0.2f)
            // skeleton layer — minerals
            if (v.anatomy3d.layerOn.size > 2) {
                v.anatomy3d.layerOn[2] = true
                v.anatomy3d.layerLevel[2] = maxOf(v.anatomy3d.layerLevel[2], chemCa, mgOut * 0.8f)
            }
        } catch (_: Throwable) {}
        try {
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, wattOut * 0.3f, mgOut * 0.25f)
        } catch (_: Throwable) {}
    }
}
