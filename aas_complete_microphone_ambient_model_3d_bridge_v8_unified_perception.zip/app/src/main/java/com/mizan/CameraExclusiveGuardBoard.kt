package com.mizan

/**
 * Camera stuck-bug guard (from Android/ARCore online issues):
 * - Only one client: legacy Camera OR ARCore session
 * - Always stop legacy before ARCore resume
 * - Always pause/stop ARCore on background
 * - Detect ERROR_CAMERA_IN_USE / max cameras style failures
 * RAW COMPLETE.
 */
class CameraExclusiveGuardBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var preferAr = false
    @Volatile var autoReleaseLegacyBeforeAr = true
    @Volatile var autoPauseArOnBackground = true
    @Volatile var lastMode = "NONE" // NONE | LEGACY | ARCORE
    @Volatile var stuckHint = ""
    @Volatile var status = "CAM-GUARD idle"

    fun onLegacyStarted() {
        lastMode = "LEGACY"
        stuckHint = ""
        status = "CAM-GUARD · LEGACY preview"
    }

    fun onArStarted() {
        lastMode = "ARCORE"
        stuckHint = ""
        status = "CAM-GUARD · ARCORE session"
    }

    fun onArError(msg: String?) {
        val m = (msg ?: "").lowercase()
        if ("not available" in m || "in use" in m || "camera" in m) {
            stuckHint = "Camera busy — stop legacy preview, close other camera apps, then retry AR"
            status = "CAM-GUARD STUCK · $stuckHint"
        }
    }

    fun beforeStartAr(legacyStop: () -> Unit) {
        if (!enabled) return
        if (autoReleaseLegacyBeforeAr) {
            try { legacyStop() } catch (_: Throwable) {}
            lastMode = "NONE"
            status = "CAM-GUARD · legacy released for ARCore"
        }
    }

    fun onBackground(arPause: () -> Unit, legacyStop: () -> Unit) {
        if (!enabled || !autoPauseArOnBackground) return
        try { arPause() } catch (_: Throwable) {}
        try { legacyStop() } catch (_: Throwable) {}
        status = "CAM-GUARD · background released (anti-stuck)"
        lastMode = "NONE"
    }

    fun tick(arRunning: Boolean, legacyRunning: Boolean, arError: String?) {
        if (!enabled) {
            status = "CAM-GUARD OFF"
            return
        }
        if (arError != null) onArError(arError)
        if (arRunning && legacyRunning) {
            stuckHint = "Both LEGACY+ARCORE active — release one (ERROR_MAX_CAMERAS / IN_USE risk)"
            status = "CAM-GUARD CONFLICT · $stuckHint"
        } else if (arRunning) {
            lastMode = "ARCORE"
            if (stuckHint.isEmpty()) status = "CAM-GUARD · ARCORE only"
        } else if (legacyRunning) {
            lastMode = "LEGACY"
            if (stuckHint.isEmpty()) status = "CAM-GUARD · LEGACY only"
        } else {
            lastMode = "NONE"
            if (stuckHint.isEmpty()) status = "CAM-GUARD · camera free"
        }
        if (rawComplete && stuckHint.isNotEmpty()) status += " · RAW"
    }
    fun apply(v: VisualShieldView?) { /* guard state only */ }

}
