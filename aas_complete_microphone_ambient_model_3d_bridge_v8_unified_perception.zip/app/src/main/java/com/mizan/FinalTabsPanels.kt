package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

/**
 * Builds complete Final Tabs controls (additive panel).
 */
object FinalTabsPanels {
    fun build(ctx: Context, root: LinearLayout, f: FinalTabsCompleteBoard, view: VisualShieldView? = null) {
        val p = PanelBuilder(ctx, root)
        val violet = 0xFFCE93D8.toInt()
        val cyan = 0xFF80DEEA.toInt()
        val gold = 0xFFFFD54F.toInt()

        p.title("FINAL TABS · COMPLETE (prior Final Protection)", violet)
        p.note("All Final settings/options · additive · mic×model · bipolar · RAW")
        p.switch("System Enabled", f.systemEnabled) { f.systemEnabled = it }
        p.switch("RAW COMPLETE (all Final paths)", f.rawComplete) { f.rawComplete = it }
        p.switch("Spike Protect", f.spikeProtectOn) { f.spikeProtectOn = it }
        p.seek("Spike protect level", 0f, 1.5f, f.spikeProtectLv) { f.spikeProtectLv = it }
        p.seek("Master ambient threshold", 0.05f, 0.98f, f.masterThr) { f.masterThr = it }
        p.seek("Master ambient level", 0f, 1.5f, f.masterLv) { f.masterLv = it }

        p.title("AMBIENT LIVE BOARD", cyan)
        p.switch("Ambient Live Board ON", f.ambLiveOn) { f.ambLiveOn = it }
        p.seek("Ambient threshold", 0.05f, 0.98f, f.ambLiveThr) { f.ambLiveThr = it }
        p.seek("Spike threshold", 0.05f, 0.98f, f.ambSpikeThr) { f.ambSpikeThr = it }
        p.seek("Movement threshold", 0.05f, 0.98f, f.ambMoveThr) { f.ambMoveThr = it }
        p.seek("Pitch threshold", 0.05f, 0.98f, f.ambPitchThr) { f.ambPitchThr = it }
        p.seek("Speed threshold", 0.05f, 0.98f, f.ambSpeedThr) { f.ambSpeedThr = it }
        p.seek("Silence thr dB", -90f, 0f, f.silenceThrDb) { f.silenceThrDb = it }
        p.seek("Silence thr Hz", 1f, 200f, f.silenceThrHz) { f.silenceThrHz = it }
        p.switch("Userspace protection", f.userspaceProtect) { f.userspaceProtect = it }

        p.title("ALL ANATOMY · CORTEX · LOBES · HEART · NECK", violet)
        p.switch("All anatomy ambient ON", f.allAnatomyOn) { f.allAnatomyOn = it }
        p.switch("Cortex ambient ON", f.cortexOn) { f.cortexOn = it }
        p.seek("Cortex thr", 0.05f, 0.98f, f.cortexThr) { f.cortexThr = it }
        p.seek("Cortex lv", 0f, 1.5f, f.cortexLv) { f.cortexLv = it }
        p.switch("Frontal lobe", f.frontalOn) { f.frontalOn = it }
        p.switch("Parietal lobe", f.parietalOn) { f.parietalOn = it }
        p.switch("Temporal lobe", f.temporalOn) { f.temporalOn = it }
        p.switch("Occipital lobe", f.occipitalOn) { f.occipitalOn = it }
        p.switch("Insular lobe", f.insularOn) { f.insularOn = it }
        p.switch("Cerebellar lobes", f.cerebellarOn) { f.cerebellarOn = it }
        p.seek("Lobes thr", 0.05f, 0.98f, f.lobesThr) { f.lobesThr = it }
        p.seek("Lobes lv", 0f, 1.5f, f.lobesLv) { f.lobesLv = it }
        p.switch("Heart anatomy ambient ON", f.heartOn) { f.heartOn = it }
        p.seek("Heart thr", 0.05f, 0.98f, f.heartThr) { f.heartThr = it }
        p.seek("Heart lv", 0f, 1.5f, f.heartLv) { f.heartLv = it }
        p.switch("Neck anatomy ambient ON", f.neckOn) { f.neckOn = it }
        p.seek("Neck thr", 0.05f, 0.98f, f.neckThr) { f.neckThr = it }
        p.seek("Neck lv", 0f, 1.5f, f.neckLv) { f.neckLv = it }

        p.title("BRAIN L/R · EYES L/R", gold)
        p.switch("Left brain ON", f.leftBrainOn) { f.leftBrainOn = it }
        p.switch("Right brain ON", f.rightBrainOn) { f.rightBrainOn = it }
        p.seek("Left brain thr / lv", 0.05f, 0.98f, f.leftBrainThr) { f.leftBrainThr = it }
        p.seek("Left brain level", 0f, 1.5f, f.leftBrainLv) { f.leftBrainLv = it }
        p.seek("Right brain thr", 0.05f, 0.98f, f.rightBrainThr) { f.rightBrainThr = it }
        p.seek("Right brain level", 0f, 1.5f, f.rightBrainLv) { f.rightBrainLv = it }
        p.switch("Left eye ambient ON", f.leftEyeOn) { f.leftEyeOn = it }
        p.switch("Right eye ambient ON", f.rightEyeOn) { f.rightEyeOn = it }
        p.seek("Left eye thr", 0.05f, 0.98f, f.leftEyeThr) { f.leftEyeThr = it }
        p.seek("Left eye lv", 0f, 1.5f, f.leftEyeLv) { f.leftEyeLv = it }
        p.seek("Right eye thr", 0.05f, 0.98f, f.rightEyeThr) { f.rightEyeThr = it }
        p.seek("Right eye lv", 0f, 1.5f, f.rightEyeLv) { f.rightEyeLv = it }

        p.title("BODY SIDES · L/R/F/B", cyan)
        p.switch("Left body", f.leftBodyOn) { f.leftBodyOn = it }
        p.switch("Right body", f.rightBodyOn) { f.rightBodyOn = it }
        p.switch("Front body", f.frontBodyOn) { f.frontBodyOn = it }
        p.switch("Back body", f.backBodyOn) { f.backBodyOn = it }
        p.seek("Body side thr", 0.05f, 0.98f, f.bodySideThr) { f.bodySideThr = it }
        p.seek("Body side lv", 0f, 1.5f, f.bodySideLv) { f.bodySideLv = it }

        p.title("GLANDS · CNS · FACE · SKIN", violet)
        p.switch("Glands ambient ON", f.glandsOn) { f.glandsOn = it }
        p.switch("Hypothalamus", f.hypothalamusOn) { f.hypothalamusOn = it }
        p.switch("Thyroid", f.thyroidOn) { f.thyroidOn = it }
        p.switch("Thymus", f.thymusOn) { f.thymusOn = it }
        p.seek("Glands thr / lv", 0.05f, 0.98f, f.glandsThr) { f.glandsThr = it }
        p.seek("Glands level", 0f, 1.5f, f.glandsLv) { f.glandsLv = it }
        p.switch("CNS ambient ON", f.cnsOn) { f.cnsOn = it }
        p.seek("CNS thr", 0.05f, 0.98f, f.cnsThr) { f.cnsThr = it }
        p.seek("CNS lv", 0f, 1.5f, f.cnsLv) { f.cnsLv = it }
        p.switch("Face ambient ON", f.faceOn) { f.faceOn = it }
        p.switch("Skin ambient ON", f.skinOn) { f.skinOn = it }
        p.seek("Face/skin thr", 0.05f, 0.98f, f.faceThr) { f.faceThr = it }
        p.seek("Face/skin lv", 0f, 1.5f, f.faceLv) { f.faceLv = it }

        p.title("BODY 84 · POSE/SEG/OBB · SCREEN · AS", gold)
        p.switch("Body84 ambient ON", f.body84On) { f.body84On = it }
        p.seek("Body84 thr", 0.05f, 0.98f, f.body84Thr) { f.body84Thr = it }
        p.seek("Body84 lv", 0f, 1.5f, f.body84Lv) { f.body84Lv = it }
        p.switch("Pose ambient ON", f.poseAmbOn) { f.poseAmbOn = it }
        p.switch("Segment ambient ON", f.segAmbOn) { f.segAmbOn = it }
        p.switch("OBB ambient ON", f.obbAmbOn) { f.obbAmbOn = it }
        p.seek("Model ambient thr", 0.05f, 0.98f, f.modelAmbThr) { f.modelAmbThr = it }
        p.seek("Model ambient lv", 0f, 1.5f, f.modelAmbLv) { f.modelAmbLv = it }
        p.switch("Screen ambient ON", f.screenAmbOn) { f.screenAmbOn = it }
        p.seek("Screen thr / lv", 0.05f, 0.98f, f.screenThr) { f.screenThr = it }
        p.seek("Screen level", 0f, 1.5f, f.screenLv) { f.screenLv = it }
        p.switch("AtomSpare weapons ON", f.asWeaponsOn) { f.asWeaponsOn = it }
        p.seek("AS thr", 0.05f, 0.98f, f.asThr) { f.asThr = it }
        p.seek("AS lv", 0f, 1.5f, f.asLv) { f.asLv = it }

        p.title("ULTRASONIC · DSP · EAR ECHO", cyan)
        p.switch("Ultrasonic warfare ON", f.ultrasonicOn) { f.ultrasonicOn = it }
        p.seek("Ultrasonic thr / lv", 0.05f, 0.98f, f.ultrasonicThr) { f.ultrasonicThr = it }
        p.seek("Ultrasonic level", 0f, 1.5f, f.ultrasonicLv) { f.ultrasonicLv = it }
        p.switch("Ultrasound echo ON", f.ultrasoundEchoOn) { f.ultrasoundEchoOn = it }
        p.switch("DSP tone echo ON", f.dspToneEchoOn) { f.dspToneEchoOn = it }
        p.switch("Ear DSP echo ON", f.earDspOn) { f.earDspOn = it }
        p.seek("Ear DSP level", 0f, 1.5f, f.earDspLv) { f.earDspLv = it }

        p.title("BIPOLAR ±120 dB", violet)
        p.seek("Bipolar neg dB", -120f, 0f, f.bipNegDb) { f.bipNegDb = it }
        p.seek("Bipolar pos dB", 0f, 120f, f.bipPosDb) { f.bipPosDb = it }

        val st = p.status("FINAL —", violet)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                st.text = f.lastStatus
                h.postDelayed(this, 250)
            }
        })
    }
}
