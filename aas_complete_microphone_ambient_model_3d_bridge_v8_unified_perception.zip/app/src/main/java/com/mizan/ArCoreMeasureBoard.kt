package com.mizan

import android.app.Activity
import android.util.Log
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Camera
import com.google.ar.core.Config
import com.google.ar.core.Frame
import com.google.ar.core.Plane
import com.google.ar.core.PointCloud
import com.google.ar.core.Session
import com.google.ar.core.TrackingFailureReason
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.google.ar.core.exceptions.UnavailableException

/**
 * Real Google ARCore measurement board.
 * PAUSED/STOPPED causes:
 *  - legacy Camera still holding the camera (must stop first)
 *  - session not resumed after onPause
 *  - insufficient motion / bad light / excessive motion (TrackingFailureReason)
 *  - ARCore not installed / device unsupported
 */
class ArCoreMeasureBoard {
    private var cameraTextureId = 0
    private var displayWidth = 0
    private var displayHeight = 0
    private var displayRotation = 0


    enum class ScaleType(val id: Int, val label: String, val metersPerUnit: Float) {
        METER(0, "METER (ARCore)", 1f),
        CENTIMETER(1, "CENTIMETER", 0.01f),
        MILLIMETER(2, "MILLIMETER", 0.001f),
        INCH(3, "INCH", 0.0254f),
        FOOT(4, "FOOT", 0.3048f);
        companion object {
            fun fromId(id: Int): ScaleType =
                values().getOrElse(id.coerceIn(0, values().size - 1)) { METER }
        }
    }

    @Volatile var enabled = true
    @Volatile var arProtectOn = true
    @Volatile var arProtectLv = 0.65f

    @Volatile var trackingOn = true
    @Volatile var trackThr = 0.35f
    @Volatile var intensity = 0.70f
    @Volatile var intensityThr = 0.40f
    @Volatile var measureThr = 0.50f
    @Volatile var scaleType = ScaleType.METER

    @Volatile var trackingStateName = "STOPPED"
    @Volatile var failureReason = "NONE"
    @Volatile var trackingQuality = 0f
    @Volatile var poseX = 0f
    @Volatile var poseY = 0f
    @Volatile var poseZ = 0f
    @Volatile var distanceM = 0f
    @Volatile var intensityActive = false
    @Volatile var measureActive = false
    @Volatile var sessionRunning = false
    @Volatile var lastError: String? = null
    @Volatile var installRequested = false
    @Volatile var framesOk = 0
    // Mesh world · point cloud (Camera AR tab)
    @Volatile var meshWorldOn = true
    @Volatile var pointCloudOn = true
    @Volatile var pointCloudCount = 0
    @Volatile var pointCloudConfidenceAvg = 0f
    @Volatile var planeCount = 0
    @Volatile var horizontalPlanes = 0
    @Volatile var verticalPlanes = 0
    @Volatile var meshWorldStatus = "MESH WORLD idle"

    private var session: Session? = null
    private var activity: Activity? = null

    fun setScaleTypeId(id: Int) { scaleType = ScaleType.fromId(id) }

    fun attach(activity: Activity) {
        this.activity = activity
    }

    fun startSession(): Boolean {
        val act = activity ?: run {
            lastError = "no activity"
            return false
        }
        if (!enabled) {
            lastError = "AR board disabled"
            return false
        }
        if (!trackingOn) {
            lastError = "AR tracking OFF — turn tracking ON"
            return false
        }
        return try {
            when (ArCoreApk.getInstance().requestInstall(act, !installRequested)) {
                ArCoreApk.InstallStatus.INSTALL_REQUESTED -> {
                    installRequested = true
                    lastError = "ARCore install requested — reopen after install"
                    return false
                }
                else -> { /* INSTALLED or already present */ }
            }
            // If a previous session is still alive, pause first so resume is clean
            if (session != null) {
                try { session?.pause() } catch (_: Exception) {}
            }
            if (session == null) {
                session = Session(act)
                val config = Config(session).apply {
                    updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
                    planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
                    lightEstimationMode = Config.LightEstimationMode.AMBIENT_INTENSITY
                    focusMode = Config.FocusMode.AUTO
                    // Feature points / point cloud available whenever session runs
                }
                session?.configure(config)
            }
            // Resume claims the camera exclusively
            session?.resume()
            sessionRunning = true
            lastError = null
            trackingStateName = "RESUMED"
            true
        } catch (e: UnavailableException) {
            lastError = "ARCore unavailable: ${e.message}"
            sessionRunning = false
            trackingStateName = "STOPPED"
            Log.e("ArCoreMeasure", "Unavailable", e)
            false
        } catch (e: CameraNotAvailableException) {
            lastError = "Camera busy — stop preview first, then retry"
            sessionRunning = false
            trackingStateName = "STOPPED"
            Log.e("ArCoreMeasure", "Camera", e)
            false
        } catch (e: Exception) {
            lastError = e.message ?: "ARCore start failed"
            sessionRunning = false
            trackingStateName = "STOPPED"
            Log.e("ArCoreMeasure", "Start failed", e)
            false
        }
    }

    fun pauseSession() {
        // Anti-stuck: pause ARCore so OS camera is not held in background (ARCore issue freeze on pause)
        try {
            session?.pause()
        } catch (_: Exception) {}
        sessionRunning = false
        trackingStateName = "PAUSED"
        measureActive = false
        intensityActive = false
        lastError = null
    }

    fun stopSession() {
        // Full close — frees camera for legacy CameraManager / other apps
        try {
            session?.pause()
        } catch (_: Exception) {}
        try {
            session?.close()
        } catch (_: Exception) {}
        session = null
        sessionRunning = false
        trackingStateName = "STOPPED"
        trackingQuality = 0f
        failureReason = "NONE"
        measureActive = false
        intensityActive = false
        framesOk = 0
        pointCloudCount = 0
        planeCount = 0
        meshWorldStatus = "MESH WORLD stopped"
    }

    

    /** Pull ARCore PointCloud + planes into mesh-world stats (call each frame). */
    fun ingestMeshWorld(frame: Frame) {
        if (!meshWorldOn && !pointCloudOn) {
            meshWorldStatus = "MESH WORLD off"
            return
        }
        try {
            if (pointCloudOn) {
                frame.acquirePointCloud().use { pc: PointCloud ->
                    val buf = pc.points
                    val n = if (buf != null) buf.remaining() / 4 else 0
                    pointCloudCount = n
                    var confSum = 0f
                    var samples = 0
                    if (buf != null && n > 0) {
                        val arr = FloatArray(buf.remaining())
                        buf.get(arr)
                        var i = 3
                        while (i < arr.size) {
                            confSum += arr[i]
                            samples++
                            i += 4
                        }
                    }
                    pointCloudConfidenceAvg = if (samples > 0) (confSum / samples).coerceIn(0f, 1f) else 0f
                }
            }
            val planes = session?.getAllTrackables(Plane::class.java) ?: emptyList()
            planeCount = planes.size
            horizontalPlanes = planes.count {
                it.type == Plane.Type.HORIZONTAL_UPWARD_FACING || it.type == Plane.Type.HORIZONTAL_DOWNWARD_FACING
            }
            verticalPlanes = planes.count { it.type == Plane.Type.VERTICAL }
            meshWorldStatus =
                "MESH WORLD · planes $planeCount (H$horizontalPlanes V$verticalPlanes) · " +
                "pointCloud $pointCloudCount conf=${(pointCloudConfidenceAvg * 100).toInt()}%"
        } catch (e: Exception) {
            meshWorldStatus = "MESH WORLD · ${e.message ?: "err"}"
        }
    }

    fun distanceInScale(): Float {
        val mpu = scaleType.metersPerUnit
        if (mpu <= 0f) return 0f
        return distanceM / mpu
    }

    fun statusLine(): String {
        if (lastError != null && !sessionRunning) {
            return "ARCore: $lastError · $meshWorldStatus"
        }
        val unit = when (scaleType) {
            ScaleType.METER -> "m"
            ScaleType.CENTIMETER -> "cm"
            ScaleType.MILLIMETER -> "mm"
            ScaleType.INCH -> "in"
            ScaleType.FOOT -> "ft"
        }
        val d = distanceInScale()
        val meas = if (measureActive) "MEAS" else "-"
        val inten = if (intensityActive) "INT" else "-"
        val run = if (sessionRunning) "SESSION" else "NO-SESSION"
        val fail = if (failureReason != "NONE" && trackingStateName != "TRACKING") " fail=$failureReason" else ""
        return "ARCore $run $trackingStateName$fail Q=${(trackingQuality*100).toInt()}% · ${scaleType.label} · d=${"%.3f".format(d)}$unit · pose=(${"%.2f".format(poseX)},${"%.2f".format(poseY)},${"%.2f".format(poseZ)})m · frames=$framesOk · $meas $inten"
    }

    @Synchronized
    fun setDisplayGeometry(width: Int, height: Int) {
        displayWidth = width.coerceAtLeast(1)
        displayHeight = height.coerceAtLeast(1)
        displayRotation = activity?.windowManager?.defaultDisplay?.rotation ?: 0
        try {
            session?.setDisplayGeometry(displayRotation, displayWidth, displayHeight)
        } catch (e: Exception) {
            lastError = e.message
        }
    }

    /** OpenGL-thread Session.update with camera texture. */
    @Synchronized
    fun updateFromArCore(textureId: Int): Frame? {
        if (!enabled || !trackingOn) {
            trackingStateName = if (!enabled) "STOPPED" else "PAUSED"
            trackingQuality = 0f
            measureActive = false
            intensityActive = false
            return null
        }
        val sess = session
        if (sess == null || !sessionRunning) {
            trackingStateName = "STOPPED"
            return null
        }
        try {
            if (cameraTextureId != textureId) {
                sess.setCameraTextureNames(intArrayOf(textureId))
                cameraTextureId = textureId
                if (displayWidth > 0 && displayHeight > 0) {
                    sess.setDisplayGeometry(displayRotation, displayWidth, displayHeight)
                }
            }
            val frame: Frame = sess.update()
            val camera: Camera = frame.camera
            val ts: TrackingState = camera.trackingState
            trackingStateName = ts.name
            failureReason = try {
                camera.trackingFailureReason?.name ?: "NONE"
            } catch (_: Exception) {
                "NONE"
            }
            trackingQuality = when (ts) {
                TrackingState.TRACKING -> intensity.coerceIn(0.15f, 1f)
                TrackingState.PAUSED -> 0.20f * intensity
                else -> 0f
            }
            if (ts == TrackingState.TRACKING) {
                framesOk++
                val pose = camera.displayOrientedPose
                poseX = pose.tx()
                poseY = pose.ty()
                poseZ = pose.tz()
                distanceM = kotlin.math.sqrt(poseX * poseX + poseY * poseY + poseZ * poseZ)
            }
            intensityActive = trackingQuality >= intensityThr.coerceIn(0.05f, 1f)
            measureActive = ts == TrackingState.TRACKING &&
                trackingQuality >= measureThr.coerceIn(0.05f, 1f) &&
                trackingQuality >= trackThr.coerceIn(0.05f, 1f)
            ingestMeshWorld(frame)
            lastError = null
            return frame
        } catch (e: CameraNotAvailableException) {
            lastError = "Camera not available mid-session"
            trackingStateName = "STOPPED"
            sessionRunning = false
            return null
        } catch (e: Exception) {
            lastError = e.message
            return null
        }
    }

    /** Legacy no-arg tick for non-GL callers */
    fun updateFromArCore() {
        // no-op without GL texture; GL path uses updateFromArCore(textureId)
    }

}
