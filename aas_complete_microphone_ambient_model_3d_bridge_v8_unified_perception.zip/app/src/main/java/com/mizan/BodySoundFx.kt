package com.mizan

/**
 * Camera-gated sound effect trigger. Camera pose/mask confidence selects the
 * body region; live microphone level and spectral brightness control effect
 * intensity/rate. A single phone microphone cannot identify which person or
 * body part produced a sound, so the selected region is a visual destination,
 * not a claim about sound origin.
 */
class BodySoundFx {
    @Volatile var enabled = MemoryPaths.getBool("body_fx_on", false)
        set(value) { field = value; MemoryPaths.putBool("body_fx_on", value) }
    @Volatile var raw = MemoryPaths.getBool("body_fx_raw", false)
        set(value) { field = value; MemoryPaths.putBool("body_fx_raw", value) }
    @Volatile var detectionThreshold = MemoryPaths.getFloat("body_fx_det_thr", 0.45f).coerceIn(0.10f, 0.95f)
        set(value) { field = value.coerceIn(0.10f, 0.95f); MemoryPaths.putFloat("body_fx_det_thr", field) }
    @Volatile var partThreshold = MemoryPaths.getFloat("body_fx_part_thr", 0.18f).coerceIn(0f, 0.95f)
        set(value) { field = value.coerceIn(0f, 0.95f); MemoryPaths.putFloat("body_fx_part_thr", field) }
    @Volatile var audioThreshold = MemoryPaths.getFloat("body_fx_audio_thr", 0.08f).coerceIn(0f, 1f)
        set(value) { field = value.coerceIn(0f, 1f); MemoryPaths.putFloat("body_fx_audio_thr", field) }
    @Volatile var level = MemoryPaths.getFloat("body_fx_level", 0.55f).coerceIn(0f, 1f)
        set(value) { field = value.coerceIn(0f, 1f); MemoryPaths.putFloat("body_fx_level", field) }
    @Volatile var brainMix = MemoryPaths.getFloat("body_fx_brain_mix", 0.25f).coerceIn(0f, 1f)
        set(value) { field = value.coerceIn(0f, 1f); MemoryPaths.putFloat("body_fx_brain_mix", field) }
    @Volatile var cooldownMs = MemoryPaths.getFloat("body_fx_cooldown", 1600f).toInt().coerceIn(250, 10_000)
        set(value) { field = value.coerceIn(250, 10_000); MemoryPaths.putFloat("body_fx_cooldown", field.toFloat()) }
    @Volatile var selectedPart = MemoryPaths.getFloat("body_fx_part", HumanDetection.PART_TORSO.toFloat()).toInt()
        .coerceIn(0, HumanDetection.PART_NAMES.lastIndex)
        set(value) {
            field = value.coerceIn(0, HumanDetection.PART_NAMES.lastIndex)
            MemoryPaths.putFloat("body_fx_part", field.toFloat())
            synchronized(this) { updateTargetPartConfidence() }
        }
    @Volatile var selectedTrack = MemoryPaths.getFloat("body_fx_track", -1f).toInt()
        set(value) { field = value; MemoryPaths.putFloat("body_fx_track", field.toFloat()) }

    @Volatile var microphoneLevel = 0f
        private set
    @Volatile var spectralCentroidHz = 0f
        private set
    @Volatile var brainIntensity = 0f
        private set
    @Volatile var detectionConfidence = 0f
        private set
    @Volatile var targetPartConfidence = 0f
        private set
    @Volatile var lastPlayedPart = -1
        private set
    @Volatile var lastPlayedTrack = -1
        private set
    @Volatile var status = "Disabled"
        private set

    @Volatile var onPlayEffect: ((trackIndex: Int, intensity: Float, playbackRate: Float, partIndex: Int) -> Unit)? = null

    private var hasPerson = false
    private var armed = true
    private var lastTriggerMs = 0L
    private var latestDetection = HumanDetection.none()

    @Synchronized
    fun feedAudio(rmsLevel: Float, centroidHz: Float, brain: Float = brainIntensity) {
        microphoneLevel = rmsLevel.coerceIn(0f, 1f)
        spectralCentroidHz = centroidHz.coerceIn(0f, 12_000f)
        brainIntensity = brain.coerceIn(0f, 1f)
        tryTrigger()
    }

    fun feedBrainIntensity(value: Float) {
        brainIntensity = value.coerceIn(0f, 1f)
    }

    /**
     * Hook for actual camera-model results only. Audio cannot create a person
     * detection or body-part score.
     */
    @Synchronized
    fun feedDetection(detection: HumanDetection) {
        latestDetection = detection
        hasPerson = detection.hasPerson && detection.isFresh()
        detectionConfidence = if (hasPerson) detection.confidence else 0f
        updateTargetPartConfidence()
        if (!hasPerson || targetPartConfidence < partThreshold) armed = true
        tryTrigger()
    }

    private fun updateTargetPartConfidence() {
        val d = latestDetection
        targetPartConfidence = if (hasPerson && d.isFresh()) {
            d.partScores.getOrNull(selectedPart)?.coerceIn(0f, 1f) ?: 0f
        } else 0f
    }

    @Synchronized
    private fun tryTrigger() {
        if (!enabled) {
            status = "Body FX off"
            return
        }
        if (!hasPerson || !latestDetection.isFresh() || detectionConfidence < detectionThreshold) {
            if (!latestDetection.isFresh()) {
                hasPerson = false
                detectionConfidence = 0f
                targetPartConfidence = 0f
            }
            status = "Waiting for live person pose + mask"
            armed = true
            return
        }
        if (targetPartConfidence < partThreshold) {
            status = "Person found · selected part not confidently visible"
            armed = true
            return
        }
        val audioDrive = microphoneLevel * (1f - brainMix) + brainIntensity * brainMix
        // Brain intensity shapes the result, but a live mic event is always
        // required. RAW bypasses only the mic threshold, never person/part
        // detection or the non-silence check.
        val audioReady = microphoneLevel > 0.005f && (raw || microphoneLevel >= audioThreshold)
        if (!audioReady) {
            status = "Person + ${HumanDetection.PART_NAMES[selectedPart]} · waiting for audio threshold"
            armed = true
            return
        }
        val track = selectedTrack
        val callback = onPlayEffect
        if (track < 0 || callback == null) {
            status = "Person + audio ready · choose an SD sound"
            return
        }
        val now = System.currentTimeMillis()
        if (!armed || now - lastTriggerMs < cooldownMs) {
            status = "Armed · ${HumanDetection.PART_NAMES[selectedPart]} · cooldown"
            return
        }

        val effectIntensity = (audioDrive * level).coerceIn(0f, 1f)
        val playbackRate = (0.85f + (spectralCentroidHz / 12_000f) * 0.50f).coerceIn(0.85f, 1.35f)
        try {
            callback(track, effectIntensity, playbackRate, selectedPart)
            lastTriggerMs = now
            lastPlayedTrack = track
            lastPlayedPart = selectedPart
            armed = false
            status = "Triggered ${HumanDetection.PART_NAMES[selectedPart]} · ${"%.0f".format(effectIntensity * 100)}%"
        } catch (t: Throwable) {
            status = "Playback error · ${t.message ?: "unknown"}"
        }
    }

    @Synchronized
    fun resetDetection() {
        hasPerson = false
        detectionConfidence = 0f
        targetPartConfidence = 0f
        armed = true
        status = if (enabled) "Waiting for live person pose + mask" else "Body FX off"
    }

    fun statusLine(): String =
        "BODY FX · ${HumanDetection.PART_NAMES.getOrNull(selectedPart) ?: "—"} · " +
            "person=${(detectionConfidence * 100).toInt()}% part=${(targetPartConfidence * 100).toInt()}% " +
            "mic=${(microphoneLevel * 100).toInt()}% brain=${(brainIntensity * 100).toInt()}% · $status"
}
