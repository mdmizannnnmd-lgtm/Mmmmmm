package com.mizan

/**
 * COCO-WholeBody / DWPose standard: **133 keypoints**
 * Body 17 + feet 6 = 23 · Face 68 · Left hand 21 · Right hand 21
 * @see https://github.com/jin-s13/COCO-WholeBody
 */
object WholeBodyPose133 {
    const val COUNT = 133
    const val BODY_COUNT = 23   // 17 body + 6 feet
    const val FACE_COUNT = 68
    const val HAND_COUNT = 21

    val BODY = arrayOf(
        "nose", "left_eye", "right_eye", "left_ear", "right_ear",
        "left_shoulder", "right_shoulder", "left_elbow", "right_elbow",
        "left_wrist", "right_wrist", "left_hip", "right_hip",
        "left_knee", "right_knee", "left_ankle", "right_ankle",
        "left_big_toe", "left_small_toe", "left_heel",
        "right_big_toe", "right_small_toe", "right_heel"
    )

    /** Face 0..67 (COCO-WholeBody convention). */
    fun faceName(i: Int) = "face-$i"

    val HAND = arrayOf(
        "wrist",
        "thumb_cmc", "thumb_mcp", "thumb_ip", "thumb_tip",
        "index_mcp", "index_pip", "index_dip", "index_tip",
        "middle_mcp", "middle_pip", "middle_dip", "middle_tip",
        "ring_mcp", "ring_pip", "ring_dip", "ring_tip",
        "pinky_mcp", "pinky_pip", "pinky_dip", "pinky_tip"
    )

    /** All 133 names in order: body23 + face68 + left hand21 + right hand21. */
    val NAMES: Array<String> = buildList {
        addAll(BODY)
        for (i in 0 until FACE_COUNT) add(faceName(i))
        for (h in HAND) add("left_$h")
        for (h in HAND) add("right_$h")
    }.toTypedArray()

    init {
        require(NAMES.size == COUNT) { "WholeBodyPose133 size ${NAMES.size} != $COUNT" }
    }

    /** Index ranges for subsystems. */
    val BODY_RANGE = 0 until BODY_COUNT
    val FACE_RANGE = BODY_COUNT until (BODY_COUNT + FACE_COUNT)
    val LEFT_HAND_RANGE = (BODY_COUNT + FACE_COUNT) until (BODY_COUNT + FACE_COUNT + HAND_COUNT)
    val RIGHT_HAND_RANGE = (BODY_COUNT + FACE_COUNT + HAND_COUNT) until COUNT
}
