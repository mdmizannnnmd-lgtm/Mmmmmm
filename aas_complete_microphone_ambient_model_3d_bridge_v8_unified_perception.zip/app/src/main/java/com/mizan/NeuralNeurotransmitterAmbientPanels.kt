package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object NeuralNeurotransmitterAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: NeuralNeurotransmitterAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFCE93D8.toInt()
        p.title("NEURAL · NEUROTRANSMITTER · NEURON 3D", c)
        p.note("Glu · GABA · ACh · DA · NE · 5-HT · neuron field · repair/heal Hz · safe neuron")
        p.switch("Neural ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.seek("Threshold", 0.05f, 1f, b.thr) { b.thr = it }
        p.seek("Level", 0.1f, 1.5f, b.levelAmt) { b.levelAmt = it }
        p.seek("Bad neural thr", 0.2f, 1.2f, b.badNeuralThr) { b.badNeuralThr = it }
        p.seek("Repair freq Hz", 1f, 40f, b.repairFreqHz) { b.repairFreqHz = it }
        p.seek("Heal freq Hz", 5f, 100f, b.healFreqHz) { b.healFreqHz = it }
        val st = p.status("NEURAL —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 300) }
        })
    }
}
