package com.mizan

/**
 * Calcium ambient (model + BLE scale) · Mg+Ca pair · enemy destroy Mg/Ca/water ·
 * full chemical thr · skin/cells thr · body-wide protect.
 * Symbolic only — not medical. RAW COMPLETE.
 */
class CaMgProtectChemBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Calcium ambient (mirror Mg path)
    @Volatile var caOn = true
    @Volatile var caThr = 0.22f
    @Volatile var caLv = 0.85f
    @Volatile var caOut = 0f
    @Volatile var caModelDrive = 0f

    // Paired Mg (from scale board or local)
    @Volatile var mgPairOut = 0f

    // Enemy destroy paths
    @Volatile var enemyDestroyOn = true
    @Volatile var enemyDestroyMg = 0f
    @Volatile var enemyDestroyCa = 0f
    @Volatile var enemyDestroyWater = 0f
    @Volatile var enemyDestroyThr = 0.20f
    @Volatile var enemyDestroyLv = 0.90f

    // Our protection (counter-destroy)
    @Volatile var protectOn = true
    @Volatile var protectMg = 0f
    @Volatile var protectCa = 0f
    @Volatile var protectWater = 0f
    @Volatile var protectChem = 0f
    @Volatile var protectSkin = 0f
    @Volatile var protectCells = 0f
    @Volatile var protectThr = 0.18f
    @Volatile var protectLv = 0.95f
    @Volatile var protectFullOut = 0f

    // Chemical thresholds (master)
    @Volatile var chemThrOn = true
    @Volatile var chemThr = 0.22f
    @Volatile var chemLv = 0.88f
    @Volatile var chemOut = 0f
    @Volatile var waterOut = 0f

    // Skin + cells thresholds
    @Volatile var skinThrOn = true
    @Volatile var skinThr = 0.22f
    @Volatile var skinLv = 0.88f
    @Volatile var skinOut = 0f
    @Volatile var cellsThrOn = true
    @Volatile var cellsThr = 0.22f
    @Volatile var cellsLv = 0.88f
    @Volatile var cellsOut = 0f

    @Volatile var status = "Ca·Mg PROTECT·CHEM idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        mic: Float,
        modelE: Float,
        mgIn: Float,
        enemyThreat: Float,
        waterIn: Float,
        skinIn: Float,
        cellsIn: Float
    ) {
        if (!enabled) {
            status = "Ca·Mg PROTECT OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        caModelDrive = modelE.coerceIn(0f, 1f)
        caOut = lane(caOn, caThr, caLv, maxOf(e, caModelDrive))
        mgPairOut = mgIn.coerceIn(0f, 1f)

        // Enemy "destroy" intensity on Mg/Ca/water channels
        val thrE = enemyThreat.coerceIn(0f, 1f)
        enemyDestroyMg = lane(enemyDestroyOn, enemyDestroyThr, enemyDestroyLv, thrE * 0.95f)
        enemyDestroyCa = lane(enemyDestroyOn, enemyDestroyThr, enemyDestroyLv, thrE * 0.92f)
        enemyDestroyWater = lane(enemyDestroyOn, enemyDestroyThr, enemyDestroyLv, thrE * 0.90f)

        // Protection counters — rise with our Mg/Ca/water + skin/cells when threat present
        val baseProt = maxOf(mgPairOut, caOut, waterIn, skinIn, cellsIn, e * 0.5f)
        protectMg = lane(protectOn, protectThr, protectLv, maxOf(baseProt, enemyDestroyMg))
        protectCa = lane(protectOn, protectThr, protectLv, maxOf(baseProt, enemyDestroyCa))
        protectWater = lane(protectOn, protectThr, protectLv, maxOf(waterIn, enemyDestroyWater, e))
        protectChem = lane(protectOn, protectThr, protectLv, maxOf(mgPairOut, caOut, chemOut))
        protectSkin = lane(protectOn, protectThr, protectLv, maxOf(skinIn, e * 0.7f))
        protectCells = lane(protectOn, protectThr, protectLv, maxOf(cellsIn, e * 0.65f))
        protectFullOut = maxOf(protectMg, protectCa, protectWater, protectChem, protectSkin, protectCells)

        waterOut = lane(chemThrOn, chemThr, chemLv, maxOf(waterIn, e * 0.9f))
        chemOut = lane(chemThrOn, chemThr, chemLv, maxOf(mgPairOut, caOut, waterOut, e))
        skinOut = lane(skinThrOn, skinThr, skinLv, maxOf(skinIn, e * 0.85f))
        cellsOut = lane(cellsThrOn, cellsThr, cellsLv, maxOf(cellsIn, e * 0.8f))

        status =
            "Ca=${(caOut*100).toInt()}% Mg=${(mgPairOut*100).toInt()}% · " +
            "ENEMY-DEST Mg/Ca/H2O=${(enemyDestroyMg*100).toInt()}/${(enemyDestroyCa*100).toInt()}/${(enemyDestroyWater*100).toInt()} · " +
            "PROT Mg/Ca/H2O=${(protectMg*100).toInt()}/${(protectCa*100).toInt()}/${(protectWater*100).toInt()} · " +
            "CHEM/SKIN/CELL=${(chemOut*100).toInt()}/${(skinOut*100).toInt()}/${(cellsOut*100).toInt()} · " +
            "FULL-PROT=${(protectFullOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled) return
        // Dampen enemy-ish outs when protect is high
        if (protectFullOut > 0.02f) {
            val k = (1f - protectFullOut * 0.9f).coerceIn(0.05f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
            sb.bulletOut *= (1f - protectFullOut * 0.5f).coerceIn(0.1f, 1f)
            sb.knifeOut *= (1f - protectFullOut * 0.5f).coerceIn(0.1f, 1f)
        }
        val vv = v ?: return
        try {
            vv.bodyChemBrain.calcium = maxOf(vv.bodyChemBrain.calcium, caOut, protectCa * 0.5f)
            vv.bodyChemBrain.magnesium = maxOf(vv.bodyChemBrain.magnesium, mgPairOut, protectMg * 0.5f)
            vv.bodyChemBrain.water = maxOf(vv.bodyChemBrain.water, waterOut, protectWater * 0.5f)
            vv.bodyChemBrain.mineral = maxOf(vv.bodyChemBrain.mineral, chemOut)
            vv.bodyChemBrain.chemFullOut = maxOf(vv.bodyChemBrain.chemFullOut, chemOut, protectChem)
        } catch (_: Throwable) {}
        try {
            vv.mgBleScaleWatt.mgOut = maxOf(vv.mgBleScaleWatt.mgOut, mgPairOut, protectMg * 0.4f)
            vv.mgBleScaleWatt.chemCa = maxOf(vv.mgBleScaleWatt.chemCa, caOut)
            vv.mgBleScaleWatt.chemMg = maxOf(vv.mgBleScaleWatt.chemMg, mgPairOut)
        } catch (_: Throwable) {}
        try {
            vv.bioSkinCell.epidermisOut = maxOf(vv.bioSkinCell.epidermisOut, skinOut * 0.6f, protectSkin * 0.5f)
            vv.bioSkinCell.cellMembrane = maxOf(vv.bioSkinCell.cellMembrane, cellsOut * 0.6f, protectCells * 0.5f)
            vv.bioSkinCell.nucleus = maxOf(vv.bioSkinCell.nucleus, cellsOut * 0.5f)
            vv.bioSkinCell.bioFullOut = maxOf(vv.bioSkinCell.bioFullOut, protectFullOut * 0.5f)
        } catch (_: Throwable) {}
        try {
            vv.allBodySkinAnatomy.allSkinOut = maxOf(vv.allBodySkinAnatomy.allSkinOut, skinOut, protectSkin)
            vv.skinSoundsProtect.protectOut = maxOf(vv.skinSoundsProtect.protectOut, protectFullOut)
        } catch (_: Throwable) {}
        try {
            if (vv.anatomy3d.layerOn.size > 2) {
                vv.anatomy3d.layerOn[2] = true
                vv.anatomy3d.layerLevel[2] = maxOf(vv.anatomy3d.layerLevel[2], caOut, protectCa)
            }
            vv.anatomy3d.atmosphere = maxOf(vv.anatomy3d.atmosphere, protectFullOut * 0.4f)
        } catch (_: Throwable) {}
        try {
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, protectFullOut)
            vv.completeAtomProtect.atomInsideOut = maxOf(vv.completeAtomProtect.atomInsideOut, protectWater, protectCells)
            vv.completeAtomProtect.atomOutsideOut = maxOf(vv.completeAtomProtect.atomOutsideOut, protectSkin)
        } catch (_: Throwable) {}
        try {
            vv.enemySoundCancel.atomEnemyCancelOut = maxOf(vv.enemySoundCancel.atomEnemyCancelOut, protectFullOut * 0.7f)
        } catch (_: Throwable) {}
    }
}
