package com.mizan

/**
 * Complete atomspare (all previous paths unified) + full protection.
 * Skin in/out · anatomy shell · 84 full human · front/back/L/R/up/down ·
 * hair · enemy cannot break out · model/atom abuse · isolation · master/AR shields.
 * RAW COMPLETE.
 */
class CompleteAtomspareProtectBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Master atomspare
    @Volatile var atomOn = true
    @Volatile var atomThr = 0.28f
    @Volatile var atomLv = 0.85f
    @Volatile var atomAutoThr = true
    @Volatile var atomOut = 0f
    @Volatile var atomInsideOut = 0f
    @Volatile var atomOutsideOut = 0f

    // Body directional atomspare (all atmospheric)
    @Volatile var bodyUpAtom = 0f
    @Volatile var bodyDownAtom = 0f
    @Volatile var bodyLeftAtom = 0f
    @Volatile var bodyRightAtom = 0f
    @Volatile var bodyCenterAtom = 0f
    @Volatile var bodyFrontAtom = 0f
    @Volatile var bodyBackAtom = 0f
    @Volatile var allPreviousAtmospheric = true

    // Protection master
    @Volatile var protectOn = true
    @Volatile var protectLv = 0.92f
    @Volatile var enemyCannotBreakOut = true
    @Volatile var enemyModelAbuseProtect = true
    @Volatile var enemyAtomAbuseProtect = true
    @Volatile var isolationOn = true
    @Volatile var masterShieldOn = true
    @Volatile var arShieldOn = true
    @Volatile var protectOut = 0f

    @Volatile var status = "COMPLETE ATOMPARE·PROTECT idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, enemyThreat: Float = 0f) {
        if (!enabled) {
            status = "COMPLETE ATOMPARE·PROTECT OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        if (atomAutoThr) {
            atomThr = (0.10f + e * 0.28f).coerceIn(0.08f, 0.55f)
        }
        atomOut = lane(atomOn, atomThr, atomLv, e)
        atomOutsideOut = atomOut * 0.95f
        atomInsideOut = atomOut * 0.90f
        // Directional body atomspare from master atom
        bodyCenterAtom = atomOut
        bodyUpAtom = atomOut * 0.95f
        bodyDownAtom = atomOut * 0.90f
        bodyLeftAtom = atomOut * 0.92f
        bodyRightAtom = atomOut * 0.92f
        bodyFrontAtom = atomOutsideOut
        bodyBackAtom = atomOutsideOut * 0.95f

        val enemy = enemyThreat.coerceIn(0f, 1f)
        protectOut = if (protectOn) {
            (maxOf(atomOut, enemy) * protectLv.coerceIn(0.1f, 1f)).coerceIn(0f, 1f)
        } else 0f

        status =
            "ATOM C=${(bodyCenterAtom*100).toInt()}% U/D=${(bodyUpAtom*100).toInt()}/${(bodyDownAtom*100).toInt()} " +
            "L/R=${(bodyLeftAtom*100).toInt()}/${(bodyRightAtom*100).toInt()} F/Bk=${(bodyFrontAtom*100).toInt()}/${(bodyBackAtom*100).toInt()}% · " +
            "autoT=${"%.2f".format(atomThr)} PROT=${(protectOut*100).toInt()}% " +
            "noBreak=$enemyCannotBreakOut abuse=${enemyModelAbuseProtect && enemyAtomAbuseProtect} " +
            "iso=$isolationOn M/AR=$masterShieldOn/$arShieldOn" +
            if (rawComplete) " · RAW" else ""
    }

    /** Push complete atomspare into all previous boards + hard protection. */
    fun apply(v: VisualShieldView, sb: SoundBankGuard) {
        if (!enabled) return

        // Skin atomspare
        try {
            val s = v.skinAtomspare
            if (s.enabled) {
                s.atomSpareOut = maxOf(s.atomSpareOut, atomOut)
                s.skinOutsideOut = maxOf(s.skinOutsideOut, atomOutsideOut)
                s.skinInsideOut = maxOf(s.skinInsideOut, atomInsideOut)
                s.atomSpareOn = true
                s.skinOutsideOn = true
                s.skinInsideOn = true
            }
        } catch (_: Throwable) {}

        // Anatomy shell
        try {
            val a = v.anatomyShell
            if (a.enabled) {
                a.atomSpareShellOut = maxOf(a.atomSpareShellOut, atomOut)
                a.outsideShellOut = maxOf(a.outsideShellOut, atomOutsideOut)
                a.insideSystemsOut = maxOf(a.insideSystemsOut, atomInsideOut)
                a.insideAtmoOut = maxOf(a.insideAtmoOut, atomInsideOut)
                a.atomSpareShellOn = true
                a.enemyCannotBreakOut = enemyCannotBreakOut || a.enemyCannotBreakOut
                a.enemyModelAbuseProtect = enemyModelAbuseProtect || a.enemyModelAbuseProtect
                a.enemyAtomAbuseProtect = enemyAtomAbuseProtect || a.enemyAtomAbuseProtect
            }
        } catch (_: Throwable) {}

        // 84 full human
        try {
            val h = v.body84FullHuman
            if (h.enabled) {
                h.atomOut = maxOf(h.atomOut, atomOut)
                h.outsideOut = maxOf(h.outsideOut, atomOutsideOut)
                h.insideOut = maxOf(h.insideOut, atomInsideOut)
                h.outsideOn = true
                h.insideOn = true
            }
        } catch (_: Throwable) {}

        // Body atmosphere 3D
        try {
            v.bodyAtmo3d.level = maxOf(v.bodyAtmo3d.level, atomOut)
            v.bodyAtmo3d.waveLevel = maxOf(v.bodyAtmo3d.waveLevel, atomOutsideOut)
            v.bodyAtmo3d.movementLevel = maxOf(v.bodyAtmo3d.movementLevel, atomInsideOut)
        } catch (_: Throwable) {}

        // Anatomy3D atmosphere
        try {
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, atomOut)
            v.anatomy3d.outside.level = maxOf(v.anatomy3d.outside.level, atomOutsideOut)
            v.anatomy3d.inside.level = maxOf(v.anatomy3d.inside.level, atomInsideOut)
        } catch (_: Throwable) {}

        // Front/back/L/R/up/down sides
        try {
            val f = v.frontSideAmbient
            f.bodyFrontOut = maxOf(f.bodyFrontOut, atomOutsideOut * 0.9f)
            f.bodyBackOut = maxOf(f.bodyBackOut, atomOutsideOut * 0.85f)
            f.bodyLeftOut = maxOf(f.bodyLeftOut, atomOutsideOut * 0.85f)
            f.bodyRightOut = maxOf(f.bodyRightOut, atomOutsideOut * 0.85f)
            f.bodyUpOut = maxOf(f.bodyUpOut, bodyUpAtom)
            f.bodyDownOut = maxOf(f.bodyDownOut, bodyDownAtom)
            f.bodyLeftOut = maxOf(f.bodyLeftOut, bodyLeftAtom)
            f.bodyRightOut = maxOf(f.bodyRightOut, bodyRightAtom)
            f.bodyFrontOut = maxOf(f.bodyFrontOut, bodyFrontAtom)
            f.bodyBackOut = maxOf(f.bodyBackOut, bodyBackAtom)
        } catch (_: Throwable) {}

        // Hair
        try {
            v.hairBullet.hairOut = maxOf(v.hairBullet.hairOut, atomOut * 0.8f)
        } catch (_: Throwable) {}

        // ── Protection ──
        
        // Everything previous is atmospheric
        if (allPreviousAtmospheric) {
            try { v.skinAtomspare.enabled = true; v.skinAtomspare.atomSpareOn = true } catch (_: Throwable) {}
            try { v.anatomyShell.enabled = true; v.anatomyShell.atomSpareShellOn = true; v.anatomyShell.insideAtmospheric = true } catch (_: Throwable) {}
            try { v.body84FullHuman.enabled = true; v.body84FullHuman.outsideOn = true; v.body84FullHuman.insideOn = true } catch (_: Throwable) {}
            try { v.bodyAtmo3d.enabled = true } catch (_: Throwable) {}
            try { v.anatomy3d.enabled = true } catch (_: Throwable) {}
            try { v.frontSideAmbient.enabled = true } catch (_: Throwable) {}
            try { v.hairBullet.enabled = true; v.hairBullet.hairOn = true } catch (_: Throwable) {}
            // Center body regions
            try {
                v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, bodyCenterAtom)
                v.skinAbdomen.atmosphere = maxOf(v.skinAbdomen.atmosphere, bodyCenterAtom * 0.95f)
                v.heart.atmosphere = maxOf(v.heart.atmosphere, bodyCenterAtom * 0.9f)
                v.belly.atmosphere = maxOf(v.belly.atmosphere, bodyCenterAtom * 0.9f)
            } catch (_: Throwable) {}
            try {
                v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, bodyUpAtom)
                v.skinLegL.atmosphere = maxOf(v.skinLegL.atmosphere, bodyDownAtom)
                v.skinLegR.atmosphere = maxOf(v.skinLegR.atmosphere, bodyDownAtom)
                v.skinArmL.atmosphere = maxOf(v.skinArmL.atmosphere, bodyLeftAtom)
                v.skinArmR.atmosphere = maxOf(v.skinArmR.atmosphere, bodyRightAtom)
            } catch (_: Throwable) {}
        }

        if (!protectOn) return
        val threat = maxOf(sb.enemyBodyOut, sb.micEnemyOut, sb.bulletOut * 0.5f)
        val p = (protectOut * protectLv).coerceIn(0f, 1f)
        if (enemyCannotBreakOut || threat > 0.02f) {
            val k = (1f - maxOf(p, threat) * 0.96f).coerceIn(0.02f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
            sb.enemyBodyMove *= k
            sb.enemyBodySpeed *= k
            sb.enemyBodyWave *= k
        }
        if (masterShieldOn) sb.enemyMasterShieldOn = true
        if (arShieldOn) sb.arRealityShieldOn = true
        if (isolationOn) {
            try {
                v.bodyIsolation.enabled = true
                v.bodyIsolation.myBodyNoInteract = true
                v.bodyIsolation.enemyTxElsewhere = true
            } catch (_: Throwable) {}
        }
        sb.protectBodyOn = true
        sb.enemyCommBlockOut = maxOf(sb.enemyCommBlockOut, p)
    }
}
