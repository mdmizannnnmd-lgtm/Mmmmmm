package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object PoseSegEyeBodyPanels {
    fun build(ctx: Context, root: LinearLayout, b: PoseSegEyeBodyBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFA5D6A7.toInt()
        p.title("POSE · SEGMENT EYES (groups, not single) + FULL BODY", c)
        p.note("MediaPipe Pose L/R eye inner·center·outer groups · FaceMesh contours+iris · COCO-17 · Seg regions")
        p.switch("Pose·Seg·Eye master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Pose ON (33 + COCO-17)", b.poseOn) { b.poseOn = it }
        p.switch("Segment body regions ON", b.segOn) { b.segOn = it }
        p.switch("FaceMesh eye groups ON", b.faceMeshEyesOn) { b.faceMeshEyesOn = it }
        p.seek("Threshold", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Level", 0f, 1.5f, b.level) { b.level = it }
        val st = p.status("POSE·SEG —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 250) }
        })
    }
}
