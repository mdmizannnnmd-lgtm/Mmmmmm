package com.mizan

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.Switch

/** Panels for the SD-card Sound Bank (+ memory paths + audio focus) and for ONENESS (brain ↔ anatomy ↔ rings ↔ sound). */
object OnenessSdPanels {

    fun buildSd(
        act: Activity,
        root: LinearLayout,
        sd: SdSoundBank,
        bodyFx: BodySoundFx,
        pickFolder: () -> Unit
    ) {
        val p = PanelBuilder(act, root)
        val teal = Color.rgb(0x80, 0xCB, 0xC4)
        val grey = Color.rgb(0xB0, 0xBE, 0xC5)
        p.title("SD CARD · SOUND BANK · AUDIO FOCUS · MEMORY PATHS", teal)
        p.note("Loads the sounds already on your SD card into the app's Sound Bank. Pick the folder once — it is remembered. Also scans Android/data/<app>/files/sounds on every card.")
        p.button("Pick sound folder (SD card / USB / internal)") { pickFolder() }
        p.button("Rescan sounds") { sd.scan() }
        p.button("Use remembered folders…") {
            val list = MemoryPaths.recentTrees()
            if (list.isEmpty()) return@button
            AlertDialog.Builder(act).setTitle("Remembered folders")
                .setItems(list.map { MemoryPaths.shortUri(it) }.toTypedArray()) { _, i ->
                    MemoryPaths.soundTreeUri = list[i]; sd.scan()
                }.show()
        }
        p.button("Forget folder") { MemoryPaths.forgetTree(); sd.scan() }

        p.title("Play", grey)
        p.button("Choose sound…") {
            val names = sd.tracks.map { "${it.name}  ·  ${it.source}" }.toTypedArray()
            if (names.isEmpty()) return@button
            AlertDialog.Builder(act).setTitle("Sounds (${names.size})").setItems(names) { _, i -> sd.play(i) }.show()
        }
        p.button("▶ / ❚❚  play · pause (resumes the last sound)") { sd.togglePause() }
        p.button("⏮ previous") { sd.prev() }
        p.button("⏭ next") { sd.next() }
        p.button("■ stop (abandon audio focus)") { sd.stop() }
        p.switch("Loop track", sd.loop) { sd.setLoopOn(it) }
        p.switch("Shuffle", sd.shuffle) { sd.setShuffleOn(it) }
        p.seek("Volume", 0f, 1f, sd.volume) { sd.setVolumeLevel(it) }

        p.title("Into the Sound Bank", grey)
        p.note("Loud sound → raises Sound Bank focus + model mix, so brain, anatomy and rings move with it. Losing audio focus (call, other app) COLLAPSES the bank; a short loss resumes when focus returns; ducking lowers the volume.")
        val bank = sd.bankRef()
        p.switch("SD sound drives the Sound Bank", bank.sdLinkOn) { bank.sdLinkOn = it; MemoryPaths.putBool("sd_link", it) }
        p.button("Collapse bank now (test)") { sd.collapseBank() }

        p.title("LIVE BODY SOUND FX · CAMERA-GATED", Color.rgb(0xFF, 0xD5, 0x4F))
        p.note(
            "An effect can fire only when the on-device pose + person mask sees the selected body region and the mic level crosses its gate. " +
                "The single phone mic cannot tell which person or body part made a sound: the chosen part is the visual target; playback comes from the phone/headphones."
        )
        p.switch("Body sound effects ON", bodyFx.enabled) { bodyFx.enabled = it }
        p.button("Choose visual body-part target…") {
            AlertDialog.Builder(act)
                .setTitle("Body-part target")
                .setSingleChoiceItems(HumanDetection.PART_NAMES.toTypedArray(), bodyFx.selectedPart) { dialog, which ->
                    bodyFx.selectedPart = which
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        p.button("Choose sound from the scanned SD-card bank…") {
            val names = sd.tracks.map { "${it.name} · ${it.source}" }.toTypedArray()
            if (names.isEmpty()) return@button
            AlertDialog.Builder(act)
                .setTitle("Sound effect track")
                .setSingleChoiceItems(names, bodyFx.selectedTrack.coerceIn(0, names.lastIndex)) { dialog, which ->
                    bodyFx.selectedTrack = which
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        p.switch("RAW audio response (keeps person + part detection gate)", bodyFx.raw) { bodyFx.raw = it }
        p.seek("Person confidence threshold", 0.10f, 0.95f, bodyFx.detectionThreshold) {
            bodyFx.detectionThreshold = it
        }
        p.seek("Selected-part confidence threshold", 0f, 0.95f, bodyFx.partThreshold) {
            bodyFx.partThreshold = it
        }
        p.seek("Mic/audio intensity threshold", 0f, 1f, bodyFx.audioThreshold) {
            bodyFx.audioThreshold = it
        }
        p.seek("Effect level", 0f, 1f, bodyFx.level) { bodyFx.level = it }
        p.seek("Brain intensity contribution", 0f, 1f, bodyFx.brainMix) { bodyFx.brainMix = it }
        p.seek("Trigger cooldown (ms)", 250f, 10_000f, bodyFx.cooldownMs.toFloat(), 0) {
            bodyFx.cooldownMs = it.toInt()
        }
        val fxStatus = p.status("BODY FX —", Color.rgb(0xFF, 0xD5, 0x4F))

        val st = p.status("SD-BANK —", teal)
        val mem = p.status("MEMORY —", grey)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                st.text = sd.statusLine()
                mem.text = MemoryPaths.summary()
                fxStatus.text = bodyFx.statusLine()
                h.postDelayed(this, 250)
            }
        })
    }

    /** Returns the RAW COMPLETE EVERYTHING switch. */
    fun buildOneness(act: Activity, root: LinearLayout, view: VisualShieldView): Switch {
        val o = view.oneness
        val p = PanelBuilder(act, root)
        val gold = Color.rgb(0xFF, 0xD5, 0x4F)
        val grey = Color.rgb(0xB0, 0xBE, 0xC5)

        o.enabled = MemoryPaths.getBool("one_on", o.enabled)
        o.couple = MemoryPaths.getFloat("one_couple", o.couple)
        o.soundLink = MemoryPaths.getBool("one_sound", o.soundLink)
        o.ringsLink = MemoryPaths.getBool("one_rings", o.ringsLink)
        view.brain3d.dockInAnatomy = MemoryPaths.getBool("one_dock", view.brain3d.dockInAnatomy)

        p.title("ONENESS · BRAIN ↔ ANATOMY ↔ RINGS ↔ SOUND — ONE BODY", gold)
        p.note("The brain is not single: it sits inside the 3D anatomy body, its ring balls feed back into both hemispheres, and anatomy, rings and the Sound Bank (incl. SD sound) share one field.")
        p.switch("Oneness ON", o.enabled) { o.enabled = it; MemoryPaths.putBool("one_on", it) }
        p.seek("Coupling (how much of the shared field every part receives)", 0f, 1f, o.couple) {
            o.couple = it; MemoryPaths.putFloat("one_couple", it)
        }
        p.switch("Brain lives inside the anatomy model (hide the separate floating brain)", view.brain3d.dockInAnatomy) {
            view.brain3d.dockInAnatomy = it; MemoryPaths.putBool("one_dock", it)
        }
        p.switch("Rings + balls in the shared field (brain rings ↔ hemispheres)", o.ringsLink) {
            o.ringsLink = it; MemoryPaths.putBool("one_rings", it)
        }
        p.switch("Sound Bank in the shared field", o.soundLink) { o.soundLink = it; MemoryPaths.putBool("one_sound", it) }
        val raw = p.switch("RAW COMPLETE EVERYTHING (brain + anatomy + rings + sound bank, no threshold · gain · rails)", o.rawEverything) {
            o.setRawEverything(view, it)
        }
        buildGame(p, view)
        buildCentroid(p, view)
        buildCentroidSet(p, view)
        buildMotion(p, view)

        val st = p.status("ONENESS —", gold)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                st.text = o.statusLine()
                h.postDelayed(this, 200)
            }
        })
        return raw
    }

    private fun axisControls(p: PanelBuilder, name: String, key: String, ax: BodyMotionHub.Axis, rangeMax: Float, rangeLabel: String) {
        p.title(name, Color.rgb(0xB0, 0xBE, 0xC5))
        ax.on = MemoryPaths.getBool("bm_${key}_on", ax.on)
        ax.thr = MemoryPaths.getFloat("bm_${key}_thr", ax.thr)
        ax.level = MemoryPaths.getFloat("bm_${key}_lv", ax.level)
        ax.range = MemoryPaths.getFloat("bm_${key}_rg", ax.range)
        ax.bipolar = MemoryPaths.getBool("bm_${key}_bip", ax.bipolar)
        p.switch("$name ON", ax.on) { ax.on = it; MemoryPaths.putBool("bm_${key}_on", it) }
        p.seek("Threshold (centre point — at it the body is centred)", 0.02f, 0.98f, ax.thr) { ax.thr = it; MemoryPaths.putFloat("bm_${key}_thr", it) }
        p.seek("Level", 0f, 1f, ax.level) { ax.level = it; MemoryPaths.putFloat("bm_${key}_lv", it) }
        p.seek(rangeLabel, 0f, rangeMax, ax.range, 3) { ax.range = it; MemoryPaths.putFloat("bm_${key}_rg", it) }
        p.switch("Bipolar (above threshold = +, below = −)", ax.bipolar) { ax.bipolar = it; MemoryPaths.putBool("bm_${key}_bip", it) }
        p.seek("Attack (ms)", 1f, 500f, ax.attackMs.toFloat(), 0) { ax.attackMs = it.toInt().coerceAtLeast(1) }
        p.seek("Release (ms)", 1f, 2000f, ax.releaseMs.toFloat(), 0) { ax.releaseMs = it.toInt().coerceAtLeast(1) }
    }

    private fun buildMotion(p: PanelBuilder, view: VisualShieldView) {
        val m = view.bodyMotion
        val gold = Color.rgb(0xFF, 0xD5, 0x4F)
        m.enabled = MemoryPaths.getBool("bm_on", m.enabled)
        m.centerPull = MemoryPaths.getFloat("bm_pull", m.centerPull)
        m.wMotion = MemoryPaths.getFloat("bm_wmot", m.wMotion)
        m.wField = MemoryPaths.getFloat("bm_wfield", m.wField)
        p.title("BODY MOTION · VERTICAL · ROTATION · TILT · CENTRED", gold)
        p.note("Moves the whole body model together (anatomy, brain, face lines, rings + balls). Level · threshold · bipolar per axis; RAW COMPLETE EVERYTHING above makes it raw too.")
        p.switch("Body motion ON", m.enabled) { m.enabled = it; MemoryPaths.putBool("bm_on", it) }
        p.switch("Centred (zero = body centre)", m.centered) { m.centered = it }
        p.seek("Return to centre between moves", 0f, 1f, m.centerPull) { m.centerPull = it; MemoryPaths.putFloat("bm_pull", it) }
        p.seek("Source: device motion weight", 0f, 1f, m.wMotion) { m.wMotion = it; MemoryPaths.putFloat("bm_wmot", it) }
        p.seek("Source: oneness field weight", 0f, 1f, m.wField) { m.wField = it; MemoryPaths.putFloat("bm_wfield", it) }
        p.button("Centre everything now (position · rotation · tilt)") { m.centerAll(view) }
        axisControls(p, "VERTICAL", "v", m.vertical, 0.25f, "Vertical range (fraction of screen height)")
        axisControls(p, "ROTATION", "yaw", m.yaw, 1.6f, "Rotation range (radians)")
        axisControls(p, "TILT", "tilt", m.tilt, 0.8f, "Tilt range (radians)")
        val st = p.status("BODY MOTION —", gold)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                st.text = m.statusLine()
                h.postDelayed(this, 200)
            }
        })
    }

    private fun buildCentroid(p: PanelBuilder, view: VisualShieldView) {
        val c = view.centroid
        val gold = Color.rgb(0xFF, 0xD5, 0x4F)
        c.enabled = MemoryPaths.getBool("cen_on", c.enabled)
        c.level = MemoryPaths.getFloat("cen_lv", c.level)
        c.thr = MemoryPaths.getFloat("cen_thr", c.thr)
        c.followX = MemoryPaths.getFloat("cen_fx", c.followX)
        c.followY = MemoryPaths.getFloat("cen_fy", c.followY)
        c.wRings = MemoryPaths.getFloat("cen_wr", c.wRings)
        c.wBrain = MemoryPaths.getFloat("cen_wb", c.wBrain)
        p.title("CENTROID · CENTRE OF ALL ACTIVE BODY PARTS", gold)
        p.note("Rings, balls and both brain hemispheres vote with their live energy; the weighted centre drives body centring and joins the shared oneness field (ambient · motion · body models · Sound Bank).")
        p.switch("Centroid ON", c.enabled) { c.enabled = it; MemoryPaths.putBool("cen_on", it) }
        p.seek("Centroid level", 0f, 1.5f, c.level) { c.level = it; MemoryPaths.putFloat("cen_lv", it) }
        p.seek("Centroid threshold", 0f, 0.98f, c.thr) { c.thr = it; MemoryPaths.putFloat("cen_thr", it) }
        p.seek("Rings + balls vote weight", 0f, 1f, c.wRings) { c.wRings = it; MemoryPaths.putFloat("cen_wr", it) }
        p.seek("Brain vote weight", 0f, 1f, c.wBrain) { c.wBrain = it; MemoryPaths.putFloat("cen_wb", it) }
        p.seek("Centre the body on the centroid · horizontal", 0f, 1f, c.followX) { c.followX = it; MemoryPaths.putFloat("cen_fx", it) }
        p.seek("Centre the body on the centroid · vertical", 0f, 1f, c.followY) { c.followY = it; MemoryPaths.putFloat("cen_fy", it) }
        p.switch("Centroid RAW COMPLETE (no level · threshold · smoothing)", c.raw) { c.raw = it }
        val st = p.status("CENTROID —", gold)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = c.statusLine(); h.postDelayed(this, 200) }
        })
    }

    private fun buildGame(p: PanelBuilder, view: VisualShieldView) {
        val g = view.gameWorld
        val gold = Color.rgb(0xFF, 0xD5, 0x4F)
        g.enabled = MemoryPaths.getBool("gw_on", g.enabled)
        g.level = MemoryPaths.getFloat("gw_lv", g.level)
        g.thr = MemoryPaths.getFloat("gw_thr", g.thr)
        g.size = MemoryPaths.getFloat("gw_size", g.size)
        g.posY = MemoryPaths.getFloat("gw_py", g.posY)
        g.holdMs = MemoryPaths.getFloat("gw_hold", g.holdMs.toFloat()).toInt()
        p.title("3D GAME WORLD · YOUR BODY + ALL TRACKED NOISE BODIES", gold)
        p.note("A game-style 3D scene (ground grid · orbit camera · radar · energy bars). Camera-body figures follow pose + foreground-mask estimates. A single phone mic cannot localize a person or body part, so audio-only markers are visualizations, not measured source positions. Read-only: nothing in the original app is changed.")
        p.switch("3D game world ON", g.enabled) { g.enabled = it; MemoryPaths.putBool("gw_on", it) }
        p.switch("RAW COMPLETE game world (no threshold · level · hold)", g.raw) { g.raw = it }
        p.switch("Show YOU", g.youOn) { g.youOn = it }
        p.switch("Ground grid", g.gridOn) { g.gridOn = it }
        p.switch("Radar", g.radarOn) { g.radarOn = it }
        p.switch("Name + energy bars", g.labelsOn) { g.labelsOn = it }
        p.switch("Trails", g.trailsOn) { g.trailsOn = it }
        p.seek("Detect threshold", 0f, 0.98f, g.thr) { g.thr = it; MemoryPaths.putFloat("gw_thr", it) }
        p.seek("Level", 0f, 1.5f, g.level) { g.level = it; MemoryPaths.putFloat("gw_lv", it) }
        p.seek("Keep tracking after lost (ms)", 0f, 10000f, g.holdMs.toFloat(), 0) { g.holdMs = it.toInt(); MemoryPaths.putFloat("gw_hold", it) }
        p.seek("Window size", 0.15f, 0.90f, g.size) { g.size = it; MemoryPaths.putFloat("gw_size", it) }
        p.seek("Window vertical position", 0.2f, 0.95f, g.posY) { g.posY = it; MemoryPaths.putFloat("gw_py", it) }
        p.switch("Camera auto orbit", g.camYawAuto) { g.camYawAuto = it }
        p.seek("Camera yaw", -3.1f, 3.1f, g.camYaw) { g.camYaw = it }
        p.seek("Camera pitch", 0.05f, 1.2f, g.camPitch) { g.camPitch = it }
        p.seek("Camera distance", 3f, 12f, g.camDist) { g.camDist = it }
        for (b in g.bodies) p.switch("Track: ${b.label}", b.on) { b.on = it }
        val st = p.status("3D GAME —", gold)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = g.statusLine(); h.postDelayed(this, 200) }
        })
    }

    private fun buildCentroidSet(p: PanelBuilder, view: VisualShieldView) {
        val cs = view.centroids
        val gold = Color.rgb(0xFF, 0xD5, 0x4F)
        cs.enabled = MemoryPaths.getBool("cs_on", cs.enabled)
        cs.useMaster = MemoryPaths.getBool("cs_master", cs.useMaster)
        cs.followX = MemoryPaths.getFloat("cs_fx", cs.followX)
        cs.followY = MemoryPaths.getFloat("cs_fy", cs.followY)
        p.title("MORE CENTROIDS · MODEL · AMBIENT · BODY · MASTER", gold)
        p.note("MODEL = all 84 body channels · AMBIENT = every body region's ambient · BODY = torso / limbs / pelvis by pose + camera person mask + sound · MASTER = the strength-weighted centre of all of them plus the original centroid.")
        p.switch("Centroid set ON", cs.enabled) { cs.enabled = it; MemoryPaths.putBool("cs_on", it) }
        p.switch("MASTER centroid centres every body model (off = original centroid)", cs.useMaster) { cs.useMaster = it; MemoryPaths.putBool("cs_master", it) }
        p.seek("Centre on MASTER · horizontal", 0f, 1f, cs.followX) { cs.followX = it; MemoryPaths.putFloat("cs_fx", it) }
        p.seek("Centre on MASTER · vertical", 0f, 1f, cs.followY) { cs.followY = it; MemoryPaths.putFloat("cs_fy", it) }
        for (c in cs.all) {
            p.title("${c.label} CENTROID", Color.rgb(0xB0, 0xBE, 0xC5))
            c.on = MemoryPaths.getBool("cs_${c.key}_on", c.on)
            c.level = MemoryPaths.getFloat("cs_${c.key}_lv", c.level)
            c.thr = MemoryPaths.getFloat("cs_${c.key}_thr", c.thr)
            p.switch("${c.label} ON", c.on) { c.on = it; MemoryPaths.putBool("cs_${c.key}_on", it) }
            p.seek("${c.label} level", 0f, 1.5f, c.level) { c.level = it; MemoryPaths.putFloat("cs_${c.key}_lv", it) }
            p.seek("${c.label} threshold", 0f, 0.98f, c.thr) { c.thr = it; MemoryPaths.putFloat("cs_${c.key}_thr", it) }
            p.switch("${c.label} RAW COMPLETE", c.raw) { c.raw = it }
        }
        val st = p.status("CENTROIDS —", gold)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = cs.statusLine(); h.postDelayed(this, 200) }
        })
    }
}
