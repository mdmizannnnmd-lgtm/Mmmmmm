package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object EyesHeartBellyCompletePanels {
    fun build(ctx: Context, root: LinearLayout, b: EyesHeartBellyCompleteBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFEF9A9A.toInt()
        p.title("EYES FULL · HEART FULL · BELLY FULL · EXTRA ORGANS", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("EYES (sclera cornea iris pupil lens retina optic lid tear L/R)", c)
        p.switch("Eyes ON", b.eyesOn) { b.eyesOn = it }
        p.seek("Eyes thr", 0.05f, 0.98f, b.eyesThr) { b.eyesThr = it }
        p.seek("Eyes level", 0f, 1.5f, b.eyesLv) { b.eyesLv = it }

        p.title("HEART (atrium ventricle valve rhythm pericardium)", c)
        p.switch("Heart ON", b.heartOn) { b.heartOn = it }
        p.seek("Heart thr", 0.05f, 0.98f, b.heartThr) { b.heartThr = it }
        p.seek("Heart level", 0f, 1.5f, b.heartLv) { b.heartLv = it }

        p.title("BELLY (stomach intestine liver pancreas spleen gallbladder)", c)
        p.switch("Belly ON", b.bellyOn) { b.bellyOn = it }
        p.seek("Belly thr", 0.05f, 0.98f, b.bellyThr) { b.bellyThr = it }
        p.seek("Belly level", 0f, 1.5f, b.bellyLv) { b.bellyLv = it }

        p.title("EXTRA (lungs kidneys bladder lymph thyroid adrenal)", c)
        p.switch("Extra organs ON", b.extraOn) { b.extraOn = it }

        val st = p.status("EYES·HEART·BELLY —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
