package com.mizan

/** Deterministic, conservative behavior state derived from perception; no autonomous external actions. */
class PerceptionBehaviorController(
    private val attentionThreshold: Float = 0.55f,
    private val activityThreshold: Float = 0.30f,
    private val holdMs: Long = 900L
) {
    enum class Mode { IDLE, ATTENDING, AUDIO_REACTIVE, TRACKING }
    data class State(val mode: Mode = Mode.IDLE, val sinceMs: Long = 0L, val targetX: Float = 0.5f, val targetY: Float = 0.5f)
    @Volatile private var state = State()
    fun current(): State = state
    @Synchronized fun update(p: UnifiedPerceptionEngine.Snapshot, nowMs: Long = System.currentTimeMillis()): State {
        val next = when {
            p.personPresent && p.attention >= attentionThreshold -> Mode.TRACKING
            p.audioActive && p.activity >= activityThreshold -> Mode.AUDIO_REACTIVE
            p.personPresent -> Mode.ATTENDING
            else -> Mode.IDLE
        }
        val chosen = if (next == Mode.IDLE && nowMs - state.sinceMs < holdMs && state.mode != Mode.IDLE) state.mode else next
        state = State(chosen, if (chosen != state.mode) nowMs else state.sinceMs,
            if (p.personPresent) p.centerX else 0.5f, if (p.personPresent) p.centerY else 0.5f)
        return state
    }
    fun reset(nowMs: Long = System.currentTimeMillis()) { state = State(sinceMs=nowMs) }
}
