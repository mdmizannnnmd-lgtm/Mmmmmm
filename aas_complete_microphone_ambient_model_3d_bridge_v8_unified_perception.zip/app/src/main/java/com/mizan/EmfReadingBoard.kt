package com.mizan

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Real magnetometer EMF-style reading board (µT).
 * Not a calibrated RF meter — phone TYPE_MAGNETIC_FIELD only.
 * No simulation path: values come only from [GameSensorsHub] live samples.
 * Tracks magnitude, delta, baseline, peak; RAW = unfiltered magnitude energy.
 */
class EmfReadingBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true

    /** Live readings (µT) — filled from real sensor only */
    @Volatile var xUt = 0f
    @Volatile var yUt = 0f
    @Volatile var zUt = 0f
    @Volatile var magnitudeUt = 0f
    @Volatile var deltaUt = 0f
    @Volatile var baselineUt = 0f
    @Volatile var peakUt = 0f
    @Volatile var sampleCount = 0L

    /** Tracking thresholds (µT) */
    @Volatile var trackOn = true
    @Volatile var trackThrUt = 5f
    @Volatile var trackActive = false
    @Volatile var trackOut = 0f

    /** Energy 0..1 for 3D game / mixer (from real delta or magnitude) */
    @Volatile var energy = 0f
    @Volatile var gain = 1.0f
    @Volatile var active = false

    // Ambient threshold (EMF ambient rail)
    @Volatile var ambientOn = true
    @Volatile var ambientThr = 0.30f
    @Volatile var ambientLv = 0.60f
    @Volatile var ambientActive = false
    @Volatile var ambientOut = 0f

    // Centroid of recent |Δ| history (tracking board)
    @Volatile var centroidOn = true
    @Volatile var centroidThr = 0.25f
    @Volatile var centroidUt = 0f
    @Volatile var centroidNorm = 0f
    @Volatile var centroidActive = false

    // Spike
    @Volatile var spikeOn = true
    @Volatile var spikeThr = 0.50f
    @Volatile var spikeLv = 0.70f
    @Volatile var spikeThrUt = 12f
    @Volatile var spikeActive = false
    @Volatile var spikeOut = 0f


    /** History ring for tracking board (last N deltas) */
    private val hist = FloatArray(48)
    private var histIdx = 0
    @Volatile var histFilled = 0

    /**
     * Feed real magnetometer sample from [GameSensorsHub].
     * Call only with hardware values — never synthetic.
     */
    fun feedReal(
        mx: Float, my: Float, mz: Float,
        magnitude: Float, delta: Float,
        sensorActive: Boolean
    ) {
        if (!enabled || !sensorActive) {
            active = false
            if (!rawComplete) {
                energy = 0f
                trackActive = false
                trackOut = 0f
            }
            return
        }
        xUt = mx; yUt = my; zUt = mz
        magnitudeUt = magnitude
        deltaUt = delta
        sampleCount++
        if (baselineUt <= 0.01f) baselineUt = magnitude
        else baselineUt = baselineUt * 0.995f + magnitude * 0.005f
        if (magnitude > peakUt) peakUt = magnitude

        hist[histIdx] = abs(delta)
        histIdx = (histIdx + 1) % hist.size
        if (histFilled < hist.size) histFilled++

        val g = gain.coerceIn(0.1f, 5f)
        if (rawComplete) {
            val norm = (magnitude / 100f).coerceIn(0f, 1f) * g
            energy = norm.coerceIn(0f, 1f)
            trackActive = true
            trackOut = energy
            ambientActive = true
            ambientOut = energy * ambientLv.coerceIn(0f, 1f)
            centroidUt = abs(delta)
            centroidNorm = energy
            centroidActive = true
            spikeActive = true
            spikeOut = energy * spikeLv.coerceIn(0f, 1f)
            active = energy > 0.01f
            return
        }

        val thr = trackThrUt.coerceIn(0.5f, 200f)
        trackActive = trackOn && abs(delta) >= thr
        trackOut = if (trackActive) {
            ((abs(delta) - thr) / (thr * 3f + 1f)).coerceIn(0f, 1f) * g
        } else 0f
        // energy from delta primarily (change detects local field events)
        val dNorm = (abs(delta) / 50f).coerceIn(0f, 1f)
        val mNorm = (abs(magnitude - baselineUt) / 80f).coerceIn(0f, 1f)
        energy = (maxOf(dNorm, mNorm * 0.6f, trackOut) * g).coerceIn(0f, 1f)

        // Ambient
        ambientActive = ambientOn && energy >= ambientThr.coerceIn(0.05f, 1f)
        ambientOut = if (ambientActive) {
            val t0 = ambientThr.coerceIn(0.05f, 1f)
            (((energy - t0) / (1f - t0).coerceAtLeast(0.05f)) * ambientLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        // Centroid of history
        var sum = 0f
        val n = histFilled.coerceAtMost(hist.size).coerceAtLeast(1)
        for (i in 0 until n) sum += hist[i]
        centroidUt = sum / n
        centroidNorm = (centroidUt / 40f).coerceIn(0f, 1f)
        centroidActive = centroidOn && centroidNorm >= centroidThr.coerceIn(0.05f, 1f)

        // Spike (µT thr or energy thr)
        val spikeHit = abs(delta) >= spikeThrUt.coerceIn(1f, 200f) || energy >= spikeThr.coerceIn(0.05f, 1f)
        spikeActive = spikeOn && spikeHit
        spikeOut = if (spikeActive) {
            val depth = maxOf(
                ((abs(delta) - spikeThrUt) / (spikeThrUt * 2f + 1f)).coerceIn(0f, 1f),
                ((energy - spikeThr) / (1f - spikeThr).coerceAtLeast(0.05f)).coerceIn(0f, 1f)
            )
            (depth * spikeLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f

        energy = maxOf(energy, ambientOut * 0.5f, if (centroidActive) centroidNorm * 0.4f else 0f, spikeOut * 0.7f)
        active = energy > 0.02f
    }

    fun historyPeak(): Float {
        var p = 0f
        val n = histFilled.coerceAtMost(hist.size)
        for (i in 0 until n) if (hist[i] > p) p = hist[i]
        return p
    }

    fun statusLine(): String {
        if (!enabled) return "EMF-READ off"
        val tag = when {
            !active && sampleCount == 0L -> "NO-SENSOR"
            rawComplete -> "RAW"
            trackActive -> "TRACK"
            else -> "idle"
        }
        return "EMF-READ $tag · |B|=${"%.1f".format(magnitudeUt)}µT Δ=${"%.2f".format(deltaUt)}µT " +
            "base=${"%.1f".format(baselineUt)} peak=${"%.1f".format(peakUt)} · " +
            "E=${(energy * 100).toInt()}% amb=${(ambientOut * 100).toInt()}% cen=${(centroidNorm * 100).toInt()}% spk=${(spikeOut * 100).toInt()}% n=$sampleCount"
    }
}
