package com.mizan

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sqrt

/**
 * Optional, on-device inputs for the 3D game.
 *
 * GPS is started only after the user enables the game GPS switch and grants
 * location permission. Coordinates are reduced to a temporary offset from the
 * first accepted fix; raw coordinates are neither persisted nor transmitted.
 * The magnetic sensor reports magnetic flux density in µT. It is not an RF or
 * calibrated EMF meter.
 */
class GameSensorsHub(context: Context) : SensorEventListener, LocationListener, AutoCloseable {

    private val appContext = context.applicationContext
    private val sensorManager =
        appContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val locationManager =
        appContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val magneticSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    @Volatile var magneticRequested = false
        private set
    @Volatile var magneticActive = false
        private set
    val magneticAvailable: Boolean get() = magneticSensor != null

    @Volatile var magneticXUt = 0f
        private set
    @Volatile var magneticYUt = 0f
        private set
    @Volatile var magneticZUt = 0f
        private set
    @Volatile var magneticMagnitudeUt = 0f
        private set
    @Volatile var magneticDeltaUt = 0f
        private set

    @Volatile var locationOptIn = false
        private set
    @Volatile var gpsActive = false
        private set
    @Volatile var hasLocationFix = false
        private set
    @Volatile var eastMeters = 0f
        private set
    @Volatile var northMeters = 0f
        private set
    @Volatile var distanceFromStartMeters = 0f
        private set
    @Volatile var locationAccuracyMeters = 0f
        private set
    @Volatile var gpsSequence = 0L
        private set
    @Volatile var maxGpsAccuracyMeters = 50f
    @Volatile var status = "MAG off · GPS off"
        private set

    private var resumed = false
    private var requestedProvider: String? = null
    private var originLatitude: Double? = null
    private var originLongitude: Double? = null
    private var magneticBaselineUt = Float.NaN
    private var gpsStatusLine = "GPS off"

    fun setMagneticEnabled(enabled: Boolean) {
        magneticRequested = enabled
        if (!enabled) {
            if (magneticActive) sensorManager.unregisterListener(this, magneticSensor)
            magneticActive = false
            magneticXUt = 0f
            magneticYUt = 0f
            magneticZUt = 0f
            magneticMagnitudeUt = 0f
            magneticDeltaUt = 0f
            magneticBaselineUt = Float.NaN
        } else if (resumed) {
            startMagnetometer()
        }
        updateStatus()
    }

    /**
     * Enables foreground location updates. Call only after the UI has obtained
     * coarse or fine location permission from the user.
     */
    fun enableLocation(): String {
        locationOptIn = true
        if (!hasLocationPermission()) {
            locationOptIn = false
            gpsStatusLine = "GPS off · location permission not granted"
            updateStatus()
            return status
        }
        if (resumed) startLocationUpdates()
        else gpsStatusLine = "GPS waiting · foreground only"
        updateStatus()
        return status
    }

    fun disableLocation() {
        locationOptIn = false
        stopLocationUpdates()
        originLatitude = null
        originLongitude = null
        hasLocationFix = false
        eastMeters = 0f
        northMeters = 0f
        distanceFromStartMeters = 0f
        locationAccuracyMeters = 0f
        gpsSequence++
        gpsStatusLine = "GPS off"
        updateStatus()
    }

    fun resumeSensors() {
        resumed = true
        if (magneticRequested) startMagnetometer()
        if (locationOptIn) startLocationUpdates()
    }

    fun pauseSensors() {
        resumed = false
        if (magneticActive) sensorManager.unregisterListener(this, magneticSensor)
        magneticActive = false
        stopLocationUpdates()
        if (locationOptIn) gpsStatusLine = "GPS paused · resumes in foreground"
        updateStatus()
    }

    private fun startMagnetometer() {
        val sensor = magneticSensor
        if (!resumed || !magneticRequested || sensor == null || magneticActive) return
        magneticActive = sensorManager.registerListener(
            this,
            sensor,
            SensorManager.SENSOR_DELAY_GAME
        )
    }

    private fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            appContext,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            appContext,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    private fun startLocationUpdates() {
        if (!resumed || !locationOptIn || gpsActive) return
        if (!hasLocationPermission()) {
            gpsStatusLine = "GPS paused · location permission unavailable"
            updateStatus()
            return
        }

        val fine = ContextCompat.checkSelfPermission(
            appContext,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val provider = try {
            when {
                fine && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ->
                    LocationManager.GPS_PROVIDER
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ->
                    LocationManager.NETWORK_PROVIDER
                fine -> LocationManager.GPS_PROVIDER
                else -> null
            }
        } catch (_: Exception) {
            null
        }

        if (provider == null) {
            gpsStatusLine = "GPS unavailable · enable a location provider"
            updateStatus()
            return
        }

        try {
            locationManager.requestLocationUpdates(
                provider,
                1000L,
                1f,
                this,
                Looper.getMainLooper()
            )
            requestedProvider = provider
            gpsActive = true
            gpsStatusLine = "GPS starting · waiting for an accurate fix · device only"
        } catch (_: SecurityException) {
            gpsActive = false
            gpsStatusLine = "GPS paused · location permission unavailable"
        } catch (e: Exception) {
            gpsActive = false
            gpsStatusLine = "GPS unavailable · ${e.message ?: "provider error"}"
        }
        updateStatus()
    }

    private fun stopLocationUpdates() {
        try {
            locationManager.removeUpdates(this)
        } catch (_: Exception) {
        }
        requestedProvider = null
        gpsActive = false
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_MAGNETIC_FIELD ||
            !magneticRequested || event.values.size < 3
        ) return

        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        val magnitude = sqrt(x * x + y * y + z * z)
        magneticXUt = x
        magneticYUt = y
        magneticZUt = z
        magneticMagnitudeUt = magnitude

        if (magneticBaselineUt.isNaN()) {
            magneticBaselineUt = magnitude
        } else {
            magneticDeltaUt = abs(magnitude - magneticBaselineUt)
            // Slowly follow ordinary drift; abrupt changes remain visible.
            if (magneticDeltaUt < 2f) {
                magneticBaselineUt = magneticBaselineUt * 0.98f + magnitude * 0.02f
            }
        }
        updateStatus()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onLocationChanged(location: Location) {
        if (!locationOptIn || !gpsActive) return
        val accuracy = if (location.hasAccuracy()) location.accuracy else Float.MAX_VALUE
        locationAccuracyMeters = accuracy
        if (accuracy > maxGpsAccuracyMeters.coerceAtLeast(1f)) {
            gpsStatusLine = "GPS waiting · accuracy ${accuracy.toInt()}m exceeds ${maxGpsAccuracyMeters.toInt()}m · local only"
            updateStatus()
            return
        }

        val originLat = originLatitude
        val originLon = originLongitude
        if (originLat == null || originLon == null) {
            originLatitude = location.latitude
            originLongitude = location.longitude
            eastMeters = 0f
            northMeters = 0f
        } else {
            val latRadians = Math.toRadians(originLat)
            eastMeters = ((location.longitude - originLon) *
                111_320.0 * cos(latRadians)).toFloat()
            northMeters = ((location.latitude - originLat) * 111_132.0).toFloat()
        }
        distanceFromStartMeters = sqrt(eastMeters * eastMeters + northMeters * northMeters)
        hasLocationFix = true
        gpsSequence++
        gpsStatusLine = "GPS own path ${"%.1f".format(distanceFromStartMeters)}m · ±${accuracy.toInt()}m · local only"
        updateStatus()
    }

    @Suppress("DEPRECATION")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    override fun onProviderEnabled(provider: String) {
        if (locationOptIn && resumed) startLocationUpdates()
    }

    override fun onProviderDisabled(provider: String) {
        if (provider == requestedProvider) {
            stopLocationUpdates()
            gpsStatusLine = "GPS paused · location provider disabled"
            updateStatus()
        }
    }

    private fun updateStatus() {
        val magText = when {
            !magneticRequested && !magneticAvailable -> "MAG unavailable on this phone"
            !magneticRequested -> "MAG off"
            !magneticAvailable -> "MAG unavailable on this phone"
            !magneticActive -> "MAG paused"
            else -> "MAG ${"%.1f".format(magneticMagnitudeUt)}µT · Δ${"%.1f".format(magneticDeltaUt)}µT"
        }
        val gpsText = if (!locationOptIn) "GPS off" else gpsStatusLine
        status = "$magText · $gpsText"
    }

    override fun close() {
        locationOptIn = false
        magneticRequested = false
        pauseSensors()
    }
}
