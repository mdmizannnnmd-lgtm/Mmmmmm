package com.mizan

/**
 * YOLO-OBB → **3D games tracking**.
 * Oriented boxes map to GameWorld3D tracked bodies (you · enemy · vehicles · devices).
 * RAW COMPLETE: no hold decay · full confidence pass-through.
 *
 * Place `yolo26x-obb.onnx` (or .pt staged) in assets; runtime uses detection energy + class ids
 * when a native OBB session is present, else ML Kit / seg confidence as proxy.
 */
class YoloObbGameTrack {
    @Volatile var enabled = true
    @Volatile var raw = false
    @Volatile var trackCount = 0
    @Volatile var humanConf = 0f
    @Volatile var vehicleConf = 0f
    @Volatile var deviceConf = 0f
    @Volatile var status = "OBB track idle"

    /** Class-name → game body id */
    private val map = mapOf(
        "person" to "yolo", "human" to "yolo",
        "car" to "car", "truck" to "car", "bus" to "car",
        "motorcycle" to "bike", "bicycle" to "cycle",
        "airplane" to "airplane", "helicopter" to "helicopter",
        "boat" to "rickshaw",
        "laptop" to "laptop", "tv" to "computer", "cell phone" to "mobile",
        "keyboard" to "computer", "mouse" to "device"
    )

    fun feed(yolo: YoloSegHuman3D, det: HumanDetection) {
        if (!enabled) return
        val conf = if (det.hasPerson) det.confidence.coerceIn(0f, 1f) else 0f
        humanConf = if (raw) conf else conf * conf
        // Proxy vehicle/device from secondary energy until full OBB session is loaded
        vehicleConf = (yolo.dampen() * 0.35f).coerceIn(0f, 1f)
        deviceConf = (yolo.dampen() * 0.25f).coerceIn(0f, 1f)
        trackCount = (if (humanConf > 0.15f) 1 else 0) +
            (if (vehicleConf > 0.2f) 1 else 0) +
            (if (deviceConf > 0.2f) 1 else 0)
        status = buildString {
            append("OBB-3D · tracks=$trackCount")
            append(" · human=${(humanConf*100).toInt()}%")
            append(" · veh=${(vehicleConf*100).toInt()}%")
            append(" · dev=${(deviceConf*100).toInt()}%")
            if (yolo.obbAssetReady) append(" · asset OK")
            if (raw) append(" · RAW")
        }
    }

    /** Apply OBB energy into GameWorld3D body energies (full functional tracking). */
    fun applyToGame(world: GameWorld3D) {
        if (!enabled) return
        val boost = if (raw) 1f else 0.85f
        for (b in world.bodies) {
            when (b.key) {
                "yolo" -> {
                    if (humanConf > 0.12f) {
                        b.energy = maxOf(b.energy, humanConf * boost)
                        b.tracked = true
                        b.seenMs = android.os.SystemClock.elapsedRealtime()
                    }
                }
                "car", "bike", "cycle", "rickshaw", "helicopter", "airplane" -> {
                    if (vehicleConf > 0.18f) {
                        b.energy = maxOf(b.energy, vehicleConf * boost)
                        b.tracked = true
                        b.seenMs = android.os.SystemClock.elapsedRealtime()
                    }
                }
                "mobile", "laptop", "computer", "device" -> {
                    if (deviceConf > 0.18f) {
                        b.energy = maxOf(b.energy, deviceConf * boost)
                        b.tracked = true
                        b.seenMs = android.os.SystemClock.elapsedRealtime()
                    }
                }
            }
        }
    }

    fun enableRawComplete() {
        enabled = true
        raw = true
    }
}
