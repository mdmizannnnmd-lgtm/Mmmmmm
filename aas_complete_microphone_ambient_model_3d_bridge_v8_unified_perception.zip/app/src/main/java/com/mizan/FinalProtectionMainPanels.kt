package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

/** All 26 Final Protection sections on main page — same PanelBuilder style. */
object FinalProtectionMainPanels {
    fun build(ctx: Context, root: LinearLayout, b: FinalProtectionMainBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFCE93D8.toInt()
        p.title("FINAL PROTECTION · 26 SECTIONS · MAIN PAGE · LIVE ENGINE", c)
        p.note("XML: 26 includes · ~758 switches · ~1082 seeks mapped as section masters. Anatomy 11 systems on Full Anatomy 132 panel. Live SoundBank.")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Final master ON", b.masterOn) { b.masterOn = it }
        p.seek("Shared thr", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Shared level", 0f, 1.5f, b.lv) { b.lv = it }

        p.title("1 · MAIN PROTECTION", c)
        p.switch("Main protection", b.mainProtOn) { b.mainProtOn = it }
        p.switch("Counter system", b.counterSysOn) { b.counterSysOn = it }
        p.switch("Auto safe", b.autoSafeOn) { b.autoSafeOn = it }
        p.switch("Event log", b.eventLogOn) { b.eventLogOn = it }
        p.switch("Audio / beat / spectrum", b.audioProtOn) { b.audioProtOn = it; b.beatProtOn = it; b.spectrumProtOn = it }
        p.title("MICROPHONE PROTECTION (FINAL)", 0xFF29B6F6.toInt())
        p.switch("Mic live prot", b.micLiveProtOn) { b.micLiveProtOn = it }
        p.switch("Mic enemy prot", b.micEnemyProtOn) { b.micEnemyProtOn = it }
        p.switch("Mic axis prot", b.micAxisProtOn) { b.micAxisProtOn = it }
        p.switch("Mic stereo L/R", b.micStereoProtOn) { b.micStereoProtOn = it }
        p.switch("Mic gate prot", b.micGateProtOn) { b.micGateProtOn = it }
        p.switch("Mic focus prot", b.micFocusProtOn) { b.micFocusProtOn = it }
        p.seek("Mic thr", 0.05f, 0.9f, b.micThr) { b.micThr = it }
        p.seek("Mic level", 0.2f, 1.5f, b.micLv) { b.micLv = it }

        p.title("FULL MICROPHONE SYSTEM (FINAL)", 0xFF0288D1.toInt())
        p.note("Echo cancel · noise reduce · mono/stereo · gain/amp · bipolar ± · axis XYZ · record amp")
        p.switch("Echo cancel", b.micEchoCancelOn) { b.micEchoCancelOn = it }
        p.switch("Noise reduce", b.micNoiseReduceOn) { b.micNoiseReduceOn = it }
        p.switch("Mic mono", b.micMonoOn) { b.micMonoOn = it }
        p.switch("Mic stereo mode", b.micStereoModeOn) { b.micStereoModeOn = it }
        p.switch("Mic bipolar ±", b.micBipolarOn) { b.micBipolarOn = it }
        p.switch("Mic axis X", b.micAxisXOn) { b.micAxisXOn = it }
        p.switch("Mic axis Y", b.micAxisYOn) { b.micAxisYOn = it }
        p.switch("Mic axis Z", b.micAxisZOn) { b.micAxisZOn = it }
        p.switch("Record amplify", b.micRecordAmpOn) { b.micRecordAmpOn = it }
        p.seek("Mic gain", 0.1f, 2f, b.micGain) { b.micGain = it }
        p.seek("Mic amp gain", 0.1f, 3f, b.micAmpGain) { b.micAmpGain = it }
        p.seek("Bipolar -dB", 0f, 120f, b.micBipNeg) { b.micBipNeg = it }
        p.seek("Bipolar +dB", 0f, 120f, b.micBipPos) { b.micBipPos = it }

        p.switch("Visual / particle / shader", b.visualProtOn) { b.visualProtOn = it; b.particleProtOn = it; b.shaderProtOn = it }
        p.switch("Camera / face / DSP", b.cameraProtOn) { b.cameraProtOn = it; b.faceProtOn = it; b.dspProtOn = it }
        p.switch("Spike protect", b.spikeProtOn) { b.spikeProtOn = it }
        p.switch("Speed / spare / 3D shield", b.speedProtOn) { b.speedProtOn = it; b.spareProtOn = it; b.shield3dOn = it }

        p.title("2 · AMBIENT LIVE BOARD", c)
        p.switch("Amb live board", b.ambLiveOn) { b.ambLiveOn = it }
        p.switch("Userspace", b.ambLiveUserspace) { b.ambLiveUserspace = it }
        p.switch("Enemy TX blocker", b.ambLiveEnemyTxBlock) { b.ambLiveEnemyTxBlock = it }

        p.title("3 · AMBIENT THRESHOLD BOARD", c)
        p.switch("Amb thr board", b.ambThrOn) { b.ambThrOn = it }
        p.switch("Lock live amb thr", b.ambThrLock) { b.ambThrLock = it }
        p.seek("Amb thr", 0.05f, 0.98f, b.ambThr) { b.ambThr = it }
        p.seek("Amb level", 0f, 1.5f, b.ambLv) { b.ambLv = it }

        p.title("4 · ATOMSPARE WEAPONS", c)
        p.switch("AS weapons", b.asWeaponsOn) { b.asWeaponsOn = it }
        p.switch("Sound / vibe / pitch / spike", b.asSoundOn) {
            b.asSoundOn = it; b.asVibeOn = it; b.asPitchOn = it; b.asSpikeOn = it
        }
        p.switch("Mirror", b.asMirrorOn) { b.asMirrorOn = it }

        p.title("5 · 3D BODY DIAGRAM", c)
        p.switch("3D body diagram", b.body3dOn) { b.body3dOn = it }
        p.switch("Pose / Seg / OBB / AtomSpare diag", b.poseDiagOn) {
            b.poseDiagOn = it; b.segDiagOn = it; b.obbDiagOn = it; b.atomDiagOn = it
        }
        p.switch("Auto-rotate", b.autoRotateOn) { b.autoRotateOn = it }

        p.title("6 · 84-CHANNEL PATH", c)
        p.switch("84-channel master", b.body84On) { b.body84On = it }

        p.title("84-CHANNEL FULL FIELDS", 0xFF7E57C2.toInt())
        p.note("AtomSpare 3D · move/speed/wave thr+lv · intention · vis brain · bulk ambient/bip · rescan")
        p.switch("84 virtual focus", b.body84VirtualFocusOn) { b.body84VirtualFocusOn = it }
        p.switch("84 human comm", b.body84HumanCommOn) { b.body84HumanCommOn = it }
        p.switch("84 vis brain", b.body84VisBrainOn) { b.body84VisBrainOn = it }
        p.switch("84 rescan", b.body84RescanOn) { b.body84RescanOn = it }
        p.seek("84 AS thr", 0.05f, 0.9f, b.body84AsThr) { b.body84AsThr = it }
        p.seek("84 AS spike thr", 0.05f, 0.9f, b.body84AsSpikeThr) { b.body84AsSpikeThr = it }
        p.seek("84 AS 3D thr", 0.05f, 0.9f, b.body84As3dThr) { b.body84As3dThr = it }
        p.seek("84 move 3D thr", 0.05f, 0.9f, b.body84Move3dThr) { b.body84Move3dThr = it }
        p.seek("84 move 3D lv", 0.1f, 1.5f, b.body84Move3dLv) { b.body84Move3dLv = it }
        p.seek("84 speed 3D thr", 0.05f, 0.9f, b.body84Speed3dThr) { b.body84Speed3dThr = it }
        p.seek("84 speed 3D lv", 0.1f, 1.5f, b.body84Speed3dLv) { b.body84Speed3dLv = it }
        p.seek("84 wave 3D thr", 0.05f, 0.9f, b.body84Wave3dThr) { b.body84Wave3dThr = it }
        p.seek("84 wave 3D lv", 0.1f, 1.5f, b.body84Wave3dLv) { b.body84Wave3dLv = it }
        p.seek("84 intent thr", 0.05f, 0.9f, b.body84IntentThr) { b.body84IntentThr = it }
        p.seek("84 intent lv", 0.1f, 1.5f, b.body84IntentLv) { b.body84IntentLv = it }
        p.seek("84 vis brain thr", 0.05f, 0.9f, b.body84VisBrainThr) { b.body84VisBrainThr = it }
        p.seek("84 atom thr", 0.05f, 0.9f, b.body84AtomThr) { b.body84AtomThr = it }
        p.seek("84 atom lv", 0.1f, 1.5f, b.body84AtomLv) { b.body84AtomLv = it }
        p.seek("84 bulk ambient", 0f, 1f, b.body84BulkAmbient) { b.body84BulkAmbient = it }
        p.seek("84 bulk thr", 0.05f, 0.9f, b.body84BulkThr) { b.body84BulkThr = it }
        p.seek("84 bip -dB", -120f, 0f, b.body84BipNeg) { b.body84BipNeg = it }
        p.seek("84 bip +dB", 0f, 120f, b.body84BipPos) { b.body84BipPos = it }

        p.switch("GPS / nature / motion / intention", b.body84GpsOn) {
            b.body84GpsOn = it; b.body84NatureOn = it; b.body84MotionOn = it; b.body84IntentOn = it
        }

        p.title("7–9 · BODY L/R · PARTS · SIDES", c)
        p.switch("Body L/R channels", b.bodyLrOn) { b.bodyLrOn = it }
        p.switch("L / R / Front / Back", b.bodyLOn) {
            b.bodyLOn = it; b.bodyROn = it; b.bodyFrontOn = it; b.bodyBackOn = it
        }
        p.switch("Body parts channels", b.bodyPartsOn) { b.bodyPartsOn = it }
        p.switch("Body sides + L/R brain", b.bodySidesOn) {
            b.bodySidesOn = it; b.brainLOn = it; b.brainROn = it
        }

        p.title("10–14 · BRAIN · EYES · L/R", c)
        p.switch("Brain anatomy (cortex…ventricles)", b.brainAnatOn) {
            b.brainAnatOn = it; b.cortexOn = it; b.limbicOn = it; b.basalOn = it
            b.diencephOn = it; b.brainstemOn = it; b.cerebellumOn = it
            b.whiteMatterOn = it; b.ventriclesOn = it
        }
        p.switch("Eyes + brain visual", b.eyeBrainVisOn) {
            b.eyeBrainVisOn = it; b.eyeVisLOn = it; b.eyeVisROn = it; b.brainVisOn = it
        }
        p.switch("Eye channels + colour", b.eyeChOn) { b.eyeChOn = it; b.eyeColourOn = it }
        p.switch("L/R eyes ambient + lines + optic", b.lrEyesOn) {
            b.lrEyesOn = it; b.eyeLinesOn = it; b.opticNerveOn = it
        }
        p.switch("L/R brain full", b.lrBrainOn) { b.lrBrainOn = it }

        p.title("15–19 · FACE · GLAND · HEART · WHOLE · ALL ANAT", c)
        p.switch("Face neck skin", b.faceNeckSkinOn) { b.faceNeckSkinOn = it }
        p.switch("Gland/CNS (hypo thyroid thymus CNS)", b.glandCnsOn) {
            b.glandCnsOn = it; b.hypoOn = it; b.thyroidOn = it; b.paraThyOn = it
            b.thymusOn = it; b.cnsOn = it
        }
        p.switch("Heart + neck", b.heartNeckOn) { b.heartNeckOn = it }
        p.switch("Whole-body anatomy", b.wholeBodyOn) { b.wholeBodyOn = it }
        p.switch("All anatomy ambient", b.allAnatAmbOn) { b.allAnatAmbOn = it }

        
        p.title("EYES ANATOMY AMBIENT FULL", 0xFF42A5F5.toInt())
        p.note("L/R · optical (cornea/lens/retina/optic/pupil/iris) · vision bright/contrast · move · pitch")
        p.switch("Eye L", b.eyeLOn) { b.eyeLOn = it }
        p.switch("Eye R", b.eyeROn) { b.eyeROn = it }
        p.switch("Optical path", b.eyeOpticalOn) { b.eyeOpticalOn = it }
        p.switch("Cornea", b.eyeCorneaOn) { b.eyeCorneaOn = it }
        p.switch("Lens", b.eyeLensOn) { b.eyeLensOn = it }
        p.switch("Retina", b.eyeRetinaOn) { b.eyeRetinaOn = it }
        p.switch("Pupil", b.eyePupilOn) { b.eyePupilOn = it }
        p.switch("Iris", b.eyeIrisOn) { b.eyeIrisOn = it }
        p.switch("Eye move", b.eyeMoveOn) { b.eyeMoveOn = it }
        p.switch("Eye pitch prot", b.eyePitchProtOn) { b.eyePitchProtOn = it }
        p.seek("Eye L thr", 0.05f, 0.9f, b.eyeLThr) { b.eyeLThr = it }
        p.seek("Eye L lv", 0.2f, 1.5f, b.eyeLLv) { b.eyeLLv = it }
        p.seek("Eye R thr", 0.05f, 0.9f, b.eyeRThr) { b.eyeRThr = it }
        p.seek("Eye R lv", 0.2f, 1.5f, b.eyeRLv) { b.eyeRLv = it }
        p.seek("Eye shared thr", 0.05f, 0.9f, b.eyeSharedThr) { b.eyeSharedThr = it }
        p.seek("Eye move thr", 0.05f, 0.9f, b.eyeMoveThr) { b.eyeMoveThr = it }
        p.seek("Eye move lv", 0.1f, 1.5f, b.eyeMoveLv) { b.eyeMoveLv = it }
        p.seek("Bright L", 0f, 1f, b.eyeBrightL) { b.eyeBrightL = it }
        p.seek("Contrast L", 0f, 1f, b.eyeContrastL) { b.eyeContrastL = it }
        p.seek("Bright R", 0f, 1f, b.eyeBrightR) { b.eyeBrightR = it }
        p.seek("Contrast R", 0f, 1f, b.eyeContrastR) { b.eyeContrastR = it }
        p.seek("Colour thr", 0.05f, 0.9f, b.eyeColThr) { b.eyeColThr = it }
        p.seek("Eye bip -dB", -120f, 0f, b.eyeBipNeg) { b.eyeBipNeg = it }
        p.seek("Eye bip +dB", 0f, 120f, b.eyeBipPos) { b.eyeBipPos = it }

        p.title("EYE-SKIN + SKIN ANATOMY AMBIENT", 0xFFFF8A65.toInt())
        p.note("Eye skin L/R · lid/brow · epidermis/dermis/hypodermis · face/head/neck · mic live drive")
        p.switch("Eye skin", b.eyeSkinOn) { b.eyeSkinOn = it }
        p.switch("Eye skin L", b.eyeSkinLOn) { b.eyeSkinLOn = it }
        p.switch("Eye skin R", b.eyeSkinROn) { b.eyeSkinROn = it }
        p.switch("Eyelid skin", b.eyeLidSkinOn) { b.eyeLidSkinOn = it }
        p.switch("Eyebrow skin", b.eyeBrowSkinOn) { b.eyeBrowSkinOn = it }
        p.switch("Skin full", b.skinFullOn) { b.skinFullOn = it }
        p.switch("Epidermis", b.skinEpidermisOn) { b.skinEpidermisOn = it }
        p.switch("Dermis", b.skinDermisOn) { b.skinDermisOn = it }
        p.switch("Hypodermis", b.skinHypodermisOn) { b.skinHypodermisOn = it }
        p.switch("Face skin", b.skinFaceOn) { b.skinFaceOn = it }
        p.switch("Head skin", b.skinHeadOn) { b.skinHeadOn = it }
        p.switch("Neck skin", b.skinNeckOn) { b.skinNeckOn = it }
        p.switch("Mic→Anatomy live", b.micLiveDriveAnatOn) { b.micLiveDriveAnatOn = it }
        p.switch("Mic→Eyes live", b.micLiveDriveEyesOn) { b.micLiveDriveEyesOn = it }
        p.switch("Mic→Skin live", b.micLiveDriveSkinOn) { b.micLiveDriveSkinOn = it }
        p.switch("Mic→84 live", b.micLiveDrive84On) { b.micLiveDrive84On = it }
        p.seek("Skin thr", 0.05f, 0.9f, b.skinThr) { b.skinThr = it }
        p.seek("Skin level", 0.2f, 1.5f, b.skinLv) { b.skinLv = it }


        p.title("ANATOMY AMBIENT FULL SYSTEMS", 0xFF66BB6A.toInt())
        p.note("11 systems · brain L/R · glands · ear · full 132 parity")
        p.switch("Respiratory", b.respAnatOn) { b.respAnatOn = it }
        p.switch("Cardiovascular", b.cardioAnatOn) { b.cardioAnatOn = it }
        p.switch("Digestive", b.digestAnatOn) { b.digestAnatOn = it }
        p.switch("Urinary", b.urinaryAnatOn) { b.urinaryAnatOn = it }
        p.switch("Endocrine", b.endoAnatOn) { b.endoAnatOn = it }
        p.switch("Lymphatic", b.lymphAnatOn) { b.lymphAnatOn = it }
        p.switch("Skeletal", b.skeletalAnatOn) { b.skeletalAnatOn = it }
        p.switch("Muscular", b.muscleAnatOn) { b.muscleAnatOn = it }
        p.switch("Joints", b.jointAnatOn) { b.jointAnatOn = it }
        p.switch("PNS", b.pnsAnatOn) { b.pnsAnatOn = it }
        p.switch("Reproductive", b.reproAnatOn) { b.reproAnatOn = it }
        p.switch("Ear anatomy", b.earAnatOn) { b.earAnatOn = it }
        p.switch("Hypothalamus", b.hypothalamusOn) { b.hypothalamusOn = it }
        p.switch("Thyroid", b.thyroidOn) { b.thyroidOn = it }
        p.switch("Thymus", b.thymusOn) { b.thymusOn = it }
        p.switch("Pituitary", b.pituitaryOn) { b.pituitaryOn = it }
        p.switch("Pineal", b.pinealOn) { b.pinealOn = it }
        p.switch("Adrenal", b.adrenalOn) { b.adrenalOn = it }
        p.seek("Anatomy thr", 0.05f, 0.9f, b.anatThr) { b.anatThr = it }
        p.seek("Anatomy level", 0.2f, 1.5f, b.anatLv) { b.anatLv = it }

        p.title("20–23 · EAR DSP · TONE · ULTRASOUND · WARFARE", c)
        p.switch("Ear DSP echo L/R + auditory gland", b.earDspOn) {
            b.earDspOn = it; b.earDspLOn = it; b.earDspROn = it; b.auditoryGlandOn = it
        }
        p.switch("DSP tone echo", b.dspToneOn) { b.dspToneOn = it }
        p.switch("Ultrasound echo + focus-only", b.usEchoOn) {
            b.usEchoOn = it; b.usFocusOnlyOn = it
        }
        p.switch("Ultrasonic warfare", b.usWarfareOn) { b.usWarfareOn = it }

        p.title("24–26 · SCREEN · MOBILE BUBBLE · MODEL MIX", c)
        p.switch("Screen ambient", b.screenAmbOn) { b.screenAmbOn = it }
        p.switch("Enemy / virtual screen + spike", b.enemyScreenOn) {
            b.enemyScreenOn = it; b.virtualScreenOn = it; b.screenSpikeOn = it
        }
        p.switch("Mobile / laptop / computer track", b.mobileTrackOn) {
            b.mobileTrackOn = it; b.laptopTrackOn = it; b.computerTrackOn = it
        }
        p.switch("Mobile bubble + battery/charge/spike", b.mobileBubbleOn) {
            b.mobileBubbleOn = it; b.batteryShieldOn = it; b.chargeShieldOn = it; b.mobileSpikeOn = it
        }
        p.switch("NFC shock (default off)", b.nfcShockOn) { b.nfcShockOn = it }
        p.switch("Model anatomy mix", b.modelMixOn) { b.modelMixOn = it }
        p.switch("Pose / Seg / OBB ambient", b.poseAmbOn) {
            b.poseAmbOn = it; b.segAmbOn = it; b.obbAmbOn = it
        }

        val st = p.status("FINAL26 —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 200) }
        })
    }
}
