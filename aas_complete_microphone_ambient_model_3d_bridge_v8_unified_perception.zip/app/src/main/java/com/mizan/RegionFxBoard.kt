package com.mizan

/**
 * Region FX: scale + ripple for body region drawing.
 */
class RegionFxBoard {
    @Volatile var enabled = true
    @Volatile var protectThr = 0.40f
    @Volatile var protectLv = 0.65f
    @Volatile var anyEffectOn = true
    @Volatile var anyEffectThr = 0.35f
    @Volatile var anyEffectLv = 0.60f
    @Volatile var scale = 1f
    @Volatile var ripple = 0f
    private var phase = 0f

    fun tick(energy: Float) {
        if (!enabled) {
            scale = 1f
            ripple = 0f
            return
        }
        val e = energy.coerceIn(0f, 1f)
        val prot = if (e >= protectThr.coerceIn(0.05f, 1f)) protectLv.coerceIn(0f, 1f) else 0f
        val any = if (anyEffectOn && e >= anyEffectThr.coerceIn(0.05f, 1f)) anyEffectLv.coerceIn(0f, 1f) else 0f
        scale = (1f - prot * 0.35f - any * 0.20f).coerceIn(0.35f, 1f)
        phase += 0.08f + e * 0.12f
        ripple = kotlin.math.sin(phase) * e * 12f
    }

    fun regionScale(): Float = scale
    fun rippleOffset(): Float = ripple

    fun statusLine(): String =
        if (!enabled) "REGION-FX off"
        else "REGION-FX scale=${"%.2f".format(scale)} ripple=${"%.1f".format(ripple)}"
    fun apply(v: VisualShieldView?) { /* region FX state */ }

}
