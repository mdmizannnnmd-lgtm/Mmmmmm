package com.mizan

import android.content.Context
import android.content.res.AssetManager
import java.io.File
import java.io.FileOutputStream

/**
 * Complete **`.pt` / `.ptl` runtime loading** for Android.
 *
 * Reality on device:
 *  · Raw training checkpoints (`state_dict` only) do **not** run — need TorchScript.
 *  · Prefer: TorchScript `.pt` or Lite Interpreter `.ptl` via **PyTorch Mobile** (`org.pytorch:pytorch_android`).
 *  · Fallback: copy asset to files dir + status; ONNX/TFLite remains primary for YOLO-seg/obb.
 *
 * Place any of these in `assets/`:
 *  yolo26x-seg.pt · yolo26x-obb.pt · yolo11x-seg.pt · skin-seg.pt · human-parse.pt
 *  or mobile-optimized `*.ptl`
 */
object PtModelRuntime {

    val CANDIDATES = arrayOf(
        // YOLO seg
        "yolo26x-seg.pt", "yolo26x-seg.ptl", "yolo11x-seg.pt", "yolo11n-seg.pt",
        // YOLO OBB
        "yolo26x-obb.pt", "yolo26x-obb.ptl", "yolo11x-obb.pt", "yolo11n-obb.pt",
        // Skin / human parse (complete skin sub-system masks)
        "skin-seg.pt", "skin-seg.ptl", "human-parse.pt", "body-parse.pt",
        // Generic
        "model.pt", "model.ptl"
    )

    @Volatile var status = "no .pt scanned"
    @Volatile var loadedPath: String? = null
    @Volatile var loadedName: String? = null
    @Volatile var pytorchAvailable = false
    @Volatile var moduleLoaded = false
    @Volatile var lastError: String? = null

    /** Optional handle — Module class loaded only if dependency present. */
    @Volatile private var moduleRef: Any? = null

    fun scanAssets(am: AssetManager): List<String> {
        val found = mutableListOf<String>()
        try {
            val names = am.list("") ?: emptyArray()
            for (n in names) {
                val low = n.lowercase()
                if (low.endsWith(".pt") || low.endsWith(".ptl") || low.endsWith(".pth")) {
                    found.add(n)
                }
            }
        } catch (e: Exception) {
            lastError = e.message
        }
        return found
    }

    /**
     * Copy asset → app files (PyTorch Mobile prefers absolute path).
     */
    fun materialize(context: Context, assetName: String): File? {
        return try {
            val out = File(context.filesDir, "pt_models")
            if (!out.exists()) out.mkdirs()
            val dest = File(out, assetName.substringAfterLast('/'))
            if (!dest.exists() || dest.length() == 0L) {
                context.assets.open(assetName).use { input ->
                    FileOutputStream(dest).use { output -> input.copyTo(output) }
                }
            }
            dest
        } catch (e: Exception) {
            lastError = "materialize $assetName: ${e.message}"
            null
        }
    }

    /**
     * Try load first available `.pt`/`.ptl` from assets via PyTorch Mobile reflection
     * (so the app builds even when `pytorch_android` is not on the classpath).
     */
    fun tryLoad(context: Context, preferred: String? = null): Boolean {
        moduleLoaded = false
        moduleRef = null
        loadedPath = null
        loadedName = null
        lastError = null

        val am = context.assets
        val scanned = scanAssets(am)
        val order = buildList {
            preferred?.let { add(it) }
            addAll(CANDIDATES)
            addAll(scanned)
        }.distinct()

        // Detect pytorch
        pytorchAvailable = try {
            Class.forName("org.pytorch.Module")
            true
        } catch (_: Throwable) {
            false
        }

        if (!pytorchAvailable) {
            // Still materialize so export/ONNX pipeline can use the file path
            for (name in order) {
                val f = materialize(context, name) ?: continue
                loadedPath = f.absolutePath
                loadedName = name
                status = "PT file ready at ${f.name} — add org.pytorch:pytorch_android to run TorchScript"
                return true
            }
            status = "no .pt/.ptl in assets · export: yolo export model=….pt format=onnx"
            return false
        }

        for (name in order) {
            val f = materialize(context, name) ?: continue
            try {
                val moduleCls = Class.forName("org.pytorch.Module")
                val load = moduleCls.getMethod("load", String::class.java)
                val mod = load.invoke(null, f.absolutePath)
                moduleRef = mod
                moduleLoaded = true
                loadedPath = f.absolutePath
                loadedName = name
                status = "PT loaded · $name · TorchScript runtime"
                return true
            } catch (e: Throwable) {
                lastError = "load $name: ${e.message}"
                // try next candidate
            }
        }
        status = "pytorch present but no loadable TorchScript .pt · ${lastError ?: ""}"
        return false
    }

    fun isReady(): Boolean = moduleLoaded || loadedPath != null

    fun summary(): String = buildString {
        append(status)
        loadedName?.let { append(" · file=$it") }
        if (pytorchAvailable) append(" · pytorch=yes") else append(" · pytorch=no (ONNX/TFLite still used)")
        lastError?.let { append(" · err=$it") }
    }
}
