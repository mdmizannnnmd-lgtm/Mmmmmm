package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object UltrasoundWeaponOutPanels {
    fun build(ctx: Context, root: LinearLayout, b: UltrasoundWeaponOutBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFF8A65.toInt()
        p.title("BULLET BURST · KNIFE SHARP · ULTRASOUND 0–50 Hz · 300 dB SPL", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.note("Bullet thr uses live mic energy + 0–50 Hz / dB. Enemy bullet prank protect uses audio+camera focus.")

        p.title("BULLET BURST Hz + dB", c)
        p.switch("Bullet burst ON", b.bulletBurstOn) { b.bulletBurstOn = it }
        p.seek("Bullet Hz thr", 0f, 50f, b.bulletHzThr) { b.bulletHzThr = it }
        p.seek("Bullet dB thr", -120f, 0f, b.bulletDbThr) { b.bulletDbThr = it }
        p.seek("Bullet level", 0f, 1.5f, b.bulletDbLv) { b.bulletDbLv = it }

        p.title("KNIFE SHARP Hz + dB", c)
        p.switch("Knife sharp ON", b.knifeSharpOn) { b.knifeSharpOn = it }
        p.seek("Knife Hz thr", 0f, 50f, b.knifeHzThr) { b.knifeHzThr = it }
        p.seek("Knife dB thr", -120f, 0f, b.knifeDbThr) { b.knifeDbThr = it }
        p.seek("Knife level", 0f, 1.5f, b.knifeDbLv) { b.knifeDbLv = it }

        p.title("ULTRASOUND 0–50 Hz · 300 dB SPL", c)
        p.switch("Ultrasound ON", b.ultraOn) { b.ultraOn = it }
        p.seek("Ultra Hz max (≤50)", 1f, 50f, b.ultraHzMax) { b.ultraHzMax = it }
        p.seek("Ultra Hz thr", 0f, 50f, b.ultraThrHz) { b.ultraThrHz = it }
        p.seek("Ultra dB SPL thr (0–300)", 0f, 300f, b.ultraThrDb) { b.ultraThrDb = it }
        p.seek("Ultra dB SPL max", 1f, 300f, b.ultraDbSplMax) { b.ultraDbSplMax = it }
        p.seek("Ultra level", 0f, 1.5f, b.ultraLv) { b.ultraLv = it }

        val st = p.status("ULTRA —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 250) }
        })
    }
}
