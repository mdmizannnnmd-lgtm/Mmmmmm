package com.mizan

/** Public read-only facade for boards that need the complete raw microphone state. */
object RawMicApi {
    val sampleRate: Int get() = RawMicBus.sampleRate
    val channels: Int get() = RawMicBus.channels
    val sequence: Long get() = RawMicBus.sequence
    val rms: Float get() = RawMicBus.rms
    val peak: Float get() = RawMicBus.peak
    val dbfs: Float get() = RawMicBus.dbfs
    val level: Float get() = RawMicBus.level
    val dominantHz: Float get() = RawMicBus.dominantHz
    val centroidHz: Float get() = RawMicBus.centroidHz
    val timestampMs: Long get() = RawMicBus.timestampMs
    val diagnostics: RawMicDiagnostics.Snapshot get() = RawMicDiagnostics.snapshot()

    fun latestMonoPcm(): ShortArray = RawMicBus.latestPcmSnapshot()
    fun latestInterleavedPcm(): ShortArray = RawMicBus.latestRawInterleavedSnapshot()
    fun subscribe(listener: (RawMicFrame) -> Unit): AutoCloseable = RawMicBus.subscribe(listener)
}
