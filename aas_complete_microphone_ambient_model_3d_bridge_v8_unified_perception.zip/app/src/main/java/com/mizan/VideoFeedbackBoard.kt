package com.mizan

import android.graphics.Bitmap
import android.graphics.BlendMode
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.os.Build
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Video feedback loops + video levels (own display).
 *
 * 1) VIRTUAL VIDEO FEEDBACK LOOP — the rendered virtual video is drawn into an offscreen buffer and the
 *    previous frame is drawn back underneath the new one (gain = decay, zoom, rotation). This produces
 *    classic video-feedback trails/tunnels.
 * 2) CAMERA FEEDBACK LOOP — live camera preview statistics (brightness, contrast, colour, motion) modulate
 *    the loop's gain / zoom / swirl. If the camera sees the screen, the loop closes physically
 *    (camera -> stats -> loop -> screen -> camera). Needs the camera running; if the camera signal goes
 *    stale (> 1 s) the modulation falls back to neutral.
 * 3) LOOP SAFETY — when the drive reaches [fbThr] the loop gain is held to [fbRail] (0..255, 255 = no limit),
 *    slew-limited (fast clamp, slow release). Gain is also hard-capped at [MAX_GAIN] so it can never run away.
 * 4) VIDEO LEVELS — contrast / brightness / colour level applied to the virtual video through a ColorMatrix.
 *    Brightness can also drive the camera's exposure compensation (see [exposureLevel]).
 *
 * Defaults: both loops OFF and levels neutral, so nothing changes until you enable them.
 */
class VideoFeedbackBoard {
    @Volatile var enabled = true

    // ---- live camera signal (written by CameraManager's preview callback) ----
    @Volatile var camLuma = 0f
    @Volatile var camContrast = 0f
    @Volatile var camColour = 0f
    @Volatile var camMotion = 0f
    @Volatile var camSpeed = 0f
    @Volatile var camWave = 0f
    @Volatile var cameraPower = 1.0f
    @Volatile private var camSignalAtMs = 0L
    private var previousCameraSamples: FloatArray? = null
    private var previousCameraMotion = 0f
    private var previousCameraFrameAtMs = 0L

    // ---- virtual video feedback loop (shared base parameters, 0..1 raw; 0.5 = neutral for zoom/rotate) ----
    @Volatile var vfOn = false
    @Volatile var freezeFrame = false
    @Volatile var vfGain = 0.60f
    @Volatile var vfZoom = 0.50f
    @Volatile var vfRotate = 0.50f
    @Volatile var trailDecay = 0.90f
    @Volatile var blendMode = BLEND_SCREEN
    /** Loop buffer resolution as a fraction of the view (0.25..1). Lower = faster. */
    @Volatile var vfRes = 0.50f

    // ---- loop safety ----
    @Volatile var fbThrOn = true
    @Volatile var fbThr = 0.60f
    @Volatile var fbRail = 255
    @Volatile var fbTripped = false

    // ---- camera feedback loop ----
    @Volatile var cfOn = false
    @Volatile var cfMix = 0.50f

    // ---- video levels (1 / 0 / 1 = unchanged) ----
    @Volatile var contrast = 1f      // 0..2
    @Volatile var brightness = 0f    // -1..1
    @Volatile var colour = 1f        // 0..2 (saturation)
    @Volatile var hue = 0f           // -180..180 degrees
    @Volatile var camExposureFollow = true

    // Audio mappings: RMS -> brightness, bass -> zoom/strength, mid -> rotation, high -> hue.
    @Volatile var audioReactiveOn = true
    @Volatile var audioRms = 0f
    @Volatile var audioBass = 0f
    @Volatile var audioLowMid = 0f
    @Volatile var audioMid = 0f
    @Volatile var audioHigh = 0f
    @Volatile var audioAir = 0f
    @Volatile var audioCentroid = 0.5f
    @Volatile var audioBrightnessMix = 0.80f
    @Volatile var audioZoomMix = 0.50f
    @Volatile var audioStrengthMix = 0.30f
    @Volatile var audioRotateMix = 1.00f
    @Volatile var audioHueMix = 1.00f

    /** Audio colour board (threshold / contrast / brightness / colour level offsets); set by MainActivity. */
    @Volatile var audioColourRef: AudioColourBoard? = null

    // Protection starts enabled. RAW bypasses colour transforms only, never the loop or flash limits.
    @Volatile var protectionOn = true
    @Volatile var protectionPreset = PRESET_SAFE
    @Volatile var maxBrightness = 1.0f
    @Volatile var maxContrast = 1.5f
    @Volatile var maxStrength = 0.80f

    @Volatile var motionDetectionOn = true
    @Volatile var motionSensitivity = 1.00f
    @Volatile var motionMoveGate = 0.05f
    @Volatile var motionSpeedGate = 0.20f
    @Volatile var motionWaveGate = 0.40f
    @Volatile var motionStrengthMix = 1.15f
    @Volatile var motionZoomMix = 0.30f
    @Volatile var motionRotateMix = 0.50f
    @Volatile var motionHueMix = 60f
    @Volatile var motionActive = false

    // RAW TOWS pass. Overdrive is still hard-capped at MAX_GAIN after all multipliers.
    @Volatile var rawTowsOn = false
    @Volatile var rawPass = false
    @Volatile var overdrive = 1.0f
    @Volatile var pixelWaveOn = false
    @Volatile var pixelWaveAmp = 0.025f
    @Volatile var pixelWaveFreq = 4.0f
    @Volatile var pixelWaveSpeed = 1.5f
    @Volatile var invertColors = false

    class ChannelGate {
        @Volatile var enabled = true
        @Volatile var min = 0
        @Volatile var max = 255
        @Volatile var gain = 1.0f
    }
    val red = ChannelGate()
    val green = ChannelGate()
    val blue = ChannelGate()

    @Volatile private var railSmooth = 1f
    private var lastTickMs = 0L
    @Volatile private var wavePhase = 0f
    @Volatile private var brightnessOut = 0f
    @Volatile private var gainOut = 0f
    @Volatile private var hueOut = 0f
    private var lastLevelKey = Long.MIN_VALUE
    private var lastLevelFilter: ColorMatrixColorFilter? = null

    // ---- offscreen loop buffers ----
    private class Buf(val bmp: Bitmap) { val canvas = Canvas(bmp) }
    private var bufA: Buf? = null
    private var bufB: Buf? = null
    private var bw = 0
    private var bh = 0
    private var hasRenderedFrame = false
    private val fbPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val outPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val srcR = Rect()
    private val dstR = Rect()

    // ------------------------------------------------------------------ camera signal
    /** Called from the camera preview callback. Values 0..1; smoothed here. */
    fun feedCamera(luma: Float, contrastV: Float, colourV: Float, motion: Float) {
        val k = 0.35f
        camLuma += (luma.coerceIn(0f, 1f) - camLuma) * k
        camContrast += (contrastV.coerceIn(0f, 1f) - camContrast) * k
        camColour += (colourV.coerceIn(0f, 1f) - camColour) * k
        camMotion += (motion.coerceIn(0f, 1f) - camMotion) * k
        camSignalAtMs = SystemClock.elapsedRealtime()
    }

    /**
     * Summarize a sampled NV21 preview frame without retaining camera pixels.
     * The camera contributes only normalized luma, contrast, chroma and motion
     * signals to the effects; the frame is not uploaded or stored.
     */
    fun feedCameraFrame(nv21: ByteArray, width: Int, height: Int) {
        if (width < 2 || height < 2 || nv21.size < width * height) return
        val samplesX = 12
        val samplesY = 8
        val current = FloatArray(samplesX * samplesY)
        var sum = 0f
        var sumSq = 0f
        var chromaSum = 0f
        var sampled = 0
        val ySize = width * height
        for (row in 0 until samplesY) {
            val y = ((row + 0.5f) * height / samplesY).toInt().coerceIn(0, height - 1)
            for (col in 0 until samplesX) {
                val x = ((col + 0.5f) * width / samplesX).toInt().coerceIn(0, width - 1)
                val index = y * width + x
                val luma = (nv21[index].toInt() and 0xFF).coerceIn(16, 235)
                val normalized = ((luma - 16) / 219f).coerceIn(0f, 1f)
                current[sampled++] = normalized
                sum += normalized
                sumSq += normalized * normalized
                val chromaIndex = ySize + (y / 2) * width + (x and 0xFFFE)
                if (chromaIndex + 1 < nv21.size) {
                    val v = (nv21[chromaIndex].toInt() and 0xFF) - 128
                    val u = (nv21[chromaIndex + 1].toInt() and 0xFF) - 128
                    chromaSum += (sqrt((u * u + v * v).toFloat()) / 181f).coerceIn(0f, 1f)
                }
            }
        }
        val count = sampled.coerceAtLeast(1)
        val mean = sum / count
        val variance = (sumSq / count - mean * mean).coerceAtLeast(0f)
        val previous = previousCameraSamples
        var frameMotion = 0f
        if (previous != null && previous.size == current.size) {
            for (i in current.indices) frameMotion += abs(current[i] - previous[i])
            frameMotion = ((frameMotion / count) * 3.5f).coerceIn(0f, 1f)
        }
        val now = SystemClock.elapsedRealtime()
        val dt = if (previousCameraFrameAtMs == 0L) 0.033f
            else ((now - previousCameraFrameAtMs) / 1000f).coerceIn(0.008f, 0.2f)
        val speed = (abs(frameMotion - previousCameraMotion) / dt * 0.12f).coerceIn(0f, 1f)
        camSpeed += (speed - camSpeed) * 0.35f
        camWave += (abs(frameMotion - camWave) - camWave) * 0.12f
        previousCameraSamples = current
        previousCameraMotion = frameMotion
        previousCameraFrameAtMs = now
        feedCamera(mean, (sqrt(variance) * 2.0f).coerceIn(0f, 1f),
            (chromaSum / count).coerceIn(0f, 1f), frameMotion)
        tick(frameMotion)
    }

    fun camFresh(): Boolean =
        camSignalAtMs > 0L && SystemClock.elapsedRealtime() - camSignalAtMs <= 1000L

    /** Called by AudioProcessor; values are normalized 0..1 band envelopes. */
    fun feedAudio(
        rms: Float,
        bass: Float,
        lowMid: Float,
        mid: Float,
        high: Float,
        air: Float,
        centroid: Float = 0.5f
    ) {
        val k = 0.35f
        audioRms += (rms.coerceIn(0f, 1f) - audioRms) * k
        audioBass += (bass.coerceIn(0f, 1f) - audioBass) * k
        audioLowMid += (lowMid.coerceIn(0f, 1f) - audioLowMid) * k
        audioMid += (mid.coerceIn(0f, 1f) - audioMid) * k
        audioHigh += (high.coerceIn(0f, 1f) - audioHigh) * k
        audioAir += (air.coerceIn(0f, 1f) - audioAir) * k
        audioCentroid += (centroid.coerceIn(0f, 1f) - audioCentroid) * k
    }

    // ------------------------------------------------------------------ tick / effective values
    @Synchronized fun tick(energy: Float) {
        val now = SystemClock.elapsedRealtime()
        val dt = if (lastTickMs == 0L) 0.016f else ((now - lastTickMs) / 1000f).coerceIn(0.001f, 0.1f)
        lastTickMs = now
        val e = energy.coerceIn(0f, 1f)
        fbTripped = enabled && fbThrOn && e >= fbThr.coerceIn(0.05f, 1f)
        val target = if (fbTripped) (fbRail.coerceIn(0, 255) / 255f) else 1f
        railSmooth = if (target < railSmooth) {
            maxOf(target, railSmooth - 6f * dt)      // fast clamp
        } else {
            minOf(target, railSmooth + 1.5f * dt)    // slow release
        }
        wavePhase = (wavePhase + dt * pixelWaveSpeed.coerceIn(0f, 20f)) % (2f * PI.toFloat())
        val requestedBrightness = (brightness +
            (if (audioReactiveOn) audioRms * audioBrightnessMix.coerceIn(0f, 1f) * 0.35f else 0f) +
            acBrightness()).coerceIn(-1f, 1f)
        val hardBrightnessCap = if (protectionOn) {
            maxBrightness.coerceIn(0f, 2f) / 2f
        } else 0.50f
        val targetBrightness = requestedBrightness.coerceIn(-hardBrightnessCap, hardBrightnessCap)
        val maxStep = 0.75f * dt
        brightnessOut += (targetBrightness - brightnessOut).coerceIn(-maxStep, maxStep)
        val hueDelta = wrapHue(requestedHue() - hueOut)
        hueOut = wrapHue(hueOut + hueDelta.coerceIn(-180f * dt, 180f * dt))
        val requestedGain = targetGain()
        val gainStep = 1.20f * dt
        gainOut += (requestedGain - gainOut).coerceIn(-gainStep, gainStep)
        motionActive = motionAmount() > 0.02f
    }

    fun loopActive(): Boolean = enabled && (vfOn || cfOn)

    /** Camera modulation amount (0 when the camera loop is off or the camera signal is stale). */
    private fun camMod(): Float = if (cfOn && camFresh()) {
        (cfMix.coerceIn(0f, 1f) * cameraPower.coerceIn(0f, 2f)).coerceIn(0f, 1f)
    } else 0f

    fun effectiveGain(): Float {
        if (!loopActive()) return 0f
        return gainOut.coerceIn(0f, MAX_GAIN)
    }

    private fun targetGain(): Float {
        if (!loopActive()) return 0f
        val audioBoost = if (audioReactiveOn) audioBass * audioStrengthMix.coerceIn(0f, 1f) * 0.35f else 0f
        val motionBoost = if (motionDetectionOn) motionAmount() *
            motionStrengthMix.coerceIn(0f, 2f) * 0.12f else 0f
        val rawDrive = if (rawTowsOn) overdrive.coerceIn(1f, 6f) else 1f
        var g = (vfGain.coerceIn(0f, 1f) + audioBoost + motionBoost) *
            MAX_GAIN * trailDecay.coerceIn(0f, 1f) * rawDrive
        val m = camMod()
        if (m > 0f) g *= (1f - m) + m * (0.30f + 0.70f * camLuma.coerceIn(0f, 1f))
        g *= railSmooth
        if (protectionOn) g = minOf(g, maxStrength.coerceIn(0f, MAX_GAIN))
        return g.coerceIn(0f, MAX_GAIN)
    }

    fun effectiveRotateDeg(): Float {
        var r = (vfRotate.coerceIn(0f, 1f) - 0.5f) * 8f
        r += camMod() * camMotion.coerceIn(0f, 1f) * 3f
        if (audioReactiveOn) r += audioMid * audioRotateMix.coerceIn(0f, 1f) * 8f
        if (motionDetectionOn) r += motionAmount() * motionRotateMix.coerceIn(0f, 10f)
        return r
    }

    fun effectiveZoom(): Float {
        var z = 1f + (vfZoom.coerceIn(0f, 1f) - 0.5f) * 0.30f
        z += camMod() * camContrast.coerceIn(0f, 1f) * 0.01f
        if (audioReactiveOn) z += audioBass * audioZoomMix.coerceIn(0f, 1f) * 0.08f
        if (motionDetectionOn) z += motionAmount() * motionZoomMix.coerceIn(0f, 0.5f)
        return z.coerceIn(0.70f, 1.30f)
    }

    private fun motionAmount(): Float {
        if (!motionDetectionOn || !camFresh()) return 0f
        val movement = gate(camMotion, motionMoveGate)
        val speed = gate(camSpeed, motionSpeedGate)
        val wave = gate(camWave, motionWaveGate)
        return (maxOf(movement, speed * 0.55f, wave * 0.35f) *
            motionSensitivity.coerceIn(0f, 2f) * cameraPower.coerceIn(0f, 2f)).coerceIn(0f, 1f)
    }

    private fun gate(value: Float, threshold: Float): Float {
        val t = threshold.coerceIn(0f, 0.95f)
        return if (value <= t) 0f else ((value - t) / (1f - t).coerceAtLeast(0.05f)).coerceIn(0f, 1f)
    }

    // ------------------------------------------------------------------ loop rendering
    /**
     * Renders one frame through the feedback loop. [drawScene] draws the normal virtual video into the
     * canvas it is given, in full view coordinates (the canvas is pre-scaled to the loop buffer).
     */
    fun renderLoop(canvas: Canvas, w: Int, h: Int, drawScene: (Canvas) -> Unit) {
        val res = vfRes.coerceIn(0.25f, 1f)
        val nw = (w * res).toInt().coerceAtLeast(16)
        val nh = (h * res).toInt().coerceAtLeast(16)
        if (bufA == null || bufB == null || bw != nw || bh != nh) {
            releaseLoop()
            bufA = Buf(Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888))
            bufB = Buf(Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888))
            bw = nw
            bh = nh
        }
        val prev = bufA!!
        val next = bufB!!
        val nc = next.canvas
        nc.drawColor(0, PorterDuff.Mode.CLEAR)

        // Draw the current image first so each selected Porter/BlendMode combines
        // the retained frame with real pixels rather than with a transparent buffer.
        if (freezeFrame && hasRenderedFrame) {
            nc.drawBitmap(prev.bmp, 0f, 0f, null)
        } else {
            nc.save()
            nc.scale(nw / w.toFloat(), nh / h.toFloat())
            drawScene(nc)
            nc.restore()
        }

        // Feed the previous image back over the current image with gain / transform.
        val g = effectiveGain()
        if (g > 0.01f && !freezeFrame) {
            nc.save()
            nc.translate(nw / 2f, nh / 2f)
            nc.rotate(effectiveRotateDeg())
            nc.scale(effectiveZoom(), effectiveZoom())
            nc.translate(-nw / 2f, -nh / 2f)
            fbPaint.alpha = (g * 255f).toInt().coerceIn(0, 255)
            setBlendMode(fbPaint, blendMode)
            if (pixelWaveOn && pixelWaveAmp > 0.001f) {
                drawPixelWave(nc, prev.bmp, nw, nh, fbPaint)
            } else {
                nc.drawBitmap(prev.bmp, 0f, 0f, fbPaint)
            }
            fbPaint.alpha = 255
            fbPaint.xfermode = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) fbPaint.blendMode = null
            nc.restore()
        }

        // 3) present, then swap buffers
        srcR.set(0, 0, nw, nh)
        dstR.set(0, 0, w, h)
        if (isBlackout()) {
            canvas.drawColor(android.graphics.Color.BLACK)
        } else {
            outPaint.colorFilter = levelsFilter()
            canvas.drawBitmap(next.bmp, srcR, dstR, outPaint)
            outPaint.colorFilter = null
        }
        bufA = next
        bufB = prev
        hasRenderedFrame = true
    }

    private fun drawPixelWave(canvas: Canvas, bitmap: Bitmap, w: Int, h: Int, paint: Paint) {
        val strip = 4
        val amplitudePx = (pixelWaveAmp.coerceIn(0f, 0.12f) * w).toInt()
        val cycles = pixelWaveFreq.coerceIn(0.1f, 24f)
        val phase = wavePhase
        val src = Rect()
        val dst = Rect()
        canvas.save()
        canvas.clipRect(0, 0, w, h)
        var y = 0
        while (y < h) {
            val bottom = minOf(h, y + strip)
            val wave = sin((y.toFloat() / h * cycles * 2f * PI.toFloat()) + phase)
            val dx = (wave * amplitudePx).toInt()
            src.set(0, y, w, bottom)
            dst.set(dx, y, w + dx, bottom)
            canvas.drawBitmap(bitmap, src, dst, paint)
            y = bottom
        }
        canvas.restore()
    }

    private fun setBlendMode(paint: Paint, mode: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            paint.xfermode = null
            paint.blendMode = when (mode) {
                BLEND_OVERLAY -> BlendMode.OVERLAY
                BLEND_MULTIPLY -> BlendMode.MULTIPLY
                BLEND_LIGHTER -> BlendMode.LIGHTEN
                BLEND_DIFFERENCE -> BlendMode.DIFFERENCE
                BLEND_EXCLUSION -> BlendMode.EXCLUSION
                BLEND_HARD_LIGHT -> BlendMode.HARD_LIGHT
                BLEND_SOFT_LIGHT -> BlendMode.SOFT_LIGHT
                BLEND_COLOR_DODGE -> BlendMode.COLOR_DODGE
                else -> BlendMode.SCREEN
            }
        } else {
            paint.blendMode = null
            paint.xfermode = PorterDuffXfermode(
                when (mode) {
                    BLEND_OVERLAY -> PorterDuff.Mode.OVERLAY
                    BLEND_MULTIPLY -> PorterDuff.Mode.MULTIPLY
                    BLEND_LIGHTER -> PorterDuff.Mode.LIGHTEN
                    else -> PorterDuff.Mode.SCREEN
                }
            )
        }
    }

    fun releaseLoop() {
        bufA?.bmp?.recycle()
        bufB?.bmp?.recycle()
        bufA = null
        bufB = null
        bw = 0
        bh = 0
        hasRenderedFrame = false
        gainOut = 0f
    }

    // ------------------------------------------------------------------ video levels
    private fun effectiveBrightness(): Float {
        val cap = if (protectionOn) maxBrightness.coerceIn(0f, 2f) / 2f else 0.50f
        return brightnessOut.coerceIn(-cap, cap)
    }

    private fun effectiveContrast(): Float {
        val requested = (contrast + acContrast()).coerceIn(0f, 2.5f)
        return if (protectionOn) minOf(requested, maxContrast.coerceIn(0f, 2.5f)) else requested
    }

    private fun acBoard(): AudioColourBoard? = audioColourRef?.takeIf { it.enabled }
    private fun acBrightness(): Float = acBoard()?.dBrightness ?: 0f
    private fun acContrast(): Float = acBoard()?.dContrast ?: 0f

    /** Colour level (saturation) incl. the audio colour offset. */
    private fun effectiveColour(): Float = (colour + (acBoard()?.dColour ?: 0f)).coerceIn(0f, 2.5f)

    private fun requestedHue(): Float {
        val audio = if (audioReactiveOn) audioHigh * audioHueMix.coerceIn(0f, 1f) * 120f else 0f
        val motion = if (motionDetectionOn) gate(camWave, motionWaveGate) * motionHueMix.coerceIn(0f, 120f) else 0f
        return wrapHue(hue + audio + motion)
    }

    private fun effectiveHue(): Float = hueOut

    private fun wrapHue(value: Float): Float = ((value + 180f) % 360f + 360f) % 360f - 180f

    fun isBlackout(): Boolean = protectionOn && protectionPreset == PRESET_BLACKOUT

    private fun channelIsNeutral(channel: ChannelGate): Boolean =
        rawPass || !channel.enabled ||
            (channel.min == 0 && channel.max == 255 && kotlin.math.abs(channel.gain - 1f) < 0.005f)

    fun levelsNeutral(): Boolean =
        rawPass ||
            (
        !invertColors &&
        kotlin.math.abs(effectiveContrast() - 1f) < 0.005f &&
            kotlin.math.abs(effectiveBrightness()) < 0.005f &&
            kotlin.math.abs(effectiveColour() - 1f) < 0.005f &&
            kotlin.math.abs(effectiveHue()) < 0.005f &&
            channelIsNeutral(red) && channelIsNeutral(green) && channelIsNeutral(blue)
            )

    /** ColorMatrix filter for levels, hue rotation and per-channel black/white points. */
    fun levelsFilter(): ColorMatrixColorFilter? {
        if (rawPass) return null
        if (levelsNeutral()) return null
        var key = 17L
        fun keyPart(value: Int) { key = key * 31L + value }
        keyPart((effectiveContrast() * 1000).toInt())
        keyPart((effectiveBrightness() * 1000).toInt())
        keyPart((effectiveColour() * 1000).toInt())
        keyPart((effectiveHue() * 10).toInt())
        keyPart(if (invertColors) 1 else 0)
        listOf(red, green, blue).forEach { ch ->
            keyPart(if (rawPass || !ch.enabled) 0 else 1)
            keyPart(ch.min); keyPart(ch.max); keyPart((ch.gain * 1000).toInt())
        }
        if (key == lastLevelKey) return lastLevelFilter

        val c = effectiveContrast().coerceIn(0f, 2.5f)
        val b = effectiveBrightness()
        val s = effectiveColour()
        val cm = ColorMatrix()
        cm.setSaturation(s)
        if (!rawPass) {
            fun scale(channel: ChannelGate): Pair<Float, Float> {
                if (!channel.enabled) return 1f to 0f
                val lo = channel.min.coerceIn(0, 254)
                val hi = channel.max.coerceIn(lo + 1, 255)
                val factor = channel.gain.coerceIn(0f, 2f) * 255f / (hi - lo).toFloat()
                return factor to (-lo * factor)
            }
            val r = scale(red)
            val g = scale(green)
            val bl = scale(blue)
            cm.postConcat(ColorMatrix(floatArrayOf(
                r.first, 0f, 0f, 0f, r.second,
                0f, g.first, 0f, 0f, g.second,
                0f, 0f, bl.first, 0f, bl.second,
                0f, 0f, 0f, 1f, 0f
            )))
        }

        val radians = Math.toRadians(effectiveHue().toDouble())
        val cosA = kotlin.math.cos(radians).toFloat()
        val sinA = kotlin.math.sin(radians).toFloat()
        cm.postConcat(ColorMatrix(floatArrayOf(
            0.213f + cosA * 0.787f - sinA * 0.213f,
            0.715f - cosA * 0.715f - sinA * 0.715f,
            0.072f - cosA * 0.072f + sinA * 0.928f, 0f, 0f,
            0.213f - cosA * 0.213f + sinA * 0.143f,
            0.715f + cosA * 0.285f + sinA * 0.140f,
            0.072f - cosA * 0.072f - sinA * 0.283f, 0f, 0f,
            0.213f - cosA * 0.213f - sinA * 0.787f,
            0.715f - cosA * 0.715f + sinA * 0.715f,
            0.072f + cosA * 0.928f + sinA * 0.072f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )))
        val t = 128f * (1f - c) + b * 255f
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    c, 0f, 0f, 0f, t,
                    0f, c, 0f, 0f, t,
                    0f, 0f, c, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        if (invertColors) {
            cm.postConcat(ColorMatrix(floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )))
        }
        val filter = ColorMatrixColorFilter(cm)
        lastLevelKey = key
        lastLevelFilter = filter
        return filter
    }

    /** -1..1 camera exposure level (0 when brightness does not drive the camera). */
    fun exposureLevel(): Float = if (camExposureFollow) effectiveBrightness().coerceIn(-1f, 1f) else 0f

    fun statusLine(): String {
        if (!enabled) return "VIDEO FB off"
        val loop = when {
            vfOn && cfOn -> "LOOP vf+cf"
            vfOn -> "LOOP vf"
            cfOn -> "LOOP cf"
            else -> "loop off"
        }
        val cam = if (camFresh()) {
            "CAM luma=${(camLuma * 100).toInt()}% con=${(camContrast * 100).toInt()}% " +
                "col=${(camColour * 100).toInt()}% mot=${(camMotion * 100).toInt()}%"
        } else "CAM no signal"
        val extras = buildList {
            if (audioReactiveOn) add("AUDIO")
            if (acBoard() != null) add("AUDIO-COLOUR")
            if (motionDetectionOn) add(if (motionActive) "MOTION" else "MOTION-READY")
            if (rawTowsOn) add("RAW×${"%.1f".format(overdrive.coerceIn(1f, 6f))}")
            if (fbTripped) add("FB-RAIL")
        }.joinToString(" ")
        return "$loop ${blendName(blendMode)} gain=${(effectiveGain() * 100).toInt()}% " +
            "zoom=${"%.3f".format(effectiveZoom())} rot=${"%.1f".format(effectiveRotateDeg())}° " +
            "trail=${(trailDecay * 100).toInt()}% · $cam · " +
            "levels c=${(effectiveContrast() * 100).toInt()}% b=${(effectiveBrightness() * 100).toInt()} " +
            "sat=${(effectiveColour() * 100).toInt()}% hue=${"%.0f".format(effectiveHue())}° $extras"
    }

    companion object {
        /** Hard cap so the loop can never run away. */
        const val MAX_GAIN = 0.96f

        const val BLEND_SCREEN = 0
        const val BLEND_OVERLAY = 1
        const val BLEND_MULTIPLY = 2
        const val BLEND_LIGHTER = 3
        const val BLEND_DIFFERENCE = 4
        const val BLEND_EXCLUSION = 5
        const val BLEND_HARD_LIGHT = 6
        const val BLEND_SOFT_LIGHT = 7
        const val BLEND_COLOR_DODGE = 8

        const val PRESET_OFF = 0
        const val PRESET_SAFE = 1
        const val PRESET_SOFT = 2
        const val PRESET_MEDIUM = 3
        const val PRESET_HARD = 4
        const val PRESET_BLACKOUT = 5
        const val PRESET_CUSTOM = 6

        fun blendName(value: Int): String = when (value) {
            BLEND_OVERLAY -> "overlay"
            BLEND_MULTIPLY -> "multiply"
            BLEND_LIGHTER -> "lighter"
            BLEND_DIFFERENCE -> "difference"
            BLEND_EXCLUSION -> "exclusion"
            BLEND_HARD_LIGHT -> "hard-light"
            BLEND_SOFT_LIGHT -> "soft-light"
            BLEND_COLOR_DODGE -> "color-dodge"
            else -> "screen"
        }
    }
    fun apply(v: VisualShieldView?) { /* video feedback state */ }

}
