package com.mizan

import kotlin.math.sqrt

/**
 * State bridge from the app's live 84-channel/motion systems to the ARCore GPU renderer.
 * Values are app sensor/render signals; this is not body tracking or physiological sensing.
 */
class BodySurfaceGpuBoard {
    @Volatile var enabled = true
    @Volatile var level = 0.68f
    @Volatile var threshold = 0.08f

    @Volatile var atomSpareOn = true
    @Volatile var atomSpareThreshold = 0.30f
    @Volatile var atomSpareLevel = 0.55f

    @Volatile var waveSpareOn = true
    @Volatile var waveSpareThreshold = 0.25f
    @Volatile var waveSpareLevel = 0.55f

    @Volatile var particlesOn = true
    @Volatile var particleLevel = 0.65f
    @Volatile var movementOn = true
    @Volatile var rawMotionOn = true
    @Volatile var movementThreshold = 0.15f
    @Volatile var movementLevel = 0.60f

    @Volatile var inputRaw = 0f
        private set
    @Volatile var bodyOutput = 0f
        private set
    @Volatile var movementOutput = 0f
        private set
    @Volatile var movementX = 0f
        private set
    @Volatile var movementY = 0f
        private set
    @Volatile var movementZ = 0f
        private set
    @Volatile var atomSpareActive = false
        private set
    @Volatile var waveSpareActive = false
        private set
    @Volatile var particleCount = 0
        private set
    @Volatile var rawAccelX = 0f
        private set
    @Volatile var rawAccelY = 0f
        private set
    @Volatile var rawAccelZ = 0f
        private set
    @Volatile var rawGyroX = 0f
        private set
    @Volatile var rawGyroY = 0f
        private set
    @Volatile var rawGyroZ = 0f
        private set
    @Volatile var activeChannels = 0
        private set

    fun tick(energy: Float, body: Body84Channels, pose: PoseSurfaceBoard, motion: MotionSensorHub?) {
        inputRaw = energy.coerceIn(0f, 1f)
        activeChannels = body.activeCount
        val signal = maxOf(inputRaw, body.avgOut.coerceIn(0f, 1f), pose.bodyOut.coerceIn(0f, 1f))
        val gate = threshold.coerceIn(0f, 1f)
        bodyOutput = if (enabled && signal >= gate) {
            (((signal - gate) / (1f - gate).coerceAtLeast(0.05f)) * level.coerceIn(0f, 1f))
                .coerceIn(0f, 1f)
        } else 0f

        atomSpareActive = atomSpareOn && signal >= atomSpareThreshold.coerceIn(0f, 1f)
        waveSpareActive = waveSpareOn && pose.bodyWaveSpareOn &&
            signal >= maxOf(
                waveSpareThreshold.coerceIn(0f, 1f),
                pose.bodyWaveSpareThr.coerceIn(0f, 1f)
            )

        val m = motion
        rawAccelX = m?.rawAccelX ?: 0f
        rawAccelY = m?.rawAccelY ?: 0f
        rawAccelZ = m?.rawAccelZ ?: 0f
        rawGyroX = m?.rawGyroX ?: 0f
        rawGyroY = m?.rawGyroY ?: 0f
        rawGyroZ = m?.rawGyroZ ?: 0f

        if (m != null && movementOn) {
            if (rawMotionOn) {
                movementX = (rawAccelX / 22f).coerceIn(-0.45f, 0.45f)
                movementY = (-rawAccelY / 30f).coerceIn(-0.35f, 0.35f)
                movementZ = (rawGyroY / 8f).coerceIn(-0.30f, 0.30f)
                val rawMagnitude = sqrt(rawAccelX * rawAccelX + rawAccelY * rawAccelY + rawAccelZ * rawAccelZ)
                val gyroMagnitude = sqrt(rawGyroX * rawGyroX + rawGyroY * rawGyroY + rawGyroZ * rawGyroZ)
                val accelMotion = ((rawMagnitude - 9.4f).coerceAtLeast(0f) / 8f).coerceIn(0f, 1f)
                val gyroMotion = (gyroMagnitude / 3f).coerceIn(0f, 1f)
                val motionSignal = maxOf(accelMotion, gyroMotion)
                movementOutput = if (motionSignal >= movementThreshold.coerceIn(0f, 1f)) {
                    motionSignal * movementLevel.coerceIn(0f, 1f)
                } else 0f
            } else {
                movementX = (m.pitchR - m.pitchL).coerceIn(-1f, 1f) * 0.30f
                movementY = (m.pitchDown - m.pitchUp).coerceIn(-1f, 1f) * 0.24f
                movementZ = (m.axisZ - 0.5f).coerceIn(-0.5f, 0.5f) * 0.20f
                movementOutput = if (m.liveMove >= movementThreshold.coerceIn(0f, 1f)) {
                    m.liveMove.coerceIn(0f, 1f) * movementLevel.coerceIn(0f, 1f)
                } else 0f
            }
        } else {
            movementX = 0f
            movementY = 0f
            movementZ = 0f
            movementOutput = 0f
        }

        val particles = if (enabled && particlesOn) {
            (body.bulkParticles.coerceIn(0f, 1f) * 0.45f +
                body.avgOut.coerceIn(0f, 1f) * 0.55f) *
                particleLevel.coerceIn(0f, 1f) *
                (if (bodyOutput > 0f) 0.45f + bodyOutput * 0.55f else 0.12f)
        } else 0f
        particleCount = if (particles > 0.01f) (8 + particles * 112f).toInt() else 0
    }

    fun statusLine(cameraTextureActive: Boolean = false): String {
        val atom = if (atomSpareActive) "ON" else "idle"
        val wave = if (waveSpareActive) "ON" else "idle"
        return "GPU BODY ${if (enabled) "ON" else "OFF"} · " +
            "camera=${if (cameraTextureActive) "ARCore" else "waiting for ARCore"} · " +
            "raw=${(inputRaw * 100f).toInt()}% " +
            "body=${(bodyOutput * 100f).toInt()}% ch=$activeChannels/84 · " +
            "atom-spare=$atom/${(atomSpareLevel * 100f).toInt()}% " +
            "wave-spare=$wave/${(waveSpareLevel * 100f).toInt()}% " +
            "particles=$particleCount · move=${(movementOutput * 100f).toInt()}% " +
            "${if (rawMotionOn) "RAW" else "filtered"} " +
            "accel=${"%.1f".format(rawAccelX)},${"%.1f".format(rawAccelY)},${"%.1f".format(rawAccelZ)} " +
            "gyro=${"%.2f".format(rawGyroX)},${"%.2f".format(rawGyroY)},${"%.2f".format(rawGyroZ)}"
    }
    fun apply(v: VisualShieldView?) { /* GPU surface state */ }

}
