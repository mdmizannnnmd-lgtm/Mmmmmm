package com.mizan

import kotlin.math.abs

/**
 * Converts a live camera person detection into bounded, smoothed eye-gaze values.
 * This is a visual control signal, not evidence of independent perception.
 * All coordinates are normalized camera-frame coordinates (0..1).
 */
class CameraGazeController(
    private val confidenceThreshold: Float = 0.45f,
    private val smoothing: Float = 0.22f,
    private val horizontalRange: Float = 0.85f,
    private val verticalRange: Float = 0.70f,
    private val deadZone: Float = 0.025f,
    private val staleHoldMs: Long = 650L
) {
    data class State(
        val leftX: Float = 0f,
        val leftY: Float = 0f,
        val rightX: Float = 0f,
        val rightY: Float = 0f,
        val confidence: Float = 0f,
        val tracking: Boolean = false,
        val timestampMs: Long = 0L
    )

    @Volatile private var state = State()

    fun update(detection: HumanDetection, nowMs: Long = System.currentTimeMillis()): State {
        val usable = detection.modelReady && detection.hasPerson && detection.isFresh(nowMs) &&
            detection.confidence >= confidenceThreshold &&
            detection.centerX.isFinite() && detection.centerY.isFinite()

        if (!usable) {
            val previous = state
            if (previous.tracking && nowMs - previous.timestampMs <= staleHoldMs) return previous
            state = State(timestampMs = nowMs)
            return state
        }

        val targetX = deadZone(detection.centerX.coerceIn(0f, 1f) * 2f - 1f) * horizontalRange
        // Camera Y increases downward; gaze Y increases upward.
        val targetY = deadZone((0.5f - detection.centerY.coerceIn(0f, 1f)) * 2f) * verticalRange
        val old = state
        val alpha = smoothing.coerceIn(0.01f, 1f)
        val x = lerp(old.leftX, targetX, alpha).coerceIn(-1f, 1f)
        val y = lerp(old.leftY, targetY, alpha).coerceIn(-1f, 1f)
        state = State(x, y, x, y, detection.confidence.coerceIn(0f, 1f), true, nowMs)
        return state
    }

    fun reset(nowMs: Long = System.currentTimeMillis()): State {
        state = State(timestampMs = nowMs)
        return state
    }

    fun current(): State = state

    private fun deadZone(value: Float): Float =
        if (abs(value) <= deadZone) 0f else value

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t
}
