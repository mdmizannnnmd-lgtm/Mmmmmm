package com.mizan

import kotlin.math.abs
import kotlin.math.max

/**
 * CENTROID — the centre of mass of everything that is active on the body right now.
 * Every ring on the 3D body (outside + inside), both brain hemispheres and the body-motion offsets vote with their live
 * energy at their place on the body. The result is one point [cx],[cy] (body units, y up) and one strength [strength].
 *
 *  · LEVEL scales every vote, THRESHOLD ignores votes below it (soft knee). RAW COMPLETE: no level, no threshold.
 *  · [followX]/[followY] move the whole body model so the centroid drifts toward the screen centre (all motions centred
 *    on the active point). [pull] is how strongly; 0 = fixed.
 *  · [strength] joins the oneness field, so ambient, motion, body models and the Sound Bank all react to it.
 */
class CentroidHub {
    @Volatile var enabled = true
    @Volatile var level = 0.85f
    @Volatile var thr = 0.12f
    @Volatile var followX = 0.6f
    @Volatile var followY = 0.3f
    @Volatile var wRings = 0.8f
    @Volatile var wBrain = 0.8f
    @Volatile var raw = false

    @Volatile var cx = 0f
        private set
    @Volatile var cy = 0.6f
        private set
    @Volatile var strength = 0f
        private set
    @Volatile var active = false
        private set
    @Volatile var xOffset = 0f      // add to anatomy3d.posX
        private set
    @Volatile var yOffset = 0f      // add to anatomy3d.posY
        private set

    private var sx = 0f
    private var sy = 0.6f

    private fun vote(e: Float): Float {
        val x = e.coerceIn(0f, 1f)
        if (raw) return x
        val t = thr.coerceIn(0f, 0.98f)
        return if (x <= t) 0f else ((x - t) / (1f - t)) * level.coerceIn(0f, 1.5f)
    }

    fun tick(v: VisualShieldView) {
        if (!enabled) { strength = 0f; active = false; xOffset = 0f; yOffset = 0f; return }
        var wsum = 0f; var xs = 0f; var ys = 0f; var n = 0
        if (v.ringBoard.enabled) {
            for (r in v.ringBoard.rings) {
                if (!r.on) continue
                val w = vote(max(r.outOut, r.inOut)) * wRings
                if (w <= 0f) continue
                val a = r.outside
                wsum += w; xs += a.x * w; ys += a.y * w; n++
            }
        }
        if (v.brain3d.enabled) {
            val l = vote(v.brain3d.left.out) * wBrain
            val rr = vote(v.brain3d.right.out) * wBrain
            wsum += l + rr
            xs += -0.05f * l + 0.05f * rr
            ys += 1.58f * (l + rr)
            if (l > 0f || rr > 0f) n++
        }
        active = wsum > 0.001f
        if (active) {
            val tx = xs / wsum; val ty = ys / wsum
            val k = if (raw) 1f else 0.25f                 // smoothing of the point itself
            cx += (tx - cx) * k
            cy += (ty - cy) * k
        }
        strength = (wsum / (v.ringBoard.rings.size + 2).coerceAtLeast(1)).coerceIn(0f, 1f)
        // pull the active point toward the screen centre (body centre y ≈ 0.6 body units)
        val goalX = if (active) (-cx * followX * 0.10f) else 0f
        val goalY = if (active) (-(cy - 0.6f) * followY * 0.06f) else 0f
        val s = if (raw) 1f else 0.12f
        sx += (goalX - sx) * s
        sy += (goalY - sy) * s
        xOffset = sx
        yOffset = sy
    }

    fun statusLine(): String {
        if (!enabled) return "CENTROID off"
        return "CENTROID · x=${"%+.2f".format(cx)} y=${"%+.2f".format(cy)} · strength=${(strength * 100).toInt()}% · " +
            (if (active) "ACTIVE" else "idle") + (if (raw) " · RAW COMPLETE" else " · thr=${(thr * 100).toInt()}% lv=${(level * 100).toInt()}%")
    }

    fun offCentre(): Float = max(abs(cx), abs(cy - 0.6f))
}
