package com.mizan

import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

/**
 * Multi-platform AI API keys · ChatGPT/OpenAI · optional other OpenAI-compatible endpoints.
 * For your own keys and allowed use only. RAW COMPLETE.
 */
class AiPlatformApiBoard {

    enum class Platform(val label: String, val defaultBase: String) {
        OPENAI("ChatGPT / OpenAI", "https://api.openai.com/v1"),
        OPENAI_COMPAT("OpenAI-compatible", "https://api.openai.com/v1"),
        CUSTOM("Custom HTTPS base", "")
    }

    @Volatile var enabled = true
    @Volatile var platform = Platform.OPENAI
    @Volatile var apiKey = ""
    @Volatile var baseUrl = Platform.OPENAI.defaultBase
    @Volatile var model = "gpt-4o-mini"
    @Volatile var systemPrompt = "You are a helpful assistant inside the Mizan ambient anatomy app."
    @Volatile var userPrompt = "Say hello in one short sentence."
    @Volatile var temperature = 0.7f
    @Volatile var maxTokens = 512

    @Volatile var busy = false
    @Volatile var lastResponse = ""
    @Volatile var lastError = ""
    @Volatile var lastCode = 0
    @Volatile var status = "AI API idle"

    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun selectPlatform(p: Platform) {
        platform = p
        if (p.defaultBase.isNotEmpty()) baseUrl = p.defaultBase
    }

    fun sendChat(onDone: (() -> Unit)? = null) {
        if (!enabled) {
            status = "AI API OFF"
            onDone?.let { main.post(it) }
            return
        }
        if (apiKey.isBlank()) {
            lastError = "API key empty"
            status = "AI API: set key"
            onDone?.let { main.post(it) }
            return
        }
        if (busy) {
            status = "AI API busy…"
            return
        }
        busy = true
        status = "AI API sending…"
        val key = apiKey.trim()
        val base = baseUrl.trim().trimEnd('/')
        val mdl = model.trim().ifEmpty { "gpt-4o-mini" }
        val sys = systemPrompt
        val usr = userPrompt
        val temp = temperature.toDouble()
        val maxT = maxTokens

        exec.execute {
            var code = 0
            var body = ""
            var err = ""
            try {
                val url = URL("$base/chat/completions")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 60000
                    doInput = true
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $key")
                    setRequestProperty("Content-Type", "application/json")
                }
                val payload = JSONObject().apply {
                    put("model", mdl)
                    put("temperature", temp)
                    put("max_tokens", maxT)
                    put("messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content", sys))
                        .put(JSONObject().put("role", "user").put("content", usr)))
                }
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use {
                    it.write(payload.toString()); it.flush()
                }
                code = conn.responseCode
                val stream = try {
                    if (code in 200..299) conn.inputStream else conn.errorStream
                } catch (_: Throwable) { null }
                body = if (stream != null) BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() } else ""
                conn.disconnect()
                if (code in 200..299) {
                    try {
                        val json = JSONObject(body)
                        val content = json.getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content")
                        body = content
                    } catch (_: Throwable) {
                        // keep raw body
                    }
                }
            } catch (t: Throwable) {
                err = t.javaClass.simpleName + ": " + (t.message ?: "")
            }
            main.post {
                lastCode = code
                lastError = err
                lastResponse = body.take(50_000)
                busy = false
                status = if (err.isNotEmpty()) "AI ERR $err"
                else if (code !in 200..299) "AI HTTP $code"
                else "AI OK $code · ${lastResponse.length} chars"
                onDone?.invoke()
            }
        }
    }
}
