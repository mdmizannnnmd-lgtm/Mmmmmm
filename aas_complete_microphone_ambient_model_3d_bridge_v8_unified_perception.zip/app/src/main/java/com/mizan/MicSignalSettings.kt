package com.mizan

/** Runtime thresholds for the microphone-to-system event bridge. */
object MicSignalSettings {
    @Volatile var silenceDbfs: Float = -55f
    @Volatile var activeDbfs: Float = -35f
    @Volatile var burstPeak: Float = 0.92f
    @Volatile var lowHzMax: Float = 250f
    @Volatile var highHzMin: Float = 4000f
    @Volatile var toneCentroidTolerance: Float = 0.08f
    @Volatile var enabled: Boolean = true
}
