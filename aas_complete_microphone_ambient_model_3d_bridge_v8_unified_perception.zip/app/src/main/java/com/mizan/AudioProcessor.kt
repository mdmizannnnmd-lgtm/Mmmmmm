package com.mizan

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class AudioProcessor {

    private var audioRecord: AudioRecord? = null
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var isRecording = false
    val microphoneConnected: Boolean get() = isRecording
    private var mainActivity: MainActivity? = null

    private var amplifierGain = 1.85f
    private var baseThreshold = 52
    private var atmosphereLevel = 0.65f

    // New Threshold Feedback Parameters
    private var thresholdDb = 60
    private var feedbackGain = 0.5f
    private var decayTimeMs = 50

    private var recentAverageRMS = 0.05f
    private var lastTriggerDb = -999.0
    private var triggerCount = 0
    val armor = BodyArmorShield()
    val ultrasound = UltrasoundGuard()
    val uiBlock = UiIntensityBlocker()
    val echo = EchoEngine()
    val ambientBoard = AmbientThresholdBoard()
    /** Live FFT of the real microphone: spectrum bars, centroid Hz, dominant Hz, atmo %, dBFS. */
    val analyzer = LiveSpectrumAnalyzer()
    /** Optional generic sound-level cue; it does not classify a weapon or injury. */
    val soundAlert = AmbientSoundAlert()
    /** Screen sounds pitch protection, LEFT and RIGHT. */
    val pitch = StereoPitchGuard()
    private var channels = 1
    private val sampleRate = 44100
    @Volatile var lastCurrentDb = -80.0
    var systemGuardRef: SystemGuardEngine? = null
    var screenAmbientRef: ScreenAmbientBoard? = null
    var soundBankRef: SoundBankGuard? = null
    var bodySoundFxRef: BodySoundFx? = null
    @Volatile var videoFeedbackRef: VideoFeedbackBoard? = null
    @Volatile var audioColourRef: AudioColourBoard? = null

    private val handler = Handler(Looper.getMainLooper())

    fun startListening(activity: MainActivity) {
        this.mainActivity = activity
        if (isRecording) return

        val enc = AudioFormat.ENCODING_PCM_16BIT
        var rec: AudioRecord? = null
        var ch = 1

        // real stereo first, so LEFT and RIGHT can be pitch-protected separately
        val minStereo = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_STEREO, enc)
        if (minStereo > 0) {
            rec = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate,
                    AudioFormat.CHANNEL_IN_STEREO, enc, minStereo * 4)
            } catch (e: Exception) {
                null
            }
            if (rec != null && rec.state == AudioRecord.STATE_INITIALIZED) {
                ch = 2
            } else {
                rec?.release()
                rec = null
            }
        }
        // fall back to mono (L = R)
        if (rec == null) {
            val minMono = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, enc)
            rec = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate,
                    AudioFormat.CHANNEL_IN_MONO, enc, minMono * 4)
            } catch (e: Exception) {
                null
            }
            ch = 1
        }

        audioRecord = rec
        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            Log.e("AudioProcessor", "AudioRecord failed")
            try { audioRecord?.release() } catch (_: Exception) {}
            audioRecord = null
            return
        }
        channels = ch
        pitch.stereoLive = ch == 2

        audioRecord?.startRecording()
        isRecording = true
        executor.execute(::processAudio)

        startAutoAtmosphereUpdater()
    }

    private fun processAudio() {
        val ch = channels
        val frames = 2048
        val buffer = ShortArray(frames * ch)
        val mono = ShortArray(frames)
        val leftBuf = ShortArray(frames)
        val rightBuf = ShortArray(frames)
        while (isRecording) {
            val read = try {
                audioRecord?.read(buffer, 0, buffer.size) ?: 0
            } catch (e: Exception) {
                if (!isRecording) break
                RawMicDiagnostics.onReadError()
                Log.w("AudioProcessor", "Microphone read failed", e)
                0
            }
            if (read <= 0) {
                if (read == 0) RawMicDiagnostics.onEmptyRead()
                if (read < 0) {
                    try { Thread.sleep(10) } catch (e: InterruptedException) {}
                }
                continue
            }
            val n = read / ch
            if (n <= 0) continue

            // split into LEFT / RIGHT plus a mono mix for the existing analysis path
            if (ch == 2) {
                for (i in 0 until n) {
                    val l = buffer[2 * i]
                    val r = buffer[2 * i + 1]
                    leftBuf[i] = l
                    rightBuf[i] = r
                    mono[i] = ((l.toInt() + r.toInt()) / 2).toShort()
                }
            } else {
                for (i in 0 until n) {
                    val v = buffer[i]
                    leftBuf[i] = v
                    rightBuf[i] = v
                    mono[i] = v
                }
            }

            val rms = calculateRMS(mono, n) * amplifierGain
            recentAverageRMS = (recentAverageRMS * 0.75f + rms * 0.25f)
            ultrasound.processPcm(mono, n)

            // Screen sounds pitch protection (LEFT / RIGHT). RAW COMPLETE leaves everything untouched.
            pitch.process(leftBuf, rightBuf, n)
            val pitchDamp = pitch.damp()
            val shield = (1f - pitchDamp * 0.8f).coerceIn(0.2f, 1f)
            val energy = recentAverageRMS * shield

            uiBlock.tick(energy, ultrasound.liveBand)
            echo.tick(energy)

            val currentDb = 20 * Math.log10(max(rms.toDouble(), 0.00001))
            lastCurrentDb = currentDb
            val peakApprox = max(rms, energy * 1.2f)
            analyzer.process(mono, n)
            // Publish the exact PCM16 microphone frame to the single global raw bus.
            RawMicBus.publish(mono, n, sampleRate, ch, analyzer.domHz, analyzer.centroidHz, buffer, read)
            soundAlert.update(analyzer.peakDbfs, analyzer.centroidHz)
            val spectrum = analyzer.bands
            fun bandMean(first: Int, last: Int): Float {
                var total = 0f
                var count = 0
                for (i in first..last) {
                    total += spectrum.getOrElse(i) { 0f }
                    count++
                }
                return if (count == 0) 0f else total / count
            }
            val audioBands = floatArrayOf(
                bandMean(0, 10), bandMean(11, 23), bandMean(24, 39),
                bandMean(40, 53), bandMean(54, 63)
            )
            videoFeedbackRef?.feedAudio(
                energy.coerceIn(0f, 1f),
                audioBands[0], audioBands[1], audioBands[2], audioBands[3], audioBands[4],
                analyzer.hzToX(analyzer.centroidHz)
            )
            audioColourRef?.tick(energy.coerceIn(0f, 1f), audioBands)
            videoFeedbackRef?.tick(energy.coerceIn(0f, 1f))
            bodySoundFxRef?.feedAudio(
                energy.coerceIn(0f, 1f),
                analyzer.centroidHz
            )
            ambientBoard.feedAnalysis(analyzer, currentDb)
            ambientBoard.tick(energy, peakApprox, currentDb)
            screenAmbientRef?.tick(energy, currentDb, 0f, 0f, energy)
            // Mic-driven sound bank (real microphone dB ±1000 path)
            val sb = soundBankRef
            sb?.feedAudioAnalysis(
                energy, analyzer.domHz, analyzer.centroidHz,
                analyzer.rmsDbfs, analyzer.peakDbfs
            )
            sb?.tick(energy, currentDb.coerceIn(-1000.0, 1000.0), peakApprox,
                enemyE = energy, // mic energy as enemy-sound probe when hot
                enemyMove = energy,
                enemySpeed = energy,
                enemyWave = energy)
            // Apply enemy communication blocker to feedback path
            val commScale = sb?.enemyCommScale ?: 1f
            val prot = sb?.protectMoveFactor ?: 1f
            systemGuardRef?.tick(
                energy * ambientBoard.gateFactor(),
                energy * ambientBoard.gateFactor(),
                ambientBoard.limitedDb
            )

            // Threshold Feedback Logic (+ real ultrasound protect + pitch protect)
            val ultraDamp = ultrasound.protectDamp()
            val effThr = armor.effectiveThresholdDb(thresholdDb) + ((ultraDamp + pitchDamp) * 12f).toInt()
            val mag = ((currentDb - effThr) / 40.0).coerceIn(0.0, 1.0).toFloat()
            val clamped = armor.clampSpikeMagnitude(mag)
            if (currentDb > effThr && clamped > 0.35f) {
                triggerCount++
                lastTriggerDb = currentDb
                mainActivity?.runOnUiThread {
                    val phys = armor.physicalAudioLabel()
                    mainActivity?.updateAudioStatus(
                        if (clamped < 0.5f) "ARMORED / BLOCKED · $phys"
                        else "HIGH POWER · $phys"
                    )
                }
            }

            val pitchTag = buildString {
                if (pitch.left.active) append(" · PITCH-L")
                if (pitch.right.active) append(" · PITCH-R")
            }
            val status = (if (rms > baseThreshold * 0.8) "HIGH POWER / THREAT" else "Low") + pitchTag
            mainActivity?.runOnUiThread {
                mainActivity?.updateAudioStatus(status)
            }
        }
    }

    private fun calculateRMS(buffer: ShortArray, length: Int): Float {
        var sum = 0L
        for (i in 0 until length) sum += buffer[i].toLong() * buffer[i]
        return (Math.sqrt(sum.toDouble() / length) / 32768.0).toFloat()
    }

    private fun startAutoAtmosphereUpdater() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                atmosphereLevel = if (recentAverageRMS > 0.18f) 0.82f else if (recentAverageRMS > 0.08f) 0.68f else 0.48f
                handler.postDelayed(this, 7000)
            }
        }, 1500)
    }

    // New Adjustable Methods
    fun setThresholdDb(value: Int) { thresholdDb = -value }   // negative dB
    fun setFeedbackGain(value: Int) { feedbackGain = value / 100f }
    fun setDecayTimeMs(value: Int) { decayTimeMs = value }
    fun setEchoThreshold(v: Float) { echo.threshold = v.coerceIn(0f, 1f) }
    fun setEchoDecayMs(v: Int) { echo.decayMs = v.coerceIn(20, 5000); decayTimeMs = echo.decayMs }
    fun setEchoFeedback(v: Float) { echo.feedback = v.coerceIn(0f, 1f) }
    fun setEchoEnabled(on: Boolean) { echo.enabled = on }

    fun setAmbientThrPct(v: Float) {
        ambientBoard.ambientThrPct = v.coerceIn(0f, 100f)
        if (!ambientBoard.liveOutput) ambientBoard.lockedPct = ambientBoard.ambientThrPct
    }
    fun setAmbientLive(on: Boolean) { ambientBoard.liveOutput = on }
    fun setAmbientLockedPct(v: Float) { ambientBoard.lockedPct = v.coerceIn(0f, 100f) }
    fun setAmbientBipolarNeg(v: Float) { ambientBoard.bipolarNeg = v.coerceIn(-120f, 0f) }
    fun setAmbientBipolarPos(v: Float) { ambientBoard.bipolarPos = v.coerceIn(0f, 120f) }
    fun setThrGainDb(v: Float) {
        // legacy single → map to pos if positive else neg
        val c = v.coerceIn(-300f, 300f)
        if (c >= 0f) ambientBoard.thrGainPosDb = c else ambientBoard.thrGainNegDb = c
    }
    fun setThrGainNegDb(v: Float) { ambientBoard.thrGainNegDb = v.coerceIn(-300f, 0f) }
    fun setThrGainPosDb(v: Float) { ambientBoard.thrGainPosDb = v.coerceIn(0f, 300f) }
    fun setLimiterDb(v: Float) { ambientBoard.limiterDb = v.coerceIn(-300f, 300f) }
    fun setLimiterOn(on: Boolean) { ambientBoard.limiterOn = on }
    fun setAmbientDecayMs(v: Int) { ambientBoard.decayMidMs = v.coerceIn(10, 5000) }
    fun setAmbientDecayFastMs(v: Int) { ambientBoard.decayFastMs = v.coerceIn(10, 5000) }
    fun setAmbientDecayMidMs(v: Int) { ambientBoard.decayMidMs = v.coerceIn(10, 5000) }
    fun setAmbientDecaySlowMs(v: Int) { ambientBoard.decaySlowMs = v.coerceIn(10, 5000) }
    fun setAmbientDecayWFast(v: Float) { ambientBoard.decayFastW = v.coerceIn(0f, 1f) }
    fun setAmbientDecayWMid(v: Float) { ambientBoard.decayMidW = v.coerceIn(0f, 1f) }
    fun setAmbientDecayWSlow(v: Float) { ambientBoard.decaySlowW = v.coerceIn(0f, 1f) }
    fun setAmbientMirror(on: Boolean) { ambientBoard.mirrorOn = on }
    fun setAmbientBoardEnabled(on: Boolean) { ambientBoard.enabled = on }

    fun setAmplifierGain(percent: Int) { amplifierGain = (percent / 100f) * 2.2f }
    fun setBaseThreshold(value: Int) { baseThreshold = value }

    fun stopListening() {
        isRecording = false
        handler.removeCallbacksAndMessages(null)
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        RawMicBus.clear()
    }
}