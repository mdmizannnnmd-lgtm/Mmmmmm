package com.mizan

/**
 * Pointer / bullet sounds · linear frequency path + burst protection.
 * Linear Hz ramp (not log) for click/impulse/bullet-like transients.
 * Detect · threshold · protect · damp SoundBank bullet/burst. RAW COMPLETE.
 */
class PointerBulletLinearFreqBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Linear frequency window for pointer/bullet-like impulses (Hz)
    @Volatile var linearHzMin = 80f
    @Volatile var linearHzMax = 12000f
    @Volatile var linearHzNow = 0f
    @Volatile var linearSlope = 1f          // Hz per unit energy (linear map)
    @Volatile var pointerHz = 0f
    @Volatile var bulletHz = 0f
    @Volatile var burstHz = 0f

    // Detection level
    @Volatile var thrDb = -42f
    @Volatile var levelAmt = 0.95f
    @Volatile var pointerOut = 0f
    @Volatile var bulletOut = 0f
    @Volatile var burstOut = 0f

    // Burst protection
    @Volatile var burstProtectOn = true
    @Volatile var burstProtectThr = 0.22f
    @Volatile var burstProtectLv = 0.96f
    @Volatile var burstProtectOut = 0f

    // Pointer / bullet protect
    @Volatile var pointerProtectOn = true
    @Volatile var bulletProtectOn = true
    @Volatile var pointerProtectOut = 0f
    @Volatile var bulletProtectOut = 0f

    @Volatile var status = "PTR·BULLET·LINEAR idle"

    /** Linear map energy 0..1.5 → Hz in [min,max] (not logarithmic). */
    private fun linearHz(energy: Float): Float {
        val e = energy.coerceIn(0f, 1.5f)
        val t = (e / 1.5f).coerceIn(0f, 1f)
        return linearHzMin + (linearHzMax - linearHzMin) * t * linearSlope.coerceIn(0.1f, 3f)
    }

    private fun lane(x: Float, thr: Float): Float {
        val e = x.coerceIn(0f, 1.5f)
        if (rawComplete) return (e * levelAmt).coerceIn(0f, 1f)
        return if (e >= thr) ((e - thr) / (1.2f - thr).coerceAtLeast(0.05f) * levelAmt).coerceIn(0f, 1f) else 0f
    }

    /**
     * @param mic energy 0..1.5
     * @param sbBullet / sbBurst existing bank meters
     * @param detectedHz optional external Hz estimate (0 = derive linear from energy)
     */
    fun tick(mic: Float, sbBullet: Float, sbBurst: Float, detectedHz: Float = 0f) {
        if (!enabled) {
            status = "PTR·BULLET OFF"
            return
        }
        val e = mic.coerceIn(0f, 1.5f)
        linearHzNow = if (detectedHz > 1f) detectedHz.coerceIn(linearHzMin, linearHzMax) else linearHz(e)

        // Pointer: short high-slope clicks in upper-mid linear band
        val ptrBand = ((linearHzNow - 2000f) / 6000f).coerceIn(0f, 1f)
        pointerHz = linearHzNow
        pointerOut = lane(e * (0.4f + ptrBand * 0.8f) + sbBullet * 0.3f, 0.18f)

        // Bullet: impulse across wide linear span
        bulletHz = linearHzNow
        bulletOut = lane(maxOf(e, sbBullet) * 0.95f, 0.16f)

        // Burst: clustered energy
        burstHz = linearHz(maxOf(e, sbBurst))
        burstOut = lane(maxOf(e * 0.9f, sbBurst), 0.15f)

        // Protection outs
        burstProtectOut = if (burstProtectOn) lane(burstOut, burstProtectThr) * burstProtectLv else 0f
        pointerProtectOut = if (pointerProtectOn) pointerOut * levelAmt else 0f
        bulletProtectOut = if (bulletProtectOn) bulletOut * levelAmt else 0f

        if (rawComplete) {
            burstProtectOut = maxOf(burstProtectOut, 0.2f + burstOut * 0.5f)
            bulletProtectOut = maxOf(bulletProtectOut, 0.2f + bulletOut * 0.5f)
        }

        status =
            "LIN ${linearHzNow.toInt()}Hz [${linearHzMin.toInt()}-${linearHzMax.toInt()}] · " +
            "ptr=${(pointerOut*100).toInt()}% ${pointerHz.toInt()}Hz · " +
            "bullet=${(bulletOut*100).toInt()}% ${bulletHz.toInt()}Hz · " +
            "burst=${(burstOut*100).toInt()}% prot=${(burstProtectOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!enabled) return
        val bank = sb ?: return
        try {
            if (bulletProtectOut > 0.02f) {
                bank.bulletOut *= (1f - bulletProtectOut * 0.95f).coerceIn(0.03f, 1f)
            }
            if (burstProtectOut > 0.02f) {
                bank.burstOut *= (1f - burstProtectOut * 0.95f).coerceIn(0.03f, 1f)
            }
            if (pointerProtectOut > 0.02f) {
                bank.sharpOut *= (1f - pointerProtectOut * 0.85f).coerceIn(0.05f, 1f)
            }
        } catch (_: Throwable) {}
        val vv = v ?: return
        try {
            vv.sharpBurstMeter.burstMeter = maxOf(vv.sharpBurstMeter.burstMeter, burstOut)
            vv.sharpBurstMeter.burstHz = maxOf(vv.sharpBurstMeter.burstHz, burstHz)
            vv.enemySoundCancel.burstCancelOut = maxOf(vv.enemySoundCancel.burstCancelOut, burstProtectOut)
        } catch (_: Throwable) {}
    }
}
