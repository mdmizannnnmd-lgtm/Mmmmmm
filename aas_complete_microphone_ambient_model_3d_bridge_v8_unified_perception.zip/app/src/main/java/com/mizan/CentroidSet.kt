package com.mizan

import kotlin.math.max

/**
 * CENTROID SET — four more centroids next to the original [CentroidHub], each with its own LEVEL · THRESHOLD · RAW:
 *
 *   MODEL    full body model — the 84 body channels on the 3D body (every channel votes with its live output)
 *   AMBIENT  all body ambient — every body region's ambient (forehead … legs) at its place on the body
 *   BODY     body tracking — rings of torso / limbs / pelvis weighted by the body mixer (pose · YOLO · sound) energy
 *   MASTER   the new one — the strength-weighted centre of RINGS (original centroid), MODEL, AMBIENT and BODY together
 *
 * MASTER can take over centring all body models ([useMaster]); the original centroid stays untouched and still feeds MASTER.
 * Read-only: nothing here changes any board except the centring offsets and the oneness field.
 */
class CentroidSet {

    class Cen(val key: String, val label: String) {
        @Volatile var on = true
        @Volatile var level = 0.85f
        @Volatile var thr = 0.10f
        @Volatile var raw = false
        @Volatile var cx = 0f
            internal set
        @Volatile var cy = 0.6f
            internal set
        @Volatile var strength = 0f
            internal set
        @Volatile var active = false
            internal set
        internal var wsum = 0f; internal var xs = 0f; internal var ys = 0f

        fun begin() { wsum = 0f; xs = 0f; ys = 0f }
        fun vote(x: Float, y: Float, e: Float) {
            val v = shape(e)
            if (v <= 0f) return
            wsum += v; xs += x * v; ys += y * v
        }
        fun shape(e: Float): Float {
            val x = e.coerceIn(0f, 1f)
            if (raw) return x
            val t = thr.coerceIn(0f, 0.98f)
            return if (x <= t) 0f else ((x - t) / (1f - t)) * level.coerceIn(0f, 1.5f)
        }
        fun finish(count: Int) {
            if (!on) { active = false; strength = 0f; return }
            active = wsum > 0.001f
            if (active) {
                val k = if (raw) 1f else 0.25f
                cx += (xs / wsum - cx) * k
                cy += (ys / wsum - cy) * k
            }
            strength = (wsum / count.coerceAtLeast(1)).coerceIn(0f, 1f)
        }
        fun status(): String = if (!on) "$label off" else
            "$label x=${"%+.2f".format(cx)} y=${"%+.2f".format(cy)} ${(strength * 100).toInt()}%" +
                (if (active) "" else " idle") + (if (raw) " RAW" else "")
    }

    val model = Cen("model", "MODEL")
    val ambient = Cen("ambient", "AMBIENT")
    val body = Cen("body", "BODY")
    val master = Cen("master", "MASTER")
    val all = listOf(model, ambient, body, master)

    @Volatile var enabled = true
    @Volatile var useMaster = true
    @Volatile var followX = 0.6f
    @Volatile var followY = 0.3f
    @Volatile var xOffset = 0f
        private set
    @Volatile var yOffset = 0f
        private set
    private var sx = 0f
    private var sy = 0f

    fun setRaw(on: Boolean) { for (c in all) c.raw = on }

    fun tick(v: VisualShieldView) {
        if (!enabled) { xOffset = 0f; yOffset = 0f; for (c in all) { c.strength = 0f; c.active = false }; return }
        val rb = v.ringBoard
        val rawAny = model.raw || ambient.raw || body.raw

        // MODEL — 84 channels
        model.begin()
        val n = rb.channelAnchors.size
        for (i in 0 until n) {
            val a = rb.channelAnchors[i]
            model.vote(a[0], a[1], rb.channelOut.getOrElse(i) { 0f })
        }
        model.finish(n)

        // AMBIENT — every body region ambient at its ring position
        ambient.begin()
        for (r in rb.rings) {
            val reg = r.region ?: continue
            val e = if (ambient.raw) reg.ambient else reg.effectiveAmbient()
            ambient.vote(r.outside.x, r.outside.y, e)
        }
        ambient.finish(rb.rings.size)

        // BODY — torso / limbs / pelvis rings weighted by the body-model mix energy
        body.begin()
        val mix = v.bodyMixer.mixedE.coerceIn(0f, 1f)
        val tracked = max(mix, max(v.poseSurface.dampen(), v.yoloSeg.dampen()))
        var cnt = 0
        for (r in rb.rings) {
            if (r.group != AnatomyRingBoard.G_TORSO && r.group != AnatomyRingBoard.G_LIMBS && r.group != AnatomyRingBoard.G_PELVIS) continue
            cnt++
            body.vote(r.outside.x, r.outside.y, (max(r.outOut, r.inOut) * (0.4f + 0.6f * tracked)).coerceIn(0f, 1f))
        }
        body.finish(cnt)

        // MASTER — strength-weighted mix of every centroid (RINGS = the original one)
        master.begin()
        val o = v.centroid
        val parts = listOf(
            Triple(o.cx, o.cy, o.strength), Triple(model.cx, model.cy, model.strength),
            Triple(ambient.cx, ambient.cy, ambient.strength), Triple(body.cx, body.cy, body.strength)
        )
        var ws = 0f; var xs = 0f; var ys = 0f
        for ((x, y, s) in parts) { val w = master.shape(s); ws += w; xs += x * w; ys += y * w }
        master.wsum = ws; master.xs = xs; master.ys = ys
        master.finish(1)
        master.strength = (ws / parts.size).coerceIn(0f, 1f)

        val src = if (useMaster) master else null
        val goalX = if (src != null && src.active) -src.cx * followX * 0.10f else 0f
        val goalY = if (src != null && src.active) -(src.cy - 0.6f) * followY * 0.06f else 0f
        val s = if (rawAny) 1f else 0.12f
        sx += (goalX - sx) * s
        sy += (goalY - sy) * s
        xOffset = sx; yOffset = sy
    }

    fun statusLine(): String = if (!enabled) "CENTROIDS off" else all.joinToString(" · ") { it.status() }
}
