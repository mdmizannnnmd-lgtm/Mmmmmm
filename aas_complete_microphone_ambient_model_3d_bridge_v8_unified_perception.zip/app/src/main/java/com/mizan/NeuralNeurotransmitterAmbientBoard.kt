package com.mizan

/**
 * Neural + neurotransmitter ambient (glutamate, GABA, ACh, dopamine, NE, serotonin, glycine…).
 * Neuron 3D field · healing/repair frequency · bad-neural threshold · safe-neuron protect.
 * Chemical ambient + particles. Symbolic only. RAW COMPLETE.
 */
class NeuralNeurotransmitterAmbientBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.30f
    @Volatile var levelAmt = 0.90f

    // Classic transmitters
    @Volatile var glutamate = 0f
    @Volatile var gaba = 0f
    @Volatile var acetylcholine = 0f
    @Volatile var dopamine = 0f
    @Volatile var norepinephrine = 0f
    @Volatile var serotonin = 0f
    @Volatile var glycine = 0f
    @Volatile var histamine = 0f
    @Volatile var endorphin = 0f

    // Neuron field
    @Volatile var neuronField = 0f
    @Volatile var synapseDensity = 0f
    @Volatile var axonSignal = 0f
    @Volatile var dendriteRecv = 0f

    // Bad neural / repair
    @Volatile var badNeuralThr = 0.72f
    @Volatile var badNeuralOut = 0f
    @Volatile var repairFreqHz = 7.83f
    @Volatile var healFreqHz = 40f
    @Volatile var repairOut = 0f
    @Volatile var healOut = 0f
    @Volatile var safeNeuronOut = 0f

    @Volatile var neuralFull = 0f
    @Volatile var status = "NEURAL idle"

    private fun lane(e: Float): Float {
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * levelAmt).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * levelAmt).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, brain: Float, cns: Float) {
        if (!enabled) { status = "NEURAL OFF"; return }
        val e = maxOf(mic * 0.6f, brain, cns).coerceIn(0f, 1.5f)
        glutamate = lane(e * 0.96f)
        gaba = lane(e * 0.90f)
        acetylcholine = lane(e * 0.92f)
        dopamine = lane(e * 0.88f)
        norepinephrine = lane(e * 0.87f)
        serotonin = lane(e * 0.89f)
        glycine = lane(e * 0.84f)
        histamine = lane(e * 0.82f)
        endorphin = lane(e * 0.85f)
        neuronField = lane(e * 0.95f)
        synapseDensity = lane(e * 0.91f)
        axonSignal = lane(e * 0.93f)
        dendriteRecv = lane(e * 0.90f)
        neuralFull = maxOf(glutamate, gaba, acetylcholine, dopamine, neuronField, synapseDensity)
        badNeuralOut = if (e > badNeuralThr) ((e - badNeuralThr) * 1.4f).coerceIn(0f, 1f) else 0f
        // repair / heal symbolic strength from inverse bad + base
        repairOut = ((1f - badNeuralOut) * (repairFreqHz / 20f).coerceIn(0.2f, 1f) * levelAmt).coerceIn(0f, 1f)
        healOut = ((1f - badNeuralOut * 0.7f) * (healFreqHz / 80f).coerceIn(0.2f, 1f) * levelAmt).coerceIn(0f, 1f)
        safeNeuronOut = (neuronField * (1f - badNeuralOut) * repairOut).coerceIn(0f, 1f)
        if (rawComplete) neuralFull = maxOf(neuralFull, 0.3f + e * 0.4f)
        status = "NEURAL full=${(neuralFull*100).toInt()}% · Glu/GABA/ACh=${(glutamate*100).toInt()}/${(gaba*100).toInt()}/${(acetylcholine*100).toInt()} · " +
            "safe=${(safeNeuronOut*100).toInt()}% repair=${repairFreqHz.toInt()}Hz heal=${healFreqHz.toInt()}Hz" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView?) {
        if (!enabled || neuralFull < 0.02f) return
        val vv = v ?: return
        try {
            vv.bodyChemBrain.brainFullOut = maxOf(vv.bodyChemBrain.brainFullOut, neuralFull)
            vv.fullAnatomy132.brainOut = maxOf(vv.fullAnatomy132.brainOut, neuralFull * 0.8f)
            vv.anatomy3d.layerLevel[4] = maxOf(vv.anatomy3d.layerLevel[4], neuronField)
            vv.bodyFreqRegen.ownRegenOut = maxOf(vv.bodyFreqRegen.ownRegenOut, repairOut, healOut)
            vv.completeAtomProtect.atomInsideOut = maxOf(vv.completeAtomProtect.atomInsideOut, safeNeuronOut)
            vv.finalProtectionMain.brainAnatOut = maxOf(vv.finalProtectionMain.brainAnatOut, neuralFull * 0.7f)
        } catch (_: Throwable) {}
    }
}
