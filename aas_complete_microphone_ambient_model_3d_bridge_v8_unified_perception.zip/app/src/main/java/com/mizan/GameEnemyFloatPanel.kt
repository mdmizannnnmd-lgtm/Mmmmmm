package com.mizan

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * FLOATING 3D-GAME CONTROL BUTTONS (left edge, same look as the right-hand fire buttons).
 *
 *   GAME▾   fold / unfold the column
 *   ◀ SEL ▶ pick the previous / next figure (YOU · enemy · devices) — or just tap a figure on the game board
 *   IN-ROT  inside rotation of the selected figure on / off      PITCH  head pitch on / off
 *   SUPER   selected settings drive EVERY tracked figure         RAW    RAW COMPLETE (no level · threshold · smoothing)
 *   LOCK    freeze at the touch offsets                          RST    reset the touch offsets
 *   SET     sheet with LEVEL · THRESHOLD · RANGE · BIPOLAR · per-channel RAW
 *
 * Touch on the board: tap = select · drag sideways = inside rotation · drag up / down = head pitch · long press = reset.
 */
object GameEnemyFloatPanel {

    @SuppressLint("ClickableViewAccessibility")
    fun install(ctx: Context, parent: ViewGroup, view: VisualShieldView) {
        val world = view.gameWorld
        val ctl = world.ctl
        ctl.loadGlobals()
        fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

        // ── touch on the game board (only consumes touches that start on a figure) ──
        view.setOnTouchListener { _, ev -> ctl.onTouch(ev, world) }

        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#99000000"))
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        val lp = RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            addRule(RelativeLayout.ALIGN_PARENT_START)
            addRule(RelativeLayout.ALIGN_PARENT_TOP)
            topMargin = dp(118)
            marginStart = dp(6)
        }
        parent.addView(col, lp)

        val body = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val header = Button(ctx).apply {
            text = "GAME▾"; textSize = 10f; setTextColor(Color.parseColor("#80DEEA"))
            backgroundTintList = ColorStateList.valueOf(Color.parseColor("#66003344"))
            setPadding(0, 0, 0, 0); minWidth = 0; minHeight = 0; minimumWidth = 0; minimumHeight = 0
        }
        col.addView(header, LinearLayout.LayoutParams(dp(74), dp(36)))
        col.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fun bbtn(text: String, color: String, tint: String = "#66330000", onClick: (Button) -> Unit): Button {
            val b = Button(ctx).apply {
                this.text = text; textSize = 10f; setTextColor(Color.parseColor(color))
                backgroundTintList = ColorStateList.valueOf(Color.parseColor(tint))
                setPadding(0, 0, 0, 0); minWidth = 0; minHeight = 0; minimumWidth = 0; minimumHeight = 0
                setOnClickListener { onClick(this) }
            }
            body.addView(b, LinearLayout.LayoutParams(dp(74), dp(36)).apply { topMargin = dp(3) })
            return b
        }

        val nameTv = TextView(ctx).apply {
            text = "none"; textSize = 10f; setTextColor(Color.parseColor("#FFEB3B")); gravity = Gravity.CENTER
        }
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun small(text: String, onClick: () -> Unit): Button = Button(ctx).apply {
            this.text = text; textSize = 11f; setTextColor(Color.parseColor("#FFEB3B"))
            backgroundTintList = ColorStateList.valueOf(Color.parseColor("#66443300"))
            setPadding(0, 0, 0, 0); minWidth = 0; minHeight = 0; minimumWidth = 0; minimumHeight = 0
            setOnClickListener { onClick() }
        }
        row.addView(small("◀") { ctl.cycle(world, -1) }, LinearLayout.LayoutParams(dp(36), dp(36)))
        row.addView(small("▶") { ctl.cycle(world, +1) }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginStart = dp(2) })
        body.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
        body.addView(nameTv, LinearLayout.LayoutParams(dp(74), ViewGroup.LayoutParams.WRAP_CONTENT))

        // a figure must be selected before its controls do anything: with none selected the buttons select YOU first
        fun needSel(): GameEnemyControl.Cfg {
            if (ctl.selectedKey == null) ctl.select(world.you.key)
            return ctl.cfg(ctl.selectedKey!!)
        }
        val inRot = bbtn("IN-ROT", "#CE93D8", "#66220033") { val c = needSel(); c.inRotOn = !c.inRotOn; ctl.save(c) }
        val pitch = bbtn("PITCH", "#80DEEA", "#66003344") { val c = needSel(); c.pitchOn = !c.pitchOn; ctl.save(c) }
        val sup = bbtn("SUPER", "#FFCC80", "#66440000") { ctl.superMode = !ctl.superMode; ctl.saveGlobals() }
        val raw = bbtn("RAW", "#EF9A9A", "#66330000") { ctl.rawAll = !ctl.rawAll; ctl.saveGlobals() }
        val lock = bbtn("LOCK", "#A5D6A7", "#66002200") { val c = needSel(); c.locked = !c.locked; ctl.save(c) }
        bbtn("RST", "#B0BEC5", "#66222222") { ctl.resetManual() }
        val setBtn = bbtn("SET", "#FFEB3B", "#66443300") { }

        // ── settings sheet ──
        val sheetRoot = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(8)) }
        val sheetScroll = ScrollView(ctx).apply {
            setBackgroundColor(Color.parseColor("#E6000000"))
            addView(sheetRoot)
            visibility = View.GONE
        }
        val sheetLp = RelativeLayout.LayoutParams(dp(270), dp(380)).apply {
            addRule(RelativeLayout.ALIGN_PARENT_START)
            addRule(RelativeLayout.ALIGN_PARENT_TOP)
            topMargin = dp(118)
            marginStart = dp(86)
        }
        parent.addView(sheetScroll, sheetLp)

        var builtFor: String? = "\u0000"
        fun buildSheet() {
            val key = ctl.selectedKey
            builtFor = key
            sheetRoot.removeAllViews()
            val p = PanelBuilder(ctx, sheetRoot)
            if (key == null) {
                p.title("3D GAME · NO FIGURE SELECTED", Color.rgb(0xFF, 0xEB, 0x3B))
                p.note("Tap a figure on the game board, or press ◀ ▶, then open SET again.")
                p.switch("Touch on the board (select · drag · long press)", ctl.touchOn) { ctl.touchOn = it; ctl.saveGlobals() }
                return
            }
            val c = ctl.cfg(key)
            val gold = Color.rgb(0xFF, 0xEB, 0x3B)
            val violet = Color.rgb(0xCE, 0x93, 0xD8)
            val teal = Color.rgb(0x80, 0xDE, 0xEA)
            p.title("3D GAME · ${ctl.labelOf(world, key)}", gold)
            p.note("SUPER makes these settings drive every tracked figure; each still follows its own energy.")
            p.switch("Touch on the board (select · drag · long press)", ctl.touchOn) { ctl.touchOn = it; ctl.saveGlobals() }
            p.title("INSIDE ROTATION", violet)
            p.switch("Inside rotation ON", c.inRotOn) { c.inRotOn = it; ctl.save(c) }
            p.seek("Level", 0f, 1.5f, c.inRotLevel) { c.inRotLevel = it; ctl.save(c) }
            p.seek("Threshold (neutral point)", 0f, 0.98f, c.inRotThr) { c.inRotThr = it; ctl.save(c) }
            p.seek("Range (rad)", 0f, 3.14f, c.inRotRange) { c.inRotRange = it; ctl.save(c) }
            p.switch("Bipolar (below threshold turns the other way)", c.inRotBipolar) { c.inRotBipolar = it; ctl.save(c) }
            p.switch("Inside rotation RAW", c.inRotRaw) { c.inRotRaw = it; ctl.save(c) }
            p.title("HEAD PITCH", teal)
            p.switch("Head pitch ON", c.pitchOn) { c.pitchOn = it; ctl.save(c) }
            p.seek("Level", 0f, 1.5f, c.pitchLevel) { c.pitchLevel = it; ctl.save(c) }
            p.seek("Threshold (neutral point)", 0f, 0.98f, c.pitchThr) { c.pitchThr = it; ctl.save(c) }
            p.seek("Range (rad)", 0f, 1.2f, c.pitchRange) { c.pitchRange = it; ctl.save(c) }
            p.switch("Bipolar (below threshold nods down)", c.pitchBipolar) { c.pitchBipolar = it; ctl.save(c) }
            p.switch("Head pitch RAW", c.pitchRaw) { c.pitchRaw = it; ctl.save(c) }
            p.title("ALL", gold)
            p.switch("SUPER (selected settings → every tracked figure)", ctl.superMode) { ctl.superMode = it; ctl.saveGlobals() }
            p.switch("RAW COMPLETE (every figure)", ctl.rawAll) { ctl.rawAll = it; ctl.saveGlobals() }
            p.switch("LOCK at the touch offsets", c.locked) { c.locked = it; ctl.save(c) }
            p.button("Reset touch offsets") { ctl.resetManual(key) }
        }
        setBtn.setOnClickListener {
            if (sheetScroll.visibility == View.VISIBLE) sheetScroll.visibility = View.GONE
            else { buildSheet(); sheetScroll.visibility = View.VISIBLE }
        }
        header.setOnClickListener {
            val open = body.visibility == View.VISIBLE
            body.visibility = if (open) View.GONE else View.VISIBLE
            header.text = if (open) "GAME▸" else "GAME▾"
            if (open) sheetScroll.visibility = View.GONE
        }

        // ── live state of the buttons (selection can also change by touching a figure) ──
        fun lit(b: Button, on: Boolean, base: String) {
            b.alpha = if (on) 1f else 0.55f
            b.setTextColor(Color.parseColor(if (on) "#FFFFFF" else base))
        }
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                val key = ctl.selectedKey
                nameTv.text = ctl.labelOf(world, key)
                val c = key?.let { ctl.cfg(it) }
                lit(inRot, c?.inRotOn == true, "#CE93D8")
                lit(pitch, c?.pitchOn == true, "#80DEEA")
                lit(sup, ctl.superMode, "#FFCC80")
                lit(raw, ctl.rawAll, "#EF9A9A")
                lit(lock, c?.locked == true, "#A5D6A7")
                if (sheetScroll.visibility == View.VISIBLE && builtFor != key) buildSheet()   // follow the selection
                h.postDelayed(this, 200)
            }
        })
    }
}
