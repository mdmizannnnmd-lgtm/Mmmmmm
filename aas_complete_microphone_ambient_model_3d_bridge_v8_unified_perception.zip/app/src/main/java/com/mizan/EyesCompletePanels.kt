package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

/** Mono + Final eyes complete settings panels (no missing · multiple paths). */
object EyesCompletePanels {

    fun buildMono(ctx: Context, root: LinearLayout, m: MonoEyesCompleteBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF80CBC4.toInt()
        p.title("MONO TABS · EYES COMPLETE (all settings)", c)
        p.switch("Mono eyes master ON", m.masterOn) { m.masterOn = it }
        p.switch("Mono eyes RAW COMPLETE", m.rawComplete) { m.rawComplete = it }
        p.title("MONO · LEFT / RIGHT AMBIENT", c)
        p.switch("Left ambient ON", m.leftAmbOn) { m.leftAmbOn = it }
        p.seek("Left amb thr", 0.05f, 0.98f, m.leftAmbThr) { m.leftAmbThr = it }
        p.seek("Left amb lv", 0f, 1.5f, m.leftAmbLv) { m.leftAmbLv = it }
        p.switch("Right ambient ON", m.rightAmbOn) { m.rightAmbOn = it }
        p.seek("Right amb thr", 0.05f, 0.98f, m.rightAmbThr) { m.rightAmbThr = it }
        p.seek("Right amb lv", 0f, 1.5f, m.rightAmbLv) { m.rightAmbLv = it }
        p.seek("Shared eyes thr", 0.05f, 0.98f, m.sharedThr) { m.sharedThr = it }
        p.seek("Shared eyes lv", 0f, 1.5f, m.sharedLv) { m.sharedLv = it }
        p.switch("Eye lines protection", m.eyeLinesProt) { m.eyeLinesProt = it }
        p.switch("Optical nerve ambient", m.opticalNerveOn) { m.opticalNerveOn = it }
        p.title("MONO · VISUAL PATH L/R", c)
        p.switch("Left visual ON", m.leftVisOn) { m.leftVisOn = it }
        p.seek("L bright", 0f, 1f, m.leftBright) { m.leftBright = it }
        p.seek("L contrast", 0f, 1f, m.leftContrast) { m.leftContrast = it }
        p.seek("L vis lv / thr", 0f, 1.5f, m.leftVisLv) { m.leftVisLv = it }
        p.seek("L vis thr", 0.05f, 0.98f, m.leftVisThr) { m.leftVisThr = it }
        p.seek("L colour thr", 0.05f, 0.98f, m.leftColThr) { m.leftColThr = it }
        p.seek("L R / G / B", 0f, 1f, m.leftR) { m.leftR = it }
        p.seek("L G", 0f, 1f, m.leftG) { m.leftG = it }
        p.seek("L B", 0f, 1f, m.leftB) { m.leftB = it }
        p.switch("Right visual ON", m.rightVisOn) { m.rightVisOn = it }
        p.seek("R bright", 0f, 1f, m.rightBright) { m.rightBright = it }
        p.seek("R contrast", 0f, 1f, m.rightContrast) { m.rightContrast = it }
        p.seek("R vis lv", 0f, 1.5f, m.rightVisLv) { m.rightVisLv = it }
        p.seek("R vis thr", 0.05f, 0.98f, m.rightVisThr) { m.rightVisThr = it }
        p.seek("R colour thr", 0.05f, 0.98f, m.rightColThr) { m.rightColThr = it }
        p.seek("R R", 0f, 1f, m.rightR) { m.rightR = it }
        p.seek("R G", 0f, 1f, m.rightG) { m.rightG = it }
        p.seek("R B", 0f, 1f, m.rightB) { m.rightB = it }
        p.title("MONO · MOVE / WAVE / SPEED · BIPOLAR", c)
        p.seek("Move lv / thr", 0f, 1.5f, m.moveLv) { m.moveLv = it }
        p.seek("Move thr", 0.05f, 0.98f, m.moveThr) { m.moveThr = it }
        p.seek("Wave lv", 0f, 1.5f, m.waveLv) { m.waveLv = it }
        p.seek("Wave thr", 0.05f, 0.98f, m.waveThr) { m.waveThr = it }
        p.seek("Speed lv", 0f, 1.5f, m.speedLv) { m.speedLv = it }
        p.seek("Speed thr", 0.05f, 0.98f, m.speedThr) { m.speedThr = it }
        p.seek("Bipolar neg dB", -120f, 0f, m.bipNeg) { m.bipNeg = it }
        p.seek("Bipolar pos dB", 0f, 120f, m.bipPos) { m.bipPos = it }
        p.title("MONO · FILTERS · PROTECT", c)
        p.seek("LR filter", 0f, 1f, m.lrFilter) { m.lrFilter = it }
        p.seek("UD filter", 0f, 1f, m.udFilter) { m.udFilter = it }
        p.seek("Random / center / corner / vib", 0f, 1f, m.randomFilter) { m.randomFilter = it }
        p.seek("Center filter", 0f, 1f, m.centerFilter) { m.centerFilter = it }
        p.seek("Atmosphere / wavespare", 0f, 1f, m.atmosphere) { m.atmosphere = it }
        p.seek("Wavespare", 0f, 1f, m.wavespare) { m.wavespare = it }
        p.switch("Protect L", m.protectL) { m.protectL = it }
        p.switch("Protect R", m.protectR) { m.protectR = it }
        val st = p.status("MONO-EYES —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = m.status; h.postDelayed(this, 250) }
        })
    }

    fun buildFinal(ctx: Context, root: LinearLayout, f: FinalEyesCompleteBoard) {
        val p = PanelBuilder(ctx, root)
        val v = 0xFFF48FB1.toInt()
        p.title("FINAL TABS · EYES COMPLETE (all settings)", v)
        p.switch("Final eyes master ON", f.masterOn) { f.masterOn = it }
        p.switch("Final eyes RAW COMPLETE", f.rawComplete) { f.rawComplete = it }
        p.switch("Dual path (shared + L/R)", f.dualPathOn) { f.dualPathOn = it }
        p.title("FINAL · LEFT / RIGHT AMBIENT", v)
        p.switch("Left eye ambient ON", f.leftOn) { f.leftOn = it }
        p.seek("Left thr", 0.05f, 0.98f, f.leftThr) { f.leftThr = it }
        p.seek("Left lv", 0f, 1.5f, f.leftLv) { f.leftLv = it }
        p.switch("Right eye ambient ON", f.rightOn) { f.rightOn = it }
        p.seek("Right thr", 0.05f, 0.98f, f.rightThr) { f.rightThr = it }
        p.seek("Right lv", 0f, 1.5f, f.rightLv) { f.rightLv = it }
        p.seek("Shared thr / lv", 0.05f, 0.98f, f.sharedThr) { f.sharedThr = it }
        p.seek("Shared lv", 0f, 1.5f, f.sharedLv) { f.sharedLv = it }
        p.switch("Eye lines protection", f.eyeLinesProt) { f.eyeLinesProt = it }
        p.switch("Optical nerve ambient", f.opticalOn) { f.opticalOn = it }
        p.title("FINAL · VISUAL PATH L/R", v)
        p.switch("Left visual ON", f.leftVisOn) { f.leftVisOn = it }
        p.seek("L bright / contrast", 0f, 1f, f.leftBright) { f.leftBright = it }
        p.seek("L contrast", 0f, 1f, f.leftContrast) { f.leftContrast = it }
        p.seek("L vis lv / thr", 0f, 1.5f, f.leftVisLv) { f.leftVisLv = it }
        p.seek("L vis thr", 0.05f, 0.98f, f.leftVisThr) { f.leftVisThr = it }
        p.seek("L colour thr · RGB", 0.05f, 0.98f, f.leftColThr) { f.leftColThr = it }
        p.seek("L R", 0f, 1f, f.leftR) { f.leftR = it }
        p.seek("L G", 0f, 1f, f.leftG) { f.leftG = it }
        p.seek("L B", 0f, 1f, f.leftB) { f.leftB = it }
        p.switch("Right visual ON", f.rightVisOn) { f.rightVisOn = it }
        p.seek("R bright", 0f, 1f, f.rightBright) { f.rightBright = it }
        p.seek("R contrast", 0f, 1f, f.rightContrast) { f.rightContrast = it }
        p.seek("R vis lv", 0f, 1.5f, f.rightVisLv) { f.rightVisLv = it }
        p.seek("R vis thr", 0.05f, 0.98f, f.rightVisThr) { f.rightVisThr = it }
        p.seek("R colour thr", 0.05f, 0.98f, f.rightColThr) { f.rightColThr = it }
        p.seek("R R/G/B", 0f, 1f, f.rightR) { f.rightR = it }
        p.seek("R G", 0f, 1f, f.rightG) { f.rightG = it }
        p.seek("R B", 0f, 1f, f.rightB) { f.rightB = it }
        p.title("FINAL · PITCH PROTECT · BIPOLAR", v)
        p.switch("Pitch protect L", f.pitchProtL) { f.pitchProtL = it }
        p.switch("Pitch protect R", f.pitchProtR) { f.pitchProtR = it }
        p.seek("Pitch thr L", 0.05f, 0.98f, f.pitchThrL) { f.pitchThrL = it }
        p.seek("Pitch thr R", 0.05f, 0.98f, f.pitchThrR) { f.pitchThrR = it }
        p.seek("Pitch lv L", 0f, 1.5f, f.pitchLvL) { f.pitchLvL = it }
        p.seek("Pitch lv R", 0f, 1.5f, f.pitchLvR) { f.pitchLvR = it }
        p.seek("Bipolar neg dB", -120f, 0f, f.bipNeg) { f.bipNeg = it }
        p.seek("Bipolar pos dB", 0f, 120f, f.bipPos) { f.bipPos = it }
        val st = p.status("FINAL-EYES —", v)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = f.status; h.postDelayed(this, 250) }
        })
    }
}
