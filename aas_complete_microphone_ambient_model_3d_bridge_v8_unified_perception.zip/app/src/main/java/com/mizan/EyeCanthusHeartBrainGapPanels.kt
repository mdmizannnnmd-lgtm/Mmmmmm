package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object EyeCanthusHeartBrainGapPanels {
    fun build(ctx: Context, root: LinearLayout, b: EyeCanthusHeartBrainGapBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF81D4FA.toInt()
        p.title("EYE CANTHUS · EYE→HEART→BRAIN · FACE NEURAL · MOTION LOCK", c)
        p.note("Gaps: medial/lateral canthus · ANS eye path · face neural · motion protect")
        p.switch("ON", b.enabled) { b.enabled = it }
        p.switch("RAW", b.rawComplete) { b.rawComplete = it }
        p.switch("Eye motion protect", b.eyeMotionProtectOn) { b.eyeMotionProtectOn = it }
        p.seek("Thr", 0.05f, 0.8f, b.thr) { b.thr = it }
        p.seek("Level", 0.2f, 1.5f, b.levelAmt) { b.levelAmt = it }
        val st = p.status("EYE-GAP —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() { st.text = b.status; Handler(Looper.getMainLooper()).postDelayed(this, 280) }
        })
    }
}
