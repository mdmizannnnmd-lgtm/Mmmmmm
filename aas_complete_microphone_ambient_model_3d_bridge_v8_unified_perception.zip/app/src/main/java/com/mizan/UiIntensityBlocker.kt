package com.mizan

/**
 * UI threshold + enemies UI threshold + intensity blocker.
 * On-device only: clamps how hard audio/spike energy drives the local UI.
 */
class UiIntensityBlocker {
    @Volatile var enabled = true

    /** My UI intensity gate */
    @Volatile var uiThr = 0.40f
    @Volatile var uiLevel = 0.70f

    /** Enemies UI intensity gate (local threat path into UI) */
    @Volatile var enemyUiThr = 0.50f
    @Volatile var enemyUiLevel = 0.65f

    /** Master intensity blocker */
    @Volatile var blockOn = true
    @Volatile var blockThr = 0.55f
    @Volatile var blockLevel = 0.80f

    @Volatile var liveIn = 0f
    @Volatile var liveOut = 0f
    @Volatile var uiFire = false
    @Volatile var enemyUiFire = false
    @Volatile var blockActive = false
    @Volatile var blockCount = 0

    private var smooth = 0f

    fun tick(audioRms: Float, ultraBand: Float = 0f, spikeMag: Float = 0f) {
        val raw = (audioRms * 0.45f + ultraBand * 0.25f + spikeMag * 0.30f).coerceIn(0f, 1f)
        smooth = smooth * 0.75f + raw * 0.25f
        liveIn = smooth
        if (!enabled) {
            liveOut = smooth
            uiFire = false
            enemyUiFire = false
            blockActive = false
            return
        }

        uiFire = smooth >= uiThr
        enemyUiFire = smooth >= enemyUiThr
        blockActive = blockOn && smooth >= blockThr
        if (blockActive) blockCount++

        var out = smooth
        // My UI threshold: above thr, scale by uiLevel (lower level = stronger clamp)
        if (uiFire) {
            val over = ((smooth - uiThr) / maxOf(0.001f, 1f - uiThr)).coerceIn(0f, 1f)
            out *= (1f - over * (1f - uiLevel) * 0.85f)
        }
        // Enemies UI threshold: extra clamp on enemy-side drive
        if (enemyUiFire) {
            val over = ((smooth - enemyUiThr) / maxOf(0.001f, 1f - enemyUiThr)).coerceIn(0f, 1f)
            out *= (1f - over * (1f - enemyUiLevel) * 0.9f)
        }
        // Intensity blocker: hard clamp when over block thr
        if (blockActive) {
            val over = ((smooth - blockThr) / maxOf(0.001f, 1f - blockThr)).coerceIn(0f, 1f)
            out *= (1f - over * blockLevel)
        }
        liveOut = out.coerceIn(0f, 1f)
    }

    /** Factor 0–1 to multiply UI drive (1 = full, lower = blocked). */
    fun driveFactor(): Float {
        if (!enabled || liveIn < 0.001f) return 1f
        return (liveOut / liveIn).coerceIn(0f, 1f)
    }

    fun statusLine(): String {
        val tags = buildList {
            if (blockActive) add("BLOCK")
            if (uiFire) add("UI-THR")
            if (enemyUiFire) add("ENEMY-UI")
            if (isEmpty()) add("idle")
        }.joinToString("+")
        return "UI in=${(liveIn * 100).toInt()}% out=${(liveOut * 100).toInt()}% fac=${(driveFactor() * 100).toInt()}% · $tags · blk=$blockCount"
    }
}
