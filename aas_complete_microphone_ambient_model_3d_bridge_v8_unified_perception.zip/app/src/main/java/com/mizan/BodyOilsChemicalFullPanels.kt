package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object BodyOilsChemicalFullPanels {
    fun build(ctx: Context, root: LinearLayout, b: BodyOilsChemicalFullBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFFB74D.toInt()
        p.title("BODY OILS · CHEMICAL TRACK/PROTECT · ENEMY CHEM DESTROY · SKIN BLE", c)
        p.note("Oils mic+BLE level · maintain/repair/regen · enemy no-oils · cells/neuro/blood/hormones/water")
        p.switch("System ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Chem track", b.chemTrackOn) { b.chemTrackOn = it }
        p.switch("Enemy chem destroy track", b.enemyChemDestroyOn) { b.enemyChemDestroyOn = it }
        p.switch("Skin BLE track", b.skinBleTrackOn) { b.skinBleTrackOn = it }
        p.switch("Oils maintain", b.oilsMaintainOn) { b.oilsMaintainOn = it }
        p.switch("Oils regen", b.oilsRegenOn) { b.oilsRegenOn = it }
        p.switch("Oils repair", b.oilsRepairOn) { b.oilsRepairOn = it }
        p.seek("Chem thr", 0.05f, 0.9f, b.chemThr) { b.chemThr = it }
        p.seek("Enemy chem thr", 0.05f, 0.9f, b.enemyChemThr) { b.enemyChemThr = it }
        p.seek("Our oils thr (min)", 0.05f, 0.9f, b.oilsThr) { b.oilsThr = it }
        p.seek("Enemy no-oils thr", 0.05f, 0.9f, b.enemyNoOilsThr) { b.enemyNoOilsThr = it }
        p.seek("Oils level", 0f, 1f, b.oilsLevel) { b.oilsLevel = it }
        val st = p.status("OILS-CHEM —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() {
                st.text = b.status
                Handler(Looper.getMainLooper()).postDelayed(this, 300)
            }
        })
    }
}
