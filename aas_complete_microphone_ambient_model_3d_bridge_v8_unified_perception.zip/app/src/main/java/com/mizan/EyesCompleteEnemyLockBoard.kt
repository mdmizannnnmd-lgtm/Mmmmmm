package com.mizan

/**
 * More complete eyes ambient + enemy eye-motion lock.
 * Iris/pupil/sclera/orbit · L/R · lock so enemy paths cannot drive eye move.
 * Symbolic only. RAW COMPLETE.
 */
class EyesCompleteEnemyLockBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.18f
    @Volatile var lv = 0.92f

    @Volatile var eyesOn = true
    @Volatile var irisL = 0f
    @Volatile var irisR = 0f
    @Volatile var pupilL = 0f
    @Volatile var pupilR = 0f
    @Volatile var scleraL = 0f
    @Volatile var scleraR = 0f
    @Volatile var orbitL = 0f
    @Volatile var orbitR = 0f
    @Volatile var opticL = 0f
    @Volatile var opticR = 0f
    @Volatile var gazeStableL = 0f
    @Volatile var gazeStableR = 0f
    @Volatile var eyesFullOut = 0f

    // Enemy eye motion lock
    @Volatile var enemyEyeLockOn = true
    @Volatile var enemyEyeLockThr = 0.15f
    @Volatile var enemyEyeLockLv = 0.98f
    @Volatile var enemyEyeThreat = 0f
    @Volatile var eyeLockOut = 0f
    @Volatile var eyeMoveBlocked = 0f

    @Volatile var status = "EYES COMPLETE·LOCK idle"

    private fun lane(on: Boolean, t: Float, l: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * l).coerceIn(0f, 1f)
        val th = t.coerceIn(0.02f, 1f)
        return if (e >= th) (((e - th) / (1f - th).coerceAtLeast(0.05f)) * l).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, enemy: Float, eyeSkinL: Float, eyeSkinR: Float) {
        if (!enabled) {
            status = "EYES LOCK OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        irisL = lane(eyesOn, thr, lv, maxOf(e, eyeSkinL))
        irisR = lane(eyesOn, thr, lv, maxOf(e, eyeSkinR))
        pupilL = irisL * 0.95f
        pupilR = irisR * 0.95f
        scleraL = irisL * 0.90f
        scleraR = irisR * 0.90f
        orbitL = irisL * 0.88f
        orbitR = irisR * 0.88f
        opticL = irisL * 0.92f
        opticR = irisR * 0.92f
        gazeStableL = irisL * 0.97f
        gazeStableR = irisR * 0.97f
        eyesFullOut = maxOf(irisL, irisR, gazeStableL, gazeStableR)

        enemyEyeThreat = enemy.coerceIn(0f, 1f)
        eyeLockOut = lane(enemyEyeLockOn, enemyEyeLockThr, enemyEyeLockLv, maxOf(enemyEyeThreat, e * 0.4f))
        eyeMoveBlocked = eyeLockOut

        status =
            "EYE iris L/R=${(irisL*100).toInt()}/${(irisR*100).toInt()}% FULL=${(eyesFullOut*100).toInt()}% · " +
            "ENEMY-LOCK=${(eyeLockOut*100).toInt()}% MOVE-BLOCK=${(eyeMoveBlocked*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled) return
        // Dampen enemy-driven motion/audio that could “move eyes”
        if (eyeMoveBlocked > 0.02f) {
            val k = (1f - eyeMoveBlocked * 0.97f).coerceIn(0.02f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
            sb.whipOut *= k
            sb.rippleOut *= k
        }
        val vv = v ?: return
        try {
            vv.allBodySkinAnatomy.eyeSkinL = maxOf(vv.allBodySkinAnatomy.eyeSkinL, irisL, scleraL)
            vv.allBodySkinAnatomy.eyeSkinR = maxOf(vv.allBodySkinAnatomy.eyeSkinR, irisR, scleraR)
            vv.allBodySkinAnatomy.eyesSkinOut = maxOf(vv.allBodySkinAnatomy.eyesSkinOut, eyesFullOut)
            vv.allBodySkinAnatomy.eyelidSkinL = maxOf(vv.allBodySkinAnatomy.eyelidSkinL, orbitL * 0.9f)
            vv.allBodySkinAnatomy.eyelidSkinR = maxOf(vv.allBodySkinAnatomy.eyelidSkinR, orbitR * 0.9f)
        } catch (_: Throwable) {}
        try {
            vv.bioSkinCell.eyeCellsL = maxOf(vv.bioSkinCell.eyeCellsL, irisL)
            vv.bioSkinCell.eyeCellsR = maxOf(vv.bioSkinCell.eyeCellsR, irisR)
        } catch (_: Throwable) {}
        try {
            vv.eyeL.atmosphere = maxOf(vv.eyeL.atmosphere, irisL, gazeStableL)
            vv.eyeR.atmosphere = maxOf(vv.eyeR.atmosphere, irisR, gazeStableR)
            vv.eyes.atmosphere = maxOf(vv.eyes.atmosphere, eyesFullOut, eyeLockOut * 0.5f)
        } catch (_: Throwable) {}
        try {
            // Lock eye motion controllers if present
            vv.bodyRegionEnemyProtect.eyeLProt = maxOf(vv.bodyRegionEnemyProtect.eyeLProt, eyeLockOut)
            vv.bodyRegionEnemyProtect.eyeRProt = maxOf(vv.bodyRegionEnemyProtect.eyeRProt, eyeLockOut)
            vv.bodyRegionEnemyProtect.eyesProt = maxOf(vv.bodyRegionEnemyProtect.eyesProt, eyeLockOut)
            vv.bodyRegionEnemyProtect.protectOut = maxOf(vv.bodyRegionEnemyProtect.protectOut, eyeLockOut * 0.8f)
        } catch (_: Throwable) {}
        try {
            vv.faceEyeNoise.eyeL = maxOf(vv.faceEyeNoise.eyeL, irisL)
            vv.faceEyeNoise.eyeR = maxOf(vv.faceEyeNoise.eyeR, irisR)
            vv.eyesHeartBelly.eyeLOut = maxOf(vv.eyesHeartBelly.eyeLOut, irisL)
            vv.eyesHeartBelly.eyeROut = maxOf(vv.eyesHeartBelly.eyeROut, irisR)
        } catch (_: Throwable) {}
        try {
            // Zero-out enemy influence on anatomy eye-related wave if lock high
            if (eyeMoveBlocked > 0.5f) {
                vv.anatomy3d.atmosphere = maxOf(vv.anatomy3d.atmosphere, eyeLockOut * 0.3f)
            }
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, eyeLockOut)
        } catch (_: Throwable) {}
        try {
            // Soft freeze of enemy motion feed into multi-model move near eyes
            if (eyeMoveBlocked > 0.3f) {
                vv.skinMultiMotion.moveOut *= (1f - eyeMoveBlocked * 0.5f).coerceIn(0.2f, 1f)
            }
        } catch (_: Throwable) {}
    }
}
