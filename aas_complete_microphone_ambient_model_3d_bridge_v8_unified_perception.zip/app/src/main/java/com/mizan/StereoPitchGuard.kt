package com.mizan

import kotlin.math.exp
import kotlin.math.sqrt

/**
 * SCREEN SOUNDS · PITCH PROTECTION — LEFT and RIGHT.
 *
 * Runs a real pitch detector (normalised autocorrelation, McLeod style) on the LEFT and the RIGHT
 * channel separately. When a clear, loud pitch lands at or above the side's pitch ceiling (shrill / whistle)
 * — or, optionally, at or below its pitch floor (deep rumble) — that side is protected:
 *
 *   · [Side.damp] rises instantly and falls back over [releaseMs],
 *   · [scaleL] / [scaleR] shrink the visuals that belong to that side (eyes, hands, brain hemisphere),
 *   · AudioProcessor lowers the energy it feeds the rest of the app and raises its trigger threshold.
 *
 * RAW COMPLETE: no protection is applied at all (damp stays 0, scale stays 1) — pitch / level readouts keep
 * running so you can see what *would* have been protected.
 *
 * It analyses the microphone signal of this device. Left / right are the two channels the mic delivers
 * (a mono mic reports the same data on both sides — [stereoLive] tells you which one you have).
 */
class StereoPitchGuard {

    class Side(val label: String) {
        @Volatile var on = true
        @Volatile var highHz = 2500f        // pitch ceiling
        @Volatile var lowOn = false         // also protect against deep pitch
        @Volatile var lowHz = 90f           // pitch floor
        @Volatile var levelThr = 0.12f      // 0..1 (rms x 3.5): the pitch only counts when this loud
        @Volatile var protLv = 0.70f        // 0..1 how hard to damp

        @Volatile var pitchHz = 0f
        @Volatile var clarity = 0f
        @Volatile var level = 0f
        @Volatile var hot = false           // a protected pitch is present (also reported in RAW COMPLETE)
        @Volatile var active = false        // protection really applied
        @Volatile var damp = 0f
        @Volatile var hits = 0
        internal var env = 0f
        internal var wasHot = false
    }

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var linkLR = false            // worse side protects both
    @Volatile var clarityThr = 0.55f        // 0..1 minimum pitch clarity
    @Volatile var releaseMs = 400
    @Volatile var stereoLive = false

    val left = Side("L")
    val right = Side("R")

    private val maxProtectHz = 4000f
    private var work = FloatArray(0)
    private var dec = FloatArray(0)
    private var nsdf = FloatArray(0)
    private val peakTau = IntArray(48)
    private val peakVal = FloatArray(48)
    private var lastHz = 0f
    private var lastClarity = 0f

    /** [l] and [r] hold the first [n] samples of each channel. */
    fun process(l: ShortArray, r: ShortArray, n: Int, sampleRate: Int = 44100) {
        if (n < 512) return
        val dtMs = n * 1000f / sampleRate
        analyse(left, l, n, sampleRate, dtMs)
        analyse(right, r, n, sampleRate, dtMs)

        var dl = left.env
        var dr = right.env
        if (linkLR) {
            val m = maxOf(dl, dr)
            dl = m; dr = m
        }
        if (rawComplete || !enabled) {
            dl = 0f; dr = 0f
        }
        left.damp = dl
        right.damp = dr
        left.active = dl > 0.02f
        right.active = dr > 0.02f
    }

    private fun analyse(s: Side, buf: ShortArray, n: Int, sr: Int, dtMs: Float) {
        if (work.size < n) work = FloatArray(n)
        val x = work

        var mean = 0.0
        for (i in 0 until n) mean += buf[i].toDouble()
        mean /= n
        var e = 0.0
        for (i in 0 until n) {
            val v = ((buf[i] - mean) / 32768.0).toFloat()
            x[i] = v
            e += (v * v).toDouble()
        }
        val rms = sqrt(e / n).toFloat()
        s.level = (rms * 3.5f).coerceIn(0f, 1f)

        lastHz = 0f
        lastClarity = 0f
        if (rms > 0.004f) detectPitch(x, n, sr)
        val pitched = lastClarity >= clarityThr.coerceIn(0.05f, 0.99f) && lastHz > 0f
        s.pitchHz = if (pitched) lastHz else 0f
        s.clarity = lastClarity

        val thr = s.levelThr.coerceIn(0.01f, 1f)
        val levelOk = s.level >= thr
        val high = pitched && lastHz >= s.highHz && levelOk
        val low = s.lowOn && pitched && lastHz <= s.lowHz && levelOk
        val hit = s.on && enabled && (high || low)
        s.hot = hit
        if (hit && !s.wasHot) s.hits++
        s.wasHot = hit

        var target = 0f
        if (hit) {
            val pOver = if (high) {
                ((lastHz - s.highHz) / (maxProtectHz - s.highHz).coerceAtLeast(1f)).coerceIn(0f, 1f)
            } else {
                ((s.lowHz - lastHz) / s.lowHz.coerceAtLeast(1f)).coerceIn(0f, 1f)
            }
            val lOver = ((s.level - thr) / (1f - thr).coerceAtLeast(0.05f)).coerceIn(0f, 1f)
            target = s.protLv.coerceIn(0f, 1f) * (0.5f + 0.5f * maxOf(pOver, lOver))
        }
        if (target >= s.env) {
            s.env += (target - s.env) * 0.7f
        } else {
            s.env *= exp(-dtMs / releaseMs.coerceIn(20, 5000).toFloat())
        }
        if (s.env < 0.01f) s.env = 0f
    }

    /**
     * McLeod normalised square difference function on a 2x decimated copy of [x].
     * Writes [lastHz] / [lastClarity]; both stay 0 when no clear pitch is found.
     */
    private fun detectPitch(x: FloatArray, n: Int, sr: Int) {
        val nd = n / 2
        if (dec.size < nd) dec = FloatArray(nd)
        for (i in 0 until nd) dec[i] = (x[2 * i] + x[2 * i + 1]) * 0.5f
        val srd = sr / 2

        val minLag = (srd / 4000).coerceAtLeast(2)
        val maxLag = (srd / 60).coerceAtMost(nd / 2)
        if (maxLag <= minLag + 4) return
        if (nsdf.size < maxLag + 2) nsdf = FloatArray(maxLag + 2)

        // m(0) = 2 * sum(x^2); m(tau) is updated incrementally.
        var m = 0.0
        for (j in 0 until nd) m += 2.0 * dec[j] * dec[j]
        for (tau in 0..maxLag + 1) {
            if (tau > 0) {
                val a = dec[tau - 1].toDouble()
                val b = dec[nd - tau].toDouble()
                m -= a * a + b * b
            }
            var acf = 0.0
            val lim = nd - tau
            for (j in 0 until lim) acf += (dec[j] * dec[j + tau]).toDouble()
            nsdf[tau] = if (m > 1e-9) (2.0 * acf / m).toFloat() else 0f
        }

        // Skip the first positive lobe, then collect the peaks.
        var t = 1
        while (t < maxLag && nsdf[t] > 0f) t++
        var peaks = 0
        var highest = 0f
        while (t < maxLag) {
            val v = nsdf[t]
            if (v > 0f && v >= nsdf[t - 1] && v > nsdf[t + 1] && t >= minLag) {
                if (peaks < peakTau.size) {
                    peakTau[peaks] = t
                    peakVal[peaks] = v
                    peaks++
                }
                if (v > highest) highest = v
            }
            t++
        }
        if (peaks == 0 || highest <= 0f) return

        var pick = -1
        for (k in 0 until peaks) {
            if (peakVal[k] >= 0.9f * highest) { pick = k; break }
        }
        if (pick < 0) return
        val tp = peakTau[pick]
        val a = nsdf[tp - 1]
        val b = nsdf[tp]
        val c = nsdf[tp + 1]
        val denom = a - 2f * b + c
        val shift = if (denom < -1e-6f) (0.5f * (a - c) / denom).coerceIn(-1f, 1f) else 0f
        val tauF = tp + shift
        if (tauF <= 0f) return
        lastHz = srd / tauF
        lastClarity = b.coerceIn(0f, 1f)
    }

    /** Visual / energy scale for the LEFT side: 1 = untouched, down to 0.15 when fully protected. */
    fun scaleL(): Float = (1f - left.damp * 0.85f).coerceIn(0.15f, 1f)

    /** Visual / energy scale for the RIGHT side. */
    fun scaleR(): Float = (1f - right.damp * 0.85f).coerceIn(0.15f, 1f)

    /** Centre / shared parts (brain, mouth …): the more protected of the two sides. */
    fun scaleBoth(): Float = minOf(scaleL(), scaleR())

    /** Strongest protection of either side, 0..1. */
    fun damp(): Float = maxOf(left.damp, right.damp)

    fun statusLine(): String {
        fun side(s: Side): String {
            val st = when {
                rawComplete && s.hot -> "RAW·would-protect"
                s.active -> "PROTECT"
                s.hot -> "HOT"
                else -> "idle"
            }
            val hz = if (s.pitchHz > 0f) "${s.pitchHz.toInt()}Hz" else "—"
            return "${s.label}: $hz clar=${(s.clarity * 100).toInt()}% lv=${(s.level * 100).toInt()}% " +
                "damp=${(s.damp * 100).toInt()}% · $st · #${s.hits}"
        }
        val head = when {
            rawComplete -> "PITCH PROT RAW COMPLETE (readout only · no protection)"
            !enabled -> "PITCH PROT off"
            else -> "PITCH PROT${if (linkLR) " LINK" else ""}"
        }
        return "$head · ${if (stereoLive) "stereo mic" else "mono mic (L=R)"}\n${side(left)}\n${side(right)}"
    }
}
