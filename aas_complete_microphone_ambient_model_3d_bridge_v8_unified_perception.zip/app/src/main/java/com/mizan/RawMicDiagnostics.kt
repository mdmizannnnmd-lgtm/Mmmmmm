package com.mizan

import java.util.concurrent.atomic.AtomicLong

/** Lightweight real-time health counters for the shared microphone pipeline. */
object RawMicDiagnostics {
    private val published = AtomicLong(0)
    private val readErrors = AtomicLong(0)
    private val emptyReads = AtomicLong(0)
    private val listenerErrors = AtomicLong(0)
    private val maxFrameLatencyMs = AtomicLong(0)

    fun onPublished(timestampMs: Long) {
        published.incrementAndGet()
        val latency = (System.currentTimeMillis() - timestampMs).coerceAtLeast(0L)
        maxFrameLatencyMs.updateAndGet { maxOf(it, latency) }
    }
    fun onReadError() = readErrors.incrementAndGet()
    fun onEmptyRead() = emptyReads.incrementAndGet()
    fun onListenerError() = listenerErrors.incrementAndGet()

    data class Snapshot(
        val publishedFrames: Long,
        val readErrors: Long,
        val emptyReads: Long,
        val listenerErrors: Long,
        val maxObservedLatencyMs: Long
    )

    fun snapshot() = Snapshot(
        published.get(), readErrors.get(), emptyReads.get(), listenerErrors.get(), maxFrameLatencyMs.get()
    )

    fun reset() {
        published.set(0); readErrors.set(0); emptyReads.set(0); listenerErrors.set(0); maxFrameLatencyMs.set(0)
    }
}
