package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object SkinAtomspare3dPanels {
    fun build(ctx: Context, root: LinearLayout, b: SkinAtomspare3dBoard) {
        val p = try {
            PanelBuilder(ctx, root)
        } catch (_: Throwable) {
            // minimal fallback if PanelBuilder API differs
            null
        }
        if (p == null) return
        val c = 0xFFFFAB91.toInt()
        p.title("3D SKIN ATOMPARE · IN/OUT · BODY-ONLY SFX · KNIFE/BULLET/SD", c)
        p.note("Epidermis·dermis·fat (out) · muscle·vessel·core (in) · SFX enter human body only")
        p.switch("Skin atomspare master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Outside skin layers ON", b.skinOutsideOn) { b.skinOutsideOn = it }
        p.switch("Inside body layers ON", b.skinInsideOn) { b.skinInsideOn = it }
        p.switch("Atomspare ON", b.atomSpareOn) { b.atomSpareOn = it }
        p.switch("Auto threshold", b.atomSpareAutoThr) { b.atomSpareAutoThr = it }
        p.seek("Atomspare thr", 0.05f, 0.98f, b.atomSpareThr) { b.atomSpareThr = it }
        p.seek("Atomspare level", 0f, 1.5f, b.atomSpareLv) { b.atomSpareLv = it }
        p.switch("Body-only entry (not anywhere)", b.bodyOnlyEntry) { b.bodyOnlyEntry = it }
        p.seek("Body entry thr", 0.05f, 0.98f, b.bodyEntryThr) { b.bodyEntryThr = it }

        p.title("MODES", c)
        p.switch("Knife mode", b.knifeMode) { b.knifeMode = it }
        p.seek("Knife thr / lv", 0.05f, 0.98f, b.knifeThr) { b.knifeThr = it }
        p.seek("Knife level", 0f, 1.5f, b.knifeLv) { b.knifeLv = it }
        p.switch("Bullet mode", b.bulletMode) { b.bulletMode = it }
        p.seek("Bullet thr", 0.05f, 0.98f, b.bulletThr) { b.bulletThr = it }
        p.seek("Bullet level", 0f, 1.5f, b.bulletLv) { b.bulletLv = it }
        p.switch("SD card mode", b.sdCardMode) { b.sdCardMode = it }
        p.switch("Audio-focused SFX", b.audioFocusedSfx) { b.audioFocusedSfx = it }
        p.switch("Virtual atomspare SFX", b.virtualAtomSfx) { b.virtualAtomSfx = it }
        p.switch("SFX body-only", b.sfxBodyOnly) { b.sfxBodyOnly = it }
        p.button("Scan SD atomspare folder") { _ ->
            val n = b.scanSdCard(ctx)
            android.widget.Toast.makeText(ctx, "SD atomspare files: $n", android.widget.Toast.LENGTH_SHORT).show()
        }
        p.button("Play body atomspare SFX (SD)") { _ ->
            val ok = b.tryPlaySdCard(ctx)
            android.widget.Toast.makeText(
                ctx,
                if (ok) "Playing ${b.lastPlayed}" else "No play (need body HIT + files)",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }

        val st = p.status("SKIN·ATOM —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
