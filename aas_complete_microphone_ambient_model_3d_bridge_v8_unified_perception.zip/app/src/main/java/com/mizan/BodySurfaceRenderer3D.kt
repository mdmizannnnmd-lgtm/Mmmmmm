package com.mizan

import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.Matrix
import android.util.Log
import com.google.ar.core.Coordinates2d
import com.google.ar.core.Frame
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.sin

/**
 * Continuous GPU outer body shell and particles composited over the live ARCore camera texture.
 * This is a camera-relative visual overlay, not ARCore human-body/depth tracking.
 */
internal class BodySurfaceRenderer3D {
    private val shellMesh by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { makeContinuousShellMesh() }
    private val particleMax = 128
    private val body84Anchors = makeBody84Anchors()

    private var bodyProgram = 0
    private var pointProgram = 0
    private var bodyPosition = -1
    private var bodyNormal = -1
    private var bodyCameraUv = -1
    private var bodyMvp = -1
    private var bodyTexture = -1
    private var bodyTint = -1
    private var bodyTextureMix = -1
    private var pointPosition = -1
    private var pointColor = -1
    private var pointMvp = -1
    private var pointSize = -1

    private val root = FloatArray(16)
    private val part = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvp = FloatArray(16)
    private val projection = FloatArray(16)
    private val clip = FloatArray(4)
    private val localVertex = FloatArray(4)
    private val shellClipBuffer by lazy(LazyThreadSafetyMode.NONE) {
        floatBuffer(shellMesh.positions.limit() / 3 * 2)
    }
    private val shellCameraUvBuffer by lazy(LazyThreadSafetyMode.NONE) {
        floatBuffer(shellMesh.positions.limit() / 3 * 2)
    }
    private val particlePositions = floatBuffer(particleMax * 3)
    private val particleColors = floatBuffer(particleMax * 4)

    fun onSurfaceCreated() {
        bodyProgram = linkProgram(BODY_VERTEX, BODY_FRAGMENT)
        pointProgram = linkProgram(POINT_VERTEX, POINT_FRAGMENT)
        if (bodyProgram != 0) {
            bodyPosition = GLES20.glGetAttribLocation(bodyProgram, "a_Position")
            bodyNormal = GLES20.glGetAttribLocation(bodyProgram, "a_Normal")
            bodyCameraUv = GLES20.glGetAttribLocation(bodyProgram, "a_CameraUv")
            bodyMvp = GLES20.glGetUniformLocation(bodyProgram, "u_Mvp")
            bodyTexture = GLES20.glGetUniformLocation(bodyProgram, "u_Camera")
            bodyTint = GLES20.glGetUniformLocation(bodyProgram, "u_Tint")
            bodyTextureMix = GLES20.glGetUniformLocation(bodyProgram, "u_TextureMix")
        }
        if (pointProgram != 0) {
            pointPosition = GLES20.glGetAttribLocation(pointProgram, "a_Position")
            pointColor = GLES20.glGetAttribLocation(pointProgram, "a_Color")
            pointMvp = GLES20.glGetUniformLocation(pointProgram, "u_Mvp")
            pointSize = GLES20.glGetUniformLocation(pointProgram, "u_PointSize")
        }
    }

    fun draw(frame: Frame, cameraTextureId: Int, view: VisualShieldView) {
        val board = view.bodySurfaceGpu
        val channels = view.body84
        if (!board.enabled || board.bodyOutput <= 0f || bodyProgram == 0 || pointProgram == 0) return

        try {
            frame.camera.getProjectionMatrix(projection, 0, 0.1f, 40f)
        } catch (e: Exception) {
            Log.w(TAG, "Could not read ARCore camera projection for body overlay", e)
            return
        }

        val sparePulse = if (board.atomSpareActive) {
            1f + 0.045f * board.atomSpareLevel.coerceIn(0f, 1f) *
                sin(android.os.SystemClock.elapsedRealtime() / 180.0).toFloat()
        } else 1f
        val wave = if (board.waveSpareActive) {
            board.waveSpareLevel.coerceIn(0f, 1f) *
                (0.45f + channels.bulkWaveSpare.coerceIn(0f, 1f) * 0.55f) *
                (0.50f + view.poseSurface.bodyWaveSpareLv.coerceIn(0f, 1f) * 0.50f)
        } else 0f
        val motionGain = if (board.movementOn) board.movementOutput.coerceIn(0f, 1f) else 0f
        val rootX = board.movementX.coerceIn(-0.45f, 0.45f) * motionGain
        val rootY = board.movementY.coerceIn(-0.35f, 0.35f) * motionGain
        val rootZ = -2.75f + board.movementZ.coerceIn(-0.25f, 0.25f) * motionGain
        val phase = android.os.SystemClock.elapsedRealtime() / 1000f
        Matrix.setIdentityM(root, 0)
        Matrix.translateM(root, 0, rootX, rootY, rootZ)
        Matrix.rotateM(root, 0, (rootY * 24f).coerceIn(-18f, 18f), 1f, 0f, 0f)
        Matrix.rotateM(root, 0, (rootX * -28f).coerceIn(-22f, 22f), 0f, 1f, 0f)
        Matrix.rotateM(root, 0, sin(phase * 1.3f) * wave * 4f, 0f, 0f, 1f)

        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        GLES20.glUseProgram(bodyProgram)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, cameraTextureId)
        GLES20.glUniform1i(bodyTexture, 0)
        GLES20.glUniform1f(bodyTextureMix, 0.56f)

        val opacity = (0.20f + board.bodyOutput * 0.42f + channels.avgOut * 0.20f)
            .coerceIn(0.12f, 0.76f) * board.level.coerceIn(0f, 1f)
        drawContinuousShell(frame, cameraTextureId, projection, root, opacity, wave, phase, sparePulse)

        drawParticles(view, projection, root, phase, wave)
        GLES20.glDepthMask(false)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    private fun fillCameraUv(
        frame: Frame,
        modelViewProjection: FloatArray,
        source: GpuMesh,
        workClipBuffer: FloatBuffer,
        workUvBuffer: FloatBuffer
    ) {
        workClipBuffer.clear()
        val count = source.positions.limit() / 3
        for (i in 0 until count) {
            val p = i * 3
            localVertex[0] = source.positions.get(p)
            localVertex[1] = source.positions.get(p + 1)
            localVertex[2] = source.positions.get(p + 2)
            localVertex[3] = 1f
            Matrix.multiplyMV(
                clip, 0, modelViewProjection, 0,
                localVertex, 0
            )
            val inverseW = if (kotlin.math.abs(clip[3]) > 0.00001f) 1f / clip[3] else 1f
            workClipBuffer.put(clip[0] * inverseW)
            workClipBuffer.put(clip[1] * inverseW)
        }
        workClipBuffer.flip()
        workUvBuffer.clear()
        workUvBuffer.limit(count * 2)
        try {
            frame.transformCoordinates2d(
                Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,
                workClipBuffer,
                Coordinates2d.TEXTURE_NORMALIZED,
                workUvBuffer
            )
            workUvBuffer.position(0)
        } catch (e: Exception) {
            // NDC-to-image fallback works for both the old sphere helper and the new shell mesh.
            workUvBuffer.clear()
            for (i in 0 until count) {
                val ndcX = workClipBuffer.get(i * 2)
                val ndcY = workClipBuffer.get(i * 2 + 1)
                workUvBuffer.put(((ndcX + 1f) * 0.5f).coerceIn(0f, 1f))
                workUvBuffer.put(((1f - ndcY) * 0.5f).coerceIn(0f, 1f))
            }
            workUvBuffer.flip()
            Log.w(TAG, "Camera UV transform failed for body model", e)
        }
    }

    private fun drawContinuousShell(
        frame: Frame,
        cameraTextureId: Int,
        projection: FloatArray,
        modelRoot: FloatArray,
        opacity: Float,
        wave: Float,
        phase: Float,
        sparePulse: Float
    ) {
        val shell = shellMesh
        Matrix.setIdentityM(part, 0)
        val breathe = (1f + 0.012f * wave * sin(phase * 1.7f)) * sparePulse
        Matrix.scaleM(part, 0, 1f, breathe, 1f)
        Matrix.multiplyMM(modelMatrix, 0, modelRoot, 0, part, 0)
        Matrix.multiplyMM(mvp, 0, projection, 0, modelMatrix, 0)

        fillCameraUv(frame, mvp, shell, shellClipBuffer, shellCameraUvBuffer)
        GLES20.glUniformMatrix4fv(bodyMvp, 1, false, mvp, 0)
        GLES20.glUniform4f(bodyTint, 0x26 / 255f, 0xC6 / 255f, 0xDA / 255f, opacity.coerceIn(0f, 0.8f))
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, cameraTextureId)
        shell.positions.position(0)
        shell.normals.position(0)
        shellCameraUvBuffer.position(0)
        GLES20.glEnableVertexAttribArray(bodyPosition)
        GLES20.glVertexAttribPointer(bodyPosition, 3, GLES20.GL_FLOAT, false, 0, shell.positions)
        GLES20.glEnableVertexAttribArray(bodyNormal)
        GLES20.glVertexAttribPointer(bodyNormal, 3, GLES20.GL_FLOAT, false, 0, shell.normals)
        GLES20.glEnableVertexAttribArray(bodyCameraUv)
        GLES20.glVertexAttribPointer(bodyCameraUv, 2, GLES20.GL_FLOAT, false, 0, shellCameraUvBuffer)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, shell.vertexCount)
        GLES20.glDisableVertexAttribArray(bodyPosition)
        GLES20.glDisableVertexAttribArray(bodyNormal)
        GLES20.glDisableVertexAttribArray(bodyCameraUv)
    }

    private fun drawParticles(
        view: VisualShieldView,
        projection: FloatArray,
        modelRoot: FloatArray,
        phase: Float,
        wave: Float
    ) {
        val board = view.bodySurfaceGpu
        if (!board.particlesOn || board.particleCount <= 0 || pointProgram == 0) return
        // The first 84 points are the live 84 body channels; extra points are the particle field.
        val count = maxOf(Body84Channels.NAMES.size, board.particleCount).coerceIn(1, particleMax)
        particlePositions.clear()
        particleColors.clear()
        val signal = (board.bodyOutput * board.particleLevel.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        val bodyChannels = view.body84.channels
        for (i in 0 until count) {
            val u = (i + 0.5f) / count
            val angle = i * 2.399963f + phase * (0.45f + wave * 0.9f)
            val channelIndex = i % bodyChannels.size
            val bodyChannel = bodyChannels[channelIndex]
            val channelOut = bodyChannel.out.coerceIn(0f, 1f)
            val anchor = body84Anchors[channelIndex]
            val x: Float
            val y: Float
            val z: Float
            if (i < Body84Channels.NAMES.size) {
                x = anchor[0] + sin(angle) * (0.012f + channelOut * 0.025f)
                y = anchor[1] + cos(angle * 1.3f) * (0.012f + channelOut * wave * 0.045f)
                z = anchor[2] + sin(angle * 0.7f) * 0.035f
            } else {
                y = -0.92f + u * 2.40f
                val bodyRadius = when {
                    y > 1.28f -> 0.20f
                    y > 0.36f -> 0.39f
                    y > -0.13f -> 0.30f
                    else -> 0.22f
                }
                val radius = bodyRadius + 0.06f + (i % 7) * 0.018f
                x = cos(angle) * radius
                z = sin(angle) * radius * 0.56f
            }
            particlePositions.put(x.toFloat())
            particlePositions.put(y.toFloat())
            particlePositions.put(z.toFloat())
            val alpha = (0.08f + signal * 0.42f + channelOut * 0.34f).coerceIn(0.08f, 0.82f)
            particleColors.put(0.18f + channelOut * 0.58f)
            particleColors.put(0.50f + 0.30f * u)
            particleColors.put(0.75f + channelOut * 0.20f)
            particleColors.put(alpha)
        }
        particlePositions.flip()
        particleColors.flip()

        Matrix.multiplyMM(mvp, 0, projection, 0, modelRoot, 0)
        GLES20.glUseProgram(pointProgram)
        GLES20.glUniformMatrix4fv(pointMvp, 1, false, mvp, 0)
        GLES20.glUniform1f(pointSize, 2.5f + board.particleLevel.coerceIn(0f, 1f) * 8f)
        GLES20.glEnableVertexAttribArray(pointPosition)
        GLES20.glVertexAttribPointer(pointPosition, 3, GLES20.GL_FLOAT, false, 0, particlePositions)
        GLES20.glEnableVertexAttribArray(pointColor)
        GLES20.glVertexAttribPointer(pointColor, 4, GLES20.GL_FLOAT, false, 0, particleColors)
        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, count)
        GLES20.glDisableVertexAttribArray(pointPosition)
        GLES20.glDisableVertexAttribArray(pointColor)
        GLES20.glUseProgram(bodyProgram)
    }

    private fun linkProgram(vertexSource: String, fragmentSource: String): Int {
        val vertex = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource)
        val fragment = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
        if (vertex == 0 || fragment == 0) return 0
        val program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vertex)
        GLES20.glAttachShader(program, fragment)
        GLES20.glLinkProgram(program)
        val status = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, status, 0)
        GLES20.glDeleteShader(vertex)
        GLES20.glDeleteShader(fragment)
        if (status[0] == 0) {
            Log.e(TAG, "Body surface shader link failed: ${GLES20.glGetProgramInfoLog(program)}")
            GLES20.glDeleteProgram(program)
            return 0
        }
        return program
    }

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            Log.e(TAG, "Body surface shader compile failed: ${GLES20.glGetShaderInfoLog(shader)}")
            GLES20.glDeleteShader(shader)
            return 0
        }
        return shader
    }

    /** Flatten the shared watertight outer shell into GL_TRIANGLES with per-face normals. */
    private fun makeContinuousShellMesh(): GpuMesh {
        val triangles = ContinuousBodySurface.triangles
        val positions = FloatArray(triangles.size * 9)
        val normals = FloatArray(triangles.size * 9)
        var cursor = 0
        for (tri in triangles) {
            positions[cursor] = tri.ax; positions[cursor + 1] = tri.ay; positions[cursor + 2] = tri.az
            positions[cursor + 3] = tri.bx; positions[cursor + 4] = tri.by; positions[cursor + 5] = tri.bz
            positions[cursor + 6] = tri.cx; positions[cursor + 7] = tri.cy; positions[cursor + 8] = tri.cz
            repeat(3) {
                normals[cursor] = tri.nx; normals[cursor + 1] = tri.ny; normals[cursor + 2] = tri.nz
                cursor += 3
            }
        }
        return GpuMesh(
            floatBuffer(positions),
            floatBuffer(normals),
            positions.size / 3
        )
    }

    private fun makeBody84Anchors(): Array<FloatArray> =
        Body84Channels.NAMES.mapIndexed { index, name ->
            val label = name.lowercase()
            val side = if (label.contains("left")) -1f else 1f
            when {
                label.contains("head") -> floatArrayOf(0f, 1.51f, 0.02f)
                label.contains("eye") -> floatArrayOf(side * 0.075f, 1.53f, 0.13f)
                label.contains("jaw") -> floatArrayOf(0f, 1.39f, 0.12f)
                label.contains("neck") -> floatArrayOf(0f, 1.25f, 0.02f)
                label.contains("shoulder") -> floatArrayOf(side * 0.37f, 1.02f, 0f)
                label.contains("upperarm") || label.contains("arm") ->
                    floatArrayOf(side * 0.48f, 0.76f, 0f)
                label.contains("forearm") || label.contains("hand") ->
                    floatArrayOf(side * 0.53f, 0.30f, 0f)
                label.contains("finger") || label.contains("thumb") || label.contains("middle") ||
                    label.contains("ring") || label.contains("little") ->
                    floatArrayOf(side * 0.57f, 0.08f + (index % 4) * 0.025f, 0.02f)
                label.contains("leg") || label.contains("foot") || label.contains("toe") ->
                    floatArrayOf(side * 0.16f, if (label.contains("foot") || label.contains("toe")) -0.82f else -0.42f, 0.02f)
                label.contains("hip") -> floatArrayOf(0f, 0.22f, 0f)
                label.contains("chest") -> floatArrayOf(0f, 0.84f, 0.02f)
                label.contains("spine") -> floatArrayOf(0f, 0.45f + (index % 3) * 0.14f, -0.01f)
                else -> floatArrayOf(0f, -0.75f + (index % 9) * 0.22f, 0f)
            }
        }.toTypedArray()

    private fun floatBuffer(size: Int): FloatBuffer =
        ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    private fun floatBuffer(values: FloatArray): FloatBuffer =
        floatBuffer(values.size).apply { put(values); position(0) }

    private data class GpuMesh(
        val positions: FloatBuffer,
        val normals: FloatBuffer,
        val vertexCount: Int
    )

    companion object {
        private const val TAG = "GpuBodySurface"
        private const val BODY_VERTEX = """
            attribute vec3 a_Position;
            attribute vec3 a_Normal;
            attribute vec2 a_CameraUv;
            uniform mat4 u_Mvp;
            varying vec3 v_Normal;
            varying vec2 v_CameraUv;
            void main() {
                gl_Position = u_Mvp * vec4(a_Position, 1.0);
                v_Normal = a_Normal;
                v_CameraUv = a_CameraUv;
            }
        """
        private const val BODY_FRAGMENT = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            uniform samplerExternalOES u_Camera;
            uniform vec4 u_Tint;
            uniform float u_TextureMix;
            varying vec3 v_Normal;
            varying vec2 v_CameraUv;
            void main() {
                vec3 cameraColor = texture2D(u_Camera, v_CameraUv).rgb;
                vec3 normal = normalize(v_Normal);
                float light = 0.38 + 0.62 * max(dot(normal, normalize(vec3(0.35, 0.72, 0.58))), 0.0);
                vec3 surfaceColor = u_Tint.rgb * light;
                gl_FragColor = vec4(mix(cameraColor, surfaceColor, u_TextureMix), u_Tint.a);
            }
        """
        private const val POINT_VERTEX = """
            attribute vec3 a_Position;
            attribute vec4 a_Color;
            uniform mat4 u_Mvp;
            uniform float u_PointSize;
            varying vec4 v_Color;
            void main() {
                gl_Position = u_Mvp * vec4(a_Position, 1.0);
                gl_PointSize = u_PointSize;
                v_Color = a_Color;
            }
        """
        private const val POINT_FRAGMENT = """
            precision mediump float;
            varying vec4 v_Color;
            void main() {
                vec2 p = gl_PointCoord - vec2(0.5);
                float r = length(p);
                if (r > 0.5) discard;
                float soft = 1.0 - smoothstep(0.22, 0.5, r);
                gl_FragColor = vec4(v_Color.rgb, v_Color.a * soft);
            }
        """
    }
}
