package com.mizan

/** Device OBB classes: see [YoloObbCatalog]. Human seg remains primary. */

/**
 * Camera-derived, ten-region body surface controls (inside + outside).
 * Historical class name is retained for compatibility; inference is supplied
 * by HumanCameraDetector, not by a YOLO/ONNX file.
 * Every segment has the SAME controller set as pose/atmosphere:
 * thr · level · move · wave · speed · atomspare · wavespare · bipolar.
 */
class YoloSegHuman3D {

    @Volatile var obbAssetReady = false
    @Volatile var obbStatus = "place ${YoloObbCatalog.ASSET_CANDIDATES[0]} in assets"
    @Volatile var enabled = true
    @Volatile var modelName = "ML Kit pose + person mask"
    @Volatile var modelReady = false

    @Volatile var segOn = true
    @Volatile var multiSeg = true
    @Volatile var segCount = SmplBodyParts.PARSE_COUNT

    @Volatile var poseLinkOn = true
    @Volatile var poseThr = 0.40f
    @Volatile var poseLv = 0.60f
    @Volatile var poseActive = false
    @Volatile var poseOut = 0f

    @Volatile var insideAtmoOn = true
    @Volatile var insideAtmoThr = 0.38f
    @Volatile var insideAtmoLv = 0.55f
    @Volatile var insideAtmoActive = false
    @Volatile var insideAtmoOut = 0f

    @Volatile var outsideAtmoOn = true
    @Volatile var outsideAtmoThr = 0.42f
    @Volatile var outsideAtmoLv = 0.50f
    @Volatile var outsideAtmoActive = false
    @Volatile var outsideAtmoOut = 0f

    class SegCtrl(
        val label: String,
        var on: Boolean = true,
        var thr: Float = 0.35f,
        var lv: Float = 0.55f,
        var moveOn: Boolean = true,
        var moveThr: Float = 0.35f,
        var moveLv: Float = 0.50f,
        var waveOn: Boolean = true,
        var waveThr: Float = 0.35f,
        var waveLv: Float = 0.50f,
        var speedOn: Boolean = true,
        var speedThr: Float = 0.35f,
        var speedLv: Float = 0.50f,
        var atmoOn: Boolean = true,
        var atmoThr: Float = 0.38f,
        var atmoLv: Float = 0.50f,
        var waveSpareOn: Boolean = true,
        var waveSpareThr: Float = 0.40f,
        var waveSpareLv: Float = 0.48f,
        var bipOn: Boolean = true,
        var bipNeg: Float = -40f,
        var bipPos: Float = 40f,
        var active: Boolean = false,
        var out: Float = 0f,
        var moveActive: Boolean = false,
        var moveOut: Float = 0f,
        var waveActive: Boolean = false,
        var waveOut: Float = 0f,
        var speedActive: Boolean = false,
        var speedOut: Float = 0f,
        var atmoActive: Boolean = false,
        var atmoOut: Float = 0f,
        var waveSpareActive: Boolean = false,
        var waveSpareOut: Float = 0f,
        var bipHit: Boolean = false
    )

    /** Complete human-parse segments (not single) — [SmplBodyParts.PARSE]. */
    val segments = Array(SmplBodyParts.PARSE.size) { i ->
        SegCtrl(SmplBodyParts.PARSE[i])
    }

    @Volatile var bulkThr = 0.35f
    @Volatile var bulkLv = 0.55f
    @Volatile var bulkMoveThr = 0.35f
    @Volatile var bulkMoveLv = 0.50f
    @Volatile var bulkWaveThr = 0.35f
    @Volatile var bulkWaveLv = 0.50f
    @Volatile var bulkSpeedThr = 0.35f
    @Volatile var bulkSpeedLv = 0.50f
    @Volatile var bulkAtmoThr = 0.38f
    @Volatile var bulkAtmoLv = 0.50f
    @Volatile var bulkWspThr = 0.40f
    @Volatile var bulkWspLv = 0.48f

    fun applyBulkToAll() {
        segments.forEach { s ->
            s.thr = bulkThr; s.lv = bulkLv
            s.moveThr = bulkMoveThr; s.moveLv = bulkMoveLv
            s.waveThr = bulkWaveThr; s.waveLv = bulkWaveLv
            s.speedThr = bulkSpeedThr; s.speedLv = bulkSpeedLv
            s.atmoThr = bulkAtmoThr; s.atmoLv = bulkAtmoLv
            s.waveSpareThr = bulkWspThr; s.waveSpareLv = bulkWspLv
        }
    }

    @Volatile var energyIn = 0f
    @Volatile var activeSegs = 0
    @Volatile private var latestDetection = HumanDetection.none()

    fun enableRawCompleteSeg() {
        segOn = true
        multiSeg = true
        segCount = segments.size
        segments.forEach { it.on = true; it.lv = maxOf(it.lv, 0.55f) }
        insideAtmoOn = true
        outsideAtmoOn = true
    }

    fun tryLoadModel(context: android.content.Context, assetPath: String = "yolo26x-seg.onnx") {
        PtModelRuntime.tryLoad(context, preferred = assetPath.replace(".onnx", ".pt").replace(".tflite", ".pt"))
        obbAssetReady = PtModelRuntime.isReady()
        if (PtModelRuntime.loadedName != null) {
            obbStatus = PtModelRuntime.summary()
            modelName = "PT ${PtModelRuntime.loadedName} + ML Kit"
        }
        tryLoadModel(assetPath)
    }

    fun tryLoadModel(assetPath: String = "yolo26x-seg.onnx") {
        // Also scan .pt companions (TorchScript) when present
        // Caller may pass Context via tryLoadModel(context, path)

        // Kept as a compatibility entry point. It never claims that a missing
        // ONNX asset was loaded.
        modelName = "ML Kit pose + person mask"
        modelReady = false
    }

    fun setDetectorReady(available: Boolean) { modelReady = available }

    fun feedDetection(detection: HumanDetection) {
        latestDetection = detection
    }

    private fun gate(on: Boolean, e: Float, thr: Float, lv: Float): Pair<Boolean, Float> {
        val t = thr.coerceIn(0.05f, 1f)
        val a = on && e >= t
        val o = if (a) {
            (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        return a to o
    }

    @Suppress("UNUSED_PARAMETER")
    fun tick(energy: Float, db: Double = -80.0) {
        val detection = latestDetection
        val personPresent = detection.hasPerson && detection.isFresh()
        val e = if (personPresent) detection.confidence.coerceIn(0f, 1f) else 0f
        // Bipolar rails are driven by camera confidence, never microphone dB.
        val cameraDb = if (personPresent) -120.0 + e * 240.0 else -120.0
        energyIn = e
        if (!enabled || !personPresent) {
            poseActive = false; poseOut = 0f
            insideAtmoActive = false; insideAtmoOut = 0f
            outsideAtmoActive = false; outsideAtmoOut = 0f
            activeSegs = 0
            segments.forEach {
                it.active = false; it.out = 0f
                it.moveActive = false; it.moveOut = 0f
                it.waveActive = false; it.waveOut = 0f
                it.speedActive = false; it.speedOut = 0f
                it.atmoActive = false; it.atmoOut = 0f
                it.waveSpareActive = false; it.waveSpareOut = 0f
                it.bipHit = false
            }
            return
        }

        gate(poseLinkOn, detection.poseConfidence, poseThr, poseLv).let { poseActive = it.first; poseOut = it.second }
        gate(insideAtmoOn, detection.maskConfidence, insideAtmoThr, insideAtmoLv).let {
            insideAtmoActive = it.first; insideAtmoOut = it.second
        }
        gate(outsideAtmoOn, detection.maskConfidence, outsideAtmoThr, outsideAtmoLv).let {
            outsideAtmoActive = it.first; outsideAtmoOut = it.second
        }

        val n = if (multiSeg) segCount.coerceIn(1, segments.size) else 1
        activeSegs = 0
        for (i in segments.indices) {
            val s = segments[i]
            if (i >= n || !segOn || !s.on) {
                s.active = false; s.out = 0f
                s.moveActive = false; s.moveOut = 0f
                s.waveActive = false; s.waveOut = 0f
                s.speedActive = false; s.speedOut = 0f
                s.atmoActive = false; s.atmoOut = 0f
                s.waveSpareActive = false; s.waveSpareOut = 0f
                s.bipHit = false
                continue
            }
            val bias = (i * 0.035f) % 0.22f
            val lo = s.bipNeg.coerceIn(-120f, 0f).toDouble()
            val hi = s.bipPos.coerceIn(0f, 120f).toDouble()
            s.bipHit = s.bipOn && (cameraDb <= lo || cameraDb >= hi)

            val partEnergy = detection.partScores.getOrNull(i)?.coerceIn(0f, 1f) ?: 0f
            var (a, o) = gate(true, partEnergy, s.thr + bias, s.lv)
            if (s.bipHit) { a = true; o = maxOf(o, 0.22f) }
            if (poseActive) o = maxOf(o, poseOut * 0.35f)
            s.active = a; s.out = o

            gate(s.moveOn, partEnergy, s.moveThr + bias * 0.5f, s.moveLv).let {
                s.moveActive = it.first; s.moveOut = it.second
            }
            gate(s.waveOn, partEnergy, s.waveThr + bias * 0.5f, s.waveLv).let {
                s.waveActive = it.first; s.waveOut = it.second
            }
            gate(s.speedOn, partEnergy, s.speedThr + bias * 0.5f, s.speedLv).let {
                s.speedActive = it.first; s.speedOut = it.second
            }
            gate(s.atmoOn, partEnergy, s.atmoThr + bias * 0.4f, s.atmoLv).let {
                s.atmoActive = it.first; s.atmoOut = it.second
            }
            gate(s.waveSpareOn, partEnergy, s.waveSpareThr + bias * 0.4f, s.waveSpareLv).let {
                s.waveSpareActive = it.first; s.waveSpareOut = it.second
            }
            if (s.active) activeSegs++
        }
    }

    fun dampen(): Float {
        if (!enabled) return 0f
        var d = 0f
        if (poseActive) d = maxOf(d, 0.28f + poseOut * 0.36f)
        if (insideAtmoActive) d = maxOf(d, 0.26f + insideAtmoOut * 0.32f)
        if (outsideAtmoActive) d = maxOf(d, 0.24f + outsideAtmoOut * 0.30f)
        val n = segCount.coerceIn(1, segments.size)
        for (i in 0 until n) {
            val s = segments[i]
            if (s.active) d = maxOf(d, 0.20f + s.out * 0.38f)
            if (s.moveActive) d = maxOf(d, 0.16f + s.moveOut * 0.24f)
            if (s.waveActive) d = maxOf(d, 0.15f + s.waveOut * 0.22f)
            if (s.speedActive) d = maxOf(d, 0.15f + s.speedOut * 0.22f)
            if (s.atmoActive) d = maxOf(d, 0.18f + s.atmoOut * 0.26f)
            if (s.waveSpareActive) d = maxOf(d, 0.14f + s.waveSpareOut * 0.20f)
        }
        return d.coerceIn(0f, 1f)
    }

    fun statusLine(): String {
        if (!enabled) return "CAMERA BODY-SEG off"
        val tags = buildList {
            if (modelReady) add("MLKIT")
            if (poseActive) add("POSE")
            if (insideAtmoActive) add("IN-ATMO")
            if (outsideAtmoActive) add("OUT-ATMO")
            if (multiSeg) add("MULTI") else add("SINGLE")
            segments.take(segCount.coerceIn(1, segments.size)).forEach { s ->
                if (s.active) {
                    val sub = buildList {
                        add(s.label.uppercase())
                        if (s.moveActive) add("M")
                        if (s.waveActive) add("W")
                        if (s.speedActive) add("S")
                        if (s.atmoActive) add("A")
                        if (s.waveSpareActive) add("WS")
                        if (s.bipHit) add("BIP")
                    }.joinToString(".")
                    add(sub)
                }
            }
            if (isEmpty()) add("idle")
        }.joinToString("+")
        return "CAMERA BODY-SEG · $tags · segs=$activeSegs/$segCount · " +
            "pose=${(poseOut*100).toInt()}% in=${(insideAtmoOut*100).toInt()}% " +
            "out=${(outsideAtmoOut*100).toInt()}% · damp=${(dampen()*100).toInt()}%"
    }
}
