package com.mizan

/**
 * Fully body anatomy — OUTSIDE + INSIDE interconnected (not single isolated parts).
 * Outside shell ↔ skin layers ↔ muscle ↔ vessels ↔ organs ↔ CNS/brain as one system.
 * RAW COMPLETE.
 */
class FullBodyAnatomyInterconnectBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    /** Interconnect strength 0..1 — how much each layer drives the next */
    @Volatile var interconnectLv = 0.85f
    @Volatile var outsideOn = true
    @Volatile var insideOn = true
    @Volatile var thr = 0.20f
    @Volatile var lv = 0.90f

    // Outside chain
    @Volatile var outsideShell = 0f
    @Volatile var outsideSkin = 0f
    @Volatile var outsideMuscle = 0f
    @Volatile var outsideFat = 0f
    @Volatile var outsideFull = 0f

    // Inside chain
    @Volatile var insideBone = 0f
    @Volatile var insideVessel = 0f
    @Volatile var insideOrgan = 0f
    @Volatile var insideCns = 0f
    @Volatile var insideFull = 0f

    // Interconnected whole (outside ↔ inside)
    @Volatile var bodyWholeOut = 0f
    @Volatile var flowOutsideToInside = 0f
    @Volatile var flowInsideToOutside = 0f

    @Volatile var status = "FULL BODY ANATOMY interconnect idle"

    private fun lane(on: Boolean, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float) {
        if (!enabled) {
            status = "FULL BODY ANATOMY OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val k = interconnectLv.coerceIn(0.1f, 1f)

        // Outside chain (each stage fed by previous — not single)
        outsideShell = lane(outsideOn, e)
        outsideSkin = lane(outsideOn, maxOf(e, outsideShell * k))
        outsideMuscle = lane(outsideOn, maxOf(e * 0.95f, outsideSkin * k))
        outsideFat = lane(outsideOn, maxOf(e * 0.9f, outsideSkin * k * 0.9f))
        outsideFull = maxOf(outsideShell, outsideSkin, outsideMuscle, outsideFat)

        // Inside chain (fed by outside flow + energy)
        flowOutsideToInside = outsideFull * k
        insideBone = lane(insideOn, maxOf(e * 0.92f, flowOutsideToInside))
        insideVessel = lane(insideOn, maxOf(e * 0.9f, insideBone * k, flowOutsideToInside))
        insideOrgan = lane(insideOn, maxOf(e * 0.94f, insideVessel * k, flowOutsideToInside))
        insideCns = lane(insideOn, maxOf(e * 0.96f, insideOrgan * k * 0.95f, flowOutsideToInside))
        insideFull = maxOf(insideBone, insideVessel, insideOrgan, insideCns)

        // Inside feeds back to outside (interconnected, not one-way)
        flowInsideToOutside = insideFull * k * 0.9f
        outsideFull = maxOf(outsideFull, flowInsideToOutside * 0.85f)
        outsideSkin = maxOf(outsideSkin, flowInsideToOutside * 0.8f)

        bodyWholeOut = maxOf(outsideFull, insideFull)

        status =
            "OUT shell/skin/musc=${(outsideShell*100).toInt()}/${(outsideSkin*100).toInt()}/${(outsideMuscle*100).toInt()}% · " +
            "IN bone/ves/org/cns=${(insideBone*100).toInt()}/${(insideVessel*100).toInt()}/${(insideOrgan*100).toInt()}/${(insideCns*100).toInt()}% · " +
            "FLOW↔ ${(flowOutsideToInside*100).toInt()}/${(flowInsideToOutside*100).toInt()} · WHOLE=${(bodyWholeOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        val k = interconnectLv.coerceIn(0.1f, 1f)

        // Anatomy 3D — all 7 layers together, not single
        try {
            val a = v.anatomy3d
            a.enabled = true
            a.enableCompleteHumanLayers()
            // 0 Skin 1 Muscle 2 Skeleton 3 Organs 4 Vessels 5 Brain 6 Face
            if (a.layerOn.size >= 7) {
                a.layerOn[0] = outsideOn; a.layerLevel[0] = maxOf(a.layerLevel[0], outsideSkin)
                a.layerOn[1] = outsideOn; a.layerLevel[1] = maxOf(a.layerLevel[1], outsideMuscle)
                a.layerOn[2] = insideOn; a.layerLevel[2] = maxOf(a.layerLevel[2], insideBone)
                a.layerOn[3] = insideOn; a.layerLevel[3] = maxOf(a.layerLevel[3], insideOrgan)
                a.layerOn[4] = insideOn; a.layerLevel[4] = maxOf(a.layerLevel[4], insideVessel)
                a.layerOn[5] = insideOn; a.layerLevel[5] = maxOf(a.layerLevel[5], insideCns)
                a.layerOn[6] = outsideOn; a.layerLevel[6] = maxOf(a.layerLevel[6], outsideSkin * 0.9f)
            }
            a.atmosphere = maxOf(a.atmosphere, bodyWholeOut)
            try {
                a.outside.level = maxOf(a.outside.level, outsideFull)
                a.inside.level = maxOf(a.inside.level, insideFull)
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}

        // Skin atomspare outside/inside linked
        try {
            val s = v.skinAtomspare
            s.enabled = true
            s.atomSpareOn = true
            s.skinOutsideOn = true
            s.skinInsideOn = true
            s.skinOutsideOut = maxOf(s.skinOutsideOut, outsideFull)
            s.skinInsideOut = maxOf(s.skinInsideOut, insideFull)
            s.atomSpareOut = maxOf(s.atomSpareOut, bodyWholeOut)
            s.epidermisOut = maxOf(s.epidermisOut, outsideSkin)
        } catch (_: Throwable) {}

        // Shell outside ↔ inside systems
        try {
            val sh = v.anatomyShell
            sh.enabled = true
            sh.atomSpareShellOn = true
            sh.outsideShellOut = maxOf(sh.outsideShellOut, outsideShell)
            sh.insideSystemsOut = maxOf(sh.insideSystemsOut, insideFull)
            sh.insideAtmoOut = maxOf(sh.insideAtmoOut, insideOrgan, insideCns)
            sh.atomSpareShellOut = maxOf(sh.atomSpareShellOut, bodyWholeOut)
        } catch (_: Throwable) {}

        // 84 human outside/inside both on, driven together
        try {
            val h = v.body84FullHuman
            h.enabled = true
            h.outsideOn = true
            h.insideOn = true
            h.outsideOut = maxOf(h.outsideOut, outsideFull)
            h.insideOut = maxOf(h.insideOut, insideFull)
            h.atomOut = maxOf(h.atomOut, bodyWholeOut)
        } catch (_: Throwable) {}

        // Complete atomspare whole
        try {
            val c = v.completeAtomProtect
            c.enabled = true
            c.atomOn = true
            c.allPreviousAtmospheric = true
            c.atomOutsideOut = maxOf(c.atomOutsideOut, outsideFull)
            c.atomInsideOut = maxOf(c.atomInsideOut, insideFull)
            c.atomOut = maxOf(c.atomOut, bodyWholeOut)
        } catch (_: Throwable) {}

        // Body systems + brain interconnected with whole
        try {
            val f = v.bodyFreqRegen
            f.enabled = true
            f.bodySystemsOn = true
            f.brainStructuresOn = true
            f.bodyFullSysOut = maxOf(f.bodyFullSysOut, insideOrgan)
            f.bodyCnsSysOut = maxOf(f.bodyCnsSysOut, insideCns)
            f.brainFullOut = maxOf(f.brainFullOut, insideCns * k)
        } catch (_: Throwable) {}

        // Surface regions share whole (not isolated singles)
        try {
            val w = bodyWholeOut
            v.skinAll.atmosphere = maxOf(v.skinAll.atmosphere, outsideSkin, w * 0.8f)
            v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, outsideFull * 0.9f, insideOrgan * 0.7f)
            v.skinAbdomen.atmosphere = maxOf(v.skinAbdomen.atmosphere, outsideFull * 0.85f, insideOrgan * 0.75f)
            v.heart.atmosphere = maxOf(v.heart.atmosphere, insideOrgan, insideVessel)
            v.belly.atmosphere = maxOf(v.belly.atmosphere, insideOrgan)
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, insideCns, outsideSkin)
            v.neck.atmosphere = maxOf(v.neck.atmosphere, insideVessel * 0.9f)
        } catch (_: Throwable) {}
    }
}
