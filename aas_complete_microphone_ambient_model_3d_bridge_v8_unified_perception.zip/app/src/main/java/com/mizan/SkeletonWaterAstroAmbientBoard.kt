package com.mizan

/**
 * Bones & skeletal ambient (206 symbolic) · axial/appendicular ·
 * BLE water thr · daily water tracking · unlimited scale maintain ·
 * light astrological ambient · 3D model draw drive · skin/membrane link.
 * Symbolic only — not medical or predictive astrology. RAW COMPLETE.
 */
class SkeletonWaterAstroAmbientBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.20f
    @Volatile var lv = 0.85f

    // Skeleton
    @Volatile var skeletonOn = true
    @Volatile var axialOut = 0f
    @Volatile var appendicularOut = 0f
    @Volatile var skullOut = 0f
    @Volatile var spineOut = 0f
    @Volatile var ribCageOut = 0f
    @Volatile var femurOut = 0f
    @Volatile var marrowOut = 0f
    @Volatile var jointSynovial = 0f
    @Volatile var osteoblast = 0f
    @Volatile var osteoclast = 0f
    @Volatile var skeletonFull = 0f

    // BLE water digital scale
    @Volatile var waterOn = true
    @Volatile var waterThr = 0.15f
    @Volatile var waterLv = 0.90f
    @Volatile var waterOut = 0f
    @Volatile var waterLitersToday = 0f
    @Volatile var waterDailyGoalL = 3.0f
    @Volatile var waterUnlimited = true  // no hard daily cap in tracker
    @Volatile var waterScaleMaintain = true
    @Volatile var waterLastL = 0f

    // Astrological ambient (symbolic decorative channel only)
    @Volatile var astroOn = true
    @Volatile var astroOut = 0f
    @Volatile var sunPath = 0f
    @Volatile var moonPath = 0f
    @Volatile var phasePath = 0f

    @Volatile var status = "SKELETON·WATER·ASTRO idle"

    private fun lane(on: Boolean, t: Float, l: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * l).coerceIn(0f, 1f)
        val th = t.coerceIn(0.02f, 1f)
        return if (e >= th) (((e - th) / (1f - th).coerceAtLeast(0.05f)) * l).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, mineralE: Float, caE: Float, phase: Float) {
        if (!enabled) {
            status = "SKELETON·WATER·ASTRO OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val boneSrc = maxOf(e, mineralE, caE)

        axialOut = lane(skeletonOn, thr, lv, boneSrc * 0.95f)
        appendicularOut = lane(skeletonOn, thr, lv, boneSrc)
        skullOut = axialOut * 0.94f
        spineOut = axialOut * 0.96f
        ribCageOut = axialOut * 0.92f
        femurOut = appendicularOut * 0.97f
        marrowOut = lane(skeletonOn, thr, lv, boneSrc * 0.88f)
        jointSynovial = lane(skeletonOn, thr, lv, boneSrc * 0.90f)
        osteoblast = lane(skeletonOn, thr, lv, maxOf(caE, boneSrc * 0.9f))
        osteoclast = lane(skeletonOn, thr, lv, boneSrc * 0.85f)
        skeletonFull = maxOf(axialOut, appendicularOut, femurOut, skullOut)

        waterOut = lane(waterOn, waterThr, waterLv, e)
        if (waterScaleMaintain) {
            waterLitersToday = waterLitersToday * 0.999f + waterOut * 0.002f
            if (!waterUnlimited) {
                waterLitersToday = waterLitersToday.coerceAtMost(waterDailyGoalL * 1.5f)
            }
            waterLastL = waterLitersToday
        }

        // Symbolic phase-linked decorative ambient (not predictive)
        val ph = (phase % 6.2831853f)
        sunPath = lane(astroOn, 0.15f, 0.7f, e * (0.5f + 0.5f * kotlin.math.sin(ph * 0.1f)))
        moonPath = lane(astroOn, 0.15f, 0.7f, e * (0.5f + 0.5f * kotlin.math.cos(ph * 0.07f)))
        phasePath = lane(astroOn, 0.15f, 0.7f, (sunPath + moonPath) * 0.5f)
        astroOut = maxOf(sunPath, moonPath, phasePath)

        status =
            "BONE axial/app=${(axialOut*100).toInt()}/${(appendicularOut*100).toInt()}% " +
            "skull/spine/femur=${(skullOut*100).toInt()}/${(spineOut*100).toInt()}/${(femurOut*100).toInt()} · " +
            "H2O=${(waterOut*100).toInt()}% today=${"%.2f".format(waterLitersToday)}L · " +
            "ASTRO=${(astroOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun addWaterSample(liters: Float) {
        waterLitersToday += liters.coerceAtLeast(0f)
        if (!waterUnlimited) waterLitersToday = waterLitersToday.coerceAtMost(waterDailyGoalL * 2f)
        waterLastL = waterLitersToday
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        try {
            val a = v.anatomy3d
            if (a.layerOn.size > 2) {
                a.layerOn[2] = true
                a.layerLevel[2] = maxOf(a.layerLevel[2], skeletonFull)
            }
            a.atmosphere = maxOf(a.atmosphere, skeletonFull * 0.45f, waterOut * 0.25f, astroOut * 0.15f)
            // mild FX for bone emphasis
            a.audioFxLevel = maxOf(a.audioFxLevel, skeletonFull * 0.25f)
        } catch (_: Throwable) {}
        try {
            v.bodyChemBrain.calcium = maxOf(v.bodyChemBrain.calcium, osteoblast * 0.6f)
            v.bodyChemBrain.phosphorus = maxOf(v.bodyChemBrain.phosphorus, skeletonFull * 0.5f)
            v.bodyChemBrain.water = maxOf(v.bodyChemBrain.water, waterOut)
            v.bodyChemBrain.mineral = maxOf(v.bodyChemBrain.mineral, skeletonFull * 0.5f)
        } catch (_: Throwable) {}
        try {
            v.caMgProtectChem.caOut = maxOf(v.caMgProtectChem.caOut, osteoblast * 0.4f)
            v.caMgProtectChem.waterOut = maxOf(v.caMgProtectChem.waterOut, waterOut)
            v.caMgProtectChem.protectWater = maxOf(v.caMgProtectChem.protectWater, waterOut * 0.5f)
        } catch (_: Throwable) {}
        try {
            v.bioSkinCell.cutaneousMembrane = maxOf(v.bioSkinCell.cutaneousMembrane, skeletonFull * 0.2f)
            v.bioSkinCell.synovialMembrane = maxOf(v.bioSkinCell.synovialMembrane, jointSynovial)
            v.bioSkinCell.meninges = maxOf(v.bioSkinCell.meninges, skullOut * 0.3f)
        } catch (_: Throwable) {}
        try {
            v.skinAll.atmosphere = maxOf(v.skinAll.atmosphere, waterOut * 0.2f)
            v.completeAtomProtect.atomInsideOut = maxOf(v.completeAtomProtect.atomInsideOut, marrowOut * 0.4f, waterOut * 0.3f)
            v.completeAtomProtect.atomOutsideOut = maxOf(v.completeAtomProtect.atomOutsideOut, skeletonFull * 0.25f)
        } catch (_: Throwable) {}
    }
}
