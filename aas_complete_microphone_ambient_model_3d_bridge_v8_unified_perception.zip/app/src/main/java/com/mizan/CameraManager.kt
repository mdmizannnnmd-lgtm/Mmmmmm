package com.mizan

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.Camera
import android.util.Log
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import androidx.core.content.ContextCompat

/**
 * Legacy Camera API wrapper used for the non-AR preview path.
 * Must fully release the camera before ARCore Session.resume(), otherwise
 * ARCore throws CameraNotAvailableException.
 */
class CameraManager(
    private val context: Context,
    private val surfaceView: SurfaceView,
    private val humanDetector: HumanCameraDetector? = null,
    private val videoFeedbackBoard: VideoFeedbackBoard? = null
) {

    private var camera: Camera? = null
    @Volatile var lastError: String? = null
    @Volatile var running = false

    fun startCamera(): Boolean {
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            lastError = "CAMERA permission not granted"
            Log.e(TAG, lastError!!)
            return false
        }
        // Always fully release first so we never hold a stale handle
        stopCamera()
        return try {
            val cam = Camera.open(0) ?: run {
                lastError = "Camera.open returned null"
                Log.e(TAG, lastError!!)
                return false
            }
            camera = cam
            val params = cam.parameters
            if (params != null) {
                if (params.supportedPreviewFormats?.contains(ImageFormat.NV21) == true) {
                    params.previewFormat = ImageFormat.NV21
                }
                if (params.supportedFocusModes?.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE) == true) {
                    params.focusMode = Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
                }
                // Prefer a moderate preview size to reduce contention
                val sizes = params.supportedPreviewSizes
                if (!sizes.isNullOrEmpty()) {
                    val preferred = sizes
                        .filter { it.width <= 1280 && it.height <= 720 }
                        .maxByOrNull { it.width * it.height }
                        ?: sizes.minByOrNull { Math.abs(it.width * it.height - 640 * 480) }
                    preferred?.let {
                        params.setPreviewSize(it.width, it.height)
                    }
                }
                cam.parameters = params
            }
            cam.setDisplayOrientation(90)
            cam.setPreviewDisplay(surfaceView.holder)
            val info = Camera.CameraInfo()
            Camera.getCameraInfo(0, info)
            val rotation = frameRotationDegrees(info)
            cam.setPreviewCallback { bytes, source ->
                if (bytes == null) return@setPreviewCallback
                try {
                    val size = source.parameters?.previewSize ?: return@setPreviewCallback
                    videoFeedbackBoard?.feedCameraFrame(bytes, size.width, size.height)
                    humanDetector?.processNv21(bytes, size.width, size.height, rotation)
                } catch (e: Exception) {
                    Log.w(TAG, "Camera inference frame skipped", e)
                }
            }
            cam.startPreview()
            running = true
            lastError = null
            Log.d(TAG, "Camera started successfully")
            true
        } catch (e: Exception) {
            lastError = e.message ?: "camera open failed"
            Log.e(TAG, "Camera error", e)
            running = false
            forceRelease()
            false
        }
    }

    /**
     * Fully release the camera hardware. Call this before starting ARCore.
     * Safe to call multiple times / from any thread.
     */
    fun stopCamera() {
        // Anti stuck-camera: drop callbacks → stop preview → clear surface → release (Camera2/ARCore offline)
        val cam = camera
        camera = null
        running = false
        humanDetector?.reset("Camera preview stopped")
        if (cam == null) return
        try {
            try { cam.setPreviewCallback(null) } catch (_: Exception) {}
            try { cam.setPreviewCallbackWithBuffer(null) } catch (_: Exception) {}
            try { cam.stopPreview() } catch (_: Exception) {}
            try { cam.setPreviewDisplay(null as SurfaceHolder?) } catch (_: Exception) {}
            try { cam.release() } catch (_: Exception) {}
            Log.d(TAG, "Camera fully released (anti-stuck)")
        } catch (e: Exception) {
            Log.w(TAG, "stopCamera cleanup", e)
            try { cam.release() } catch (_: Exception) {}
        }
    }

    /** Force free camera for ARCore / other clients (ERROR_CAMERA_IN_USE / max cameras). */
    fun forceReleaseForArCore() {
        stopCamera()
        forceRelease()
    }

    private fun forceRelease() {
        try {
            camera?.release()
        } catch (_: Exception) {}
        camera = null
        running = false
        humanDetector?.reset("Camera unavailable")
    }

    @Suppress("DEPRECATION")
    private fun frameRotationDegrees(info: Camera.CameraInfo): Int {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        val displayDegrees = when (wm?.defaultDisplay?.rotation ?: Surface.ROTATION_0) {
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
        return if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            (info.orientation + displayDegrees) % 360
        } else {
            (info.orientation - displayDegrees + 360) % 360
        }
    }

    companion object {
        private const val TAG = "CameraManager"
    }
}
