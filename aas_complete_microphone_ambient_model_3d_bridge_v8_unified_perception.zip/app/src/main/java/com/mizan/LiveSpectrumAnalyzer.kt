package com.mizan

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Live microphone analysis for the ambient board: a 1024-point FFT of the mic signal giving
 *   · [bands]      64 log-spaced bars (0..1) for the spectrum display,
 *   · [wave]       128 waveform points (−1..1),
 *   · [centroidHz] spectral centroid (the "brightness" centre of the sound),
 *   · [domHz]      dominant frequency,
 *   · [atmoPct]    share of energy outside the dominant peak (the "atmosphere" / room tone),
 *   · [rmsDbfs] / [peakDbfs]  live microphone level in dBFS (0 dBFS = full scale).
 *
 * Read-only: it only measures the signal that [AudioProcessor] already reads, it never changes it.
 */
class LiveSpectrumAnalyzer(private val sampleRate: Int = 44100) {

    companion object {
        const val N = 1024
        const val BANDS = 64
        const val WAVE_POINTS = 128
        const val F_MIN = 20f
        const val F_MAX = 20000f
    }

    @Volatile var bands = FloatArray(BANDS)
        private set
    @Volatile var wave = FloatArray(WAVE_POINTS)
        private set
    @Volatile var centroidHz = 0f
        private set
    @Volatile var domHz = 0f
        private set
    @Volatile var atmoPct = 0f
        private set
    @Volatile var rmsDbfs = -90.0
        private set
    @Volatile var peakDbfs = -90.0
        private set

    private val re = FloatArray(N)
    private val im = FloatArray(N)
    private val window = FloatArray(N) { (0.5 - 0.5 * cos(2.0 * PI * it / (N - 1))).toFloat() }
    private val mag = FloatArray(N / 2)
    private val bandIdx = IntArray(N / 2) { k ->
        val hz = k * sampleRate.toFloat() / N
        if (hz < F_MIN) -1 else {
            val t = ln(hz / F_MIN) / ln(F_MAX / F_MIN)
            min(BANDS - 1, max(0, (t * BANDS).toInt()))
        }
    }
    private var smooth = FloatArray(BANDS)

    /** Frequency (Hz) at the centre of display bar [i]. */
    fun bandHz(i: Int): Float = F_MIN * Math.pow((F_MAX / F_MIN).toDouble(), (i + 0.5) / BANDS).toFloat()

    /** Position 0..1 along the log-frequency axis (the display bars) for [hz]. */
    fun hzToX(hz: Float): Float =
        (ln(max(hz, F_MIN) / F_MIN) / ln(F_MAX / F_MIN)).coerceIn(0f, 1f)

    fun process(pcm: ShortArray, n: Int) {
        if (n <= 0) return
        // ── level (full block) ─────────────────────────────────────────────
        var sum = 0.0
        var pk = 0
        for (i in 0 until n) {
            val s = pcm[i].toInt()
            sum += s.toDouble() * s
            val a = if (s < 0) -s else s
            if (a > pk) pk = a
        }
        val rms = sqrt(sum / n) / 32768.0
        rmsDbfs = 20.0 * log10(max(rms, 1e-5))
        peakDbfs = 20.0 * log10(max(pk / 32768.0, 1e-5))

        // ── waveform (decimated) ───────────────────────────────────────────
        val w = FloatArray(WAVE_POINTS)
        val step = max(1, n / WAVE_POINTS)
        for (i in 0 until WAVE_POINTS) w[i] = pcm[min(n - 1, i * step)] / 32768f
        wave = w

        // ── FFT of the newest N samples ────────────────────────────────────
        val start = max(0, n - N)
        for (i in 0 until N) {
            val idx = start + i
            re[i] = if (idx < n) pcm[idx] / 32768f * window[i] else 0f
            im[i] = 0f
        }
        fft()
        var total = 0f
        var wsum = 0f
        var peak = 0f
        var peakK = 0
        for (k in 1 until N / 2) {
            val m = sqrt(re[k] * re[k] + im[k] * im[k]) / (N / 4f)
            mag[k] = m
            val hz = k * sampleRate.toFloat() / N
            if (hz < F_MIN) continue
            total += m
            wsum += m * hz
            if (m > peak) { peak = m; peakK = k }
        }
        val silent = total < 1e-4f
        centroidHz = if (silent) 0f else (wsum / total)
        domHz = if (silent) 0f else peakK * sampleRate.toFloat() / N
        atmoPct = if (silent) 0f else ((total - peak) / total * 100f).coerceIn(0f, 100f)

        // ── 64 log bars (peak per bar, dB-scaled to 0..1, smoothed) ────────
        val b = FloatArray(BANDS)
        for (k in 1 until N / 2) {
            val bi = bandIdx[k]
            if (bi >= 0 && mag[k] > b[bi]) b[bi] = mag[k]
        }
        val out = FloatArray(BANDS)
        for (i in 0 until BANDS) {
            val db = 20f * log10(max(b[i], 1e-6f))          // −120 … 0
            val v = ((db + 100f) / 80f).coerceIn(0f, 1f)    // −100 dB → 0, −20 dB → 1
            smooth[i] += (v - smooth[i]) * (if (v > smooth[i]) 0.6f else 0.18f)
            out[i] = smooth[i]
        }
        bands = out
    }

    /** In-place radix-2 FFT on [re]/[im]. */
    private fun fft() {
        var j = 0
        for (i in 1 until N) {
            var bit = N shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= N) {
            val ang = -2.0 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            var i = 0
            while (i < N) {
                var cr = 1f
                var ci = 0f
                for (k in 0 until len / 2) {
                    val a = i + k
                    val c = i + k + len / 2
                    val xr = re[c] * cr - im[c] * ci
                    val xi = re[c] * ci + im[c] * cr
                    re[c] = re[a] - xr; im[c] = im[a] - xi
                    re[a] += xr; im[a] += xi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
