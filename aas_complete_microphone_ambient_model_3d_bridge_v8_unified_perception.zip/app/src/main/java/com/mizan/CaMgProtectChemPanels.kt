package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object CaMgProtectChemPanels {
    fun build(ctx: Context, root: LinearLayout, b: CaMgProtectChemBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFB0BEC5.toInt()
        p.title("Ca AMBIENT · Mg/Ca/WATER PROTECT · ENEMY DESTROY · CHEM·SKIN·CELLS THR", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("CALCIUM AMBIENT (model + scale path)", c)
        p.switch("Ca ON", b.caOn) { b.caOn = it }
        p.seek("Ca thr", 0.05f, 0.98f, b.caThr) { b.caThr = it }
        p.seek("Ca level", 0f, 1.5f, b.caLv) { b.caLv = it }

        p.title("ENEMY DESTROY Mg / Ca / WATER", c)
        p.switch("Enemy destroy detect ON", b.enemyDestroyOn) { b.enemyDestroyOn = it }
        p.seek("Enemy destroy thr", 0.05f, 0.98f, b.enemyDestroyThr) { b.enemyDestroyThr = it }
        p.seek("Enemy destroy level", 0f, 1.5f, b.enemyDestroyLv) { b.enemyDestroyLv = it }

        p.title("MY PROTECTION Mg · Ca · WATER · CHEM · SKIN · CELLS", c)
        p.switch("Protection ON", b.protectOn) { b.protectOn = it }
        p.seek("Protect thr", 0.05f, 0.98f, b.protectThr) { b.protectThr = it }
        p.seek("Protect level", 0f, 1.5f, b.protectLv) { b.protectLv = it }

        p.title("CHEMICAL · SKIN · CELLS THRESHOLDS", c)
        p.switch("Chem thr ON", b.chemThrOn) { b.chemThrOn = it }
        p.seek("Chem thr / lv", 0.05f, 0.98f, b.chemThr) { b.chemThr = it }
        p.seek("Chem level", 0f, 1.5f, b.chemLv) { b.chemLv = it }
        p.switch("Skin thr ON", b.skinThrOn) { b.skinThrOn = it }
        p.seek("Skin thr", 0.05f, 0.98f, b.skinThr) { b.skinThr = it }
        p.seek("Skin level", 0f, 1.5f, b.skinLv) { b.skinLv = it }
        p.switch("Cells thr ON", b.cellsThrOn) { b.cellsThrOn = it }
        p.seek("Cells thr", 0.05f, 0.98f, b.cellsThr) { b.cellsThr = it }
        p.seek("Cells level", 0f, 1.5f, b.cellsLv) { b.cellsLv = it }

        val st = p.status("Ca·Mg PROT —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 220) }
        })
    }
}
