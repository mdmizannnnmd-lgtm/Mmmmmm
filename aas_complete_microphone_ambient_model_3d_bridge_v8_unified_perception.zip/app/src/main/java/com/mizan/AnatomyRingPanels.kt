package com.mizan

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.Switch

/** Control panel for the rings + balls that sit on the 3D anatomy body (inside + outside). */
object AnatomyRingPanels {

    /** Returns the RAW COMPLETE switch. */
    fun build(ctx: Context, root: LinearLayout, view: VisualShieldView): Switch {
        val rb = view.ringBoard
        val p = PanelBuilder(ctx, root)
        val gold = Color.rgb(0xFF, 0xB7, 0x4D)
        val grey = Color.rgb(0xB0, 0xBE, 0xC5)

        p.title("RINGS + BALLS · 3D ANATOMY BODY · INSIDE + OUTSIDE", gold)
        p.note("Every ring and ball of the body regions sits on the complete 3D body: an OUTSIDE ring + ball on the skin, an INSIDE ring + ball on the organ / bone / brain under it. They turn, shrink and fade with the body.")
        p.switch("3D anatomy rings + balls ON", rb.enabled) { rb.enabled = it }
        val raw = p.switch("RAW COMPLETE rings + balls (all layers · live signal untouched · no threshold · gain · rails · tuning)", rb.rawComplete) {
            rb.setRawAll(it)
        }
        p.note("RAW shows every ring and ball on both layers; your switches come back when RAW is off.")
        p.switch("Replace the flat 2D rings and eye balls with these 3D ones", rb.replace2d) { rb.replace2d = it }

        p.title("Draw", grey)
        p.switch("Rings", rb.ringsOn) { rb.ringsOn = it }
        p.switch("Balls", rb.ballsOn) { rb.ballsOn = it }
        p.switch("Outside layer (skin / face)", rb.outsideOn) { rb.outsideOn = it }
        p.switch("Inside layer (organs / bones / brain)", rb.insideOn) { rb.insideOn = it }
        p.switch("Connector lines (outside ring ↔ inside organ)", rb.connectorsOn) { rb.connectorsOn = it }
        p.switch("Labels", rb.labelsOn) { rb.labelsOn = it }
        p.switch("Eye detail (iris + pupil on the eye balls)", rb.eyeDetailOn) { rb.eyeDetailOn = it }
        p.switch("84 body-channel balls on the body", rb.channelBallsOn) { rb.channelBallsOn = it }

        p.title("Levels · sizes", grey)
        p.seek("Ring level", 0f, 1.5f, rb.ringLevel) { rb.ringLevel = it }
        p.seek("Ball level", 0f, 1.5f, rb.ballLevel) { rb.ballLevel = it }
        p.seek("Outside level", 0f, 1.5f, rb.outsideLevel) { rb.outsideLevel = it }
        p.seek("Inside level", 0f, 1.5f, rb.insideLevel) { rb.insideLevel = it }
        p.seek("Ring size", 0.3f, 2.5f, rb.ringScale) { rb.ringScale = it }
        p.seek("Ball size", 0.3f, 2.5f, rb.ballScale) { rb.ballScale = it }
        p.seek("Ring line width", 0.3f, 4f, rb.ringWidth) { rb.ringWidth = it }
        p.seek("Channel ball size", 0.3f, 3f, rb.channelScale) { rb.channelScale = it }

        p.title("Body groups", grey)
        for (g in 0 until AnatomyRingBoard.GROUP_COUNT) {
            p.switch(AnatomyRingBoard.GROUP_NAMES[g], rb.groupOn[g]) { rb.groupOn[g] = it }
            p.seek("Level", 0f, 1.5f, rb.groupLevel[g]) { rb.groupLevel[g] = it }
        }

        p.title("Each ring + ball", grey)
        for (r in rb.rings) {
            p.switch(r.label, r.on) { r.on = it }
        }

        pathControls(p, "INSIDE PATH (rings + balls on organs · bones · brain)", rb.inside)
        pathControls(p, "OUTSIDE PATH (rings + balls on skin · face)", rb.outside)

        val t = rb.tuning
        p.title("Rings + balls visual", grey)
        p.seek("Contrast", 0f, 2f, t.contrast) { t.contrast = it }
        p.seek("Contrast threshold", 0f, 1f, t.contrastThr) { t.contrastThr = it }
        p.seek("Brightness", -1f, 1f, t.brightness) { t.brightness = it }
        p.seek("Brightness threshold", 0f, 1f, t.brightnessThr) { t.brightnessThr = it }
        p.seek("Colour level (saturation)", 0f, 2f, rb.colourLevel) { rb.colourLevel = it }
        p.seek("Colour threshold R", 0f, 255f, t.thrR.toFloat(), 0) { t.thrR = it.toInt() }
        p.seek("Colour threshold G", 0f, 255f, t.thrG.toFloat(), 0) { t.thrG = it.toInt() }
        p.seek("Colour threshold B", 0f, 255f, t.thrB.toFloat(), 0) { t.thrB = it.toInt() }
        p.seek("Threshold softness", 0f, 1f, t.softness) { t.softness = it }
        p.button("Colour threshold mode: ${VisualShieldView.EyeTuning.MODE_NAMES[t.mode]} (tap to change)") { btn ->
            t.mode = (t.mode + 1) % VisualShieldView.EyeTuning.MODE_COUNT
            btn.text = "Colour threshold mode: ${VisualShieldView.EyeTuning.MODE_NAMES[t.mode]} (tap to change)"
        }
        p.switch("Invert colours", t.invert) { t.invert = it }

        val status = p.status("RINGS + BALLS 3D —", gold)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                status.text = rb.statusLine()
                h.postDelayed(this, 200)
            }
        })
        // 3D anatomy INSIDE warp + inside rotation (centroid · vertical)
        AnatomyInsidePanels.build(ctx, root, view.anatomy3d.insideFx)
        return raw
    }

    private fun pathControls(p: PanelBuilder, name: String, sp: SignalPath) {
        p.title(name, Color.rgb(0xB0, 0xBE, 0xC5))
        p.switch("Active", sp.on) { sp.on = it }
        p.seek("Threshold", 0f, 1f, sp.thr) { sp.thr = it }
        p.seek("Level", 0f, 1f, sp.level) { sp.level = it }
        p.seek("Gain below threshold (dB)", -300f, 0f, sp.gainNegDb, 0) { sp.gainNegDb = it }
        p.seek("Gain above threshold (dB)", 0f, 300f, sp.gainPosDb, 0) { sp.gainPosDb = it }
        p.switch("Bipolar ±120 dB rails", sp.bipOn) { sp.bipOn = it }
        p.seek("FLOOR rail (dB)", -120f, 0f, sp.bipNeg, 0) { sp.bipNeg = it }
        p.seek("OVER rail (dB)", 0f, 120f, sp.bipPos, 0) { sp.bipPos = it }
        p.seek("Attack (ms)", 1f, 500f, sp.attackMs.toFloat(), 0) { sp.attackMs = it.toInt().coerceAtLeast(1) }
        p.seek("Release (ms)", 1f, 2000f, sp.releaseMs.toFloat(), 0) { sp.releaseMs = it.toInt().coerceAtLeast(1) }
    }
}
