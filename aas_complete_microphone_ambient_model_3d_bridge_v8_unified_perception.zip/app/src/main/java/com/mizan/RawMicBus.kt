package com.mizan

import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Single-source raw microphone state.
 *
 * AudioProcessor is the only component that owns AudioRecord. Every other
 * subsystem reads this immutable snapshot, so the project stays microphone
 * driven without opening competing microphone devices.
 */
object RawMicBus {
    @Volatile var sampleRate: Int = 44100
        private set
    @Volatile var channels: Int = 1
        private set
    @Volatile var sequence: Long = 0
        private set

    @Volatile var rms: Float = 0f
        private set
    @Volatile var peak: Float = 0f
        private set
    @Volatile var dbfs: Float = -80f
        private set
    @Volatile var dominantHz: Float = 0f
        private set
    @Volatile var centroidHz: Float = 0f
        private set

    /** 0..1 raw microphone level derived from PCM16 RMS. */
    @Volatile var level: Float = 0f
        private set

    /** Monotonic timestamp of the latest frame. */
    @Volatile var timestampMs: Long = 0L
        private set

    /** Latest untouched PCM16 mono frame. A defensive copy is returned to callers. */
    @Volatile private var latestPcm: ShortArray = ShortArray(0)
    @Volatile private var latestRawInterleaved: ShortArray = ShortArray(0)
    @Volatile var latestRawInterleavedLength: Int = 0
        private set
    @Volatile var latestPcmLength: Int = 0
        private set

    private val seq = AtomicLong(0)
    private val listeners = CopyOnWriteArrayList<(RawMicFrame) -> Unit>()

    /** Subscribe to every raw microphone frame. The callback is invoked from the audio thread. */
    fun subscribe(listener: (RawMicFrame) -> Unit): AutoCloseable {
        listeners += listener
        return AutoCloseable { listeners -= listener }
    }

    /** Defensive snapshot of the latest untouched PCM16 frame. */
    fun latestPcmSnapshot(): ShortArray = latestPcm.copyOf(latestPcmLength.coerceAtMost(latestPcm.size))

    /** Exact interleaved PCM16 snapshot captured from AudioRecord. */
    fun latestRawInterleavedSnapshot(): ShortArray =
        latestRawInterleaved.copyOf(latestRawInterleavedLength.coerceAtMost(latestRawInterleaved.size))

    fun publish(
        pcm: ShortArray,
        length: Int,
        rate: Int,
        channelCount: Int,
        dominant: Float = 0f,
        centroid: Float = 0f,
        rawInterleaved: ShortArray? = null,
        rawInterleavedLength: Int = rawInterleaved?.size ?: length
    ) {
        val n = length.coerceIn(0, pcm.size)
        if (n <= 0) return

        var sum = 0.0
        var maxAbs = 0
        for (i in 0 until n) {
            val v = pcm[i].toInt()
            sum += v.toDouble() * v.toDouble()
            val a = kotlin.math.abs(v)
            if (a > maxAbs) maxAbs = a
        }
        val r = (sqrt(sum / n) / 32768.0).toFloat().coerceIn(0f, 1f)
        val db = (20.0 * log10(r.toDouble().coerceAtLeast(1e-5))).toFloat()

        sampleRate = rate
        channels = channelCount
        rms = r
        peak = (maxAbs / 32768f).coerceIn(0f, 1f)
        dbfs = db.coerceIn(-100f, 0f)
        level = ((db + 80f) / 80f).coerceIn(0f, 1f)
        dominantHz = dominant.coerceAtLeast(0f)
        centroidHz = centroid.coerceAtLeast(0f)
        val now = System.currentTimeMillis()
        val newSequence = seq.incrementAndGet()
        val copy = pcm.copyOf(n)
        latestPcm = copy
        latestPcmLength = n
        val raw = rawInterleaved ?: pcm
        val rawN = rawInterleavedLength.coerceIn(0, raw.size)
        latestRawInterleaved = raw.copyOf(rawN)
        latestRawInterleavedLength = rawN
        timestampMs = now
        sequence = newSequence

        val frame = RawMicFrame(
            pcm = copy,
            rawInterleavedPcm = latestRawInterleaved.copyOf(latestRawInterleavedLength),
            length = n,
            sampleRate = rate,
            channels = channelCount,
            sequence = newSequence,
            timestampMs = now,
            rms = rms,
            peak = peak,
            dbfs = dbfs,
            dominantHz = dominantHz,
            centroidHz = centroidHz
        )
        RawMicDiagnostics.onPublished(now)
        for (listener in listeners) {
            try { listener(frame) } catch (_: Throwable) { RawMicDiagnostics.onListenerError() }
        }
        // Additive system bridge: existing RawMicBus subscribers remain unchanged.
        MicSignalBridge.onFrame(frame)
    }

    fun clear() {
        rms = 0f
        peak = 0f
        dbfs = -80f
        level = 0f
        dominantHz = 0f
        centroidHz = 0f
        latestPcm = ShortArray(0)
        latestPcmLength = 0
        latestRawInterleaved = ShortArray(0)
        latestRawInterleavedLength = 0
        timestampMs = System.currentTimeMillis()
    }
}
