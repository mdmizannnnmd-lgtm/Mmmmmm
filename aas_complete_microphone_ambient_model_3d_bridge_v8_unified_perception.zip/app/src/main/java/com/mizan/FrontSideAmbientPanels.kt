package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object FrontSideAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: FrontSideAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF81D4FA.toInt()
        p.title("EYE/BODY · FRONT·BACK·L·R·UP·DOWN 3D AMBIENT", c)
        p.switch("Front ambient master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("EYE FRONT SIDE", c)
        p.switch("Eye front ambient ON", b.eyeFrontOn) { b.eyeFrontOn = it }
        p.seek("Eye front thr", 0.05f, 0.98f, b.eyeFrontThr) { b.eyeFrontThr = it }
        p.seek("Eye front level", 0f, 1.5f, b.eyeFrontLv) { b.eyeFrontLv = it }
        p.switch("Eye front bipolar ±", b.eyeFrontBipolarOn) { b.eyeFrontBipolarOn = it }
        p.seek("Eye bip −dB", -120f, 0f, b.eyeFrontBipNeg) { b.eyeFrontBipNeg = it }
        p.seek("Eye bip +dB", 0f, 120f, b.eyeFrontBipPos) { b.eyeFrontBipPos = it }

        p.title("BODY FRONT SIDE", c)
        p.switch("Body front ambient ON", b.bodyFrontOn) { b.bodyFrontOn = it }
        p.seek("Body front thr", 0.05f, 0.98f, b.bodyFrontThr) { b.bodyFrontThr = it }
        p.seek("Body front level", 0f, 1.5f, b.bodyFrontLv) { b.bodyFrontLv = it }
        p.switch("Body front bipolar ±", b.bodyFrontBipolarOn) { b.bodyFrontBipolarOn = it }
        p.seek("Body bip −dB", -120f, 0f, b.bodyFrontBipNeg) { b.bodyFrontBipNeg = it }
        p.seek("Body bip +dB", 0f, 120f, b.bodyFrontBipPos) { b.bodyFrontBipPos = it }

        p.title("BODY BACK SIDE", c)
        p.switch("Body back ambient ON", b.bodyBackOn) { b.bodyBackOn = it }
        p.seek("Body back thr", 0.05f, 0.98f, b.bodyBackThr) { b.bodyBackThr = it }
        p.seek("Body back level", 0f, 1.5f, b.bodyBackLv) { b.bodyBackLv = it }
        p.switch("Body back bipolar ±", b.bodyBackBipolarOn) { b.bodyBackBipolarOn = it }

        p.title("BODY LEFT · RIGHT 3D", c)
        p.switch("Body left ambient ON", b.bodyLeftOn) { b.bodyLeftOn = it }
        p.seek("Body left thr / lv", 0.05f, 0.98f, b.bodyLeftThr) { b.bodyLeftThr = it }
        p.seek("Body left level", 0f, 1.5f, b.bodyLeftLv) { b.bodyLeftLv = it }
        p.switch("Body right ambient ON", b.bodyRightOn) { b.bodyRightOn = it }
        p.seek("Body right thr", 0.05f, 0.98f, b.bodyRightThr) { b.bodyRightThr = it }
        p.seek("Body right level", 0f, 1.5f, b.bodyRightLv) { b.bodyRightLv = it }
        p.switch("Side bipolar ±", b.bodySideBipolarOn) { b.bodySideBipolarOn = it }

        p.title("EYE BACK (posterior)", c)
        p.switch("Eye back ambient ON", b.eyeBackOn) { b.eyeBackOn = it }
        p.seek("Eye back thr / lv", 0.05f, 0.98f, b.eyeBackThr) { b.eyeBackThr = it }
        p.seek("Eye back level", 0f, 1.5f, b.eyeBackLv) { b.eyeBackLv = it }

        p.title("BODY UP · DOWN 3D", c)
        p.switch("Body up ambient ON", b.bodyUpOn) { b.bodyUpOn = it }
        p.seek("Body up thr", 0.05f, 0.98f, b.bodyUpThr) { b.bodyUpThr = it }
        p.seek("Body up level", 0f, 1.5f, b.bodyUpLv) { b.bodyUpLv = it }
        p.switch("Body down ambient ON", b.bodyDownOn) { b.bodyDownOn = it }
        p.seek("Body down thr", 0.05f, 0.98f, b.bodyDownThr) { b.bodyDownThr = it }
        p.seek("Body down level", 0f, 1.5f, b.bodyDownLv) { b.bodyDownLv = it }
        p.switch("Up/Down bipolar ±", b.bodyUpDownBipolarOn) { b.bodyUpDownBipolarOn = it }

        val st = p.status("FRONT —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
