package com.mizan

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/**
 * MEMORY PATHS — one small persistent store for every place and setting the app should remember between runs:
 *  · the sound-bank folder the user picked (SD card / USB / internal, as a persisted SAF tree uri),
 *  · recent folders, the last track + position, volume / loop / shuffle,
 *  · the oneness settings (brain ↔ anatomy ↔ rings ↔ sound bank).
 *
 * Call [init] once (MainActivity.onCreate). Every getter has a safe default if [init] was not called.
 */
object MemoryPaths {
    private const val PREFS = "mizan_memory_paths"
    private const val K_TREE = "sound_tree_uri"
    private const val K_RECENT = "sound_recent_trees"
    private const val K_LAST_TRACK = "last_track_uri"
    private const val K_LAST_NAME = "last_track_name"
    private const val K_LAST_POS = "last_track_pos_ms"
    private const val MAX_RECENT = 8

    @Volatile private var sp: SharedPreferences? = null

    fun init(ctx: Context) {
        if (sp == null) sp = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    // ── sound bank folder ────────────────────────────────────────────────────
    var soundTreeUri: String?
        get() = sp?.getString(K_TREE, null)
        set(v) {
            sp?.edit()?.putString(K_TREE, v)?.apply()
            if (v != null) addRecent(v)
        }

    fun recentTrees(): List<String> {
        val raw = sp?.getString(K_RECENT, null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { a.getString(it) }
        } catch (_: Exception) { emptyList() }
    }

    private fun addRecent(uri: String) {
        val list = recentTrees().toMutableList()
        list.remove(uri)
        list.add(0, uri)
        while (list.size > MAX_RECENT) list.removeAt(list.size - 1)
        sp?.edit()?.putString(K_RECENT, JSONArray(list).toString())?.apply()
    }

    fun forgetTree() { sp?.edit()?.remove(K_TREE)?.apply() }

    // ── last track ───────────────────────────────────────────────────────────
    var lastTrackUri: String?
        get() = sp?.getString(K_LAST_TRACK, null)
        set(v) { sp?.edit()?.putString(K_LAST_TRACK, v)?.apply() }

    var lastTrackName: String?
        get() = sp?.getString(K_LAST_NAME, null)
        set(v) { sp?.edit()?.putString(K_LAST_NAME, v)?.apply() }

    var lastPositionMs: Int
        get() = sp?.getInt(K_LAST_POS, 0) ?: 0
        set(v) { sp?.edit()?.putInt(K_LAST_POS, v)?.apply() }

    // ── generic settings ─────────────────────────────────────────────────────
    fun getBool(key: String, def: Boolean): Boolean = sp?.getBoolean(key, def) ?: def
    fun putBool(key: String, v: Boolean) { sp?.edit()?.putBoolean(key, v)?.apply() }
    fun getFloat(key: String, def: Float): Float = sp?.getFloat(key, def) ?: def
    fun putFloat(key: String, v: Float) { sp?.edit()?.putFloat(key, v)?.apply() }
    fun getString(key: String, def: String?): String? = sp?.getString(key, def) ?: def
    fun putString(key: String, v: String?) { sp?.edit()?.putString(key, v)?.apply() }

    /** Short readable summary for the status line. */
    fun summary(): String =
        "MEMORY · folder=${soundTreeUri?.let { shortUri(it) } ?: "none"} · last=${lastTrackName ?: "none"} · recent=${recentTrees().size}"

    fun shortUri(u: String): String = android.net.Uri.decode(u).substringAfterLast(':').ifEmpty { u.takeLast(24) }
}
