package com.mizan

/**
 * Echo-tabs style effect protection (from prior aratombox/feka Echo master-anti + shields).
 * Adjustable paths: body AS/WS, knife, any-effect, master anti-scan, eyes L/R pitch protect.
 * Pure Kotlin — drives [SoundBankGuard] + armor factors.
 */
class EchoEffectProtection(private val bank: SoundBankGuard) {

    @Volatile var enabled = true
    @Volatile var masterAntiOn = true
    @Volatile var masterAntiLv = 0.85f

    @Volatile var bodyAsShieldOn = true
    @Volatile var bodyAsThr = 0.35f
    @Volatile var bodyAsLv = 0.80f

    @Volatile var bodyWsShieldOn = true
    @Volatile var bodyWsThr = 0.35f
    @Volatile var bodyWsLv = 0.75f

    @Volatile var knifeShieldOn = true
    @Volatile var knifeShieldLv = 0.80f

    @Volatile var anyEffectOn = true
    @Volatile var anyEffectThr = 0.30f
    @Volatile var anyEffectLv = 0.85f

    @Volatile var eyesPitchProtL = true
    @Volatile var eyesPitchProtR = true
    @Volatile var eyesPitchThrL = 0.30f
    @Volatile var eyesPitchThrR = 0.30f
    @Volatile var eyesPitchLvL = 0.70f
    @Volatile var eyesPitchLvR = 0.70f

    @Volatile var antiBypassOn = true
    @Volatile var antiBypassThr = 0.40f
    @Volatile var antiBypassLv = 0.70f

    @Volatile var lastStatus = "echo-protect idle"
        private set

    /** Apply adjustable protection each audio/visual frame. */
    fun tick(enemyEnergy: Float, knifeOut: Float, modelDrive: Float = 1f) {
        if (!enabled) {
            lastStatus = "echo-protect OFF"
            return
        }
        val drive = (0.25f + 0.75f * modelDrive.coerceIn(0f, 1f))
        val e = enemyEnergy.coerceIn(0f, 1f)

        if (masterAntiOn) {
            bank.enemyMasterShieldOn = true
            bank.enemyMasterShieldLv = (masterAntiLv * drive).coerceIn(0.1f, 1f)
            bank.arRealityShieldOn = true
            bank.protectBodyOn = true
            bank.protectLv = (masterAntiLv * drive).coerceIn(0.1f, 1f)
        }

        if (bodyAsShieldOn && e >= bodyAsThr * drive) {
            bank.protectMoveOn = true
            bank.protectSpeedOn = true
            bank.protectWaveOn = true
            bank.protectLv = maxOf(bank.protectLv, bodyAsLv * drive)
        }
        if (bodyWsShieldOn && e >= bodyWsThr * drive) {
            bank.protectWaveOn = true
            bank.protectSpeedOn = true
            bank.protectLv = maxOf(bank.protectLv, bodyWsLv * drive)
        }
        if (knifeShieldOn) {
            bank.knifeProtect = true
            bank.enemyFxProtectLv = maxOf(bank.enemyFxProtectLv, knifeShieldLv * drive)
        }
        if (anyEffectOn && e >= anyEffectThr * drive) {
            bank.bulletProtect = true
            bank.knifeProtect = true
            bank.whipProtect = true
            bank.sharpProtect = true
            bank.burstProtect = true
            bank.rippleProtect = true
            bank.enemyFxProtectLv = maxOf(bank.enemyFxProtectLv, anyEffectLv * drive)
        }
        if (antiBypassOn && e >= antiBypassThr * drive) {
            bank.ancProtectOn = true
            bank.ancProtectLv = maxOf(bank.ancProtectLv, antiBypassLv * drive)
        }

        lastStatus =
            "MAS ${if (masterAntiOn) "ON" else "off"} lv=${(masterAntiLv * 100).toInt()}% · " +
            "AS ${if (bodyAsShieldOn) "ON" else "off"} WS ${if (bodyWsShieldOn) "ON" else "off"} · " +
            "knife ${if (knifeShieldOn) "ON" else "off"} any ${if (anyEffectOn) "ON" else "off"} · " +
            "eyeL ${if (eyesPitchProtL) "ON" else "off"} eyeR ${if (eyesPitchProtR) "ON" else "off"} · " +
            "e=${(e * 100).toInt()}%"
    }
}
