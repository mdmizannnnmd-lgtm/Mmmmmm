package com.mizan

/**
 * Mic Speaker board — MIC-1 / MIC-2, MONO, echo cancellation, noise reduction,
 * karaoke / room reverb effects (from Mic Speaker style UI).
 * Microphone-driven; RAW bypasses soft gates.
 */
class MicSpeakerBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true

    /** MIC-1 (primary) / MIC-2 (secondary) selection */
    @Volatile var mic1On = true
    @Volatile var mic2On = false
    @Volatile var monoOn = true
    /** Stereo mode — L/R independent (overrides mono when ON) */
    @Volatile var stereoOn = false
    @Volatile var micLOn = true
    @Volatile var micROn = true
    @Volatile var stereoBalance = 0.5f   // 0=L only, 1=R only, 0.5=center
    @Volatile var stereoLvL = 1f
    @Volatile var stereoLvR = 1f
    @Volatile var stereoThrL = 0.05f
    @Volatile var stereoThrR = 0.05f
    @Volatile var outL = 0f
    @Volatile var outR = 0f

    @Volatile var echoCancelOn = true
    @Volatile var noiseReduceOn = true
    @Volatile var echoCancelLv = 0.70f
    @Volatile var noiseReduceLv = 0.65f

    enum class KaraokeEffect(val id: Int, val label: String) {
        NONE(0, "No Effect"),
        SMALL_ROOM(1, "Small Room"),
        MEDIUM_ROOM(2, "Medium Room"),
        LARGE_ROOM(3, "Large Room"),
        MEDIUM_HALL(4, "Medium Hall"),
        LARGE_HALL(5, "Large Hall"),
        METAL_PLATE(6, "Metal Plate Reverb");
        companion object {
            fun fromId(id: Int) = entries.firstOrNull { it.id == id } ?: NONE
        }
    }
    @Volatile var karaokeEffect = KaraokeEffect.NONE
    @Volatile var effectLevel = 0.85f

    @Volatile var speakerGain = 0.80f
    @Volatile var micGain = 0.90f
    @Volatile var ampGain = 1.0f
    @Volatile var saveAudioOn = false

    @Volatile var micEnergy = 0f
    @Volatile var out = 0f
    @Volatile var cleanedOut = 0f
    @Volatile var effectOut = 0f
    @Volatile var active = false

    fun setKaraokeById(id: Int) { karaokeEffect = KaraokeEffect.fromId(id) }

    fun tick(energy: Float) {
        var e = energy.coerceIn(0f, 1f) * micGain.coerceIn(0f, 2f)
        // MIC select weight
        val micW = when {
            mic1On && mic2On -> 1f
            mic1On || mic2On -> 0.85f
            else -> 0.15f
        }
        e *= micW
        if (monoOn) e = e // already mono path in AudioProcessor
        micEnergy = e.coerceIn(0f, 1f)

        if (!enabled) {
            out = 0f; cleanedOut = 0f; effectOut = 0f; active = false
            return
        }
        if (rawComplete) {
            cleanedOut = micEnergy
            effectOut = micEnergy * effectLevel.coerceIn(0f, 1f)
            out = (cleanedOut * speakerGain.coerceIn(0f, 2f) * ampGain.coerceIn(0f, 3f)).coerceIn(0f, 1f)
            active = out > 0.02f
            return
        }

        // Echo cancellation soft subtract
        var cleaned = micEnergy
        if (echoCancelOn) cleaned *= (1f - echoCancelLv.coerceIn(0f, 1f) * 0.35f)
        if (noiseReduceOn) cleaned *= (1f - noiseReduceLv.coerceIn(0f, 1f) * 0.25f)
        cleanedOut = cleaned.coerceIn(0f, 1f)

        // Karaoke / room reverb colouring (level scale by preset)
        val presetMul = when (karaokeEffect) {
            KaraokeEffect.NONE -> 0.15f
            KaraokeEffect.SMALL_ROOM -> 0.40f
            KaraokeEffect.MEDIUM_ROOM -> 0.55f
            KaraokeEffect.LARGE_ROOM -> 0.70f
            KaraokeEffect.MEDIUM_HALL -> 0.80f
            KaraokeEffect.LARGE_HALL -> 0.92f
            KaraokeEffect.METAL_PLATE -> 1.0f
        }
        effectOut = (cleanedOut * effectLevel.coerceIn(0f, 1f) * presetMul).coerceIn(0f, 1f)
        val base = (cleanedOut * speakerGain.coerceIn(0f, 2f) * ampGain.coerceIn(0f, 3f) * (0.6f + effectOut * 0.4f))
            .coerceIn(0f, 1f)
        if (stereoOn && !monoOn) {
            val bal = stereoBalance.coerceIn(0f, 1f)
            val lMul = if (micLOn) stereoLvL.coerceIn(0f, 1f) * (1f - bal) * 2f else 0f
            val rMul = if (micROn) stereoLvR.coerceIn(0f, 1f) * bal * 2f else 0f
            outL = if (base >= stereoThrL.coerceIn(0.05f, 1f)) (base * lMul.coerceIn(0f, 2f)).coerceIn(0f, 1f) else 0f
            outR = if (base >= stereoThrR.coerceIn(0.05f, 1f)) (base * rMul.coerceIn(0f, 2f)).coerceIn(0f, 1f) else 0f
            out = maxOf(outL, outR)
        } else {
            // MONO or stereo off: both sides same
            outL = base
            outR = base
            out = base
        }
        active = out > 0.02f
    }

    fun statusLine(): String {
        if (!enabled) return "MIC-SPEAKER off"
        val mics = buildList {
            if (mic1On) add("MIC-1")
            if (mic2On) add("MIC-2")
            if (isEmpty()) add("no-mic")
        }.joinToString("+")
        val mode = when {
            stereoOn && !monoOn -> "STEREO L${(outL*100).toInt()}% R${(outR*100).toInt()}% bal=${(stereoBalance*100).toInt()}"
            monoOn -> "MONO"
            else -> "DUAL"
        }
        return "MIC-SPEAKER $mics $mode · " +
            "fx=${karaokeEffect.label} lv=${(effectLevel * 100).toInt()}% · " +
            "out=${(out * 100).toInt()}%${if (rawComplete) " · RAW" else ""}" +
            (if (echoCancelOn) " · EC" else "") +
            (if (noiseReduceOn) " · NR" else "")
    }
    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        /* state board — levels already on SoundBank path */
    }

}
