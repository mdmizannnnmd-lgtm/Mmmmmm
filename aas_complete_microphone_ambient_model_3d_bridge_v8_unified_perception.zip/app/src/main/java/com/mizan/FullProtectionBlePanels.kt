package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object FullProtectionBlePanels {
    fun build(
        ctx: Context,
        root: LinearLayout,
        full: FullProtectionBleBoard,
        lib: BleScaleLibrary?
    ) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF26A69A.toInt()
        p.title("FULL PROTECTION · BLE LIBRARY · LIFESUM-STYLE SCALE", c)
        p.note("RxAndroidBle optional: com.polidea.rxandroidble3:rxandroidble:1.19.1 · native scan built-in")
        p.switch("Full protect ON", full.enabled) { full.enabled = it }
        p.switch("RAW COMPLETE", full.rawComplete) { full.rawComplete = it }
        p.button("BLE scan scales (12s)") { _ ->
            lib?.startScan(12_000L)
        }
        p.button("BLE stop scan") { _ -> lib?.stopScan() }
        val st = p.status("FULL-PROT-BLE —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() {
                val libSt = lib?.status ?: "no lib"
                st.text = full.status + " · " + libSt
                Handler(Looper.getMainLooper()).postDelayed(this, 400)
            }
        })
    }
}
