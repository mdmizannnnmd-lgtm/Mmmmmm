package com.mizan

import kotlin.math.max

/**
 * ONENESS — the brain is not a single separate thing. One shared field joins:
 *   3D brain (left + right hemisphere)  ↔  3D anatomy body (inside + outside layers, brain layer, face)
 *   ↔  rings + balls on the body (incl. the brain-L / brain-R rings)  ↔  Sound Bank (incl. the SD-card sound).
 *
 * Every frame [tick] measures how active each part is, builds the shared [field], and feeds a [couple] share of it
 * back into every part (never lowering a part — it only lifts it). The brain ring balls also push back into the
 * hemispheres, and the brain can be docked inside the anatomy body so there is one model, not a floating copy.
 *
 * RAW COMPLETE for everything: [setRawEverything] switches the brain, anatomy, rings and sound bank to raw together.
 */
class OnenessHub {
    @Volatile var enabled = true
    @Volatile var couple = 0.35f          // 0..1 share of the shared field fed back into each part
    @Volatile var soundLink = true        // include the Sound Bank (and SD sound) in the field
    @Volatile var ringsLink = true
    @Volatile var rawEverything = false
        private set

    @Volatile var field = 0f
        private set
    @Volatile var brainPart = 0f
        private set
    @Volatile var anatomyPart = 0f
        private set
    @Volatile var ringsPart = 0f
        private set
    @Volatile var soundPart = 0f
        private set

    fun setRawEverything(v: VisualShieldView, on: Boolean) {
        rawEverything = on
        v.brain3d.setRawAll(on)
        v.anatomy3d.setRawAll(on)
        v.ringBoard.setRawAll(on)
        v.soundBank.rawComplete = on
        v.centroid.raw = on
        v.centroids.setRaw(on)
        v.gameWorld.raw = on
        v.micSpeaker.rawComplete = on
        v.setAllRegionsRaw(on)
        v.noise3d.raw = on
    }

    fun tick(v: VisualShieldView) {
        val b = v.brain3d
        val a = v.anatomy3d
        val r = v.ringBoard
        val sb = v.soundBank

        brainPart = ((b.left.out + b.right.out) * 0.5f).coerceIn(0f, 1f)
        anatomyPart = ((a.inside.out + a.outside.out) * 0.5f).coerceIn(0f, 1f)
        ringsPart = if (ringsLink && r.enabled) ((r.inside.out + r.outside.out) * 0.5f).coerceIn(0f, 1f) else 0f
        soundPart = if (soundLink) sb.mixEnergy.coerceIn(0f, 1f) else 0f

        val cen = max(v.centroid.strength, if (v.centroids.enabled) v.centroids.master.strength else 0f)
        var sum = 0f; var n = 0
        if (v.centroid.enabled) { sum += cen; n++ }
        if (b.enabled) { sum += brainPart; n++ }
        if (a.enabled) { sum += anatomyPart; n++ }
        if (ringsLink && r.enabled) { sum += ringsPart; n++ }
        if (soundLink) { sum += soundPart; n++ }
        val mean = if (n == 0) 0f else sum / n
        // the strongest part also pulls the field up, so one loud part moves the whole body
        field = max(mean, max(max(brainPart, cen), max(anatomyPart, max(ringsPart, soundPart))) * 0.6f).coerceIn(0f, 1f)

        if (!enabled) return
        val c = couple.coerceIn(0f, 1f)
        val f = field * c

        // brain ← field, and ← the brain rings on the body (ring balls push back into the hemispheres)
        if (b.enabled) {
            var ringL = 0f; var ringR = 0f
            if (ringsLink && r.enabled) {
                for (ring in r.rings) {
                    if (ring.key == "brainL") ringL = max(ring.outOut, ring.inOut)
                    if (ring.key == "brainR") ringR = max(ring.outOut, ring.inOut)
                }
            }
            b.left.out = max(b.left.out, max(f, ringL * c))
            b.right.out = max(b.right.out, max(f, ringR * c))
        }
        // anatomy ← field and ← the brain (the Brain layer is an inside layer)
        if (a.enabled) {
            a.inside.blend(max(f, brainPart * c))
            a.outside.blend(f * 0.7f)
        }
        // rings ← field and ← the anatomy
        if (ringsLink && r.enabled) {
            r.inside.blend(max(f, anatomyPart * c * 0.8f))
            r.outside.blend(f * 0.8f)
        }
        // everything feeds the body model mix
        v.bodyMixer.mixedE = max(v.bodyMixer.mixedE, f * 0.5f)
    }

    fun statusLine(): String {
        if (!enabled) return "ONENESS off"
        return "ONENESS · field=${(field * 100).toInt()}% · brain=${(brainPart * 100).toInt()}% anat=${(anatomyPart * 100).toInt()}% " +
            "rings=${(ringsPart * 100).toInt()}% sound=${(soundPart * 100).toInt()}% · couple=${(couple * 100).toInt()}%" +
            (if (rawEverything) " · RAW COMPLETE ALL" else "")
    }
}
