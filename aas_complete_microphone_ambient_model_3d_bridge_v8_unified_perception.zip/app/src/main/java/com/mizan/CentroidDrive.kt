package com.mizan

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min

/**
 * CENTROID DRIVE — ties the whole 3D body to the ambient board's CENTROID and VERTICAL (each with its own level ·
 * threshold · bipolar · RAW COMPLETE, set on the ambient board):
 *
 *   · MOVEMENT  ← VERTICAL level      (body moves up / down with the height of the active centroid)
 *   · SPEED     ← CENTROID level      (brighter sound = faster turntable)
 *   · WAVES     ← CENTROID + VERTICAL (breathing · heartbeat · ring waves)
 *   · 84 BODY AMBIENT ← every channel is boosted by how close it sits to the live centroid point (side) and height (vertical)
 *   · EYES      ← the LEFT and RIGHT eye ball look at the centroid point; the vertical level lifts / lowers the gaze, the
 *                 spectral centroid (bipolar) opens / closes the pupils.
 *
 * Read-only on every other board: it only writes the boost / gaze fields of [Anatomy3DBoard].
 * RAW COMPLETE ([rawEverything] from the ONENESS hub, or [raw]): no smoothing, every drive passes straight through.
 */
class CentroidDrive {

    @Volatile var enabled = true
    @Volatile var raw = false

    @Volatile var moveOn = true
    @Volatile var speedOn = true
    @Volatile var waveOn = true
    @Volatile var channelsOn = true
    @Volatile var eyesOn = true
    @Volatile var ambientOn = true

    /** How much of each drive is applied (0 = none, 1 = full, up to 1.5). */
    @Volatile var moveAmt = 0.80f
    @Volatile var speedAmt = 0.80f
    @Volatile var waveAmt = 0.80f
    @Volatile var channelAmt = 0.60f
    @Volatile var ambientAmt = 0.70f

    // ── Movement · centroid · vertical · thr · RAW ─────────────
    @Volatile var moveCenOn = true
    @Volatile var moveCenLv = 0.80f
    @Volatile var moveCenThr = 0.20f
    @Volatile var moveCenRaw = false
    @Volatile var moveVerOn = true
    @Volatile var moveVerLv = 0.80f
    @Volatile var moveVerThr = 0.20f
    @Volatile var moveVerRaw = false
    @Volatile var moveCenOut = 0f
    @Volatile var moveVerOut = 0f

    // ── Speed · centroid · vertical · thr · RAW ────────────────
    @Volatile var speedCenOn = true
    @Volatile var speedCenLv = 0.80f
    @Volatile var speedCenThr = 0.20f
    @Volatile var speedCenRaw = false
    @Volatile var speedVerOn = true
    @Volatile var speedVerLv = 0.55f
    @Volatile var speedVerThr = 0.25f
    @Volatile var speedVerRaw = false
    @Volatile var speedCenOut = 0f
    @Volatile var speedVerOut = 0f

    // ── Waves · centroid · vertical · thr · RAW ────────────────
    @Volatile var waveCenOn = true
    @Volatile var waveCenLv = 0.75f
    @Volatile var waveCenThr = 0.22f
    @Volatile var waveCenRaw = false
    @Volatile var waveVerOn = true
    @Volatile var waveVerLv = 0.75f
    @Volatile var waveVerThr = 0.22f
    @Volatile var waveVerRaw = false
    @Volatile var waveCenOut = 0f
    @Volatile var waveVerOut = 0f

    // ── Ambient · centroid · vertical · thr · RAW ──────────────
    @Volatile var ambCenOn = true
    @Volatile var ambCenLv = 0.70f
    @Volatile var ambCenThr = 0.25f
    @Volatile var ambCenRaw = false
    @Volatile var ambVerOn = true
    @Volatile var ambVerLv = 0.70f
    @Volatile var ambVerThr = 0.25f
    @Volatile var ambVerRaw = false
    @Volatile var ambCenOut = 0f
    @Volatile var ambVerOut = 0f
    @Volatile var ambientOut = 0f

    /** How far an eye can turn toward the centroid (1 = ±0.5 rad) and how fast it follows. */
    @Volatile var gazeRange = 1.25f
    @Volatile var gazeFollow = 0.55f
    /** Independent left/right eye gaze gain and normalized position offsets (−1..+1). */
    @Volatile var gazeLRotationLevel = 1.0f
    @Volatile var gazeRRotationLevel = 1.0f
    @Volatile var gazeLPositionX = 0.0f
    @Volatile var gazeLPositionY = 0.0f
    @Volatile var gazeRPositionX = 0.0f
    @Volatile var gazeRPositionY = 0.0f

    @Volatile var moveOut = 0f
        private set
    @Volatile var speedOut = 0f
        private set
    @Volatile var waveOut = 0f
        private set
    @Volatile var vOffsetBias = 0f           // signed, fraction of view height — added to the body vertical offset
        private set

    private var gLx = 0f; private var gLy = 0f; private var gRx = 0f; private var gRy = 0f; private var pupil = 1f


    private fun rail(
        on: Boolean, src: Float, thr: Float, lv: Float, rawRail: Boolean, rawNow: Boolean
    ): Float {
        if (!on) return 0f
        val s = src.coerceIn(0f, 1f)
        if (rawRail || rawNow) return (s * lv.coerceIn(0f, 1.5f)).coerceIn(0f, 1.5f)
        val t = thr.coerceIn(0.05f, 1f)
        if (s < t) return 0f
        return (((s - t) / (1f - t).coerceAtLeast(0.05f)) * lv.coerceIn(0f, 1.5f)).coerceIn(0f, 1.5f)
    }

    private fun ease(cur: Float, tgt: Float, rawNow: Boolean, k: Float = 0.2f): Float =
        if (rawNow) tgt else cur + (tgt - cur) * k

    fun tick(v: VisualShieldView) {
        val a = v.anatomy3d
        if (!enabled) {
            moveOut = 0f; speedOut = 0f; waveOut = 0f; ambientOut = 0f; vOffsetBias = 0f
            moveCenOut = 0f; moveVerOut = 0f; speedCenOut = 0f; speedVerOut = 0f
            waveCenOut = 0f; waveVerOut = 0f; ambCenOut = 0f; ambVerOut = 0f
            a.moveBoost = 0f; a.speedBoost = 0f; a.waveBoost = 0f
            a.gazeLx = 0f; a.gazeLy = 0f; a.gazeRx = 0f; a.gazeRy = 0f; a.pupilScale = 1f
            return
        }
        val b = v.ambientBoardRef
        val rawNow = raw || v.oneness.rawEverything
        // Locked mode: freeze body motion drives (levels still mix in audio path)
        if (v.bodyLocked) {
            moveOut = 0f; speedOut = 0f; waveOut = 0f; ambientOut = 0f; vOffsetBias = 0f
            moveCenOut = 0f; moveVerOut = 0f; speedCenOut = 0f; speedVerOut = 0f
            waveCenOut = 0f; waveVerOut = 0f; ambCenOut = 0f; ambVerOut = 0f
            a.moveBoost = 0f; a.speedBoost = 0f; a.waveBoost = 0f
            a.gazeLx = 0f; a.gazeLy = 0f; a.gazeRx = 0f; a.gazeRy = 0f; a.pupilScale = 1f
            gLx = 0f; gLy = 0f; gRx = 0f; gRy = 0f; pupil = 1f
            return
        }
        val cen = (b?.centroidOut ?: 0f).coerceIn(0f, 1f)
        val ver = (b?.verticalOut ?: 0f).coerceIn(0f, 1f)
        val verBip = b?.verticalBip ?: 0f
        val cenBip = b?.centroidBip ?: 0f

        // Movement centroid · vertical
        moveCenOut = rail(moveOn && moveCenOn, cen, moveCenThr, moveCenLv * moveAmt, moveCenRaw, rawNow)
        moveVerOut = rail(moveOn && moveVerOn, ver, moveVerThr, moveVerLv * moveAmt, moveVerRaw, rawNow)
        moveOut = ease(moveOut, max(moveCenOut, moveVerOut).coerceIn(0f, 1.5f), rawNow)

        // Speed centroid · vertical
        speedCenOut = rail(speedOn && speedCenOn, cen, speedCenThr, speedCenLv * speedAmt, speedCenRaw, rawNow)
        speedVerOut = rail(speedOn && speedVerOn, ver, speedVerThr, speedVerLv * speedAmt, speedVerRaw, rawNow)
        speedOut = ease(speedOut, max(speedCenOut, speedVerOut).coerceIn(0f, 1.5f), rawNow)

        // Waves centroid · vertical
        waveCenOut = rail(waveOn && waveCenOn, cen, waveCenThr, waveCenLv * waveAmt, waveCenRaw, rawNow)
        waveVerOut = rail(waveOn && waveVerOn, ver, waveVerThr, waveVerLv * waveAmt, waveVerRaw, rawNow)
        waveOut = ease(waveOut, max(waveCenOut, waveVerOut).coerceIn(0f, 1.5f), rawNow)

        // Ambient centroid · vertical
        ambCenOut = rail(ambientOn && ambCenOn, cen, ambCenThr, ambCenLv * ambientAmt, ambCenRaw, rawNow)
        ambVerOut = rail(ambientOn && ambVerOn, ver, ambVerThr, ambVerLv * ambientAmt, ambVerRaw, rawNow)
        ambientOut = ease(ambientOut, max(ambCenOut, ambVerOut).coerceIn(0f, 1.5f), rawNow)

        vOffsetBias = ease(vOffsetBias, if (moveOn) -verBip * moveAmt * 0.04f else 0f, rawNow)
        a.moveBoost = moveOut
        a.speedBoost = speedOut
        a.waveBoost = waveOut
        // Ambient → ALL body parts (not anywhere / not single region)
        a.ambientBoost = ambientOut
        applyAllBodyAmbient(v, ambientOut, rawNow)


        // ── eyes: look at centroid · idle scan when quiet · clamped in-socket (no break/miss) ──
        if (eyesOn) {
            val cs = v.centroids
            val src: Triple<Float, Float, Boolean> = when {
                cs.enabled && cs.useMaster && cs.master.active -> Triple(cs.master.cx, cs.master.cy, true)
                v.centroid.enabled && v.centroid.active -> Triple(v.centroid.cx, v.centroid.cy, true)
                else -> Triple(0f, BODY_MID_Y, false)
            }
            // Idle micro-saccades so eyes still move when no centroid target
            val tSec = (android.os.SystemClock.elapsedRealtime() % 100000L) / 1000f
            val idleX = if (!src.third) (kotlin.math.sin(tSec * 0.7f) * 0.22f + kotlin.math.sin(tSec * 1.3f) * 0.08f) else 0f
            val idleY = if (!src.third) (kotlin.math.sin(tSec * 0.55f + 1.2f) * 0.15f) else 0f
            val depth = 1.60f
            val range = (0.5f * gazeRange.coerceIn(0.2f, 2.5f)).coerceAtLeast(0.15f)
            fun gaze(
                ex: Float,
                positionX: Float,
                positionY: Float,
                rotationLevel: Float
            ): Pair<Float, Float> {
                val targetX = if (src.third) src.first else (ex + idleX * 0.4f)
                val targetY = if (src.third) src.second else (BODY_MID_Y + idleY * 0.35f)
                val yaw = atan2(targetX - ex, depth)
                val pitch = atan2(targetY - BODY_MID_Y, depth) + if (src.third) verBip * 0.18f else idleY * 0.12f
                val gain = rotationLevel.coerceIn(0.15f, 2f) // never fully zero gain
                // Socket clamp ±0.85 so iris/pupil never leave the eyeball (no break / miss)
                val gx = ((yaw / range) * gain + positionX.coerceIn(-1f, 1f) + idleX * 0.35f).coerceIn(-0.85f, 0.85f)
                val gy = ((pitch / range) * gain + positionY.coerceIn(-1f, 1f) + idleY * 0.30f).coerceIn(-0.75f, 0.75f)
                return Pair(gx, gy)
            }
            val l = gaze(-EYE_X, gazeLPositionX, gazeLPositionY, gazeLRotationLevel)
            val r = gaze(EYE_X, gazeRPositionX, gazeRPositionY, gazeRRotationLevel)
            // Faster follow so motion is visible; RAW = instant
            val k = if (rawNow) 1f else gazeFollow.coerceIn(0.12f, 1f)
            gLx += (l.first - gLx) * k; gLy += (l.second - gLy) * k
            gRx += (r.first - gRx) * k; gRy += (r.second - gRy) * k
            // Hard socket lock after smoothing
            gLx = gLx.coerceIn(-0.85f, 0.85f); gLy = gLy.coerceIn(-0.75f, 0.75f)
            gRx = gRx.coerceIn(-0.85f, 0.85f); gRy = gRy.coerceIn(-0.75f, 0.75f)
            val pt = (1f + 0.35f * cenBip).coerceIn(0.6f, 1.5f)
            pupil = if (rawNow) pt else pupil + (pt - pupil) * 0.15f
            a.gazeLx = gLx; a.gazeLy = gLy; a.gazeRx = gRx; a.gazeRy = gRy; a.pupilScale = pupil
        } else {
            a.gazeLx = 0f; a.gazeLy = 0f; a.gazeRx = 0f; a.gazeRy = 0f; a.pupilScale = 1f
        }
    }

    /**
     * Gain for a body channel / ball anchored at ([ax], [ay]) in body units: 1 + boost, boost grows with the vertical level
     * and the centroid level and with how close the anchor is to the live centroid point. 1.0 when off or RAW COMPLETE.
     */
    fun channelGain(v: VisualShieldView, ax: Float, ay: Float): Float {
        if (!enabled || !channelsOn || raw || v.oneness.rawEverything) return 1f
        val b = v.ambientBoardRef ?: return 1f
        val drive = max(b.centroidOut, b.verticalOut)
        if (drive <= 0.001f) return 1f
        val near = 1f - min(1f, abs(ay - b.bodyCy) / 0.90f) * 0.6f - min(1f, abs(ax - b.bodyCx) / 0.60f) * 0.4f
        return 1f + channelAmt * drive * near.coerceIn(0f, 1f)
    }


    /**
     * Lift ambient on **every** body region + all 84 channels — not a single part / not "anywhere only".
     */
    private fun applyAllBodyAmbient(v: VisualShieldView, amount: Float, raw: Boolean) {
        if (!ambientOn || amount <= 0.001f) return
        val add = amount.coerceIn(0f, 1.5f)
        fun lift(r: VisualShieldView.Region) {
            val target = if (raw) max(r.ambient, add) else (r.ambient * 0.85f + add * 0.35f).coerceIn(0f, 1.5f)
            r.ambient = target
        }
        lift(v.eyes); lift(v.eyeL); lift(v.eyeR)
        lift(v.eyeLOut); lift(v.eyeROut); lift(v.eyeLIn); lift(v.eyeRIn)
        lift(v.eyeLSkinOut); lift(v.eyeRSkinOut); lift(v.eyeLSkinIn); lift(v.eyeRSkinIn)
        lift(v.eyeAtmo)
        runCatching {
            for (name in listOf(
                "eyeLSclera","eyeRSclera","eyeLCornea","eyeRCornea","eyeLIris","eyeRIris",
                "eyeLPupil","eyeRPupil","eyeLLidU","eyeRLidU","eyeLLidD","eyeRLidD",
                "eyeLLash","eyeRLash","eyeLConjunctiva","eyeRConjunctiva",
                "eyeLLacrimal","eyeRLacrimal","eyeLCanthus","eyeRCanthus","eyeLOrbit","eyeROrbit"
            )) {
                val f = v.javaClass.getDeclaredField(name)
                f.isAccessible = true
                (f.get(v) as? VisualShieldView.Region)?.let { lift(it) }
            }
        }
        lift(v.browL); lift(v.browR)
        lift(v.face); lift(v.forehead); lift(v.nose)
        lift(v.lipU); lift(v.lipL); lift(v.tongue)
        lift(v.brain); lift(v.heart); lift(v.neck); lift(v.belly)
        // Complete skin sub-system ambient
        lift(v.skinHead); lift(v.skinNeck); lift(v.skinChest); lift(v.skinAbdomen); lift(v.skinBack)
        lift(v.skinArmL); lift(v.skinArmR); lift(v.skinHandL); lift(v.skinHandR)
        lift(v.skinLegL); lift(v.skinLegR); lift(v.skinFootL); lift(v.skinFootR); lift(v.skinAll)
        v.bodyRegionAmbientBoost = (v.bodyRegionAmbientBoost * 0.7f + add * 0.4f).coerceIn(0f, 1.5f)
        if (channelsOn) {
            val body = v.body84
            val n = body.channels.size
            for (i in 0 until n) {
                val ch = body.channels[i]
                if (!ch.on) continue
                val g = channelGain(v, 0f, i.toFloat() / n.coerceAtLeast(1).toFloat())
                val liftAmt = add * 0.30f * g.coerceIn(0f, 2f)
                ch.ambient = (ch.ambient * 0.80f + liftAmt).coerceIn(0f, 1.5f)
                if (raw) ch.out = max(ch.out, liftAmt)
            }
        }
    }

    fun statusLine(): String {
        if (!enabled) return "CENTROID DRIVE off"
        return "CENTROID DRIVE · move ${(moveOut * 100).toInt()}% · speed ${(speedOut * 100).toInt()}% · waves ${(waveOut * 100).toInt()}%" +
            (if (eyesOn) " · eyes L ${"%+.0f".format(gLx * 100)}/${"%+.0f".format(gLy * 100)} R ${"%+.0f".format(gRx * 100)}/${"%+.0f".format(gRy * 100)}" else "") +
            (if (raw) " · RAW COMPLETE" else "")
    }

    companion object {
        const val EYE_X = 0.062f
        const val EYE_Y = 1.555f
        const val BODY_MID_Y = 0.60f
    }
    /** RAW COMPLETE — every centroid / vertical drive unfiltered. */
    fun enableRawComplete() {
        raw = true
        ambCenRaw = true; ambVerRaw = true
        moveCenRaw = true; moveVerRaw = true
        speedCenRaw = true; speedVerRaw = true
        waveCenRaw = true; waveVerRaw = true
        enabled = true
        ambientOn = true; moveOn = true; speedOn = true; waveOn = true; channelsOn = true
    }

}

/** Shared eye-ball turning maths (used by the 3D anatomy renderer and the 3D game world). */
object EyeGazeMath {
    private val kinds = arrayOf(
        "Eyeball", "Sclera", "Sclera vessel", "Cornea", "Corneal", "Iris", "Pupil", "Lens",
        "Retina", "Neural retina", "Retinal pigment epithelium", "Vitreous", "Choroid",
        "Macula", "Fovea", "Optic disc", "Optic nerve head", "Anterior chamber",
        "Posterior chamber", "Ciliary body", "Ciliary process", "Zonular fibers", "Tear film",
        "Bulbar conjunctiva", "Central retinal artery", "Central retinal vein",
        "Retinal artery branch", "Retinal vein branch"
    )

    fun isEyeContent(name: String): Boolean {
        for (k in kinds) if (name.startsWith(k)) return true
        return false
    }

    /**
     * Turns the eye-ball part [p] toward the gaze (−1..+1 for yaw / pitch). Writes x, y, z (body units) and the size factor
     * (pupil dilation for the pupil, 1 otherwise) into [out] and returns true; false for parts that do not move with the gaze.
     */
    fun turn(
        p: AnatomyModel3D.Part, gxL: Float, gyL: Float, gxR: Float, gyR: Float, pupilScale: Float, out: FloatArray
    ): Boolean {
        if (p.side == 0 || !isEyeContent(p.name)) return false
        val left = p.side < 0
        val th = (if (left) gxL else gxR).coerceIn(-0.85f, 0.85f) * 0.38f  // yaw — socket-safe
        val ph = (if (left) gyL else gyR).coerceIn(-0.75f, 0.75f) * 0.32f  // pitch — socket-safe
        val ex = p.side * CentroidDrive.EYE_X
        val rx = p.x - ex
        val ry = p.y - CentroidDrive.EYE_Y
        val rz = p.z - 0.115f
        val ct = kotlin.math.cos(th); val st = kotlin.math.sin(th)
        val cp = kotlin.math.cos(ph); val sp = kotlin.math.sin(ph)
        val x1 = rx * ct + rz * st
        val z1 = -rx * st + rz * ct
        val y2 = ry * cp + z1 * sp
        val z2 = -ry * sp + z1 * cp
        // Keep content inside the eyeball sphere (no break / miss outside orbit)
        val maxR = 0.028f
        val r = kotlin.math.sqrt(x1 * x1 + y2 * y2 + z2 * z2)
        val s = if (r > maxR && r > 1e-6f) maxR / r else 1f
        out[0] = ex + x1 * s
        out[1] = CentroidDrive.EYE_Y + y2 * s
        out[2] = 0.115f + z2 * s
        out[3] = if (p.name.startsWith("Pupil")) pupilScale.coerceIn(0.5f, 1.6f) else 1f
        return true
    }
}
