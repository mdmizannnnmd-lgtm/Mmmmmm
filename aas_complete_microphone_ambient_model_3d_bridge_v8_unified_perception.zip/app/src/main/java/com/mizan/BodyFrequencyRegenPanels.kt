package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object BodyFrequencyRegenPanels {
    fun build(ctx: Context, root: LinearLayout, b: BodyFrequencyRegenBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFA5D6A7.toInt()
        p.title("BODY Hz · INFECTION · DAMAGE · REPAIR · REGEN · NEURON · HORMONE · BLE W", c)
        p.switch("Body Hz system ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("BODY Hz OUTPUT (0–50)", c)
        p.seek("Body Hz max", 1f, 50f, b.bodyHzMax) { b.bodyHzMax = it }

        p.title("BAD · INFECTION · DAMAGE CELL", c)
        p.switch("Infection Hz ON", b.infectionOn) { b.infectionOn = it }
        p.seek("Infection Hz thr", 0f, 50f, b.infectionHzThr) { b.infectionHzThr = it }
        p.seek("Infection band lo", 0f, 50f, b.infectionBandLo) { b.infectionBandLo = it }
        p.seek("Infection band hi", 0f, 50f, b.infectionBandHi) { b.infectionBandHi = it }
        p.switch("Damage cell Hz ON", b.damageCellOn) { b.damageCellOn = it }
        p.seek("Damage cell Hz thr", 0f, 50f, b.damageCellHzThr) { b.damageCellHzThr = it }
        p.seek("Bad body Hz thr", 0f, 50f, b.badBodyHzThr) { b.badBodyHzThr = it }
        p.switch("Fully body bad Hz scan ON", b.badBodyFullScanOn) { b.badBodyFullScanOn = it }

        p.title("PARTICLES THRESHOLD · FULL BODY MODEL SCAN", c)
        p.switch("Particles ON", b.particlesOn) { b.particlesOn = it }
        p.switch("Particles auto thr", b.particlesAutoThr) { b.particlesAutoThr = it }
        p.seek("Particles thr", 0.05f, 0.98f, b.particlesThr) { b.particlesThr = it }
        p.seek("Particles level", 0f, 1.5f, b.particlesLv) { b.particlesLv = it }
        p.switch("Full body model scan ON", b.modelScanOn) { b.modelScanOn = it }
        p.seek("Model scan thr", 0.05f, 0.98f, b.modelScanThr) { b.modelScanThr = it }
        p.seek("Model scan level", 0f, 1.5f, b.modelScanLv) { b.modelScanLv = it }

        p.title("GOOD FREQUENCY · REPAIR · REGEN", c)
        p.switch("Good frequency ON", b.goodFreqOn) { b.goodFreqOn = it }
        p.seek("Good Hz lo", 0f, 50f, b.goodHzLo) { b.goodHzLo = it }
        p.seek("Good Hz hi", 0f, 50f, b.goodHzHi) { b.goodHzHi = it }
        p.switch("Repair ON", b.repairOn) { b.repairOn = it }
        p.seek("Repair target Hz", 0f, 50f, b.repairHz) { b.repairHz = it }
        p.seek("Repair thr / lv", 0.05f, 0.98f, b.repairHzThr) { b.repairHzThr = it }
        p.seek("Repair level", 0f, 1.5f, b.repairLv) { b.repairLv = it }
        p.switch("Healing frequency ON", b.healingOn) { b.healingOn = it }
        p.seek("Healing mapped Hz (body band)", 0f, 50f, b.healingHzMapped) { b.healingHzMapped = it }
        p.seek("Healing thr", 0.05f, 0.98f, b.healingThr) { b.healingThr = it }
        p.seek("Healing level", 0f, 1.5f, b.healingLv) { b.healingLv = it }
        p.switch("Regeneration ON", b.regenOn) { b.regenOn = it }
        p.seek("Regen target Hz", 0f, 50f, b.regenHz) { b.regenHz = it }
        p.seek("Regen thr", 0.05f, 0.98f, b.regenHzThr) { b.regenHzThr = it }
        p.seek("Regen level", 0f, 1.5f, b.regenLv) { b.regenLv = it }

        p.title("OUR OWN REGENERATION FREQUENCY · FULL MIX", c)
        p.switch("Our own regen ON", b.ownRegenOn) { b.ownRegenOn = it }
        p.seek("Own regen target Hz", 0f, 50f, b.ownRegenHz) { b.ownRegenHz = it }
        p.seek("Own regen thr", 0.05f, 0.98f, b.ownRegenThr) { b.ownRegenThr = it }
        p.seek("Own regen level", 0f, 1.5f, b.ownRegenLv) { b.ownRegenLv = it }
        p.seek("Own mix mic", 0f, 1f, b.ownRegenMixMic) { b.ownRegenMixMic = it }
        p.seek("Own mix model", 0f, 1f, b.ownRegenMixModel) { b.ownRegenMixModel = it }
        p.seek("Own mix sensor", 0f, 1f, b.ownRegenMixSensor) { b.ownRegenMixSensor = it }
        p.seek("Own mix camera", 0f, 1f, b.ownRegenMixCamera) { b.ownRegenMixCamera = it }
        p.seek("Own mix BLE", 0f, 1f, b.ownRegenMixBle) { b.ownRegenMixBle = it }
        p.seek("Own mix repair", 0f, 1f, b.ownRegenMixRepair) { b.ownRegenMixRepair = it }
        p.seek("Own mix neuron", 0f, 1f, b.ownRegenMixNeuron) { b.ownRegenMixNeuron = it }
        p.seek("Own mix hormone", 0f, 1f, b.ownRegenMixHormone) { b.ownRegenMixHormone = it }

        p.title("BRAIN BANDS (δ θ α β γ SMR) · NEURONS · HORMONE", c)
        p.note("Delta 0.5–4 · Theta 4–8 · Alpha 8–12 · Beta 12–30 · Gamma 30–50 · SMR 12–15 (app signal bands)")
        p.switch("Delta ON", b.brainDeltaOn) { b.brainDeltaOn = it }
        p.seek("Delta center Hz", 0.5f, 4f, b.brainDeltaHz) { b.brainDeltaHz = it }
        p.switch("Theta ON", b.brainThetaOn) { b.brainThetaOn = it }
        p.seek("Theta center Hz", 4f, 8f, b.brainThetaHz) { b.brainThetaHz = it }
        p.switch("Alpha ON", b.brainAlphaOn) { b.brainAlphaOn = it }
        p.seek("Alpha center Hz", 8f, 12f, b.brainAlphaHz) { b.brainAlphaHz = it }
        p.switch("Beta ON", b.brainBetaOn) { b.brainBetaOn = it }
        p.seek("Beta center Hz", 12f, 30f, b.brainBetaHz) { b.brainBetaHz = it }
        p.switch("Gamma ON", b.brainGammaOn) { b.brainGammaOn = it }
        p.seek("Gamma center Hz", 30f, 50f, b.brainGammaHz) { b.brainGammaHz = it }
        p.switch("SMR ON", b.brainSmrOn) { b.brainSmrOn = it }
        p.seek("SMR center Hz", 12f, 15f, b.brainSmrHz) { b.brainSmrHz = it }
        p.seek("Brain band thr / lv", 0.05f, 0.98f, b.brainBandThr) { b.brainBandThr = it }
        p.seek("Brain band level", 0f, 1.5f, b.brainBandLv) { b.brainBandLv = it }
        p.switch("Brain structures complete ON", b.brainStructuresOn) { b.brainStructuresOn = it }
        p.seek("Brain structure thr / lv", 0.05f, 0.98f, b.brainStructThr) { b.brainStructThr = it }
        p.seek("Brain structure level", 0f, 1.5f, b.brainStructLv) { b.brainStructLv = it }
        p.note("Structures: Frontal Parietal Temporal Occipital Cerebellum Thalamus Hippocampus Insula Cingulate Basal Amygdala Hypothalamus Brainstem Pituitary Pineal Callosum L/R hem")
        p.switch("Body organ systems complete ON", b.bodySystemsOn) { b.bodySystemsOn = it }
        p.seek("Body systems thr", 0.05f, 0.98f, b.bodySysThr) { b.bodySysThr = it }
        p.seek("Body systems level", 0f, 1.5f, b.bodySysLv) { b.bodySysLv = it }
        p.note("Systems: Heart Lung Liver Kidney Spine Gut Immune Skin Muscle Bone CNS")

        p.title("BRAIN NEURONS · HORMONE FIX", c)
        p.switch("Neuron regen ON", b.neuronRegenOn) { b.neuronRegenOn = it }
        p.seek("Neuron regen Hz", 0f, 50f, b.neuronRegenHz) { b.neuronRegenHz = it }
        p.seek("Neuron thr / lv", 0.05f, 0.98f, b.neuronRegenThr) { b.neuronRegenThr = it }
        p.seek("Neuron level", 0f, 1.5f, b.neuronRegenLv) { b.neuronRegenLv = it }
        p.switch("Hormone fix ON", b.hormoneOn) { b.hormoneOn = it }
        p.seek("Hormone Hz", 0f, 50f, b.hormoneHz) { b.hormoneHz = it }
        p.seek("Hormone thr", 0.05f, 0.98f, b.hormoneHzThr) { b.hormoneHzThr = it }
        p.seek("Hormone level", 0f, 1.5f, b.hormoneLv) { b.hormoneLv = it }

        p.title("BLE WATT · MIC · MODEL · SENSOR · CAMERA MIX", c)
        p.switch("BLE power ON", b.bleOn) { b.bleOn = it }
        p.seek("BLE watt max", 0.1f, 50f, b.bleWattMax) { b.bleWattMax = it }
        p.seek("BLE watt thr", 0f, 20f, b.bleWattThr) { b.bleWattThr = it }
        p.seek("Mix mic", 0f, 1f, b.bleMixMic) { b.bleMixMic = it }
        p.seek("Mix model", 0f, 1f, b.bleMixModel) { b.bleMixModel = it }
        p.seek("Mix sensor", 0f, 1f, b.bleMixSensor) { b.bleMixSensor = it }
        p.seek("Mix camera", 0f, 1f, b.bleMixCamera) { b.bleMixCamera = it }

        p.title("LEVEL REPAIR · FACE/BODY WHITENING · BRIGHTENING · SENSORS · BLE REGEN", c)
        p.switch("Level repair ON", b.levelRepairOn) { b.levelRepairOn = it }
        p.seek("Level repair thr / lv", 0.05f, 0.98f, b.levelRepairThr) { b.levelRepairThr = it }
        p.seek("Level repair level", 0f, 1.5f, b.levelRepairLv) { b.levelRepairLv = it }
        p.switch("Face whitening ON", b.faceWhitenOn) { b.faceWhitenOn = it }
        p.seek("Face whiten thr", 0.05f, 0.98f, b.faceWhitenThr) { b.faceWhitenThr = it }
        p.seek("Face whiten level", 0f, 1.5f, b.faceWhitenLv) { b.faceWhitenLv = it }
        p.switch("Body whitening ON", b.bodyWhitenOn) { b.bodyWhitenOn = it }
        p.seek("Body whiten thr", 0.05f, 0.98f, b.bodyWhitenThr) { b.bodyWhitenThr = it }
        p.seek("Body whiten level", 0f, 1.5f, b.bodyWhitenLv) { b.bodyWhitenLv = it }
        p.switch("Body brightening ON", b.bodyBrightOn) { b.bodyBrightOn = it }
        p.seek("Body bright thr", 0.05f, 0.98f, b.bodyBrightThr) { b.bodyBrightThr = it }
        p.seek("Body bright level", 0f, 1.5f, b.bodyBrightLv) { b.bodyBrightLv = it }
        p.switch("All sensors mix ON", b.allSensorMixOn) { b.allSensorMixOn = it }
        p.switch("BLE mixers regeneration ON", b.bleRegenMixOn) { b.bleRegenMixOn = it }

        val st = p.status("BODY Hz —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 250) }
        })
    }
}
