package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object EnemySoundCountersPanels {
    fun build(ctx: Context, root: LinearLayout, b: EnemySoundCountersBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFFAB91.toInt()
        p.title("DISPLAY BURST·WHIP·ARROW·KNIFE · COUNTERS · ANTI PROTECT · LIVE MIC", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Counters ON", b.countersOn) { b.countersOn = it }
        p.seek("Detect thr", 0.05f, 0.98f, b.detectThr) { b.detectThr = it }
        p.switch("Anti bullet (inside body)", b.antiBulletOn) { b.antiBulletOn = it }
        p.switch("Anti burst (inside body)", b.antiBurstOn) { b.antiBurstOn = it }
        p.switch("Anti echo sound", b.antiEchoOn) { b.antiEchoOn = it }
        p.switch("Anti whip", b.antiWhipOn) { b.antiWhipOn = it }
        p.switch("Anti arrow", b.antiArrowOn) { b.antiArrowOn = it }
        p.switch("Anti knife", b.antiKnifeOn) { b.antiKnifeOn = it }
        p.seek("Anti thr", 0.05f, 0.98f, b.antiThr) { b.antiThr = it }
        p.seek("Anti level", 0f, 1.5f, b.antiLv) { b.antiLv = it }
        p.switch("Mic axis X/Y/Z ON", b.micAxisOn) { b.micAxisOn = it }
        p.seek("Mic axis thr", 0.05f, 0.98f, b.micAxisThr) { b.micAxisThr = it }
        p.seek("Mic axis level", 0f, 1.5f, b.micAxisLv) { b.micAxisLv = it }
        val st = p.status("COUNTERS —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 180) }
        })
    }
}
