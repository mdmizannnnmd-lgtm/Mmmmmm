package com.mizan

/**
 * Burst meters · Knife meters · Sharp/Burst/Pitch/Spikes Hz analysis (0 Hz → unlimited) ·
 * detected Hz thr · pitch dB · spikes dB · sharp dB out · body-region SFX protection ·
 * anti-bullet / anti-knife ANC. RAW COMPLETE.
 */
class SharpBurstKnifeMeterBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Meters 0..1
    @Volatile var burstMeter = 0f
    @Volatile var knifeMeter = 0f
    @Volatile var sharpMeter = 0f
    @Volatile var pitchMeter = 0f
    @Volatile var spikesMeter = 0f

    // Hz analysis — 0 to unlimited (no hard 20k cap for detection path)
    @Volatile var detectedHz = 0f
    @Volatile var pitchHz = 0f
    @Volatile var spikesHz = 0f
    @Volatile var sharpHz = 0f
    @Volatile var burstHz = 0f
    @Volatile var knifeHz = 0f
    @Volatile var detectedHzThr = 0f          // 0 = any
    @Volatile var detectedHzThrMax = 1_000_000f // "unlimited" practical ceiling

    // dB analysis
    @Volatile var pitchDb = -90f
    @Volatile var spikesDb = -90f
    @Volatile var sharpDb = -90f
    @Volatile var burstDb = -90f
    @Volatile var knifeDb = -90f
    @Volatile var pitchDbThr = -55f
    @Volatile var spikesDbThr = -50f
    @Volatile var sharpDbThr = -48f

    // Body region SFX protection
    @Volatile var bodyRegionProtectOn = true
    @Volatile var bodyRegionThr = 0.28f
    @Volatile var bodyRegionLv = 0.90f
    @Volatile var bodyRegionOut = 0f
    @Volatile var headProtect = 0f
    @Volatile var chestProtect = 0f
    @Volatile var bellyProtect = 0f
    @Volatile var armProtect = 0f
    @Volatile var legProtect = 0f

    // Anti bullet / anti knife ANC-style
    @Volatile var antiBulletOn = true
    @Volatile var antiBulletThr = 0.25f
    @Volatile var antiBulletLv = 0.92f
    @Volatile var antiBulletOut = 0f
    @Volatile var antiKnifeOn = true
    @Volatile var antiKnifeThr = 0.25f
    @Volatile var antiKnifeLv = 0.92f
    @Volatile var antiKnifeOut = 0f

    @Volatile var status = "METER·Hz·dB·ANTI idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        micE: Float,
        domHz: Float,
        cenHz: Float,
        rmsDbfs: Float,
        sharpOut: Float,
        burstOut: Float,
        knifeOut: Float,
        bulletOut: Float,
        pitchProxy: Float = 0f,
        spikeProxy: Float = 0f
    ) {
        if (!enabled) {
            status = "METER·Hz·dB·ANTI OFF"
            return
        }
        val e = micE.coerceIn(0f, 1f)
        // Unlimited Hz path: keep raw value (no 20k clamp for analysis)
        detectedHz = maxOf(domHz, cenHz, 0f)
        if (detectedHzThr > 0f && detectedHz < detectedHzThr) {
            // below thr — still show Hz but meters soft
        }
        val hzGate = if (detectedHzThr <= 0f) true
        else detectedHz >= detectedHzThr && detectedHz <= detectedHzThrMax

        pitchHz = if (pitchProxy > 0.01f) detectedHz else detectedHz * 0.95f
        spikesHz = if (spikeProxy > 0.01f) detectedHz * 1.05f else detectedHz
        sharpHz = detectedHz
        burstHz = detectedHz * 0.9f
        knifeHz = detectedHz * 1.1f

        val db = rmsDbfs.coerceIn(-120f, 0f)
        pitchDb = db
        spikesDb = if (spikeProxy > 0.05f) (db + 6f).coerceIn(-120f, 0f) else db
        sharpDb = if (sharpOut > 0.05f) (db + 3f).coerceIn(-120f, 0f) else db
        burstDb = if (burstOut > 0.05f) (db + 4f).coerceIn(-120f, 0f) else db
        knifeDb = if (knifeOut > 0.05f) (db + 5f).coerceIn(-120f, 0f) else db

        val dbOkPitch = pitchDb >= pitchDbThr
        val dbOkSpike = spikesDb >= spikesDbThr
        val dbOkSharp = sharpDb >= sharpDbThr

        // Meters
        sharpMeter = if (hzGate && dbOkSharp) maxOf(sharpOut, e * 0.5f).coerceIn(0f, 1f) else sharpOut * 0.3f
        burstMeter = if (hzGate) maxOf(burstOut, e * 0.45f).coerceIn(0f, 1f) else burstOut * 0.3f
        knifeMeter = if (hzGate) maxOf(knifeOut, e * 0.4f).coerceIn(0f, 1f) else knifeOut * 0.3f
        pitchMeter = if (hzGate && dbOkPitch) maxOf(pitchProxy, e * 0.5f).coerceIn(0f, 1f) else 0f
        spikesMeter = if (hzGate && dbOkSpike) maxOf(spikeProxy, (if (e > 0.4f) e else 0f)).coerceIn(0f, 1f) else 0f

        if (rawComplete) {
            sharpMeter = maxOf(sharpMeter, e)
            burstMeter = maxOf(burstMeter, e)
            knifeMeter = maxOf(knifeMeter, e * 0.9f)
        }

        // Body region SFX protection from sharp/burst/knife/bullet threat
        val threat = maxOf(sharpMeter, burstMeter, knifeMeter, bulletOut, spikesMeter)
        bodyRegionOut = lane(bodyRegionProtectOn, bodyRegionThr, bodyRegionLv, threat)
        headProtect = bodyRegionOut * 1.0f
        chestProtect = bodyRegionOut * 0.95f
        bellyProtect = bodyRegionOut * 0.90f
        armProtect = bodyRegionOut * 0.88f
        legProtect = bodyRegionOut * 0.85f

        // Anti bullet / knife ANC
        antiBulletOut = lane(antiBulletOn, antiBulletThr, antiBulletLv, maxOf(bulletOut, burstMeter))
        antiKnifeOut = lane(antiKnifeOn, antiKnifeThr, antiKnifeLv, maxOf(knifeOut, knifeMeter, sharpMeter * 0.8f))

        status =
            "Hz ${"%.1f".format(detectedHz)} thr=${"%.0f".format(detectedHzThr)} · " +
            "SHARP ${"%.0f".format(sharpHz)}Hz ${"%.0f".format(sharpDb)}dB m=${(sharpMeter*100).toInt()}% · " +
            "BURST m=${(burstMeter*100).toInt()}% KNIFE m=${(knifeMeter*100).toInt()}% · " +
            "PITCH ${"%.0f".format(pitchDb)}dB SPIKE ${"%.0f".format(spikesDb)}dB · " +
            "BODY-PROT=${(bodyRegionOut*100).toInt()}% · " +
            "ANTI-B=${(antiBulletOut*100).toInt()}% ANTI-K=${(antiKnifeOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled) return
        // Feed meters back into bank awareness
        sb.sharpOut = maxOf(sb.sharpOut, sharpMeter * 0.5f)
        sb.burstOut = maxOf(sb.burstOut, burstMeter * 0.5f)
        // Anti bullet/knife damp enemy-like outs (ANC style)
        if (antiBulletOut > 0.02f) {
            val k = (1f - antiBulletOut * 0.95f).coerceIn(0.02f, 1f)
            sb.bulletOut *= k
            sb.burstOut *= k
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
        }
        if (antiKnifeOut > 0.02f) {
            val k = (1f - antiKnifeOut * 0.95f).coerceIn(0.02f, 1f)
            sb.knifeOut *= k
            sb.sharpOut *= k
            sb.enemyBodyOut *= (0.5f + 0.5f * k)
        }
        // Body region protect → atmosphere damp of threat feel on body
        if (bodyRegionOut > 0.02f && v != null) {
            try {
                v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, headProtect * 0.3f) // presence of shield
                v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, chestProtect * 0.3f)
                v.belly.atmosphere = maxOf(v.belly.atmosphere, bellyProtect * 0.3f)
            } catch (_: Throwable) {}
            try {
                v.completeAtomProtect.protectOut = maxOf(v.completeAtomProtect.protectOut, bodyRegionOut)
            } catch (_: Throwable) {}
        }
    }
}
