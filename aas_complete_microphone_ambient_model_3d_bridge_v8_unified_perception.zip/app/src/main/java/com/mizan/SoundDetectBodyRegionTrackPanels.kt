package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object SoundDetectBodyRegionTrackPanels {
    fun build(ctx: Context, root: LinearLayout, b: SoundDetectBodyRegionTrackBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF80DEEA.toInt()
        p.title("SOUND DETECT · BODY REGION TRACK · PEAK REGION", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Sound detect ON", b.detectOn) { b.detectOn = it }
        p.switch("Body region track ON", b.trackOn) { b.trackOn = it }
        p.seek("Detect thr", 0.05f, 0.98f, b.detectThr) { b.detectThr = it }
        p.seek("Detect level", 0f, 1.5f, b.detectLv) { b.detectLv = it }
        val st = p.status("DETECT·TRACK —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 180) }
        })
    }
}
