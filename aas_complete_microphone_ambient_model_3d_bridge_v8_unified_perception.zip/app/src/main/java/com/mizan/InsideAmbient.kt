package com.mizan

/**
 * **Inside ambient system** — organs · skeleton · vessels · brain.
 * Centroid · vertical · Hz · dB · RAW COMPLETE (deeper layers, not skin).
 */
class InsideAmbient {
    @Volatile var enabled = true
    @Volatile var raw = false
    @Volatile var cenHz = 0f
    @Volatile var db = -80.0
    @Volatile var verPct = 0f
    @Volatile var cenOut = 0f
    @Volatile var verOut = 0f
    @Volatile var level = 1f
    @Volatile var thr = 0.25f

    fun feed(board: AmbientThresholdBoard) {
        if (!enabled) return
        val useRaw = raw || board.rawEverything
        cenHz = board.insideHz.takeIf { it > 1f } ?: board.centroidHz
        db = board.micDb()
        verPct = board.verticalNorm
        val c = board.insideCenOut
        val v = board.insideVerOut
        if (useRaw) {
            cenOut = c
            verOut = v
        } else {
            cenOut = if (c >= thr) (c * level).coerceIn(0f, 1.5f) else 0f
            verOut = if (v >= thr) (v * level).coerceIn(0f, 1.5f) else 0f
        }
    }

    fun line(): String =
        "INSIDE AMB · CEN ${cenHz.toInt()}Hz ${"%+.0f".format(db)}dB · VERT ${(verPct*100).toInt()}% · " +
        "C${(cenOut*100).toInt()}% V${(verOut*100).toInt()}%" + (if (raw) " · RAW" else "")

    fun enableRawComplete() {
        enabled = true
        raw = true
        level = 1f
        thr = 0f
    }
}
