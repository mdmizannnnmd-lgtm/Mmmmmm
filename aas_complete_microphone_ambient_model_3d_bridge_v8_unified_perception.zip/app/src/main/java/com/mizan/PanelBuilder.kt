package com.mizan

import android.content.Context
import android.graphics.Color
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/**
 * Builds control rows (title · switch · labelled slider · button · status) into a LinearLayout from code,
 * so the big brain / anatomy panels stay consistent and short. Sliders show their live value.
 */
class PanelBuilder(private val ctx: Context, private val root: LinearLayout) {

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    private fun add(v: android.view.View) {
        root.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    fun title(text: String, color: Int = Color.rgb(0x80, 0xDE, 0xEA)) {
        add(TextView(ctx).apply {
            this.text = text; setTextColor(color); textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(2))
        })
    }

    fun note(text: String) {
        add(TextView(ctx).apply { this.text = text; setTextColor(Color.rgb(0x9E, 0x9E, 0x9E)); textSize = 10f })
    }

    fun status(initial: String, color: Int = Color.rgb(0x80, 0xDE, 0xEA)): TextView {
        val t = TextView(ctx).apply { text = initial; setTextColor(color); textSize = 11f }
        add(t)
        return t
    }

    fun switch(text: String, checked: Boolean, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(ctx).apply {
            this.text = text; isChecked = checked; setTextColor(Color.rgb(0xE5, 0xE5, 0xEA)); textSize = 12f
            setOnCheckedChangeListener { _, c -> onChange(c) }
        }
        add(s)
        return s
    }

    fun button(text: String, onClick: (Button) -> Unit): Button {
        val b = Button(ctx).apply {
            this.text = text; textSize = 11f
            setOnClickListener { onClick(this) }
        }
        add(b)
        return b
    }

    /** Slider from [min] to [max] (float), showing "label · value". */
    fun seek(label: String, min: Float, max: Float, value: Float, decimals: Int = 2, onChange: (Float) -> Unit): SeekBar {
        val steps = 400
        val tv = TextView(ctx).apply { setTextColor(Color.rgb(0xB0, 0xBE, 0xC5)); textSize = 10f }
        fun fmt(v: Float): String = "$label · " + (if (decimals == 0) "${v.toInt()}" else "%.${decimals}f".format(v))
        tv.text = fmt(value)
        add(tv)
        val sb = SeekBar(ctx).apply {
            this.max = steps
            progress = (((value - min) / (max - min)) * steps).toInt().coerceIn(0, steps)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = min + (max - min) * (p / steps.toFloat())
                    tv.text = fmt(v)
                    onChange(v)
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        }
        add(sb)
        return sb
    }
}
