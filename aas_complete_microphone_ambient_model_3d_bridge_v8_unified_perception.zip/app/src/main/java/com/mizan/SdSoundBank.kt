package com.mizan

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.max

/**
 * SD-CARD SOUND BANK — loads the sound files that already exist on the SD card (or any folder the user picked) into
 * the app's own Sound Bank ([SoundBankGuard]) and plays them with proper AUDIO FOCUS.
 *
 * Sources (all merged into one track list):
 *  1. the folder the user picked with the system folder picker (persisted, see [MemoryPaths]) — works for SD / USB / internal
 *     without any storage permission (Storage Access Framework),
 *  2. the app's own folder on every removable card:  Android/data/<package>/files/sounds  (no permission needed),
 *  3. the app's internal  files/sounds  folder.
 *
 * AUDIO FOCUS: the bank asks for focus before playing. On loss it pauses and COLLAPSES the sound bank
 * ([SoundBankGuard.fireCollapse] / [SoundBankGuard.fireAmbSysCollapse]); on transient loss it resumes when focus comes back;
 * on "can duck" it lowers the volume. The live loudness of the playing file (Visualizer RMS) is injected into the bank
 * through [SoundBankGuard.injectSd] so the whole app — brain, anatomy, rings — reacts to the loaded sound.
 */
class SdSoundBank(private val ctx: Context, private val bank: SoundBankGuard) : AudioManager.OnAudioFocusChangeListener {

    class Track(val name: String, val uri: Uri, val source: String)

    val tracks = CopyOnWriteArrayList<Track>()
    @Volatile var scanning = false
        private set
    @Volatile var index = -1
        private set
    @Volatile var loop = false
    @Volatile var shuffle = false
    @Volatile var volume = 0.80f
    @Volatile var focusState = "no focus"
        private set
    @Volatile var focusHeld = false
        private set
    @Volatile var lastError: String? = null
        private set

    private val main = Handler(Looper.getMainLooper())
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var player: MediaPlayer? = null
    private var effectPlayer: MediaPlayer? = null
    private var visualizer: Visualizer? = null
    private var focusReq: AudioFocusRequest? = null
    private var resumeOnGain = false
    private var ducked = false
    @Volatile private var effectGain = 0f
    @Volatile private var smoothLevel = 0f
    @Volatile var lastEffectName = "—"
        private set

    fun bankRef(): SoundBankGuard = bank

    val playing: Boolean get() = try { player?.isPlaying == true } catch (_: Exception) { false }
    val currentName: String get() = tracks.getOrNull(index)?.name ?: MemoryPaths.lastTrackName ?: "—"

    init {
        volume = MemoryPaths.getFloat("sd_volume", 0.80f)
        bank.sdLinkOn = MemoryPaths.getBool("sd_link", true)
        loop = MemoryPaths.getBool("sd_loop", false)
        shuffle = MemoryPaths.getBool("sd_shuffle", false)
    }

    // ───────────────────────────────────────────────────────── scanning
    fun scan(onDone: (() -> Unit)? = null) {
        if (scanning) return
        scanning = true
        Thread {
            val found = ArrayList<Track>()
            try {
                MemoryPaths.soundTreeUri?.let { scanTree(Uri.parse(it), found) }
                scanAppDirs(found)
            } catch (e: Exception) {
                lastError = "scan: ${e.message}"
            }
            found.sortBy { it.name.lowercase() }
            main.post {
                tracks.clear(); tracks.addAll(found)
                val last = MemoryPaths.lastTrackUri
                index = if (last != null) found.indexOfFirst { it.uri.toString() == last } else -1
                scanning = false
                onDone?.invoke()
            }
        }.start()
    }

    private fun isAudioName(n: String): Boolean {
        val e = n.substringAfterLast('.', "").lowercase()
        return e in AUDIO_EXT
    }

    private fun scanAppDirs(out: MutableList<Track>) {
        try {
            // index 0 = primary shared storage, index >= 1 = removable SD card / USB (null when not mounted)
            ctx.getExternalFilesDirs("sounds").forEachIndexed { i, f ->
                if (f != null) {
                    if (!f.exists()) f.mkdirs()
                    walkFiles(f, 0, if (i == 0) "device" else "SD card", out)
                }
            }
        } catch (_: Exception) {}
        val internal = File(ctx.filesDir, "sounds")
        if (!internal.exists()) internal.mkdirs()
        walkFiles(internal, 0, "internal", out)
    }

    private fun walkFiles(dir: File, depth: Int, label: String, out: MutableList<Track>) {
        if (depth > 4 || out.size >= MAX_TRACKS) return
        val list = dir.listFiles() ?: return
        for (f in list) {
            if (out.size >= MAX_TRACKS) return
            if (f.isDirectory) walkFiles(f, depth + 1, label, out)
            else if (isAudioName(f.name)) out.add(Track(f.nameWithoutExtension, Uri.fromFile(f), label))
        }
    }

    private fun scanTree(tree: Uri, out: MutableList<Track>) {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        walkTree(tree, rootId, 0, out)
    }

    private fun walkTree(tree: Uri, docId: String, depth: Int, out: MutableList<Track>) {
        if (depth > 5 || out.size >= MAX_TRACKS) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                if (out.size >= MAX_TRACKS) return
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val mime = c.getString(2) ?: ""
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    walkTree(tree, id, depth + 1, out)
                } else if (mime.startsWith("audio/") || isAudioName(name)) {
                    out.add(Track(name.substringBeforeLast('.'), DocumentsContract.buildDocumentUriUsingTree(tree, id), "picked folder"))
                }
            }
        }
    }

    // ───────────────────────────────────────────────────────── audio focus
    private fun requestFocus(): Boolean {
        val r = if (Build.VERSION.SDK_INT >= 26) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setOnAudioFocusChangeListener(this, main)
                .setWillPauseWhenDucked(false)
                .build()
            focusReq = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        focusHeld = r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        focusState = if (focusHeld) "focus GAIN" else "focus DENIED"
        return focusHeld
    }

    private fun abandonFocus() {
        try {
            if (Build.VERSION.SDK_INT >= 26) focusReq?.let { am.abandonAudioFocusRequest(it) }
            else @Suppress("DEPRECATION") am.abandonAudioFocus(this)
        } catch (_: Exception) {}
        focusHeld = false
        focusState = "no focus"
    }

    override fun onAudioFocusChange(change: Int) {
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                focusHeld = true; focusState = "focus GAIN"
                if (ducked) { ducked = false; applyVolume(); applyEffectVolume() }
                if (resumeOnGain) { resumeOnGain = false; try { player?.start() } catch (_: Exception) {} }
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                focusHeld = false; focusState = "focus LOSS → collapse"
                resumeOnGain = false
                try { player?.pause() } catch (_: Exception) {}
                stopEffectPlayer()
                collapseBank()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                focusState = "focus LOSS (transient)"
                resumeOnGain = playing
                try { player?.pause() } catch (_: Exception) {}
                stopEffectPlayer()
                bank.fireAmbSysCollapse()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                focusState = "focus DUCK"
                ducked = true; applyVolume()
                applyEffectVolume()
            }
        }
    }

    /** Collapse the whole sound bank (ambient systems + enemy bank + own collapse) — used on audio-focus loss. */
    fun collapseBank() {
        bank.fireCollapse()
        bank.fireAmbSysCollapse()
        bank.fireEnemyBankCollapse()
    }

    // ───────────────────────────────────────────────────────── playback
    private fun applyVolume() {
        val v = (if (ducked) volume * 0.2f else volume).coerceIn(0f, 1f)
        try { player?.setVolume(v, v) } catch (_: Exception) {}
    }

    fun play(i: Int, startMs: Int = 0) {
        val t = tracks.getOrNull(i) ?: run { lastError = "no track"; return }
        stopPlayer()
        if (!requestFocus()) { lastError = "audio focus denied"; return }
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            mp.setDataSource(ctx, t.uri)
            mp.setOnPreparedListener {
                if (startMs > 0) it.seekTo(startMs)
                it.start()
                attachVisualizer(it.audioSessionId)
            }
            mp.setOnCompletionListener { onCompleted() }
            mp.setOnErrorListener { _, w, e -> lastError = "player $w/$e"; stopPlayer(); true }
            player = mp
            index = i
            applyVolume()
            mp.prepareAsync()
            MemoryPaths.lastTrackUri = t.uri.toString()
            MemoryPaths.lastTrackName = t.name
            lastError = null
        } catch (e: Exception) {
            lastError = "play: ${e.message}"
            stopPlayer()
        }
    }

    private fun onCompleted() {
        MemoryPaths.lastPositionMs = 0
        if (loop) { play(index); return }
        next()
    }

    fun togglePause() {
        val p = player
        if (p == null) { resumeLast(); return }
        try {
            if (p.isPlaying) { p.pause(); MemoryPaths.lastPositionMs = p.currentPosition }
            else if (requestFocus()) p.start()
        } catch (_: Exception) {}
    }

    /** Continue the track that was playing when the app was last closed (from the remembered position). */
    fun resumeLast() {
        val last = MemoryPaths.lastTrackUri
        val i = if (last != null) tracks.indexOfFirst { it.uri.toString() == last } else -1
        if (i >= 0) play(i, MemoryPaths.lastPositionMs) else if (tracks.isNotEmpty()) play(0)
    }

    fun next() {
        if (tracks.isEmpty()) return
        val n = if (shuffle) (0 until tracks.size).random() else (index + 1) % tracks.size
        play(n)
    }

    fun prev() {
        if (tracks.isEmpty()) return
        play(if (index <= 0) tracks.size - 1 else index - 1)
    }

    fun stop() {
        try { player?.let { MemoryPaths.lastPositionMs = if (it.isPlaying) it.currentPosition else MemoryPaths.lastPositionMs } } catch (_: Exception) {}
        stopEffectPlayer()
        stopPlayer()
        abandonFocus()
    }

    /**
     * Play one short sound from the remembered SD-card folder as a camera-gated
     * effect. This player is separate from the normal track player.
     */
    fun playEffect(trackIndex: Int, intensity: Float, playbackRate: Float = 1f) {
        val track = tracks.getOrNull(trackIndex) ?: run {
            lastError = "effect sound not found"
            return
        }
        val gain = intensity.coerceIn(0f, 1f)
        val rate = playbackRate.coerceIn(0.85f, 1.35f)
        main.post {
            try {
                stopEffectPlayer()
                if (!focusHeld && !requestFocus()) {
                    lastError = "effect audio focus denied"
                    return@post
                }
                val mp = MediaPlayer()
                effectPlayer = mp
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                mp.setDataSource(ctx, track.uri)
                mp.setOnPreparedListener { prepared ->
                    if (effectPlayer !== prepared) {
                        try { prepared.release() } catch (_: Exception) {}
                        return@setOnPreparedListener
                    }
                    effectGain = gain
                    applyEffectVolume()
                    if (Build.VERSION.SDK_INT >= 23) {
                        try {
                            prepared.setPlaybackParams(prepared.playbackParams.setSpeed(rate))
                        } catch (_: Exception) {}
                    }
                    prepared.start()
                    lastEffectName = track.name
                    lastError = null
                }
                mp.setOnCompletionListener { completed ->
                    if (effectPlayer === completed) {
                        try { completed.release() } catch (_: Exception) {}
                        effectPlayer = null
                        effectGain = 0f
                        if (!playing) abandonFocus()
                    }
                }
                mp.setOnErrorListener { failed, what, extra ->
                    lastError = "effect player $what/$extra"
                    if (effectPlayer === failed) {
                        try { failed.release() } catch (_: Exception) {}
                        effectPlayer = null
                        effectGain = 0f
                        if (!playing) abandonFocus()
                    }
                    true
                }
                mp.prepareAsync()
            } catch (e: Exception) {
                lastError = "effect: ${e.message ?: "playback failed"}"
                stopEffectPlayer()
                if (!playing) abandonFocus()
            }
        }
    }

    private fun stopEffectPlayer() {
        try { effectPlayer?.stop() } catch (_: Exception) {}
        try { effectPlayer?.release() } catch (_: Exception) {}
        effectPlayer = null
        effectGain = 0f
    }

    private fun applyEffectVolume() {
        val duckFactor = if (ducked) 0.2f else 1f
        val v = (volume * effectGain * duckFactor).coerceIn(0f, 1f)
        try { effectPlayer?.setVolume(v, v) } catch (_: Exception) {}
    }

    private fun stopPlayer() {
        try { visualizer?.setEnabled(false); visualizer?.release() } catch (_: Exception) {}
        visualizer = null
        try { player?.release() } catch (_: Exception) {}
        player = null
        smoothLevel = 0f
    }

    fun setVolumeLevel(v: Float) {
        volume = v.coerceIn(0f, 1f)
        MemoryPaths.putFloat("sd_volume", volume)
        applyVolume()
    }

    fun setLoopOn(v: Boolean) { loop = v; MemoryPaths.putBool("sd_loop", v) }
    fun setShuffleOn(v: Boolean) { shuffle = v; MemoryPaths.putBool("sd_shuffle", v) }

    /** Remember where the playing sound is, so it can resume after the app is closed. */
    fun rememberPosition() {
        try { player?.let { if (it.isPlaying) MemoryPaths.lastPositionMs = it.currentPosition } } catch (_: Exception) {}
    }

    /** Call from Activity.onDestroy. */
    fun release() {
        stop()
    }

    // ───────────────────────────────────────────────────────── live level → sound bank
    private fun attachVisualizer(session: Int) {
        try {
            val v = Visualizer(session)
            v.setMeasurementMode(Visualizer.MEASUREMENT_MODE_PEAK_RMS)
            v.setEnabled(true)
            visualizer = v
        } catch (_: Throwable) {
            visualizer = null   // no RECORD_AUDIO / unsupported → fallback level below
        }
    }

    /** 0..1 loudness of the playing file (0 when not playing). */
    fun level(): Float {
        if (!playing) { smoothLevel *= 0.85f; return smoothLevel }
        var raw = 0.35f * volume
        val v = visualizer
        if (v != null) {
            try {
                val m = Visualizer.MeasurementPeakRms()
                if (v.getMeasurementPeakRms(m) == Visualizer.SUCCESS) {
                    val db = m.mRms / 100f                       // millibel → dB (−96 … 0)
                    raw = ((db + 60f) / 60f).coerceIn(0f, 1f)
                }
            } catch (_: Throwable) {}
        }
        smoothLevel += (raw - smoothLevel) * (if (raw > smoothLevel) 0.5f else 0.15f)
        return smoothLevel
    }

    /** Push the loaded sound into the app's Sound Bank. Call once per frame. */
    fun pushToBank() {
        bank.injectSd(level(), playing, focusHeld)
    }

    fun statusLine(): String {
        val pos = try { player?.let { "${it.currentPosition / 1000}s/${it.duration / 1000}s" } ?: "—" } catch (_: Exception) { "—" }
        return "SD-BANK · ${tracks.size} sounds${if (scanning) " (scanning…)" else ""} · " +
            (if (playing) "▶" else "■") + " $currentName $pos · $focusState · lvl=${(smoothLevel * 100).toInt()}%" +
            (if (loop) " · LOOP" else "") + (if (shuffle) " · SHUFFLE" else "") +
            (lastError?.let { " · ! $it" } ?: "")
    }

    companion object {
        private const val MAX_TRACKS = 2000
        private val AUDIO_EXT = setOf("mp3", "wav", "ogg", "oga", "m4a", "aac", "flac", "opus", "amr", "3gp", "mid", "midi")
    }
}
