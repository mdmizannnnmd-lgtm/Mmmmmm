package com.mizan

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * AUDIO LEVELS board — audio brightness + audio contrast + raw complete, applied to the microphone
 * signal before any of the analysis (RMS, bands, echo, ambient, guards) sees it.
 *
 *  - AUDIO BRIGHTNESS (−1 … +1): spectral tilt. Positive lifts the highs (high-shelf, up to ≈ +12 dB),
 *    negative rolls them off (down to a full low-pass at −1). 0 = unchanged.
 *  - AUDIO CONTRAST (0 … 2): dynamic contrast around [pivot]. 1 = unchanged, above 1 widens the dynamic
 *    range (quiet gets quieter, loud gets louder), below 1 squeezes it. The gain change is clamped to
 *    ¼× … 4× and ramped across the buffer, so it never clicks.
 *  - RAW COMPLETE: skips both of the above and lets [AudioProcessor] use the complete signal untouched
 *    (amplifier gain 1×, no RMS smoothing). The ambient limiter / gate stays active.
 *
 * Defaults: OFF and neutral, so nothing changes until you enable it.
 */
class AudioLevelsBoard {
    @Volatile var enabled = false
    @Volatile var rawComplete = true

    @Volatile var brightness = 0f       // −1 … +1
    @Volatile var contrast = 1f         // 0 … 2
    @Volatile var pivot = 0.10f         // RMS (0..1) that contrast leaves unchanged

    // ---- live readouts ----
    @Volatile var inRms = 0f
    @Volatile var outRms = 0f
    @Volatile var gainApplied = 1f

    private var lp = 0.0          // low-pass state for the tilt filter
    private var prevGain = 1f

    /** True when [process] would actually change the signal. */
    fun needsProcessing(): Boolean =
        enabled && !rawComplete && (abs(brightness) > 0.005f || abs(contrast - 1f) > 0.005f)

    /**
     * Writes the processed samples of [src] (first [n]) into [dst]; [dst] must hold at least [n] samples.
     * Never modifies [src].
     */
    fun process(src: ShortArray, n: Int, dst: ShortArray, sampleRate: Int = 44100) {
        if (n <= 0) return
        val b = brightness.coerceIn(-1f, 1f)
        // k: output = x + k * (x − lowpass(x)). k = −1 → pure low-pass, k = +3 → ≈ +12 dB highs.
        val k = if (b >= 0f) b * 3.0 else b.toDouble()
        val fc = 2000.0
        val a = exp(-2.0 * Math.PI * fc / sampleRate)

        var sumIn = 0.0
        var sumTilt = 0.0
        val tilted = tiltBuf(n)
        for (i in 0 until n) {
            val x = src[i] / 32768.0
            lp = (1.0 - a) * x + a * lp
            val y = x + k * (x - lp)
            tilted[i] = y
            sumIn += x * x
            sumTilt += y * y
        }
        val rmsIn = sqrt(sumIn / n).toFloat()
        val rmsTilt = sqrt(sumTilt / n).toFloat()
        inRms = rmsIn

        val c = contrast.coerceIn(0f, 2f)
        val target = if (abs(c - 1f) < 0.005f) 1f
        else {
            val pv = pivot.coerceIn(0.005f, 0.8f)
            (rmsTilt.coerceAtLeast(1e-4f) / pv).toDouble().pow((c - 1f).toDouble()).toFloat()
                .coerceIn(0.25f, 4f)
        }

        // Ramp the gain across the buffer so contrast never clicks.
        val g0 = prevGain
        var sumOut = 0.0
        for (i in 0 until n) {
            val g = g0 + (target - g0) * ((i + 1).toFloat() / n)
            val v = (tilted[i] * g).coerceIn(-1.0, 1.0)
            sumOut += v * v
            dst[i] = (v * 32767.0).toInt().toShort()
        }
        prevGain = target
        gainApplied = target
        outRms = sqrt(sumOut / n).toFloat()
    }

    private var scratch = DoubleArray(0)
    private fun tiltBuf(n: Int): DoubleArray {
        if (scratch.size < n) scratch = DoubleArray(n)
        return scratch
    }

    fun statusLine(): String {
        if (rawComplete) return "AUDIO LEVELS RAW COMPLETE · untouched signal · gain 1× · no smoothing"
        if (!enabled) return "AUDIO LEVELS off"
        return "AUDIO LEVELS bright=${"%+.2f".format(brightness)} contrast=${"%.2f".format(contrast)}× " +
            "pivot=${(pivot * 100).toInt()}% · in ${(inRms * 100).toInt()}% → out ${(outRms * 100).toInt()}% " +
            "(gain ${"%.2f".format(gainApplied)}×)"
    }
}
