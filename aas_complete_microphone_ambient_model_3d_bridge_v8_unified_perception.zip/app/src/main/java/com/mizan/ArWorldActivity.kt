package com.mizan

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.Manifest.permission.RECORD_AUDIO
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Session
import java.util.Locale
import kotlin.math.sqrt

/**
 * A local, decorative AR playground. Shapes are anchored to ARCore planes;
 * the scene does not detect weapons or claim to provide physical protection.
 */
class ArWorldActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var surface: GLSurfaceView
    private lateinit var renderer: ArWorldRenderer
    private lateinit var status: TextView
    private val audioMonitor = ArAudioMonitor { level, atmosphere ->
        runOnUiThread {
            if (::renderer.isInitialized) {
                renderer.soundValue = level
                renderer.atmosphereValue = atmosphere
            }
        }
    }
    private var session: Session? = null
    private var installRequested = false
    private var audioPermissionRequested = false
    private var sensorManager: SensorManager? = null
    private var lastAcceleration = 9.81f
    private var motionThreshold = 0.18f
    private var selectedShape = ArWorldRenderer.Shape.MESH

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        renderer = ArWorldRenderer { line -> runOnUiThread { status.text = line } }
        surface = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_UP) {
                    renderer.requestPlacement(event.x, event.y, selectedShape)
                    true
                } else true
            }
        }

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(surface, FrameLayout.LayoutParams(-1, -1))
        }
        status = TextView(this).apply {
            text = "AR WORLD · Looking for surfaces…"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setBackgroundColor(0xCC101820.toInt())
        }
        root.addView(status, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val controls = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
            addView(buildControls())
        }
        root.addView(
            controls,
            FrameLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.55f).toInt(), Gravity.BOTTOM).apply {
                leftMargin = dp(8)
                rightMargin = dp(8)
                bottomMargin = dp(8)
            }
        )
        setContentView(root)

        sensorManager = getSystemService(SENSOR_SERVICE) as? SensorManager
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_REQUEST)
        }
    }

    private fun buildControls(): View {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(0xDD101820.toInt())
        }
        val hint = TextView(this).apply {
            text = "Scan a floor or wall, choose a layer, then tap to place it. MESH is decorative; studio pose detection stays on the studio camera screen."
            setTextColor(0xFFCFD8DC.toInt())
            textSize = 12f
            setPadding(0, 0, 0, dp(6))
        }
        panel.addView(hint)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val modes = listOf(
            "MESH" to ArWorldRenderer.Shape.MESH,
            "RING" to ArWorldRenderer.Shape.RING,
            "CURVE" to ArWorldRenderer.Shape.CURVE,
            "WALL" to ArWorldRenderer.Shape.WALL,
            "AURA" to ArWorldRenderer.Shape.AURA,
            "SHIELD" to ArWorldRenderer.Shape.SHIELD
        )
        modes.forEach { (label, shape) ->
            row.addView(Button(this).apply {
                text = label
                textSize = 10f
                setPadding(dp(3), 0, dp(3), 0)
                setOnClickListener {
                    selectedShape = shape
                    Toast.makeText(this@ArWorldActivity, "$label selected · tap a tracked plane", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(3)
            })
        }
        panel.addView(row)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        actions.addView(Button(this).apply {
            text = "CLEAR"
            textSize = 10f
            setOnClickListener { surface.queueEvent { renderer.clearObjects() } }
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) })
        val planesButton = Button(this).apply {
            text = if (renderer.showPlanes) "PLANES ON" else "PLANES OFF"
            textSize = 10f
            setOnClickListener {
                renderer.showPlanes = !renderer.showPlanes
                text = if (renderer.showPlanes) "PLANES ON" else "PLANES OFF"
            }
        }
        actions.addView(planesButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        panel.addView(actions)

        panel.addView(thresholdRow("New layer size", 35) {
            renderer.objectScale = 0.2f + it / 100f * 2.3f
        })
            panel.addView(Button(this@ArWorldActivity).apply {
                text = if (renderer.showPointCloud) "POINTS ON" else "POINTS OFF"
                setOnClickListener {
                    renderer.showPointCloud = !renderer.showPointCloud
                    text = if (renderer.showPointCloud) "POINTS ON" else "POINTS OFF"
                }
            })

        panel.addView(thresholdRow("New layer intensity", 80) {
            renderer.objectIntensity = 0.05f + it / 100f * 0.95f
        })
        panel.addView(thresholdRow("New layer rotation · rad/s", 12) {
            renderer.rotationSpeed = it / 100f * 2.5f
        })

        panel.addView(thresholdRow("Camera light FX threshold", 28) {
            renderer.ambientThreshold = it / 100f
        })
        panel.addView(thresholdRow("Motion FX threshold", 18) {
            motionThreshold = it / 100f
            renderer.motionThreshold = motionThreshold
        })
        panel.addView(thresholdRow("AR sound FX threshold · microphone level", 42) {
            renderer.soundThreshold = it / 100f
        })
        panel.addView(thresholdRow("AR atmosphere FX threshold · room-tone share", 35) {
            renderer.atmosphereThreshold = it / 100f
        })
        panel.addView(Button(this).apply {
            text = "BACK TO STUDIO"
            textSize = 11f
            setOnClickListener { finish() }
        })
        return panel
    }

    private fun thresholdRow(label: String, initial: Int, onChange: (Int) -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        row.addView(TextView(this).apply {
            text = label
            setTextColor(0xFFB0BEC5.toInt())
            textSize = 11f
        })
        row.addView(SeekBar(this).apply {
            max = 100
            progress = initial
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    onChange(value)
                }
                override fun onStartTrackingTouch(bar: SeekBar?) = Unit
                override fun onStopTrackingTouch(bar: SeekBar?) = Unit
            })
        })
        return row
    }

    override fun onResume() {
        super.onResume()
        surface.onResume()
        sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            resumeArSession()
        }
    }

    private fun resumeArSession() {
        try {
            when (ArCoreApk.getInstance().requestInstall(this, !installRequested)) {
                ArCoreApk.InstallStatus.INSTALL_REQUESTED -> {
                    installRequested = true
                    status.text = "Install or update Google Play Services for AR, then return here."
                    return
                }
                else -> Unit
            }
            val active = session ?: Session(this).also { session = it }
            val config = Config(active).apply {
                planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
                lightEstimationMode = Config.LightEstimationMode.AMBIENT_INTENSITY
                updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
            }
            active.configure(config)
            active.resume()
            renderer.setSession(active)
            startAudioOrRequestPermission()
        } catch (error: Exception) {
            status.text = "AR unavailable · ${error.message ?: "check ARCore support"}"
            Toast.makeText(this, status.text, Toast.LENGTH_LONG).show()
        }
    }

    override fun onPause() {
        audioMonitor.stop()
        sensorManager?.unregisterListener(this)
        try { session?.pause() } catch (_: Exception) {}
        surface.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        audioMonitor.stop()
        try { session?.close() } catch (_: Exception) {}
        session = null
        super.onDestroy()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val magnitude = sqrt(
            event.values[0] * event.values[0] +
                event.values[1] * event.values[1] +
                event.values[2] * event.values[2]
        )
        val motion = (kotlin.math.abs(magnitude - lastAcceleration) / 9.81f).coerceIn(0f, 1f)
        lastAcceleration = magnitude
        renderer.motionValue = motion
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    @Deprecated("Legacy permission callback used for the existing Android target")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == AUDIO_REQUEST) {
            val granted = results.firstOrNull() == PackageManager.PERMISSION_GRANTED
            val started = granted && audioMonitor.start()
            renderer.audioAvailable = started
            if (!started) status.text = "AR WORLD · microphone FX unavailable · mesh and plane tracking still work"
            return
        }
        if (requestCode == CAMERA_REQUEST && results.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            resumeArSession()
        } else if (requestCode == CAMERA_REQUEST) {
            status.text = "Camera permission is needed for the AR camera view."
        }
    }

    private fun startAudioOrRequestPermission() {
        if (checkSelfPermission(RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            val started = audioMonitor.start()
            renderer.audioAvailable = started
            if (!started) status.text = "AR WORLD · microphone unavailable · audio thresholds are idle"
        } else if (!audioPermissionRequested) {
            audioPermissionRequested = true
            requestPermissions(arrayOf(RECORD_AUDIO), AUDIO_REQUEST)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val CAMERA_REQUEST = 3812
        private const val AUDIO_REQUEST = 3813
    }
}
