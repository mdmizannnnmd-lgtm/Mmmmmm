package com.mizan

/** Immutable description of one microphone PCM frame published by [RawMicBus]. */
data class RawMicFrame(
    /** Mono PCM view used by the existing analysis boards. */
    val pcm: ShortArray,
    /** Exact interleaved PCM16 frame when the source was multichannel. */
    val rawInterleavedPcm: ShortArray,
    val length: Int,
    val sampleRate: Int,
    val channels: Int,
    val sequence: Long,
    val timestampMs: Long,
    val rms: Float,
    val peak: Float,
    val dbfs: Float,
    val dominantHz: Float,
    val centroidHz: Float
)
