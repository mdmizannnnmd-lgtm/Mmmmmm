package com.mizan

/**
 * Complete human 360° anatomy ambient — external directions + cavities +
 * layer stack + major channel systems + quantum-level symbolic hierarchy.
 * Fills gaps from full anatomical blueprint (front/back/L/R/up/down/inner).
 * Eye ICT XYZ center + camera eye point. Symbolic ambient only. RAW COMPLETE.
 */
class CompleteHumanAnatomy360Board {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.18f
    @Volatile var levelAmt = 0.92f

    // Directions 360
    @Volatile var frontOut = 0f
    @Volatile var backOut = 0f
    @Volatile var leftOut = 0f
    @Volatile var rightOut = 0f
    @Volatile var upOut = 0f
    @Volatile var downOut = 0f
    @Volatile var innerOut = 0f
    @Volatile var outerOut = 0f
    @Volatile var dirFull = 0f

    // External regions (group energy)
    @Volatile var headExt = 0f
    @Volatile var neckExt = 0f
    @Volatile var thoraxExt = 0f
    @Volatile var abdomenExt = 0f
    @Volatile var pelvisExt = 0f
    @Volatile var upperLimbExt = 0f
    @Volatile var lowerLimbExt = 0f

    // Cavities
    @Volatile var cranialCav = 0f
    @Volatile var thoracicCav = 0f
    @Volatile var abdominalCav = 0f
    @Volatile var pelvicCav = 0f
    @Volatile var cavityFull = 0f

    // Layers outside→inside
    @Volatile var layerSkin = 0f
    @Volatile var layerFascia = 0f
    @Volatile var layerMuscle = 0f
    @Volatile var layerBone = 0f
    @Volatile var layerOrgan = 0f
    @Volatile var layerFull = 0f

    // Channel systems
    @Volatile var channelBlood = 0f
    @Volatile var channelLymph = 0f
    @Volatile var channelNerve = 0f
    @Volatile var channelAir = 0f
    @Volatile var channelDigest = 0f
    @Volatile var channelUrine = 0f
    @Volatile var channelFull = 0f

    // Quantum hierarchy symbolic (atom→molecule→cell)
    @Volatile var quantumAtom = 0f
    @Volatile var quantumMolecule = 0f
    @Volatile var quantumCell = 0f
    @Volatile var quantumFull = 0f

    // Eye ICT trans-communication ambient — position XYZ + center + camera eye point
    @Volatile var eyeIctOn = true
    @Volatile var eyeX = 0.5f
    @Volatile var eyeY = 0.5f
    @Volatile var eyeZ = 0.5f
    @Volatile var eyeCenter = 0.5f
    @Volatile var cameraEyePointX = 0.5f
    @Volatile var cameraEyePointY = 0.5f
    @Volatile var cameraEyePointZ = 0.5f
    @Volatile var eyeIctOut = 0f

    // 3D draw drives
    @Volatile var draw360 = 0f
    @Volatile var drawChannels = 0f
    @Volatile var drawQuantum = 0f
    @Volatile var drawEyeIct = 0f

    @Volatile var systemFull = 0f
    @Volatile var status = "ANATOMY-360 idle"

    private fun lane(e: Float, t: Float = thr): Float {
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * levelAmt).coerceIn(0f, 1f)
        return if (x >= t) ((x - t) / (1.2f - t).coerceAtLeast(0.05f) * levelAmt).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        mic: Float,
        model: Float,
        eyeL: Float,
        eyeR: Float,
        body: Float,
        chem: Float,
        water: Float,
        neuro: Float,
        poseX: Float,
        poseY: Float,
        poseZ: Float
    ) {
        if (!enabled) { status = "ANATOMY-360 OFF"; return }
        val e = maxOf(mic * 0.5f, model, body * 0.8f).coerceIn(0f, 1.5f)

        frontOut = lane(e * 0.95f + model * 0.3f)
        backOut = lane(e * 0.9f)
        leftOut = lane(e * 0.88f + poseX * 0.4f)
        rightOut = lane(e * 0.88f + (1f - poseX) * 0.4f)
        upOut = lane(e * 0.85f + poseY * 0.4f)
        downOut = lane(e * 0.85f + (1f - poseY) * 0.4f)
        innerOut = lane(e * 0.9f + neuro * 0.4f + chem * 0.3f)
        outerOut = lane(e * 0.92f + water * 0.3f)
        dirFull = maxOf(frontOut, backOut, leftOut, rightOut, upOut, downOut, innerOut, outerOut)

        headExt = lane(maxOf(eyeL, eyeR) * 0.8f + e * 0.5f)
        neckExt = lane(e * 0.75f)
        thoraxExt = lane(e * 0.8f + body * 0.3f)
        abdomenExt = lane(e * 0.78f)
        pelvisExt = lane(e * 0.72f)
        upperLimbExt = lane(e * 0.7f + poseX * 0.3f)
        lowerLimbExt = lane(e * 0.7f + poseY * 0.3f)

        cranialCav = lane(maxOf(eyeL, eyeR, neuro) * 0.85f)
        thoracicCav = lane(e * 0.8f)
        abdominalCav = lane(e * 0.75f + chem * 0.3f)
        pelvicCav = lane(e * 0.7f)
        cavityFull = maxOf(cranialCav, thoracicCav, abdominalCav, pelvicCav)

        layerSkin = lane(outerOut * 0.9f + water * 0.3f)
        layerFascia = lane(e * 0.7f)
        layerMuscle = lane(body * 0.85f)
        layerBone = lane(e * 0.65f)
        layerOrgan = lane(innerOut * 0.9f)
        layerFull = maxOf(layerSkin, layerFascia, layerMuscle, layerBone, layerOrgan)

        channelBlood = lane(e * 0.8f + chem * 0.3f)
        channelLymph = lane(e * 0.7f)
        channelNerve = lane(neuro * 0.95f)
        channelAir = lane(e * 0.75f)
        channelDigest = lane(e * 0.7f + chem * 0.25f)
        channelUrine = lane(e * 0.65f + water * 0.3f)
        channelFull = maxOf(channelBlood, channelLymph, channelNerve, channelAir, channelDigest, channelUrine)

        quantumAtom = lane(chem * 0.8f + e * 0.4f)
        quantumMolecule = lane(chem * 0.85f + water * 0.3f)
        quantumCell = lane(maxOf(quantumMolecule, neuro * 0.5f))
        quantumFull = maxOf(quantumAtom, quantumMolecule, quantumCell)

        // Eye ICT XYZ
        if (eyeIctOn) {
            eyeX = (0.5f + (eyeL - eyeR) * 0.25f + (poseX - 0.5f) * 0.3f).coerceIn(0f, 1f)
            eyeY = (0.5f + (maxOf(eyeL, eyeR) - 0.5f) * 0.3f + (poseY - 0.5f) * 0.2f).coerceIn(0f, 1f)
            eyeZ = (0.5f + poseZ * 0.4f).coerceIn(0f, 1f)
            eyeCenter = ((eyeX + eyeY + eyeZ) / 3f).coerceIn(0f, 1f)
            cameraEyePointX = eyeX
            cameraEyePointY = eyeY
            cameraEyePointZ = eyeZ
            eyeIctOut = lane(maxOf(eyeL, eyeR, eyeCenter))
        }

        draw360 = dirFull
        drawChannels = channelFull
        drawQuantum = quantumFull
        drawEyeIct = eyeIctOut
        if (rawComplete) {
            draw360 = maxOf(draw360, 0.3f)
            drawChannels = maxOf(drawChannels, 0.28f)
            drawQuantum = maxOf(drawQuantum, 0.25f)
            drawEyeIct = maxOf(drawEyeIct, 0.25f)
        }

        systemFull = maxOf(dirFull, cavityFull, layerFull, channelFull, quantumFull, eyeIctOut)
        if (rawComplete) systemFull = maxOf(systemFull, 0.3f)

        status =
            "360 F/B/L/R/U/D=${(frontOut*100).toInt()}/${(backOut*100).toInt()}/${(leftOut*100).toInt()}/${(rightOut*100).toInt()}/${(upOut*100).toInt()}/${(downOut*100).toInt()}% · " +
            "cav/layer/ch=${(cavityFull*100).toInt()}/${(layerFull*100).toInt()}/${(channelFull*100).toInt()}% · " +
            "eyeICT xyz=${"%.2f".format(eyeX)},${"%.2f".format(eyeY)},${"%.2f".format(eyeZ)} c=${"%.2f".format(eyeCenter)}" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView?) {
        if (!enabled) return
        val vv = v ?: return
        try {
            vv.soft3d.anatomy360Layer = draw360
            vv.soft3d.channelLayer = drawChannels
            vv.soft3d.quantumLayer = drawQuantum
            vv.soft3d.eyeIctLayer = drawEyeIct
            vv.screenEffectInside.drawGland = maxOf(vv.screenEffectInside.drawGland, layerOrgan * 0.5f)
            vv.fullAnatomy132.brainOut = maxOf(vv.fullAnatomy132.brainOut, cranialCav * 0.5f)
            vv.cnsEyesHeart.eyeLOut = maxOf(vv.cnsEyesHeart.eyeLOut, eyeIctOut * 0.4f)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, systemFull * 0.35f)
        } catch (_: Throwable) {}
    }
}
