package com.mizan

import android.content.Context
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object DevHttpsApiPanels {
    fun build(ctx: Context, root: LinearLayout, api: DevHttpsApiTester) {
        val c = 0xFFA5D6A7.toInt()
        root.addView(TextView(ctx).apply {
            text = "DEV HTTPS API · REQUEST · RESPONSE · MODIFY"
            setTextColor(c)
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setPadding(8, 12, 8, 8)
        })

        fun label(s: String) = TextView(ctx).apply {
            text = s
            setTextColor(0xFFB0BEC5.toInt())
            textSize = 12f
            setPadding(8, 8, 8, 2)
        }
        fun edit(hint: String, multi: Boolean = false) = EditText(ctx).apply {
            this.hint = hint
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0x88FFFFFF.toInt())
            setBackgroundColor(0x33FFFFFF)
            setPadding(12, 10, 12, 10)
            if (multi) {
                minLines = 3
                maxLines = 8
                gravity = android.view.Gravity.TOP or android.view.Gravity.START
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            } else {
                setSingleLine(true)
            }
        }

        root.addView(label("URL (HTTPS)"))
        val urlEdit = edit("https://…").apply { setText(api.lastUrl) }
        root.addView(urlEdit)

        root.addView(label("Method"))
        val methodRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("GET", "POST", "PUT", "PATCH", "DELETE").forEach { mth ->
            methodRow.addView(Button(ctx).apply {
                text = mth
                textSize = 11f
                setOnClickListener { api.method = mth }
            })
        }
        root.addView(methodRow)

        root.addView(label("Request headers (one Header: value per line)"))
        val hdrEdit = edit("Accept: …", multi = true).apply { setText(api.requestHeaders) }
        root.addView(hdrEdit)

        root.addView(label("Request body (modifiable)"))
        val bodyEdit = edit("{ }", multi = true).apply { setText(api.requestBody) }
        root.addView(bodyEdit)

        val modRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        modRow.addView(Button(ctx).apply {
            text = "Pretty indent"
            setOnClickListener {
                val t = bodyEdit.text?.toString().orEmpty()
                bodyEdit.setText(t.replace(",", ",\n").replace("{", "{\n").replace("}", "\n}"))
            }
        })
        modRow.addView(Button(ctx).apply {
            text = "Clear body"
            setOnClickListener { bodyEdit.setText("") }
        })
        modRow.addView(Button(ctx).apply {
            text = "Wrap JSON"
            setOnClickListener {
                val t = bodyEdit.text?.toString()?.trim().orEmpty()
                if (!t.startsWith("{")) bodyEdit.setText("{\n  \"data\": \"$t\"\n}")
            }
        })
        root.addView(modRow)

        val statusTv = TextView(ctx).apply {
            text = api.status
            setTextColor(c)
            textSize = 12f
            setPadding(8, 8, 8, 4)
        }
        root.addView(statusTv)

        root.addView(label("Response (code · headers · body)"))
        val respBox = edit("—", multi = true).apply {
            isFocusable = false
            isClickable = false
            minLines = 8
            maxLines = 16
            setTextColor(0xFFE0E0E0.toInt())
        }
        root.addView(respBox)

        fun formatResp(a: DevHttpsApiTester): String {
            if (a.error.isNotEmpty()) return "ERROR\n${a.error}\n\n${a.responseBody}"
            return buildString {
                append("HTTP ").append(a.responseCode).append(" · ").append(a.responseMs).append("ms\n\n")
                append("--- headers ---\n").append(a.responseHeaders).append("\n\n")
                append("--- body ---\n").append(a.responseBody)
            }
        }
        fun statusRefresh() {
            statusTv.text = api.status + " · method=" + api.method
        }

        root.addView(Button(ctx).apply {
            text = "Send HTTPS request"
            setOnClickListener {
                api.lastUrl = urlEdit.text?.toString()?.trim().orEmpty().ifEmpty { api.lastUrl }
                if (!api.lastUrl.startsWith("http")) api.lastUrl = "https://${api.lastUrl}"
                api.requestHeaders = hdrEdit.text?.toString().orEmpty()
                api.requestBody = bodyEdit.text?.toString().orEmpty()
                api.send {
                    statusRefresh()
                    respBox.setText(formatResp(api))
                }
            }
        })
        root.addView(Button(ctx).apply {
            text = "Clear response"
            setOnClickListener {
                api.clearResponse()
                statusRefresh()
                respBox.setText("")
            }
        })

        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                statusRefresh()
                h.postDelayed(this, 400)
            }
        })
    }
}
