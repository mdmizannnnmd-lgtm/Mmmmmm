package com.mizan

/**
 * Fully complete human model — all 84 channels with atomspare INSIDE + OUTSIDE,
 * motion control, intensity / visual / colour thresholds, Pose · Segment · OBB.
 * No single-part-only mode: full human always. RAW COMPLETE.
 */
class Body84FullHumanBoard {

    companion object {
        val CHANNELS = listOf(
            "Thumb","Middle","Ring","Little","Proximal","Intermediate","Distal",
            "1 Stretched","2 Stretched","3 Stretched",
            "Hips","LeftUpperLeg","RightUpperLeg","LeftLowerLeg","RightLowerLeg",
            "LeftFoot","RightFoot","Spine","UpperChest","Neck","Head",
            "LeftShoulder","RightShoulder","LeftUpperArm","RightUpperArm",
            "LeftLowerArm","RightLowerArm","LeftToes","RightToes","LeftEye","RightEye","Jaw",
            "Spine Front-Back","Spine Left-Right","Spine Twist Left-Right",
            "UpperChest Front-Back","UpperChest Left-Right","UpperChest Twist Left-Right",
            "Neck Nod Down-Up","Neck Tilt Left-Right","Neck Turn Left-Right",
            "Head Nod Down-Up","Head Tilt Left-Right","Head Turn Left-Right",
            "Left Eye Down-Up","Left Eye In-Out","Right Eye Down-Up","Right Eye In-Out",
            "Jaw Close","Jaw Left-Right",
            "Left Upper Leg Front-Back","Left Upper Leg In-Out","Left Upper Leg Twist In-Out",
            "Left Lower Leg Stretch","Left Lower Leg Twist In-Out",
            "Left Foot Up-Down","Left Foot Twist In-Out","Left Toes Up-Down",
            "Right Upper Leg Front-Back","Right Upper Leg In-Out","Right Upper Leg Twist In-Out",
            "Right Lower Leg Stretch","Right Lower Leg Twist In-Out",
            "Right Foot Up-Down","Right Foot Twist In-Out","Right Toes Up-Down",
            "Left Shoulder Down-Up","Left Shoulder Front-Back",
            "Left Arm Down-Up","Left Arm Front-Back","Left Arm Twist In-Out",
            "Left Forearm Stretch","Left Forearm Twist In-Out","Left Hand Down-Up","Left Hand In-Out",
            "Right Shoulder Down-Up","Right Shoulder Front-Back",
            "Right Arm Down-Up","Right Arm Front-Back","Right Arm Twist In-Out",
            "Right Forearm Stretch","Right Forearm Twist In-Out","Right Hand Down-Up","Right Hand In-Out"
        )
        const val COUNT = 84
    }

    data class Ch(
        val name: String,
        @Volatile var on: Boolean = true,
        @Volatile var outside: Float = 0f,
        @Volatile var inside: Float = 0f,
        @Volatile var atom: Float = 0f,
        @Volatile var move: Float = 0f,
        @Volatile var speed: Float = 0f,
        @Volatile var wave: Float = 0f
    )

    val channels: Array<Ch> = CHANNELS.map { Ch(it) }.toTypedArray()

    @Volatile var enabled = true
    @Volatile var rawComplete = true  // fully complete human by default
    @Volatile var fullHumanOnly = true // never single-part mode
    /** Outside↔inside interconnect (not isolated singles) */
    @Volatile var interconnectOn = true
    @Volatile var interconnectLv = 0.88f
    @Volatile var objectTrackOn = true
    @Volatile var objectOut = 0f
    @Volatile var screen3dOn = true

    // Global atomspare inside/outside
    @Volatile var outsideOn = true
    @Volatile var insideOn = true
    @Volatile var atomThr = 0.28f
    @Volatile var atomLv = 0.80f
    @Volatile var atomIntensity = 0.85f
    @Volatile var outsideOut = 0f
    @Volatile var insideOut = 0f
    @Volatile var atomOut = 0f

    // Motion control
    @Volatile var motionOn = true
    @Volatile var moveThr = 0.30f
    @Volatile var moveLv = 0.70f
    @Volatile var speedThr = 0.30f
    @Volatile var speedLv = 0.70f
    @Volatile var waveThr = 0.30f
    @Volatile var waveLv = 0.70f
    @Volatile var moveOut = 0f
    @Volatile var speedOut = 0f
    @Volatile var waveOut = 0f

    // Visual / colour thresholds
    @Volatile var visualThr = 0.30f
    @Volatile var visualLv = 0.70f
    @Volatile var visualOut = 0f
    @Volatile var colourThr = 0.30f
    @Volatile var colourLv = 0.70f
    @Volatile var colourOut = 0f
    @Volatile var bright = 0.70f
    @Volatile var contrast = 0.70f

    // Pose / Segment / OBB full model mixers
    @Volatile var poseOn = true
    @Volatile var segmentOn = true
    @Volatile var obbOn = true
    @Volatile var poseOut = 0f
    @Volatile var segmentOut = 0f
    @Volatile var obbOut = 0f
    @Volatile var modelMixOut = 0f

    @Volatile var status = "84 FULL HUMAN idle"

    private fun lane(thr: Float, lv: Float, e: Float, drive: Float): Float {
        if (rawComplete) return (e * lv * drive).coerceIn(0f, 1f)
        val t = (thr * drive).coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv * drive).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, modelDrive: Float = 1f) {
        if (!enabled) {
            status = "84 FULL HUMAN OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val drive = 0.25f + 0.75f * modelDrive.coerceIn(0f, 1f)

        atomOut = lane(atomThr, atomLv * atomIntensity, e, drive)
        outsideOut = if (outsideOn) atomOut * 0.95f else 0f
        insideOut = if (insideOn) atomOut * 0.90f else 0f

        moveOut = if (motionOn) lane(moveThr, moveLv, e, drive) else 0f
        speedOut = if (motionOn) lane(speedThr, speedLv, e * 1.02f, drive) else 0f
        waveOut = if (motionOn) lane(waveThr, waveLv, e * 0.98f, drive) else 0f

        visualOut = lane(visualThr, visualLv, e, drive)
        colourOut = lane(colourThr, colourLv, e, drive)

        poseOut = if (poseOn) (e * drive * 0.92f).coerceIn(0f, 1f) else 0f
        segmentOut = if (segmentOn) (e * drive * 0.90f).coerceIn(0f, 1f) else 0f
        obbOut = if (obbOn) (e * drive * 0.88f).coerceIn(0f, 1f) else 0f
        modelMixOut = maxOf(poseOut, segmentOut, obbOut)

        // Drive ALL 84 channels — full human, no single
        val base = maxOf(outsideOut, insideOut, atomOut, modelMixOut)
        for (i in channels.indices) {
            val c = channels[i]
            if (!c.on && fullHumanOnly) c.on = true
            // slight regional weighting by index bands
            val w = when {
                i < 10 -> 0.85f   // fingers
                i < 32 -> 1.0f    // major bones
                i < 50 -> 0.95f   // spine/neck/head/eyes
                else -> 0.92f     // limbs DOF
            }
            var outV = outsideOut * w
            var inV = insideOut * w
            if (interconnectOn) {
                val k = interconnectLv.coerceIn(0.1f, 1f)
                // outside↔inside linked per channel — not single isolated
                inV = maxOf(inV, outV * k)
                outV = maxOf(outV, inV * k * 0.9f)
            }
            c.outside = outV.coerceIn(0f, 1f)
            c.inside = inV.coerceIn(0f, 1f)
            c.atom = maxOf(base * w, c.outside, c.inside)
            c.move = moveOut * w
            c.speed = speedOut * w
            c.wave = waveOut * w
        }
        if (interconnectOn) {
            val k = interconnectLv.coerceIn(0.1f, 1f)
            outsideOut = maxOf(outsideOut, insideOut * k * 0.9f)
            insideOut = maxOf(insideOut, outsideOut * k)
            atomOut = maxOf(atomOut, outsideOut, insideOut)
        }
        objectOut = if (objectTrackOn) maxOf(poseOut, segmentOut, obbOut, atomOut) else 0f


        val active = channels.count { it.on }
        status =
            "FULL HUMAN $active/84 · out=${(outsideOut*100).toInt()}% in=${(insideOut*100).toInt()}% atom=${(atomOut*100).toInt()}% · " +
            "mov=${(moveOut*100).toInt()} spd=${(speedOut*100).toInt()} wav=${(waveOut*100).toInt()} · " +
            "vis=${(visualOut*100).toInt()} col=${(colourOut*100).toInt()} · " +
            "POSE=${(poseOut*100).toInt()} SEG=${(segmentOut*100).toInt()} OBB=${(obbOut*100).toInt()} · " +
            "IC=${(interconnectLv*100).toInt()}% OBJ=${(objectOut*100).toInt()}% 3D=${if (screen3dOn) "ON" else "off"}" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(b84: Body84Channels?, skin: SkinAtomspare3dBoard?, shell: BodyAnatomyShellBoard?) {
        if (!enabled) return
        // Sync atmosphere onto existing Body84Channels if present
        b84?.let { bank ->
            try {
                val chs = bank.javaClass.getDeclaredField("channels").also { it.isAccessible = true }.get(bank)
                // best-effort: bulk ambient/atmosphere via reflection-free public API if any
            } catch (_: Throwable) {}
        }
        skin?.let { s ->
            if (s.enabled) {
                s.skinOutsideOut = maxOf(s.skinOutsideOut, outsideOut)
                s.skinInsideOut = maxOf(s.skinInsideOut, insideOut)
                s.atomSpareOut = maxOf(s.atomSpareOut, atomOut)
            }
        }
        shell?.let { sh ->
            if (sh.enabled) {
                sh.outsideShellOut = maxOf(sh.outsideShellOut, outsideOut)
                sh.insideSystemsOut = maxOf(sh.insideSystemsOut, insideOut)
                sh.atomSpareShellOut = maxOf(sh.atomSpareShellOut, atomOut)
            }
        }
    }

    /** Drive 3D screen anatomy + interconnect full human (inside+outside). */
    fun applyToView(v: VisualShieldView) {
        if (!enabled || !screen3dOn) return
        enableFullHuman()
        try {
            val a = v.anatomy3d
            a.enabled = true
            a.enableCompleteHumanLayers()
            a.atmosphere = maxOf(a.atmosphere, atomOut, objectOut)
            try {
                a.outside.level = maxOf(a.outside.level, outsideOut)
                a.inside.level = maxOf(a.inside.level, insideOut)
            } catch (_: Throwable) {}
            for (i in a.layerOn.indices) {
                a.layerOn[i] = true
                a.layerLevel[i] = maxOf(a.layerLevel[i], 0.75f + atomOut * 0.2f)
            }
            a.poseRigOn = true
            a.gpuOn = true
        } catch (_: Throwable) {}
        try {
            v.fullBodyAnatomy.enabled = true
            v.fullBodyAnatomy.outsideOn = true
            v.fullBodyAnatomy.insideOn = true
            v.fullBodyAnatomy.outsideFull = maxOf(v.fullBodyAnatomy.outsideFull, outsideOut)
            v.fullBodyAnatomy.insideFull = maxOf(v.fullBodyAnatomy.insideFull, insideOut)
            v.fullBodyAnatomy.bodyWholeOut = maxOf(v.fullBodyAnatomy.bodyWholeOut, atomOut)
        } catch (_: Throwable) {}
        try {
            v.completeAtomProtect.atomOutsideOut = maxOf(v.completeAtomProtect.atomOutsideOut, outsideOut)
            v.completeAtomProtect.atomInsideOut = maxOf(v.completeAtomProtect.atomInsideOut, insideOut)
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, atomOut)
        } catch (_: Throwable) {}
        try {
            v.skinAtomspare.skinOutsideOut = maxOf(v.skinAtomspare.skinOutsideOut, outsideOut)
            v.skinAtomspare.skinInsideOut = maxOf(v.skinAtomspare.skinInsideOut, insideOut)
        } catch (_: Throwable) {}
        try {
            v.anatomyShell.outsideShellOut = maxOf(v.anatomyShell.outsideShellOut, outsideOut)
            v.anatomyShell.insideSystemsOut = maxOf(v.anatomyShell.insideSystemsOut, insideOut)
        } catch (_: Throwable) {}
        // Map major channels to surface regions for on-screen 3D
        try {
            val ch = channels
            fun a(i: Int) = if (i in ch.indices) maxOf(ch[i].outside, ch[i].inside) else 0f
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, a(20), a(41), a(42), a(43))
            v.neck.atmosphere = maxOf(v.neck.atmosphere, a(19), a(38), a(39), a(40))
            v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, a(18), a(35), a(36), a(37))
            v.eyeL.atmosphere = maxOf(v.eyeL.atmosphere, a(29), a(44), a(45))
            v.eyeR.atmosphere = maxOf(v.eyeR.atmosphere, a(30), a(46), a(47))
            v.handL.atmosphere = maxOf(v.handL.atmosphere, a(73), a(74), a(0), a(1))
            v.handR.atmosphere = maxOf(v.handR.atmosphere, a(82), a(83), a(2), a(3))
            v.skinLegL.atmosphere = maxOf(v.skinLegL.atmosphere, a(11), a(13), a(50), a(53))
            v.skinLegR.atmosphere = maxOf(v.skinLegR.atmosphere, a(12), a(14), a(58), a(61))
            v.skinFootL.atmosphere = maxOf(v.skinFootL.atmosphere, a(15), a(27), a(55), a(57))
            v.skinFootR.atmosphere = maxOf(v.skinFootR.atmosphere, a(16), a(28), a(63), a(65))
            v.skinArmL.atmosphere = maxOf(v.skinArmL.atmosphere, a(23), a(25), a(68), a(71))
            v.skinArmR.atmosphere = maxOf(v.skinArmR.atmosphere, a(24), a(26), a(77), a(80))
            v.face.atmosphere = maxOf(v.face.atmosphere, a(31), a(48), a(49))
        } catch (_: Throwable) {}
    }

    /** Bulk enable every channel — fully complete human. */
    fun enableFullHuman() {
        fullHumanOnly = true
        rawComplete = true
        outsideOn = true
        insideOn = true
        motionOn = true
        poseOn = true
        segmentOn = true
        obbOn = true
        channels.forEach { it.on = true }
    }
}
