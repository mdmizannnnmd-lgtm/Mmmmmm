package com.mizan

/**
 * Echo threshold + echo decay on the local audio intensity path.
 * When energy crosses threshold, echo holds then decays over decayMs.
 */
class EchoEngine {
    @Volatile var enabled = true
    @Volatile var threshold = 0.40f
    @Volatile var decayMs = 300
    @Volatile var feedback = 0.55f
    /** 0=none … 6=metal plate — stretches decay */
    @Volatile var reverbPreset = 0

    @Volatile var liveIn = 0f
    @Volatile var echoLevel = 0f
    @Volatile var firing = false
    @Volatile var fireCount = 0

    private var echoEnv = 0f
    private var lastTs = System.currentTimeMillis()

    fun tick(energy: Float) {
        val now = System.currentTimeMillis()
        val dt = (now - lastTs).coerceIn(1L, 100L)
        lastTs = now
        liveIn = energy.coerceIn(0f, 1f)
        if (!enabled) {
            echoEnv = 0f
            echoLevel = 0f
            firing = false
            return
        }
        if (liveIn >= threshold) {
            // hit: charge echo
            echoEnv = maxOf(echoEnv, liveIn * feedback + (1f - feedback) * echoEnv)
            if (!firing) fireCount++
            firing = true
        } else {
            firing = false
        }
        // exponential decay toward 0 over decayMs
        val presetBoost = when (reverbPreset.coerceIn(0, 6)) {
            0 -> 1f; 1 -> 1.2f; 2 -> 1.5f; 3 -> 2.0f; 4 -> 2.5f; 5 -> 3.2f; else -> 2.8f
        }
        val tau = (decayMs.coerceIn(20, 5000).toFloat() * presetBoost).coerceIn(20f, 8000f)
        val factor = kotlin.math.exp(-dt.toFloat() / tau)
        echoEnv *= factor
        if (echoEnv < 0.01f) echoEnv = 0f
        echoLevel = echoEnv.coerceIn(0f, 1f)
    }

    fun statusLine(): String {
        val st = if (firing) "ECHO-FIRE" else if (echoLevel > 0.02f) "ECHO-DECAY" else "echo-idle"
        return "ECHO in=${(liveIn*100).toInt()}% lv=${(echoLevel*100).toInt()}% thr=${(threshold*100).toInt()}% decay=${decayMs}ms · $st · #=$fireCount"
    }
}
