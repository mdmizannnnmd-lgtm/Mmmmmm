package com.mizan

import kotlin.math.abs

/** Additive v8 perception fusion. Consumes existing camera/mic signals; does not own sensors. */
class UnifiedPerceptionEngine(
    private val staleAfterMs: Long = 1200L,
    private val smoothing: Float = 0.18f
) {
    data class Snapshot(
        val timestampMs: Long = 0L,
        val cameraFresh: Boolean = false,
        val personPresent: Boolean = false,
        val cameraConfidence: Float = 0f,
        val centerX: Float = 0.5f,
        val centerY: Float = 0.5f,
        val audioActive: Boolean = false,
        val audioLevel: Float = 0f,
        val dominantHz: Float = 0f,
        val attention: Float = 0f,
        val activity: Float = 0f
    )

    @Volatile private var latestCamera: HumanDetection? = null
    @Volatile private var latestMic: MicSignalEvent? = null
    @Volatile private var snapshot = Snapshot()

    fun onCamera(detection: HumanDetection) { latestCamera = detection }
    fun onMicrophone(event: MicSignalEvent) { latestMic = event }
    fun current(): Snapshot = snapshot

    @Synchronized fun tick(nowMs: Long = System.currentTimeMillis()): Snapshot {
        val cam = latestCamera
        val mic = latestMic
        val cameraFresh = cam != null && cam.modelReady && cam.isFresh(nowMs) &&
            nowMs - cam.timestampMs <= staleAfterMs && cam.centerX.isFinite() && cam.centerY.isFinite()
        val audioFresh = mic != null && nowMs - mic.timestampMs in 0..staleAfterMs
        val person = cameraFresh && cam!!.hasPerson && cam.confidence >= 0.35f
        val confidence = if (person) cam!!.confidence.coerceIn(0f, 1f) else 0f
        val x = if (person) cam!!.centerX.coerceIn(0f, 1f) else 0.5f
        val y = if (person) cam!!.centerY.coerceIn(0f, 1f) else 0.5f
        val level = if (audioFresh) mic!!.level.coerceIn(0f, 1f) else 0f
        val active = audioFresh && mic!!.type == MicSignalEvent.Type.ACTIVE
        val prev = snapshot
        val a = smoothing.coerceIn(0.01f, 1f)
        snapshot = Snapshot(nowMs, cameraFresh == true, person, confidence,
            prev.centerX + (x - prev.centerX) * a,
            prev.centerY + (y - prev.centerY) * a,
            active, prev.audioLevel + (level - prev.audioLevel) * a,
            if (audioFresh) mic!!.dominantHz.coerceAtLeast(0f) else 0f,
            (confidence * 0.75f + level * 0.25f).coerceIn(0f, 1f),
            (level * 0.65f + if (person) confidence * 0.35f else 0f).coerceIn(0f, 1f))
        return snapshot
    }

    @Synchronized fun reset() { latestCamera = null; latestMic = null; snapshot = Snapshot() }
}
