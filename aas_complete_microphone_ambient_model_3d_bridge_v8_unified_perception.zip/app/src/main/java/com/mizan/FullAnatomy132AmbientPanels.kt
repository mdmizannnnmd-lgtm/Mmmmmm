package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object FullAnatomy132AmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: FullAnatomy132AmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF80CBC4.toInt()
        p.title("FULL ANATOMY AMBIENT · 11 SYSTEMS · ~132 STRUCTURES", c)
        p.note("GAP SCAN COMPLETE · 11 systems · resp+intercostals · CV+vessels · GI+GB · skull/femur/osteo · live engine. Symbolic.")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.seek("Thr", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Level", 0f, 1.5f, b.levelAmt) { b.levelAmt = it }
        p.switch("Brain (full)", b.brainOn) { b.brainOn = it }
        p.switch("Eyes", b.eyesOn) { b.eyesOn = it }
        p.switch("Ear", b.earOn) { b.earOn = it }
        p.switch("Face/nose/mouth/teeth/tongue/skin", b.faceOn) { b.faceOn = it }
        p.switch("Neck", b.neckOn) { b.neckOn = it }
        p.switch("Heart / CV", b.heartOn) { b.heartOn = it; b.cardioOn = it }
        p.switch("Glands / endocrine", b.glandsOn) { b.glandsOn = it; b.endoOn = it }
        p.switch("Body parts", b.bodyPartsOn) { b.bodyPartsOn = it }
        p.switch("Respiratory (12)", b.respOn) { b.respOn = it }
        p.switch("Cardiovascular (22)", b.cardioOn) { b.cardioOn = it }
        p.switch("Digestive (15)", b.digestOn) { b.digestOn = it }
        p.switch("Urinary (4)", b.urinaryOn) { b.urinaryOn = it }
        p.switch("Lymphatic/immune (5)", b.lymphOn) { b.lymphOn = it }
        p.switch("Skeletal (25)", b.skeletalOn) { b.skeletalOn = it }
        p.switch("Muscular (18)", b.muscleOn) { b.muscleOn = it }
        p.switch("Joints/connective (11)", b.jointOn) { b.jointOn = it }
        p.switch("Peripheral nervous (10)", b.pnsOn) { b.pnsOn = it }
        p.switch("Reproductive (3)", b.reproOn) { b.reproOn = it }
        val st = p.status("ANAT132 —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 220) }
        })
    }
}
