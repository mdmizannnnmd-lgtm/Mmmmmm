package com.mizan

/**
 * Sound detection + body region tracking.
 * Classifies live mic / enemy energy to head·eyes·torso·arms·legs·inside · tracks peaks.
 * RAW COMPLETE.
 */
class SoundDetectBodyRegionTrackBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    @Volatile var detectOn = true
    @Volatile var detectThr = 0.18f
    @Volatile var detectLv = 0.90f

    @Volatile var trackOn = true

    // Detected class scores
    @Volatile var detBurst = 0f
    @Volatile var detBullet = 0f
    @Volatile var detKnife = 0f
    @Volatile var detSharp = 0f
    @Volatile var detEcho = 0f
    @Volatile var detAny = 0f
    @Volatile var detLiveMic = 0f

    // Body region tracking (0..1 presence)
    @Volatile var trackHead = 0f
    @Volatile var trackEyes = 0f
    @Volatile var trackTorso = 0f
    @Volatile var trackArmL = 0f
    @Volatile var trackArmR = 0f
    @Volatile var trackLegL = 0f
    @Volatile var trackLegR = 0f
    @Volatile var trackInside = 0f
    @Volatile var trackFull = 0f

    // Peak hold
    @Volatile var peakRegion = "none"
    @Volatile var peakLevel = 0f

    @Volatile var status = "DETECT·TRACK idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        mic: Float,
        burst: Float,
        bullet: Float,
        knife: Float,
        sharp: Float,
        echo: Float,
        enemy: Float
    ) {
        if (!enabled) {
            status = "DETECT·TRACK OFF"
            return
        }
        detLiveMic = mic.coerceIn(0f, 1f)
        detBurst = lane(detectOn, detectThr, detectLv, burst)
        detBullet = lane(detectOn, detectThr, detectLv, bullet)
        detKnife = lane(detectOn, detectThr, detectLv, knife)
        detSharp = lane(detectOn, detectThr, detectLv, sharp)
        detEcho = lane(detectOn, detectThr, detectLv, echo)
        detAny = maxOf(detBurst, detBullet, detKnife, detSharp, detEcho, lane(detectOn, detectThr, detectLv, enemy), detLiveMic * 0.5f)

        if (trackOn || rawComplete) {
            val base = maxOf(detAny, enemy.coerceIn(0f, 1f), detLiveMic * 0.6f)
            // Soft distribution — symbolic region mapping from energy bands
            trackHead = base * (0.85f + 0.15f * detSharp)
            trackEyes = base * (0.80f + 0.2f * detKnife)
            trackTorso = base * (0.90f + 0.1f * detBurst)
            trackArmL = base * 0.88f
            trackArmR = base * 0.88f
            trackLegL = base * 0.86f
            trackLegR = base * 0.86f
            trackInside = base * (0.92f + 0.08f * detBullet)
            trackFull = maxOf(trackHead, trackEyes, trackTorso, trackArmL, trackArmR, trackLegL, trackLegR, trackInside)
            val pairs = listOf(
                "head" to trackHead, "eyes" to trackEyes, "torso" to trackTorso,
                "armL" to trackArmL, "armR" to trackArmR, "legL" to trackLegL,
                "legR" to trackLegR, "inside" to trackInside
            )
            val top = pairs.maxByOrNull { it.second }
            if (top != null && top.second > peakLevel * 0.85f) {
                peakRegion = top.first
                peakLevel = maxOf(peakLevel * 0.92f, top.second)
            } else {
                peakLevel *= 0.98f
            }
        }

        status =
            "DET B/Bu/K/Sh/Ec=${(detBurst*100).toInt()}/${(detBullet*100).toInt()}/${(detKnife*100).toInt()}/${(detSharp*100).toInt()}/${(detEcho*100).toInt()} · " +
            "TRACK H/E/T=${(trackHead*100).toInt()}/${(trackEyes*100).toInt()}/${(trackTorso*100).toInt()} · " +
            "IN=${(trackInside*100).toInt()}% FULL=${(trackFull*100).toInt()}% PEAK=$peakRegion" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        try {
            v.enemySoundCounters.burstDet = maxOf(v.enemySoundCounters.burstDet, detBurst)
            v.enemySoundCounters.bulletDet = maxOf(v.enemySoundCounters.bulletDet, detBullet)
            v.enemySoundCounters.knifeDet = maxOf(v.enemySoundCounters.knifeDet, detKnife)
            v.enemySoundCounters.sharpDet = maxOf(v.enemySoundCounters.sharpDet, detSharp)
            v.enemySoundCounters.echoDet = maxOf(v.enemySoundCounters.echoDet, detEcho)
        } catch (_: Throwable) {}
        try {
            val br = v.bodyRegionEnemyProtect
            br.headProt = maxOf(br.headProt, trackHead * 0.5f)
            br.eyesProt = maxOf(br.eyesProt, trackEyes * 0.5f)
            br.torsoProt = maxOf(br.torsoProt, trackTorso * 0.5f)
            br.armLProt = maxOf(br.armLProt, trackArmL * 0.5f)
            br.armRProt = maxOf(br.armRProt, trackArmR * 0.5f)
            br.legLProt = maxOf(br.legLProt, trackLegL * 0.5f)
            br.legRProt = maxOf(br.legRProt, trackLegR * 0.5f)
            br.insideCore = maxOf(br.insideCore, trackInside * 0.5f)
        } catch (_: Throwable) {}
        try {
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, trackHead * 0.25f)
            v.eyes.atmosphere = maxOf(v.eyes.atmosphere, trackEyes * 0.25f)
            v.skinChest.atmosphere = maxOf(v.skinChest.atmosphere, trackTorso * 0.25f)
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, trackFull * 0.2f)
        } catch (_: Throwable) {}
    }
}
