package com.mizan

/**
 * Counters board — burst · bullet · knife · sharpness · detected same-sounds ·
 * body-region enemy counts · mic-driven · anti bullet/burst inside · anti echo · live mic.
 * RAW COMPLETE.
 */
class EnemySoundCountersBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    @Volatile var countersOn = true
    @Volatile var detectThr = 0.22f

    // Event counters (lifetime session)
    @Volatile var burstCount = 0
    @Volatile var bulletCount = 0
    @Volatile var knifeCount = 0
    @Volatile var sharpCount = 0
    @Volatile var sameSoundCount = 0
    @Volatile var bodyRegionHitCount = 0
    @Volatile var echoCount = 0
    @Volatile var arrowCount = 0
    // All bullet sound counters
    @Volatile var bulletNearCount = 0
    @Volatile var bulletFarCount = 0
    @Volatile var bulletRicochetCount = 0
    @Volatile var bulletImpactCount = 0
    @Volatile var bulletMultiCount = 0
    @Volatile var bulletAllCount = 0

    // Live detect levels
    @Volatile var burstDet = 0f
    @Volatile var bulletDet = 0f
    @Volatile var knifeDet = 0f
    @Volatile var sharpDet = 0f
    @Volatile var sameDet = 0f
    @Volatile var echoDet = 0f
    @Volatile var arrowDet = 0f
    @Volatile var bulletNearDet = 0f
    @Volatile var bulletFarDet = 0f
    @Volatile var bulletRicochetDet = 0f
    @Volatile var bulletImpactDet = 0f
    @Volatile var liveMic = 0f
    // Microphone axis X/Y/Z level + power (symbolic spatial mic)
    @Volatile var micAxisOn = true
    @Volatile var micAxisX = 0f
    @Volatile var micAxisY = 0f
    @Volatile var micAxisZ = 0f
    @Volatile var micPowerX = 0f
    @Volatile var micPowerY = 0f
    @Volatile var micPowerZ = 0f
    @Volatile var micAxisThr = 0.15f
    @Volatile var micAxisLv = 0.90f
    // Display outputs (0..1 for UI bars)
    @Volatile var burstDisplay = 0f
    @Volatile var whipDisplay = 0f
    @Volatile var arrowDisplay = 0f
    @Volatile var knifeDisplay = 0f
    @Volatile var bulletDisplay = 0f

    // Anti
    @Volatile var antiBulletOn = true
    @Volatile var antiBurstOn = true
    @Volatile var antiEchoOn = true
    @Volatile var antiThr = 0.18f
    @Volatile var antiLv = 0.95f
    @Volatile var antiBulletOut = 0f
    @Volatile var antiBurstOut = 0f
    @Volatile var antiEchoOut = 0f
    @Volatile var antiWhipOn = true
    @Volatile var antiArrowOn = true
    @Volatile var antiKnifeOn = true
    @Volatile var antiWhipOut = 0f
    @Volatile var antiArrowOut = 0f
    @Volatile var antiKnifeOut = 0f
    @Volatile var insideProtectOut = 0f

    private var prevBurst = 0f
    private var prevBullet = 0f
    private var prevKnife = 0f
    private var prevSharp = 0f
    private var prevEcho = 0f
    private var prevArrow = 0f
    private var prevBulletNear = 0f
    private var prevBulletFar = 0f
    private var prevBulletRic = 0f
    private var prevBulletImp = 0f
    private var prevSame = 0f

    @Volatile var status = "COUNTERS idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    private fun edgeCount(prev: Float, now: Float, thr: Float): Boolean =
        prev < thr && now >= thr

    fun tick(
        mic: Float,
        burst: Float,
        bullet: Float,
        knife: Float,
        sharp: Float,
        echo: Float,
        enemyBody: Float,
        arrow: Float = 0f,
        axisX: Float = 0.33f,
        axisY: Float = 0.33f,
        axisZ: Float = 0.34f
    ) {
        if (!enabled) {
            status = "COUNTERS OFF"
            return
        }
        liveMic = mic.coerceIn(0f, 1f)
        val ax = axisX.coerceIn(0f, 1f)
        val ay = axisY.coerceIn(0f, 1f)
        val az = axisZ.coerceIn(0f, 1f)
        val sum = (ax + ay + az).coerceAtLeast(0.01f)
        val nx = ax / sum; val ny = ay / sum; val nz = az / sum
        micAxisX = lane(micAxisOn, micAxisThr, micAxisLv, liveMic * nx)
        micAxisY = lane(micAxisOn, micAxisThr, micAxisLv, liveMic * ny)
        micAxisZ = lane(micAxisOn, micAxisThr, micAxisLv, liveMic * nz)
        micPowerX = (micAxisX * micAxisX * 1.2f).coerceIn(0f, 1f)
        micPowerY = (micAxisY * micAxisY * 1.2f).coerceIn(0f, 1f)
        micPowerZ = (micAxisZ * micAxisZ * 1.2f).coerceIn(0f, 1f)
        burstDet = burst.coerceIn(0f, 1f)
        bulletDet = bullet.coerceIn(0f, 1f)
        knifeDet = knife.coerceIn(0f, 1f)
        sharpDet = sharp.coerceIn(0f, 1f)
        echoDet = echo.coerceIn(0f, 1f)
        arrowDet = arrow.coerceIn(0f, 1f)
        if (arrowDet < 0.01f) arrowDet = maxOf(sharpDet * 0.85f, knifeDet * 0.5f)
        arrowDisplay = maxOf(arrowDet, liveMic * micAxisZ)
        whipDisplay = maxOf(arrowDet * 0.95f, liveMic * maxOf(micAxisX, micAxisZ) * 0.9f)
        // Derive bullet variants from bullet + mic energy bands
        bulletNearDet = (bulletDet * 1.0f + liveMic * 0.2f).coerceIn(0f, 1f)
        bulletFarDet = (bulletDet * 0.7f + liveMic * 0.15f).coerceIn(0f, 1f)
        bulletRicochetDet = (bulletDet * 0.6f + sharpDet * 0.4f).coerceIn(0f, 1f)
        bulletImpactDet = (bulletDet * 0.85f + burstDet * 0.3f).coerceIn(0f, 1f)
        sameDet = maxOf(burstDet, bulletDet, knifeDet, sharpDet, liveMic * 0.5f)
        val axisBoost = maxOf(micAxisX, micAxisY, micAxisZ)
        burstDisplay = maxOf(burstDet, liveMic * micAxisX)
        knifeDisplay = maxOf(knifeDet, liveMic * micAxisY)
        bulletDisplay = bulletDet
        // Z emphasizes whip/arrow spatial
        val thr = detectThr

        if (countersOn) {
            if (edgeCount(prevBurst, burstDet, thr)) burstCount++
            if (edgeCount(prevBullet, bulletDet, thr)) bulletCount++
            if (edgeCount(prevKnife, knifeDet, thr)) knifeCount++
            if (edgeCount(prevSharp, sharpDet, thr)) sharpCount++
            if (edgeCount(prevEcho, echoDet, thr)) echoCount++
            if (edgeCount(prevArrow, arrowDet, thr)) arrowCount++
            if (edgeCount(prevBulletNear, bulletNearDet, thr)) bulletNearCount++
            if (edgeCount(prevBulletFar, bulletFarDet, thr * 0.9f)) bulletFarCount++
            if (edgeCount(prevBulletRic, bulletRicochetDet, thr)) bulletRicochetCount++
            if (edgeCount(prevBulletImp, bulletImpactDet, thr)) bulletImpactCount++
            if (edgeCount(prevBullet, bulletDet, thr * 0.7f) && burstDet > thr * 0.5f) bulletMultiCount++
            bulletAllCount = bulletCount + bulletNearCount + bulletFarCount + bulletRicochetCount + bulletImpactCount + bulletMultiCount
            if (edgeCount(prevSame, sameDet, thr)) sameSoundCount++
            if (edgeCount(0f, maxOf(enemyBody, sameDet), thr) && enemyBody > thr * 0.8f)
                bodyRegionHitCount++
        }
        prevBurst = burstDet
        prevBullet = bulletDet
        prevKnife = knifeDet
        prevSharp = sharpDet
        prevEcho = echoDet
        prevArrow = arrowDet
        prevBulletNear = bulletNearDet
        prevBulletFar = bulletFarDet
        prevBulletRic = bulletRicochetDet
        prevBulletImp = bulletImpactDet
        prevSame = sameDet

        antiBulletOut = lane(antiBulletOn, antiThr, antiLv, maxOf(bulletDet, liveMic * 0.4f))
        antiBurstOut = lane(antiBurstOn, antiThr, antiLv, maxOf(burstDet, liveMic * 0.4f, micPowerX * 0.5f))
        antiEchoOut = lane(antiEchoOn, antiThr, antiLv, maxOf(echoDet, liveMic * 0.35f))
        antiWhipOut = lane(antiWhipOn, antiThr, antiLv, maxOf(arrowDet * 0.9f, liveMic * 0.3f, micPowerZ * 0.5f))
        antiArrowOut = lane(antiArrowOn, antiThr, antiLv, maxOf(arrowDet, micPowerZ * 0.55f))
        antiKnifeOut = lane(antiKnifeOn, antiThr, antiLv, maxOf(knifeDet, micPowerY * 0.5f))
        whipDisplay = maxOf(whipDisplay, arrowDet * 0.95f, antiWhipOut * 0.2f)
        insideProtectOut = maxOf(antiBulletOut, antiBurstOut, antiEchoOut, antiWhipOut, antiArrowOut, antiKnifeOut)

        status =
            "CNT B/Bu/K/Sh/Ar=${burstCount}/${bulletCount}/${knifeCount}/${sharpCount}/${arrowCount} · " +
            "BULLET all/near/far/ric/imp/multi=${bulletAllCount}/${bulletNearCount}/${bulletFarCount}/${bulletRicochetCount}/${bulletImpactCount}/${bulletMultiCount} · " +
            "SAME=${sameSoundCount} BODY=${bodyRegionHitCount} ECHO=${echoCount} · " +
            "DET B/Bu/K=${(burstDet*100).toInt()}/${(bulletDet*100).toInt()}/${(knifeDet*100).toInt()} · " +
            "DISP Br/Wh/Ar/K=${(burstDisplay*100).toInt()}/${(whipDisplay*100).toInt()}/${(arrowDisplay*100).toInt()}/${(knifeDisplay*100).toInt()} · " +
            "ANTI Bu/Br/Ec/Wh/Ar/K=${(antiBulletOut*100).toInt()}/${(antiBurstOut*100).toInt()}/${(antiEchoOut*100).toInt()}/${(antiWhipOut*100).toInt()}/${(antiArrowOut*100).toInt()}/${(antiKnifeOut*100).toInt()} · " +
            "MIC=${(liveMic*100).toInt()}% XYZ=${(micAxisX*100).toInt()}/${(micAxisY*100).toInt()}/${(micAxisZ*100).toInt()} " +
            "PWR=${(micPowerX*100).toInt()}/${(micPowerY*100).toInt()}/${(micPowerZ*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun resetCounts() {
        burstCount = 0; bulletCount = 0; knifeCount = 0; sharpCount = 0
        sameSoundCount = 0; bodyRegionHitCount = 0; echoCount = 0; arrowCount = 0
        bulletNearCount = 0; bulletFarCount = 0; bulletRicochetCount = 0
        bulletImpactCount = 0; bulletMultiCount = 0; bulletAllCount = 0
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled) return
        if (antiBulletOut > 0.02f) {
            sb.bulletOut *= (1f - antiBulletOut * 0.96f).coerceIn(0.02f, 1f)
        }
        if (antiBurstOut > 0.02f) {
            sb.burstOut *= (1f - antiBurstOut * 0.96f).coerceIn(0.02f, 1f)
        }
        if (antiEchoOut > 0.02f) {
            sb.rippleOut *= (1f - antiEchoOut * 0.95f).coerceIn(0.02f, 1f)
            sb.collideOut *= (1f - antiEchoOut * 0.9f).coerceIn(0.05f, 1f)
        }
        if (antiWhipOut > 0.02f) sb.whipOut *= (1f - antiWhipOut * 0.96f).coerceIn(0.02f, 1f)
        if (antiArrowOut > 0.02f) {
            sb.whipOut *= (1f - antiArrowOut * 0.9f).coerceIn(0.02f, 1f)
            sb.sharpOut *= (1f - antiArrowOut * 0.85f).coerceIn(0.05f, 1f)
        }
        if (antiKnifeOut > 0.02f) sb.knifeOut *= (1f - antiKnifeOut * 0.96f).coerceIn(0.02f, 1f)

        if (arrowDet > detectThr) {
            sb.whipOut *= (1f - arrowDet * 0.5f).coerceIn(0.1f, 1f)
            sb.sharpOut *= (1f - arrowDet * 0.4f).coerceIn(0.1f, 1f)
        }
        if (insideProtectOut > 0.02f) {
            val k = (1f - insideProtectOut * 0.9f).coerceIn(0.05f, 1f)
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
        }
        val vv = v ?: return
        try {
            vv.sharpBurstMeter.antiBulletOut = maxOf(vv.sharpBurstMeter.antiBulletOut, antiBulletOut)
            vv.sharpBurstMeter.antiKnifeOut = maxOf(vv.sharpBurstMeter.antiKnifeOut, knifeDet * antiBulletOut)
            vv.bodyRegionEnemyProtect.boomProt = maxOf(vv.bodyRegionEnemyProtect.boomProt, antiBulletOut)
            vv.bodyRegionEnemyProtect.burstProt = maxOf(vv.bodyRegionEnemyProtect.burstProt, antiBurstOut)
            vv.bodyRegionEnemyProtect.knifeProt = maxOf(vv.bodyRegionEnemyProtect.knifeProt, antiKnifeOut)
            try {
                vv.sharpBurstMeter.antiKnifeOut = maxOf(vv.sharpBurstMeter.antiKnifeOut, antiKnifeOut)
            } catch (_: Throwable) {}
            vv.bodyRegionEnemyProtect.insideCore = maxOf(vv.bodyRegionEnemyProtect.insideCore, insideProtectOut)
            vv.antiAtomspareSounds.antiOut = maxOf(vv.antiAtomspareSounds.antiOut, antiEchoOut)
            vv.completeAtomProtect.atomInsideOut = maxOf(vv.completeAtomProtect.atomInsideOut, insideProtectOut)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, insideProtectOut)
        } catch (_: Throwable) {}
    }
}
