package com.mizan

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sin

class VisualShieldView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        const val MODE_UBR = 1
        init {
            try { System.loadLibrary("native-lib") } catch (_: Exception) {}
        }
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var active = true

    val armor = BodyArmorShield()
    var uiBlocker: UiIntensityBlocker? = null
    var systemGuard: SystemGuardEngine? = null
    @Volatile var echoLevel: Float = 0f
    var motionHub: MotionSensorHub? = null
    val attraction = AttractionMagicEngine()

    private var hardwareIntensity = 1f
    private var colorThreshold = 180
    private var lrFilter = 0.5f
    private var udFilter = 0.5f
    private var randomFilter = 0.5f
    private var centerFilter = 0.5f
    private var cornerFilter = 0.5f
    private var vibFreqFilter = 0.5f
    private var textureShift = 0.5f
    private var cameraFeedback = 0.5f

    data class Region(
        var ambient: Float = 0.55f,
        var rawComplete: Boolean = false,
        var wave: Float = 1f,
        var atmosphere: Float = 0.55f,
        var waveSpare: Float = 0.50f,
        var particles: Float = 0.50f,
        var atmoBipNeg: Float = 0f,
        var atmoBipPos: Float = 0f,
        var bipThrNeg: Float = 0f,
        var bipThrPos: Float = 0f,
        var move: Float = 0.50f,
        var moveThr: Float = 0.30f,
        var speed: Float = 0.50f,
        var speedThr: Float = 0.30f,
        var lrFilt: Float = 0.50f,
        var udFilt: Float = 0.50f,
        var randomFilt: Float = 0.50f,
        var centerFilt: Float = 0.50f,
        var cornerFilt: Float = 0.50f,
        var vibFilt: Float = 0.50f,
        var bipNegDb: Float = 0f,
        var bipPosDb: Float = 0f,
        var pigPong: Float = 0.50f,
        var pigPongThr: Float = 0.35f,
        var atmoSpikeProt: Float = 0.55f,
        var atmoSpikeProtThr: Float = 0.40f
    ) {
        fun effectiveAmbient(): Float {
            // RAW COMPLETE: pure ambient, no thr / bipolar soft mix
            if (rawComplete) return ambient.coerceIn(0f, 1f)
            val n = (bipNegDb.coerceIn(-120f, 0f) / 120f) * 0.35f
            val p = (bipPosDb.coerceIn(0f, 120f) / 120f) * 0.35f
            val atmo = atmosphere.coerceIn(0f, 1f) * 0.25f
            val abn = (atmoBipNeg.coerceIn(-300f, 0f) / 300f) * 0.20f
            val abp = (atmoBipPos.coerceIn(0f, 300f) / 300f) * 0.20f
            val btn = (bipThrNeg.coerceIn(-300f, 0f) / 300f) * 0.15f
            val btp = (bipThrPos.coerceIn(0f, 300f) / 300f) * 0.15f
            val part = particles.coerceIn(0f, 1f) * 0.12f
            val pp = if (pigPong >= pigPongThr) pigPong.coerceIn(0f, 1f) * 0.18f else 0f
            val asp = if (atmoSpikeProt >= atmoSpikeProtThr) atmoSpikeProt.coerceIn(0f, 1f) * 0.22f else 0f
            return (ambient + n + p + atmo + abn + abp + btn + btp + part + pp + asp).coerceIn(0f, 1f)
        }
        fun effectiveWave(): Float {
            val base = wave.coerceIn(0.05f, 4f)
            val spare = 0.5f + waveSpare.coerceIn(0f, 1f) * 0.75f
            return (base * spare).coerceIn(0.05f, 5f)
        }
        fun effectiveMoveThr(): Float {
            val n = (bipNegDb.coerceIn(-120f, 0f) / 120f) * 0.25f
            val p = (bipPosDb.coerceIn(0f, 120f) / 120f) * 0.25f
            return (moveThr + n + p).coerceIn(0.05f, 1f)
        }
        fun moveActive(): Boolean = move >= effectiveMoveThr()
        fun moveMag(): Float = if (moveActive()) move else move * 0.15f
        fun effectiveSpeedThr(): Float {
            val n = (bipNegDb.coerceIn(-120f, 0f) / 120f) * 0.20f
            val p = (bipPosDb.coerceIn(0f, 120f) / 120f) * 0.20f
            return (speedThr + n + p).coerceIn(0.05f, 1f)
        }
        fun speedActive(): Boolean = speed >= effectiveSpeedThr()
        fun speedMag(): Float = if (speedActive()) speed.coerceIn(0.05f, 1f) else speed * 0.20f

        fun copyFrom(o: Region) {
            ambient = o.ambient; wave = o.wave; atmosphere = o.atmosphere
            waveSpare = o.waveSpare; particles = o.particles
            atmoBipNeg = o.atmoBipNeg; atmoBipPos = o.atmoBipPos
            bipThrNeg = o.bipThrNeg; bipThrPos = o.bipThrPos
            move = o.move; moveThr = o.moveThr; speed = o.speed; speedThr = o.speedThr
            lrFilt = o.lrFilt; udFilt = o.udFilt; randomFilt = o.randomFilt
            centerFilt = o.centerFilt; cornerFilt = o.cornerFilt; vibFilt = o.vibFilt
            bipNegDb = o.bipNegDb; bipPosDb = o.bipPosDb
            pigPong = o.pigPong; pigPongThr = o.pigPongThr
            atmoSpikeProt = o.atmoSpikeProt; atmoSpikeProtThr = o.atmoSpikeProtThr
            rawComplete = o.rawComplete
        }
    }


    /**
     * Eye ring colour tuning: contrast, brightness, per-channel colour thresholds,
     * threshold options (mode / softness / invert) and master switches.
     */
    /** Shared body-region effects: spike, knife, ripple, whistle, level, protection. */
    class RegionEffects {
        @Volatile var enabled = true
        @Volatile var spikeOn = true
        @Volatile var spikeThr = 0.55f
        @Volatile var spikeLv = 0.55f
        @Volatile var knifeOn = true
        @Volatile var knifeThr = 0.45f
        @Volatile var knifeLv = 0.50f
        @Volatile var rippleOn = true
        @Volatile var rippleThr = 0.25f
        @Volatile var rippleLv = 0.45f
        @Volatile var whistleOn = true
        @Volatile var whistleThr = 0.50f
        @Volatile var whistleLv = 0.40f
        @Volatile var level = 0.70f
        @Volatile var protectOn = true
        @Volatile var protectThr = 0.40f
        @Volatile var protectLv = 0.65f
        @Volatile var anyEffectProtectOn = true
        @Volatile var anyEffectProtectThr = 0.35f
        @Volatile var anyEffectProtectLv = 0.85f
        @Volatile var masterThr = 0.30f

        @Volatile var spikeActive = false
        @Volatile var knifeActive = false
        @Volatile var rippleActive = false
        @Volatile var whistleActive = false
        @Volatile var protectActive = false

        private var ripplePhase = 0f

        fun tick(energy: Float, audioDb: Double = -80.0) {
            if (!enabled) {
                spikeActive = false; knifeActive = false; rippleActive = false
                whistleActive = false; protectActive = false
                return
            }
            val e = energy.coerceIn(0f, 1f) * level.coerceIn(0f, 1f)
            spikeActive = spikeOn && e >= spikeThr.coerceIn(0.05f, 1f)
            knifeActive = knifeOn && e >= knifeThr.coerceIn(0.05f, 1f)
            rippleActive = rippleOn && e >= rippleThr.coerceIn(0.05f, 1f)
            whistleActive = whistleOn && (audioDb >= -35.0 || e >= whistleThr.coerceIn(0.05f, 1f))
            protectActive = protectOn && (spikeActive || knifeActive || whistleActive || e >= protectThr.coerceIn(0.05f, 1f))
            // master threshold gates all FX energy
            if (e < masterThr.coerceIn(0f, 1f)) {
                spikeActive = false; knifeActive = false; rippleActive = false
                whistleActive = false
            }
            if (rippleActive) ripplePhase += 0.12f + rippleLv * 0.25f
        }

        /** Multiplier for region ambient draw (protection lowers spike punch-through). */
        fun regionScale(): Float {
            if (!enabled) return 1f
            var s = 0.55f + 0.45f * level
            if (spikeActive) s *= (1f + spikeLv * 0.35f)
            if (knifeActive) s *= (1f + knifeLv * 0.20f)
            if (whistleActive) s *= (1f + whistleLv * 0.15f)
            if (protectActive) s *= (1f - protectLv * 0.35f)
            if (anyEffectProtectOn && (spikeActive || knifeActive || whistleActive || rippleActive)) {
                s *= (1f - anyEffectProtectLv * 0.55f)
            }
            return s.coerceIn(0.15f, 1.6f)
        }

        fun rippleOffset(): Float =
            if (rippleActive) kotlin.math.sin(ripplePhase) * rippleLv * 12f else 0f

        fun statusLine(): String {
            val tags = buildList {
                if (spikeActive) add("SPIKE")
                if (knifeActive) add("KNIFE")
                if (rippleActive) add("RIPPLE")
                if (whistleActive) add("WHISTLE")
                if (protectActive) add("PROT")
                if (isEmpty()) add("idle")
            }.joinToString("+")
            return "REGION-FX thr=${(masterThr*100).toInt()}% lv=${(level*100).toInt()}% · $tags · scale=${(regionScale()*100).toInt()}%"
        }
    }

    val regionFx = RegionEffects()

    // Body particles · threshold · bipolar dB · RAW
    @Volatile var bodyParticlesOn = true
    @Volatile var bodyParticlesLv = 0.55f
    @Volatile var bodyParticlesThr = 0.30f
    @Volatile var bodyParticlesActive = false
    @Volatile var bodyParticlesOut = 0f
    @Volatile var bodyParticlesRaw = false
    @Volatile var bodyParticlesBipNeg = -40f
    @Volatile var bodyParticlesBipPos = 40f
    @Volatile var bodyParticlesBipHit = false

    val screenAmbient = ScreenAmbientBoard()
    val soundBank = SoundBankGuard()
    val echoProtect = EchoEffectProtection(soundBank)
    val eyesAmbient = EyesAmbientBoard()
    val finalAnatomy = FinalAnatomyAmbientBoard()
    val finalTabs = FinalTabsCompleteBoard()
    val monoEyes = MonoEyesCompleteBoard()
    val cnsEyesHeart = CnsEyesHeart3dBoard()
    val poseSegEyeBody = PoseSegEyeBodyBoard()
    val fullModel3d = FullModel3dBodyBoard()
    val bodyIsolation = BodyIsolationBoard()
    val body3dModelInteract = Body3dModelInteractBoard()
    val skinAtomspare = SkinAtomspare3dBoard()
    val anatomyShell = BodyAnatomyShellBoard()
    val enemy3dProtect = Enemy3dModelProtectBoard()
    val body84FullHuman = Body84FullHumanBoard()
    val ultraWeapon = UltrasoundWeaponOutBoard()
    val frontSideAmbient = FrontSideAmbientBoard()
    val hairBullet = HairAmbientBulletCollapseBoard()
    val completeAtomProtect = CompleteAtomspareProtectBoard()
    val bodyFreqRegen = BodyFrequencyRegenBoard()
    val complete3dNoMiss = Complete3dNoMissBoard()
    val eyesHeartBelly = EyesHeartBellyCompleteBoard()
    val faceEyeNoise = FaceEyeNoiseCompleteBoard()
    val moreMissed = MoreMissedCompleteBoard()
    val fullBodyAnatomy = FullBodyAnatomyInterconnectBoard()
    val sharpBurstMeter = SharpBurstKnifeMeterBoard()
    val liveMicEnemyAll = LiveMicEnemyAllSoundsBoard()
    val enemySoundCancel = EnemySoundCancelBoard()
    val allBodySkinAnatomy = AllBodySkinAnatomyAmbientBoard()
    val skinMultiMotion = SkinMultiModelMotionBoard()
    val skinSoundsProtect = SkinSoundsProtectBoard()
    val bioSkinCell = BioSkinCellAmbientBoard()
    val bodyChemBrain = BodyChemBrainAmbientBoard()
    val mgBleScaleWatt = MgBleScaleWattBoard()
    val caMgProtectChem = CaMgProtectChemBoard()
    val skeletonWaterAstro = SkeletonWaterAstroAmbientBoard()
    val fullAmbientMaster = FullAmbientMasterBoard()
    val bodyRegionEnemyProtect = BodyRegionEnemySoundProtectBoard()
    val antiAtomspareSounds = AntiAtomspareSoundsBoard()
    val earAuditoryLine = EarAuditoryLineAmbientBoard()
    val eyesCompleteLock = EyesCompleteEnemyLockBoard()
    val fullBodyMotionLock = FullBodyMotionLockBoard()
    val enemySoundCounters = EnemySoundCountersBoard()
    val soundDetectBodyTrack = SoundDetectBodyRegionTrackBoard()
    val micLiveAmbientMixer = MicLiveAmbientMixerBoard()
    val fullSkeletonBone = FullSkeletonBoneAmbientBoard()
    val finalProtectionMain = FinalProtectionMainBoard()
    val fullAnatomy132 = FullAnatomy132AmbientBoard()
    val sensorGatedSfx = SensorGatedSfxDetectBoard()
    val regionFxBoard = RegionFxBoard()
    val aiPlatformApi = AiPlatformApiBoard()
    val audioLevels = AudioLevelsBoard()
    val finalEyes = FinalEyesCompleteBoard()
    val micSpeaker = MicSpeakerBoard()
    val arMeasure = ArCoreMeasureBoard()
    val cameraArMeshWorld = CameraArMeshWorldBoard(arMeasure)
    val cameraExclusiveGuard = CameraExclusiveGuardBoard()
    val heartInsideFull = HeartInsideFullAmbientBoard()
    val neuralNeuroTx = NeuralNeurotransmitterAmbientBoard()
    val enemySameBody = EnemySameBodyModelBoard()
    val waterFullBody = WaterFullBodyAmbientBoard()
    val reproAnatomy = ReproAnatomyAmbientBoard()
    val pointerBulletLinear = PointerBulletLinearFreqBoard()
    val bodyRegionBulletAtom = BodyRegionBulletAtomspareBoard()
    val eyeCanthusHeartBrain = EyeCanthusHeartBrainGapBoard()
    val enemyBleScaleTrack = EnemyBleScaleTrackBoard()
    val waterWarfareAmbient = WaterWarfareAmbientBoard()
    val enemyBodySprayPrank = EnemyBodySprayPrankBoard()
    val bleEnemyAmbientBlock = BleEnemyAmbientBlockBoard()
    val fullProtectionBle = FullProtectionBleBoard()
    val lifesumBloodBle = LifesumBloodBleSystemBoard()
    val bodyOilsChemical = BodyOilsChemicalFullBoard()
    val modelSpeakerSounds = ModelSpeakerSoundsTrackBoard()
    val screenEffectInside = ScreenEffectInsideAnatomyBoard()
    val completeHuman360 = CompleteHumanAnatomy360Board()
    val enemyFoodDustbinPrank = EnemyFoodDustbinPrankBoard()
    val eyeBodyAtomSurface = EyeBodyAtomspareSurfaceBoard()
    @Volatile var bleScaleLibrary: BleScaleLibrary? = null
    val cameraVhs = CameraVhsBoard()
    val noiseRate = NoiseRateBoard()
    val noise3d = Noise3DBoard()
    val bodyAtmo3d = BodyAtmosphere3D()
    val poseSurface = PoseSurfaceBoard()
    val yoloSeg = YoloSegHuman3D().also { it.tryLoadModel("yolo26x-seg.onnx") }
    val bodyMixer = BodyModelMixer()
    val brain3d = BrainBoard()
    val anatomy3d = Anatomy3DBoard()
    val insideWarpRot = InsideWarpRot()
    val soft3d = Soft3DRenderer()
    val insideAmbient = InsideAmbient()
    val yoloObbTrack = YoloObbGameTrack()
    /** Rings + balls of every body region, anchored on the 3D anatomy body (inside + outside, RAW COMPLETE). */
    val ringBoard = AnatomyRingBoard()
    /** One shared field joining brain · anatomy · rings · sound bank. */
    val oneness = OnenessHub()
    /** Vertical · rotation · tilt (level · threshold · bipolar · centring) for every body-related model. */
    val bodyMotion = BodyMotionHub()
    /** Centre of mass of all active body parts (level · threshold · raw), centres all body motions. */
    val centroid = CentroidHub()
    /** Game-style 3D world: your body + every tracked noise body (read-only overlay). */
    val gameWorld = GameWorld3D()
    /** Audio/video feedback and the multi-board model motion router. */
    val videoFeedbackBoard = VideoFeedbackBoard()
    val audioColourBoard = AudioColourBoard()
    val virtualMovementBoards = VirtualMovementControlBoard()
    val emfReading = EmfReadingBoard()
    /** Optional foreground-only device sensor inputs for the game-world overlay. */
    @Volatile var gameSensors: GameSensorsHub? = null
    /** MODEL · AMBIENT · BODY · MASTER centroids (MASTER can centre every body model). */
    val centroids = CentroidSet()
    /** Ambient threshold board (live mic dB · CENTROID · VERTICAL), set from MainActivity. */
    @Volatile var ambientBoardRef: AmbientThresholdBoard? = null
    private val idleAmbientBoard = AmbientThresholdBoard()
    /** The live ambient board (the audio processor's), or an idle one until it is attached. Never null. */
    val ambientBoard: AmbientThresholdBoard get() = ambientBoardRef ?: idleAmbientBoard
    /** Movement · speed · waves · 84 body ambient · eye gaze = centroid + vertical (level · threshold · bipolar · raw). */
    val cenDrive = CentroidDrive()

    /**
     * LOCKED MODE — 3D body fixed at screen centre.
     * No rotate · twist · wait-rotation · sway · shake · L/R · U/D · snake · leave screen.
     * Mixing still runs; RAW COMPLETE still applies to levels.
     */
    @Volatile var bodyLocked = false

    private fun cenDx(): Float = if (centroids.enabled && centroids.useMaster) centroids.xOffset else centroid.xOffset
    private fun cenDy(): Float = if (centroids.enabled && centroids.useMaster) centroids.yOffset else centroid.yOffset
    /** SD-card sounds loaded into the sound bank (set from MainActivity). */
    @Volatile var sdSound: SdSoundBank? = null
    /** New sample FX can trigger only from a current camera pose + foreground mask. */
    val bodySoundFx = BodySoundFx()
    @Volatile var cameraBodyTrackOn = MemoryPaths.getBool("camera_body_track", true)
    @Volatile var cameraDetection = HumanDetection.none()
    /** Additive camera-to-eye bridge. Disabled by default to preserve legacy gaze behavior. */
    @Volatile var cameraGazeOn = MemoryPaths.getBool("camera_gaze_on", false)
    private val cameraGazeController = CameraGazeController()

    fun updateCameraDetection(detection: HumanDetection) {
        cameraDetection = detection
        yoloSeg.feedDetection(detection)
        bodySoundFx.feedDetection(detection)
        if (cameraGazeOn) {
            val gaze = cameraGazeController.update(detection)
            anatomy3d.gazeLx = gaze.leftX
            anatomy3d.gazeLy = gaze.leftY
            anatomy3d.gazeRx = gaze.rightX
            anatomy3d.gazeRy = gaze.rightY
        }
        postInvalidateOnAnimation()
    }

    /** Enable/disable camera-driven gaze without changing existing camera/body tracking. */
    fun setCameraGazeEnabled(enabled: Boolean) {
        cameraGazeOn = enabled
        MemoryPaths.putBool("camera_gaze_on", enabled)
        if (!enabled) {
            cameraGazeController.reset()
            anatomy3d.gazeLx = 0f
            anatomy3d.gazeLy = 0f
            anatomy3d.gazeRx = 0f
            anatomy3d.gazeRy = 0f
        }
    }

    /** Screen-sounds pitch protection (left / right). Set from MainActivity. */
    @Volatile var pitchGuard: StereoPitchGuard? = null
    init {
        anatomy3d.enabled = true
        brain3d.enabled = true
        anatomy3d.gpuOn = true
    }
    val bodySurfaceGpu = BodySurfaceGpuBoard()

    class EyeTuning {
        companion object {
            const val MODE_FLOOR = 0   // channel below threshold is raised to threshold
            const val MODE_GATE = 1    // channel below threshold is zeroed
            const val MODE_BINARY = 2  // channel becomes 0 or 255 around threshold
            const val MODE_COUNT = 3
            val MODE_NAMES = arrayOf("FLOOR", "GATE", "BINARY")
        }
        @Volatile var contrastOn = true
        @Volatile var brightnessOn = true
        @Volatile var thresholdOn = true
        @Volatile var invert = false

        @Volatile var contrast = 1.0f        // 0..2 (1 = unchanged)
        @Volatile var brightness = 0.0f      // -1..+1 (0 = unchanged)
        @Volatile var contrastThr = 0.0f     // 0..1 : below this ambient level contrast is not applied
        @Volatile var brightnessThr = 0.0f   // 0..1 : below this ambient level ring is dimmed
        @Volatile var thrR = 0               // 0..255 per-channel colour thresholds
        @Volatile var thrG = 0
        @Volatile var thrB = 0
        @Volatile var softness = 0.25f       // 0..1 : width of threshold transition
        @Volatile var mode = MODE_FLOOR

        private fun clamp255(v: Float) = v.coerceIn(0f, 255f)

        private fun channel(v0: Int, thr: Int): Float {
            var v = v0.toFloat()
            if (thresholdOn && thr > 0) {
                val soft = (softness * 64f).coerceAtLeast(0.001f)
                val t = thr.toFloat()
                when (mode) {
                    MODE_FLOOR -> if (v < t) v = t
                    MODE_GATE -> {
                        val k = ((v - (t - soft)) / (2f * soft)).coerceIn(0f, 1f)
                        v *= k
                    }
                    else -> {
                        val k = ((v - (t - soft)) / (2f * soft)).coerceIn(0f, 1f)
                        v = 255f * k
                    }
                }
            }
            return clamp255(v)
        }

        /** Returns packed ARGB colour after brightness / contrast / thresholds / invert. */
        fun apply(alpha: Int, r: Int, g: Int, b: Int, ambient: Float): Int {
            var rr = channel(r, thrR)
            var gg = channel(g, thrG)
            var bb = channel(b, thrB)
            if (brightnessOn) {
                val add = brightness * 255f
                rr = clamp255(rr + add); gg = clamp255(gg + add); bb = clamp255(bb + add)
            }
            if (contrastOn && ambient >= contrastThr) {
                rr = clamp255((rr - 128f) * contrast + 128f)
                gg = clamp255((gg - 128f) * contrast + 128f)
                bb = clamp255((bb - 128f) * contrast + 128f)
            }
            if (invert) { rr = 255f - rr; gg = 255f - gg; bb = 255f - bb }
            var a = alpha.toFloat()
            if (brightnessOn) {
                a *= (1f + brightness * 0.5f).coerceIn(0.2f, 1.5f)
                if (ambient < brightnessThr) {
                    val k = (ambient / brightnessThr.coerceAtLeast(0.01f)).coerceIn(0f, 1f)
                    a *= (softness + (1f - softness) * k)
                }
            }
            return Color.argb(a.toInt().coerceIn(0, 255), rr.toInt(), gg.toInt(), bb.toInt())
        }

        fun reset() {
            contrastOn = true; brightnessOn = true; thresholdOn = true; invert = false
            contrast = 1f; brightness = 0f; contrastThr = 0f; brightnessThr = 0f
            thrR = 0; thrG = 0; thrB = 0; softness = 0.25f; mode = MODE_FLOOR
        }
    }

    val eyeTuning = EyeTuning()
    val brainTuning = EyeTuning()
    val noseTuning = EyeTuning()

    val eyes = Region(ambient = 0.70f)
    /** Left / right eye paths (recovered) — independent + sync from shared eyes */
    val eyeL = Region(ambient = 0.70f)
    val eyeR = Region(ambient = 0.70f)
    val eyeLOut = Region(ambient = 0.72f)
    val eyeROut = Region(ambient = 0.72f)
    val eyeLIn = Region(ambient = 0.68f)
    val eyeRIn = Region(ambient = 0.68f)
    val eyeLSkinOut = Region(ambient = 0.66f)
    val eyeRSkinOut = Region(ambient = 0.66f)
    val eyeLSkinIn = Region(ambient = 0.58f)
    val eyeRSkinIn = Region(ambient = 0.58f)
    val eyeAtmo = Region(ambient = 0.55f)
    // Complete skin sub-system ambient (not single)
    val skinHead = Region(ambient = 0.62f)
    val skinNeck = Region(ambient = 0.60f)
    val skinChest = Region(ambient = 0.58f)
    val skinAbdomen = Region(ambient = 0.58f)
    val skinBack = Region(ambient = 0.56f)
    val skinArmL = Region(ambient = 0.58f)
    val skinArmR = Region(ambient = 0.58f)
    val skinHandL = Region(ambient = 0.55f)
    val skinHandR = Region(ambient = 0.55f)
    val skinLegL = Region(ambient = 0.58f)
    val skinLegR = Region(ambient = 0.58f)
    val skinFootL = Region(ambient = 0.54f)
    val skinFootR = Region(ambient = 0.54f)
    val skinAll = Region(ambient = 0.60f)

    // Complete eyes ambient system — L/R pairs (not single)
    val eyeLSclera = Region(ambient = 0.62f)
    val eyeRSclera = Region(ambient = 0.62f)
    val eyeLCornea = Region(ambient = 0.65f)
    val eyeRCornea = Region(ambient = 0.65f)
    val eyeLIris = Region(ambient = 0.68f)
    val eyeRIris = Region(ambient = 0.68f)
    val eyeLPupil = Region(ambient = 0.70f)
    val eyeRPupil = Region(ambient = 0.70f)
    val eyeLLidU = Region(ambient = 0.58f)
    val eyeRLidU = Region(ambient = 0.58f)
    val eyeLLidD = Region(ambient = 0.56f)
    val eyeRLidD = Region(ambient = 0.56f)
    val eyeLLash = Region(ambient = 0.50f)
    val eyeRLash = Region(ambient = 0.50f)
    val eyeLConjunctiva = Region(ambient = 0.55f)
    val eyeRConjunctiva = Region(ambient = 0.55f)
    val eyeLLacrimal = Region(ambient = 0.52f)
    val eyeRLacrimal = Region(ambient = 0.52f)
    val eyeLCanthus = Region(ambient = 0.54f)
    val eyeRCanthus = Region(ambient = 0.54f)
    val eyeLOrbit = Region(ambient = 0.60f)
    val eyeROrbit = Region(ambient = 0.60f)
    val eyesCompleteOn = true
    @Volatile var eyesAmbientRaw = false
    @Volatile var eyeLOn = true
    @Volatile var eyeROn = true
    val browL = Region(ambient = 0.55f)
    val browR = Region(ambient = 0.55f)
    @Volatile var browLOn = true
    @Volatile var browROn = true
    @Volatile var browSyncEyes = true
    @Volatile var eyeBallSep = 0.12f
    /** Small body-space adjustment from the anatomical eye socket. */
    @Volatile var eyeBallY = 0f
    @Volatile var eyeBallSize = 1.0f
    @Volatile var eyeMixOn = true
    @Volatile var eyeMixW = 0.50f
    val face = Region(ambient = 0.62f)
    val forehead = Region(ambient = 0.60f)
    val nose = Region(ambient = 0.58f)
    /** Lips upper/lower — full human face 3D, same ball-style settings */
    val lipU = Region(ambient = 0.58f)
    val lipL = Region(ambient = 0.58f)
    val tongue = Region(ambient = 0.55f)
    @Volatile var lipUOn = true
    @Volatile var lipLOn = true
    @Volatile var lipSyncFace = true
    @Volatile var lipY = 0.10f
    @Volatile var lipSep = 0.02f
    @Volatile var lipSize = 1.0f
    @Volatile var lipMixOn = true
    @Volatile var lipMixW = 0.45f
    /** Extra ambient system for all body regions (not single blob) */
    @Volatile var bodyRegionAmbientBoost = 0.0f
    @Volatile var bodyRegionRescanOn = true
    @Volatile var bodyRegionRescanOut = 0f
    @Volatile var bodyRegionActiveN = 0
    val brain = Region()
    val heart = Region()
    val neck = Region()
    val belly = Region()
    val handL = Region()
    val handR = Region()
    val pussy = Region(ambient = 0.50f)
    val dick = Region(ambient = 0.50f)
    val ass = Region(ambient = 0.50f)
    val legL = Region(ambient = 0.52f)
    val legR = Region(ambient = 0.52f)

    val body84 = Body84Channels()

    external fun nativeDraw(width: Int, height: Int, phase: Float, ambientLevel: Float, hardwareIntensity: Float)

    fun setShieldActive(value: Boolean) { active = value; invalidate() }
    fun setMode(mode: Int) {}

    fun setEyeAmbientLevel(v: Float) { eyes.ambient = v.coerceIn(0f, 1f) }
    fun setEyeWaveSpeed(v: Float) { eyes.wave = v.coerceIn(0.05f, 4f) }
    fun setEyeMove(v: Float) { eyes.move = v.coerceIn(0f, 1f) }
    fun setEyeMoveThr(v: Float) { eyes.moveThr = v.coerceIn(0.05f, 1f) }
    fun setEyeSpeed(v: Float) { eyes.speed = v.coerceIn(0f, 1f) }
    fun setEyeSpeedThr(v: Float) { eyes.speedThr = v.coerceIn(0.05f, 1f) }
    fun setEyeLrFilter(v: Float) { eyes.lrFilt = v.coerceIn(0f, 1f) }
    fun setEyeUdFilter(v: Float) { eyes.udFilt = v.coerceIn(0f, 1f) }
    /** Deterministic visual variation derived only from the live microphone frame. */
    private fun micVariation(maxExclusive: Int): Int {
        if (maxExclusive <= 1) return 0
        val seed = (RawMicBus.sequence xor
            (RawMicBus.dominantHz.toLong() * 31L) xor
            (RawMicBus.centroidHz.toLong() * 17L)).toInt()
        return kotlin.math.abs(seed) % maxExclusive
    }

    fun setEyeRandomFilter(v: Float) { eyes.randomFilt = v.coerceIn(0f, 1f) }
    fun setEyeCenterFilter(v: Float) { eyes.centerFilt = v.coerceIn(0f, 1f) }
    fun setEyeCornerFilter(v: Float) { eyes.cornerFilt = v.coerceIn(0f, 1f) }
    fun setEyeVibFilter(v: Float) { eyes.vibFilt = v.coerceIn(0f, 1f) }
    fun setEyeBipNeg(v: Float) { eyes.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setEyeBipPos(v: Float) { eyes.bipPosDb = v.coerceIn(0f, 120f) }
    fun setEyePigPong(v: Float) { eyes.pigPong = v.coerceIn(0f, 1f) }
    fun setEyePigPongThr(v: Float) { eyes.pigPongThr = v.coerceIn(0.05f, 1f) }

    fun setEyeAtmosphere(v: Float) { eyes.atmosphere = v.coerceIn(0f, 1f) }
    fun setEyeWaveSpare(v: Float) { eyes.waveSpare = v.coerceIn(0f, 1f) }
    fun setEyeAtmoBipNeg(v: Float) { eyes.atmoBipNeg = v.coerceIn(-300f, 0f) }
    fun setEyeAtmoBipPos(v: Float) { eyes.atmoBipPos = v.coerceIn(-300f, 300f).coerceAtLeast(0f) }
    fun setEyeParticles(v: Float) { eyes.particles = v.coerceIn(0f, 1f) }
    fun setEyeLSkinOut(v: Float) { eyeLSkinOut.ambient = v.coerceIn(0f, 1f) }
    fun setEyeRSkinOut(v: Float) { eyeRSkinOut.ambient = v.coerceIn(0f, 1f) }
    fun setEyeLSkinIn(v: Float) { eyeLSkinIn.ambient = v.coerceIn(0f, 1f) }
    fun setEyeRSkinIn(v: Float) { eyeRSkinIn.ambient = v.coerceIn(0f, 1f) }
    fun setEyeAtmoAmb(v: Float) { eyeAtmo.ambient = v.coerceIn(0f, 1f); eyeAtmo.atmosphere = v.coerceIn(0f, 1f) }

    fun setEyeBipThrNeg(v: Float) { eyes.bipThrNeg = v.coerceIn(-300f, 0f) }
    fun setEyeBipThrPos(v: Float) { eyes.bipThrPos = v.coerceIn(0f, 300f) }

    /** Sync shared eyes → left/right paths */
    fun syncEyesToLr() {
        eyeL.copyFrom(eyes)
        eyeR.copyFrom(eyes)
    }

    /**
     * Correct anatomical L/R eyes + full-app rescan for enemy eye vulnerability.
     * Viewer-left = subject's right eye anatomically mirrored on screen:
     * screen-left = eyeL (our left channel), screen-right = eyeR.
     */
    fun rescanEyesLr() {
        eyeLOn = true
        eyeROn = true
        // ensure independent channels not collapsed
        if (eyeL.ambient < 0.15f) eyeL.ambient = eyes.ambient.coerceAtLeast(0.55f)
        if (eyeR.ambient < 0.15f) eyeR.ambient = eyes.ambient.coerceAtLeast(0.55f)
        // mirror filters so L/R both track for enemy vulnerability scan
        eyeL.lrFilt = eyes.lrFilt.coerceAtLeast(0.5f)
        eyeR.lrFilt = eyes.lrFilt.coerceAtLeast(0.5f)
        eyeL.move = eyes.move
        eyeR.move = eyes.move
        eyeL.speed = eyes.speed
        eyeR.speed = eyes.speed
        eyeL.wave = eyes.wave
        eyeR.wave = eyes.wave
        bodyRegionRescanOn = true
    }

    /** Enemy vulnerability: both eyes must stay active and mixed into rescan. */
    fun enemyEyeVulnerabilityScale(): Float {
        val l = if (eyeLOn) eyeL.effectiveAmbient() else 0f
        val r = if (eyeROn) eyeR.effectiveAmbient() else 0f
        return ((l + r) * 0.5f).coerceIn(0f, 1f)
    }

    fun setEyeLAmbient(v: Float) { eyeL.ambient = v.coerceIn(0f, 1f) }
    fun setEyeRAmbient(v: Float) { eyeR.ambient = v.coerceIn(0f, 1f) }
    fun setBrowLAmbient(v: Float) { browL.ambient = v.coerceIn(0f, 1f) }
    fun setBrowRAmbient(v: Float) { browR.ambient = v.coerceIn(0f, 1f) }
    fun setLipUAmbient(v: Float) { lipU.ambient = v.coerceIn(0f, 1f) }
    fun setLipLAmbient(v: Float) { lipL.ambient = v.coerceIn(0f, 1f) }
    fun setTongueAmbient(v: Float) { tongue.ambient = v.coerceIn(0f, 1f) }
    fun setTongueWave(v: Float) { tongue.wave = v.coerceIn(0.05f, 4f) }
    fun setTongueMove(v: Float) { tongue.move = v.coerceIn(0f, 1f) }
    fun setTongueMoveThr(v: Float) { tongue.moveThr = v.coerceIn(0.05f, 1f) }
    fun setTongueSpeed(v: Float) { tongue.speed = v.coerceIn(0f, 1f) }
    fun setTongueSpeedThr(v: Float) { tongue.speedThr = v.coerceIn(0.05f, 1f) }
    fun setTongueLrFilter(v: Float) { tongue.lrFilt = v.coerceIn(0f, 1f) }
    fun setTongueUdFilter(v: Float) { tongue.udFilt = v.coerceIn(0f, 1f) }
    fun setTongueRandomFilter(v: Float) { tongue.randomFilt = v.coerceIn(0f, 1f) }
    fun setTongueCenterFilter(v: Float) { tongue.centerFilt = v.coerceIn(0f, 1f) }
    fun setTongueCornerFilter(v: Float) { tongue.cornerFilt = v.coerceIn(0f, 1f) }
    fun setTongueVibFilter(v: Float) { tongue.vibFilt = v.coerceIn(0f, 1f) }
    fun setTongueBipNeg(v: Float) { tongue.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setTongueBipPos(v: Float) { tongue.bipPosDb = v.coerceIn(0f, 120f) }
    fun setTongueAtmosphere(v: Float) { tongue.atmosphere = v.coerceIn(0f, 1f) }
    fun setTongueWaveSpare(v: Float) { tongue.waveSpare = v.coerceIn(0f, 1f) }
    fun setTongueAtmoBipNeg(v: Float) { tongue.atmoBipNeg = v.coerceIn(-300f, 0f) }
    fun setTongueAtmoBipPos(v: Float) { tongue.atmoBipPos = v.coerceIn(-300f, 300f).coerceAtLeast(0f) }
    fun setTongueParticles(v: Float) { tongue.particles = v.coerceIn(0f, 1f) }
    fun setTongueBipThrNeg(v: Float) { tongue.bipThrNeg = v.coerceIn(-300f, 0f) }
    fun setTongueBipThrPos(v: Float) { tongue.bipThrPos = v.coerceIn(0f, 300f) }
    fun setTongueRaw(v: Boolean) { tongue.rawComplete = v }
    fun setAllRegionsRaw(v: Boolean) {
        listOf(eyes, eyeL, eyeR, browL, browR, face, forehead, nose, lipU, lipL, tongue,
            brain, heart, neck, belly, handL, handR, pussy, dick, ass, legL, legR
        ).forEach { it.rawComplete = v }
    }

    fun setEyeLMove(v: Float) { eyeL.move = v.coerceIn(0f, 1f) }
    fun setEyeRMove(v: Float) { eyeR.move = v.coerceIn(0f, 1f) }
    fun setEyeLMoveThr(v: Float) { eyeL.moveThr = v.coerceIn(0.05f, 1f) }
    fun setEyeRMoveThr(v: Float) { eyeR.moveThr = v.coerceIn(0.05f, 1f) }

    // Eye contrast / brightness / colour threshold controls
    fun setEyeContrast(v: Float) { eyeTuning.contrast = v.coerceIn(0f, 2f) }
    fun setEyeBrightness(v: Float) { eyeTuning.brightness = v.coerceIn(-1f, 1f) }
    fun setEyeContrastThr(v: Float) { eyeTuning.contrastThr = v.coerceIn(0f, 1f) }
    fun setEyeBrightnessThr(v: Float) { eyeTuning.brightnessThr = v.coerceIn(0f, 1f) }
    fun setEyeColorThrR(v: Int) { eyeTuning.thrR = v.coerceIn(0, 255) }
    fun setEyeColorThrG(v: Int) { eyeTuning.thrG = v.coerceIn(0, 255) }
    fun setEyeColorThrB(v: Int) { eyeTuning.thrB = v.coerceIn(0, 255) }
    fun setEyeThrSoftness(v: Float) { eyeTuning.softness = v.coerceIn(0f, 1f) }
    fun setEyeThrMode(v: Int) { eyeTuning.mode = v.mod(EyeTuning.MODE_COUNT) }
    fun setEyeContrastOn(v: Boolean) { eyeTuning.contrastOn = v }
    fun setEyeBrightnessOn(v: Boolean) { eyeTuning.brightnessOn = v }
    fun setEyeThresholdOn(v: Boolean) { eyeTuning.thresholdOn = v }
    fun setEyeInvert(v: Boolean) { eyeTuning.invert = v }
    fun resetEyeTuning() { eyeTuning.reset() }

    fun setHardwareIntensity(v: Float) { hardwareIntensity = v.coerceIn(0f, 1f) }
    fun setColorThreshold(v: Int) { colorThreshold = v.coerceIn(0, 255) }
    fun setLrFilter(v: Float) { lrFilter = v.coerceIn(0f, 1f) }
    fun setUdFilter(v: Float) { udFilter = v.coerceIn(0f, 1f) }
    fun setRandomFilter(v: Float) { randomFilter = v.coerceIn(0f, 1f) }
    fun setCenterFilter(v: Float) { centerFilter = v.coerceIn(0f, 1f) }
    fun setCornerFilter(v: Float) { cornerFilter = v.coerceIn(0f, 1f) }
    fun setVibFreqFilter(v: Float) { vibFreqFilter = v.coerceIn(0f, 1f) }
    fun setTextureShift(v: Float) { textureShift = v.coerceIn(0f, 1f) }
    fun setCameraFeedback(v: Float) { cameraFeedback = v.coerceIn(0f, 1f) }
    fun setSoundBankRaw(v: Boolean) { soundBank.rawComplete = v }
    fun setScreenAmbientRaw(v: Boolean) { screenAmbient.rawComplete = v }
    fun setScreenCentroidOn(v: Boolean) { screenAmbient.centroidOn = v }
    fun setScreenCentroidLv(v: Float) { screenAmbient.centroidLv = v.coerceIn(0f, 1f) }
    fun setScreenCentroidThr(v: Float) { screenAmbient.centroidThr = v.coerceIn(0.05f, 1f) }
    fun setScreenVerticalOn(v: Boolean) { screenAmbient.verticalOn = v }
    fun setScreenDominationOn(on: Boolean) { screenAmbient.dominationOn = on }
    fun setScreenDominationThr(t: Float) { screenAmbient.dominationThr = t.coerceIn(0.05f, 0.98f) }
    fun setScreenDominationLv(l: Float) { screenAmbient.dominationLv = l.coerceIn(0f, 1f) }
    fun setScreenDominationHzFeed(hz: Float) { screenAmbient.dominationHzFeed = hz.coerceIn(0f, 20000f) }
    fun setScreenDominationRaw(on: Boolean) { screenAmbient.dominationRaw = on }
    fun setScreenDominationHzMin(hz: Float) { screenAmbient.dominationHzMin = hz.coerceIn(20f, 19000f) }
    fun setScreenDominationHzMax(hz: Float) { screenAmbient.dominationHzMax = hz.coerceIn(100f, 20000f) }
    fun setScreenVerticalLv(v: Float) { screenAmbient.verticalLv = v.coerceIn(0f, 1f) }
    fun setScreenVerticalThr(v: Float) { screenAmbient.verticalThr = v.coerceIn(0.05f, 1f) }

    fun setEmfReadingEnabled(v: Boolean) { emfReading.enabled = v }
    fun setEmfReadingRaw(v: Boolean) { emfReading.rawComplete = v }
    fun setEmfTrackThrUt(v: Float) { emfReading.trackThrUt = v.coerceIn(0.5f, 200f) }
    fun setEmfGain(v: Float) { emfReading.gain = v.coerceIn(0.1f, 5f) }
    fun setEmfTrackOn(v: Boolean) { emfReading.trackOn = v }
    fun setEmfAmbientThr(v: Float) { emfReading.ambientThr = v.coerceIn(0.05f, 1f) }
    fun setEmfAmbientLv(v: Float) { emfReading.ambientLv = v.coerceIn(0f, 1f) }
    fun setEmfCentroidThr(v: Float) { emfReading.centroidThr = v.coerceIn(0.05f, 1f) }
    fun setEmfSpikeThr(v: Float) { emfReading.spikeThr = v.coerceIn(0.05f, 1f) }
    fun setEmfSpikeLv(v: Float) { emfReading.spikeLv = v.coerceIn(0f, 1f) }
    fun setEmfSpikeThrUt(v: Float) { emfReading.spikeThrUt = v.coerceIn(1f, 200f) }


    fun setSoundBankEnabled(v: Boolean) { soundBank.enabled = v }
    fun setAudioFocusLv(v: Float) { soundBank.audioFocusLv = v.coerceIn(0f, 1f) }
    fun setAudioFocusThr(v: Float) { soundBank.audioFocusThr = v.coerceIn(0.05f, 1f) }
    fun setFocusMoveLv(v: Float) { soundBank.focusMoveLv = v.coerceIn(0f, 1f) }
    fun setFocusSpeedLv(v: Float) { soundBank.focusSpeedLv = v.coerceIn(0f, 1f) }
    fun setFocusWaveLv(v: Float) { soundBank.focusWaveLv = v.coerceIn(0f, 1f) }
    fun setBipDbNeg(v: Float) { soundBank.bipDbNeg = v.coerceIn(-1000f, 0f) }
    fun setBipDbPos(v: Float) { soundBank.bipDbPos = v.coerceIn(0f, 1000f) }
    fun setEnemyBodyThr(v: Float) { soundBank.enemyBodyThr = v.coerceIn(0.05f, 1f) }
    fun setEnemyBodyLv(v: Float) { soundBank.enemyBodyLv = v.coerceIn(0f, 1f) }
    fun setEnemyBodyOn(v: Boolean) { soundBank.enemyBodyOn = v }
    fun setBodySurfCommOn(v: Boolean) { soundBank.bodySurfCommOn = v }
    fun setMicDrivenOn(v: Boolean) { soundBank.micDrivenOn = v }
    fun setMicEnemyThr(v: Float) { soundBank.micEnemyThr = v.coerceIn(0.05f, 1f) }
    fun setMicEnemyLv(v: Float) { soundBank.micEnemyLv = v.coerceIn(0f, 1f) }
    fun setProtectBodyOn(v: Boolean) { soundBank.protectBodyOn = v }
    fun setProtectLv(v: Float) { soundBank.protectLv = v.coerceIn(0f, 1f) }
    fun setProtectThr(v: Float) { soundBank.protectThr = v.coerceIn(0.05f, 1f) }
    fun setEnemyCommBlockOn(v: Boolean) { soundBank.enemyCommBlockOn = v }
    fun setEnemyCommBlockThr(v: Float) { soundBank.enemyCommBlockThr = v.coerceIn(0.05f, 1f) }
    fun setEnemyCommBlockLv(v: Float) { soundBank.enemyCommBlockLv = v.coerceIn(0f, 1f) }
    fun setAntiAudioOn(v: Boolean) { soundBank.antiAudioOn = v }
    fun setAntiAudioThr(v: Float) { soundBank.antiAudioThr = v.coerceIn(0.05f, 1f) }
    fun setAntiAudioLv(v: Float) { soundBank.antiAudioLv = v.coerceIn(0f, 1f) }
    fun setAntiBodyOn(v: Boolean) { soundBank.antiBodyOn = v }
    fun setAntiBodyThr(v: Float) { soundBank.antiBodyThr = v.coerceIn(0.05f, 1f) }
    fun setAntiBodyLv(v: Float) { soundBank.antiBodyLv = v.coerceIn(0f, 1f) }
    fun setAtmoFireOn(v: Boolean) { soundBank.atmoFireOn = v }
    fun setAtmoFireThr(v: Float) { soundBank.atmoFireThr = v.coerceIn(0.05f, 1f) }
    fun setAtmoFireLv(v: Float) { soundBank.atmoFireLv = v.coerceIn(0f, 1f) }
    fun setAtmoFireBipNeg(v: Float) { soundBank.atmoFireBipNeg = v.coerceIn(-1000f, 0f) }
    fun setAtmoFireBipPos(v: Float) { soundBank.atmoFireBipPos = v.coerceIn(0f, 1000f) }
    fun setEyeFireOn(v: Boolean) { soundBank.eyeFireOn = v }
    fun setHeadFireOn(v: Boolean) { soundBank.headFireOn = v }
    fun fireAtmo() { soundBank.fireAtmo() }
    fun fireEye() { soundBank.fireEye() }
    fun fireHead() { soundBank.fireHead() }
    fun fireBody() { soundBank.fireBody() }
    fun fireAs() { soundBank.fireAs() }
    fun fireGun() { soundBank.fireGun() }
    fun fireCollapse() { soundBank.fireCollapse() }
    fun fireLhc() { soundBank.fireLhc() }
    fun fireAmbSysCollapse() { soundBank.fireAmbSysCollapse() }
    fun fireEnemyBankCollapse() { soundBank.fireEnemyBankCollapse() }
    fun setAmbSysCollapseOn(v: Boolean) { soundBank.ambSysCollapseOn = v }
    fun setEnemyBankCollapseOn(v: Boolean) { soundBank.enemyBankCollapseOn = v }
    fun setSoundsBankCollideOn(v: Boolean) { soundBank.soundsBankCollideOn = v }
    fun ambCollapseStatus(): String = soundBank.ambCollapseStatus()
    fun setLhcColliderOn(v: Boolean) { soundBank.lhcColliderOn = v }
    fun setLhcEchoCancelOn(v: Boolean) { soundBank.lhcEchoCancelOn = v }
    fun setLhcAxisCollapseOn(v: Boolean) { soundBank.lhcAxisCollapseOn = v }
    fun setLhcEnergy(v: Float) { soundBank.lhcEnergy = v.coerceIn(0.05f, 1f) }
    fun setLhcThr(v: Float) { soundBank.lhcThr = v.coerceIn(0.05f, 1f) }
    fun setLhcDbThr(v: Float) { soundBank.lhcDbThr = v.coerceIn(1f, 120f) }
    fun updateLhc(ourRms: Float, enemyTx: Float, ax: Float, ay: Float, az: Float, echoOn: Boolean) {
        soundBank.updateLhc(ourRms, enemyTx, ax, ay, az, echoOn)
    }
    fun lhcStatus(): String = soundBank.lhcStatus()
    fun fireAnti() { soundBank.fireAnti() }
    fun fireAll() { soundBank.fireAll() }
    fun setBulletThr(v: Float) { soundBank.bulletThr = v.coerceIn(0.05f, 1f) }
    fun setBulletLv(v: Float) { soundBank.bulletLv = v.coerceIn(0f, 1f) }
    fun setBulletOn(v: Boolean) { soundBank.bulletOn = v }
    fun setKnifeThr(v: Float) { soundBank.knifeThr = v.coerceIn(0.05f, 1f) }
    fun setKnifeLv(v: Float) { soundBank.knifeLv = v.coerceIn(0f, 1f) }
    fun setKnifeOn(v: Boolean) { soundBank.knifeOn = v }
    fun setWhipOn(v: Boolean) { soundBank.whipOn = v }
    fun setWhipThr(v: Float) { soundBank.whipThr = v.coerceIn(0.05f, 1f) }
    fun setWhipLv(v: Float) { soundBank.whipLv = v.coerceIn(0f, 1f) }
    fun setWhipProtect(v: Boolean) { soundBank.whipProtect = v }
    fun setMobileBurstProtect(on: Boolean) { soundBank.mobileBurstProtect = on }
    fun setMobileBurstProtectLv(l: Float) { soundBank.mobileBurstProtectLv = l.coerceIn(0f, 1f) }
    fun setMobileKnifeProtect(on: Boolean) { soundBank.mobileKnifeProtect = on }
    fun setMobileKnifeProtectLv(l: Float) { soundBank.mobileKnifeProtectLv = l.coerceIn(0f, 1f) }
    fun setBlockEnemyBurstOnBody(on: Boolean) { soundBank.blockEnemyBurstOnBody = on }
    fun setBlockEnemyBurstOnHead(on: Boolean) { soundBank.blockEnemyBurstOnHead = on }
    fun setBlockEnemyBurstOnMobile(on: Boolean) { soundBank.blockEnemyBurstOnMobile = on }
    fun setWhipModelDrive(v: Boolean) { soundBank.whipModelDrive = v }
    fun setArMixerProtectOn(v: Boolean) { bodyMixer.arMixerProtectOn = v }
    fun setArMixerProtectLv(v: Float) { bodyMixer.arMixerProtectLv = v.coerceIn(0f, 1f) }
    fun setArCoreProtectOn(v: Boolean) { /* ar board if exposed */ }

    fun setRippleThr(v: Float) { soundBank.rippleThr = v.coerceIn(0.05f, 1f) }
    fun setRippleLv(v: Float) { soundBank.rippleLv = v.coerceIn(0f, 1f) }
    fun setRippleOn(v: Boolean) { soundBank.rippleOn = v }
    fun setWhistleThr(v: Float) { soundBank.whistleThr = v.coerceIn(0.05f, 1f) }
    fun setWhistleLv(v: Float) { soundBank.whistleLv = v.coerceIn(0f, 1f) }
    fun setWhistleOn(v: Boolean) { soundBank.whistleOn = v }
    fun setAmbitiousThr(v: Float) { soundBank.ambitiousThr = v.coerceIn(0.05f, 1f) }
    fun setAmbitiousLv(v: Float) { soundBank.ambitiousLv = v.coerceIn(0f, 1f) }
    fun setAmbitiousOn(v: Boolean) { soundBank.ambitiousOn = v }
    fun setCollideThr(v: Float) { soundBank.collideThr = v.coerceIn(0.05f, 1f) }
    fun setCollideLv(v: Float) { soundBank.collideLv = v.coerceIn(0f, 1f) }
    fun setCollapseThr(v: Float) { soundBank.collapseThr = v.coerceIn(0.05f, 1f) }
    fun setCollapseLv(v: Float) { soundBank.collapseLv = v.coerceIn(0f, 1f) }
    fun setEnemyFxProtectLv(v: Float) { soundBank.enemyFxProtectLv = v.coerceIn(0f, 1f) }
    fun setEnemyMasterShieldOn(on: Boolean) { soundBank.enemyMasterShieldOn = on }
    fun setEnemyMasterShieldLv(l: Float) { soundBank.enemyMasterShieldLv = l.coerceIn(0f, 1f) }
    fun setArRealityShieldOn(on: Boolean) { soundBank.arRealityShieldOn = on }
    fun setArRealityShieldLv(l: Float) { soundBank.arRealityShieldLv = l.coerceIn(0f, 1f) }
    fun setEchoMasterAntiOn(on: Boolean) { echoProtect.masterAntiOn = on; echoProtect.enabled = true }
    fun setEchoMasterAntiLv(l: Float) { echoProtect.masterAntiLv = l.coerceIn(0f, 1f) }
    fun setEchoBodyAsShield(on: Boolean) { echoProtect.bodyAsShieldOn = on }
    fun setEchoBodyWsShield(on: Boolean) { echoProtect.bodyWsShieldOn = on }
    fun setEchoKnifeShield(on: Boolean) { echoProtect.knifeShieldOn = on }
    fun setEchoAnyEffectProtect(on: Boolean) { echoProtect.anyEffectOn = on }
    fun setEchoAnyEffectLv(l: Float) { echoProtect.anyEffectLv = l.coerceIn(0f, 1f) }
    fun setEyesAmbLeftOn(on: Boolean) { eyesAmbient.leftOn = on }
    fun setEyesAmbRightOn(on: Boolean) { eyesAmbient.rightOn = on }
    fun setEyesAmbLeftThr(t: Float) { eyesAmbient.leftThr = t.coerceIn(0.05f, 1f) }
    fun setEyesAmbRightThr(t: Float) { eyesAmbient.rightThr = t.coerceIn(0.05f, 1f) }
    fun setEyesAmbLeftLv(l: Float) { eyesAmbient.leftLv = l.coerceIn(0f, 1f) }
    fun setEyesAmbRightLv(l: Float) { eyesAmbient.rightLv = l.coerceIn(0f, 1f) }
    fun setEyesAmbProtectL(on: Boolean) { eyesAmbient.protectL = on; echoProtect.eyesPitchProtL = on }
    fun setEyesAmbProtectR(on: Boolean) { eyesAmbient.protectR = on; echoProtect.eyesPitchProtR = on }
    fun setEyesAmbBipNeg(db: Float) { eyesAmbient.bipNegDb = db.coerceIn(-120f, 0f) }
    fun setEyesAmbBipPos(db: Float) { eyesAmbient.bipPosDb = db.coerceIn(0f, 120f) }
    fun setFinalAnatomyEnabled(on: Boolean) { finalAnatomy.enabled = on }
    fun setFinalAnatomyGlobalThr(t: Float) { finalAnatomy.globalThr = t.coerceIn(0.05f, 1f) }
    fun setFinalAnatomyGlobalLv(l: Float) { finalAnatomy.globalLv = l.coerceIn(0f, 1f) }
    fun setFinalAnatomyRaw(on: Boolean) { finalAnatomy.rawComplete = on }
    fun setFinalLeftBody(on: Boolean) { finalAnatomy.leftBodyOn = on }
    fun setFinalRightBody(on: Boolean) { finalAnatomy.rightBodyOn = on }
    fun setFinalFrontBody(on: Boolean) { finalAnatomy.frontBodyOn = on }
    fun setFinalBackBody(on: Boolean) { finalAnatomy.backBodyOn = on }
    fun setFinalLeftBrain(on: Boolean) { finalAnatomy.leftBrainOn = on }
    fun setFinalRightBrain(on: Boolean) { finalAnatomy.rightBrainOn = on }
    fun setFinalLeftBodyThr(t: Float) { finalAnatomy.leftBodyThr = t.coerceIn(0.05f, 1f) }
    fun setFinalRightBodyThr(t: Float) { finalAnatomy.rightBodyThr = t.coerceIn(0.05f, 1f) }
    fun setFinalLeftBodyLv(l: Float) { finalAnatomy.leftBodyLv = l.coerceIn(0f, 1f) }
    fun setFinalRightBodyLv(l: Float) { finalAnatomy.rightBodyLv = l.coerceIn(0f, 1f) }
    fun setFinalAnatomyBipNeg(db: Float) { finalAnatomy.bipolarNegDb = db.coerceIn(-120f, 0f) }
    fun setFinalAnatomyBipPos(db: Float) { finalAnatomy.bipolarPosDb = db.coerceIn(0f, 120f) }
    fun setAtmoCentroidOn(v: Boolean) { soundBank.atmoCentroidOn = v }
    fun setAtmoCentroidThr(v: Float) { soundBank.atmoCentroidThr = v.coerceIn(0.05f, 1f) }
    fun setAtmoCentroidLv(v: Float) { soundBank.atmoCentroidLv = v.coerceIn(0f, 1f) }
    fun setAncOn(v: Boolean) { soundBank.ancOn = v }
    fun setAncLv(v: Float) { soundBank.ancLv = v.coerceIn(0f, 1f) }
    fun setAncThr(v: Float) { soundBank.ancThr = v.coerceIn(0.05f, 1f) }
    fun setAncProtectOn(v: Boolean) { soundBank.ancProtectOn = v }
    fun setAncProtectLv(v: Float) { soundBank.ancProtectLv = v.coerceIn(0f, 1f) }
    fun setNatureMotionOn(v: Boolean) { soundBank.natureMotionOn = v }


    fun setMicSpeakerEnabled(v: Boolean) { micSpeaker.enabled = v }
    fun setMicSpeakerRaw(v: Boolean) { micSpeaker.rawComplete = v }
    fun setMic1On(v: Boolean) { micSpeaker.mic1On = v }
    fun setMic2On(v: Boolean) { micSpeaker.mic2On = v }
    fun setMicMono(v: Boolean) { micSpeaker.monoOn = v }
    fun setMicStereoOn(v: Boolean) {
        micSpeaker.stereoOn = v
        if (v) micSpeaker.monoOn = false
    }
    fun setMicLOn(v: Boolean) { micSpeaker.micLOn = v }
    fun setMicROn(v: Boolean) { micSpeaker.micROn = v }
    fun setStereoBalance(v: Float) { micSpeaker.stereoBalance = v.coerceIn(0f, 1f) }
    fun setStereoLvL(v: Float) { micSpeaker.stereoLvL = v.coerceIn(0f, 1f) }
    fun setStereoLvR(v: Float) { micSpeaker.stereoLvR = v.coerceIn(0f, 1f) }
    fun setStereoThrL(v: Float) { micSpeaker.stereoThrL = v.coerceIn(0.05f, 1f) }
    fun setStereoThrR(v: Float) { micSpeaker.stereoThrR = v.coerceIn(0.05f, 1f) }
    fun setEchoCancelOn(v: Boolean) { micSpeaker.echoCancelOn = v }
    fun setNoiseReduceOn(v: Boolean) { micSpeaker.noiseReduceOn = v }
    fun setKaraokeEffectId(id: Int) {
        micSpeaker.setKaraokeById(id)
        // sync echo decay colour from preset
    }
    fun setEffectLevel(v: Float) { micSpeaker.effectLevel = v.coerceIn(0f, 1f) }
    fun setSpeakerGain(v: Float) { micSpeaker.speakerGain = v.coerceIn(0f, 2f) }
    fun setMicGain(v: Float) { micSpeaker.micGain = v.coerceIn(0f, 2f) }
    fun setAmpGain(v: Float) { micSpeaker.ampGain = v.coerceIn(0f, 3f) }





    private fun applyRegion(r: Region, block: Region.() -> Unit) { r.block() }

    fun setBrainAmbient(v: Float) { brain.ambient = v.coerceIn(0f, 1f) }
    fun setBrainWave(v: Float) { brain.wave = v.coerceIn(0.05f, 4f) }
    fun setBrainMove(v: Float) { brain.move = v.coerceIn(0f, 1f) }
    fun setBrainMoveThr(v: Float) { brain.moveThr = v.coerceIn(0.05f, 1f) }
    fun setBrainSpeed(v: Float) { brain.speed = v.coerceIn(0f, 1f) }
    fun setBrainSpeedThr(v: Float) { brain.speedThr = v.coerceIn(0.05f, 1f) }
    fun setBrainLrFilter(v: Float) { brain.lrFilt = v.coerceIn(0f, 1f) }
    fun setBrainUdFilter(v: Float) { brain.udFilt = v.coerceIn(0f, 1f) }
    fun setBrainRandomFilter(v: Float) { brain.randomFilt = v.coerceIn(0f, 1f) }
    fun setBrainCenterFilter(v: Float) { brain.centerFilt = v.coerceIn(0f, 1f) }
    fun setBrainCornerFilter(v: Float) { brain.cornerFilt = v.coerceIn(0f, 1f) }
    fun setBrainVibFilter(v: Float) { brain.vibFilt = v.coerceIn(0f, 1f) }
    fun setBrainBipNeg(v: Float) { brain.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setBrainBipPos(v: Float) { brain.bipPosDb = v.coerceIn(0f, 120f) }

    fun setBrainAtmosphere(v: Float) { brain.atmosphere = v.coerceIn(0f, 1f) }
    fun setBrainWaveSpare(v: Float) { brain.waveSpare = v.coerceIn(0f, 1f) }
    fun setBrainAtmoBipNeg(v: Float) { brain.atmoBipNeg = v.coerceIn(-300f, 0f) }
    fun setBrainAtmoBipPos(v: Float) { brain.atmoBipPos = v.coerceIn(-300f, 300f).coerceAtLeast(0f) }
    fun setBrainParticles(v: Float) { brain.particles = v.coerceIn(0f, 1f) }
    fun setBrainBipThrNeg(v: Float) { brain.bipThrNeg = v.coerceIn(-300f, 0f) }
    fun setBrainBipThrPos(v: Float) { brain.bipThrPos = v.coerceIn(0f, 300f) }
    fun setBrainAtmoSpikeProt(v: Float) { brain.atmoSpikeProt = v.coerceIn(0f, 1f) }
    fun setBrainAtmoSpikeProtThr(v: Float) { brain.atmoSpikeProtThr = v.coerceIn(0.05f, 1f) }
    fun setAssAmbient(v: Float) { ass.ambient = v.coerceIn(0f, 1f) }
    fun setNoise3dEnabled(v: Boolean) { noise3d.enabled = v }
    fun setNoise3dRaw(v: Boolean) { noise3d.raw = v }
    fun setNoise3dDensity(v: Float) { noise3d.density = v.coerceIn(0f, 1f) }
    fun setNoise3dSize(v: Float) { noise3d.size = v.coerceIn(0f, 1f) }
    fun setNoise3dSpeed(v: Float) { noise3d.speed = v.coerceIn(0f, 1f) }
    fun setNoise3dDepth(v: Float) { noise3d.depth = v.coerceIn(0f, 1f) }
    fun setNoise3dLevel(v: Float) { noise3d.level = v.coerceIn(0f, 1f) }
    fun setBodyAtmo3dEnabled(v: Boolean) { bodyAtmo3d.enabled = v }

    fun setLegLAmbient(v: Float) { legL.ambient = v.coerceIn(0f, 1f) }
    fun setLegRAmbient(v: Float) { legR.ambient = v.coerceIn(0f, 1f) }

    fun setBrainContrast(v: Float) { brainTuning.contrast = v.coerceIn(0f, 2f) }
    fun setBrainBrightness(v: Float) { brainTuning.brightness = v.coerceIn(-1f, 1f) }
    fun setBrainContrastThr(v: Float) { brainTuning.contrastThr = v.coerceIn(0f, 1f) }
    fun setBrainBrightnessThr(v: Float) { brainTuning.brightnessThr = v.coerceIn(0f, 1f) }
    fun setBrainContrastOn(v: Boolean) { brainTuning.contrastOn = v }
    fun setBrainBrightnessOn(v: Boolean) { brainTuning.brightnessOn = v }
    fun setBrainThresholdOn(v: Boolean) { brainTuning.thresholdOn = v }
    fun setNoseContrast(v: Float) { noseTuning.contrast = v.coerceIn(0f, 2f) }
    fun setNoseBrightness(v: Float) { noseTuning.brightness = v.coerceIn(-1f, 1f) }
    fun setNoseContrastThr(v: Float) { noseTuning.contrastThr = v.coerceIn(0f, 1f) }
    fun setNoseBrightnessThr(v: Float) { noseTuning.brightnessThr = v.coerceIn(0f, 1f) }

    fun setFaceAmbient(v: Float) { face.ambient = v.coerceIn(0f, 1f) }
    fun setFaceWave(v: Float) { face.wave = v.coerceIn(0.05f, 4f) }
    fun setFaceMove(v: Float) { face.move = v.coerceIn(0f, 1f) }
    fun setFaceMoveThr(v: Float) { face.moveThr = v.coerceIn(0.05f, 1f) }
    fun setFaceSpeed(v: Float) { face.speed = v.coerceIn(0f, 1f) }
    fun setFaceSpeedThr(v: Float) { face.speedThr = v.coerceIn(0.05f, 1f) }
    fun setFaceLrFilter(v: Float) { face.lrFilt = v.coerceIn(0f, 1f) }
    fun setFaceUdFilter(v: Float) { face.udFilt = v.coerceIn(0f, 1f) }
    fun setFaceRandomFilter(v: Float) { face.randomFilt = v.coerceIn(0f, 1f) }
    fun setFaceCenterFilter(v: Float) { face.centerFilt = v.coerceIn(0f, 1f) }
    fun setFaceCornerFilter(v: Float) { face.cornerFilt = v.coerceIn(0f, 1f) }
    fun setFaceVibFilter(v: Float) { face.vibFilt = v.coerceIn(0f, 1f) }
    fun setFaceBipNeg(v: Float) { face.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setFaceBipPos(v: Float) { face.bipPosDb = v.coerceIn(0f, 120f) }

    fun setFaceAtmosphere(v: Float) { face.atmosphere = v.coerceIn(0f, 1f) }
    fun setFaceWaveSpare(v: Float) { face.waveSpare = v.coerceIn(0f, 1f) }
    fun setFaceAtmoBipNeg(v: Float) { face.atmoBipNeg = v.coerceIn(-300f, 0f) }
    fun setFaceAtmoBipPos(v: Float) { face.atmoBipPos = v.coerceIn(-300f, 300f).coerceAtLeast(0f) }
    fun setFaceParticles(v: Float) { face.particles = v.coerceIn(0f, 1f) }
    fun setFaceBipThrNeg(v: Float) { face.bipThrNeg = v.coerceIn(-300f, 0f) }
    fun setFaceBipThrPos(v: Float) { face.bipThrPos = v.coerceIn(0f, 300f) }

    fun setForeheadAmbient(v: Float) { forehead.ambient = v.coerceIn(0f, 1f) }
    fun setForeheadWave(v: Float) { forehead.wave = v.coerceIn(0.05f, 4f) }
    fun setForeheadMove(v: Float) { forehead.move = v.coerceIn(0f, 1f) }
    fun setForeheadMoveThr(v: Float) { forehead.moveThr = v.coerceIn(0.05f, 1f) }
    fun setForeheadSpeed(v: Float) { forehead.speed = v.coerceIn(0f, 1f) }
    fun setForeheadSpeedThr(v: Float) { forehead.speedThr = v.coerceIn(0.05f, 1f) }
    fun setForeheadLrFilter(v: Float) { forehead.lrFilt = v.coerceIn(0f, 1f) }
    fun setForeheadUdFilter(v: Float) { forehead.udFilt = v.coerceIn(0f, 1f) }
    fun setForeheadRandomFilter(v: Float) { forehead.randomFilt = v.coerceIn(0f, 1f) }
    fun setForeheadCenterFilter(v: Float) { forehead.centerFilt = v.coerceIn(0f, 1f) }
    fun setForeheadCornerFilter(v: Float) { forehead.cornerFilt = v.coerceIn(0f, 1f) }
    fun setForeheadVibFilter(v: Float) { forehead.vibFilt = v.coerceIn(0f, 1f) }
    fun setForeheadBipNeg(v: Float) { forehead.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setForeheadBipPos(v: Float) { forehead.bipPosDb = v.coerceIn(0f, 120f) }

    fun setForeheadAtmosphere(v: Float) { forehead.atmosphere = v.coerceIn(0f, 1f) }
    fun setForeheadWaveSpare(v: Float) { forehead.waveSpare = v.coerceIn(0f, 1f) }
    fun setForeheadAtmoBipNeg(v: Float) { forehead.atmoBipNeg = v.coerceIn(-300f, 0f) }
    fun setForeheadAtmoBipPos(v: Float) { forehead.atmoBipPos = v.coerceIn(-300f, 300f).coerceAtLeast(0f) }
    fun setForeheadParticles(v: Float) { forehead.particles = v.coerceIn(0f, 1f) }
    fun setForeheadBipThrNeg(v: Float) { forehead.bipThrNeg = v.coerceIn(-300f, 0f) }
    fun setForeheadBipThrPos(v: Float) { forehead.bipThrPos = v.coerceIn(0f, 300f) }

    fun setNoseAmbient(v: Float) { nose.ambient = v.coerceIn(0f, 1f) }
    fun setNoseWave(v: Float) { nose.wave = v.coerceIn(0.05f, 4f) }
    fun setNoseMove(v: Float) { nose.move = v.coerceIn(0f, 1f) }
    fun setNoseMoveThr(v: Float) { nose.moveThr = v.coerceIn(0.05f, 1f) }
    fun setNoseSpeed(v: Float) { nose.speed = v.coerceIn(0f, 1f) }
    fun setNoseSpeedThr(v: Float) { nose.speedThr = v.coerceIn(0.05f, 1f) }
    fun setNoseLrFilter(v: Float) { nose.lrFilt = v.coerceIn(0f, 1f) }
    fun setNoseUdFilter(v: Float) { nose.udFilt = v.coerceIn(0f, 1f) }
    fun setNoseRandomFilter(v: Float) { nose.randomFilt = v.coerceIn(0f, 1f) }
    fun setNoseCenterFilter(v: Float) { nose.centerFilt = v.coerceIn(0f, 1f) }
    fun setNoseCornerFilter(v: Float) { nose.cornerFilt = v.coerceIn(0f, 1f) }
    fun setNoseVibFilter(v: Float) { nose.vibFilt = v.coerceIn(0f, 1f) }
    fun setNoseBipNeg(v: Float) { nose.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setNoseBipPos(v: Float) { nose.bipPosDb = v.coerceIn(0f, 120f) }

    fun setNoseAtmosphere(v: Float) { nose.atmosphere = v.coerceIn(0f, 1f) }
    fun setNoseWaveSpare(v: Float) { nose.waveSpare = v.coerceIn(0f, 1f) }
    fun setNoseAtmoBipNeg(v: Float) { nose.atmoBipNeg = v.coerceIn(-300f, 0f) }
    fun setNoseAtmoBipPos(v: Float) { nose.atmoBipPos = v.coerceIn(-300f, 300f).coerceAtLeast(0f) }
    fun setNoseParticles(v: Float) { nose.particles = v.coerceIn(0f, 1f) }
    fun setNoseBipThrNeg(v: Float) { nose.bipThrNeg = v.coerceIn(-300f, 0f) }
    fun setNoseBipThrPos(v: Float) { nose.bipThrPos = v.coerceIn(0f, 300f) }

    fun setHeartAmbient(v: Float) { heart.ambient = v.coerceIn(0f, 1f) }
    fun setHeartWave(v: Float) { heart.wave = v.coerceIn(0.05f, 4f) }
    fun setHeartMove(v: Float) { heart.move = v.coerceIn(0f, 1f) }
    fun setHeartMoveThr(v: Float) { heart.moveThr = v.coerceIn(0.05f, 1f) }
    fun setHeartSpeed(v: Float) { heart.speed = v.coerceIn(0f, 1f) }
    fun setHeartSpeedThr(v: Float) { heart.speedThr = v.coerceIn(0.05f, 1f) }
    fun setHeartLrFilter(v: Float) { heart.lrFilt = v.coerceIn(0f, 1f) }
    fun setHeartUdFilter(v: Float) { heart.udFilt = v.coerceIn(0f, 1f) }
    fun setHeartRandomFilter(v: Float) { heart.randomFilt = v.coerceIn(0f, 1f) }
    fun setHeartCenterFilter(v: Float) { heart.centerFilt = v.coerceIn(0f, 1f) }
    fun setHeartCornerFilter(v: Float) { heart.cornerFilt = v.coerceIn(0f, 1f) }
    fun setHeartVibFilter(v: Float) { heart.vibFilt = v.coerceIn(0f, 1f) }
    fun setHeartBipNeg(v: Float) { heart.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setHeartBipPos(v: Float) { heart.bipPosDb = v.coerceIn(0f, 120f) }

    fun setHeartAtmosphere(v: Float) { heart.atmosphere = v.coerceIn(0f, 1f) }
    fun setHeartWaveSpare(v: Float) { heart.waveSpare = v.coerceIn(0f, 1f) }
    fun setHeartAtmoBipNeg(v: Float) { heart.atmoBipNeg = v.coerceIn(-300f, 0f) }
    fun setHeartAtmoBipPos(v: Float) { heart.atmoBipPos = v.coerceIn(-300f, 300f).coerceAtLeast(0f) }
    fun setHeartParticles(v: Float) { heart.particles = v.coerceIn(0f, 1f) }
    fun setHeartBipThrNeg(v: Float) { heart.bipThrNeg = v.coerceIn(-300f, 0f) }
    fun setHeartBipThrPos(v: Float) { heart.bipThrPos = v.coerceIn(0f, 300f) }

    fun setNeckAmbient(v: Float) { neck.ambient = v.coerceIn(0f, 1f) }
    fun setNeckWave(v: Float) { neck.wave = v.coerceIn(0.05f, 4f) }
    fun setNeckMove(v: Float) { neck.move = v.coerceIn(0f, 1f) }
    fun setNeckMoveThr(v: Float) { neck.moveThr = v.coerceIn(0.05f, 1f) }
    fun setNeckSpeed(v: Float) { neck.speed = v.coerceIn(0f, 1f) }
    fun setNeckSpeedThr(v: Float) { neck.speedThr = v.coerceIn(0.05f, 1f) }
    fun setNeckLrFilter(v: Float) { neck.lrFilt = v.coerceIn(0f, 1f) }
    fun setNeckUdFilter(v: Float) { neck.udFilt = v.coerceIn(0f, 1f) }
    fun setNeckRandomFilter(v: Float) { neck.randomFilt = v.coerceIn(0f, 1f) }
    fun setNeckCenterFilter(v: Float) { neck.centerFilt = v.coerceIn(0f, 1f) }
    fun setNeckCornerFilter(v: Float) { neck.cornerFilt = v.coerceIn(0f, 1f) }
    fun setNeckVibFilter(v: Float) { neck.vibFilt = v.coerceIn(0f, 1f) }
    fun setNeckBipNeg(v: Float) { neck.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setNeckBipPos(v: Float) { neck.bipPosDb = v.coerceIn(0f, 120f) }

    fun setNeckAtmosphere(v: Float) { neck.atmosphere = v.coerceIn(0f, 1f) }
    fun setNeckWaveSpare(v: Float) { neck.waveSpare = v.coerceIn(0f, 1f) }
    fun setNeckAtmoBipNeg(v: Float) { neck.atmoBipNeg = v.coerceIn(-300f, 0f) }
    fun setNeckAtmoBipPos(v: Float) { neck.atmoBipPos = v.coerceIn(-300f, 300f).coerceAtLeast(0f) }
    fun setNeckParticles(v: Float) { neck.particles = v.coerceIn(0f, 1f) }
    fun setNeckBipThrNeg(v: Float) { neck.bipThrNeg = v.coerceIn(-300f, 0f) }
    fun setNeckBipThrPos(v: Float) { neck.bipThrPos = v.coerceIn(0f, 300f) }

    fun setBellyAmbient(v: Float) { belly.ambient = v.coerceIn(0f, 1f) }
    fun setBellyWave(v: Float) { belly.wave = v.coerceIn(0.05f, 4f) }
    fun setBellyMove(v: Float) { belly.move = v.coerceIn(0f, 1f) }
    fun setBellyMoveThr(v: Float) { belly.moveThr = v.coerceIn(0.05f, 1f) }
    fun setBellySpeed(v: Float) { belly.speed = v.coerceIn(0f, 1f) }
    fun setBellySpeedThr(v: Float) { belly.speedThr = v.coerceIn(0.05f, 1f) }
    fun setBellyLrFilter(v: Float) { belly.lrFilt = v.coerceIn(0f, 1f) }
    fun setBellyUdFilter(v: Float) { belly.udFilt = v.coerceIn(0f, 1f) }
    fun setBellyRandomFilter(v: Float) { belly.randomFilt = v.coerceIn(0f, 1f) }
    fun setBellyCenterFilter(v: Float) { belly.centerFilt = v.coerceIn(0f, 1f) }
    fun setBellyCornerFilter(v: Float) { belly.cornerFilt = v.coerceIn(0f, 1f) }
    fun setBellyVibFilter(v: Float) { belly.vibFilt = v.coerceIn(0f, 1f) }
    fun setBellyBipNeg(v: Float) { belly.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setBellyBipPos(v: Float) { belly.bipPosDb = v.coerceIn(0f, 120f) }

    fun setBellyAtmosphere(v: Float) { belly.atmosphere = v.coerceIn(0f, 1f) }
    fun setBellyWaveSpare(v: Float) { belly.waveSpare = v.coerceIn(0f, 1f) }
    fun setBellyAtmoBipNeg(v: Float) { belly.atmoBipNeg = v.coerceIn(-300f, 0f) }
    fun setBellyAtmoBipPos(v: Float) { belly.atmoBipPos = v.coerceIn(-300f, 300f).coerceAtLeast(0f) }
    fun setBellyParticles(v: Float) { belly.particles = v.coerceIn(0f, 1f) }
    fun setBellyBipThrNeg(v: Float) { belly.bipThrNeg = v.coerceIn(-300f, 0f) }
    fun setBellyBipThrPos(v: Float) { belly.bipThrPos = v.coerceIn(0f, 300f) }

    fun setHandLAmbient(v: Float) { handL.ambient = v.coerceIn(0f, 1f) }
    fun setHandLWave(v: Float) { handL.wave = v.coerceIn(0.05f, 4f) }
    fun setHandLMove(v: Float) { handL.move = v.coerceIn(0f, 1f) }
    fun setHandLMoveThr(v: Float) { handL.moveThr = v.coerceIn(0.05f, 1f) }
    fun setHandLSpeed(v: Float) { handL.speed = v.coerceIn(0f, 1f) }
    fun setHandLSpeedThr(v: Float) { handL.speedThr = v.coerceIn(0.05f, 1f) }
    fun setHandLLrFilter(v: Float) { handL.lrFilt = v.coerceIn(0f, 1f) }
    fun setHandLUdFilter(v: Float) { handL.udFilt = v.coerceIn(0f, 1f) }
    fun setHandLRandomFilter(v: Float) { handL.randomFilt = v.coerceIn(0f, 1f) }
    fun setHandLCenterFilter(v: Float) { handL.centerFilt = v.coerceIn(0f, 1f) }
    fun setHandLCornerFilter(v: Float) { handL.cornerFilt = v.coerceIn(0f, 1f) }
    fun setHandLVibFilter(v: Float) { handL.vibFilt = v.coerceIn(0f, 1f) }
    fun setHandLBipNeg(v: Float) { handL.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setHandLBipPos(v: Float) { handL.bipPosDb = v.coerceIn(0f, 120f) }

    fun setHandLAtmosphere(v: Float) { handL.atmosphere = v.coerceIn(0f, 1f) }
    fun setHandLWaveSpare(v: Float) { handL.waveSpare = v.coerceIn(0f, 1f) }

    fun setHandRAmbient(v: Float) { handR.ambient = v.coerceIn(0f, 1f) }
    fun setHandRWave(v: Float) { handR.wave = v.coerceIn(0.05f, 4f) }
    fun setHandRMove(v: Float) { handR.move = v.coerceIn(0f, 1f) }
    fun setHandRMoveThr(v: Float) { handR.moveThr = v.coerceIn(0.05f, 1f) }
    fun setHandRSpeed(v: Float) { handR.speed = v.coerceIn(0f, 1f) }
    fun setHandRSpeedThr(v: Float) { handR.speedThr = v.coerceIn(0.05f, 1f) }
    fun setHandRLrFilter(v: Float) { handR.lrFilt = v.coerceIn(0f, 1f) }
    fun setHandRUdFilter(v: Float) { handR.udFilt = v.coerceIn(0f, 1f) }
    fun setHandRRandomFilter(v: Float) { handR.randomFilt = v.coerceIn(0f, 1f) }
    fun setHandRCenterFilter(v: Float) { handR.centerFilt = v.coerceIn(0f, 1f) }
    fun setHandRCornerFilter(v: Float) { handR.cornerFilt = v.coerceIn(0f, 1f) }
    fun setHandRVibFilter(v: Float) { handR.vibFilt = v.coerceIn(0f, 1f) }
    fun setHandRBipNeg(v: Float) { handR.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setHandRBipPos(v: Float) { handR.bipPosDb = v.coerceIn(0f, 120f) }

    fun setHandRAtmosphere(v: Float) { handR.atmosphere = v.coerceIn(0f, 1f) }
    fun setHandRWaveSpare(v: Float) { handR.waveSpare = v.coerceIn(0f, 1f) }

    fun setPussyAmbient(v: Float) { pussy.ambient = v.coerceIn(0f, 1f) }
    fun setPussyWave(v: Float) { pussy.wave = v.coerceIn(0.05f, 4f) }
    fun setPussyMove(v: Float) { pussy.move = v.coerceIn(0f, 1f) }
    fun setPussyMoveThr(v: Float) { pussy.moveThr = v.coerceIn(0.05f, 1f) }
    fun setPussySpeed(v: Float) { pussy.speed = v.coerceIn(0f, 1f) }
    fun setPussySpeedThr(v: Float) { pussy.speedThr = v.coerceIn(0.05f, 1f) }
    fun setPussyLrFilter(v: Float) { pussy.lrFilt = v.coerceIn(0f, 1f) }
    fun setPussyUdFilter(v: Float) { pussy.udFilt = v.coerceIn(0f, 1f) }
    fun setPussyRandomFilter(v: Float) { pussy.randomFilt = v.coerceIn(0f, 1f) }
    fun setPussyCenterFilter(v: Float) { pussy.centerFilt = v.coerceIn(0f, 1f) }
    fun setPussyCornerFilter(v: Float) { pussy.cornerFilt = v.coerceIn(0f, 1f) }
    fun setPussyVibFilter(v: Float) { pussy.vibFilt = v.coerceIn(0f, 1f) }
    fun setPussyBipNeg(v: Float) { pussy.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setPussyBipPos(v: Float) { pussy.bipPosDb = v.coerceIn(0f, 120f) }

    fun setPussyAtmosphere(v: Float) { pussy.atmosphere = v.coerceIn(0f, 1f) }
    fun setPussyWaveSpare(v: Float) { pussy.waveSpare = v.coerceIn(0f, 1f) }
    fun setPussyAtmoBipNeg(v: Float) { pussy.atmoBipNeg = v.coerceIn(-300f, 0f) }
    fun setPussyAtmoBipPos(v: Float) { pussy.atmoBipPos = v.coerceIn(-300f, 300f).coerceAtLeast(0f) }
    fun setPussyParticles(v: Float) { pussy.particles = v.coerceIn(0f, 1f) }
    fun setPussyBipThrNeg(v: Float) { pussy.bipThrNeg = v.coerceIn(-300f, 0f) }
    fun setPussyBipThrPos(v: Float) { pussy.bipThrPos = v.coerceIn(0f, 300f) }

    fun setDickAmbient(v: Float) { dick.ambient = v.coerceIn(0f, 1f) }
    fun setDickWave(v: Float) { dick.wave = v.coerceIn(0.05f, 4f) }
    fun setDickMove(v: Float) { dick.move = v.coerceIn(0f, 1f) }
    fun setDickMoveThr(v: Float) { dick.moveThr = v.coerceIn(0.05f, 1f) }
    fun setDickSpeed(v: Float) { dick.speed = v.coerceIn(0f, 1f) }
    fun setDickSpeedThr(v: Float) { dick.speedThr = v.coerceIn(0.05f, 1f) }
    fun setDickLrFilter(v: Float) { dick.lrFilt = v.coerceIn(0f, 1f) }
    fun setDickUdFilter(v: Float) { dick.udFilt = v.coerceIn(0f, 1f) }
    fun setDickRandomFilter(v: Float) { dick.randomFilt = v.coerceIn(0f, 1f) }
    fun setDickCenterFilter(v: Float) { dick.centerFilt = v.coerceIn(0f, 1f) }
    fun setDickCornerFilter(v: Float) { dick.cornerFilt = v.coerceIn(0f, 1f) }
    fun setDickVibFilter(v: Float) { dick.vibFilt = v.coerceIn(0f, 1f) }
    fun setDickBipNeg(v: Float) { dick.bipNegDb = v.coerceIn(-120f, 0f) }
    fun setDickBipPos(v: Float) { dick.bipPosDb = v.coerceIn(0f, 120f) }

    fun setDickAtmosphere(v: Float) { dick.atmosphere = v.coerceIn(0f, 1f) }
    fun setDickWaveSpare(v: Float) { dick.waveSpare = v.coerceIn(0f, 1f) }
    fun setDickAtmoBipNeg(v: Float) { dick.atmoBipNeg = v.coerceIn(-300f, 0f) }
    fun setDickAtmoBipPos(v: Float) { dick.atmoBipPos = v.coerceIn(-300f, 300f).coerceAtLeast(0f) }
    fun setDickParticles(v: Float) { dick.particles = v.coerceIn(0f, 1f) }
    fun setDickBipThrNeg(v: Float) { dick.bipThrNeg = v.coerceIn(-300f, 0f) }
    fun setDickBipThrPos(v: Float) { dick.bipThrPos = v.coerceIn(0f, 300f) }

    fun triggerSpike() {
        eyes.ambient = 1f; brain.ambient = 1f; heart.ambient = 1f
        invalidate()
    }

    fun meanAmbient(): Float {
        val list = listOf(eyes, brain, heart, neck, belly, handL, handR, pussy, dick)
        return list.map { it.effectiveAmbient() }.average().toFloat().coerceIn(0f, 1f)
    }

    fun meanWave(): Float {
        val list = listOf(eyes, brain, heart, neck, belly, handL, handR, pussy, dick)
        return list.map { it.wave }.average().toFloat().coerceIn(0.05f, 4f)
    }

    private fun drawRegionRing(
        canvas: Canvas, baseCx: Float, baseCy: Float, r: Region, baseHue: Int, phaseOff: Float,
        radiusScale: Float = 1f, strokeOnly: Boolean = false
    ) {
        val amb = r.effectiveAmbient()
        val mag = r.moveMag()
        val spd = r.speedMag()
        val lrf = r.lrFilt * lrFilter
        val udf = r.udFilt * udFilter
        val rnd = r.randomFilt * randomFilter
        val ctr = r.centerFilt * centerFilter
        val cor = r.cornerFilt * cornerFilter
        val vib = r.vibFilt * vibFreqFilter
        val w = width.toFloat()
        val h = height.toFloat()
        val rs = radiusScale.coerceIn(0.02f, 1f)
        val vibOsc = sin(phase * (0.05f + vib * 0.35f)) * 18f * vib * rs
        val rndX = sin(phase * 0.11f + baseCx * 0.01f) * 30f * rnd * rs
        val rndY = cos(phase * 0.13f + baseCy * 0.01f) * 24f * rnd * rs
        val corX = sin(phase * 0.02f) * 50f * cor * rs
        val corY = cos(phase * 0.02f) * 40f * cor * rs
        val ctrPullX = (w / 2f - baseCx) * 0.15f * ctr * rs
        val ctrPullY = (h / 2f - baseCy) * 0.15f * ctr * rs
        val cx = baseCx + sin(phase * 0.04f * r.wave * (0.5f + spd)) * 40f * mag * lrf * rs + rndX + corX + ctrPullX + vibOsc
        val cy = baseCy + cos(phase * 0.03f * r.wave * (0.5f + spd)) * 25f * mag * udf * rs + rndY + corY + ctrPullY
        val alphaBase = (40 + amb * 100).toInt().coerceIn(20, 160)
        val oldStyle = paint.style
        val oldStroke = paint.strokeWidth
        if (strokeOnly) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = (0.8f + amb * 1.2f).coerceIn(0.8f, 2f)
        }
        for (i in 0 until 8) {
            val radius = (20f + i * 12f + sin(phase * 0.02f * r.wave + phaseOff + i) * 6f * amb) * rs
            val red = minOf(255, baseHue + (amb * 40).toInt() + micVariation(30))
            val g = minOf(255, 180 + (r.wave * 20).toInt())
            val b = minOf(255, 100 + i * 8)
            paint.color = Color.argb(alphaBase, red, g, b)
            canvas.drawCircle(cx, cy, radius, paint)
        }
        if (strokeOnly) {
            paint.style = oldStyle
            paint.strokeWidth = oldStroke
        }
    }


    private fun drawRegionParticles(canvas: Canvas, cx: Float, cy: Float, level: Float, color: Int) {
        val lv = level.coerceIn(0f, 1f)
        if (lv < 0.05f) return
        val n = (3 + (lv * 12).toInt()).coerceIn(3, 16)
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        p.style = android.graphics.Paint.Style.FILL
        val t = (System.currentTimeMillis() % 10000L) / 1000f
        for (i in 0 until n) {
            val a = (i * 2.399f + t * (0.6f + lv)) 
            val r = 8f + lv * 28f * (0.4f + (i % 5) * 0.12f)
            val x = cx + kotlin.math.cos(a) * r
            val y = cy + kotlin.math.sin(a * 1.3f) * r * 0.7f
            val alpha = (40 + lv * 140).toInt().coerceIn(20, 200)
            p.color = (alpha shl 24) or (color and 0x00FFFFFF)
            canvas.drawCircle(x, y, 1.5f + lv * 2.2f, p)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!active) return
        val feedback = videoFeedbackBoard
        if (feedback.enabled && width > 0 && height > 0 &&
            (feedback.loopActive() || !feedback.levelsNeutral() || feedback.isBlackout())) {
            feedback.renderLoop(canvas, width, height) { frame -> drawScene(frame) }
        } else {
            drawScene(canvas)
        }
    }

    private fun drawScene(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val detected = cameraDetection
        val liveHuman = cameraBodyTrackOn && detected.modelReady && detected.hasPerson && detected.isFresh()
        val feedback = videoFeedbackBoard
        val movement = virtualMovementBoards.tick(
            VirtualMovementControlBoard.Inputs(
                micRms = feedback.audioRms,
                centroid = feedback.audioCentroid,
                deviceMove = motionHub?.liveMove ?: 0f,
                deviceSpeed = motionHub?.liveSpeed ?: 0f,
                cameraMove = feedback.camMotion,
                cameraWave = feedback.camWave,
                timeSeconds = android.os.SystemClock.elapsedRealtime() / 1000f
            )
        )
        try { virtualMovementBoards.apply(this) } catch (_: Throwable) {}
        // AMBIENT MOVEMENT (outside): the whole body moves; locked mode keeps the body fixed
        val mvB = ambientBoard.movement
        val mvDx = if (mvB.on && mvB.outsideOn && !bodyLocked) mvB.outsideDx else 0f
        val mvDy = if (mvB.on && mvB.outsideOn && !bodyLocked) mvB.outsideDy else 0f
        val modelCx = (if (liveHuman) w * detected.centerX else w * (anatomy3d.posX + cenDx() + mvDx)) +
            w * movement.modelX * 0.20f
        val hoverOffset = sin(phase * 0.025f * movement.hoverSpeed.coerceIn(0f, 8f)) * h * 0.008f
        val modelCy = (if (liveHuman) h * detected.centerY
            else h * (anatomy3d.posY + bodyMotion.vOffset + cenDy() + mvDy)) +
            h * movement.modelY * 0.12f + hoverOffset
        val baseModelSize = if (liveHuman) {
            (detected.boxHeight * 1.16f).coerceIn(0.18f, 1.2f)
        } else anatomy3d.size
        val modelSize = (baseModelSize * (1f + movement.warpFactor.coerceIn(0f, 2f) * 0.16f))
            .coerceIn(0.18f, 1.2f)
        val mixAmb = meanAmbient()
        val mixWave = meanWave()
        val uiFac = uiBlocker?.driveFactor() ?: 1f
        val g = systemGuard
        val drawScale = g?.drawScale() ?: 1f
        val clamped = armor.clampSpikeMagnitude(mixAmb) * uiFac * drawScale
        regionFx.tick(clamped)
        body84.tick(clamped)
        try { body84.apply(this) } catch (_: Throwable) {}
        val cameraPerson = detected.modelReady && detected.hasPerson && detected.isFresh()
        val poseEnergy = if (cameraPerson) detected.poseConfidence else 0f
        val cameraDb = if (cameraPerson) -120.0 + detected.confidence.coerceIn(0f, 1f) * 240.0 else -120.0
        poseSurface.tick(poseEnergy, cameraDb, cameraPerson)
        try { poseSurface.apply(this) } catch (_: Throwable) {}
        yoloSeg.feedDetection(if (cameraPerson) detected else HumanDetection.none("No live person", yoloSeg.modelReady))
        yoloSeg.tick(0f, cameraDb)
        bodySurfaceGpu.tick(clamped, body84, poseSurface, motionHub)
        try { bodySurfaceGpu.apply(this) } catch (_: Throwable) {}
        bodyMixer.tick(
            clamped, cameraDb,
            body84 = body84.avgOut,
            pose = poseSurface.dampen(),
            yolo = yoloSeg.dampen(),
            armor = if (armor.hardwareShieldOn) armor.hardwareLv else 0f,
            region = (1f - regionFx.regionScale()).coerceIn(0f, 1f),
            yoloSegOuts = FloatArray(yoloSeg.segments.size) { i -> yoloSeg.segments[i].out }
        )
        // Eyes + brows feed body mixer as extra energy when eyeMixOn
        if (eyeMixOn) {
            val eyeE = ((eyeL.effectiveAmbient() + eyeR.effectiveAmbient()) * 0.5f *
                eyeMixW.coerceIn(0f, 1f)).coerceIn(0f, 1f)
            val browE = ((browL.effectiveAmbient() + browR.effectiveAmbient()) * 0.5f * 0.35f)
            bodyMixer.mixedE = maxOf(bodyMixer.mixedE, (eyeE + browE).coerceIn(0f, 1f))
        }
        if (lipMixOn) {
            val lipE = ((lipU.effectiveAmbient() + lipL.effectiveAmbient() + tongue.effectiveAmbient()) / 3f *
                lipMixW.coerceIn(0f, 1f)).coerceIn(0f, 1f)
            bodyMixer.mixedE = maxOf(bodyMixer.mixedE, lipE)
        }
        // All body regions → model mix (full human 3D, not single)
        val regionMix = (
            face.effectiveAmbient() * 0.12f +
            forehead.effectiveAmbient() * 0.08f +
            nose.effectiveAmbient() * 0.06f +
            brain.effectiveAmbient() * 0.10f +
            heart.effectiveAmbient() * 0.12f +
            neck.effectiveAmbient() * 0.08f +
            belly.effectiveAmbient() * 0.10f +
            handL.effectiveAmbient() * 0.07f +
            handR.effectiveAmbient() * 0.07f +
            pussy.effectiveAmbient() * 0.05f +
            dick.effectiveAmbient() * 0.05f +
            ass.effectiveAmbient() * 0.05f +
            legL.effectiveAmbient() * 0.06f +
            legR.effectiveAmbient() * 0.06f
        ).coerceIn(0f, 1f)
        bodyMixer.mixedE = maxOf(bodyMixer.mixedE, regionMix * 0.55f)
        // Body-region ambient system + rescan (multi, not single)
        val regionBoost = bodyRegionAmbientBoost.coerceIn(0f, 1f)
        if (regionBoost > 0.01f) {
            bodyMixer.mixedE = maxOf(bodyMixer.mixedE, (regionMix + regionBoost * 0.4f).coerceIn(0f, 1f))
        }
        if (bodyRegionRescanOn) {
            val parts = listOf(
                eyes.effectiveAmbient(), eyeL.effectiveAmbient(), eyeR.effectiveAmbient(),
                browL.effectiveAmbient(), browR.effectiveAmbient(),
                face.effectiveAmbient(), forehead.effectiveAmbient(), nose.effectiveAmbient(),
                lipU.effectiveAmbient(), lipL.effectiveAmbient(), tongue.effectiveAmbient(),
                brain.effectiveAmbient(), heart.effectiveAmbient(), neck.effectiveAmbient(),
                belly.effectiveAmbient(), handL.effectiveAmbient(), handR.effectiveAmbient(),
                pussy.effectiveAmbient(), dick.effectiveAmbient(), ass.effectiveAmbient(), legL.effectiveAmbient(), legR.effectiveAmbient()
            )
            bodyRegionActiveN = parts.count { it > 0.08f }
            bodyRegionRescanOut = (parts.sum() / parts.size.coerceAtLeast(1)).coerceIn(0f, 1f)
            bodyMixer.mixedE = maxOf(bodyMixer.mixedE, bodyRegionRescanOut * 0.35f)
        }
        // Brain 3D L/R + anatomy inside/outside (multi, not single) → model mix
        run {
            val amb = clamped
            val mid = (soundBank.dbLimitOut * 0.5f + soundBank.ambLimitOut * 0.5f).coerceIn(0f, 1f)
            val high = cameraVhs.contrastOut.coerceIn(0f, 1f)
            val bass = soundBank.dbLimitOut.coerceIn(0f, 1f)
            val motion = motionHub?.liveMove ?: 0f
            val cam = cameraVhs.brightnessOut.coerceIn(0f, 1f)
            brain3d.tick(
                ambient = amb,
                audioRms = mid,
                audioLow = bass,
                audioMid = mid,
                audioHigh = high,
                camera = cam,
                motion = motion,
                model = bodyMixer.mixedE
            )
            brain3d.linkEyes(eyeTuning)
            anatomy3d.tick(bodyMixer.insideOut, bodyMixer.outsideOut)
            try { anatomy3d.apply(this) } catch (_: Throwable) {}
            anatomy3d.insideFx.rawEverything = oneness.rawEverything
            anatomy3d.insideFx.tick(ambientBoardRef)
            anatomy3d.insideFx.bodyLocked = bodyLocked
            ambientBoard.movement.rawEverything = oneness.rawEverything
            ambientBoard.movement.tick(ambientBoard, this)
            anatomy3d.moveFx = ambientBoard.movement
            val pgt = pitchGuard
            ringBoard.tick(
                this, clamped, regionFx.regionScale() * soundBank.outScale(), anatomy3d,
                pgt?.scaleL() ?: 1f, pgt?.scaleR() ?: 1f
            )
            val brainMix = ((brain3d.left.out + brain3d.right.out) * 0.5f).coerceIn(0f, 1f)
            bodySoundFx.feedBrainIntensity(brainMix)
            bodyMixer.mixedE = maxOf(bodyMixer.mixedE, brainMix * 0.5f)
        }

        screenAmbient.body84Link = body84.avgOut
        soundBank.feedMicModel(bodyMixer.mixedE.coerceIn(0f, 1f))
        echoProtect.tick(
            enemyEnergy = maxOf(soundBank.micEnemyOut, soundBank.enemyBodyOut, soundBank.mixEnergy * 0.5f),
            knifeOut = soundBank.knifeOut,
            modelDrive = bodyMixer.mixedE.coerceIn(0f, 1f)
        )
        eyesAmbient.tick(
            micEnergy = soundBank.liveAudioEnergy,
            modelDrive = bodyMixer.mixedE.coerceIn(0f, 1f),
            motion = soundBank.protectMoveFactor.let { 1f - it }.coerceIn(0f, 1f),
            wave = soundBank.protectWaveFactor.let { 1f - it }.coerceIn(0f, 1f),
            speed = soundBank.protectSpeedFactor.let { 1f - it }.coerceIn(0f, 1f)
        )
        try { eyesAmbient.apply(this) } catch (_: Throwable) {}
        finalAnatomy.tick(
            micEnergy = soundBank.liveAudioEnergy,
            modelDrive = bodyMixer.mixedE.coerceIn(0f, 1f)
        )
        try { finalAnatomy.apply(this) } catch (_: Throwable) {}
        finalTabs.tick(
            micEnergy = soundBank.liveAudioEnergy,
            modelDrive = bodyMixer.mixedE.coerceIn(0f, 1f),
            domHz = soundBank.liveDominantHz
        )
        try { finalTabs.apply(soundBank, this) } catch (_: Throwable) {}
        monoEyes.tick(soundBank.liveAudioEnergy, bodyMixer.mixedE.coerceIn(0f, 1f))
        try { monoEyes.apply(this) } catch (_: Throwable) {}
        cnsEyesHeart.tick(soundBank.liveAudioEnergy, bodyMixer.mixedE.coerceIn(0f, 1f))
        cnsEyesHeart.applyToShield(this)
        poseSegEyeBody.tick(soundBank.liveAudioEnergy, bodyMixer.mixedE.coerceIn(0f, 1f))
        poseSegEyeBody.applyToEyes(cnsEyesHeart, this)
        fullModel3d.tick(soundBank.liveAudioEnergy, bodyMixer.mixedE.coerceIn(0f, 1f))
        fullModel3d.applyToShield(this)
        bodyIsolation.tick(soundBank.liveAudioEnergy, maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut))
        bodyIsolation.apply(soundBank, this)
        val arMot = if (arMeasure.sessionRunning) arMeasure.trackingQuality else 0f
        body3dModelInteract.tick(
            soundBank.liveAudioEnergy,
            bodyMixer.mixedE.coerceIn(0f, 1f),
            maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut),
            arMot
        )
        body3dModelInteract.apply(this, soundBank)
        skinAtomspare.tick(soundBank.liveAudioEnergy, 1f, humanDetected = true)
        skinAtomspare.applyToAtmosphere(bodyAtmo3d)
        skinAtomspare.applyToSoundBank(soundBank)
        anatomyShell.tick(
            soundBank.liveAudioEnergy, 1f,
            maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut)
        )
        anatomyShell.apply(soundBank, skinAtomspare)
        enemy3dProtect.tick(
            soundBank.liveAudioEnergy,
            maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut),
            soundBank.enemyBodyMove,
            soundBank.enemyBodySpeed
        )
        enemy3dProtect.apply(soundBank)
        body84FullHuman.tick(soundBank.liveAudioEnergy, 1f)
        ultraWeapon.tick(
            soundBank.liveAudioEnergy,
            soundBank.liveCentroidHz,
            soundBank.liveRmsDbfs.toFloat(),
            soundBank.liveRmsDbfs.toFloat()
        )
        ultraWeapon.apply(soundBank)
        frontSideAmbient.tick(
            soundBank.liveAudioEnergy,
            try { eyeL.ambient } catch (_: Throwable) { 0f },
            try { eyeR.ambient } catch (_: Throwable) { 0f },
            try { maxOf(face.ambient, heart.ambient, belly.ambient) } catch (_: Throwable) { soundBank.liveAudioEnergy }
        )
        frontSideAmbient.apply(this)
        hairBullet.tick(
            soundBank.liveAudioEnergy,
            1f,
            maxOf(soundBank.bulletOut, soundBank.burstOut)
        )
        hairBullet.apply(this, soundBank)
        completeAtomProtect.tick(
            soundBank.liveAudioEnergy,
            maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut)
        )
        completeAtomProtect.apply(this, soundBank)
        bodyFreqRegen.micE = soundBank.liveAudioEnergy
        bodyFreqRegen.modelE = try { body84FullHuman.modelMixOut } catch (_: Throwable) { soundBank.liveAudioEnergy * 0.5f }
        bodyFreqRegen.sensorE = try { bodyAtmo3d.input } catch (_: Throwable) { 0f }
        bodyFreqRegen.cameraE = soundBank.cameraFocusEnergy
        bodyFreqRegen.liveCentroidHz = soundBank.liveCentroidHz
        bodyFreqRegen.tick()
        bodyFreqRegen.apply(this, soundBank)
        complete3dNoMiss.apply(this)
        eyesHeartBelly.tick(soundBank.liveAudioEnergy)
        eyesHeartBelly.apply(this)
        faceEyeNoise.tick(soundBank.liveAudioEnergy)
        faceEyeNoise.apply(this, soundBank)
        moreMissed.tick(soundBank.liveAudioEnergy)
        moreMissed.apply(this)
        fullBodyAnatomy.tick(soundBank.liveAudioEnergy)
        fullBodyAnatomy.apply(this)
        sharpBurstMeter.tick(
            soundBank.liveAudioEnergy,
            maxOf(soundBank.liveDetectedHzUnlimited, soundBank.liveDominantHz),
            soundBank.liveCentroidHz,
            soundBank.liveRmsDbfs.toFloat(),
            soundBank.sharpOut,
            soundBank.burstOut,
            soundBank.knifeOut,
            soundBank.bulletOut,
            soundBank.liveAudioEnergy * (soundBank.liveCentroidHz / 5000f).coerceIn(0f, 1f),
            maxOf(soundBank.burstOut, soundBank.sharpOut)
        )
        sharpBurstMeter.apply(soundBank, this)
        liveMicEnemyAll.tick(
            soundBank.liveAudioEnergy,
            soundBank.enemyBodyOut,
            soundBank.micEnemyOut,
            soundBank.knifeOut,
            soundBank.bulletOut,
            soundBank.burstOut,
            soundBank.sharpOut,
            maxOf(soundBank.whipOut, soundBank.rippleOut, soundBank.collideOut),
            soundBank.liveRmsDbfs.toFloat()
        )
        liveMicEnemyAll.apply(soundBank, this)
        enemySoundCancel.tick(
            soundBank.burstOut,
            soundBank.knifeOut,
            soundBank.bulletOut,
            soundBank.sharpOut,
            soundBank.whipOut,
            soundBank.rippleOut,
            soundBank.collideOut,
            soundBank.enemyBodyOut,
            soundBank.micEnemyOut,
            try { completeAtomProtect.atomOut } catch (_: Throwable) { soundBank.liveAudioEnergy }
        )
        enemySoundCancel.apply(soundBank, this)
        allBodySkinAnatomy.tick(soundBank.liveAudioEnergy)
        allBodySkinAnatomy.apply(this)
        run {
            val poseE = try { body84FullHuman.poseOut } catch (_: Throwable) { 0f }
            val segE = try { body84FullHuman.segmentOut } catch (_: Throwable) { 0f }
            val obbE = try { body84FullHuman.obbOut } catch (_: Throwable) { 0f }
            val mv = try { body84FullHuman.moveOut } catch (_: Throwable) { soundBank.liveAudioEnergy }
            val sp = try { body84FullHuman.speedOut } catch (_: Throwable) { soundBank.liveAudioEnergy }
            val wv = try { body84FullHuman.waveOut } catch (_: Throwable) { soundBank.liveAudioEnergy }
            skinMultiMotion.tick(soundBank.liveAudioEnergy, poseE, segE, obbE, mv, sp, wv)
            skinMultiMotion.apply(this)
        skinSoundsProtect.tick(
            soundBank.bulletOut,
            soundBank.knifeOut,
            soundBank.sharpOut,
            soundBank.burstOut,
            try { liveMicEnemyAll.pitchSoundsOut } catch (_: Throwable) { soundBank.liveAudioEnergy * 0.5f },
            try { maxOf(completeAtomProtect.atomOut, soundBank.collideOut) } catch (_: Throwable) { soundBank.burstOut },
            soundBank.liveAudioEnergy
        )
        skinSoundsProtect.apply(soundBank, this)
        bioSkinCell.tick(soundBank.liveAudioEnergy)
        bioSkinCell.apply(this)
        bodyChemBrain.tick(soundBank.liveAudioEnergy)
        bodyChemBrain.apply(this)
        run {
            val modelE = try {
                maxOf(body84FullHuman.poseOut, body84FullHuman.segmentOut, body84FullHuman.obbOut)
            } catch (_: Throwable) { soundBank.liveAudioEnergy }
            val ax = try { soundBank.axisX } catch (_: Throwable) { soundBank.liveAudioEnergy * 0.3f }
            val ay = try { soundBank.axisY } catch (_: Throwable) { soundBank.liveAudioEnergy * 0.3f }
            val az = try { soundBank.axisZ } catch (_: Throwable) { soundBank.liveAudioEnergy * 0.3f }
            val vibe = try { soundBank.vibeOut } catch (_: Throwable) { maxOf(ax, ay, az) }
            val w = try { bodyFreqRegen.bleWatt } catch (_: Throwable) { 0f }
            mgBleScaleWatt.tick(soundBank.liveAudioEnergy, modelE, ax, ay, az, vibe, w)
            mgBleScaleWatt.apply(this)
        run {
            val modelE = try {
                maxOf(body84FullHuman.poseOut, body84FullHuman.segmentOut, body84FullHuman.obbOut)
            } catch (_: Throwable) { soundBank.liveAudioEnergy }
            val mg = try { mgBleScaleWatt.mgOut } catch (_: Throwable) { 0f }
            val enemy = try {
                maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut, soundBank.bulletOut, soundBank.knifeOut)
            } catch (_: Throwable) { 0f }
            val water = try { bodyChemBrain.water } catch (_: Throwable) { soundBank.liveAudioEnergy * 0.8f }
            val skin = try { allBodySkinAnatomy.allSkinOut } catch (_: Throwable) { soundBank.liveAudioEnergy * 0.7f }
            val cells = try { bioSkinCell.nucleus } catch (_: Throwable) { soundBank.liveAudioEnergy * 0.6f }
            caMgProtectChem.tick(soundBank.liveAudioEnergy, modelE, mg, enemy, water, skin, cells)
            caMgProtectChem.apply(soundBank, this)
        run {
            val mineral = try { bodyChemBrain.mineral } catch (_: Throwable) { 0f }
            val ca = try { bodyChemBrain.calcium } catch (_: Throwable) { 0f }
            val phase = System.nanoTime() * 1e-9f
            skeletonWaterAstro.tick(soundBank.liveAudioEnergy, mineral, ca, phase)
            skeletonWaterAstro.apply(this)
        run {
            val skin = try { maxOf(allBodySkinAnatomy.allSkinOut, allBodySkinAnatomy.completeSkinCoverage) } catch (_: Throwable) { 0f }
            val hz = try { sharpBurstMeter.detectedHz } catch (_: Throwable) { 0f }
            val astro = try { skeletonWaterAstro.astroOut } catch (_: Throwable) { 0f }
            val aOut = try { completeAtomProtect.atomOutsideOut } catch (_: Throwable) { 0f }
            val aIn = try { completeAtomProtect.atomInsideOut } catch (_: Throwable) { 0f }
            val mv = try { skinMultiMotion.moveOut } catch (_: Throwable) { 0f }
            val sp = try { skinMultiMotion.speedOut } catch (_: Throwable) { 0f }
            val wv = try { skinMultiMotion.waveOut } catch (_: Throwable) { 0f }
            val pt = try { liveMicEnemyAll.pitchSoundsOut } catch (_: Throwable) { soundBank.liveAudioEnergy * 0.5f }
            val sk = try { soundBank.burstOut } catch (_: Throwable) { 0f }
            val bag = try {
                maxOf(
                    bioSkinCell.bioFullOut,
                    bodyChemBrain.chemFullOut,
                    bodyChemBrain.brainFullOut,
                    caMgProtectChem.protectFullOut,
                    skeletonWaterAstro.skeletonFull
                )
            } catch (_: Throwable) { soundBank.liveAudioEnergy }
            fullAmbientMaster.tick(
                soundBank.liveAudioEnergy, skin, hz, astro, aOut, aIn,
                mv, sp, wv, pt, sk, bag
            )
            fullAmbientMaster.apply(this)
        bodyRegionEnemyProtect.tick(
            soundBank.liveAudioEnergy,
            soundBank.knifeOut,
            maxOf(soundBank.bulletOut, soundBank.collideOut),
            soundBank.burstOut,
            maxOf(soundBank.sharpOut, try { fullAmbientMaster.spikeOut } catch (_: Throwable) { 0f }),
            try { liveMicEnemyAll.pitchSoundsOut } catch (_: Throwable) { soundBank.liveAudioEnergy * 0.4f },
            try { mgBleScaleWatt.vibeOut } catch (_: Throwable) { 0f },
            maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut)
        )
        bodyRegionEnemyProtect.apply(soundBank, this)
        antiAtomspareSounds.tick(
            soundBank.liveAudioEnergy,
            try { completeAtomProtect.atomOutsideOut } catch (_: Throwable) { 0f },
            try { completeAtomProtect.atomInsideOut } catch (_: Throwable) { 0f },
            try { fullAmbientMaster.spikeOut } catch (_: Throwable) { soundBank.burstOut },
            soundBank.collideOut,
            soundBank.rippleOut,
            maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut)
        )
        antiAtomspareSounds.apply(soundBank, this)
        earAuditoryLine.tick(soundBank.liveAudioEnergy)
        earAuditoryLine.apply(this)
        eyesCompleteLock.tick(
            soundBank.liveAudioEnergy,
            maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut),
            try { allBodySkinAnatomy.eyeSkinL } catch (_: Throwable) { 0f },
            try { allBodySkinAnatomy.eyeSkinR } catch (_: Throwable) { 0f }
        )
        eyesCompleteLock.apply(soundBank, this)
        fullBodyMotionLock.tick(
            soundBank.liveAudioEnergy,
            maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut),
            try { eyesCompleteLock.eyeMoveBlocked } catch (_: Throwable) { 0f }
        )
        fullBodyMotionLock.apply(soundBank, this)
        enemySoundCounters.tick(
            soundBank.liveAudioEnergy,
            soundBank.burstOut,
            soundBank.bulletOut,
            soundBank.knifeOut,
            soundBank.sharpOut,
            maxOf(soundBank.rippleOut, soundBank.collideOut),
            maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut),
            soundBank.whipOut,
            // mic axis X/Y/Z — use bank spatial if present else equal
            0.34f,
            0.33f,
            0.33f
        )
        enemySoundCounters.apply(soundBank, this)
        soundDetectBodyTrack.tick(
            soundBank.liveAudioEnergy,
            soundBank.burstOut,
            soundBank.bulletOut,
            soundBank.knifeOut,
            soundBank.sharpOut,
            maxOf(soundBank.rippleOut, soundBank.collideOut),
            maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut)
        )
        soundDetectBodyTrack.apply(this)
        micLiveAmbientMixer.tick(soundBank.liveAudioEnergy)
        micLiveAmbientMixer.apply(this)
        fullSkeletonBone.tick(
            soundBank.liveAudioEnergy,
            maxOf(soundBank.enemyBodyOut, soundBank.micEnemyOut),
            soundBank.burstOut,
            soundBank.bulletOut,
            soundBank.knifeOut,
            try { fullAmbientMaster.spikeOut } catch (_: Throwable) { soundBank.sharpOut }
        )
        fullSkeletonBone.apply(soundBank, this)
        finalProtectionMain.tick(
            soundBank.liveAudioEnergy,
            soundBank.burstOut,
            soundBank.bulletOut,
            soundBank.knifeOut,
            soundBank.whipOut,
            try { fullAmbientMaster.moveOut } catch (_: Throwable) { 0f },
            try { fullAmbientMaster.speedOut } catch (_: Throwable) { 0f },
            try { fullAmbientMaster.waveOut } catch (_: Throwable) { 0f },
            try { eyesCompleteLock.eyesFullOut } catch (_: Throwable) { 0f },
            try { bodyChemBrain.brainFullOut } catch (_: Throwable) { 0f },
            try { earAuditoryLine.earLineFull } catch (_: Throwable) { 0f },
            try { allBodySkinAnatomy.allSkinOut } catch (_: Throwable) { 0f },
            try { bodyChemBrain.chemFullOut } catch (_: Throwable) { 0f }
        )
        finalProtectionMain.apply(soundBank, this)
        fullAnatomy132.tick(
            soundBank.liveAudioEnergy,
            try { bodyChemBrain.brainFullOut } catch (_: Throwable) { 0f },
            try { eyesCompleteLock.eyesFullOut } catch (_: Throwable) { 0f },
            try { earAuditoryLine.earLineFull } catch (_: Throwable) { 0f },
            try { allBodySkinAnatomy.allSkinOut } catch (_: Throwable) { 0f },
            try { finalProtectionMain.heartOut } catch (_: Throwable) { 0f }
        )
        fullAnatomy132.apply(this)
        sensorGatedSfx.tick(soundBank.liveAudioEnergy)
        sensorGatedSfx.apply(soundBank, this)
        cameraArMeshWorld.tick()
        cameraArMeshWorld.apply(this)
        cameraExclusiveGuard.tick(arMeasure.sessionRunning, false, arMeasure.lastError)
        try { cameraExclusiveGuard.apply(this) } catch (_: Throwable) {}
        val micN = try { soundBank.liveAudioEnergy.coerceIn(0f, 1.5f) } catch (_: Throwable) { 0.2f }
        val heartIn = try { cnsEyesHeart.heartOut } catch (_: Throwable) { 0.2f }
        val cardioIn = try { fullAnatomy132.cardioOut } catch (_: Throwable) { 0.2f }
        heartInsideFull.tick(micN, heartIn, cardioIn)
        heartInsideFull.apply(this)
        val brainIn = try { fullAnatomy132.brainOut } catch (_: Throwable) { 0.2f }
        val cnsIn = try { fullAnatomy132.brainOut } catch (_: Throwable) { 0.2f }
        neuralNeuroTx.tick(micN, brainIn, cnsIn)
        neuralNeuroTx.apply(this)
        val poseN = try { maxOf(poseSegEyeBody.poseEyeLGroup, poseSegEyeBody.poseEyeRGroup, body84FullHuman.poseOut) } catch (_: Throwable) { 0.2f }
        val segN = try { maxOf(poseSegEyeBody.segFullBody, body84FullHuman.segmentOut) } catch (_: Throwable) { 0.2f }
        val obbN = try { body84FullHuman.outsideOut } catch (_: Throwable) { 0.2f }
        val e3d = try { enemy3dProtect.enemyModelOut } catch (_: Throwable) { 0.2f }
        enemySameBody.tick(micN, poseN, segN, obbN, e3d)
        enemySameBody.apply(this)
        val skinN = try { allBodySkinAnatomy.fullBodySkinOut } catch (_: Throwable) { 0.2f }
        val chemN = try { caMgProtectChem.chemOut } catch (_: Throwable) { 0.2f }
        waterFullBody.tick(micN, skinN, chemN)
        waterFullBody.apply(this)
        val bodyN = try { fullAnatomy132.bodyPartsOut } catch (_: Throwable) { 0.2f }
        reproAnatomy.tick(micN, bodyN)
        reproAnatomy.apply(this)
        val detHz = try { sharpBurstMeter.detectedHz } catch (_: Throwable) { 0f }
        val sbB = try { soundBank.bulletOut } catch (_: Throwable) { 0f }
        val sbBr = try { soundBank.burstOut } catch (_: Throwable) { 0f }
        pointerBulletLinear.tick(micN, sbB, sbBr, detHz)
        pointerBulletLinear.apply(soundBank, this)
        try {
            val kn = try { soundBank.knifeOut } catch (_: Throwable) { 0f }
            val sh = try { soundBank.sharpOut } catch (_: Throwable) { 0f }
            bodyRegionBulletAtom.tick(micN, sbB, sbBr, kn, sh)
            bodyRegionBulletAtom.apply(soundBank, this)
            val eL = try { cnsEyesHeart.eyeLOut } catch (_: Throwable) { 0.2f }
            val eR = try { cnsEyesHeart.eyeROut } catch (_: Throwable) { 0.2f }
            val hrt = try { cnsEyesHeart.heartOut } catch (_: Throwable) { 0.2f }
            val brn = try { fullAnatomy132.brainOut } catch (_: Throwable) { 0.2f }
            val fac = try { faceEyeNoise.faceOut } catch (_: Throwable) { 0.2f }
            eyeCanthusHeartBrain.tick(micN, eL, eR, hrt, brn, fac)
            eyeCanthusHeartBrain.apply(this)
            val bleW = try { mgBleScaleWatt.mgOut } catch (_: Throwable) { 0.2f }
            val mod = try { enemy3dProtect.enemyModelOut } catch (_: Throwable) { 0.2f }
            enemyBleScaleTrack.tick(micN, bleW, mod)
            enemyBleScaleTrack.apply(this)
            val wtr = try { waterFullBody.waterFull } catch (_: Throwable) { 0.2f }
            waterWarfareAmbient.tick(micN, wtr, bleW, mod)
            waterWarfareAmbient.apply(this)
            enemyBodySprayPrank.tick(micN, bleW, mod, mod)
            enemyBodySprayPrank.apply(soundBank, this)
            try {
                val ownB = try { mgBleScaleWatt.mgOut } catch (_: Throwable) { 0.2f }
                val enB = try { enemyBleScaleTrack.enemyScaleOut } catch (_: Throwable) { 0f }
                val enA = try { soundBank.enemyBodyOut } catch (_: Throwable) { 0f }
                bleEnemyAmbientBlock.tick(ownB, enB, micN, enA)
                bleEnemyAmbientBlock.apply(soundBank, this)
            try {
                bleScaleLibrary?.applyToBoards(mgBleScaleWatt, enemyBleScaleTrack, bleEnemyAmbientBlock)
                fullProtectionBle.tick(
                    bleEnemyAmbientBlock.bleAmbientBlockOut,
                    try { soundBank.bulletOut } catch (_: Throwable) { 0f },
                    try { soundBank.burstOut } catch (_: Throwable) { 0f },
                    try { soundBank.knifeOut } catch (_: Throwable) { 0f },
                    try { soundBank.enemyBodyOut } catch (_: Throwable) { 0f },
                    try { enemyBleScaleTrack.enemyScaleOut } catch (_: Throwable) { 0f },
                    bleScaleLibrary?.presenceEnergy ?: 0f
                )
                fullProtectionBle.apply(soundBank, this)
            try {
                val bleP = bleScaleLibrary?.presenceEnergy ?: try { mgBleScaleWatt.mgOut } catch (_: Throwable) { 0.2f }
                val enB = try { enemyBleScaleTrack.enemyScaleOut } catch (_: Throwable) { 0f }
                val wat = try { waterFullBody.waterFull } catch (_: Throwable) { 0.2f }
                val ch = try { caMgProtectChem.chemOut } catch (_: Throwable) { 0.2f }
                val bHz = try { bodyFreqRegen.badBodyHzOut } catch (_: Throwable) { 0.3f }
                val rgn = try { bodyFreqRegen.regenOut } catch (_: Throwable) { 0.2f }
                lifesumBloodBle.tick(micN, bleP, enB, wat, ch, bHz, rgn)
                lifesumBloodBle.apply(soundBank, this)
            try {
                val bleP = bleScaleLibrary?.presenceEnergy ?: try { mgBleScaleWatt.mgOut } catch (_: Throwable) { 0.2f }
                val enB = try { enemyBleScaleTrack.enemyScaleOut } catch (_: Throwable) { 0f }
                val ch = try { caMgProtectChem.chemOut } catch (_: Throwable) { 0.2f }
                val wat = try { waterFullBody.waterFull } catch (_: Throwable) { 0.2f }
                val bld = try { lifesumBloodBle.bloodFull } catch (_: Throwable) { 0.2f }
                val neu = try { neuralNeuroTx.neuralFull } catch (_: Throwable) { 0.2f }
                val hor = try { bodyFreqRegen.hormoneOut } catch (_: Throwable) { 0.2f }
                val bHz = try { bodyFreqRegen.badBodyHzOut } catch (_: Throwable) { 0.3f }
                val rgn = try { bodyFreqRegen.regenOut } catch (_: Throwable) { 0.2f }
                val sk = try { bioSkinCell.bioFullOut } catch (_: Throwable) { 0.2f }
                bodyOilsChemical.tick(micN, bleP, enB, ch, wat, bld, neu, hor, bHz, rgn, sk)
                bodyOilsChemical.apply(soundBank, this)
            try {
                val modelE = try { body84FullHuman.modelMixOut } catch (_: Throwable) { micN * 0.5f }
                val spk = try { micSpeaker.out } catch (_: Throwable) { 0.2f }
                val bu = try { soundBank.burstOut } catch (_: Throwable) { 0f }
                val bl = try { soundBank.bulletOut } catch (_: Throwable) { 0f }
                val kn = try { soundBank.knifeOut } catch (_: Throwable) { 0f }
                val sh = try { soundBank.sharpOut } catch (_: Throwable) { 0f }
                val wh = try { soundBank.whipOut } catch (_: Throwable) { 0f }
                val ar = try { 0f /* no arrowOut */ } catch (_: Throwable) { 0f }
                val ax = try { enemySoundCounters.micAxisX } catch (_: Throwable) { 0.33f }
                val ay = try { enemySoundCounters.micAxisY } catch (_: Throwable) { 0.33f }
                val az = try { enemySoundCounters.micAxisZ } catch (_: Throwable) { 0.34f }
                val sen = try { bodyFreqRegen.sensorE } catch (_: Throwable) { 0.2f }
                modelSpeakerSounds.tick(micN, modelE, spk, bu, bl, kn, sh, wh, ar, ax, ay, az, sen)
                modelSpeakerSounds.apply(soundBank, this)
            try {
                val bu = try { soundBank.burstOut } catch (_: Throwable) { 0f }
                val bl = try { soundBank.bulletOut } catch (_: Throwable) { 0f }
                val kn = try { soundBank.knifeOut } catch (_: Throwable) { 0f }
                val bHz = try { bodyFreqRegen.badBodyHzOut } catch (_: Throwable) { 0.3f }
                val rgn = try { bodyFreqRegen.regenOut } catch (_: Throwable) { 0.2f }
                val rpr = try { bodyFreqRegen.repairOut } catch (_: Throwable) { 0.2f }
                val ch = try { caMgProtectChem.chemOut } catch (_: Throwable) { 0.2f }
                val wat = try { waterFullBody.waterFull } catch (_: Throwable) { 0.2f }
                val bld = try { lifesumBloodBle.bloodFull } catch (_: Throwable) { 0.2f }
                val neu = try { neuralNeuroTx.neuralFull } catch (_: Throwable) { 0.2f }
                val hor = try { bodyFreqRegen.hormoneOut } catch (_: Throwable) { 0.2f }
                val eye = try { cnsEyesHeart.eyeLOut + cnsEyesHeart.eyeROut } catch (_: Throwable) { 0.3f }
                val sk = try { bioSkinCell.bioFullOut } catch (_: Throwable) { 0.2f }
                screenEffectInside.tick(micN, bu, bl, kn, bHz, rgn, rpr, ch, wat, bld, neu, hor, eye * 0.5f, sk)
                screenEffectInside.apply(soundBank, this)
            try {
                val modelE = try { body84FullHuman.modelMixOut } catch (_: Throwable) { micN * 0.5f }
                val eL = try { cnsEyesHeart.eyeLOut } catch (_: Throwable) { 0.2f }
                val eR = try { cnsEyesHeart.eyeROut } catch (_: Throwable) { 0.2f }
                val bodyE = try { body84FullHuman.modelMixOut } catch (_: Throwable) { 0.2f }
                val ch = try { caMgProtectChem.chemOut } catch (_: Throwable) { 0.2f }
                val wat = try { waterFullBody.waterFull } catch (_: Throwable) { 0.2f }
                val neu = try { neuralNeuroTx.neuralFull } catch (_: Throwable) { 0.2f }
                completeHuman360.tick(micN, modelE, eL, eR, bodyE, ch, wat, neu, 0.5f, 0.5f, 0.5f)
                completeHuman360.apply(this)
                val en = try { enemy3dProtect.enemyModelOut } catch (_: Throwable) { 0f }
                val bleP = bleScaleLibrary?.presenceEnergy ?: 0.2f
                enemyFoodDustbinPrank.tick(micN, bleP, modelE, en)
                enemyFoodDustbinPrank.apply(soundBank, this)
            try {
                val eL = try { cnsEyesHeart.eyeLOut } catch (_: Throwable) { 0.2f }
                val eR = try { cnsEyesHeart.eyeROut } catch (_: Throwable) { 0.2f }
                val bin = try { body84FullHuman.insideOut } catch (_: Throwable) { 0.2f }
                val bout = try { body84FullHuman.outsideOut } catch (_: Throwable) { 0.2f }
                val modelE = try { body84FullHuman.modelMixOut } catch (_: Throwable) { micN * 0.5f }
                val bu = try { soundBank.bulletOut } catch (_: Throwable) { 0f }
                val kn = try { soundBank.knifeOut } catch (_: Throwable) { 0f }
                val wh = try { soundBank.whipOut } catch (_: Throwable) { 0f }
                val br = try { soundBank.burstOut } catch (_: Throwable) { 0f }
                eyeBodyAtomSurface.tick(micN, eL, eR, bin, bout, modelE, micN * 0.4f, bu, kn, wh, br)
                eyeBodyAtomSurface.apply(soundBank, this)
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}
        try {
            finalProtectionMain.wholeBodyOut = maxOf(finalProtectionMain.wholeBodyOut, fullAnatomy132.anatomyFullOut)
            finalProtectionMain.brainAnatOut = maxOf(finalProtectionMain.brainAnatOut, fullAnatomy132.brainOut)
            finalProtectionMain.heartOut = maxOf(finalProtectionMain.heartOut, fullAnatomy132.heartOut, fullAnatomy132.cardioOut)
            finalProtectionMain.allAnatOut = maxOf(finalProtectionMain.allAnatOut, fullAnatomy132.anatomyFullOut)
            finalProtectionMain.faceNeckSkinOut = maxOf(finalProtectionMain.faceNeckSkinOut, fullAnatomy132.faceOut)
            finalProtectionMain.glandCnsOut = maxOf(finalProtectionMain.glandCnsOut, fullAnatomy132.glandsOut, fullAnatomy132.endoOut)
            finalProtectionMain.earDspOut = maxOf(finalProtectionMain.earDspOut, fullAnatomy132.earOut)
            finalProtectionMain.lrEyesOut = maxOf(finalProtectionMain.lrEyesOut, fullAnatomy132.eyesOut)
        } catch (_: Throwable) {}
        }
        }
        }
        }
        }
        try {
            body84FullHuman.interconnectOn = true
            body84FullHuman.screen3dOn = true
            body84FullHuman.objectTrackOn = true
            body84FullHuman.enableFullHuman()
            // ensure tick got energy
            body84FullHuman.applyToView(this)
        } catch (_: Throwable) {}
        // Camera focus energy for enemy bullet prank path
        soundBank.cameraFocusEnergy = maxOf(
            soundBank.liveAudioEnergy * 0.5f,
            try { body84FullHuman.modelMixOut } catch (_: Throwable) { 0f },
            try { anatomyShell.atomSpareShellOut } catch (_: Throwable) { 0f }
        )
        body84FullHuman.apply(null, skinAtomspare, anatomyShell)
        finalEyes.tick(soundBank.liveAudioEnergy, bodyMixer.mixedE.coerceIn(0f, 1f))
        try { finalEyes.apply(this) } catch (_: Throwable) {}
        eyesAmbient.leftOn = monoEyes.leftAmbOn || finalEyes.leftOn
        eyesAmbient.rightOn = monoEyes.rightAmbOn || finalEyes.rightOn
        eyesAmbient.leftThr = monoEyes.leftAmbThr
        eyesAmbient.rightThr = monoEyes.rightAmbThr
        eyesAmbient.leftLv = monoEyes.leftAmbLv
        eyesAmbient.rightLv = monoEyes.rightAmbLv

        // Screen vertical from body mix / ambient (0=feet … 1=head)
        screenAmbient.verticalFeed = (0.35f + bodyMixer.mixedE * 0.65f).coerceIn(0f, 1f)
        // live microphone + body centroid / vertical → screen echo
        run {
            val ex = screenAmbient.echoX
            ex.rawEverything = oneness.rawEverything
            ex.feedMic(ambientBoardRef, ambientBoardRef?.micFresh() == true)
            ex.feedScreen(centroid.cx, ((centroid.cy + 0.95f) / 2.7f))
        }
        screenAmbient.tick(
            clamped,
            -80.0 + clamped * 60.0,
            domHz = soundBank.liveDominantHz.takeIf { it > 1f } ?: 0f
        )
        try { screenAmbient.apply(this) } catch (_: Throwable) {}
        // Own Sound Bank: atmosphere + enemy-body auto-trigger + bipolar ±1000 dB
        val enemyE = maxOf(
            poseSurface.dampen(),
            yoloSeg.dampen(),
            bodyMixer.mixedE * 0.5f
        )
        val enemyMv = (motionHub?.liveMove ?: mixAmb).coerceIn(0f, 1f)
        val enemySp = (motionHub?.liveSpeed ?: mixWave).coerceIn(0f, 1f) / 4f
        val enemyWv = (motionHub?.liveWave ?: mixWave).coerceIn(0f, 1f) / 4f
        val liveDb = (-80.0 + clamped * 60.0).coerceIn(-1000.0, 1000.0)
        soundBank.feedBodyPartTarget(bodySoundFx.selectedPart, bodySoundFx.targetPartConfidence)
        soundBank.tick(clamped, liveDb, clamped, enemyE, enemyMv, enemySp, enemyWv)
        val fxOutputs = floatArrayOf(soundBank.bulletOut, soundBank.knifeOut, soundBank.rippleOut)
        val visibleFxTarget =
            bodySoundFx.detectionConfidence >= bodySoundFx.detectionThreshold &&
                bodySoundFx.targetPartConfidence >= bodySoundFx.partThreshold
        anatomy3d.audioFxTargetPart = soundBank.bodyPartTarget
        anatomy3d.audioFxKind = fxOutputs.indices.maxByOrNull { fxOutputs[it] } ?: 0
        anatomy3d.audioFxLevel = if (visibleFxTarget) (fxOutputs.maxOrNull() ?: 0f) else 0f
        sdSound?.pushToBank()
        centroid.tick(this)
        centroids.tick(this)
        ambientBoardRef?.let { ab ->
            ab.rawEverything = oneness.rawEverything
            val m = centroids.master
            if (centroids.enabled && centroids.useMaster && m.active) ab.feedBody(m.cx, m.cy, m.strength, true)
            else ab.feedBody(centroid.cx, centroid.cy, centroid.strength, centroid.active)
        }
        anatomy3d.bodyLocked = bodyLocked
        cenDrive.eyesOn = true
        if (!anatomy3d.bodyLocked) {
            // keep eyes able to move inside head
        }
        cenDrive.tick(this)
        // Body particles · thr · bipolar · RAW
        run {
            val e = clamped
            val db = -80.0 + clamped * 60.0
            bodyParticlesBipHit = db <= bodyParticlesBipNeg || db >= bodyParticlesBipPos
            if (bodyParticlesRaw) {
                bodyParticlesActive = bodyParticlesOn
                bodyParticlesOut = e * bodyParticlesLv.coerceIn(0f, 1f)
            } else {
                val fuel = maxOf(e, if (bodyParticlesBipHit) 0.55f else 0f)
                bodyParticlesActive = bodyParticlesOn && fuel >= bodyParticlesThr.coerceIn(0.05f, 1f)
                bodyParticlesOut = if (bodyParticlesActive) {
                    val t = bodyParticlesThr.coerceIn(0.05f, 1f)
                    (((fuel - t) / (1f - t).coerceAtLeast(0.05f)) * bodyParticlesLv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
                } else 0f
            }
            if (bodyParticlesActive) {
                bodyMixer.mixedE = maxOf(bodyMixer.mixedE, bodyParticlesOut * (if (bodyParticlesRaw) 0.70f else 0.40f))
            }
        }
        yoloObbTrack.applyToGame(gameWorld)
        gameWorld.tick(this)
        if (emfReading.active) {
            val emfE = maxOf(emfReading.energy, emfReading.ambientOut, emfReading.spikeOut, emfReading.centroidNorm * 0.5f)
            bodyMixer.mixedE = maxOf(bodyMixer.mixedE, emfE * (if (emfReading.rawComplete) 0.85f else 0.50f))
        }
        oneness.tick(this)
        bodyMotion.rawAll = oneness.rawEverything
        bodyMotion.tick(this)
        val mvOut = ambientBoard.movement
        val mvOutOn = mvOut.on && mvOut.outsideOn && !bodyLocked
        soft3d.motionYaw = bodyMotion.yawOffset + (if (mvOutOn) mvOut.outsideYaw else 0f) + movement.rotation
        soft3d.motionTilt = bodyMotion.tiltOffset + (if (mvOutOn) mvOut.outsideTilt else 0f)
        if (soundBank.mixEnergy > 0.01f) {
            bodyMixer.mixedE = maxOf(bodyMixer.mixedE, soundBank.mixEnergy * (if (soundBank.rawComplete) 0.90f else 0.55f))
        }
        micSpeaker.tick(clamped)
        try { micSpeaker.apply(soundBank, this) } catch (_: Throwable) {}
        if (micSpeaker.active) {
            bodyMixer.mixedE = maxOf(bodyMixer.mixedE, micSpeaker.out * (if (micSpeaker.rawComplete) 0.85f else 0.40f))
            echoLevel = maxOf(echoLevel, micSpeaker.effectOut * 0.6f)
        }
        // Enemy eye vulnerability keeps both L/R in mix
        val eyeVuln = enemyEyeVulnerabilityScale()
        if (eyeVuln > 0.05f) {
            bodyMixer.mixedE = maxOf(bodyMixer.mixedE, eyeVuln * 0.30f)
        }
        cameraVhs.tick(clamped)
        try { cameraVhs.apply(this) } catch (_: Throwable) {}
        noiseRate.tick(clamped)
        try { noiseRate.apply(this) } catch (_: Throwable) {}
        noise3d.tick(noiseRate.out)
        try { noise3d.apply(this) } catch (_: Throwable) {}
        bodyAtmo3d.feedAtomspare(ambientBoard)
        insideAmbient.feed(ambientBoard)
        yoloObbTrack.feed(yoloSeg, cameraDetection)
        bodyAtmo3d.tick(clamped)
        if (bodyAtmo3d.enabled) {
            bodyMixer.mixedE = maxOf(bodyMixer.mixedE, bodyAtmo3d.appliedScale * 0.25f)
        }
        if (noise3d.active) {
            bodyMixer.mixedE = maxOf(bodyMixer.mixedE, noise3d.out * 0.20f)
        }
        val hw = (if (armor.hardwareShieldOn) hardwareIntensity * (1f - armor.hardwareLv * 0.4f) else hardwareIntensity) * drawScale
        // GPU/batt guard can further cut hardware path
        runCatching { nativeDraw(width, height, phase, clamped, hw) }
        g?.tick(clamped, (mixAmb * mixWave * 0.5f).coerceIn(0f, 1f))

        val mh = motionHub
        val mx = (mh?.axisX ?: 0f) - (mh?.axisY ?: 0f) * 0.3f
        val my = (mh?.pitchUp ?: 0f) - (mh?.pitchDown ?: 0f)
        val mspd = (mh?.liveSpeed ?: 1f).coerceIn(0.2f, 4f)
        attraction.tick(
            move = mh?.liveMove ?: 0.3f,
            wave = mh?.liveWave ?: (mixWave / 4f),
            speed = mh?.liveSpeed ?: mixWave,
            mindHint = attraction.mindEnergy,
            bodyHint = attraction.bodyEnergy
        )
        val tj0 = attraction.teleportJitter()
        val boost = attraction.visualBoost()
        val tscale = attraction.timePhaseScale()

        val cx = width / 2f + sin(phase * 0.03f) * 100f * lrFilter +
            (mh?.let { (it.pitchR - it.pitchL) * 80f + mx * 40f } ?: 0f) +
            sin(phase * 0.07f) * tj0
        val cy = height / 2f + cos(phase * 0.02f) * 50f * textureShift * udFilter + my * 60f +
            cos(phase * 0.05f) * tj0 * 0.6f

        
        // The flat 2D rings / balls give way to the 3D anatomy ones (same regions, same ambient) when they are on.
        val ring3d = ringBoard.enabled && ringBoard.replace2d && anatomy3d.enabled

        // FOREHEAD region
        if (!ring3d) run {
            val sc = (regionFx.regionScale() * soundBank.outScale())
            val ro = regionFx.rippleOffset()
            val a0 = forehead.effectiveAmbient() * (0.35f + 0.65f * clamped) * sc
            val cx = width * 0.50f + (forehead.lrFilt - 0.5f) * width * 0.06f * forehead.moveMag()
            val cy = height * 0.16f + (forehead.udFilt - 0.5f) * height * 0.04f * forehead.moveMag() + ro * 0.3f
            val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            p.style = android.graphics.Paint.Style.STROKE
            p.strokeWidth = 2.2f + forehead.vibFilt * 2.8f
            for (i in 0 until (2 + (forehead.centerFilt * 3).toInt())) {
                val rr = (width * 0.10f) + i * 8f * (0.55f + forehead.cornerFilt)
                val a = (a0 * 190 * (1f - i * 0.14f)).toInt().coerceIn(20, 200)
                p.color = (a shl 24) or 0x00FFE082
                canvas.drawOval(cx - rr * 1.2f, cy - rr * 0.45f, cx + rr * 1.2f, cy + rr * 0.45f, p)
            }
        }

        // FACE region (head oval)
        val fAmb = face.effectiveAmbient() * (0.35f + 0.65f * clamped) * (regionFx.regionScale() * soundBank.outScale())
        val fWave = face.effectiveWave() * (0.5f + 0.5f * face.speedMag())
        val fCx = width * 0.50f + (face.lrFilt - 0.5f) * width * 0.08f * face.moveMag()
        val fCy = height * 0.22f + (face.udFilt - 0.5f) * height * 0.06f * face.moveMag()
        val fPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        fPaint.style = android.graphics.Paint.Style.STROKE
        fPaint.strokeWidth = 2.5f + face.vibFilt * 3f
        if (!ring3d) for (i in 0 until (3 + (face.centerFilt * 4).toInt())) {
            val rr = (width * 0.12f) + i * 10f * (0.6f + face.cornerFilt)
            val a = (fAmb * 180 * (1f - i * 0.12f)).toInt().coerceIn(20, 200)
            fPaint.color = (a shl 24) or 0x00F5C26B
            canvas.drawOval(fCx - rr, fCy - rr * 1.15f, fCx + rr, fCy + rr * 1.15f, fPaint)
        }

        // NOSE region
        val nAmb = nose.effectiveAmbient() * (0.35f + 0.65f * clamped) * (regionFx.regionScale() * soundBank.outScale())
            val nCyOff = regionFx.rippleOffset()
        val nCx = width * 0.50f + (nose.lrFilt - 0.5f) * width * 0.04f * nose.moveMag()
        val nCy = height * 0.28f + (nose.udFilt - 0.5f) * height * 0.04f * nose.moveMag()
        val nPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        nPaint.style = android.graphics.Paint.Style.STROKE
        nPaint.strokeWidth = 2f + nose.vibFilt * 2.5f
        if (!ring3d) for (i in 0 until (2 + (nose.centerFilt * 3).toInt())) {
            val rr = (width * 0.035f) + i * 6f * (0.5f + nose.cornerFilt)
            val a = (nAmb * 200 * (1f - i * 0.15f)).toInt().coerceIn(25, 210)
            nPaint.color = (a shl 24) or 0x00FFAB91
            canvas.drawCircle(nCx, nCy, rr, nPaint)
        }

        // Shared eyes base + recovered LEFT / RIGHT eye paths
        // Correct anatomical L/R eyeball positions + shared center (mix)
        val sep = eyeBallSep.coerceIn(0.08f, 0.22f)
        val eyeY = eyeBallY.coerceIn(-0.10f, 0.10f)
        val ballSc = eyeBallSize.coerceIn(0.4f, 2.0f)
        fun drawEyeBall(r: Region, side: Float) {
            // The detailed L/R eyeballs remain in AnatomyModel3D. These are
            // compact animated signal rings projected onto those eye sockets.
            val sharedMix = if (eyeMixOn && side != 0f) 0.25f else 0f
            val eAmb = (r.effectiveAmbient() * (1f - sharedMix) +
                eyes.effectiveAmbient() * sharedMix) * (0.35f + 0.65f * clamped)
            val eMag = maxOf(r.moveMag(), eyes.moveMag() * sharedMix)
            val eSpd = maxOf(r.speedMag(), eyes.speedMag() * sharedMix)
            val eRnd = maxOf(r.randomFilt, eyes.randomFilt * sharedMix) * randomFilter
            val eCor = maxOf(r.cornerFilt, eyes.cornerFilt * sharedMix) * cornerFilter
            val eVib = maxOf(r.vibFilt, eyes.vibFilt * sharedMix) * vibFreqFilter
            val socket = if (anatomy3d.enabled) {
                soft3d.projectEyePosition(
                    modelCx, modelCy, h, anatomy3d, phase, side, sep, eyeY, modelSize
                )
            } else {
                (cx + side * w * 0.10f) to (cy - h * 0.22f + eyeY * h * 0.10f)
            }
            val eyeUnit = h * modelSize.coerceIn(0.2f, 1.2f) / 2.7f
            val ecx = socket.first +
                sin(phase * 0.04f * r.wave) * eyeUnit * 0.04f * eMag * r.lrFilt * lrFilter +
                sin(phase * 0.11f) * eyeUnit * 0.025f * eRnd +
                sin(phase * (0.05f + eVib * 0.3f)) * eyeUnit * 0.015f * eVib
            val ecy = socket.second +
                cos(phase * 0.03f * r.wave) * eyeUnit * 0.03f * eMag * r.udFilt * udFilter +
                cos(phase * 0.13f) * eyeUnit * 0.02f * eRnd +
                cos(phase * 0.02f) * eyeUnit * 0.025f * eCor
            val baseR = (eyeUnit * 0.025f * ballSc).coerceIn(2.5f, 14f)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = (0.8f + 1.4f * eAmb).coerceIn(0.8f, 2.4f)
            for (i in 0..7) {
                val radius = baseR + i * eyeUnit * 0.0045f * ballSc +
                    sin(phase * 0.02f * r.wave * (0.5f + eSpd) + i) * eyeUnit * 0.0015f
                val colCeil = systemGuard?.effectiveColorCeiling(colorThreshold) ?: colorThreshold
                val red = minOf(255, colCeil + micVariation(40))
                val a = ((95 * eAmb) * (1f - i * 0.075f)).toInt().coerceIn(18, 130)
                paint.color = eyeTuning.apply(a, red, 255, 130, eAmb)
                canvas.drawCircle(ecx, ecy, radius, paint)
            }
            // Keep the pupil pulse small; the 3D sclera, iris and pupil are
            // already rendered as connected L/R parts inside the head.
            paint.style = Paint.Style.FILL
            paint.color = eyeTuning.apply((40 * eAmb).toInt().coerceIn(12, 80), 20, 40, 80, eAmb)
            canvas.drawCircle(ecx, ecy, (baseR * 0.25f).coerceIn(1f, 3.5f), paint)
        }
        fun drawBrow(r: Region, side: Float) {
            val eAmb = r.effectiveAmbient() * (0.35f + 0.65f * clamped)
            val eMag = r.moveMag()
            val socket = if (anatomy3d.enabled) {
                soft3d.projectEyePosition(
                    modelCx, modelCy, h, anatomy3d, phase, side, sep, eyeY + 0.045f, modelSize
                )
            } else {
                (cx + side * w * 0.10f) to (cy - h * 0.25f)
            }
            val eyeUnit = h * modelSize.coerceIn(0.2f, 1.2f) / 2.7f
            val bx = socket.first + sin(phase * 0.03f * r.wave) * eyeUnit * 0.04f * eMag * r.lrFilt * lrFilter
            val by = socket.second + cos(phase * 0.025f * r.wave) * eyeUnit * 0.025f * eMag * r.udFilt * udFilter
            val bw = eyeUnit * 0.075f * ballSc
            val bh = (eyeUnit * 0.018f + eyeUnit * 0.025f * ballSc * eAmb).coerceAtLeast(2f)
            paint.color = eyeTuning.apply((70 * eAmb).toInt().coerceIn(20, 110), 180, 140, 90, eAmb)
            canvas.drawRoundRect(bx - bw, by - bh, bx + bw, by + bh * 0.4f, bh, bh, paint)
            // atmosphere arc above brow
            if (r.atmosphere > 0.05f) {
                paint.color = eyeTuning.apply((50 * eAmb * r.atmosphere).toInt().coerceIn(10, 90), 120, 200, 255, eAmb)
                canvas.drawArc(bx - bw * 1.2f, by - bh * 3f, bx + bw * 1.2f, by + bh, 200f, 140f, false, paint)
            }
        }
        if (browSyncEyes) {
            browL.copyFrom(eyeL); browR.copyFrom(eyeR)
            browL.ambient = (browL.ambient * 0.85f + eyeL.ambient * 0.15f).coerceIn(0f, 1f)
            browR.ambient = (browR.ambient * 0.85f + eyeR.ambient * 0.15f).coerceIn(0f, 1f)
        }

        fun drawLip(r: Region, upper: Boolean) {
            val eAmb = r.effectiveAmbient() * (0.35f + 0.65f * clamped)
            val eMag = r.moveMag()
            val ly = lipY.coerceIn(0.02f, 0.22f)
            val lsz = lipSize.coerceIn(0.5f, 2.0f)
            val gap = lipSep.coerceIn(0f, 0.06f)
            val baseOy = h * (if (upper) ly - gap else ly + gap * 1.4f)
            val bx = cx + sin(phase * 0.035f * r.wave) * 10f * eMag * r.lrFilt * lrFilter
            val by = cy + baseOy + cos(phase * 0.028f * r.wave) * 6f * eMag * r.udFilt * udFilter
            val bw = w * 0.11f * lsz
            val bh = (5f + 7f * lsz * eAmb) * (if (upper) 1f else 1.15f)
            paint.color = eyeTuning.apply((75 * eAmb).toInt().coerceIn(22, 120), 220, 80, 100, eAmb)
            canvas.drawOval(bx - bw, by - bh, bx + bw, by + bh, paint)
            if (r.atmosphere > 0.05f) {
                paint.color = eyeTuning.apply((45 * eAmb * r.atmosphere).toInt().coerceIn(10, 90), 255, 120, 140, eAmb)
                canvas.drawOval(bx - bw * 1.08f, by - bh * 1.3f, bx + bw * 1.08f, by + bh * 0.6f, paint)
            }
        }
        if (lipSyncFace) {
            lipU.copyFrom(face); lipL.copyFrom(face)
            lipU.ambient = (lipU.ambient * 0.7f + face.ambient * 0.3f).coerceIn(0f, 1f)
            lipL.ambient = (lipL.ambient * 0.7f + face.ambient * 0.3f).coerceIn(0f, 1f)
        }
        if (!ring3d && lipUOn) drawLip(lipU, true)
        if (!ring3d && lipLOn) drawLip(lipL, false)

        if (brain3d.enabled) {
            // oneness: the brain is drawn INSIDE the anatomy body (Brain layer) — no second floating brain
            if (!(brain3d.dockInAnatomy && anatomy3d.enabled)) {
                soft3d.drawBrain(canvas, cx, cy - h * 0.18f + h * bodyMotion.vOffset, w, brain3d, phase)
                soft3d.drawOpticalLines(canvas, cx, cy - h * 0.18f, w, brain3d, phase)
            }
        } else {
            drawRegionRing(canvas, cx, cy - h * 0.18f, brain, 120, 0.5f)
        }
        drawFireBursts(canvas, w, h, phase)
        if (noise3d.enabled) {
            soft3d.drawNoise3D(canvas, w * 0.5f, h * 0.55f, h, noise3d, phase)
        }
        if (anatomy3d.enabled) {
            soft3d.drawCentroidHud(canvas, width.toFloat(), height.toFloat(), ambientBoard)
        // preDrawFullHuman: complete body model on screen (not single)
            try {
                anatomy3d.enabled = true
                anatomy3d.enableCompleteHumanLayers()
                anatomy3d.setRawAll(true)
                anatomy3d.layerOn[0] = true
                val cellE = try { maxOf(bioSkinCell.nucleus, bioSkinCell.cellMembrane, bioSkinCell.bioFullOut) } catch (_: Throwable) { 0.5f }
                anatomy3d.layerLevel[0] = maxOf(anatomy3d.layerLevel[0], cellE, 0.9f)
                anatomy3d.atmosphere = maxOf(anatomy3d.atmosphere, cellE * 0.5f)
            } catch (_: Throwable) {}
            soft3d.drawAnatomy(canvas, modelCx, modelCy, h, anatomy3d, brain3d, phase, modelSize)
            soft3d.drawHeartInside(canvas, modelCx, modelCy + h * 0.05f, h, heartInsideFull, phase)
            soft3d.drawNeuronField(canvas, modelCx, modelCy - h * 0.12f, h, neuralNeuroTx, phase)
            if (brain3d.faceLinesOn) {
                soft3d.drawFaceLines(canvas, modelCx, modelCy, h, anatomy3d, phase, modelSize)
            }
            // rings + balls anchored on the body (outside on the skin, inside on the organs)
            soft3d.drawCentroidHud(canvas, width.toFloat(), height.toFloat(), ambientBoard)
        soft3d.drawAnatomyRings(canvas, modelCx, modelCy, h, anatomy3d, ringBoard, phase, modelSize)
            soft3d.drawMovementHud(canvas, height.toFloat(), ambientBoard)
        }
        // Eye L/R effects are drawn AFTER the anatomy so each ring sits over
        // the corresponding eye in the same head, not as separate floating balls.
        if (!ring3d) {
            if (eyeLOn) drawEyeBall(eyeL, -1f)
            if (eyeROn) drawEyeBall(eyeR, 1f)
            drawEyeSkinLayers(canvas, cx, cy, w, h, phase, clamped)
            if (browLOn) drawBrow(browL, -1f)
            if (browROn) drawBrow(browR, 1f)
            if (anatomy3d.enabled && brain3d.enabled) {
                val eyeUnit = h * modelSize.coerceIn(0.2f, 1.2f) / 2.7f
                val eyeRingScale = (eyeUnit * 0.065f / 104f).coerceIn(0.02f, 0.35f)
                if (eyeLOn) {
                    val p = soft3d.projectEyePosition(modelCx, modelCy, h, anatomy3d, phase, -1f, sep, eyeY, modelSize)
                    drawRegionRing(canvas, p.first, p.second, eyeL, 255, 0.4f, eyeRingScale, true)
                }
                if (eyeROn) {
                    val p = soft3d.projectEyePosition(modelCx, modelCy, h, anatomy3d, phase, 1f, sep, eyeY, modelSize)
                    drawRegionRing(canvas, p.first, p.second, eyeR, 200, 0.5f, eyeRingScale, true)
                }
            }
        }
        gameWorld.draw(canvas, w, h, phase)
        if (!ring3d) {
            drawRegionRing(canvas, cx - w * 0.12f, cy + h * 0.02f, heart, 200, 1.1f)
            drawRegionRing(canvas, cx, cy + h * 0.08f, neck, 90, 1.7f)
            drawRegionRing(canvas, cx, cy + h * 0.22f, belly, 60, 2.3f)
            drawRegionRing(canvas, cx - w * 0.28f, cy + h * 0.12f, handL, 150, 2.9f)
            drawRegionRing(canvas, cx + w * 0.28f, cy + h * 0.12f, handR, 150, 3.5f)
            drawRegionRing(canvas, cx - w * 0.08f, cy + h * 0.30f, pussy, 180, 4.1f)
            drawRegionRing(canvas, cx + w * 0.08f, cy + h * 0.30f, dick, 160, 4.7f)
        }

        
        // Screen threshold / AV intensity protect (own UI)
        val sg = systemGuard
        val damp = maxOf(sg?.screenChangeDampen ?: 0f, screenAmbient.dampen, poseSurface.dampen(), yoloSeg.dampen(), bodyMixer.dampen())
        if (damp > 0.01f || sg?.screenStuckProtect == true) {
            val op = android.graphics.Paint()
            if (sg?.screenStuckProtect == true) {
                op.color = 0x55000000
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), op)
                op.color = 0x6600E5FF
                canvas.drawRect(width * 0.15f, height * 0.42f, width * 0.85f, height * 0.52f, op)
            } else {
                val a = (damp * 140).toInt().coerceIn(0, 180)
                op.color = (a shl 24)
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), op)
            }
        }

        // Screen sounds pitch protection: LEFT and RIGHT dim + edge stripe
        val pgo = pitchGuard
        if (pgo != null && (pgo.left.damp > 0.01f || pgo.right.damp > 0.01f)) {
            val op = android.graphics.Paint()
            val halfW = width / 2f
            val fullH = height.toFloat()
            if (pgo.left.damp > 0.01f) {
                op.color = ((pgo.left.damp * 150).toInt().coerceIn(0, 170) shl 24)
                canvas.drawRect(0f, 0f, halfW, fullH, op)
                op.color = ((pgo.left.damp * 255).toInt().coerceIn(0, 255) shl 24) or 0x0000E5FF
                canvas.drawRect(0f, 0f, 8f, fullH, op)
            }
            if (pgo.right.damp > 0.01f) {
                op.color = ((pgo.right.damp * 150).toInt().coerceIn(0, 170) shl 24)
                canvas.drawRect(halfW, 0f, width.toFloat(), fullH, op)
                op.color = ((pgo.right.damp * 255).toInt().coerceIn(0, 255) shl 24) or 0x0000E5FF
                canvas.drawRect(width - 8f, 0f, width.toFloat(), fullH, op)
            }
        }

        // Protect MY body move/speed/wave from enemy / mic thresholded sounds
        val pMv = soundBank.protectMoveFactor
        val pSp = soundBank.protectSpeedFactor
        val pWv = soundBank.protectWaveFactor
        val speed = movement.atomSpeed.coerceIn(0f, 100f)
        val speedFactor = if (speed <= 1f) speed else
            (1f + (ln(speed) / ln(100f)) * 3f).coerceIn(1f, 4f)
        phase += 2f * mixWave * pWv * mspd * pSp * boost * tscale * speedFactor *
            (0.5f + 0.5f * cameraFeedback) *
            (((systemGuard?.drawScale() ?: 1f) * cameraVhs.drawCut()).coerceIn(0.15f, 1f)) *
            (1f + 0.35f * echoLevel)
        invalidate()
    }
    /** Eye / head / atmosphere fire bursts (enemy-body oriented). */
    private fun drawFireBursts(canvas: Canvas, w: Float, h: Float, phase: Float) {
        val sb = soundBank
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val cx = w * 0.5f
        // Head fire (forehead)
        if (sb.headFireOut > 0.04f) {
            val e = sb.headFireOut
            paint.color = Color.argb((80 + e * 140).toInt().coerceIn(40, 220), 255, (80 + e * 100).toInt(), 20)
            canvas.drawCircle(cx, h * 0.18f, 18f + e * 36f, paint)
            paint.color = Color.argb((60 + e * 100).toInt(), 255, 200, 40)
            canvas.drawCircle(cx, h * 0.18f, 8f + e * 16f, paint)
        }
        // Eye fire L/R
        if (sb.eyeFireOut > 0.04f) {
            val e = sb.eyeFireOut
            paint.color = Color.argb((90 + e * 130).toInt().coerceIn(40, 220), 255, (60 + e * 80).toInt(), 10)
            val eyeY = h * 0.22f
            canvas.drawCircle(cx - w * 0.08f, eyeY, 10f + e * 22f, paint)
            canvas.drawCircle(cx + w * 0.08f, eyeY, 10f + e * 22f, paint)
        }
        // Atmosphere fire halo around body center
        if (sb.atmoFireOut > 0.04f) {
            val e = sb.atmoFireOut
            paint.color = Color.argb((50 + e * 90).toInt().coerceIn(20, 160), 255, (40 + e * 60).toInt(), 0)
            canvas.drawCircle(cx, h * 0.52f, 40f + e * 90f, paint)
        }
    }


    /** Complete 3D eye skin L/R inside·outside + full atmosphere (not single). */
    private fun drawEyeSkinLayers(canvas: Canvas, cx: Float, cy: Float, w: Float, h: Float, phase: Float, clamped: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val eyeY = cy - h * 0.22f
        fun skin(x: Float, outR: Region, inR: Region, on: Boolean) {
            if (!on) return
            val o = outR.effectiveAmbient() * (0.4f + 0.6f * clamped)
            val i = inR.effectiveAmbient() * (0.4f + 0.6f * clamped)
            if (o > 0.04f) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f + o * 3.5f
                paint.color = Color.argb((55 + o * 110).toInt().coerceIn(20, 200), 0xFF, 0xCC, 0xBC)
                canvas.drawOval(x - 24f - o * 10f, eyeY - 18f - o * 7f, x + 24f + o * 10f, eyeY + 20f + o * 7f, paint)
            }
            if (i > 0.04f) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1.3f + i * 2.2f
                paint.color = Color.argb((40 + i * 95).toInt().coerceIn(15, 170), 0xEF, 0x9A, 0x9A)
                canvas.drawOval(x - 15f - i * 6f, eyeY - 11f, x + 15f + i * 6f, eyeY + 13f, paint)
            }
            // outer lid ring
            if (o > 0.05f) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1.8f + o * 2f
                paint.color = Color.argb((50 + o * 90).toInt(), 0x80, 0xDE, 0xEA)
                canvas.drawCircle(x, eyeY, 12f + o * 14f, paint)
            }
            // inner globe tint
            if (i > 0.05f) {
                paint.style = Paint.Style.FILL
                paint.color = Color.argb((30 + i * 70).toInt(), 0xF5, 0xF5, 0xF5)
                canvas.drawCircle(x, eyeY, 5f + i * 8f, paint)
            }
        }
        skin(cx - w * 0.10f, eyeLSkinOut, eyeLSkinIn, eyeLOn)
        skin(cx + w * 0.10f, eyeRSkinOut, eyeRSkinIn, eyeROn)
        // Full atmosphere around both eyes
        val at = eyeAtmo.effectiveAmbient().coerceAtLeast(eyes.atmosphere * 0.75f) * (0.4f + 0.6f * clamped)
        if (at > 0.05f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.6f + at * 2.8f
            paint.color = Color.argb((30 + at * 85).toInt().coerceIn(12, 150), 0x4D, 0xD0, 0xE1)
            canvas.drawOval(cx - w * 0.24f, eyeY - h * 0.09f, cx + w * 0.24f, eyeY + h * 0.11f, paint)
        }
        // Body particles
        if (bodyParticlesActive && bodyParticlesOut > 0.04f) {
            val n = (8 + (bodyParticlesOut * 28).toInt()).coerceAtMost(40)
            paint.style = Paint.Style.FILL
            for (i in 0 until n) {
                val a = phase * 0.07f + i * 0.41f
                val px = cx + kotlin.math.sin(a) * w * (0.06f + bodyParticlesOut * 0.28f)
                val py = cy + kotlin.math.cos(a * 1.25f) * h * (0.10f + bodyParticlesOut * 0.22f)
                paint.color = Color.argb((45 + bodyParticlesOut * 130).toInt().coerceIn(20, 210), 0x80, 0xDE, 0xEA)
                canvas.drawCircle(px, py, 1.4f + bodyParticlesOut * 3.2f, paint)
            }
        }
    }


    /** Ensure eye ambient · eye skin · face · full body skin defaults are complete (nothing missing). */

    fun allAmbientLine(): String = AmbientSystems.line(AmbientSystems.snapshot(ambientBoard))

    fun loadPtModels(context: android.content.Context) {
        PtModelRuntime.tryLoad(context)
        yoloSeg.tryLoadModel(context, "yolo26x-seg.onnx")
    }

    fun ensureCompleteBodySkin() {
        for (r in listOf(
            skinHead, skinNeck, skinChest, skinAbdomen, skinBack,
            skinArmL, skinArmR, skinHandL, skinHandR,
            skinLegL, skinLegR, skinFootL, skinFootR, skinAll
        )) {
            if (r.ambient < 0.45f) r.ambient = 0.60f
        }
        if (face.ambient < 0.45f) face.ambient = 0.65f
        if (neck.ambient < 0.4f) neck.ambient = 0.60f
        if (heart.ambient < 0.4f) heart.ambient = 0.60f
        ensureCompleteEyesAmbient()
        anatomy3d.enabled = true
        anatomy3d.enableCompleteHumanLayers()
        anatomy3d.enableAllSubSystems()
        yoloSeg.enableRawCompleteSeg()
        AmbientSystems.enableRawCompleteAll(this)
    }

    /** Complete eyes ambient system — every L/R structure, not a single eye channel. */
    fun ensureCompleteEyesAmbient() {
        val targets = listOf(
            eyes, eyeL, eyeR, eyeLOut, eyeROut, eyeLIn, eyeRIn,
            eyeLSkinOut, eyeRSkinOut, eyeLSkinIn, eyeRSkinIn, eyeAtmo,
            eyeLSclera, eyeRSclera, eyeLCornea, eyeRCornea, eyeLIris, eyeRIris,
            eyeLPupil, eyeRPupil, eyeLLidU, eyeRLidU, eyeLLidD, eyeRLidD,
            eyeLLash, eyeRLash, eyeLConjunctiva, eyeRConjunctiva,
            eyeLLacrimal, eyeRLacrimal, eyeLCanthus, eyeRCanthus, eyeLOrbit, eyeROrbit,
            browL, browR
        )
        for (r in targets) {
            if (r.ambient < 0.45f) r.ambient = 0.62f
        }
        eyeLOn = true
        eyeROn = true
        if (eyes.ambient < 0.55f) eyes.ambient = 0.72f
    }

}
