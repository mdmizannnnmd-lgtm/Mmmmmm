package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object LifesumBloodBleSystemPanels {
    fun build(ctx: Context, root: LinearLayout, b: LifesumBloodBleSystemBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFEF5350.toInt()
        p.title("LIFESUM SYSTEM · BLOOD PROTECT/REPAIR · BLE REGEN · ELECTRODES", c)
        p.note("BIA Z 150–1200Ω · water% · blood thr · badHz→regen · enemy electrode/scale/colour protect")
        p.switch("System ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Blood protect", b.bloodProtectOn) { b.bloodProtectOn = it }
        p.switch("Blood repair", b.bloodRepairOn) { b.bloodRepairOn = it }
        p.switch("BLE regen", b.bleRegenOn) { b.bleRegenOn = it }
        p.switch("Electrode protect", b.electrodeProtectOn) { b.electrodeProtectOn = it }
        p.switch("Scale meas protect", b.scaleMeasProtectOn) { b.scaleMeasProtectOn = it }
        p.switch("BLE colour protect", b.bleColourProtectOn) { b.bleColourProtectOn = it }
        p.seek("Blood thr", 0.05f, 0.9f, b.bloodThr) { b.bloodThr = it }
        p.seek("Blood repair Hz", 1f, 40f, b.bloodRepairHz) { b.bloodRepairHz = it }
        p.seek("Bad freq thr", 0.2f, 0.95f, b.badFreqThr) { b.badFreqThr = it }
        p.seek("Regen Hz", 1f, 40f, b.regenHz) { b.regenHz = it }
        p.seek("Electrode thr", 0.05f, 0.9f, b.electrodeThr) { b.electrodeThr = it }
        p.seek("Scale meas thr", 0.05f, 0.9f, b.scaleMeasThr) { b.scaleMeasThr = it }
        p.seek("BLE colour thr", 0.05f, 0.9f, b.bleColourThr) { b.bleColourThr = it }
        val st = p.status("LIFESUM-BLOOD —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() {
                st.text = b.status
                Handler(Looper.getMainLooper()).postDelayed(this, 300)
            }
        })
    }
}
