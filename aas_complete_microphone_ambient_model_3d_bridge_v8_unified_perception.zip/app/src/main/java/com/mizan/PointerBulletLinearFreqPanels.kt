package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object PointerBulletLinearFreqPanels {
    fun build(ctx: Context, root: LinearLayout, b: PointerBulletLinearFreqBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFFFAB40.toInt()
        p.title("POINTER · BULLET · LINEAR Hz · BURST PROTECT", c)
        p.note("Linear frequency (not log) for pointer/bullet impulses · burst damp on SoundBank")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Burst protect", b.burstProtectOn) { b.burstProtectOn = it }
        p.switch("Pointer protect", b.pointerProtectOn) { b.pointerProtectOn = it }
        p.switch("Bullet protect", b.bulletProtectOn) { b.bulletProtectOn = it }
        p.seek("Linear Hz min", 20f, 5000f, b.linearHzMin) { b.linearHzMin = it }
        p.seek("Linear Hz max", 1000f, 20000f, b.linearHzMax) { b.linearHzMax = it }
        p.seek("Linear slope", 0.2f, 2.5f, b.linearSlope) { b.linearSlope = it }
        p.seek("Level", 0.2f, 1.5f, b.levelAmt) { b.levelAmt = it }
        p.seek("Burst protect thr", 0.05f, 0.8f, b.burstProtectThr) { b.burstProtectThr = it }
        p.seek("Burst protect lv", 0.3f, 1.2f, b.burstProtectLv) { b.burstProtectLv = it }
        val st = p.status("PTR·BULLET —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                st.text = b.status
                h.postDelayed(this, 250)
            }
        })
    }
}
