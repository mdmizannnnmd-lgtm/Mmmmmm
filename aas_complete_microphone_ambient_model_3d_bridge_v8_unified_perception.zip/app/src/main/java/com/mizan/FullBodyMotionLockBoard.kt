package com.mizan

/**
 * Fully body locked motion — enemy cannot drive move/speed/wave on full body.
 * Region locks + master lock. RAW COMPLETE.
 */
class FullBodyMotionLockBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    @Volatile var lockOn = true
    @Volatile var lockThr = 0.15f
    @Volatile var lockLv = 0.98f
    @Volatile var lockOut = 0f

    @Volatile var lockHead = 0f
    @Volatile var lockEyes = 0f
    @Volatile var lockTorso = 0f
    @Volatile var lockArms = 0f
    @Volatile var lockLegs = 0f
    @Volatile var lockFull = 0f

    @Volatile var lockMove = 0f
    @Volatile var lockSpeed = 0f
    @Volatile var lockWave = 0f
    @Volatile var lockPitch = 0f
    @Volatile var lockSpike = 0f
    @Volatile var lockNeck = 0f
    @Volatile var lockSpine = 0f
    @Volatile var lockHands = 0f
    @Volatile var lockFeet = 0f
    @Volatile var lockInside = 0f
    @Volatile var hardLock = true  // stronger freeze when true

    @Volatile var status = "FULL BODY MOTION LOCK idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, enemy: Float, eyeLock: Float) {
        if (!enabled) {
            status = "BODY MOTION LOCK OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val threat = maxOf(enemy, e * 0.35f, eyeLock * 0.5f)
        lockOut = lane(lockOn, lockThr, lockLv, threat)
        lockHead = lockOut * 1.0f
        lockEyes = maxOf(lockOut, eyeLock)
        lockTorso = lockOut * 0.98f
        lockArms = lockOut * 0.96f
        lockLegs = lockOut * 0.96f
        lockMove = lockOut
        lockSpeed = lockOut * 0.98f
        lockWave = lockOut * 0.97f
        lockPitch = lockOut * 0.96f
        lockSpike = lockOut * 0.95f
        lockNeck = lockOut * 0.99f
        lockSpine = lockOut * 0.98f
        lockHands = lockOut * 0.94f
        lockFeet = lockOut * 0.94f
        lockInside = lockOut * 0.97f
        lockFull = maxOf(lockHead, lockEyes, lockTorso, lockArms, lockLegs, lockNeck, lockSpine, lockHands, lockFeet, lockInside, lockOut)

        status =
            "BODY-LOCK=${(lockFull*100).toInt()}% H/E/T/A/L=${(lockHead*100).toInt()}/${(lockEyes*100).toInt()}/${(lockTorso*100).toInt()}/${(lockArms*100).toInt()}/${(lockLegs*100).toInt()} · " +
            "MOV/SPD/WAV/PIT/SPK=${(lockMove*100).toInt()}/${(lockSpeed*100).toInt()}/${(lockWave*100).toInt()}/${(lockPitch*100).toInt()}/${(lockSpike*100).toInt()}% · " +
            "N/S/H/F/IN=${(lockNeck*100).toInt()}/${(lockSpine*100).toInt()}/${(lockHands*100).toInt()}/${(lockFeet*100).toInt()}/${(lockInside*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled || lockFull < 0.02f) return
        val strength = if (hardLock) 0.995f else 0.97f
        val k = (1f - lockFull * strength).coerceIn(0.01f, 1f)
        sb.enemyBodyOut *= k
        sb.micEnemyOut *= k
        sb.whipOut *= k
        sb.rippleOut *= k
        sb.burstOut *= (1f - lockFull * 0.7f).coerceIn(0.05f, 1f)
        sb.knifeOut *= (1f - lockFull * 0.7f).coerceIn(0.05f, 1f)
        sb.bulletOut *= (1f - lockFull * 0.7f).coerceIn(0.05f, 1f)
        sb.sharpOut *= (1f - lockSpike * 0.8f).coerceIn(0.05f, 1f)
        sb.collideOut *= k

        val vv = v ?: return
        try {
            // Freeze enemy-fed motion controllers
            val mk = (1f - lockMove * 0.85f).coerceIn(0.05f, 1f)
            val sk = (1f - lockSpeed * 0.85f).coerceIn(0.05f, 1f)
            val wk = (1f - lockWave * 0.85f).coerceIn(0.05f, 1f)
            vv.skinMultiMotion.moveOut *= mk
            vv.skinMultiMotion.speedOut *= sk
            vv.skinMultiMotion.waveOut *= wk
            vv.fullAmbientMaster.moveOut *= mk
            vv.fullAmbientMaster.speedOut *= sk
            vv.fullAmbientMaster.waveOut *= wk
            vv.body84FullHuman.moveOut *= mk
            vv.body84FullHuman.speedOut *= sk
            vv.body84FullHuman.waveOut *= wk
            try {
                vv.fullAmbientMaster.pitchOut *= (1f - lockPitch * 0.85f).coerceIn(0.05f, 1f)
                vv.fullAmbientMaster.spikeOut *= (1f - lockSpike * 0.85f).coerceIn(0.05f, 1f)
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}
        try {
            vv.bodyRegionEnemyProtect.headProt = maxOf(vv.bodyRegionEnemyProtect.headProt, lockHead)
            vv.bodyRegionEnemyProtect.torsoProt = maxOf(vv.bodyRegionEnemyProtect.torsoProt, lockTorso)
            vv.bodyRegionEnemyProtect.armLProt = maxOf(vv.bodyRegionEnemyProtect.armLProt, lockArms)
            vv.bodyRegionEnemyProtect.armRProt = maxOf(vv.bodyRegionEnemyProtect.armRProt, lockArms)
            vv.bodyRegionEnemyProtect.legLProt = maxOf(vv.bodyRegionEnemyProtect.legLProt, lockLegs)
            vv.bodyRegionEnemyProtect.legRProt = maxOf(vv.bodyRegionEnemyProtect.legRProt, lockLegs)
            vv.bodyRegionEnemyProtect.insideCore = maxOf(vv.bodyRegionEnemyProtect.insideCore, lockInside)
        } catch (_: Throwable) {}
        try {
            vv.eyesCompleteLock.eyeMoveBlocked = maxOf(vv.eyesCompleteLock.eyeMoveBlocked, lockEyes)
            vv.eyesCompleteLock.eyeLockOut = maxOf(vv.eyesCompleteLock.eyeLockOut, lockEyes)
            vv.bodyRegionEnemyProtect.fullBodyProt = maxOf(vv.bodyRegionEnemyProtect.fullBodyProt, lockFull)
            vv.bodyRegionEnemyProtect.protectOut = maxOf(vv.bodyRegionEnemyProtect.protectOut, lockFull)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, lockFull)
            vv.antiAtomspareSounds.antiOut = maxOf(vv.antiAtomspareSounds.antiOut, lockFull * 0.8f)
        } catch (_: Throwable) {}
        try {
            vv.skinAll.atmosphere = maxOf(vv.skinAll.atmosphere, lockFull * 0.25f)
            vv.anatomy3d.atmosphere = maxOf(vv.anatomy3d.atmosphere, lockFull * 0.2f)
        } catch (_: Throwable) {}
    }
}
