package com.mizan

/**
 * Full 3D body model as region groups (not single joints).
 * Order: full body first, then major groups — never single-point only.
 * RAW COMPLETE supported.
 */
class FullModel3dBodyBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.28f
    @Volatile var level = 0.70f

    // Full body first
    @Volatile var fullBodyOn = true
    @Volatile var fullBodyOut = 0f

    // Major groups (not single)
    @Volatile var headGroupOn = true
    @Volatile var headGroupOut = 0f
    @Volatile var torsoGroupOn = true
    @Volatile var torsoGroupOut = 0f
    @Volatile var armLGroupOn = true
    @Volatile var armLGroupOut = 0f
    @Volatile var armRGroupOn = true
    @Volatile var armRGroupOut = 0f
    @Volatile var legLGroupOn = true
    @Volatile var legLGroupOut = 0f
    @Volatile var legRGroupOn = true
    @Volatile var legRGroupOut = 0f
    @Volatile var pelvisGroupOn = true
    @Volatile var pelvisGroupOut = 0f
    @Volatile var spineGroupOn = true
    @Volatile var spineGroupOut = 0f

    // Optional singles only after groups (derived)
    @Volatile var deriveSingles = true
    @Volatile var status = "FULL-MODEL-3D idle"

    private fun lane(on: Boolean, e: Float, drive: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * level * drive).coerceIn(0f, 1f)
        val t = (thr * drive).coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * level * drive).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, modelDrive: Float = 1f) {
        if (!enabled) { status = "FULL-MODEL-3D OFF"; return }
        val e = mic.coerceIn(0f, 1f)
        val drive = 0.25f + 0.75f * modelDrive.coerceIn(0f, 1f)

        // 1) Full body first
        fullBodyOut = if (fullBodyOn) lane(true, e * 1.05f, drive) else 0f
        val base = maxOf(e, fullBodyOut)

        // 2) Groups (not single)
        headGroupOut = if (headGroupOn) lane(true, base * 1.08f, drive) else 0f
        torsoGroupOut = if (torsoGroupOn) lane(true, base * 1.0f, drive) else 0f
        armLGroupOut = if (armLGroupOn) lane(true, base * 0.96f, drive) else 0f
        armRGroupOut = if (armRGroupOn) lane(true, base * 0.96f, drive) else 0f
        legLGroupOut = if (legLGroupOn) lane(true, base * 0.94f, drive) else 0f
        legRGroupOut = if (legRGroupOn) lane(true, base * 0.94f, drive) else 0f
        pelvisGroupOut = if (pelvisGroupOn) lane(true, base * 0.97f, drive) else 0f
        spineGroupOut = if (spineGroupOn) lane(true, base * 0.98f, drive) else 0f

        // Re-assert full body = max of groups
        fullBodyOut = maxOf(
            fullBodyOut, headGroupOut, torsoGroupOut,
            armLGroupOut, armRGroupOut, legLGroupOut, legRGroupOut,
            pelvisGroupOut, spineGroupOut
        )

        status =
            "FULL3D body=${(fullBodyOut*100).toInt()}% · " +
            "H${(headGroupOut*100).toInt()} T${(torsoGroupOut*100).toInt()} " +
            "AL${(armLGroupOut*100).toInt()} AR${(armRGroupOut*100).toInt()} " +
            "LL${(legLGroupOut*100).toInt()} LR${(legRGroupOut*100).toInt()} " +
            "P${(pelvisGroupOut*100).toInt()} S${(spineGroupOut*100).toInt()}" +
            if (rawComplete) " · RAW" else ""
    }

    fun applyToShield(v: VisualShieldView) {
        if (!enabled) return
        v.skinHead.ambient = maxOf(v.skinHead.ambient, headGroupOut)
        v.skinChest.ambient = maxOf(v.skinChest.ambient, torsoGroupOut)
        v.skinAbdomen.ambient = maxOf(v.skinAbdomen.ambient, torsoGroupOut * 0.9f)
        v.skinBack.ambient = maxOf(v.skinBack.ambient, spineGroupOut)
        v.skinArmL.ambient = maxOf(v.skinArmL.ambient, armLGroupOut)
        v.skinArmR.ambient = maxOf(v.skinArmR.ambient, armRGroupOut)
        v.skinLegL.ambient = maxOf(v.skinLegL.ambient, legLGroupOut)
        v.skinLegR.ambient = maxOf(v.skinLegR.ambient, legRGroupOut)
        if (deriveSingles) {
            v.skinHandL.ambient = maxOf(v.skinHandL.ambient, armLGroupOut * 0.85f)
            v.skinHandR.ambient = maxOf(v.skinHandR.ambient, armRGroupOut * 0.85f)
            v.skinFootL.ambient = maxOf(v.skinFootL.ambient, legLGroupOut * 0.85f)
            v.skinFootR.ambient = maxOf(v.skinFootR.ambient, legRGroupOut * 0.85f)
            v.skinNeck.ambient = maxOf(v.skinNeck.ambient, headGroupOut * 0.8f)
        }
        v.skinAll.ambient = maxOf(v.skinAll.ambient, fullBodyOut)
    }
}
