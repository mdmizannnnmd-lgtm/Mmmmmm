package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object Enemy3dModelProtectPanels {
    fun build(ctx: Context, root: LinearLayout, b: Enemy3dModelProtectBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFEF9A9A.toInt()
        p.title("ENEMY 3D MODELS · AUTO THR · ROTATE/MOTION/LOOK-AT · MANIP · ALGO DECAY", c)
        p.switch("Enemy 3D model protect master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Automatic enemy model threshold", b.autoThrOn) { b.autoThrOn = it }
        p.seek("Auto thr margin", 0.05f, 0.4f, b.autoThrMargin) { b.autoThrMargin = it }
        p.seek("Enemy model thr / lv", 0.05f, 0.98f, b.enemyModelThr) { b.enemyModelThr = it }
        p.seek("Enemy model level", 0f, 1.5f, b.enemyModelLv) { b.enemyModelLv = it }
        p.switch("Rotate protection", b.rotateProtectOn) { b.rotateProtectOn = it }
        p.seek("Rotate protect level", 0.1f, 1f, b.rotateProtectLv) { b.rotateProtectLv = it }
        p.switch("Motion protection", b.motionProtectOn) { b.motionProtectOn = it }
        p.seek("Motion protect level", 0.1f, 1f, b.motionProtectLv) { b.motionProtectLv = it }
        p.switch("Look-at protection", b.lookAtProtectOn) { b.lookAtProtectOn = it }
        p.seek("Look-at protect level", 0.1f, 1f, b.lookAtProtectLv) { b.lookAtProtectLv = it }
        p.switch("Manipulation protection", b.manipProtectOn) { b.manipProtectOn = it }
        p.seek("Manip protect level", 0.1f, 1f, b.manipProtectLv) { b.manipProtectLv = it }
        p.switch("Algorithms decay ON", b.algoDecayOn) { b.algoDecayOn = it }
        p.seek("Algo decay rate", 0.01f, 0.5f, b.algoDecayRate) { b.algoDecayRate = it }
        p.seek("Algo decay floor", 0f, 0.5f, b.algoDecayFloor) { b.algoDecayFloor = it }
        val st = p.status("E3D PROT —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
