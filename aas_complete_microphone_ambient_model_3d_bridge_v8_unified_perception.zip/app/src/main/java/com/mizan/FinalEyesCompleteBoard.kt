package com.mizan

/**
 * Final tabs — full eyes settings (prior final eye channels + L/R ambient + brain/eye visual).
 * Multiple paths: ambient L/R · channels · optical · lines · dual gate · visual · brain link.
 */
class FinalEyesCompleteBoard {
    @Volatile var masterOn = true
    @Volatile var rawComplete = true
    @Volatile var dualPathOn = true

    // L/R ambient (final)
    @Volatile var leftOn = true
    @Volatile var leftThr = 0.30f
    @Volatile var leftLv = 0.55f
    @Volatile var rightOn = true
    @Volatile var rightThr = 0.30f
    @Volatile var rightLv = 0.55f
    @Volatile var sharedThr = 0.30f
    @Volatile var sharedLv = 0.55f
    @Volatile var eyeLinesProt = true
    @Volatile var opticalOn = true

    // Channel anatomy metrics (subset live outs)
    @Volatile var cornea = 0f
    @Volatile var lens = 0f
    @Volatile var retina = 0f
    @Volatile var opticNerve = 0f
    @Volatile var pupil = 0f
    @Volatile var iris = 0f

    // Visual L/R (final brain-eye)
    @Volatile var leftVisOn = true
    @Volatile var leftBright = 0.50f
    @Volatile var leftContrast = 0.50f
    @Volatile var leftVisLv = 0.55f
    @Volatile var leftVisThr = 0.30f
    @Volatile var leftColThr = 0.30f
    @Volatile var leftR = 0.50f
    @Volatile var leftG = 0.50f
    @Volatile var leftB = 0.50f
    @Volatile var rightVisOn = true
    @Volatile var rightBright = 0.50f
    @Volatile var rightContrast = 0.50f
    @Volatile var rightVisLv = 0.55f
    @Volatile var rightVisThr = 0.30f
    @Volatile var rightColThr = 0.30f
    @Volatile var rightR = 0.50f
    @Volatile var rightG = 0.50f
    @Volatile var rightB = 0.50f

    // Pitch protect
    @Volatile var pitchProtL = true
    @Volatile var pitchProtR = true
    @Volatile var pitchThrL = 0.30f
    @Volatile var pitchThrR = 0.30f
    @Volatile var pitchLvL = 0.70f
    @Volatile var pitchLvR = 0.70f

    @Volatile var bipNeg = 0f
    @Volatile var bipPos = 0f

    @Volatile var leftOut = 0f
    @Volatile var rightOut = 0f
    @Volatile var leftVisOut = 0f
    @Volatile var rightVisOut = 0f
    @Volatile var status = "FINAL-EYES idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float, drive: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv * drive).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f) * drive
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv * drive).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, model: Float = 1f) {
        if (!masterOn) { status = "FINAL-EYES OFF"; return }
        val drive = 0.25f + 0.75f * model.coerceIn(0f, 1f)
        val e = mic.coerceIn(0f, 1f)
        leftOut = lane(leftOn, leftThr, leftLv, e * 1.02f, drive)
        rightOut = lane(rightOn, rightThr, rightLv, e, drive)
        if (dualPathOn) {
            val sh = lane(true, sharedThr, sharedLv, e, drive)
            leftOut = maxOf(leftOut, sh * 0.5f)
            rightOut = maxOf(rightOut, sh * 0.5f)
        }
        leftVisOut = lane(leftVisOn, leftVisThr, leftVisLv, e * 1.01f, drive)
        rightVisOut = lane(rightVisOn, rightVisThr, rightVisLv, e, drive)
        cornea = leftOut * 0.9f; lens = leftOut * 0.85f; retina = rightOut * 0.9f
        opticNerve = maxOf(leftOut, rightOut) * if (opticalOn) 1f else 0.3f
        pupil = (leftOut + rightOut) * 0.5f; iris = pupil * 0.9f
        if (pitchProtL) leftOut *= (1f - pitchLvL * 0.15f).coerceIn(0.5f, 1f)
        if (pitchProtR) rightOut *= (1f - pitchLvR * 0.15f).coerceIn(0.5f, 1f)
        status = "FINAL-EYES L=${(leftOut*100).toInt()}% R=${(rightOut*100).toInt()}% " +
            "vis L/R=${(leftVisOut*100).toInt()}/${(rightVisOut*100).toInt()}% " +
            "opt=${(opticNerve*100).toInt()}%" + if (rawComplete) " · RAW" else ""
    }
    fun apply(v: VisualShieldView?) {
        if (!masterOn) return
        val vv = v ?: return
        try {
            vv.cnsEyesHeart.eyeLOut = maxOf(vv.cnsEyesHeart.eyeLOut, leftOut)
            vv.cnsEyesHeart.eyeROut = maxOf(vv.cnsEyesHeart.eyeROut, rightOut)
            try { vv.eyeBodyAtomSurface.eyeLOut = maxOf(vv.eyeBodyAtomSurface.eyeLOut, leftOut) } catch (_: Throwable) {}
            try { vv.eyeBodyAtomSurface.eyeROut = maxOf(vv.eyeBodyAtomSurface.eyeROut, rightOut) } catch (_: Throwable) {}
            try { vv.eyeBodyAtomSurface.eyeVisionOut = maxOf(vv.eyeBodyAtomSurface.eyeVisionOut, maxOf(leftVisOut, rightVisOut)) } catch (_: Throwable) {}
            try { vv.finalProtectionMain.lrEyesOut = maxOf(vv.finalProtectionMain.lrEyesOut, maxOf(leftOut, rightOut)) } catch (_: Throwable) {}
            try { vv.finalProtectionMain.eyeChOut = maxOf(vv.finalProtectionMain.eyeChOut, opticNerve) } catch (_: Throwable) {}
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, maxOf(leftOut, rightOut) * 0.4f)
        } catch (_: Throwable) {}
    }

}
