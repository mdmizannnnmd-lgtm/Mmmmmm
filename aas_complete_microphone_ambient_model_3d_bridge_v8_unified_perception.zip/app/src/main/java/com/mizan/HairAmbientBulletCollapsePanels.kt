package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object HairAmbientBulletCollapsePanels {
    fun build(ctx: Context, root: LinearLayout, b: HairAmbientBulletCollapseBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFBCAAA4.toInt()
        p.title("HAIR AMBIENT · BULLET COLLAPSE · COUNTERS · HEAD SIDES", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }

        p.title("HAIR AMBIENT (draw)", c)
        p.switch("Hair ambient ON", b.hairOn) { b.hairOn = it }
        p.switch("Hair auto threshold", b.hairAutoThr) { b.hairAutoThr = it }
        p.seek("Hair thr", 0.05f, 0.98f, b.hairThr) { b.hairThr = it }
        p.seek("Hair level", 0f, 1.5f, b.hairLv) { b.hairLv = it }

        p.title("BULLET COLLAPSE · LIVE MIC · COUNTERS", c)
        p.switch("Bullet collapse ON", b.bulletCollapseOn) { b.bulletCollapseOn = it }
        p.switch("Bullet auto threshold (mic analysis)", b.bulletCollapseAutoThr) { b.bulletCollapseAutoThr = it }
        p.seek("Bullet collapse thr", 0.05f, 0.98f, b.bulletCollapseThr) { b.bulletCollapseThr = it }
        p.seek("Bullet collapse level", 0f, 1.5f, b.bulletCollapseLv) { b.bulletCollapseLv = it }
        p.button("Reset bullet counters") { _ -> b.resetCounters() }

        p.title("HEAD FRONT · UP · DOWN · LEFT · RIGHT (default ON)", c)
        p.switch("Head front ON", b.headFrontOn) { b.headFrontOn = it }
        p.seek("Head front thr / lv", 0.05f, 0.98f, b.headFrontThr) { b.headFrontThr = it }
        p.seek("Head front level", 0f, 1.5f, b.headFrontLv) { b.headFrontLv = it }
        p.switch("Head up ON", b.headUpOn) { b.headUpOn = it }
        p.seek("Head up thr", 0.05f, 0.98f, b.headUpThr) { b.headUpThr = it }
        p.seek("Head up level", 0f, 1.5f, b.headUpLv) { b.headUpLv = it }
        p.switch("Head down ON", b.headDownOn) { b.headDownOn = it }
        p.seek("Head down thr", 0.05f, 0.98f, b.headDownThr) { b.headDownThr = it }
        p.seek("Head down level", 0f, 1.5f, b.headDownLv) { b.headDownLv = it }
        p.switch("Head left ON", b.headLeftOn) { b.headLeftOn = it }
        p.seek("Head left thr", 0.05f, 0.98f, b.headLeftThr) { b.headLeftThr = it }
        p.seek("Head left level", 0f, 1.5f, b.headLeftLv) { b.headLeftLv = it }
        p.switch("Head right ON", b.headRightOn) { b.headRightOn = it }
        p.seek("Head right thr", 0.05f, 0.98f, b.headRightThr) { b.headRightThr = it }
        p.seek("Head right level", 0f, 1.5f, b.headRightLv) { b.headRightLv = it }

        val st = p.status("HAIR·BULLET —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 250) }
        })
    }
}
