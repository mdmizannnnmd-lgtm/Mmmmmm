package com.mizan

/**
 * Mono tabs — full eyes settings (prior mono eye channels + cam brain/eye visual).
 * Multiple paths kept: ambient L/R · visual L/R · optical · lines · move/wave/speed · colour.
 */
class MonoEyesCompleteBoard {
    @Volatile var masterOn = true
    @Volatile var rawComplete = true

    // Ambient L/R
    @Volatile var leftAmbOn = true
    @Volatile var leftAmbThr = 0.30f
    @Volatile var leftAmbLv = 0.55f
    @Volatile var rightAmbOn = true
    @Volatile var rightAmbThr = 0.30f
    @Volatile var rightAmbLv = 0.55f
    @Volatile var sharedThr = 0.30f
    @Volatile var sharedLv = 0.55f
    @Volatile var eyeLinesProt = true
    @Volatile var opticalNerveOn = true

    // Visual path L/R
    @Volatile var leftVisOn = true
    @Volatile var leftBright = 0.50f
    @Volatile var leftContrast = 0.50f
    @Volatile var leftVisLv = 0.55f
    @Volatile var leftVisThr = 0.30f
    @Volatile var leftColThr = 0.30f
    @Volatile var leftR = 0.50f
    @Volatile var leftG = 0.50f
    @Volatile var leftB = 0.50f
    @Volatile var rightVisOn = true
    @Volatile var rightBright = 0.50f
    @Volatile var rightContrast = 0.50f
    @Volatile var rightVisLv = 0.55f
    @Volatile var rightVisThr = 0.30f
    @Volatile var rightColThr = 0.30f
    @Volatile var rightR = 0.50f
    @Volatile var rightG = 0.50f
    @Volatile var rightB = 0.50f

    // Move / wave / speed + bipolar
    @Volatile var moveLv = 0.50f
    @Volatile var moveThr = 0.30f
    @Volatile var waveLv = 0.50f
    @Volatile var waveThr = 0.30f
    @Volatile var speedLv = 0.50f
    @Volatile var speedThr = 0.30f
    @Volatile var bipNeg = 0f
    @Volatile var bipPos = 0f
    @Volatile var moveBipNeg = 0f
    @Volatile var moveBipPos = 0f
    @Volatile var waveBipNeg = 0f
    @Volatile var waveBipPos = 0f
    @Volatile var speedBipNeg = 0f
    @Volatile var speedBipPos = 0f

    // Filters (mono cam)
    @Volatile var lrFilter = 0.50f
    @Volatile var udFilter = 0.50f
    @Volatile var randomFilter = 0.30f
    @Volatile var centerFilter = 0.50f
    @Volatile var cornerFilter = 0.30f
    @Volatile var vibFilter = 0.30f
    @Volatile var atmosphere = 0.50f
    @Volatile var wavespare = 0.50f

    // Protect
    @Volatile var protectL = true
    @Volatile var protectR = true

    @Volatile var leftAmbOut = 0f
    @Volatile var rightAmbOut = 0f
    @Volatile var leftVisOut = 0f
    @Volatile var rightVisOut = 0f
    @Volatile var status = "MONO-EYES idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float, drive: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv * drive).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f) * drive
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv * drive).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, model: Float = 1f) {
        if (!masterOn) { status = "MONO-EYES OFF"; return }
        val drive = 0.25f + 0.75f * model.coerceIn(0f, 1f)
        val e = mic.coerceIn(0f, 1f)
        leftAmbOut = lane(leftAmbOn, leftAmbThr, leftAmbLv, e * 1.02f, drive)
        rightAmbOut = lane(rightAmbOn, rightAmbThr, rightAmbLv, e, drive)
        val shared = lane(true, sharedThr, sharedLv, e, drive)
        leftAmbOut = maxOf(leftAmbOut, shared * 0.5f)
        rightAmbOut = maxOf(rightAmbOut, shared * 0.5f)
        leftVisOut = lane(leftVisOn, leftVisThr, leftVisLv, e * 1.01f, drive)
        rightVisOut = lane(rightVisOn, rightVisThr, rightVisLv, e, drive)
        if (protectL && leftAmbOut > 0f) leftAmbOut *= 0.92f
        if (protectR && rightAmbOut > 0f) rightAmbOut *= 0.92f
        status = "MONO-EYES L amb=${(leftAmbOut*100).toInt()}% vis=${(leftVisOut*100).toInt()}% · " +
            "R amb=${(rightAmbOut*100).toInt()}% vis=${(rightVisOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }
    fun apply(v: VisualShieldView?) {
        val vv = v ?: return
        try {
            val l = try { leftAmbOut } catch (_: Throwable) { 0f }
            val r = try { rightAmbOut } catch (_: Throwable) { 0f }
            vv.cnsEyesHeart.eyeLOut = maxOf(vv.cnsEyesHeart.eyeLOut, l)
            vv.cnsEyesHeart.eyeROut = maxOf(vv.cnsEyesHeart.eyeROut, r)
            try { vv.eyeBodyAtomSurface.eyeLOut = maxOf(vv.eyeBodyAtomSurface.eyeLOut, l) } catch (_: Throwable) {}
            try { vv.eyeBodyAtomSurface.eyeROut = maxOf(vv.eyeBodyAtomSurface.eyeROut, r) } catch (_: Throwable) {}
        } catch (_: Throwable) {}
    }

}
