package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object CompleteAtomspareProtectPanels {
    fun build(ctx: Context, root: LinearLayout, b: CompleteAtomspareProtectBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF80CBC4.toInt()
        p.title("COMPLETE ATOMPARE (all previous) · FULL PROTECTION", c)
        p.note("Unifies skin·shell·84·sides·hair atomspare + no-break · abuse · isolation · MASTER/AR")
        p.switch("Complete atomspare master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Atomspare ON", b.atomOn) { b.atomOn = it }
        p.switch("Auto threshold", b.atomAutoThr) { b.atomAutoThr = it }
        p.seek("Atom thr", 0.05f, 0.98f, b.atomThr) { b.atomThr = it }
        p.seek("Atom level", 0f, 1.5f, b.atomLv) { b.atomLv = it }
        p.switch("All previous paths atmospheric", b.allPreviousAtmospheric) { b.allPreviousAtmospheric = it }
        p.note("Body atomspare: Center · Up · Down · Left · Right · Front · Back (all driven)")

        p.title("PROTECTION", c)
        p.switch("Protection master ON", b.protectOn) { b.protectOn = it }
        p.seek("Protect level", 0.1f, 1f, b.protectLv) { b.protectLv = it }
        p.switch("Enemy cannot break out atomspare", b.enemyCannotBreakOut) { b.enemyCannotBreakOut = it }
        p.switch("Enemy model abuse protect", b.enemyModelAbuseProtect) { b.enemyModelAbuseProtect = it }
        p.switch("Enemy atomspare abuse protect", b.enemyAtomAbuseProtect) { b.enemyAtomAbuseProtect = it }
        p.switch("Body isolation ON", b.isolationOn) { b.isolationOn = it }
        p.switch("MASTER shield ON", b.masterShieldOn) { b.masterShieldOn = it }
        p.switch("AR reality shield ON", b.arShieldOn) { b.arShieldOn = it }

        val st = p.status("ATOM+PROT —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 280) }
        })
    }
}
