package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object CnsEyesHeart3dPanels {
    fun build(ctx: Context, root: LinearLayout, b: CnsEyesHeart3dBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF81D4FA.toInt()
        p.title("CNS AMBIENT · 3D EYES · 3D HEART (linked)", c)
        p.switch("CNS·Eyes·Heart 3D master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.title("CNS AMBIENT", c)
        p.switch("CNS ambient ON", b.cnsOn) { b.cnsOn = it }
        p.seek("CNS threshold", 0.05f, 0.98f, b.cnsThr) { b.cnsThr = it }
        p.seek("CNS level", 0f, 1.5f, b.cnsLv) { b.cnsLv = it }
        p.switch("Left CNS ambient ON", b.cnsLOn) { b.cnsLOn = it }
        p.seek("Left CNS thr", 0.05f, 0.98f, b.cnsLThr) { b.cnsLThr = it }
        p.seek("Left CNS lv", 0f, 1.5f, b.cnsLLv) { b.cnsLLv = it }
        p.switch("Right CNS ambient ON", b.cnsROn) { b.cnsROn = it }
        p.seek("Right CNS thr", 0.05f, 0.98f, b.cnsRThr) { b.cnsRThr = it }
        p.seek("Right CNS lv", 0f, 1.5f, b.cnsRLv) { b.cnsRLv = it }
        p.switch("Full model head ON", b.modelHeadOn) { b.modelHeadOn = it }
        p.seek("Model head thr / lv", 0.05f, 0.98f, b.modelHeadThr) { b.modelHeadThr = it }
        p.seek("Model head level", 0f, 1.5f, b.modelHeadLv) { b.modelHeadLv = it }
        p.seek("CNS → eyes link", 0f, 1.5f, b.cnsToEyesLink) { b.cnsToEyesLink = it }
        p.seek("CNS → heart link", 0f, 1.5f, b.cnsToHeartLink) { b.cnsToHeartLink = it }
        p.title("FULL 3D EYES (CNS-linked)", c)
        p.note("L/R outs: sclera·cornea·conjunctiva·iris·pupil·lens·aqueous·vitreous·retina·macula·choroid·ciliary·optic nerve")
        p.switch("3D eyes ON", b.eyes3dOn) { b.eyes3dOn = it }
        p.switch("Eye detail 3D (iris/pupil)", b.eyeDetailOn) { b.eyeDetailOn = it }
        p.switch("Optical 3D (CNS→optic)", b.optical3dOn) { b.optical3dOn = it }
        p.switch("Gaze from CNS", b.gazeFromCns) { b.gazeFromCns = it }
        p.switch("Left eye ON", b.eyeLOn) { b.eyeLOn = it }
        p.switch("Right eye ON", b.eyeROn) { b.eyeROn = it }
        p.seek("Left eye thr / lv", 0.05f, 0.98f, b.eyeLThr) { b.eyeLThr = it }
        p.seek("Left eye level", 0f, 1.5f, b.eyeLLv) { b.eyeLLv = it }
        p.seek("Right eye thr", 0.05f, 0.98f, b.eyeRThr) { b.eyeRThr = it }
        p.seek("Right eye level", 0f, 1.5f, b.eyeRLv) { b.eyeRLv = it }
        p.seek("Eye bright / contrast", 0f, 1f, b.eyeBright) { b.eyeBright = it }
        p.seek("Eye contrast", 0f, 1f, b.eyeContrast) { b.eyeContrast = it }
        p.seek("Eye 3D depth", 0f, 1f, b.eyeDepth3d) { b.eyeDepth3d = it }
        p.title("HEART 3D", c)
        p.switch("Heart 3D ON", b.heart3dOn) { b.heart3dOn = it }
        p.switch("Heartbeat from CNS", b.heartBeatFromCns) { b.heartBeatFromCns = it }
        p.seek("Heart thr", 0.05f, 0.98f, b.heartThr) { b.heartThr = it }
        p.seek("Heart level", 0f, 1.5f, b.heartLv) { b.heartLv = it }
        p.seek("Heart 3D depth", 0f, 1f, b.heartDepth3d) { b.heartDepth3d = it }
        val st = p.status("CNS·EYES·HEART —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 250) }
        })
    }
}
