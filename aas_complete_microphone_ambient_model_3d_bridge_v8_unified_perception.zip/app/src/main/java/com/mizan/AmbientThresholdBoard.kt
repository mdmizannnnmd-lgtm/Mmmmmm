package com.mizan

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Ambient threshold board:
 *  - Ambient threshold level (%), live output vs user-locked
 *  - Bipolar ambient threshold −120 … +120 (dual rails, not single)
 *  - Threshold dB gain bipolar −300 … +300 (dual rails: neg gain + pos gain)
 *  - Limiter −300 … +300 dB
 *  - Multiple decay rails: fast / mid / slow (not single)
 *  - Mirror
 *  - LIVE MICROPHONE dB output (dBFS + calibrated-offset dB) and AUTO threshold that follows the room's noise floor
 *  - CENTROID (spectral centre of the sound, Hz) with LEVEL · THRESHOLD · BIPOLAR (− / + rails) · RAW COMPLETE
 *  - VERTICAL (height of the body centroid, feet → head) with LEVEL · THRESHOLD · BIPOLAR · RAW COMPLETE
 */
class AmbientThresholdBoard {

    @Volatile var enabled = true

    @Volatile var ambientThrPct = 3.2f
    @Volatile var liveOutput = true
    @Volatile var lockedPct = 3.2f

    /** Bipolar ambient threshold −120 … +120 (two rails) */
    @Volatile var bipolarNeg = -40f
    @Volatile var bipolarPos = 40f

    /** Threshold dB gain bipolar −300 … +300 (two rails, not a single gain) */
    @Volatile var thrGainNegDb = 0f   // applied when signal is on negative side
    @Volatile var thrGainPosDb = 0f   // applied when signal is on positive side

    @Volatile var limiterDb = 120f
    @Volatile var limiterOn = true

    /** Multiple decay rails (ms) — not a single decay */
    @Volatile var decayFastMs = 80
    @Volatile var decayMidMs = 180
    @Volatile var decaySlowMs = 450
    @Volatile var decayFastW = 0.40f
    @Volatile var decayMidW = 0.35f
    @Volatile var decaySlowW = 0.25f

    @Volatile var mirrorOn = false

    /** MOVEMENT output of the ambient threshold: device · body · ambient · camera motion → the 3D anatomy body (inside + outside). */
    val movement = AmbientMovement()

    // ── LIVE MICROPHONE dB + AUTO THRESHOLD ──────────────────────────────────────────────────────
    /** Live mic level, dBFS (0 = full scale). Updated by [feedAnalysis] from the real microphone. */
    @Volatile var micDbfs = -90.0
    /** Time of the last real microphone block (for "is the mic live"). */
    @Volatile var lastFeedMs = 0L
    fun micFresh(): Boolean = System.currentTimeMillis() - lastFeedMs < 1000L
    @Volatile var micPeakDbfs = -90.0
    /** Uncalibrated phone microphones cannot report true SPL; this offset turns dBFS into a readable "dB" (0 dB ≈ −90 dBFS). */
    @Volatile var dbOffset = 90f
    @Volatile var autoThr = true
    /** AUTO threshold = tracked noise floor + this margin (dB); the Ambient Threshold slider stays the minimum. */
    @Volatile var autoMarginDb = 10f
    @Volatile var noiseFloorDb = -80.0
        private set
    @Volatile var autoThrDb = -70.0
        private set
    @Volatile var autoThrPct = 3.2f
        private set

    // ── spectrum (for the board display) ─────────────────────────────────────────────────────────
    @Volatile var bands = FloatArray(LiveSpectrumAnalyzer.BANDS)
    @Volatile var wave = FloatArray(LiveSpectrumAnalyzer.WAVE_POINTS)
    @Volatile var domHz = 0f
    @Volatile var centroidHz = 0f
    @Volatile var atmoPct = 0f

    // ── CENTROID (spectral): level · threshold · bipolar · raw ───────────────────────────────────
    @Volatile var centroidOn = true
    @Volatile var centroidLevel = 0.85f      // 0..1.5 how much of the drive is used
    @Volatile var centroidThr = 0.30f        // 0..0.98 centre point of the bipolar drive (log-Hz scale 20 Hz … 20 kHz)
    @Volatile var centroidBipolar = true
    @Volatile var centroidNegGain = 1.0f     // rail below the threshold (darker sound)
    @Volatile var centroidPosGain = 1.0f     // rail above the threshold (brighter sound)
    @Volatile var centroidRaw = false        // RAW COMPLETE: no level, threshold or smoothing
    @Volatile var centroidNorm = 0f          // 0..1 position on the log-Hz scale
        private set
    @Volatile var centroidBip = 0f           // signed −1..+1 around the threshold
        private set
    @Volatile var centroidOut = 0f           // 0..1 magnitude after level + threshold
        private set
    @Volatile var centroidHit = false
        private set

    // ── VERTICAL (body centroid height): level · threshold · bipolar · raw ───────────────────────
    @Volatile var verticalOn = true
    @Volatile var verticalLevel = 0.85f
    @Volatile var verticalThr = 0.55f        // 0..0.98 (0 = feet, 1 = head top); default ≈ chest height
    @Volatile var verticalBipolar = true
    @Volatile var verticalNegGain = 1.0f
    @Volatile var verticalPosGain = 1.0f
    @Volatile var verticalRaw = false
    @Volatile var verticalNorm = 0.5f
        private set
    @Volatile var verticalBip = 0f
        private set
    @Volatile var verticalOut = 0f
        private set
    @Volatile var verticalHit = false

    // ── DOMINATION Hz (dominant frequency): level · threshold · output · RAW ─────────────────────
    @Volatile var dominationOn = true
    @Volatile var dominationLevel = 0.85f
    @Volatile var dominationThr = 0.30f
    @Volatile var dominationBipolar = true
    @Volatile var dominationNegGain = 1.0f
    @Volatile var dominationPosGain = 1.0f
    @Volatile var dominationRaw = false
    @Volatile var dominationHzMin = 20f
    @Volatile var dominationHzMax = 8000f
    @Volatile var dominationSmooth = 0.25f
    @Volatile var dominationHz = 0f
    @Volatile var dominationNorm = 0f
    @Volatile var dominationBip = 0f
    @Volatile var dominationOut = 0f
    @Volatile var dominationHit = false
    private var domSmooth = 0f
        private set
    /** Body centroid in body units (set by the 3D body each frame through [feedBody]). */
    @Volatile var bodyCx = 0f
        private set
    @Volatile var bodyCy = 0.6f
        private set
    @Volatile var bodyStrength = 0f
    /** Inside anatomy (organs · skeleton · vessels) vs outside (skin · face) centroid/vertical drives. */
    @Volatile var insideCenOut = 0f
    @Volatile var insideVerOut = 0f
    @Volatile var outsideCenOut = 0f
    @Volatile var outsideVerOut = 0f
    @Volatile var insideHz = 0f
    @Volatile var outsideHz = 0f
        private set
    /** Set by the ONENESS "RAW EVERYTHING" switch — forces RAW COMPLETE on centroid and vertical. */
    @Volatile var rawEverything = false

    private var cenSmooth = 0f
    private var verSmooth = 0.5f

    @Volatile var rmsPct = 0f
    @Volatile var pkPct = 0f
    @Volatile var ambientOutPct = 0f
    @Volatile var effectiveDb = -80.0
    @Volatile var limitedDb = -80.0
    @Volatile var silence = true
    @Volatile var overThr = false
    @Volatile var limited = false
    @Volatile var bipolarHit = false
    @Volatile var gainNegHit = false
    @Volatile var gainPosHit = false

    private var envFast = 0f
    private var envMid = 0f
    private var envSlow = 0f
    private var env = 0f
    private var lastTs = System.currentTimeMillis()

    fun tick(rms: Float, peak: Float, rawDb: Double) {
        val now = System.currentTimeMillis()
        val dt = (now - lastTs).coerceIn(1L, 80L)
        lastTs = now

        rmsPct = (rms * 100f).coerceIn(0f, 100f)
        pkPct = (peak * 100f).coerceIn(0f, 100f)

        // Dual bipolar threshold dB gain (−300…0 and 0…+300)
        val gNeg = thrGainNegDb.coerceIn(-300f, 0f)
        val gPos = thrGainPosDb.coerceIn(0f, 300f)
        gainNegHit = rawDb < 0.0
        gainPosHit = rawDb >= 0.0
        val gain = when {
            rawDb < 0.0 -> gNeg
            else -> gPos
        }
        effectiveDb = rawDb + gain

        // Bipolar ambient threshold (dual rails)
        val lo = bipolarNeg.coerceIn(-120f, 0f).toDouble()
        val hi = bipolarPos.coerceIn(0f, 120f).toDouble()
        bipolarHit = effectiveDb <= lo || effectiveDb >= hi

        limited = false
        limitedDb = effectiveDb
        if (limiterOn) {
            val lim = abs(limiterDb).coerceIn(0f, 300f).toDouble()
            if (effectiveDb > lim) {
                limitedDb = lim
                limited = true
            } else if (effectiveDb < -lim) {
                limitedDb = -lim
                limited = true
            }
        }

        // Multiple decay envelope (fast + mid + slow weighted)
        val energy = min(1f, max(rms, peak))
        fun stepEnv(prev: Float, tauMs: Int): Float {
            var e = prev
            if (energy > e) e = energy
            else {
                val tau = tauMs.coerceIn(10, 5000).toFloat()
                e *= exp(-dt.toFloat() / tau).toFloat()
            }
            return e
        }
        envFast = stepEnv(envFast, decayFastMs)
        envMid = stepEnv(envMid, decayMidMs)
        envSlow = stepEnv(envSlow, decaySlowMs)
        val wSum = (decayFastW + decayMidW + decaySlowW).coerceAtLeast(0.01f)
        env = (
            envFast * decayFastW +
            envMid * decayMidW +
            envSlow * decaySlowW
        ) / wSum

        if (mirrorOn) {
            val thr = effectiveThrPct() / 100f
            val d = env - thr
            env = (thr - d).coerceIn(0f, 1f)
        }

        val thrPct = effectiveThrPct()
        ambientOutPct = (env * 100f).coerceIn(0f, 100f)
        overThr = ambientOutPct >= thrPct || bipolarHit
        silence = rmsPct < 0.5f && pkPct < 0.5f && !overThr
    }

    /** The slider value (live) or the locked value. */
    fun manualThrPct(): Float = if (liveOutput) ambientThrPct else lockedPct

    /**
     * Threshold actually in use (%). With AUTO on it is the HIGHER of the slider value and the live noise floor + margin:
     * the slider is the minimum (a quiet room never drops below it), and a noisy room raises the threshold above its own noise.
     */
    fun effectiveThrPct(): Float =
        if (autoThr && liveOutput) max(manualThrPct(), autoThrPct) else manualThrPct()

    /** Calibrated-offset live microphone level (dB). */
    fun micDb(): Double = micDbfs + dbOffset

    /**
     * Called by [AudioProcessor] for every audio block with the live microphone analysis.
     * [dbOut] is the same "dB output" the rest of the app uses (mic level after the amplifier) — the AUTO threshold tracks
     * its noise floor: it falls at once when the room gets quieter and rises slowly (~10 s) so speech / noise never drags it up.
     */
    fun feedAnalysis(a: LiveSpectrumAnalyzer, dbOut: Double) {
        lastFeedMs = System.currentTimeMillis()
        micDbfs = a.rmsDbfs
        micPeakDbfs = a.peakDbfs
        bands = a.bands
        wave = a.wave
        domHz = a.domHz
        centroidHz = a.centroidHz
        dominationHz = a.domHz
        atmoPct = a.atmoPct

        // AUTO threshold from the live dB output
        val db = dbOut.coerceIn(-90.0, 0.0)
        noiseFloorDb += (db - noiseFloorDb) * (if (db < noiseFloorDb) 0.25 else 0.004)
        autoThrDb = (noiseFloorDb + autoMarginDb.coerceIn(0f, 60f)).coerceAtMost(0.0)
        autoThrPct = (100.0 * 10.0.pow(autoThrDb / 20.0)).toFloat().coerceIn(0.2f, 100f)

        // CENTROID shaping
        val raw = centroidRaw || rawEverything
        val hz = a.centroidHz
        val norm = if (hz <= 0f) 0f else (ln(hz.coerceIn(LiveSpectrumAnalyzer.F_MIN, LiveSpectrumAnalyzer.F_MAX) / LiveSpectrumAnalyzer.F_MIN) /
            ln(LiveSpectrumAnalyzer.F_MAX / LiveSpectrumAnalyzer.F_MIN)).toFloat()
        cenSmooth = if (raw) norm else cenSmooth + (norm - cenSmooth) * 0.25f
        centroidNorm = cenSmooth
        val c = shapeBipolar(cenSmooth, centroidThr, centroidLevel, centroidBipolar, centroidNegGain, centroidPosGain, raw, centroidOn)
        centroidBip = c.first
        centroidOut = c.second
        centroidHit = centroidOn && centroidOut > 0.02f
        // Domination Hz path (parallel to centroid) — full adjustable
        run {
            val raw = dominationRaw || rawEverything
            val hz = dominationHz
            val fMin = dominationHzMin.coerceIn(20f, 19000f)
            val fMax = dominationHzMax.coerceIn(fMin + 50f, 20000f)
            val n = if (hz <= fMin) 0f else {
                val logMin = kotlin.math.ln(fMin.toDouble())
                val logMax = kotlin.math.ln(fMax.toDouble())
                ((kotlin.math.ln(hz.toDouble().coerceIn(fMin.toDouble(), fMax.toDouble())) - logMin) / (logMax - logMin)).toFloat().coerceIn(0f, 1f)
            }
            val sm = if (raw) 1f else dominationSmooth.coerceIn(0.05f, 1f)
            domSmooth = if (raw) n else domSmooth + (n - domSmooth) * sm
            dominationNorm = domSmooth
            val d = shapeBipolar(domSmooth, dominationThr, dominationLevel, dominationBipolar, dominationNegGain, dominationPosGain, raw, dominationOn)
            dominationBip = d.first
            dominationOut = d.second
            dominationHit = dominationOn && dominationOut > 0.02f
        }
    }

    /** Called every frame by the 3D body with the MASTER (or original) centroid, in body units (y up, feet −0.95 … head 1.75). */
    fun feedBody(cx: Float, cy: Float, strength: Float, active: Boolean) {
        bodyCx = cx; bodyCy = cy; bodyStrength = strength
        val raw = verticalRaw || rawEverything
        val norm = ((cy + 0.95f) / 2.70f).coerceIn(0f, 1f)
        verSmooth = if (raw) norm else verSmooth + (norm - verSmooth) * 0.25f
        verticalNorm = verSmooth
        val v = shapeBipolar(verSmooth, verticalThr, verticalLevel, verticalBipolar, verticalNegGain, verticalPosGain, raw, verticalOn && (active || raw))
        verticalBip = v.first
        verticalOut = v.second
        verticalHit = verticalOn && verticalOut > 0.02f
        // Inside (deeper layers) lean vertical; outside (skin) lean spectral centroid
        val cen = centroidOut
        val ver = verticalOut
        insideCenOut = (cen * 0.45f + ver * 0.55f).coerceIn(0f, 1.5f)
        insideVerOut = ver
        outsideCenOut = cen
        outsideVerOut = (cen * 0.55f + ver * 0.45f).coerceIn(0f, 1.5f)
        insideHz = (centroidHz * 0.7f + (domHz.takeIf { it > 1f } ?: centroidHz) * 0.3f)
        outsideHz = centroidHz
    }

    /**
     * Bipolar shaping around [thr]: above it the drive is positive, below it negative (each rail with its own gain), at the
     * threshold it is exactly 0. Returns (signed −1..+1, magnitude 0..1). RAW COMPLETE: no threshold, no level.
     */
    private fun shapeBipolar(
        x: Float, thr: Float, level: Float, bipolar: Boolean, negGain: Float, posGain: Float, raw: Boolean, on: Boolean
    ): Pair<Float, Float> {
        if (!on) return Pair(0f, 0f)
        val s = x.coerceIn(0f, 1f)
        if (raw) return Pair(s * 2f - 1f, s)
        val t = thr.coerceIn(0.02f, 0.98f)
        val lv = level.coerceIn(0f, 1.5f)
        val signed = when {
            s >= t -> ((s - t) / (1f - t)) * posGain.coerceIn(0f, 1.5f)
            bipolar -> -((t - s) / t) * negGain.coerceIn(0f, 1.5f)
            else -> 0f
        }
        val bip = (signed * lv).coerceIn(-1f, 1f)
        val out = (if (s >= t) abs(bip) else 0f).coerceIn(0f, 1f)
        return Pair(bip, out)
    }

    /** One line for the readout: live mic dB, auto threshold, centroid and vertical. */
    fun allSystemsLine(): String = AmbientSystems.line(AmbientSystems.snapshot(this))

    fun liveLine(): String {
        val db = micDb()
        return "3D BODY · CEN ${centroidHz.toInt()}Hz DOM ${dominationHz.toInt()}Hz out=${(dominationOut*100).toInt()}% ${"%+.0f".format(db)}dB · " +
            "VERT ${(verticalNorm * 100).toInt()}% · " +
            "IN ${insideHz.toInt()}Hz C${(insideCenOut*100).toInt()}% V${(insideVerOut*100).toInt()}% · " +
            "OUT ${outsideHz.toInt()}Hz C${(outsideCenOut*100).toInt()}% V${(outsideVerOut*100).toInt()}%" +
            " · " + movement.line() +
            (if (rawEverything) " · RAW" else "")
    }
    fun gateFactor(): Float {
        if (!enabled) return 1f
        var f = 1f
        if (overThr) f *= 0.55f
        if (limited) f *= 0.70f
        if (bipolarHit) f *= 0.60f
        return f.coerceIn(0.15f, 1f)
    }

    fun statusLine(): String {
        val mode = if (liveOutput) "LIVE" else "LOCKED"
        val sil = if (silence) "SILENCE" else if (overThr) "OVER-THR" else "OPEN"
        val lim = if (limited) "LIM" else "-"
        val mir = if (mirrorOn) "MIR" else "-"
        val gSide = when {
            gainNegHit -> "gNeg"
            gainPosHit -> "gPos"
            else -> "g—"
        }
        return liveLine() + "\n" + "$sil · RMS ${"%.1f".format(rmsPct)}% · PK ${"%.1f".format(pkPct)}% · Amb ${"%.1f".format(ambientOutPct)}% thr=${"%.1f".format(effectiveThrPct())}% [$mode] · dB=${"%.1f".format(limitedDb)} gain=${"%.0f".format(thrGainNegDb)}/${"%.0f".format(thrGainPosDb)} ($gSide) · bip=${"%.0f".format(bipolarNeg)}/+${"%.0f".format(bipolarPos)} · decay F/M/S=$decayFastMs/$decayMidMs/${decaySlowMs}ms · $lim $mir"
    }
    fun apply(v: VisualShieldView?) { /* threshold config state */ }

}
