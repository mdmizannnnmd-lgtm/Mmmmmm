package com.mizan

/**
 * Biological ambient — skin layers · cells · nucleus · DNA/RNA analysis ·
 * glands (exo/endo) · membranes · blood elements · screen 3D + ambient.
 * Symbolic in-app visualization only — not medical diagnosis. RAW COMPLETE.
 */
class BioSkinCellAmbientBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.20f
    @Volatile var lv = 0.85f

    // Skin layers (epidermis → dermis → hypodermis + epidermal strata)
    @Volatile var skinLayersOn = true
    @Volatile var epidermisOut = 0f
    @Volatile var stratumBasale = 0f
    @Volatile var stratumSpinosum = 0f
    @Volatile var stratumGranulosum = 0f
    @Volatile var stratumLucidum = 0f
    @Volatile var stratumCorneum = 0f
    @Volatile var dermisOut = 0f
    @Volatile var hypodermisOut = 0f
    @Volatile var keratinocyte = 0f
    @Volatile var melanocyte = 0f
    @Volatile var langerhans = 0f

    // Skin glands
    @Volatile var glandsOn = true
    @Volatile var sweatGland = 0f
    @Volatile var sebaceousGland = 0f
    // Endocrine set
    @Volatile var pituitary = 0f
    @Volatile var thyroid = 0f
    @Volatile var parathyroid = 0f
    @Volatile var adrenal = 0f
    @Volatile var pancreas = 0f
    @Volatile var gonad = 0f
    @Volatile var pineal = 0f
    @Volatile var thymus = 0f
    // Bilateral + full gland set (symbolic)
    @Volatile var pinealL = 0f
    @Volatile var pinealR = 0f  // midline organ — L/R drive channels for ambient symmetry
    @Volatile var pituitaryL = 0f
    @Volatile var pituitaryR = 0f
    @Volatile var thyroidL = 0f
    @Volatile var thyroidR = 0f
    @Volatile var parathyroidL = 0f
    @Volatile var parathyroidR = 0f
    @Volatile var adrenalL = 0f
    @Volatile var adrenalR = 0f
    @Volatile var salivaryL = 0f
    @Volatile var salivaryR = 0f
    @Volatile var lacrimalL = 0f
    @Volatile var lacrimalR = 0f
    @Volatile var mammaryL = 0f
    @Volatile var mammaryR = 0f
    @Volatile var gonadL = 0f
    @Volatile var gonadR = 0f
    @Volatile var thymusL = 0f
    @Volatile var thymusR = 0f
    @Volatile var pancreasHead = 0f
    @Volatile var pancreasBody = 0f
    @Volatile var pancreasTail = 0f
    @Volatile var glandsBrainOut = 0f
    @Volatile var glandsBodyOut = 0f
    @Volatile var glandsFullOut = 0f
    // More glands + refined brain vs body
    @Volatile var hypothalamusGland = 0f
    @Volatile var parathyroidSuperiorL = 0f
    @Volatile var parathyroidSuperiorR = 0f
    @Volatile var parathyroidInferiorL = 0f
    @Volatile var parathyroidInferiorR = 0f
    @Volatile var adrenalCortexL = 0f
    @Volatile var adrenalCortexR = 0f
    @Volatile var adrenalMedullaL = 0f
    @Volatile var adrenalMedullaR = 0f
    @Volatile var isletsPancreas = 0f
    @Volatile var liverBile = 0f
    @Volatile var gastricGland = 0f
    @Volatile var intestinalGland = 0f
    @Volatile var prostateSkene = 0f
    @Volatile var ceruminousL = 0f
    @Volatile var ceruminousR = 0f
    @Volatile var eardrumL = 0f
    @Volatile var eardrumR = 0f
    @Volatile var ossicleL = 0f
    @Volatile var ossicleR = 0f
    @Volatile var earSkinL = 0f
    @Volatile var earSkinR = 0f
    // Regional cells + belly skin sides + crown / full brain
    @Volatile var bellySkinFront = 0f
    @Volatile var bellySkinL = 0f
    @Volatile var bellySkinR = 0f
    @Volatile var bellyCells = 0f
    @Volatile var faceCells = 0f
    @Volatile var neckCells = 0f
    @Volatile var eyeCellsL = 0f
    @Volatile var eyeCellsR = 0f
    @Volatile var brainCells = 0f
    @Volatile var nonCellMatrix = 0f  // extracellular / matrix path
    @Volatile var crownHeadUp = 0f
    @Volatile var headUpSideL = 0f
    @Volatile var headUpSideR = 0f
    @Volatile var fullBrainOut = 0f
    @Volatile var meibomianL = 0f
    @Volatile var meibomianR = 0f
    @Volatile var glandsBrainOnly = 0f
    @Volatile var glandsBodyOnly = 0f
    @Volatile var glandsNeck = 0f
    @Volatile var glandsAbdomen = 0f
    @Volatile var glandsHeadSurface = 0f

    // Membranes
    @Volatile var membranesOn = true
    @Volatile var mucousMembrane = 0f
    @Volatile var serousMembrane = 0f
    @Volatile var synovialMembrane = 0f
    @Volatile var cutaneousMembrane = 0f
    @Volatile var meninges = 0f

    // Cell / organelle ambient
    @Volatile var cellOn = true
    @Volatile var cellMembrane = 0f
    @Volatile var cytoplasm = 0f
    @Volatile var nucleus = 0f
    @Volatile var mitochondria = 0f
    @Volatile var ribosome = 0f
    @Volatile var erRough = 0f
    @Volatile var erSmooth = 0f
    @Volatile var golgi = 0f
    @Volatile var lysosome = 0f
    @Volatile var centrosome = 0f

    // DNA / RNA analysis (symbolic energy paths)
    @Volatile var dnaRnaOn = true
    @Volatile var dnaOut = 0f
    @Volatile var rnaOut = 0f
    @Volatile var dnaIntegrity = 0f
    @Volatile var rnaExpression = 0f

    // Blood elements
    @Volatile var bloodOn = true
    @Volatile var plasma = 0f
    @Volatile var rbc = 0f
    @Volatile var wbc = 0f
    @Volatile var platelet = 0f
    @Volatile var hemoglobin = 0f

    @Volatile var bioFullOut = 0f
    @Volatile var status = "BIO SKIN·CELL·GLAND·DNA idle"

    private fun lane(on: Boolean, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float) {
        if (!enabled) {
            status = "BIO OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)

        // Skin layers
        epidermisOut = lane(skinLayersOn, e)
        stratumBasale = epidermisOut * 0.95f
        stratumSpinosum = epidermisOut * 0.93f
        stratumGranulosum = epidermisOut * 0.91f
        stratumLucidum = epidermisOut * 0.88f
        stratumCorneum = epidermisOut * 0.96f
        dermisOut = lane(skinLayersOn, e * 0.97f)
        hypodermisOut = lane(skinLayersOn, e * 0.94f)
        keratinocyte = epidermisOut * 0.94f
        melanocyte = epidermisOut * 0.90f
        langerhans = epidermisOut * 0.86f

        // Glands
        sweatGland = lane(glandsOn, e * 0.92f)
        sebaceousGland = lane(glandsOn, e * 0.90f)
        pituitary = lane(glandsOn, e * 0.88f)
        thyroid = lane(glandsOn, e * 0.90f)
        parathyroid = lane(glandsOn, e * 0.86f)
        adrenal = lane(glandsOn, e * 0.91f)
        pancreas = lane(glandsOn, e * 0.89f)
        gonad = lane(glandsOn, e * 0.85f)
        pineal = lane(glandsOn, e * 0.87f)
        thymus = lane(glandsOn, e * 0.84f)
        // L/R and regional
        pinealL = pineal * 0.98f; pinealR = pineal * 0.97f
        pituitaryL = pituitary * 0.98f; pituitaryR = pituitary * 0.97f
        thyroidL = thyroid * 0.98f; thyroidR = thyroid * 0.97f
        parathyroidL = parathyroid * 0.96f; parathyroidR = parathyroid * 0.96f
        adrenalL = adrenal * 0.98f; adrenalR = adrenal * 0.97f
        salivaryL = lane(glandsOn, e * 0.86f); salivaryR = salivaryL * 0.98f
        lacrimalL = lane(glandsOn, e * 0.85f); lacrimalR = lacrimalL * 0.98f
        mammaryL = lane(glandsOn, e * 0.82f); mammaryR = mammaryL * 0.98f
        gonadL = gonad * 0.98f; gonadR = gonad * 0.97f
        thymusL = thymus * 0.98f; thymusR = thymus * 0.97f
        pancreasHead = pancreas * 0.95f
        pancreasBody = pancreas * 0.93f
        pancreasTail = pancreas * 0.91f
        hypothalamusGland = lane(glandsOn, e * 0.89f)
        parathyroidSuperiorL = parathyroidL * 0.95f
        parathyroidSuperiorR = parathyroidR * 0.95f
        parathyroidInferiorL = parathyroidL * 0.93f
        parathyroidInferiorR = parathyroidR * 0.93f
        adrenalCortexL = adrenalL * 0.96f
        adrenalCortexR = adrenalR * 0.96f
        adrenalMedullaL = adrenalL * 0.94f
        adrenalMedullaR = adrenalR * 0.94f
        isletsPancreas = pancreas * 0.92f
        liverBile = lane(glandsOn, e * 0.83f)
        gastricGland = lane(glandsOn, e * 0.81f)
        intestinalGland = lane(glandsOn, e * 0.80f)
        prostateSkene = lane(glandsOn, e * 0.78f)
        ceruminousL = lane(glandsOn, e * 0.84f)
        ceruminousR = ceruminousL * 0.98f
        meibomianL = lane(glandsOn, e * 0.85f)
        meibomianR = meibomianL * 0.98f

        // Refined separation: intracranial / CNS-adjacent vs peripheral body
        glandsBrainOnly = maxOf(
            pineal, pinealL, pinealR,
            pituitary, pituitaryL, pituitaryR,
            hypothalamusGland
        )
        glandsNeck = maxOf(thyroid, thyroidL, thyroidR, parathyroid, parathyroidL, parathyroidR, thymus, thymusL, thymusR)
        glandsAbdomen = maxOf(
            adrenal, adrenalL, adrenalR, adrenalCortexL, adrenalMedullaL,
            pancreas, pancreasHead, isletsPancreas, liverBile, gastricGland, intestinalGland, gonad, gonadL, gonadR
        )
        glandsHeadSurface = maxOf(salivaryL, salivaryR, lacrimalL, lacrimalR, ceruminousL, meibomianL, sweatGland * 0.5f)
        glandsBrainOut = glandsBrainOnly
        glandsBodyOut = maxOf(glandsNeck, glandsAbdomen, glandsHeadSurface, sebaceousGland, mammaryL, prostateSkene)
        glandsFullOut = maxOf(glandsBrainOnly, glandsBodyOut)

        // Membranes
        mucousMembrane = lane(membranesOn, e * 0.90f)
        serousMembrane = lane(membranesOn, e * 0.88f)
        synovialMembrane = lane(membranesOn, e * 0.86f)
        cutaneousMembrane = maxOf(epidermisOut, dermisOut)
        meninges = lane(membranesOn, e * 0.89f)

        // Cell
        cellMembrane = lane(cellOn, e)
        cytoplasm = cellMembrane * 0.95f
        nucleus = lane(cellOn, e * 0.96f)
        mitochondria = lane(cellOn, e * 0.93f)
        ribosome = lane(cellOn, e * 0.90f)
        erRough = lane(cellOn, e * 0.88f)
        erSmooth = lane(cellOn, e * 0.86f)
        golgi = lane(cellOn, e * 0.87f)
        lysosome = lane(cellOn, e * 0.85f)
        centrosome = lane(cellOn, e * 0.84f)

        // DNA / RNA symbolic
        dnaOut = lane(dnaRnaOn, e * 0.95f)
        rnaOut = lane(dnaRnaOn, e * 0.92f)
        dnaIntegrity = dnaOut * 0.95f
        rnaExpression = rnaOut * 0.93f

        // Blood
        plasma = lane(bloodOn, e * 0.90f)
        rbc = lane(bloodOn, e * 0.93f)
        wbc = lane(bloodOn, e * 0.88f)
        platelet = lane(bloodOn, e * 0.86f)
        hemoglobin = rbc * 0.95f

        
        // Belly skin sides + regional cells + crown + full brain
        bellySkinFront = lane(skinLayersOn, e * 0.94f)
        bellySkinL = lane(skinLayersOn, e * 0.92f)
        bellySkinR = lane(skinLayersOn, e * 0.92f)
        bellyCells = lane(cellOn, e * 0.90f)
        faceCells = lane(cellOn, e * 0.93f)
        neckCells = lane(cellOn, e * 0.91f)
        eyeCellsL = lane(cellOn, e * 0.92f)
        eyeCellsR = lane(cellOn, e * 0.92f)
        brainCells = lane(cellOn, e * 0.95f)
        nonCellMatrix = lane(cellOn, e * 0.88f)
        crownHeadUp = lane(cellOn, e * 0.87f)
        headUpSideL = lane(cellOn, e * 0.86f)
        headUpSideR = lane(cellOn, e * 0.86f)
        fullBrainOut = maxOf(brainCells, nucleus, meninges, crownHeadUp, glandsBrainOnly)

        bioFullOut = maxOf(
            bellySkinFront, bellySkinL, bellySkinR, bellyCells, faceCells, neckCells,
            eyeCellsL, eyeCellsR, brainCells, nonCellMatrix, crownHeadUp, fullBrainOut,
            epidermisOut, dermisOut, nucleus, dnaOut, plasma, thyroid, cutaneousMembrane,
            glandsFullOut, glandsBrainOut, glandsBodyOut
        )

        status =
            "EPI/DERM/HYPO=${(epidermisOut*100).toInt()}/${(dermisOut*100).toInt()}/${(hypodermisOut*100).toInt()}% · " +
            "NUC=${(nucleus*100).toInt()}% DNA/RNA=${(dnaOut*100).toInt()}/${(rnaOut*100).toInt()}% · " +
            "GLAND CNS=${(glandsBrainOnly*100).toInt()}% NECK=${(glandsNeck*100).toInt()}% ABD=${(glandsAbdomen*100).toInt()}% HEAD-SURF=${(glandsHeadSurface*100).toInt()}% · " +
            "pineal/pit/thy L=${(pineal*100).toInt()}/${(pituitary*100).toInt()}/${(thyroidL*100).toInt()} · " +
            "BLOOD RBC/WBC=${(rbc*100).toInt()}/${(wbc*100).toInt()}% · FULL=${(bioFullOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        // Skin layers → existing skin atomspare + all body skin
        try {
            v.skinAtomspare.epidermisOut = maxOf(v.skinAtomspare.epidermisOut, epidermisOut)
            v.skinAtomspare.skinOutsideOut = maxOf(v.skinAtomspare.skinOutsideOut, epidermisOut, stratumCorneum)
            v.skinAtomspare.skinInsideOut = maxOf(v.skinAtomspare.skinInsideOut, dermisOut, hypodermisOut)
            v.allBodySkinAnatomy.allSkinOut = maxOf(v.allBodySkinAnatomy.allSkinOut, cutaneousMembrane, bioFullOut * 0.8f)
            v.allBodySkinAnatomy.completeSkinCoverage = maxOf(v.allBodySkinAnatomy.completeSkinCoverage, bioFullOut)
        } catch (_: Throwable) {}
        // 3D anatomy layers
        try {
            val a = v.anatomy3d
            a.layerOn[0] = true
            a.layerLevel[0] = maxOf(a.layerLevel[0], epidermisOut, dermisOut)
            if (a.layerOn.size > 3) {
                a.layerOn[3] = true // organs — glands/blood symbolic
                a.layerLevel[3] = maxOf(a.layerLevel[3], thyroid, pancreas, plasma * 0.7f)
            }
            if (a.layerOn.size > 4) {
                a.layerOn[4] = true // vessels
                a.layerLevel[4] = maxOf(a.layerLevel[4], rbc, plasma)
            }
            if (a.layerOn.size > 5) {
                a.layerOn[5] = true // brain — nucleus/DNA symbolic intensity
                a.layerLevel[5] = maxOf(a.layerLevel[5], nucleus * 0.6f, dnaOut * 0.5f, meninges, glandsBrainOnly)
                a.layerLevel[3] = maxOf(a.layerLevel[3], glandsBodyOut, glandsAbdomen, glandsNeck * 0.8f)
                // face/head surface glands slightly into face layer
                if (a.layerOn.size > 6) {
                    a.layerOn[6] = true
                    a.layerLevel[6] = maxOf(a.layerLevel[6], glandsHeadSurface * 0.6f)
                }
            }
            a.atmosphere = maxOf(a.atmosphere, bioFullOut * 0.7f)
        } catch (_: Throwable) {}
        try {
            v.bodyFreqRegen.thyroidOut = maxOf(v.bodyFreqRegen.thyroidOut, thyroid)
            v.bodyFreqRegen.bodySkinSysOut = maxOf(v.bodyFreqRegen.bodySkinSysOut, epidermisOut, dermisOut)
            v.bodyFreqRegen.brainFullOut = maxOf(v.bodyFreqRegen.brainFullOut, nucleus * 0.5f, meninges)
        } catch (_: Throwable) {}
        try {
            v.completeAtomProtect.atomOutsideOut = maxOf(v.completeAtomProtect.atomOutsideOut, epidermisOut)
            v.completeAtomProtect.atomInsideOut = maxOf(v.completeAtomProtect.atomInsideOut, nucleus, dnaOut, plasma)
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, bioFullOut * 0.6f)
        } catch (_: Throwable) {}
        try {
            v.skinAll.atmosphere = maxOf(v.skinAll.atmosphere, epidermisOut, dermisOut)
            try {
                v.skinAbdomen.atmosphere = maxOf(v.skinAbdomen.atmosphere, bellySkinFront, bellySkinL, bellySkinR, bellyCells * 0.5f)
                v.belly.atmosphere = maxOf(v.belly.atmosphere, bellySkinFront, bellyCells)
                v.face.atmosphere = maxOf(v.face.atmosphere, faceCells * 0.6f)
                v.neck.atmosphere = maxOf(v.neck.atmosphere, neckCells * 0.6f)
                v.eyeL.atmosphere = maxOf(v.eyeL.atmosphere, eyeCellsL * 0.5f)
                v.eyeR.atmosphere = maxOf(v.eyeR.atmosphere, eyeCellsR * 0.5f)
                v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, crownHeadUp * 0.5f, headUpSideL * 0.4f, headUpSideR * 0.4f)
            } catch (_: Throwable) {}
            try {
                v.bodyChemBrain.brainFullOut = maxOf(v.bodyChemBrain.brainFullOut, fullBrainOut)
                v.bodyChemBrain.cerebrum = maxOf(v.bodyChemBrain.cerebrum, brainCells)
            } catch (_: Throwable) {}
            try {
                if (v.anatomy3d.layerOn.size > 5) {
                    v.anatomy3d.layerLevel[5] = maxOf(v.anatomy3d.layerLevel[5], fullBrainOut, brainCells, crownHeadUp)
                }
            } catch (_: Throwable) {}
            v.heart.atmosphere = maxOf(v.heart.atmosphere, rbc * 0.5f, plasma * 0.4f)
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, pituitary * 0.4f, pineal * 0.3f, glandsBrainOut * 0.35f)
            try {
                v.bodyChemBrain.pineal = maxOf(v.bodyChemBrain.pineal, pineal)
                v.bodyChemBrain.hypothalamus = maxOf(v.bodyChemBrain.hypothalamus, pituitary * 0.5f, hypothalamusGland)
                v.bodyChemBrain.brainFullOut = maxOf(v.bodyChemBrain.brainFullOut, glandsBrainOnly)
                v.bodyChemBrain.brainFullOut = maxOf(v.bodyChemBrain.brainFullOut, glandsBrainOut)
            } catch (_: Throwable) {}
            try {
                v.bodyFreqRegen.thyroidOut = maxOf(v.bodyFreqRegen.thyroidOut, thyroid, thyroidL, thyroidR)
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}
    }
}
