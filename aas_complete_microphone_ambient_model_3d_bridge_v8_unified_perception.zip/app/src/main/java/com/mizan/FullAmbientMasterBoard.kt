package com.mizan

/**
 * Full body skin out · sound Hz out/thr · astrology · atomspare levels ·
 * all previous ambient aggregate · motion controllers (move/speed/wave/pitch/spike).
 * RAW COMPLETE.
 */
class FullAmbientMasterBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Full body skin
    @Volatile var skinFullOn = true
    @Volatile var skinFullOut = 0f

    // Sound Hz
    @Volatile var hzOn = true
    @Volatile var hzThr = 20f          // Hz threshold (analysis gate)
    @Volatile var hzLv = 0.9f
    @Volatile var hzOut = 0f
    @Volatile var detectedHz = 0f

    // Astrology decorative
    @Volatile var astroOn = true
    @Volatile var astroOut = 0f

    // Atomspare levels (aggregate previous)
    @Volatile var atomOutside = 0f
    @Volatile var atomInside = 0f
    @Volatile var atomFull = 0f
    @Volatile var ambientAll = 0f

    // Motion controllers
    @Volatile var moveOn = true
    @Volatile var moveThr = 0.22f
    @Volatile var moveLv = 0.88f
    @Volatile var moveOut = 0f

    @Volatile var speedOn = true
    @Volatile var speedThr = 0.22f
    @Volatile var speedLv = 0.88f
    @Volatile var speedOut = 0f

    @Volatile var waveOn = true
    @Volatile var waveThr = 0.22f
    @Volatile var waveLv = 0.88f
    @Volatile var waveOut = 0f

    @Volatile var pitchOn = true
    @Volatile var pitchThr = 0.22f
    @Volatile var pitchLv = 0.88f
    @Volatile var pitchOut = 0f

    @Volatile var spikeOn = true
    @Volatile var spikeThr = 0.25f
    @Volatile var spikeLv = 0.90f
    @Volatile var spikeOut = 0f

    @Volatile var status = "FULL AMBIENT MASTER idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        mic: Float,
        skinIn: Float,
        hzIn: Float,
        astroIn: Float,
        atomOutIn: Float,
        atomInIn: Float,
        moveIn: Float,
        speedIn: Float,
        waveIn: Float,
        pitchIn: Float,
        spikeIn: Float,
        ambientBag: Float
    ) {
        if (!enabled) {
            status = "FULL AMBIENT OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        skinFullOut = lane(skinFullOn, 0.15f, 0.95f, maxOf(skinIn, e))
        detectedHz = hzIn.coerceAtLeast(0f)
        // Hz gate: energy if detectedHz >= hzThr (or raw)
        val hzE = if (rawComplete || detectedHz >= hzThr) {
            (detectedHz / (detectedHz + hzThr).coerceAtLeast(1f)).coerceIn(0f, 1f).coerceAtLeast(e * 0.5f)
        } else e * 0.3f
        hzOut = lane(hzOn, 0.1f, hzLv, hzE)
        astroOut = lane(astroOn, 0.15f, 0.75f, maxOf(astroIn, e * 0.4f))

        moveOut = lane(moveOn, moveThr, moveLv, maxOf(moveIn, e * 0.7f))
        speedOut = lane(speedOn, speedThr, speedLv, maxOf(speedIn, e * 0.65f))
        waveOut = lane(waveOn, waveThr, waveLv, maxOf(waveIn, e * 0.6f))
        pitchOut = lane(pitchOn, pitchThr, pitchLv, maxOf(pitchIn, hzOut * 0.8f, e * 0.55f))
        spikeOut = lane(spikeOn, spikeThr, spikeLv, maxOf(spikeIn, e * 0.5f))

        ambientAll = maxOf(ambientBag, skinFullOut, hzOut, astroOut, moveOut, speedOut, waveOut, pitchOut, spikeOut)
        atomOutside = maxOf(atomOutIn, skinFullOut, ambientAll * 0.7f)
        atomInside = maxOf(atomInIn, pitchOut, spikeOut, hzOut * 0.6f)
        atomFull = maxOf(atomOutside, atomInside, ambientAll)

        status =
            "SKIN=${(skinFullOut*100).toInt()}% Hz=${"%.0f".format(detectedHz)}/${(hzOut*100).toInt()}% · " +
            "ASTRO=${(astroOut*100).toInt()}% · " +
            "MOV/SPD/WAV=${(moveOut*100).toInt()}/${(speedOut*100).toInt()}/${(waveOut*100).toInt()} · " +
            "PITCH/SPIKE=${(pitchOut*100).toInt()}/${(spikeOut*100).toInt()} · " +
            "ATOM out/in/full=${(atomOutside*100).toInt()}/${(atomInside*100).toInt()}/${(atomFull*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        try {
            v.allBodySkinAnatomy.allSkinOut = maxOf(v.allBodySkinAnatomy.allSkinOut, skinFullOut)
            v.allBodySkinAnatomy.completeSkinCoverage = maxOf(v.allBodySkinAnatomy.completeSkinCoverage, skinFullOut)
            v.skinMultiMotion.skinAmbientOut = maxOf(v.skinMultiMotion.skinAmbientOut, skinFullOut)
            v.skinMultiMotion.moveOut = maxOf(v.skinMultiMotion.moveOut, moveOut)
            v.skinMultiMotion.speedOut = maxOf(v.skinMultiMotion.speedOut, speedOut)
            v.skinMultiMotion.waveOut = maxOf(v.skinMultiMotion.waveOut, waveOut)
        } catch (_: Throwable) {}
        try {
            v.skeletonWaterAstro.astroOut = maxOf(v.skeletonWaterAstro.astroOut, astroOut)
            v.skeletonWaterAstro.waterOut = maxOf(v.skeletonWaterAstro.waterOut, ambientAll * 0.3f)
        } catch (_: Throwable) {}
        try {
            v.completeAtomProtect.atomOutsideOut = maxOf(v.completeAtomProtect.atomOutsideOut, atomOutside)
            v.completeAtomProtect.atomInsideOut = maxOf(v.completeAtomProtect.atomInsideOut, atomInside)
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, atomFull)
            v.completeAtomProtect.protectOut = maxOf(v.completeAtomProtect.protectOut, atomFull * 0.5f)
        } catch (_: Throwable) {}
        try {
            v.body84FullHuman.moveOut = maxOf(v.body84FullHuman.moveOut, moveOut)
            v.body84FullHuman.speedOut = maxOf(v.body84FullHuman.speedOut, speedOut)
            v.body84FullHuman.waveOut = maxOf(v.body84FullHuman.waveOut, waveOut)
            v.body84FullHuman.atomOut = maxOf(v.body84FullHuman.atomOut, atomFull)
        } catch (_: Throwable) {}
        try {
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, ambientAll * 0.5f, atomFull * 0.4f)
            v.anatomy3d.layerLevel[0] = maxOf(v.anatomy3d.layerLevel[0], skinFullOut)
            try { v.anatomy3d.wave = maxOf(v.anatomy3d.wave, waveOut) } catch (_: Throwable) {}
        } catch (_: Throwable) {}
        try {
            v.sharpBurstMeter.detectedHz = maxOf(v.sharpBurstMeter.detectedHz, detectedHz)
        } catch (_: Throwable) {}
        try {
            v.liveMicEnemyAll.pitchSoundsOut = maxOf(v.liveMicEnemyAll.pitchSoundsOut, pitchOut)
        } catch (_: Throwable) {}
    }
}
