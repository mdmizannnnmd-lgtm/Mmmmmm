package com.mizan

/**
 * Enemy track via BLE digital scale / proximity symbolic + mic + model.
 * Weight delta / presence thr · pairs with MgBleScaleWatt. RAW COMPLETE.
 */
class EnemyBleScaleTrackBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.25f
    @Volatile var levelAmt = 0.90f
    @Volatile var blePresence = 0f
    @Volatile var weightDelta = 0f
    @Volatile var enemyScaleOut = 0f
    @Volatile var modelConfirm = 0f
    @Volatile var audioConfirm = 0f
    @Volatile var status = "ENEMY-BLE-SCALE idle"

    fun tick(mic: Float, bleWatt: Float, model: Float) {
        if (!enabled) { status = "ENEMY-BLE OFF"; return }
        audioConfirm = (mic * levelAmt).coerceIn(0f, 1f)
        blePresence = (bleWatt * levelAmt).coerceIn(0f, 1f)
        modelConfirm = (model * levelAmt).coerceIn(0f, 1f)
        weightDelta = maxOf(blePresence * 0.8f, modelConfirm * 0.6f)
        enemyScaleOut = if (maxOf(blePresence, audioConfirm, modelConfirm) >= thr)
            maxOf(blePresence, audioConfirm * 0.7f, modelConfirm) else 0f
        if (rawComplete) enemyScaleOut = maxOf(enemyScaleOut, 0.2f + mic * 0.3f)
        status = "ENEMY-BLE out=${(enemyScaleOut*100).toInt()}% ble=${(blePresence*100).toInt()}% mic=${(audioConfirm*100).toInt()}% model=${(modelConfirm*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView?) {
        if (!enabled || enemyScaleOut < 0.02f) return
        val vv = v ?: return
        try {
            vv.enemy3dProtect.enemyModelOut = maxOf(vv.enemy3dProtect.enemyModelOut, enemyScaleOut * 0.6f)
        } catch (_: Throwable) {}
    }
}
