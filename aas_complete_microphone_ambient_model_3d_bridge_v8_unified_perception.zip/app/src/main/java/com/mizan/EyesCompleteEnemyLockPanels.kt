package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object EyesCompleteEnemyLockPanels {
    fun build(ctx: Context, root: LinearLayout, b: EyesCompleteEnemyLockBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF81D4FA.toInt()
        p.title("EYES COMPLETE · IRIS/PUPIL/SCLERA/ORBIT · ENEMY EYE-MOVE LOCK", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Eyes detail ON", b.eyesOn) { b.eyesOn = it }
        p.seek("Eyes thr", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Eyes level", 0f, 1.5f, b.lv) { b.lv = it }
        p.switch("Enemy eye-move LOCK ON", b.enemyEyeLockOn) { b.enemyEyeLockOn = it }
        p.seek("Lock thr", 0.05f, 0.98f, b.enemyEyeLockThr) { b.enemyEyeLockThr = it }
        p.seek("Lock level", 0f, 1.5f, b.enemyEyeLockLv) { b.enemyEyeLockLv = it }
        val st = p.status("EYES LOCK —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 200) }
        })
    }
}
