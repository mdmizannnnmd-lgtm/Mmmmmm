package com.mizan

/**
 * Legacy placeholder retained for source compatibility.
 *
 * Camera inference is implemented by [HumanCameraDetector] using ML Kit pose
 * and person segmentation. This class deliberately does not report itself as
 * ready: no ONNX model or ONNX Runtime is shipped in this source archive.
 */
class OnnxCameraMixer {
    @Volatile var enabled = false
    @Volatile var ready = false
    @Volatile var lastError: String? = "No ONNX model/runtime; use the ML Kit camera detector"

    fun start() { ready = false }
    fun stop() { ready = false }
    fun tick(energy: Float) { /* intentionally unused legacy API */ }
    fun mixScale(): Float = 1f
    fun statusLine(): String =
        if (!enabled) "ONNX off · ML Kit pose+mask is the live camera path"
        else "ONNX unavailable · no ONNX file/runtime; ML Kit pose+mask is the live camera path"
}
