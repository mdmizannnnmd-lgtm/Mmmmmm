package com.mizan

/**
 * Full body model mixer — blends all body-related boards into
 * inside + outside 3D body surfaces.
 *
 * Sources mixed:
 *  · Body84 channels
 *  · Pose surface (body + enemy)
 *  · camera pose + person-mask regions
 *  · Body armor
 *  · Region FX / region bank energy
 *
 * Each source has weight · thr · enable. Inside / outside paths
 * get independent mix + atmosphere / wavespare / motion rails.
 */
class BodyModelMixer {
    @Volatile var arMixerProtectOn = true
    @Volatile var arMixerProtectLv = 0.88f


    @Volatile var enabled = true

    // ── Source enables + weights (0..1) ─────────────────────────────
    @Volatile var srcBody84On = true
    @Volatile var srcBody84W = 0.55f
    @Volatile var srcPoseOn = true
    @Volatile var srcPoseW = 0.60f
    @Volatile var srcYoloOn = true
    @Volatile var srcYoloW = 0.70f
    @Volatile var srcArmorOn = true
    @Volatile var srcArmorW = 0.40f
    @Volatile var srcRegionOn = true
    @Volatile var srcRegionW = 0.45f

    // ── Inside surface ──────────────────────────────────────────────
    @Volatile var insideOn = true
    @Volatile var insideThr = 0.35f
    @Volatile var insideLv = 0.65f
    @Volatile var insideMoveOn = true
    @Volatile var insideMoveThr = 0.35f
    @Volatile var insideMoveLv = 0.50f
    @Volatile var insideWaveOn = true
    @Volatile var insideWaveThr = 0.35f
    @Volatile var insideWaveLv = 0.50f
    @Volatile var insideSpeedOn = true
    @Volatile var insideSpeedThr = 0.35f
    @Volatile var insideSpeedLv = 0.50f
    @Volatile var insideAtmoOn = true
    @Volatile var insideAtmoThr = 0.38f
    @Volatile var insideAtmoLv = 0.55f
    @Volatile var insideWspOn = true
    @Volatile var insideWspThr = 0.40f
    @Volatile var insideWspLv = 0.48f
    @Volatile var insideBipOn = true
    @Volatile var insideBipNeg = -40f
    @Volatile var insideBipPos = 40f

    @Volatile var insideActive = false
    @Volatile var insideOut = 0f
    @Volatile var insideMoveActive = false
    @Volatile var insideMoveOut = 0f
    @Volatile var insideWaveActive = false
    @Volatile var insideWaveOut = 0f
    @Volatile var insideSpeedActive = false
    @Volatile var insideSpeedOut = 0f
    @Volatile var insideAtmoActive = false
    @Volatile var insideAtmoOut = 0f
    @Volatile var insideWspActive = false
    @Volatile var insideWspOut = 0f
    @Volatile var insideBipHit = false

    // ── Outside surface ─────────────────────────────────────────────
    @Volatile var outsideOn = true
    @Volatile var outsideThr = 0.40f
    @Volatile var outsideLv = 0.60f
    @Volatile var outsideMoveOn = true
    @Volatile var outsideMoveThr = 0.38f
    @Volatile var outsideMoveLv = 0.48f
    @Volatile var outsideWaveOn = true
    @Volatile var outsideWaveThr = 0.38f
    @Volatile var outsideWaveLv = 0.48f
    @Volatile var outsideSpeedOn = true
    @Volatile var outsideSpeedThr = 0.38f
    @Volatile var outsideSpeedLv = 0.48f
    @Volatile var outsideAtmoOn = true
    @Volatile var outsideAtmoThr = 0.42f
    @Volatile var outsideAtmoLv = 0.52f
    @Volatile var outsideWspOn = true
    @Volatile var outsideWspThr = 0.42f
    @Volatile var outsideWspLv = 0.48f
    @Volatile var outsideBipOn = true
    @Volatile var outsideBipNeg = -40f
    @Volatile var outsideBipPos = 40f

    @Volatile var outsideActive = false
    @Volatile var outsideOut = 0f
    @Volatile var outsideMoveActive = false
    @Volatile var outsideMoveOut = 0f
    @Volatile var outsideWaveActive = false
    @Volatile var outsideWaveOut = 0f
    @Volatile var outsideSpeedActive = false
    @Volatile var outsideSpeedOut = 0f
    @Volatile var outsideAtmoActive = false
    @Volatile var outsideAtmoOut = 0f
    @Volatile var outsideWspActive = false
    @Volatile var outsideWspOut = 0f
    @Volatile var outsideBipHit = false

    /** Multi-segment inside surface (not single) — one shell per body part */
    class SegSurf(
        val label: String,
        var on: Boolean = true,
        var thr: Float = 0.35f,
        var lv: Float = 0.55f,
        var atmoOn: Boolean = true,
        var atmoThr: Float = 0.38f,
        var atmoLv: Float = 0.50f,
        var moveOn: Boolean = true,
        var moveThr: Float = 0.35f,
        var moveLv: Float = 0.48f,
        var waveOn: Boolean = true,
        var waveThr: Float = 0.35f,
        var waveLv: Float = 0.48f,
        var active: Boolean = false,
        var out: Float = 0f,
        var atmoActive: Boolean = false,
        var atmoOut: Float = 0f,
        var moveActive: Boolean = false,
        var moveOut: Float = 0f,
        var waveActive: Boolean = false,
        var waveOut: Float = 0f
    )

    val segInside = arrayOf(
        SegSurf("head"), SegSurf("torso"),
        SegSurf("armL"), SegSurf("armR"),
        SegSurf("legL"), SegSurf("legR"),
        SegSurf("handL"), SegSurf("handR"),
        SegSurf("footL"), SegSurf("footR")
    )

    @Volatile var segInsideOn = true
    @Volatile var segInsideMulti = true
    @Volatile var segInsideCount = 10
    @Volatile var segInsideActiveN = 0
    @Volatile var bulkSegThr = 0.35f
    @Volatile var bulkSegLv = 0.55f
    @Volatile var bulkSegAtmoThr = 0.38f
    @Volatile var bulkSegAtmoLv = 0.50f
    @Volatile var bulkSegMoveThr = 0.35f
    @Volatile var bulkSegMoveLv = 0.48f
    @Volatile var bulkSegWaveThr = 0.35f
    @Volatile var bulkSegWaveLv = 0.48f

    fun applyBulkSeg() {
        segInside.forEach { s ->
            s.thr = bulkSegThr; s.lv = bulkSegLv
            s.atmoThr = bulkSegAtmoThr; s.atmoLv = bulkSegAtmoLv
            s.moveThr = bulkSegMoveThr; s.moveLv = bulkSegMoveLv
            s.waveThr = bulkSegWaveThr; s.waveLv = bulkSegWaveLv
        }
    }


    /** Mixed energy after weighted sources */
    @Volatile var mixedE = 0f

    private fun gate(on: Boolean, e: Float, thr: Float, lv: Float): Pair<Boolean, Float> {
        val t = thr.coerceIn(0.05f, 1f)
        val a = on && e >= t
        val o = if (a) {
            (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
        return a to o
    }

    /**
     * @param energy base ambient energy
     * @param body84 avg from Body84Channels
     * @param pose damp/out from PoseSurfaceBoard
     * @param yolo damp/out from YoloSegHuman3D
     * @param armor hardware/spike factor from BodyArmorShield (0..1 contribution)
     * @param region scale from region FX (0..1)
     */
    fun tick(
        energy: Float,
        db: Double = -80.0,
        body84: Float = 0f,
        pose: Float = 0f,
        yolo: Float = 0f,
        armor: Float = 0f,
        region: Float = 0f,
        yoloSegOuts: FloatArray? = null
    ) {
        if (!enabled) {
            mixedE = 0f
            insideActive = false; insideOut = 0f
            outsideActive = false; outsideOut = 0f
            insideMoveActive = false; insideWaveActive = false; insideSpeedActive = false
            insideAtmoActive = false; insideWspActive = false; insideBipHit = false
            outsideMoveActive = false; outsideWaveActive = false; outsideSpeedActive = false
            outsideAtmoActive = false; outsideWspActive = false; outsideBipHit = false
            segInsideActiveN = 0
            segInside.forEach {
                it.active = false; it.out = 0f
                it.atmoActive = false; it.atmoOut = 0f
                it.moveActive = false; it.moveOut = 0f
                it.waveActive = false; it.waveOut = 0f
            }
            return
        }

        var sum = 0f
        var wSum = 0f
        fun add(on: Boolean, w: Float, v: Float) {
            if (!on) return
            val ww = w.coerceIn(0f, 1f)
            sum += v.coerceIn(0f, 1f) * ww
            wSum += ww
        }
        add(srcBody84On, srcBody84W, body84)
        add(srcPoseOn, srcPoseW, pose)
        add(srcYoloOn, srcYoloW, yolo)
        add(srcArmorOn, srcArmorW, armor)
        add(srcRegionOn, srcRegionW, region)
        // Always include raw energy as a floor mix
        sum += energy.coerceIn(0f, 1f) * 0.35f
        wSum += 0.35f
        mixedE = if (wSum > 0.01f) (sum / wSum).coerceIn(0f, 1f) else energy.coerceIn(0f, 1f)

        val e = mixedE

        // Inside bipolar
        val iLo = insideBipNeg.coerceIn(-120f, 0f).toDouble()
        val iHi = insideBipPos.coerceIn(0f, 120f).toDouble()
        insideBipHit = insideBipOn && (db <= iLo || db >= iHi)
        var (ia, io) = gate(insideOn, e, insideThr, insideLv)
        if (insideBipHit) { ia = true; io = maxOf(io, 0.22f) }
        insideActive = ia; insideOut = io
        gate(insideMoveOn, e, insideMoveThr, insideMoveLv).let {
            insideMoveActive = it.first; insideMoveOut = it.second
        }
        gate(insideWaveOn, e, insideWaveThr, insideWaveLv).let {
            insideWaveActive = it.first; insideWaveOut = it.second
        }
        gate(insideSpeedOn, e, insideSpeedThr, insideSpeedLv).let {
            insideSpeedActive = it.first; insideSpeedOut = it.second
        }
        gate(insideAtmoOn, e, insideAtmoThr, insideAtmoLv).let {
            insideAtmoActive = it.first; insideAtmoOut = it.second
        }
        gate(insideWspOn, e, insideWspThr, insideWspLv).let {
            insideWspActive = it.first; insideWspOut = it.second
        }

        // Outside bipolar
        val oLo = outsideBipNeg.coerceIn(-120f, 0f).toDouble()
        val oHi = outsideBipPos.coerceIn(0f, 120f).toDouble()
        outsideBipHit = outsideBipOn && (db <= oLo || db >= oHi)
        var (oa, oo) = gate(outsideOn, e, outsideThr, outsideLv)
        if (outsideBipHit) { oa = true; oo = maxOf(oo, 0.20f) }
        outsideActive = oa; outsideOut = oo
        gate(outsideMoveOn, e, outsideMoveThr, outsideMoveLv).let {
            outsideMoveActive = it.first; outsideMoveOut = it.second
        }
        gate(outsideWaveOn, e, outsideWaveThr, outsideWaveLv).let {
            outsideWaveActive = it.first; outsideWaveOut = it.second
        }
        gate(outsideSpeedOn, e, outsideSpeedThr, outsideSpeedLv).let {
            outsideSpeedActive = it.first; outsideSpeedOut = it.second
        }
        gate(outsideAtmoOn, e, outsideAtmoThr, outsideAtmoLv).let {
            outsideAtmoActive = it.first; outsideAtmoOut = it.second
        }
        gate(outsideWspOn, e, outsideWspThr, outsideWspLv).let {
            outsideWspActive = it.first; outsideWspOut = it.second
        }

        // Multi-segment INSIDE surface (not single blob)
        val nSeg = if (segInsideMulti) segInsideCount.coerceIn(1, segInside.size) else 1
        segInsideActiveN = 0
        for (i in segInside.indices) {
            val s = segInside[i]
            if (i >= nSeg || !segInsideOn || !s.on) {
                s.active = false; s.out = 0f
                s.atmoActive = false; s.atmoOut = 0f
                s.moveActive = false; s.moveOut = 0f
                s.waveActive = false; s.waveOut = 0f
                continue
            }
            val bias = (i * 0.032f) % 0.20f
            val yv = yoloSegOuts?.getOrNull(i)?.coerceIn(0f, 1f) ?: 0f
            val localE = (e * 0.55f + yv * 0.45f + insideOut * 0.25f).coerceIn(0f, 1f)
            val (sa, so) = gate(true, localE, s.thr + bias, s.lv)
            s.active = sa; s.out = so
            gate(s.atmoOn, localE, s.atmoThr + bias * 0.4f, s.atmoLv).let {
                s.atmoActive = it.first; s.atmoOut = it.second
            }
            gate(s.moveOn, localE, s.moveThr + bias * 0.5f, s.moveLv).let {
                s.moveActive = it.first; s.moveOut = it.second
            }
            gate(s.waveOn, localE, s.waveThr + bias * 0.5f, s.waveLv).let {
                s.waveActive = it.first; s.waveOut = it.second
            }
            if (s.active) segInsideActiveN++
        }
    }

    fun dampen(): Float {
        if (!enabled) return 0f
        var d = 0f
        if (insideActive) d = maxOf(d, 0.28f + insideOut * 0.38f)
        if (insideMoveActive) d = maxOf(d, 0.18f + insideMoveOut * 0.24f)
        if (insideWaveActive) d = maxOf(d, 0.16f + insideWaveOut * 0.22f)
        if (insideSpeedActive) d = maxOf(d, 0.16f + insideSpeedOut * 0.22f)
        if (insideAtmoActive) d = maxOf(d, 0.22f + insideAtmoOut * 0.28f)
        if (insideWspActive) d = maxOf(d, 0.14f + insideWspOut * 0.20f)
        if (outsideActive) d = maxOf(d, 0.30f + outsideOut * 0.36f)
        if (outsideMoveActive) d = maxOf(d, 0.18f + outsideMoveOut * 0.24f)
        if (outsideWaveActive) d = maxOf(d, 0.16f + outsideWaveOut * 0.22f)
        if (outsideSpeedActive) d = maxOf(d, 0.16f + outsideSpeedOut * 0.22f)
        if (outsideAtmoActive) d = maxOf(d, 0.24f + outsideAtmoOut * 0.28f)
        if (outsideWspActive) d = maxOf(d, 0.14f + outsideWspOut * 0.20f)
        val nS = segInsideCount.coerceIn(1, segInside.size)
        for (i in 0 until nS) {
            val s = segInside[i]
            if (s.active) d = maxOf(d, 0.18f + s.out * 0.32f)
            if (s.atmoActive) d = maxOf(d, 0.14f + s.atmoOut * 0.22f)
            if (s.moveActive) d = maxOf(d, 0.12f + s.moveOut * 0.18f)
            if (s.waveActive) d = maxOf(d, 0.12f + s.waveOut * 0.18f)
        }
        if (arMixerProtectOn) d = (d + arMixerProtectLv.coerceIn(0f, 1f) * 0.55f).coerceIn(0f, 1f)
        return d.coerceIn(0f, 1f)
    }

    fun statusLine(): String {
        if (!enabled) return "BODY-MIX off"
        val src = buildList {
            if (srcBody84On) add("B84")
            if (srcPoseOn) add("POSE")
            if (srcYoloOn) add("CAMERA BODY")
            if (srcArmorOn) add("ARMOR")
            if (srcRegionOn) add("REG")
        }.joinToString("+").ifEmpty { "—" }
        val tags = buildList {
            if (insideActive) add("IN")
            if (insideAtmoActive) add("IN-ATMO")
            if (outsideActive) add("OUT")
            if (outsideAtmoActive) add("OUT-ATMO")
            if (insideBipHit || outsideBipHit) add("BIP")
            if (segInsideOn && segInsideActiveN > 0) add("SEG-IN=$segInsideActiveN")
            if (isEmpty()) add("idle")
        }.joinToString("+")
        return "BODY-MIX · src=$src · $tags · mix=${(mixedE*100).toInt()}% " +
            "in=${(insideOut*100).toInt()}% out=${(outsideOut*100).toInt()}% " +
            "segIn=$segInsideActiveN/$segInsideCount · damp=${(dampen()*100).toInt()}%"
    }
}
