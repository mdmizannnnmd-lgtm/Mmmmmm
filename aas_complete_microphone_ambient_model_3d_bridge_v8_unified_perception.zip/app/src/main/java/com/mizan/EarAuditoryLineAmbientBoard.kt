package com.mizan

/**
 * Ear line · full auditory ambient L/R:
 * pinna · canal · tympanic · ossicles · cochlea · vestibule · auditory nerve · cortex path.
 * Symbolic only — not medical diagnosis. RAW COMPLETE.
 */
class EarAuditoryLineAmbientBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var thr = 0.18f
    @Volatile var lv = 0.90f

    @Volatile var earLineOn = true

    // Outer
    @Volatile var pinnaL = 0f
    @Volatile var pinnaR = 0f
    @Volatile var canalL = 0f
    @Volatile var canalR = 0f

    // Middle
    @Volatile var tympanicL = 0f
    @Volatile var tympanicR = 0f
    @Volatile var malleusL = 0f
    @Volatile var malleusR = 0f
    @Volatile var incusL = 0f
    @Volatile var incusR = 0f
    @Volatile var stapesL = 0f
    @Volatile var stapesR = 0f

    // Inner
    @Volatile var cochleaL = 0f
    @Volatile var cochleaR = 0f
    @Volatile var vestibuleL = 0f
    @Volatile var vestibuleR = 0f
    @Volatile var semicircularL = 0f
    @Volatile var semicircularR = 0f

    // Neural line
    @Volatile var auditoryNerveL = 0f
    @Volatile var auditoryNerveR = 0f
    @Volatile var brainstemAud = 0f
    @Volatile var auditoryCortexL = 0f
    @Volatile var auditoryCortexR = 0f

    // Glands near ear
    @Volatile var ceruminousL = 0f
    @Volatile var ceruminousR = 0f

    @Volatile var earLineL = 0f
    @Volatile var earLineR = 0f
    @Volatile var earLineFull = 0f

    @Volatile var status = "EAR AUDITORY LINE idle"

    private fun lane(on: Boolean, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float, leftBias: Float = 0.5f) {
        if (!enabled) {
            status = "EAR LINE OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)
        val lb = leftBias.coerceIn(0.2f, 0.8f)
        val rb = 1f - lb
        val eL = e * (0.85f + 0.3f * lb)
        val eR = e * (0.85f + 0.3f * rb)

        pinnaL = lane(earLineOn, eL); pinnaR = lane(earLineOn, eR)
        canalL = lane(earLineOn, eL * 0.98f); canalR = lane(earLineOn, eR * 0.98f)
        tympanicL = lane(earLineOn, eL * 0.96f); tympanicR = lane(earLineOn, eR * 0.96f)
        malleusL = lane(earLineOn, eL * 0.94f); malleusR = lane(earLineOn, eR * 0.94f)
        incusL = lane(earLineOn, eL * 0.93f); incusR = lane(earLineOn, eR * 0.93f)
        stapesL = lane(earLineOn, eL * 0.92f); stapesR = lane(earLineOn, eR * 0.92f)
        cochleaL = lane(earLineOn, eL * 0.95f); cochleaR = lane(earLineOn, eR * 0.95f)
        vestibuleL = lane(earLineOn, eL * 0.90f); vestibuleR = lane(earLineOn, eR * 0.90f)
        semicircularL = lane(earLineOn, eL * 0.88f); semicircularR = lane(earLineOn, eR * 0.88f)
        auditoryNerveL = lane(earLineOn, eL * 0.94f); auditoryNerveR = lane(earLineOn, eR * 0.94f)
        brainstemAud = lane(earLineOn, e * 0.91f)
        auditoryCortexL = lane(earLineOn, eL * 0.90f); auditoryCortexR = lane(earLineOn, eR * 0.90f)
        ceruminousL = lane(earLineOn, eL * 0.85f); ceruminousR = lane(earLineOn, eR * 0.85f)

        earLineL = maxOf(pinnaL, canalL, tympanicL, cochleaL, auditoryNerveL, auditoryCortexL)
        earLineR = maxOf(pinnaR, canalR, tympanicR, cochleaR, auditoryNerveR, auditoryCortexR)
        earLineFull = maxOf(earLineL, earLineR, brainstemAud)

        status =
            "EAR L/R=${(earLineL*100).toInt()}/${(earLineR*100).toInt()}% · " +
            "PIN→CAN→TYM→OSS→COCH→N→CTX · " +
            "FULL=${(earLineFull*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        try {
            v.bioSkinCell.eardrumL = maxOf(v.bioSkinCell.eardrumL, tympanicL)
            v.bioSkinCell.eardrumR = maxOf(v.bioSkinCell.eardrumR, tympanicR)
            v.bioSkinCell.ossicleL = maxOf(v.bioSkinCell.ossicleL, maxOf(malleusL, incusL, stapesL))
            v.bioSkinCell.ossicleR = maxOf(v.bioSkinCell.ossicleR, maxOf(malleusR, incusR, stapesR))
            v.bioSkinCell.ceruminousL = maxOf(v.bioSkinCell.ceruminousL, ceruminousL)
            v.bioSkinCell.ceruminousR = maxOf(v.bioSkinCell.ceruminousR, ceruminousR)
            v.bioSkinCell.earSkinL = maxOf(v.bioSkinCell.earSkinL, pinnaL)
            v.bioSkinCell.earSkinR = maxOf(v.bioSkinCell.earSkinR, pinnaR)
        } catch (_: Throwable) {}
        try {
            // MoreMissed may have eardrum/ossicle
            v.moreMissed.eardrumL = maxOf(v.moreMissed.eardrumL, tympanicL)
            v.moreMissed.eardrumR = maxOf(v.moreMissed.eardrumR, tympanicR)
            v.moreMissed.ossicleL = maxOf(v.moreMissed.ossicleL, maxOf(malleusL, stapesL))
            v.moreMissed.ossicleR = maxOf(v.moreMissed.ossicleR, maxOf(malleusR, stapesR))
            v.moreMissed.auditoryNerve = maxOf(v.moreMissed.auditoryNerve, maxOf(auditoryNerveL, auditoryNerveR))
        } catch (_: Throwable) {}
        try {
            v.bodyChemBrain.temporalLobe = maxOf(v.bodyChemBrain.temporalLobe, maxOf(auditoryCortexL, auditoryCortexR))
            v.bodyChemBrain.brainstem = maxOf(v.bodyChemBrain.brainstem, brainstemAud)
            v.bodyChemBrain.brainFullOut = maxOf(v.bodyChemBrain.brainFullOut, earLineFull * 0.5f)
        } catch (_: Throwable) {}
        try {
            if (v.anatomy3d.layerOn.size > 5) {
                v.anatomy3d.layerOn[5] = true
                v.anatomy3d.layerLevel[5] = maxOf(v.anatomy3d.layerLevel[5], auditoryCortexL, auditoryCortexR, brainstemAud)
            }
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, earLineFull * 0.35f)
            v.skinHead.atmosphere = maxOf(v.skinHead.atmosphere, earLineFull * 0.3f)
        } catch (_: Throwable) {}
        try {
            v.allBodySkinAnatomy.earSkinL = maxOf(v.allBodySkinAnatomy.earSkinL, pinnaL)
            v.allBodySkinAnatomy.earSkinR = maxOf(v.allBodySkinAnatomy.earSkinR, pinnaR)
        } catch (_: Throwable) {}
        try {
            v.fullAmbientMaster.ambientAll = maxOf(v.fullAmbientMaster.ambientAll, earLineFull)
            v.completeAtomProtect.atomInsideOut = maxOf(v.completeAtomProtect.atomInsideOut, cochleaL, cochleaR)
        } catch (_: Throwable) {}
    }
}
