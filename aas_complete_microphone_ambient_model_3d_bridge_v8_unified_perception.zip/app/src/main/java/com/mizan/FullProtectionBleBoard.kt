package com.mizan

/**
 * Full protection stack: previous enemy effects + BLE library (Lifesum-style scale) +
 * enemy BLE/audio same-effect block. RAW COMPLETE.
 */
class FullProtectionBleBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true
    @Volatile var masterProtectOut = 0f
    @Volatile var enemyEffectsBlocked = 0f
    @Volatile var bleLibLive = 0f
    @Volatile var status = "FULL-PROT-BLE idle"

    fun tick(
        bleBlock: Float,
        bullet: Float,
        burst: Float,
        knife: Float,
        enemyBody: Float,
        enemyBle: Float,
        bleLib: Float
    ) {
        if (!enabled) { status = "FULL-PROT-BLE OFF"; return }
        bleLibLive = bleLib.coerceIn(0f, 1.5f)
        val threat = maxOf(bullet, burst, knife, enemyBody, enemyBle)
        enemyEffectsBlocked = (threat * 0.85f + bleBlock * 0.9f).coerceIn(0f, 1f)
        masterProtectOut = maxOf(bleBlock, enemyEffectsBlocked * 0.7f, bleLibLive * 0.4f)
        if (rawComplete) masterProtectOut = maxOf(masterProtectOut, 0.25f + threat * 0.3f)
        status =
            "FULL-PROT out=${(masterProtectOut*100).toInt()}% · enemyFX block=${(enemyEffectsBlocked*100).toInt()}% · " +
            "BLE-lib=${(bleLibLive*100).toInt()}%" + if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!enabled || masterProtectOut < 0.02f) return
        val d = (1f - masterProtectOut * 0.9f).coerceIn(0.05f, 1f)
        try {
            if (sb != null) {
                sb.enemyBodyOut *= d
                sb.micEnemyOut *= d
                sb.bulletOut *= (1f - enemyEffectsBlocked * 0.6f).coerceIn(0.08f, 1f)
                sb.burstOut *= (1f - enemyEffectsBlocked * 0.6f).coerceIn(0.08f, 1f)
                sb.knifeOut *= (1f - enemyEffectsBlocked * 0.55f).coerceIn(0.08f, 1f)
            }
        } catch (_: Throwable) {}
        val vv = v ?: return
        try {
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, masterProtectOut)
            vv.bleEnemyAmbientBlock.bleAmbientBlockOut = maxOf(vv.bleEnemyAmbientBlock.bleAmbientBlockOut, masterProtectOut * 0.5f)
        } catch (_: Throwable) {}
    }
}
