package com.mizan

/**
 * Lightweight neural visual cortex bridge using device motion + energy.
 * Uses MotionSensorHub raw accel/gyro; no external network.
 */
class NeuralVisualCortex {
    @Volatile var enabled = true
    @Volatile var thr = 0.35f
    @Volatile var level = 0.55f
    @Volatile var active = false
    @Volatile var out = 0f
    @Volatile var rawAccelX = 0f
    @Volatile var rawAccelY = 0f
    @Volatile var rawAccelZ = 0f
    @Volatile var rawGyroX = 0f
    @Volatile var rawGyroY = 0f
    @Volatile var rawGyroZ = 0f

    fun tick(energy: Float, motion: MotionSensorHub?) {
        val e = energy.coerceIn(0f, 1f)
        rawAccelX = motion?.rawAccelX ?: 0f
        rawAccelY = motion?.rawAccelY ?: 0f
        rawAccelZ = motion?.rawAccelZ ?: 0f
        rawGyroX = motion?.rawGyroX ?: 0f
        rawGyroY = motion?.rawGyroY ?: 0f
        rawGyroZ = motion?.rawGyroZ ?: 0f
        if (!enabled) {
            active = false; out = 0f
            return
        }
        val t = thr.coerceIn(0.05f, 1f)
        active = e >= t
        out = if (active) {
            (((e - t) / (1f - t).coerceAtLeast(0.05f)) * level.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        } else 0f
    }

    fun statusLine(): String {
        if (!enabled) return "CORTEX off"
        return "CORTEX ${if (active) "ON" else "idle"} out=${(out*100).toInt()}% " +
            "a=${"%.1f".format(rawAccelX)},${"%.1f".format(rawAccelY)},${"%.1f".format(rawAccelZ)}"
    }
}
