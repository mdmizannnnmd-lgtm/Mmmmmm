package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object WaterWarfareAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: WaterWarfareAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF4FC3F7.toInt()
        p.title("WATER WARFARE AMBIENT · PURE SELF · ENEMY TAGS", c)
        p.note("Symbolic thresholds only — mic/BLE/model track. No real chemical or biological agents.")
        p.switch("ON", b.enabled) { b.enabled = it }
        p.switch("RAW", b.rawComplete) { b.rawComplete = it }
        p.seek("Thr", 0.05f, 0.8f, b.thr) { b.thr = it }
        p.seek("Level", 0.2f, 1.5f, b.levelAmt) { b.levelAmt = it }
        val st = p.status("WATER-WAR —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() { st.text = b.status; Handler(Looper.getMainLooper()).postDelayed(this, 300) }
        })
    }
}
