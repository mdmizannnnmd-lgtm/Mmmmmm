package com.mizan

/**
 * Sound burst cancellation · sound knife cancellation ·
 * ALL atomspare enemy sounds cancellation. RAW COMPLETE.
 */
class EnemySoundCancelBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    @Volatile var burstCancelOn = true
    @Volatile var burstCancelThr = 0.22f
    @Volatile var burstCancelLv = 0.95f
    @Volatile var burstCancelOut = 0f

    @Volatile var knifeCancelOn = true
    @Volatile var knifeCancelThr = 0.22f
    @Volatile var knifeCancelLv = 0.95f
    @Volatile var knifeCancelOut = 0f

    @Volatile var atomEnemyCancelOn = true
    @Volatile var atomEnemyCancelThr = 0.20f
    @Volatile var atomEnemyCancelLv = 0.95f
    @Volatile var atomEnemyCancelOut = 0f

    // Sub-paths under atomspare enemy cancel
    @Volatile var cancelBullet = 0f
    @Volatile var cancelSharp = 0f
    @Volatile var cancelWhip = 0f
    @Volatile var cancelRipple = 0f
    @Volatile var cancelCollide = 0f
    @Volatile var cancelEnemyBody = 0f
    @Volatile var cancelMicEnemy = 0f

    @Volatile var status = "ENEMY SFX CANCEL idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.02f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(
        burst: Float,
        knife: Float,
        bullet: Float,
        sharp: Float,
        whip: Float,
        ripple: Float,
        collide: Float,
        enemyBody: Float,
        micEnemy: Float,
        atomThreat: Float
    ) {
        if (!enabled) {
            status = "ENEMY SFX CANCEL OFF"
            return
        }
        burstCancelOut = lane(burstCancelOn, burstCancelThr, burstCancelLv, burst)
        knifeCancelOut = lane(knifeCancelOn, knifeCancelThr, knifeCancelLv, knife)

        cancelBullet = bullet
        cancelSharp = sharp
        cancelWhip = whip
        cancelRipple = ripple
        cancelCollide = collide
        cancelEnemyBody = enemyBody
        cancelMicEnemy = micEnemy

        val allEnemy = maxOf(
            burst, knife, bullet, sharp, whip, ripple, collide,
            enemyBody, micEnemy, atomThreat
        )
        atomEnemyCancelOut = lane(atomEnemyCancelOn, atomEnemyCancelThr, atomEnemyCancelLv, allEnemy)

        status =
            "BURST-CANCEL=${(burstCancelOut*100).toInt()}% KNIFE-CANCEL=${(knifeCancelOut*100).toInt()}% · " +
            "ATOM-ENEMY-CANCEL=${(atomEnemyCancelOut*100).toInt()}% " +
            "(B=${(bullet*100).toInt()} Sh=${(sharp*100).toInt()} W=${(whip*100).toInt()} " +
            "R=${(ripple*100).toInt()} C=${(collide*100).toInt()} EB=${(enemyBody*100).toInt()})" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard, v: VisualShieldView?) {
        if (!enabled) return

        if (burstCancelOut > 0.02f) {
            val k = (1f - burstCancelOut).coerceIn(0.01f, 1f)
            sb.burstOut *= k
        }
        if (knifeCancelOut > 0.02f) {
            val k = (1f - knifeCancelOut).coerceIn(0.01f, 1f)
            sb.knifeOut *= k
        }
        if (atomEnemyCancelOut > 0.02f) {
            val k = (1f - atomEnemyCancelOut * 0.98f).coerceIn(0.01f, 1f)
            sb.bulletOut *= k
            sb.sharpOut *= k
            sb.whipOut *= k
            sb.rippleOut *= k
            sb.collideOut *= k
            sb.enemyBodyOut *= k
            sb.micEnemyOut *= k
            sb.burstOut *= k
            sb.knifeOut *= k
            val vv = v
            if (vv != null) {
                try {
                    vv.completeAtomProtect.protectOut =
                        maxOf(vv.completeAtomProtect.protectOut, atomEnemyCancelOut)
                    vv.completeAtomProtect.atomOut =
                        maxOf(vv.completeAtomProtect.atomOut, atomEnemyCancelOut * 0.5f)
                } catch (_: Throwable) {}
            }
        }
        val vv2 = v
        if (vv2 != null) {
            try {
                vv2.liveMicEnemyAll.enemyAllOut = maxOf(vv2.liveMicEnemyAll.enemyAllOut, atomEnemyCancelOut)
                vv2.sharpBurstMeter.antiBulletOut = maxOf(vv2.sharpBurstMeter.antiBulletOut, burstCancelOut, atomEnemyCancelOut * 0.8f)
                vv2.sharpBurstMeter.antiKnifeOut = maxOf(vv2.sharpBurstMeter.antiKnifeOut, knifeCancelOut, atomEnemyCancelOut * 0.8f)
            } catch (_: Throwable) {}
        }
    }
}
