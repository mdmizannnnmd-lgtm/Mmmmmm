package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object EarAuditoryLineAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: EarAuditoryLineAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF90CAF9.toInt()
        p.title("EAR AUDITORY LINE L/R · PINNA→CANAL→TYMPANIC→OSSICLES→COCHLEA→NERVE→CORTEX", c)
        p.note("Symbolic ambient. Full ear line + balance (vestibule/semicircular). Not medical.")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Ear auditory line ON", b.earLineOn) { b.earLineOn = it }
        p.seek("Thr", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Level", 0f, 1.5f, b.lv) { b.lv = it }
        val st = p.status("EAR LINE —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 220) }
        })
    }
}
