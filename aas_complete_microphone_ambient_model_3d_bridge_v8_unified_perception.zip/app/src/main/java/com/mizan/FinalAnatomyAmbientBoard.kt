package com.mizan

/**
 * Final-tabs body anatomy ambient (from prior WholeBodyAnatomyAmbientRole / Body84AmbientShield).
 * Additive only — does not replace Body84Channels / Anatomy3DBoard / BrainBoard.
 * Adjustable: L/R/Front/Back body · L/R brain · systems · 84-channel thr/lv · bipolar · mic×model.
 */
class FinalAnatomyAmbientBoard {

    companion object {
        val SYSTEM_NAMES = arrayOf(
            "Brain", "Heart", "Belly", "Neck", "Chest", "Spine", "Arm", "Hand",
            "Pelvis", "Leg", "Foot", "Eye", "Ear", "Skin", "Vascular", "Neural"
        )
        val PART84 = arrayOf(
            "Thumb", "Middle", "Ring", "Little", "Proximal", "Intermediate", "Distal",
            "1 Stretched", "2 Stretched", "3 Stretched",
            "Hips", "LeftUpperLeg", "RightUpperLeg", "LeftLowerLeg", "RightLowerLeg",
            "LeftFoot", "RightFoot", "Spine", "UpperChest", "Neck", "Head",
            "LeftShoulder", "RightShoulder", "LeftUpperArm", "RightUpperArm",
            "LeftLowerArm", "RightLowerArm", "LeftToes", "RightToes",
            "LeftEye", "RightEye", "Jaw",
            "Spine Front-Back", "Spine Left-Right", "Spine Twist Left-Right",
            "UpperChest Front-Back", "UpperChest Left-Right", "UpperChest Twist Left-Right",
            "Neck Nod Down-Up", "Neck Tilt Left-Right", "Neck Turn Left-Right",
            "Head Nod Down-Up", "Head Tilt Left-Right", "Head Turn Left-Right",
            "Left Eye Down-Up", "Left Eye In-Out", "Right Eye Down-Up", "Right Eye In-Out",
            "Jaw Close", "Jaw Left-Right",
            "Left Upper Leg Front-Back", "Left Upper Leg In-Out", "Left Upper Leg Twist In-Out",
            "Left Lower Leg Stretch", "Left Lower Leg Twist In-Out",
            "Left Foot Up-Down", "Left Foot Twist In-Out", "Left Toes Up-Down",
            "Right Upper Leg Front-Back", "Right Upper Leg In-Out", "Right Upper Leg Twist In-Out",
            "Right Lower Leg Stretch", "Right Lower Leg Twist In-Out",
            "Right Foot Up-Down", "Right Foot Twist In-Out", "Right Toes Up-Down",
            "Left Shoulder Down-Up", "Left Shoulder Front-Back",
            "Left Arm Down-Up", "Left Arm Front-Back", "Left Arm Twist In-Out",
            "Left Forearm Stretch", "Left Forearm Twist In-Out",
            "Left Hand Down-Up", "Left Hand In-Out",
            "Right Shoulder Down-Up", "Right Shoulder Front-Back",
            "Right Arm Down-Up", "Right Arm Front-Back", "Right Arm Twist In-Out",
            "Right Forearm Stretch", "Right Forearm Twist In-Out",
            "Right Hand Down-Up", "Right Hand In-Out"
        )
        const val N84 = 84
        const val NSYS = 16
    }

    @Volatile var enabled = true
    @Volatile var globalThr = 0.30f
    @Volatile var globalLv = 0.55f
    @Volatile var bipolarNegDb = 0f
    @Volatile var bipolarPosDb = 0f
    @Volatile var rawComplete = true

    // Body sides (final anatomy path)
    @Volatile var leftBodyOn = true
    @Volatile var leftBodyThr = 0.30f
    @Volatile var leftBodyLv = 0.55f
    @Volatile var rightBodyOn = true
    @Volatile var rightBodyThr = 0.30f
    @Volatile var rightBodyLv = 0.55f
    @Volatile var frontBodyOn = true
    @Volatile var frontBodyThr = 0.30f
    @Volatile var frontBodyLv = 0.55f
    @Volatile var backBodyOn = true
    @Volatile var backBodyThr = 0.30f
    @Volatile var backBodyLv = 0.55f

    // Brain L/R
    @Volatile var leftBrainOn = true
    @Volatile var leftBrainThr = 0.30f
    @Volatile var leftBrainLv = 0.55f
    @Volatile var rightBrainOn = true
    @Volatile var rightBrainThr = 0.30f
    @Volatile var rightBrainLv = 0.55f

    @Volatile var leftBodyOut = 0f
    @Volatile var rightBodyOut = 0f
    @Volatile var frontBodyOut = 0f
    @Volatile var backBodyOut = 0f
    @Volatile var leftBrainOut = 0f
    @Volatile var rightBrainOut = 0f

    val systemOn = BooleanArray(NSYS) { true }
    val systemThr = FloatArray(NSYS) { 0.30f }
    val systemLv = FloatArray(NSYS) { 0.55f }
    val systemOut = FloatArray(NSYS) { 0f }

    val part84On = BooleanArray(N84) { true }
    val part84Thr = FloatArray(N84) { 0.30f }
    val part84Lv = FloatArray(N84) { 0.55f }
    val part84Out = FloatArray(N84) { 0f }
    val part84Active = BooleanArray(N84) { false }

    @Volatile var avgOut = 0f
    @Volatile var activeCount = 0

    private fun bip01(): Float {
        val n = (bipolarNegDb.coerceIn(-120f, 0f) / 120f) * 0.5f
        val p = (bipolarPosDb.coerceIn(0f, 120f) / 120f) * 0.5f
        return (0.5f + p - n).coerceIn(0.05f, 1f)
    }

    private fun lane(on: Boolean, thr: Float, lv: Float, energy: Float, drive: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (energy * lv * drive).coerceIn(0f, 1f)
        val t = (thr * drive * bip01()).coerceIn(0.05f, 1f)
        return if (energy >= t) {
            (((energy - t) / (1f - t).coerceAtLeast(0.05f)) * lv * drive).coerceIn(0f, 1f)
        } else 0f
    }

    /** Mic energy + model drive → all anatomy ambient outs (adjustable). */
    fun tick(micEnergy: Float, modelDrive: Float = 1f) {
        if (!enabled) {
            leftBodyOut = 0f; rightBodyOut = 0f; frontBodyOut = 0f; backBodyOut = 0f
            leftBrainOut = 0f; rightBrainOut = 0f
            avgOut = 0f; activeCount = 0
            return
        }
        val e = micEnergy.coerceIn(0f, 1f)
        val drive = (0.25f + 0.75f * modelDrive.coerceIn(0f, 1f))
        val g = lane(true, globalThr, globalLv, e, drive)

        leftBodyOut = lane(leftBodyOn, leftBodyThr, leftBodyLv, e * 1.02f, drive)
        rightBodyOut = lane(rightBodyOn, rightBodyThr, rightBodyLv, e * 1.00f, drive)
        frontBodyOut = lane(frontBodyOn, frontBodyThr, frontBodyLv, e * 1.01f, drive)
        backBodyOut = lane(backBodyOn, backBodyThr, backBodyLv, e * 0.98f, drive)
        leftBrainOut = lane(leftBrainOn, leftBrainThr, leftBrainLv, e * 1.03f, drive)
        rightBrainOut = lane(rightBrainOn, rightBrainThr, rightBrainLv, e * 1.01f, drive)

        var sum = leftBodyOut + rightBodyOut + frontBodyOut + backBodyOut + leftBrainOut + rightBrainOut
        var n = 6
        for (i in 0 until NSYS) {
            val bias = 0.92f + (i % 5) * 0.02f
            systemOut[i] = lane(systemOn[i], systemThr[i], systemLv[i], e * bias, drive) * (0.5f + 0.5f * g)
            sum += systemOut[i]; n++
        }
        activeCount = 0
        for (i in 0 until N84) {
            val bias = 0.90f + (i % 7) * 0.015f
            val o = lane(part84On[i], part84Thr[i], part84Lv[i], e * bias, drive) * (0.4f + 0.6f * g)
            part84Out[i] = o
            part84Active[i] = o > 0.02f
            if (part84Active[i]) activeCount++
            sum += o; n++
        }
        avgOut = if (n > 0) (sum / n).coerceIn(0f, 1f) else 0f
    }

    fun setPartThr(idx: Int, thr: Float) {
        if (idx in 0 until N84) part84Thr[idx] = thr.coerceIn(0.05f, 1f)
    }

    fun setPartLv(idx: Int, lv: Float) {
        if (idx in 0 until N84) part84Lv[idx] = lv.coerceIn(0f, 1f)
    }

    fun setPartOn(idx: Int, on: Boolean) {
        if (idx in 0 until N84) part84On[idx] = on
    }

    fun setSystemThr(idx: Int, thr: Float) {
        if (idx in 0 until NSYS) systemThr[idx] = thr.coerceIn(0.05f, 1f)
    }

    fun setSystemLv(idx: Int, lv: Float) {
        if (idx in 0 until NSYS) systemLv[idx] = lv.coerceIn(0f, 1f)
    }

    fun statusLine(): String =
        "FINAL-ANAT L${(leftBodyOut*100).toInt()} R${(rightBodyOut*100).toInt()} " +
        "F${(frontBodyOut*100).toInt()} B${(backBodyOut*100).toInt()} · " +
        "Brain L${(leftBrainOut*100).toInt()} R${(rightBrainOut*100).toInt()} · " +
        "84act=$activeCount avg=${(avgOut*100).toInt()}% " +
        "bip=${"%.0f".format(bipolarPosDb - bipolarNegDb)}dB" +
        if (rawComplete) " · RAW" else ""
    fun apply(v: VisualShieldView?) {
        if (!rawComplete && avgOut < 0.01f) return
        val vv = v ?: return
        try {
            vv.fullAnatomy132.brainOut = maxOf(vv.fullAnatomy132.brainOut, avgOut * 0.6f)
            vv.body84FullHuman.atomOut = maxOf(vv.body84FullHuman.atomOut, avgOut * 0.5f)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, avgOut * 0.35f)
            try { vv.finalProtectionMain.wholeBodyOut = maxOf(vv.finalProtectionMain.wholeBodyOut, avgOut) } catch (_: Throwable) {}
            try { vv.finalProtectionMain.allAnatOut = maxOf(vv.finalProtectionMain.allAnatOut, avgOut) } catch (_: Throwable) {}
        } catch (_: Throwable) {}
    }

}
