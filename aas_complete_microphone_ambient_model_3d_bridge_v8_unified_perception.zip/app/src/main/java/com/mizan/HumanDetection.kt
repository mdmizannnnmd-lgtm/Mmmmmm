package com.mizan

/**
 * One on-device camera result. The part order intentionally matches the
 * existing ten-segment body controls in YoloSegHuman3D.
 */
data class HumanDetection(
    val hasPerson: Boolean,
    val modelReady: Boolean,
    val confidence: Float,
    val poseConfidence: Float,
    val maskConfidence: Float,
    val maskCoverage: Float,
    val centerX: Float,
    val centerY: Float,
    val boxWidth: Float,
    val boxHeight: Float,
    val partScores: List<Float>,
    val status: String,
    val timestampMs: Long = System.currentTimeMillis()
) {
    fun isFresh(nowMs: Long = System.currentTimeMillis()): Boolean =
        nowMs - timestampMs in 0..MAX_AGE_MS

    companion object {
        const val MAX_AGE_MS = 1_500L
        const val PART_HEAD = 0
        const val PART_TORSO = 1
        const val PART_ARM_L = 2
        const val PART_ARM_R = 3
        const val PART_LEG_L = 4
        const val PART_LEG_R = 5
        const val PART_HAND_L = 6
        const val PART_HAND_R = 7
        const val PART_FOOT_L = 8
        const val PART_FOOT_R = 9
        val PART_NAMES = listOf(
            "Head", "Torso", "Left arm", "Right arm", "Left leg", "Right leg",
            "Left hand", "Right hand", "Left foot", "Right foot"
        )

        fun none(status: String = "Waiting for camera", modelReady: Boolean = false) =
            HumanDetection(
                hasPerson = false,
                modelReady = modelReady,
                confidence = 0f,
                poseConfidence = 0f,
                maskConfidence = 0f,
                maskCoverage = 0f,
                centerX = 0.5f,
                centerY = 0.5f,
                boxWidth = 0f,
                boxHeight = 0f,
                partScores = List(PART_NAMES.size) { 0f },
                status = status
            )
    }
}
