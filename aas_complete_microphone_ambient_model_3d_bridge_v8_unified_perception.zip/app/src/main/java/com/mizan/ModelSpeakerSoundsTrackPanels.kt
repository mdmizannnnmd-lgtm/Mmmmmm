package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object ModelSpeakerSoundsTrackPanels {
    fun build(ctx: Context, root: LinearLayout, b: ModelSpeakerSoundsTrackBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFAB47BC.toInt()
        p.title("MODEL SPEAKER TRACK · MIC BULLET · AXIS ALL · ENEMY AMBIENT CNT", c)
        p.note("Model→speaker · mic bullets · XYZ axis thr · burst/bullet/knife/sharp/whip/arrow detect+counters · sensor")
        p.switch("ON", b.enabled) { b.enabled = it }
        p.switch("RAW", b.rawComplete) { b.rawComplete = it }
        p.switch("Model→speaker", b.modelDriveOn) { b.modelDriveOn = it }
        p.switch("Mic bullet", b.micBulletOn) { b.micBulletOn = it }
        p.switch("Axis all sounds", b.axisAllOn) { b.axisAllOn = it }
        p.switch("Enemy ambient detect", b.enemyAmbOn) { b.enemyAmbOn = it }
        p.switch("Sensor fusion", b.sensorOn) { b.sensorOn = it }
        p.seek("Speaker track thr", 0.05f, 0.9f, b.speakerTrackThr) { b.speakerTrackThr = it }
        p.seek("Mic bullet thr", 0.05f, 0.9f, b.micBulletThr) { b.micBulletThr = it }
        p.seek("Axis thr", 0.05f, 0.9f, b.axisThr) { b.axisThr = it }
        p.seek("Enemy amb thr", 0.05f, 0.9f, b.enemyAmbThr) { b.enemyAmbThr = it }
        p.button("Reset counters") { _ -> b.resetCounters() }
        val st = p.status("MODEL-SPK —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() {
                st.text = b.status
                Handler(Looper.getMainLooper()).postDelayed(this, 280)
            }
        })
    }
}
