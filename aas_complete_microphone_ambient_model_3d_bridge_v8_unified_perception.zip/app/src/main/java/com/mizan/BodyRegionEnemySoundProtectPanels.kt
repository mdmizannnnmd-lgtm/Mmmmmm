package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object BodyRegionEnemySoundProtectPanels {
    fun build(ctx: Context, root: LinearLayout, b: BodyRegionEnemySoundProtectBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFEF9A9A.toInt()
        p.title("BODY-REGION ENEMY SFX · KNIFE·BOOM·BURST·SPIKE·PITCH·eVIBE · LIVE MIC dB", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Protect ON", b.protectOn) { b.protectOn = it }
        p.seek("Protect thr", 0.05f, 0.98f, b.protectThr) { b.protectThr = it }
        p.seek("Protect level", 0f, 1.5f, b.protectLv) { b.protectLv = it }
        p.switch("Live mic dB ON", b.micDbOn) { b.micDbOn = it }
        p.seek("Mic dB thr", -80f, 0f, b.micDbThr) { b.micDbThr = it }
        p.seek("Mic dB level", 0f, 1.5f, b.micDbLv) { b.micDbLv = it }
        p.title("REGION + EYE + INSIDE", c)
        p.seek("Region thr", 0.05f, 0.98f, b.regionThr) { b.regionThr = it }
        p.seek("Region level", 0f, 1.5f, b.regionLv) { b.regionLv = it }
        p.switch("Inside body region ON", b.insideOn) { b.insideOn = it }
        p.seek("Inside thr", 0.05f, 0.98f, b.insideThr) { b.insideThr = it }
        p.seek("Inside level", 0f, 1.5f, b.insideLv) { b.insideLv = it }
        val st = p.status("BODY SFX PROT —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 200) }
        })
    }
}
