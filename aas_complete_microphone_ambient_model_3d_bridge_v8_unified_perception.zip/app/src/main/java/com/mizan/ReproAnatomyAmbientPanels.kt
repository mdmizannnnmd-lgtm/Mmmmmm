package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object ReproAnatomyAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: ReproAnatomyAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFF48FB1.toInt()
        p.title("REPRO ANATOMY · INSIDE / OUTSIDE (medical)", c)
        p.note("Gonads · ducts · external · prostate/uterus — ambient channels only")
        p.switch("Repro ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.seek("Threshold", 0.05f, 1f, b.thr) { b.thr = it }
        p.seek("Level", 0.1f, 1.5f, b.levelAmt) { b.levelAmt = it }
        val st = p.status("REPRO —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 300) }
        })
    }
}
