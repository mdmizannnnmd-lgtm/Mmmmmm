package com.mizan

/**
 * BLE sensor threshold · ambient block enemy BLE ·
 * audio path so enemies cannot reuse the same BLE/audio effect on us.
 * Own BLE keep · enemy BLE damp. RAW COMPLETE.
 */
class BleEnemyAmbientBlockBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Own BLE sensor gate
    @Volatile var ownBleThr = 0.20f
    @Volatile var ownBleLv = 0.92f
    @Volatile var ownBleOut = 0f

    // Enemy BLE detect / block
    @Volatile var enemyBleThr = 0.22f
    @Volatile var enemyBleBlockOn = true
    @Volatile var enemyBleBlockLv = 0.96f
    @Volatile var enemyBleOut = 0f
    @Volatile var enemyBleBlocked = 0f

    // Audio mirror abuse block (enemy cannot same effect)
    @Volatile var audioMirrorBlockOn = true
    @Volatile var audioMirrorThr = 0.25f
    @Volatile var audioMirrorBlockLv = 0.94f
    @Volatile var audioMirrorOut = 0f
    @Volatile var audioBlocked = 0f

    // Combined ambient block
    @Volatile var bleAmbientBlockOut = 0f
    @Volatile var status = "BLE-ENEMY-BLOCK idle"

    private fun lane(e: Float, thr: Float, lv: Float): Float {
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * lv).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * lv).coerceIn(0f, 1f) else 0f
    }

    /**
     * @param ownBle own scale/watt/vibe energy
     * @param enemyBle enemy BLE track energy
     * @param mic live mic energy (mirror abuse detect)
     * @param enemyAudio enemy body/sound lane
     */
    fun tick(ownBle: Float, enemyBle: Float, mic: Float, enemyAudio: Float) {
        if (!enabled) {
            status = "BLE-ENEMY-BLOCK OFF"
            return
        }
        ownBleOut = lane(ownBle, ownBleThr, ownBleLv)

        enemyBleOut = lane(enemyBle, enemyBleThr, 1f)
        enemyBleBlocked = if (enemyBleBlockOn) (enemyBleOut * enemyBleBlockLv).coerceIn(0f, 1f) else 0f

        // Same-effect abuse: mic correlates with enemy audio while enemy BLE present
        val mirror = maxOf(mic * 0.7f, enemyAudio) * (0.4f + enemyBleOut * 0.6f)
        audioMirrorOut = lane(mirror, audioMirrorThr, 1f)
        audioBlocked = if (audioMirrorBlockOn) (audioMirrorOut * audioMirrorBlockLv).coerceIn(0f, 1f) else 0f

        bleAmbientBlockOut = maxOf(enemyBleBlocked, audioBlocked)
        if (rawComplete) bleAmbientBlockOut = maxOf(bleAmbientBlockOut, 0.2f + enemyBleOut * 0.4f)

        status =
            "OWN BLE=${(ownBleOut*100).toInt()}% · ENEMY BLE=${(enemyBleOut*100).toInt()}% blocked=${(enemyBleBlocked*100).toInt()}% · " +
            "audio mirror block=${(audioBlocked*100).toInt()}% · AMB-BLOCK=${(bleAmbientBlockOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!enabled || bleAmbientBlockOut < 0.02f) return
        val damp = (1f - bleAmbientBlockOut * 0.95f).coerceIn(0.03f, 1f)
        try {
            // Enemy cannot push same effect through body/mic enemy lanes
            if (sb != null) {
                sb.enemyBodyOut *= damp
                sb.micEnemyOut *= damp
                if (audioBlocked > 0.02f) {
                    sb.burstOut *= (1f - audioBlocked * 0.5f).coerceIn(0.1f, 1f)
                    sb.bulletOut *= (1f - audioBlocked * 0.45f).coerceIn(0.1f, 1f)
                }
            }
        } catch (_: Throwable) {}
        val vv = v ?: return
        try {
            vv.enemyBleScaleTrack.enemyScaleOut *= (1f - enemyBleBlocked * 0.9f).coerceIn(0.05f, 1f)
            vv.enemy3dProtect.enemyModelOut *= (1f - bleAmbientBlockOut * 0.7f).coerceIn(0.05f, 1f)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, bleAmbientBlockOut * 0.55f)
            vv.mgBleScaleWatt.mgOut = maxOf(vv.mgBleScaleWatt.mgOut, ownBleOut * 0.3f)
        } catch (_: Throwable) {}
    }
}
