package com.mizan

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * AMBIENT THRESHOLD BOARD (live) — same look as the original board: black ground, outlined status pill
 * ("SILENCE · RMS · PK"), flat teal line (live waveform), teal spectrum bars, "Dom · Centroid · Atmo" read-outs and the
 * white-thumb "Ambient Threshold" slider — extended with
 *
 *   · the CENTROID marker + threshold + bipolar (− / +) rails on the spectrum, and a bipolar centroid meter,
 *   · the VERTICAL gauge (height of the body centroid, feet → head) + bipolar vertical meter,
 *   · the LIVE MICROPHONE dB meter with the noise floor and the AUTO threshold,
 *   · sliders: Ambient Threshold · Centroid level / threshold / − rail / + rail · Vertical level / threshold / − rail / + rail,
 *   · chips: AUTO · CEN BIPOLAR · VERT BIPOLAR · CEN RAW · VERT RAW.
 *
 * It only reads / writes the fields of [AmbientThresholdBoard]; [onChanged] is called with (key, value) to persist a setting.
 */
class AmbientCentroidView(ctx: Context, private val b: AmbientThresholdBoard, private val onChanged: (String, Float) -> Unit) : View(ctx) {

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    // palette (taken from the original board)
    private val cBg = Color.rgb(0, 0, 0)
    private val cPillStroke = Color.rgb(0x14, 0x30, 0x38)
    private val cText = Color.rgb(0xC6, 0xE6, 0xEC)
    private val cTextDim = Color.rgb(0x4B, 0x86, 0x93)
    private val cLabel = Color.rgb(0x3A, 0x6E, 0x7A)
    private val cLine = Color.rgb(0x2B, 0xA8, 0xB6)
    private val cBar = Color.rgb(0x1A, 0x6A, 0x7B)
    private val cTrack = Color.rgb(0x0B, 0x1A, 0x1F)
    private val cVal = Color.rgb(0xBF, 0xF3, 0xFF)
    private val cAmber = Color.rgb(0xFF, 0xC1, 0x07)
    private val cNeg = Color.rgb(0x5C, 0x6B, 0xC0)
    private val cAlert = Color.rgb(0xFF, 0x70, 0x43)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val mono = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
    private val sans = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT }
    private val rf = RectF()
    private val path = Path()

    // ── slider rows ────────────────────────────────────────────────────────────────────────────────
    private class Row(
        val key: String, val label: String, val min: Float, val max: Float,
        val get: () -> Float, val set: (Float) -> Unit, val fmt: (Float) -> String, val color: Int = 0
    ) { val rect = RectF() }

    private fun hzAt(t: Float): Int = (LiveSpectrumAnalyzer.F_MIN * (LiveSpectrumAnalyzer.F_MAX / LiveSpectrumAnalyzer.F_MIN).toDouble().pow(t.toDouble())).toInt()

    private val rows: List<Row> = listOf(
        Row("thr", "Ambient Threshold", 0f, 100f, { b.manualThrPct() },
            { v -> b.ambientThrPct = v; if (!b.liveOutput) b.lockedPct = v }, { "%.1f%%".format(it) }),
        Row("auto_margin", "Auto threshold margin above noise floor", 0f, 40f, { b.autoMarginDb }, { b.autoMarginDb = it }, { "+%.0f dB".format(it) }),
        Row("cen_lv", "Centroid Level", 0f, 1.5f, { b.centroidLevel }, { b.centroidLevel = it }, { "%.0f%%".format(it * 100) }, cAmber),
        Row("cen_thr", "Centroid Threshold", 0f, 0.98f, { b.centroidThr }, { b.centroidThr = it },
            { "%.0f%% · %d Hz".format(it * 100, hzAt(it)) }, cAmber),
        Row("cen_neg", "Centroid bipolar − rail (darker sound)", 0f, 1.5f, { b.centroidNegGain }, { b.centroidNegGain = it }, { "−%.0f%%".format(it * 100) }, cNeg),
        Row("cen_pos", "Centroid bipolar + rail (brighter sound)", 0f, 1.5f, { b.centroidPosGain }, { b.centroidPosGain = it }, { "+%.0f%%".format(it * 100) }, cAmber),
        Row("ver_lv", "Vertical Level", 0f, 1.5f, { b.verticalLevel }, { b.verticalLevel = it }, { "%.0f%%".format(it * 100) }, cLine),
        Row("ver_thr", "Vertical Threshold (0 feet · 1 head)", 0f, 0.98f, { b.verticalThr }, { b.verticalThr = it }, { "%.0f%% height".format(it * 100) }, cLine),
        Row("ver_neg", "Vertical bipolar − rail (below threshold)", 0f, 1.5f, { b.verticalNegGain }, { b.verticalNegGain = it }, { "−%.0f%%".format(it * 100) }, cNeg),
        Row("ver_pos", "Vertical bipolar + rail (above threshold)", 0f, 1.5f, { b.verticalPosGain }, { b.verticalPosGain = it }, { "+%.0f%%".format(it * 100) }, cLine)
    )

    private class Chip(val label: String, val get: () -> Boolean, val set: (Boolean) -> Unit) { val rect = RectF() }

    private val chips: List<Chip> = listOf(
        Chip("AUTO THR", { b.autoThr }, { b.autoThr = it; onChanged("auto_on", if (it) 1f else 0f) }),
        Chip("CEN BIPOLAR", { b.centroidBipolar }, { b.centroidBipolar = it; onChanged("cen_bip", if (it) 1f else 0f) }),
        Chip("VERT BIPOLAR", { b.verticalBipolar }, { b.verticalBipolar = it; onChanged("ver_bip", if (it) 1f else 0f) }),
        Chip("CEN RAW", { b.centroidRaw }, { b.centroidRaw = it }),
        Chip("VERT RAW", { b.verticalRaw }, { b.verticalRaw = it }),
        Chip("CEN ON", { b.centroidOn }, { b.centroidOn = it; onChanged("cen_on", if (it) 1f else 0f) }),
        Chip("VERT ON", { b.verticalOn }, { b.verticalOn = it; onChanged("ver_on", if (it) 1f else 0f) })
    )

    // layout rects (computed in onSizeChanged / onMeasure)
    private val pill = RectF()
    private val waveR = RectF()
    private val barsR = RectF()
    private var labelsY = 0f
    private val bipR = RectF()
    private val dbR = RectF()
    private var totalH = 0f
    private var dragRow: Row? = null

    private val ticker = object : Runnable {
        override fun run() { invalidate(); postOnAnimation(this) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); postOnAnimation(ticker) }
    override fun onDetachedFromWindow() { removeCallbacks(ticker); super.onDetachedFromWindow() }

    private fun layoutAll(w: Float) {
        val pad = dp(2f)
        var y = dp(4f)
        pill.set(pad, y, w - pad, y + dp(50f)); y += dp(50f) + dp(16f)
        waveR.set(pad, y, w - pad, y + dp(74f)); y += dp(74f) + dp(10f)
        barsR.set(pad, y, w - pad, y + dp(84f)); y += dp(84f) + dp(8f)
        labelsY = y + dp(12f); y += dp(22f)
        bipR.set(pad, y, w - pad, y + dp(44f)); y += dp(44f) + dp(6f)
        dbR.set(pad, y, w - pad, y + dp(40f)); y += dp(40f) + dp(14f)
        // chips (wrap)
        var cx = pad
        val ch = dp(30f)
        mono.textSize = dp(11f)
        for (c in chips) {
            val cw = mono.measureText(c.label) + dp(24f)
            if (cx + cw > w - pad) { cx = pad; y += ch + dp(8f) }
            c.rect.set(cx, y, cx + cw, y + ch)
            cx += cw + dp(8f)
        }
        y += ch + dp(14f)
        // sliders
        for (r in rows) { r.rect.set(pad, y, w - pad, y + dp(58f)); y += dp(62f) }
        totalH = y + dp(6f)
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec).toFloat().coerceAtLeast(dp(200f))
        layoutAll(w)
        setMeasuredDimension(w.toInt(), totalH.toInt())
    }

    // ───────────────────────────────────────────────────────────────────────────── drawing
    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        c.drawColor(cBg)
        drawPill(c)
        drawWave(c)
        drawInsideOutside(c)
        drawBars(c)
        drawReadouts(c)
        drawBipolar(c)
        drawDb(c)
        drawChips(c)
        for (r in rows) drawSlider(c, r)
    }

    private fun drawPill(c: Canvas) {
        stroke.color = cPillStroke; stroke.strokeWidth = dp(1.5f)
        c.drawRoundRect(pill, dp(12f), dp(12f), stroke)
        val label = when {
            b.silence -> "SILENCE"
            b.overThr -> "OVER-THR"
            else -> "OPEN"
        }
        mono.textSize = dp(17f); mono.color = if (b.overThr && !b.silence) cAlert else cText
        mono.textAlign = Paint.Align.LEFT
        c.drawText(label, pill.left + dp(18f), pill.centerY() + dp(6f), mono)
        mono.textSize = dp(15f); mono.color = cTextDim; mono.textAlign = Paint.Align.RIGHT
        c.drawText("RMS ${"%.1f".format(b.rmsPct)}% · PK ${"%.1f".format(b.pkPct)}%", pill.right - dp(18f), pill.centerY() + dp(5f), mono)
        mono.textAlign = Paint.Align.LEFT
    }

    private fun drawWave(c: Canvas) {
        // body-height gauge on the right (vertical): feet → head, threshold tick, centroid marker
        val gaugeW = dp(26f)
        val gx = waveR.right - gaugeW / 2f
        val gt = waveR.top + dp(4f); val gb = waveR.bottom - dp(4f)
        fill.color = cTrack
        rf.set(gx - dp(4f), gt, gx + dp(4f), gb); c.drawRoundRect(rf, dp(4f), dp(4f), fill)
        val ver = b.verticalNorm
        val vy = gb - (gb - gt) * ver
        val ty = gb - (gb - gt) * b.verticalThr
        fill.color = Color.argb(150, Color.red(cLine), Color.green(cLine), Color.blue(cLine))
        rf.set(gx - dp(4f), min(vy, ty), gx + dp(4f), max(vy, ty))
        c.drawRoundRect(rf, dp(4f), dp(4f), fill)
        stroke.color = cAmber; stroke.strokeWidth = dp(1.5f)
        c.drawLine(gx - dp(10f), ty, gx + dp(10f), ty, stroke)
        fill.color = Color.WHITE; c.drawCircle(gx, vy, dp(5f), fill)

        // flat teal line = live waveform (flat in silence)
        val x0 = waveR.left; val x1 = waveR.right - gaugeW - dp(8f)
        val cy = waveR.centerY()
        stroke.color = cLine; stroke.strokeWidth = dp(1.6f)
        val wv = b.wave
        if (wv.isEmpty()) { c.drawLine(x0, cy, x1, cy, stroke); return }
        path.reset()
        val amp = (waveR.height() / 2f - dp(6f)) * 3f
        for (i in wv.indices) {
            val x = x0 + (x1 - x0) * i / (wv.size - 1).coerceAtLeast(1)
            val y = cy - (wv[i] * amp).coerceIn(-waveR.height() / 2f + dp(4f), waveR.height() / 2f - dp(4f))
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, stroke)
    }

    private fun xOfHz(hz: Float): Float = barsR.left + barsR.width() * hzNorm(hz)
    private fun hzNorm(hz: Float): Float =
        if (hz <= 0f) 0f else (kotlin.math.ln(hz.coerceIn(LiveSpectrumAnalyzer.F_MIN, LiveSpectrumAnalyzer.F_MAX) / LiveSpectrumAnalyzer.F_MIN) /
            kotlin.math.ln(LiveSpectrumAnalyzer.F_MAX / LiveSpectrumAnalyzer.F_MIN))

    private fun drawBars(c: Canvas) {
        val bands = b.bands
        val n = bands.size
        // bipolar rails: left of the centroid threshold (−) and right of it (+)
        val tx = barsR.left + barsR.width() * b.centroidThr.coerceIn(0f, 1f)
        fill.color = Color.argb(26, Color.red(cNeg), Color.green(cNeg), Color.blue(cNeg))
        rf.set(barsR.left, barsR.top, tx, barsR.bottom); c.drawRect(rf, fill)
        fill.color = Color.argb(20, Color.red(cAmber), Color.green(cAmber), Color.blue(cAmber))
        rf.set(tx, barsR.top, barsR.right, barsR.bottom); c.drawRect(rf, fill)

        val gap = dp(1.4f)
        val bw = (barsR.width() - gap * (n - 1)) / n
        val minH = dp(3f)
        fill.color = cBar
        for (i in 0 until n) {
            val h = max(minH, barsR.height() * bands[i].coerceIn(0f, 1f))
            val x = barsR.left + i * (bw + gap)
            rf.set(x, barsR.bottom - h, x + bw, barsR.bottom)
            c.drawRoundRect(rf, bw * 0.3f, bw * 0.3f, fill)
        }
        // ambient threshold line (dB mapped like the bars: −100 dB … −20 dB)
        val thrDb = 20.0 * log10(max(b.effectiveThrPct() / 100.0, 1e-5))
        val ty = barsR.bottom - barsR.height() * (((thrDb + 100.0) / 80.0).toFloat().coerceIn(0f, 1f))
        stroke.color = Color.argb(200, 255, 255, 255); stroke.strokeWidth = dp(1f)
        var x = barsR.left
        while (x < barsR.right) { c.drawLine(x, ty, min(x + dp(5f), barsR.right), ty, stroke); x += dp(9f) }

        // centroid threshold (dashed amber), centroid marker, dominant marker
        stroke.color = Color.argb(150, Color.red(cAmber), Color.green(cAmber), Color.blue(cAmber)); stroke.strokeWidth = dp(1f)
        var y = barsR.top
        while (y < barsR.bottom) { c.drawLine(tx, y, tx, min(y + dp(4f), barsR.bottom), stroke); y += dp(8f) }
        if (b.domHz > 0f) {
            val dx = xOfHz(b.domHz)
            stroke.color = Color.argb(200, 255, 255, 255); stroke.strokeWidth = dp(1f)
            c.drawLine(dx, barsR.top + dp(10f), dx, barsR.bottom, stroke)
        }
        if (b.centroidHz > 0f) {
            val cx = xOfHz(b.centroidHz)
            stroke.color = if (b.centroidHit) cAmber else Color.argb(220, Color.red(cAmber), Color.green(cAmber), Color.blue(cAmber))
            stroke.strokeWidth = dp(2f)
            c.drawLine(cx, barsR.top, cx, barsR.bottom, stroke)
            path.reset(); path.moveTo(cx - dp(5f), barsR.top - dp(1f)); path.lineTo(cx + dp(5f), barsR.top - dp(1f)); path.lineTo(cx, barsR.top + dp(7f)); path.close()
            fill.color = cAmber; c.drawPath(path, fill)
        }
    }

    private fun drawReadouts(c: Canvas) {
        mono.textSize = dp(12.5f); mono.color = cLabel
        mono.textAlign = Paint.Align.LEFT
        c.drawText("Dom: ${b.domHz.toInt()}Hz", barsR.left + dp(2f), labelsY, mono)
        mono.textAlign = Paint.Align.CENTER
        c.drawText("Centroid: ${b.centroidHz.toInt()}Hz", barsR.centerX(), labelsY, mono)
        c.drawText("Domination: ${b.dominationHz.toInt()}Hz out=${(b.dominationOut*100).toInt()}%", barsR.centerX(), labelsY + 28f, mono)
        mono.textAlign = Paint.Align.RIGHT
        c.drawText("Atmo: ${"%.1f".format(b.atmoPct)}%", barsR.right - dp(2f), labelsY, mono)
        mono.textAlign = Paint.Align.LEFT
    }

    /** Two centred bipolar meters: CENTROID (spectral) and VERTICAL (body height). */
    private fun drawBipolar(c: Canvas) {
        val half = (bipR.width() - dp(12f)) / 2f
        bipMeter(c, bipR.left, bipR.top, half, "CENTROID", b.centroidBip, b.centroidOut, cAmber, b.centroidRaw || b.rawEverything)
        bipMeter(c, bipR.left + half + dp(12f), bipR.top, half, "VERTICAL", b.verticalBip, b.verticalOut, cLine, b.verticalRaw || b.rawEverything)
    }

    private fun bipMeter(c: Canvas, x: Float, y: Float, w: Float, name: String, bip: Float, out: Float, col: Int, raw: Boolean) {
        mono.textSize = dp(11f); mono.color = cLabel; mono.textAlign = Paint.Align.LEFT
        c.drawText(name + (if (raw) " · RAW" else ""), x, y + dp(11f), mono)
        mono.textAlign = Paint.Align.RIGHT; mono.color = cVal
        c.drawText("${"%+.0f".format(bip * 100)}%  out ${"%.0f".format(out * 100)}%", x + w, y + dp(11f), mono)
        mono.textAlign = Paint.Align.LEFT
        val ty = y + dp(20f); val th = dp(10f)
        fill.color = cTrack; rf.set(x, ty, x + w, ty + th); c.drawRoundRect(rf, th / 2, th / 2, fill)
        val mid = x + w / 2f
        val vx = mid + (w / 2f) * bip.coerceIn(-1f, 1f)
        fill.color = if (bip >= 0f) col else cNeg
        rf.set(min(mid, vx), ty, max(mid, vx), ty + th); c.drawRoundRect(rf, th / 2, th / 2, fill)
        stroke.color = Color.argb(180, 255, 255, 255); stroke.strokeWidth = dp(1.2f)
        c.drawLine(mid, ty - dp(3f), mid, ty + th + dp(3f), stroke)
    }

    /** Live microphone dB meter: level, noise floor tick, AUTO threshold tick. */
    private fun drawDb(c: Canvas) {
        val x = dbR.left; val w = dbR.width(); val y = dbR.top
        mono.textSize = dp(11f); mono.color = cLabel; mono.textAlign = Paint.Align.LEFT
        c.drawText("MIC ${"%.1f".format(b.micDbfs)} dBFS · ${"%.1f".format(b.micDb())} dB", x, y + dp(11f), mono)
        mono.textAlign = Paint.Align.RIGHT
        mono.color = if (b.autoThr && b.liveOutput) cVal else cTextDim
        c.drawText(if (b.autoThr && b.liveOutput) "AUTO ${"%.0f".format(b.autoThrDb)} dB → thr ${"%.1f".format(b.effectiveThrPct())}%"
        else "thr manual ${"%.1f".format(b.effectiveThrPct())}%", x + w, y + dp(11f), mono)
        mono.textAlign = Paint.Align.LEFT
        val ty = y + dp(20f); val th = dp(10f)
        fill.color = cTrack; rf.set(x, ty, x + w, ty + th); c.drawRoundRect(rf, th / 2, th / 2, fill)
        fun px(db: Double) = x + w * ((db + 90.0) / 90.0).toFloat().coerceIn(0f, 1f)
        val lv = px(b.micDbfs)
        fill.color = if (b.overThr) cAlert else cBar
        rf.set(x, ty, max(x + th, lv), ty + th); c.drawRoundRect(rf, th / 2, th / 2, fill)
        // peak tick
        stroke.color = Color.argb(200, 255, 255, 255); stroke.strokeWidth = dp(1.2f)
        val pk = px(b.micPeakDbfs); c.drawLine(pk, ty - dp(2f), pk, ty + th + dp(2f), stroke)
        // noise floor tick (blue) + auto threshold tick (amber)
        stroke.color = cNeg; stroke.strokeWidth = dp(2f)
        val nf = px(b.noiseFloorDb); c.drawLine(nf, ty - dp(4f), nf, ty + th + dp(4f), stroke)
        stroke.color = cAmber
        val effDb = 20.0 * log10(max(b.effectiveThrPct() / 100.0, 1e-5))
        val at = px(effDb); c.drawLine(at, ty - dp(4f), at, ty + th + dp(4f), stroke)
    }

    private fun drawChips(c: Canvas) {
        mono.textSize = dp(11f); mono.textAlign = Paint.Align.CENTER
        for (ch in chips) {
            val on = ch.get()
            if (on) { fill.color = Color.argb(60, Color.red(cLine), Color.green(cLine), Color.blue(cLine)); c.drawRoundRect(ch.rect, dp(15f), dp(15f), fill) }
            stroke.color = if (on) cLine else cPillStroke; stroke.strokeWidth = dp(1.5f)
            c.drawRoundRect(ch.rect, dp(15f), dp(15f), stroke)
            mono.color = if (on) cVal else cTextDim
            c.drawText(ch.label, ch.rect.centerX(), ch.rect.centerY() + dp(4f), mono)
        }
        mono.textAlign = Paint.Align.LEFT
    }

    private fun drawSlider(c: Canvas, r: Row) {
        val v = r.get().coerceIn(r.min, r.max)
        sans.textSize = dp(15f); sans.color = if (r.color == 0) Color.rgb(0x5E, 0x9D, 0xAA) else r.color
        sans.textAlign = Paint.Align.LEFT
        c.drawText(r.label, r.rect.left + dp(2f), r.rect.top + dp(18f), sans)
        sans.textSize = dp(16f); sans.color = cVal; sans.textAlign = Paint.Align.RIGHT
        c.drawText(r.fmt(v), r.rect.right - dp(2f), r.rect.top + dp(18f), sans)
        sans.textAlign = Paint.Align.LEFT
        val tr = trackRect(r)
        fill.color = cTrack; c.drawRoundRect(tr, tr.height() / 2, tr.height() / 2, fill)
        val t = (v - r.min) / (r.max - r.min)
        val tx = tr.left + tr.width() * t
        fill.color = Color.argb(150, Color.red(cLine), Color.green(cLine), Color.blue(cLine))
        rf.set(tr.left, tr.top, max(tr.left + tr.height(), tx), tr.bottom); c.drawRoundRect(rf, tr.height() / 2, tr.height() / 2, fill)
        fill.color = Color.argb(70, 0, 0, 0); c.drawCircle(tx, tr.centerY() + dp(1.5f), dp(13f), fill)
        fill.color = Color.WHITE; c.drawCircle(tx, tr.centerY(), dp(12f), fill)
    }

    private val trackTmp = RectF()
    private fun trackRect(r: Row): RectF {
        val inset = dp(14f)
        trackTmp.set(r.rect.left + inset, r.rect.top + dp(34f), r.rect.right - inset, r.rect.top + dp(44f))
        return trackTmp
    }

    // ───────────────────────────────────────────────────────────────────────────── touch
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                for (r in rows) if (e.y >= r.rect.top + dp(20f) && e.y <= r.rect.bottom && e.x >= r.rect.left && e.x <= r.rect.right) {
                    dragRow = r
                    parent?.requestDisallowInterceptTouchEvent(true)
                    applyDrag(r, e.x)
                    return true
                }
                for (ch in chips) if (ch.rect.contains(e.x, e.y)) { ch.set(!ch.get()); invalidate(); return true }
                return false
            }
            MotionEvent.ACTION_MOVE -> { dragRow?.let { applyDrag(it, e.x); return true } }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragRow?.let { applyDrag(it, e.x) }
                dragRow = null
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    private fun applyDrag(r: Row, x: Float) {
        val tr = trackRect(r)
        val t = ((x - tr.left) / tr.width()).coerceIn(0f, 1f)
        val v = r.min + (r.max - r.min) * t
        r.set(v)
        onChanged(r.key, v)
        invalidate()
    }
    private fun drawInsideOutside(c: Canvas) {
        val b = this.b
        val pad = dp(8f)
        val y0 = height - dp(72f)
        val w = width - pad * 2
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.textSize = sp(11f)
        paint.color = 0xFFE0F7FA.toInt()
        val db = b.micDb()
        c.drawText(AmbientSystems.line(AmbientSystems.snapshot(b)).take(80), pad, y0 - dp(14f), paint)
        c.drawText(
            "BODY CEN ${b.centroidHz.toInt()}Hz DOM ${b.dominationHz.toInt()}Hz out=${(b.dominationOut*100).toInt()}% ${"%+.0f".format(db)}dB VERT ${(b.verticalNorm*100).toInt()}%",
            pad, y0, paint
        )
        paint.color = 0xFF80CBC4.toInt()
        c.drawText(
            "INSIDE  ${b.insideHz.toInt()}Hz  C${(b.insideCenOut*100).toInt()}%  V${(b.insideVerOut*100).toInt()}%",
            pad, y0 + dp(16f), paint
        )
        paint.color = 0xFFFFCC80.toInt()
        c.drawText(
            "OUTSIDE ${b.outsideHz.toInt()}Hz  C${(b.outsideCenOut*100).toInt()}%  V${(b.outsideVerOut*100).toInt()}%",
            pad, y0 + dp(32f), paint
        )
        paint.color = 0xFFB39DDB.toInt()
        c.drawText(
            "ATOMSPARE ${b.centroidHz.toInt()}Hz DOM ${b.dominationHz.toInt()}Hz ${"%+.0f".format(db)}dB IN/OUT ${if (b.rawEverything) "RAW" else "live"}",
            pad, y0 + dp(48f), paint
        )
        // bars
        val barY = y0 + dp(40f)
        val barH = dp(6f)
        paint.style = android.graphics.Paint.Style.FILL
        paint.color = 0x4480CBC4.toInt()
        c.drawRect(pad, barY, pad + w * b.insideCenOut.coerceIn(0f, 1f), barY + barH, paint)
        paint.color = 0x44FFCC80.toInt()
        c.drawRect(pad, barY + barH + dp(2f), pad + w * b.outsideCenOut.coerceIn(0f, 1f), barY + barH * 2 + dp(2f), paint)
    }

    private fun sp(v: Float): Float = v * resources.displayMetrics.scaledDensity

}
