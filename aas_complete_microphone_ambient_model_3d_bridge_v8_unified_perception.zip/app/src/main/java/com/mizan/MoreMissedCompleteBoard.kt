package com.mizan

/**
 * More missed systems — ears/auditory · oral/teeth/tongue · hands/feet · skin layers ·
 * reproductive · lymph detailed · joint/tendon · raw complete.
 */
class MoreMissedCompleteBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    @Volatile var thr = 0.22f
    @Volatile var lv = 0.85f

    // Ears / auditory
    @Volatile var earOn = true
    @Volatile var earL = 0f; @Volatile var earR = 0f
    @Volatile var canalL = 0f; @Volatile var canalR = 0f
    @Volatile var cochleaL = 0f; @Volatile var cochleaR = 0f
    @Volatile var auditoryNerve = 0f
    @Volatile var eardrumL = 0f
    @Volatile var eardrumR = 0f
    @Volatile var ossicleL = 0f
    @Volatile var ossicleR = 0f
    @Volatile var nailHandL = 0f
    @Volatile var nailHandR = 0f
    @Volatile var nailFootL = 0f
    @Volatile var nailFootR = 0f

    // Oral
    @Volatile var oralOn = true
    @Volatile var teeth = 0f
    @Volatile var tongue = 0f
    @Volatile var gums = 0f
    @Volatile var saliva = 0f
    @Volatile var throat = 0f

    // Hands / feet detail
    @Volatile var extremitiesOn = true
    @Volatile var handL = 0f; @Volatile var handR = 0f
    @Volatile var fingerL = 0f; @Volatile var fingerR = 0f
    @Volatile var footL = 0f; @Volatile var footR = 0f
    @Volatile var toeL = 0f; @Volatile var toeR = 0f
    @Volatile var wristL = 0f; @Volatile var wristR = 0f
    @Volatile var ankleL = 0f; @Volatile var ankleR = 0f

    // Skin layers
    @Volatile var skinLayersOn = true
    @Volatile var epidermis = 0f
    @Volatile var dermis = 0f
    @Volatile var hypodermis = 0f
    @Volatile var sweat = 0f
    @Volatile var follicle = 0f

    // Reproductive / pelvic
    @Volatile var pelvicOn = true
    @Volatile var pelvic = 0f
    @Volatile var reproductive = 0f

    // Joints / tendons / fascia
    @Volatile var jointOn = true
    @Volatile var joints = 0f
    @Volatile var tendons = 0f
    @Volatile var fascia = 0f

    // Lymph detailed
    @Volatile var lymphOn = true
    @Volatile var lymphNodes = 0f
    @Volatile var lymphFlow = 0f

    @Volatile var status = "MORE-MISSED idle"

    private fun lane(on: Boolean, e: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv).coerceIn(0f, 1f)
        val t = thr.coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv).coerceIn(0f, 1f) else 0f
    }

    fun tick(mic: Float) {
        if (!enabled) {
            status = "MORE-MISSED OFF"
            return
        }
        val e = mic.coerceIn(0f, 1f)

        earL = lane(earOn, e); earR = lane(earOn, e * 0.98f)
        canalL = earL * 0.9f; canalR = earR * 0.9f
        cochleaL = earL * 0.85f; cochleaR = earR * 0.85f
        auditoryNerve = maxOf(earL, earR) * 0.88f
        eardrumL = earL * 0.86f; eardrumR = earR * 0.86f
        ossicleL = earL * 0.82f; ossicleR = earR * 0.82f
        nailHandL = handL * 0.85f; nailHandR = handR * 0.85f
        nailFootL = footL * 0.85f; nailFootR = footR * 0.85f

        teeth = lane(oralOn, e * 0.95f)
        tongue = lane(oralOn, e * 0.92f)
        gums = teeth * 0.9f
        saliva = tongue * 0.85f
        throat = lane(oralOn, e * 0.9f)

        handL = lane(extremitiesOn, e * 0.94f); handR = lane(extremitiesOn, e * 0.93f)
        fingerL = handL * 0.9f; fingerR = handR * 0.9f
        footL = lane(extremitiesOn, e * 0.9f); footR = lane(extremitiesOn, e * 0.89f)
        toeL = footL * 0.88f; toeR = footR * 0.88f
        wristL = handL * 0.85f; wristR = handR * 0.85f
        ankleL = footL * 0.85f; ankleR = footR * 0.85f

        epidermis = lane(skinLayersOn, e)
        dermis = epidermis * 0.95f
        hypodermis = epidermis * 0.9f
        sweat = epidermis * 0.8f
        follicle = epidermis * 0.75f

        pelvic = lane(pelvicOn, e * 0.88f)
        reproductive = pelvic * 0.9f

        joints = lane(jointOn, e * 0.9f)
        tendons = joints * 0.9f
        fascia = joints * 0.85f

        lymphNodes = lane(lymphOn, e * 0.85f)
        lymphFlow = lymphNodes * 0.9f

        status =
            "EAR L/R=${(earL*100).toInt()}/${(earR*100).toInt()} ORAL T/Teeth=${(tongue*100).toInt()}/${(teeth*100).toInt()} · " +
            "HAND L/R=${(handL*100).toInt()}/${(handR*100).toInt()} FOOT=${(footL*100).toInt()} · " +
            "SKIN epi=${(epidermis*100).toInt()} · JOINT=${(joints*100).toInt()} LYMPH=${(lymphNodes*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(v: VisualShieldView) {
        if (!enabled) return
        try {
            v.face.atmosphere = maxOf(v.face.atmosphere, earL * 0.5f, earR * 0.5f, teeth * 0.4f, tongue * 0.4f)
            v.neck.atmosphere = maxOf(v.neck.atmosphere, throat, auditoryNerve * 0.6f)
            v.handL.atmosphere = maxOf(v.handL.atmosphere, handL, fingerL)
            v.handR.atmosphere = maxOf(v.handR.atmosphere, handR, fingerR)
            v.skinFootL.atmosphere = maxOf(v.skinFootL.atmosphere, footL, toeL)
            v.skinFootR.atmosphere = maxOf(v.skinFootR.atmosphere, footR, toeR)
            v.skinArmL.atmosphere = maxOf(v.skinArmL.atmosphere, wristL)
            v.skinArmR.atmosphere = maxOf(v.skinArmR.atmosphere, wristR)
            v.skinLegL.atmosphere = maxOf(v.skinLegL.atmosphere, ankleL)
            v.skinLegR.atmosphere = maxOf(v.skinLegR.atmosphere, ankleR)
            v.skinAll.atmosphere = maxOf(v.skinAll.atmosphere, epidermis, dermis)
            v.belly.atmosphere = maxOf(v.belly.atmosphere, pelvic * 0.7f, lymphNodes * 0.5f)
        } catch (_: Throwable) {}
        try {
            v.skinAtomspare.epidermisOut = maxOf(v.skinAtomspare.epidermisOut, epidermis)
            v.skinAtomspare.skinOutsideOut = maxOf(v.skinAtomspare.skinOutsideOut, epidermis)
            v.skinAtomspare.skinInsideOut = maxOf(v.skinAtomspare.skinInsideOut, hypodermis)
        } catch (_: Throwable) {}
        try {
            v.anatomy3d.atmosphere = maxOf(v.anatomy3d.atmosphere, maxOf(earL, earR), teeth, joints, epidermis)
            v.completeAtomProtect.atomOut = maxOf(v.completeAtomProtect.atomOut, epidermis * 0.5f, joints * 0.4f)
        } catch (_: Throwable) {}
    }
}
