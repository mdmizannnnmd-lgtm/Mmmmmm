package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object FullAmbientMasterPanels {
    fun build(ctx: Context, root: LinearLayout, b: FullAmbientMasterBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFFE1BEE7.toInt()
        p.title("FULL AMBIENT MASTER · SKIN · Hz · ASTRO · ATOMSPARE · MOVE/SPD/WAV/PITCH/SPIKE", c)
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Full body skin ON", b.skinFullOn) { b.skinFullOn = it }
        p.switch("Sound Hz ON", b.hzOn) { b.hzOn = it }
        p.seek("Hz threshold", 1f, 20000f, b.hzThr) { b.hzThr = it }
        p.seek("Hz level", 0f, 1.5f, b.hzLv) { b.hzLv = it }
        p.switch("Astro ON", b.astroOn) { b.astroOn = it }
        p.switch("Move ON", b.moveOn) { b.moveOn = it }
        p.seek("Move thr / lv", 0.05f, 0.98f, b.moveThr) { b.moveThr = it }
        p.seek("Move level", 0f, 1.5f, b.moveLv) { b.moveLv = it }
        p.switch("Speed ON", b.speedOn) { b.speedOn = it }
        p.seek("Speed thr", 0.05f, 0.98f, b.speedThr) { b.speedThr = it }
        p.seek("Speed level", 0f, 1.5f, b.speedLv) { b.speedLv = it }
        p.switch("Waves ON", b.waveOn) { b.waveOn = it }
        p.seek("Wave thr", 0.05f, 0.98f, b.waveThr) { b.waveThr = it }
        p.seek("Wave level", 0f, 1.5f, b.waveLv) { b.waveLv = it }
        p.switch("Pitch ON", b.pitchOn) { b.pitchOn = it }
        p.seek("Pitch thr", 0.05f, 0.98f, b.pitchThr) { b.pitchThr = it }
        p.seek("Pitch level", 0f, 1.5f, b.pitchLv) { b.pitchLv = it }
        p.switch("Spikes ON", b.spikeOn) { b.spikeOn = it }
        p.seek("Spike thr", 0.05f, 0.98f, b.spikeThr) { b.spikeThr = it }
        p.seek("Spike level", 0f, 1.5f, b.spikeLv) { b.spikeLv = it }
        val st = p.status("MASTER —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 200) }
        })
    }
}
