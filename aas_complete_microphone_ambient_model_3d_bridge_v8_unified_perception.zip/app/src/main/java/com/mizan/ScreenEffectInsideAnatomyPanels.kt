package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object ScreenEffectInsideAnatomyPanels {
    fun build(ctx: Context, root: LinearLayout, b: ScreenEffectInsideAnatomyBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF42A5F5.toInt()
        p.title("SCREEN ALL-FX TRACK · INSIDE BAD Hz · CELL/NEURO/GLAND REPAIR · 3D", c)
        p.note("Screen effect protect · inside cell/organ/neuro/chem/hormone/gland · eyes skin water · 3D layers")
        p.switch("ON", b.enabled) { b.enabled = it }
        p.switch("RAW", b.rawComplete) { b.rawComplete = it }
        p.switch("Screen track", b.screenTrackOn) { b.screenTrackOn = it }
        p.seek("Screen track thr", 0.05f, 0.9f, b.screenTrackThr) { b.screenTrackThr = it }
        p.seek("Inside bad thr", 0.15f, 0.95f, b.badInsideThr) { b.badInsideThr = it }
        val st = p.status("SCREEN-INSIDE —", c)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() {
                st.text = b.status
                Handler(Looper.getMainLooper()).postDelayed(this, 300)
            }
        })
    }
}
