package com.mizan

/** Small thread-safe state bus for additive perception/animation integrations. */
class EntityStateBus {
    data class EntityState(
        val id: String = "primary",
        val visible: Boolean = false,
        val confidence: Float = 0f,
        val x: Float = 0.5f,
        val y: Float = 0.5f,
        val attention: Float = 0f,
        val audioActivity: Float = 0f,
        val updatedAtMs: Long = 0L
    )
    @Volatile private var state = EntityState()
    fun publish(next: EntityState) { state = next.copy(confidence=next.confidence.coerceIn(0f,1f), x=next.x.coerceIn(0f,1f), y=next.y.coerceIn(0f,1f), attention=next.attention.coerceIn(0f,1f), audioActivity=next.audioActivity.coerceIn(0f,1f)) }
    fun current(): EntityState = state
    fun clear(nowMs: Long = System.currentTimeMillis()) { state = EntityState(updatedAtMs=nowMs) }
}
