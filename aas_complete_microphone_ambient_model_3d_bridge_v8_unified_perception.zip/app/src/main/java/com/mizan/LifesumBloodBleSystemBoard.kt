package com.mizan

/**
 * Lifesum-style body system + blood protection/repair + BLE/chemical +
 * bad-frequency → regeneration frequency + enemy BIA electrodes protect +
 * scale measurement protect + water track + BLE colour protect.
 * Metrics inspired by BLE scale / BIA research (weight, water%, impedance band).
 * Symbolic thresholds — not medical device. RAW COMPLETE.
 */
class LifesumBloodBleSystemBoard {
    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // Lifesum-style metrics (symbolic 0..1 or physical hints)
    @Volatile var weightKg = 70f
    @Volatile var bodyWaterPct = 55f
    @Volatile var bodyFatPct = 20f
    @Volatile var muscleHint = 0.5f
    @Volatile var impedanceOhm = 500f      // valid BIA ~150–1200 Ω
    @Volatile var metricsLive = 0f

    // Blood threshold / protect / repair
    @Volatile var bloodThr = 0.28f
    @Volatile var bloodLv = 0.92f
    @Volatile var bloodProtectOn = true
    @Volatile var bloodProtectOut = 0f
    @Volatile var bloodRepairOn = true
    @Volatile var bloodRepairHz = 7.83f
    @Volatile var bloodRepairOut = 0f
    @Volatile var bloodFull = 0f

    // Bad frequency → regeneration (BLE mix)
    @Volatile var badFreqThr = 0.55f
    @Volatile var badFreqOut = 0f
    @Volatile var regenHz = 10f
    @Volatile var bleRegenOn = true
    @Volatile var bleRegenOut = 0f
    @Volatile var bodyChangeProtect = 0f

    // Enemy BLE electrodes (BIA foot/hand pads) effect protection
    @Volatile var electrodeProtectOn = true
    @Volatile var electrodeThr = 0.24f
    @Volatile var electrodeProtectOut = 0f

    // Scale measurement protection
    @Volatile var scaleMeasProtectOn = true
    @Volatile var scaleMeasThr = 0.20f
    @Volatile var scaleMeasProtectOut = 0f

    // Water tracking
    @Volatile var waterTrackPct = 55f
    @Volatile var waterTrackOut = 0f

    // BLE colour protection (display/LED colour abuse symbolic)
    @Volatile var bleColourProtectOn = true
    @Volatile var bleColourThr = 0.26f
    @Volatile var bleColourProtectOut = 0f

    // Chemical
    @Volatile var chemTrackOut = 0f

    @Volatile var systemFull = 0f
    @Volatile var status = "LIFESUM-BLOOD-BLE idle"

    private fun lane(on: Boolean, e: Float, thr: Float, lv: Float): Float {
        if (!on && !rawComplete) return 0f
        val x = e.coerceIn(0f, 1.5f)
        if (rawComplete) return (x * lv).coerceIn(0f, 1f)
        return if (x >= thr) ((x - thr) / (1.2f - thr).coerceAtLeast(0.05f) * lv).coerceIn(0f, 1f) else 0f
    }

    /**
     * @param mic energy
     * @param blePresence from BleScaleLibrary
     * @param enemyBle enemy scale/electrode energy
     * @param water body water ambient
     * @param chem chemical track
     * @param bodyHz normalised body frequency 0..1 (bad if high)
     * @param regenIn existing regen board out
     */
    fun tick(
        mic: Float,
        blePresence: Float,
        enemyBle: Float,
        water: Float,
        chem: Float,
        bodyHz: Float,
        regenIn: Float
    ) {
        if (!enabled) { status = "LIFESUM-BLOOD-BLE OFF"; return }
        val e = maxOf(mic * 0.5f, blePresence).coerceIn(0f, 1.5f)

        // Metrics
        if (blePresence > 0.1f) {
            weightKg = (50f + blePresence * 50f).coerceIn(40f, 150f)
            // Water ~55–60% adult; shift with water ambient
            bodyWaterPct = (52f + water * 12f).coerceIn(45f, 70f)
            waterTrackPct = bodyWaterPct
            // Impedance valid band 150–1200; mid = healthier symbolic
            impedanceOhm = (400f + (1f - blePresence) * 400f).coerceIn(150f, 1200f)
            bodyFatPct = (12f + (1f - muscleHint) * 25f).coerceIn(5f, 45f)
            muscleHint = (0.3f + blePresence * 0.5f).coerceIn(0f, 1f)
        }
        metricsLive = lane(true, e, 0.12f, 0.9f)

        // Blood protect / repair
        bloodProtectOut = lane(bloodProtectOn, maxOf(e, mic * 0.6f), bloodThr, bloodLv)
        val repairProx = 1f - (kotlin.math.abs(bodyHz * 40f - bloodRepairHz) / 40f).coerceIn(0f, 1f)
        bloodRepairOut = lane(bloodRepairOn, maxOf(repairProx * e, regenIn * 0.7f), 0.2f, bloodLv)
        bloodFull = maxOf(bloodProtectOut, bloodRepairOut)

        // Bad frequency → regen via BLE
        badFreqOut = if (bodyHz >= badFreqThr) ((bodyHz - badFreqThr) / (1f - badFreqThr).coerceAtLeast(0.05f)).coerceIn(0f, 1f) else 0f
        bleRegenOut = lane(bleRegenOn, maxOf(blePresence, regenIn, (1f - badFreqOut) * e), 0.18f, 0.9f)
        bodyChangeProtect = lane(true, badFreqOut * 0.8f + bleRegenOut * 0.5f, 0.15f, 0.95f)

        // Enemy electrodes (BIA pads)
        electrodeProtectOut = lane(electrodeProtectOn, enemyBle * 1.05f + mic * 0.3f, electrodeThr, 0.95f)
        // Scale measurement protect
        scaleMeasProtectOut = lane(scaleMeasProtectOn, maxOf(enemyBle, blePresence * 0.4f), scaleMeasThr, 0.93f)
        // Water track
        waterTrackOut = lane(true, water * 0.9f + (bodyWaterPct / 70f) * 0.5f, 0.15f, 0.9f)
        // BLE colour protect
        bleColourProtectOut = lane(bleColourProtectOn, enemyBle * 0.8f + mic * 0.4f, bleColourThr, 0.92f)
        // Chemical
        chemTrackOut = lane(true, chem, 0.2f, 0.88f)

        systemFull = maxOf(
            metricsLive, bloodFull, bleRegenOut, bodyChangeProtect,
            electrodeProtectOut, scaleMeasProtectOut, waterTrackOut, bleColourProtectOut
        )
        if (rawComplete) systemFull = maxOf(systemFull, 0.28f + e * 0.35f)

        status =
            "LIFESUM w=${"%.0f".format(weightKg)}kg H2O=${"%.0f".format(bodyWaterPct)}% Z=${impedanceOhm.toInt()}Ω · " +
            "blood P/R=${(bloodProtectOut*100).toInt()}/${(bloodRepairOut*100).toInt()}% · " +
            "bad→regen=${(badFreqOut*100).toInt()}→${(bleRegenOut*100).toInt()}% · " +
            "electrode/scale/colour=${(electrodeProtectOut*100).toInt()}/${(scaleMeasProtectOut*100).toInt()}/${(bleColourProtectOut*100).toInt()}%" +
            if (rawComplete) " · RAW" else ""
    }

    fun apply(sb: SoundBankGuard?, v: VisualShieldView?) {
        if (!enabled || systemFull < 0.02f) return
        val vv = v ?: return
        try {
            // Blood / regen feed existing boards
            vv.bodyFreqRegen.regenOut = maxOf(vv.bodyFreqRegen.regenOut, bleRegenOut)
            vv.bodyFreqRegen.repairOut = maxOf(vv.bodyFreqRegen.repairOut, bloodRepairOut)
            vv.waterFullBody.waterFull = maxOf(vv.waterFullBody.waterFull, waterTrackOut)
            vv.waterWarfareAmbient.pureSelfOut = maxOf(vv.waterWarfareAmbient.pureSelfOut, waterTrackOut)
            vv.caMgProtectChem.chemOut = maxOf(vv.caMgProtectChem.chemOut, chemTrackOut)
            vv.completeAtomProtect.protectOut = maxOf(vv.completeAtomProtect.protectOut, bloodProtectOut * 0.6f, bodyChangeProtect * 0.5f)
            // Enemy electrode / scale / colour abuse damp
            val dampE = (1f - electrodeProtectOut * 0.9f).coerceIn(0.05f, 1f)
            val dampS = (1f - scaleMeasProtectOut * 0.9f).coerceIn(0.05f, 1f)
            vv.enemyBleScaleTrack.enemyScaleOut *= dampE * dampS
            vv.bleEnemyAmbientBlock.bleAmbientBlockOut =
                maxOf(vv.bleEnemyAmbientBlock.bleAmbientBlockOut, electrodeProtectOut, bleColourProtectOut)
            vv.fullProtectionBle.masterProtectOut =
                maxOf(vv.fullProtectionBle.masterProtectOut, systemFull * 0.55f)
            vv.mgBleScaleWatt.weightKg = weightKg
            vv.mgBleScaleWatt.mgOut = maxOf(vv.mgBleScaleWatt.mgOut, metricsLive * 0.5f)
        } catch (_: Throwable) {}
        try {
            if (sb != null && (electrodeProtectOut > 0.05f || bleColourProtectOut > 0.05f)) {
                val d = (1f - maxOf(electrodeProtectOut, bleColourProtectOut) * 0.7f).coerceIn(0.1f, 1f)
                sb.enemyBodyOut *= d
                sb.micEnemyOut *= d
            }
        } catch (_: Throwable) {}
    }
}
