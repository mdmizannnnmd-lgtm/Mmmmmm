package com.mizan

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout

object BodyChemBrainAmbientPanels {
    fun build(ctx: Context, root: LinearLayout, b: BodyChemBrainAmbientBoard) {
        val p = PanelBuilder(ctx, root)
        val c = 0xFF81D4FA.toInt()
        p.title("BODY CHEM · CHON · MINERALS · BIOMOLECULES · BRAIN MENINGES · CSF", c)
        p.note("Symbolic only. Water protein lipid · Ca Fe · ATP · Dura Arachnoid Pia · lobes · brainstem")
        p.switch("Master ON", b.enabled) { b.enabled = it }
        p.switch("RAW COMPLETE", b.rawComplete) { b.rawComplete = it }
        p.switch("Chemical composition ON", b.chemOn) { b.chemOn = it }
        p.switch("Brain / meninges ON", b.brainOn) { b.brainOn = it }
        p.seek("Shared thr", 0.05f, 0.98f, b.thr) { b.thr = it }
        p.seek("Shared level", 0f, 1.5f, b.lv) { b.lv = it }
        val st = p.status("CHEM·BRAIN —", c)
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() { st.text = b.status; h.postDelayed(this, 250) }
        })
    }
}
