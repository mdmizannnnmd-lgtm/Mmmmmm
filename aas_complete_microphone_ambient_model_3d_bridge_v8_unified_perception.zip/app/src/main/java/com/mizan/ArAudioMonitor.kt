package com.mizan

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Read-only microphone meter for AR visual effects. It never modifies or plays audio.
 * Sound level is a normalized dBFS value; atmosphere is the spectral room-tone share.
 */
class ArAudioMonitor(
    private val onLevels: (soundLevel: Float, atmosphere: Float) -> Unit,
    private val sharedRawMic: Boolean = true
) {
    @Volatile private var running = false
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var worker: Thread? = null
    @Volatile private var rawSubscription: AutoCloseable? = null

    @Synchronized
    fun start(): Boolean {
        if (running) return if (sharedRawMic) rawSubscription != null else recorder?.recordingState == AudioRecord.RECORDSTATE_RECORDING

        // RAW COMPLETE path: consume the exact frame already captured by AudioProcessor.
        // The legacy standalone AudioRecord path remains below for callers that explicitly
        // construct this monitor with sharedRawMic=false.
        if (sharedRawMic) {
            rawSubscription = RawMicBus.subscribe { frame ->
                if (!running) return@subscribe
                val level = ((frame.dbfs + 75f) / 60f).coerceIn(0f, 1f)
                val atmosphere = (frame.centroidHz / (frame.sampleRate / 2f)).coerceIn(0f, 1f)
                onLevels(level, atmosphere)
            }
            running = true
            return true
        }
        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) return false

        val active = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuffer * 2, SAMPLE_COUNT * 4)
            )
        } catch (error: Exception) {
            Log.w(TAG, "Could not open microphone meter", error)
            return false
        }
        if (active.state != AudioRecord.STATE_INITIALIZED) {
            active.release()
            return false
        }
        try {
            active.startRecording()
        } catch (error: Exception) {
            Log.w(TAG, "Could not start microphone meter", error)
            active.release()
            return false
        }

        recorder = active
        running = true
        worker = Thread({ readLoop(active) }, "ArAudioMonitor").apply {
            isDaemon = true
            start()
        }
        return true
    }

    private fun readLoop(active: AudioRecord) {
        val samples = ShortArray(SAMPLE_COUNT)
        val analyzer = LiveSpectrumAnalyzer(SAMPLE_RATE)
        while (running && active.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
            val read = try {
                active.read(samples, 0, samples.size)
            } catch (error: Exception) {
                if (running) Log.w(TAG, "Microphone meter read failed", error)
                break
            }
            if (read <= 0) {
                if (!running || active.recordingState != AudioRecord.RECORDSTATE_RECORDING) break
                try {
                    Thread.sleep(8)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    break
                }
                continue
            }

            var sumSquares = 0.0
            for (i in 0 until read) {
                val sample = samples[i].toDouble()
                sumSquares += sample * sample
            }
            val rms = sqrt(sumSquares / read) / 32768.0
            val dbfs = 20.0 * log10(rms.coerceAtLeast(1e-5))
            // Map the useful phone-mic range (-75 to -15 dBFS) into a stable 0..1 control value.
            val level = ((dbfs + 75.0) / 60.0).toFloat().coerceIn(0f, 1f)
            analyzer.process(samples, read)
            val atmosphere = (analyzer.atmoPct / 100f).coerceIn(0f, 1f)
            onLevels(level, atmosphere)
        }
    }

    @Synchronized
    fun stop() {
        running = false
        try { rawSubscription?.close() } catch (_: Exception) {}
        rawSubscription = null
        val active = recorder
        recorder = null
        try {
            if (active?.recordingState == AudioRecord.RECORDSTATE_RECORDING) active.stop()
        } catch (_: Exception) {
        }
        try {
            active?.release()
        } catch (_: Exception) {
        }
        val oldWorker = worker
        worker = null
        if (oldWorker != null && oldWorker !== Thread.currentThread()) {
            try {
                oldWorker.join(250)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
    }

    companion object {
        private const val TAG = "ArAudioMonitor"
        private const val SAMPLE_RATE = 16000
        private const val SAMPLE_COUNT = 1024
    }
}
