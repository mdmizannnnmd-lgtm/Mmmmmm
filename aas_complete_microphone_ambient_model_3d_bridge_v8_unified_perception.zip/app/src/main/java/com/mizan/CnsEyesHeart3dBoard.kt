package com.mizan

/**
 * CNS ambient (threshold/level) fully linked with eyes · full 3D eyes · heart 3D.
 * Additive path driving VisualShield regions + Soft3D eye/heart intensity.
 */
class CnsEyesHeart3dBoard {

    @Volatile var enabled = true
    @Volatile var rawComplete = true

    // CNS ambient
    @Volatile var cnsOn = true
    @Volatile var cnsThr = 0.30f
    @Volatile var cnsLv = 0.70f
    @Volatile var cnsOut = 0f
    @Volatile var cnsHit = false
    // L/R CNS ambient (hemisphere-linked)
    @Volatile var cnsLOn = true
    @Volatile var cnsROn = true
    @Volatile var cnsLThr = 0.30f
    @Volatile var cnsLLv = 0.70f
    @Volatile var cnsRThr = 0.30f
    @Volatile var cnsRLv = 0.70f
    @Volatile var cnsLOut = 0f
    @Volatile var cnsROut = 0f
    // Full model head (group, not single landmark)
    @Volatile var modelHeadOn = true
    @Volatile var modelHeadThr = 0.28f
    @Volatile var modelHeadLv = 0.75f
    @Volatile var modelHeadOut = 0f
    /** Link strength: CNS → eyes (0..1.5) */
    @Volatile var cnsToEyesLink = 1.0f
    @Volatile var cnsToHeartLink = 0.85f

    // 3D Eyes (full)
    @Volatile var eyes3dOn = true
    @Volatile var eyeDetailOn = true
    @Volatile var eyeLOn = true
    @Volatile var eyeROn = true
    @Volatile var eyeLThr = 0.28f
    @Volatile var eyeLLv = 0.75f
    @Volatile var eyeRThr = 0.28f
    @Volatile var eyeRLv = 0.75f
    @Volatile var eyeLOut = 0f
    @Volatile var eyeROut = 0f
    @Volatile var optical3dOn = true
    @Volatile var gazeFromCns = true
    @Volatile var eyeBright = 0.55f
    @Volatile var eyeContrast = 0.55f
    @Volatile var eyeDepth3d = 0.80f

    /** Complete eye structure outs (not only iris/pupil) — anatomy-accurate channels per side. */
    class EyeSideOut {
        @Volatile var total = 0f
        @Volatile var sclera = 0f      // fibrous outer white
        @Volatile var cornea = 0f      // clear anterior focus
        @Volatile var conjunctiva = 0f
        @Volatile var iris = 0f
        @Volatile var pupil = 0f
        @Volatile var lens = 0f
        @Volatile var aqueous = 0f     // anterior chamber fluid
        @Volatile var vitreous = 0f    // posterior gel
        @Volatile var retina = 0f
        @Volatile var macula = 0f
        @Volatile var choroid = 0f
        @Volatile var ciliary = 0f
        @Volatile var opticNerve = 0f
        fun fill(base: Float, sideBoost: Float = 1f) {
            val b = (base * sideBoost).coerceIn(0f, 1f)
            total = b
            sclera = b * 0.88f
            cornea = b * 0.95f
            conjunctiva = b * 0.70f
            iris = b * 0.92f
            pupil = b * 0.85f
            lens = b * 0.90f
            aqueous = b * 0.75f
            vitreous = b * 0.80f
            retina = b * 0.93f
            macula = b * 0.78f
            choroid = b * 0.72f
            ciliary = b * 0.68f
            opticNerve = b * 0.88f
        }
    }
    val leftEyeFull = EyeSideOut()
    val rightEyeFull = EyeSideOut()

    // Heart 3D
    @Volatile var heart3dOn = true
    @Volatile var heartThr = 0.30f
    @Volatile var heartLv = 0.75f
    @Volatile var heartOut = 0f
    @Volatile var heartBeatFromCns = true
    @Volatile var heartDepth3d = 0.85f

    @Volatile var status = "CNS·EYES·HEART 3D idle"

    private fun lane(on: Boolean, thr: Float, lv: Float, e: Float, drive: Float): Float {
        if (!on && !rawComplete) return 0f
        if (rawComplete) return (e * lv * drive).coerceIn(0f, 1f)
        val t = (thr * drive).coerceIn(0.05f, 1f)
        return if (e >= t) (((e - t) / (1f - t).coerceAtLeast(0.05f)) * lv * drive).coerceIn(0f, 1f) else 0f
    }

    fun tick(micEnergy: Float, modelDrive: Float = 1f) {
        if (!enabled) {
            cnsOut = 0f; eyeLOut = 0f; eyeROut = 0f; heartOut = 0f
            status = "CNS·EYES·HEART 3D OFF"
            return
        }
        val e = micEnergy.coerceIn(0f, 1f)
        val drive = 0.25f + 0.75f * modelDrive.coerceIn(0f, 1f)

        cnsOut = if (cnsOn) lane(true, cnsThr, cnsLv, e * 1.06f, drive) else 0f
        cnsLOut = if (cnsOn && cnsLOn) lane(true, cnsLThr, cnsLLv, e * 1.05f, drive) else 0f
        cnsROut = if (cnsOn && cnsROn) lane(true, cnsRThr, cnsRLv, e * 1.04f, drive) else 0f
        cnsOut = maxOf(cnsOut, cnsLOut, cnsROut)
        cnsHit = cnsOut > 0.02f
        modelHeadOut = if (modelHeadOn) lane(true, modelHeadThr, modelHeadLv, maxOf(e, cnsOut) * 1.08f, drive) else 0f
        val linkE = (cnsOut * cnsToEyesLink.coerceIn(0f, 1.5f)).coerceIn(0f, 1f)

        // Eyes fully driven by mic + CNS link
        val eyeE = if (eyes3dOn) maxOf(e, linkE) else e
        eyeLOut = if (eyeLOn && eyes3dOn) lane(true, eyeLThr, eyeLLv, eyeE * 1.02f, drive) else 0f
        eyeROut = if (eyeROn && eyes3dOn) lane(true, eyeRThr, eyeRLv, eyeE, drive) else 0f
        if (optical3dOn) {
            eyeLOut = maxOf(eyeLOut, cnsOut * 0.55f)
            eyeROut = maxOf(eyeROut, cnsOut * 0.55f)
        }
        leftEyeFull.fill(eyeLOut, 1.02f)
        rightEyeFull.fill(eyeROut, 1.0f)
        // optic nerve stronger from CNS
        if (optical3dOn) {
            leftEyeFull.opticNerve = maxOf(leftEyeFull.opticNerve, cnsOut * 0.9f)
            rightEyeFull.opticNerve = maxOf(rightEyeFull.opticNerve, cnsOut * 0.9f)
        }

        val heartE = if (heartBeatFromCns) maxOf(e, cnsOut * cnsToHeartLink.coerceIn(0f, 1.5f)) else e
        heartOut = if (heart3dOn) lane(true, heartThr, heartLv, heartE * 1.04f, drive) else 0f

        status =
            "CNS L${(cnsLOut*100).toInt()} R${(cnsROut*100).toInt()} (${(cnsOut*100).toInt()}%)${if (cnsHit) "*" else ""} head=${(modelHeadOut*100).toInt()}% → EYES " +
            "L ${ (eyeLOut*100).toInt()}% [cor${(leftEyeFull.cornea*100).toInt()} ir${(leftEyeFull.iris*100).toInt()} pu${(leftEyeFull.pupil*100).toInt()} le${(leftEyeFull.lens*100).toInt()} re${(leftEyeFull.retina*100).toInt()} on${(leftEyeFull.opticNerve*100).toInt()}] " +
            "R ${(eyeROut*100).toInt()}% [cor${(rightEyeFull.cornea*100).toInt()} ir${(rightEyeFull.iris*100).toInt()} pu${(rightEyeFull.pupil*100).toInt()} le${(rightEyeFull.lens*100).toInt()} re${(rightEyeFull.retina*100).toInt()} on${(rightEyeFull.opticNerve*100).toInt()}] · " +
            "HEART3D ${(heartOut*100).toInt()}%" + if (rawComplete) " · RAW" else ""
    }

    /** Push into VisualShield region ambients (3D body). */
    fun applyToShield(v: VisualShieldView) {
        if (!enabled) return
        // CNS couples into head/brain atmosphere
        v.skinHead.ambient = maxOf(v.skinHead.ambient, cnsOut * 0.8f, modelHeadOut)
        // L/R CNS bias into L/R eyes
        if (cnsLOut > 0f) {
            v.eyeL.ambient = maxOf(v.eyeL.ambient, cnsLOut)
            eyeLOut = maxOf(eyeLOut, cnsLOut * 0.9f)
        }
        if (cnsROut > 0f) {
            v.eyeR.ambient = maxOf(v.eyeR.ambient, cnsROut)
            eyeROut = maxOf(eyeROut, cnsROut * 0.9f)
        }
        // Full 3D eyes
        if (eyes3dOn) {
            v.eyes.ambient = maxOf(v.eyes.ambient, maxOf(eyeLOut, eyeROut))
            v.eyeL.ambient = maxOf(v.eyeL.ambient, eyeLOut)
            v.eyeR.ambient = maxOf(v.eyeR.ambient, eyeROut)
            v.eyeLIn.ambient = maxOf(v.eyeLIn.ambient, eyeLOut * 0.95f)
            v.eyeRIn.ambient = maxOf(v.eyeRIn.ambient, eyeROut * 0.95f)
            v.eyeLOut.ambient = maxOf(v.eyeLOut.ambient, eyeLOut)
            v.eyeROut.ambient = maxOf(v.eyeROut.ambient, eyeROut)
            v.eyeTuning.brightness = (eyeBright * 2f - 1f).coerceIn(-1f, 1f)
            v.eyeTuning.contrast = (0.5f + eyeContrast).coerceIn(0f, 2f)
            v.eyeTuning.brightnessOn = true
            v.eyeTuning.contrastOn = true
            v.ringBoard.eyeDetailOn = eyeDetailOn
            if (gazeFromCns && cnsOut > 0.05f) {
                // subtle gaze bias from CNS energy
                v.eyeTuning.brightness = (v.eyeTuning.brightness + cnsOut * 0.15f).coerceIn(-1f, 1f)
            }
        }
        // Heart 3D region
        if (heart3dOn) {
            v.heart.ambient = maxOf(v.heart.ambient, heartOut)
            v.heart.move = maxOf(v.heart.move, heartOut * 0.8f)
            v.heart.speed = maxOf(v.heart.speed, heartOut * 0.7f)
        }
        // Final tabs CNS/heart mirror
        v.finalTabs.cnsOn = cnsOn
        v.finalTabs.cnsThr = cnsThr
        v.finalTabs.cnsLv = cnsLv
        v.finalTabs.heartOn = heart3dOn
        v.finalTabs.heartThr = heartThr
        v.finalTabs.heartLv = heartLv
    }
}
