#include <jni.h>
#include <android/log.h>
#include <cmath>
#include <vector>
#include <algorithm>
#include <numeric>

#define LOG_TAG "UltraShieldNative"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static float globalAtmosphere = 0.45f;
static float globalThreat = 0.0f;
static float globalEnergy = 0.0f;
static float globalRipple = 0.0f;
static float globalEchoShield = 0.0f;
static float globalTexture = 0.5f;
static float globalStability = 1.0f;

static std::vector<float> rmsHistory(128, 0.0f);

static float clampf(float v, float minV, float maxV) {
    return std::max(minV, std::min(v, maxV));
}

static float smoothstep(float edge0, float edge1, float x) {
    x = clampf((x - edge0) / (edge1 - edge0), 0.0f, 1.0f);
    return x * x * (3.0f - 2.0f * x);
}

static float computeWave(float phase, float speed, float intensity) {
    return sinf(phase * speed) * intensity;
}

static float computeRipple(float phase, float rms) {
    return sinf(phase * 0.07f + rms * 8.0f) * 0.5f + 0.5f;
}

static float computeShieldEnergy(float rms, float db) {
    float energy =
            (rms * 3.2f) +
            ((db + 120.0f) / 120.0f);

    return clampf(energy, 0.0f, 1.0f);
}

static float computeThreatLevel(float rms, float db) {

    float threat = 0.0f;

    if (rms > 0.12f)
        threat += 0.25f;

    if (rms > 0.18f)
        threat += 0.25f;

    if (db > -32.0f)
        threat += 0.25f;

    if (db > -18.0f)
        threat += 0.25f;

    return clampf(threat, 0.0f, 1.0f);
}

static void updateHistory(float rms) {

    rmsHistory.erase(rmsHistory.begin());
    rmsHistory.push_back(rms);

    float avg =
            std::accumulate(
                    rmsHistory.begin(),
                    rmsHistory.end(),
                    0.0f
            ) / rmsHistory.size();

    globalAtmosphere =
            (globalAtmosphere * 0.92f) +
            (avg * 0.08f);

    globalAtmosphere =
            clampf(globalAtmosphere, 0.1f, 1.0f);
}

extern "C" {

JNIEXPORT void JNICALL
Java_com_mizan_VisualShieldView_nativeInitializeShield(
        JNIEnv *env,
        jobject thiz
) {

    globalAtmosphere = 0.45f;
    globalThreat = 0.0f;
    globalEnergy = 0.0f;
    globalRipple = 0.0f;
    globalEchoShield = 0.0f;
    globalTexture = 0.5f;
    globalStability = 1.0f;

    LOGI("Ultra Shield Initialized");
}

JNIEXPORT void JNICALL
Java_com_mizan_VisualShieldView_nativeDraw(
        JNIEnv *env,
        jobject thiz,
        jint width,
        jint height,
        jfloat phase,
        jfloat eyeAmbient,
        jfloat hardwareIntensity,
        jfloat lrFilter,
        jfloat textureShift,
        jfloat feedback,
        jfloat ripple,
        jfloat spike
) {

    float cx =
            (width * 0.5f);

    float cy =
            (height * 0.5f);

    float waveX =
            computeWave(
                    phase,
                    0.04f,
                    90.0f * hardwareIntensity
            );

    float waveY =
            computeWave(
                    phase,
                    0.03f,
                    60.0f * hardwareIntensity
            );

    float rippleValue =
            computeRipple(
                    phase,
                    globalAtmosphere
            );

    globalRipple =
            (globalRipple * 0.88f) +
            (rippleValue * 0.12f);

    cx += waveX;
    cy += waveY;

    cx +=
            (lrFilter - 0.5f) *
            180.0f *
            hardwareIntensity;

    cy +=
            textureShift *
            45.0f;

    float radius =
            180.0f *
            eyeAmbient *
            hardwareIntensity;

    radius +=
            globalRipple *
            45.0f;

    radius +=
            spike *
            120.0f;

    float energyRadius =
            radius *
            (1.0f + globalEnergy);

    float texture =
            textureShift *
            feedback *
            ripple;

    globalTexture =
            (globalTexture * 0.94f) +
            (texture * 0.06f);

    LOGI(
            "DRAW | cx=%.2f cy=%.2f radius=%.2f energy=%.2f ripple=%.2f texture=%.2f",
            cx,
            cy,
            energyRadius,
            globalEnergy,
            globalRipple,
            globalTexture
    );
}

JNIEXPORT jfloat JNICALL
Java_com_mizan_VisualShieldView_nativeComputeAtmosphere(
        JNIEnv *env,
        jobject thiz,
        jfloat rms,
        jfloat db,
        jfloat threshold
) {

    updateHistory(rms);

    float energy =
            computeShieldEnergy(
                    rms,
                    db
            );

    globalEnergy =
            (globalEnergy * 0.90f) +
            (energy * 0.10f);

    float atmosphere =
            globalAtmosphere +
            (globalEnergy * 0.4f);

    if (db > threshold) {
        atmosphere += 0.22f;
    }

    atmosphere =
            clampf(
                    atmosphere,
                    0.1f,
                    1.0f
            );

    return atmosphere;
}

JNIEXPORT jint JNICALL
Java_com_mizan_VisualShieldView_nativeComputeThreat(
        JNIEnv *env,
        jobject thiz,
        jfloat rms,
        jfloat db,
        jfloat spikeLevel
) {

    float threat =
            computeThreatLevel(
                    rms,
                    db
            );

    threat +=
            spikeLevel * 0.35f;

    threat =
            clampf(
                    threat,
                    0.0f,
                    1.0f
            );

    globalThreat =
            (globalThreat * 0.85f) +
            (threat * 0.15f);

    if (globalThreat > 0.85f)
        return 4;

    if (globalThreat > 0.65f)
        return 3;

    if (globalThreat > 0.45f)
        return 2;

    if (globalThreat > 0.20f)
        return 1;

    return 0;
}

JNIEXPORT jfloat JNICALL
Java_com_mizan_VisualShieldView_nativeComputeEchoShield(
        JNIEnv *env,
        jobject thiz,
        jfloat echo,
        jfloat feedback,
        jfloat decay
) {

    float shield =
            (echo * 0.45f) +
            (feedback * 0.35f) +
            (decay * 0.20f);

    globalEchoShield =
            (globalEchoShield * 0.90f) +
            (shield * 0.10f);

    return clampf(
            globalEchoShield,
            0.0f,
            1.0f
    );
}

JNIEXPORT jfloat JNICALL
Java_com_mizan_VisualShieldView_nativeComputeTexture(
        JNIEnv *env,
        jobject thiz,
        jfloat left,
        jfloat right,
        jfloat shift
) {

    float texture =
            fabs(left - right) *
            shift;

    globalTexture =
            (globalTexture * 0.92f) +
            (texture * 0.08f);

    return clampf(
            globalTexture,
            0.0f,
            1.0f
    );
}

JNIEXPORT void JNICALL
Java_com_mizan_VisualShieldView_nativeReset(
        JNIEnv *env,
        jobject thiz
) {

    globalAtmosphere = 0.45f;
    globalThreat = 0.0f;
    globalEnergy = 0.0f;
    globalRipple = 0.0f;
    globalEchoShield = 0.0f;
    globalTexture = 0.5f;
    globalStability = 1.0f;

    std::fill(
            rmsHistory.begin(),
            rmsHistory.end(),
            0.0f
    );

    LOGI("Shield Reset Complete");
}

}