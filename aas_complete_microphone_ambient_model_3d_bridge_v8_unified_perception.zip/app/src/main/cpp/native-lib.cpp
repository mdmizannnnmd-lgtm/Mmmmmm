#include <jni.h>
#include <android/log.h>
#include <cmath>

#define LOG_TAG "NativeShield"

#define LOGI(...) \
__android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" {

JNIEXPORT void JNICALL
Java_com_mizan_VisualShieldView_nativeDraw(
        JNIEnv* env,
        jobject thiz,
        jint width,
        jint height,
        jfloat phase,
        jfloat ambientLevel,
        jfloat hardwareIntensity
) {

    float energy =
            sin(phase * 0.05f) *
            ambientLevel *
            hardwareIntensity;

    LOGI(
            "Render W:%d H:%d Phase:%f Energy:%f",
            width,
            height,
            phase,
            energy
    );
}

}