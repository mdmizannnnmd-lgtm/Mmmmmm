package com.mizan

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SoundBankGuardAudioChannelsTest {
    @Test
    fun sharpAndBurstUseIndependentThresholdsOutsideRawMode() {
        val bank = SoundBankGuard().apply {
            sharpOn = true
            sharpThr = 0.60f
            sharpLv = 1f
            burstOn = true
            burstThr = 0.80f
            burstLv = 1f
        }

        bank.feedAudioAnalysis(0.8f, 1000f, 1000f, -60.0, -60.0)
        bank.feedAudioAnalysis(0.8f, 9000f, 9000f, -10.0, -10.0)
        bank.tick(energy = 0.8f, db = -10.0, peak = 0.8f)

        assertTrue(bank.sharpActive)
        assertTrue(bank.burstActive)
        assertTrue(bank.sharpOut <= 0.45f)
        assertTrue(bank.burstOut <= 0.45f)
    }

    @Test
    fun rawModeBypassesChannelThresholdsButKeepsTheVisualCap() {
        val bank = SoundBankGuard().apply {
            rawComplete = true
            sharpOn = true
            sharpThr = 0.99f
            sharpLv = 1f
            burstOn = true
            burstThr = 0.99f
            burstLv = 1f
        }

        bank.feedAudioAnalysis(0.8f, 9000f, 9000f, -60.0, -60.0)
        bank.feedAudioAnalysis(0.8f, 9000f, 9000f, -8.0, -8.0)
        bank.tick(energy = 0.8f, db = -8.0, peak = 0.8f)

        assertTrue(bank.sharpActive)
        assertTrue(bank.burstActive)
        assertTrue(bank.sharpOut > 0f)
        assertTrue(bank.burstOut > 0f)
        assertTrue(bank.sharpOut <= 0.45f)
        assertTrue(bank.burstOut <= 0.45f)
    }

    @Test
    fun disabledChannelsStayQuiet() {
        val bank = SoundBankGuard()
        bank.feedAudioAnalysis(1f, 9000f, 9000f, -5.0, -5.0)
        bank.tick(energy = 1f, db = -5.0, peak = 1f)

        assertFalse(bank.sharpActive)
        assertFalse(bank.burstActive)
        assertTrue(bank.sharpOut == 0f)
        assertTrue(bank.burstOut == 0f)
    }
}
