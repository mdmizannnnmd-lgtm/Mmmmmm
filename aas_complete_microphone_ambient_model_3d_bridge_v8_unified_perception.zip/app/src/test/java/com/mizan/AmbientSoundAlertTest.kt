package com.mizan

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AmbientSoundAlertTest {
    @Test
    fun disabledAlertDoesNotEmitEvents() {
        val alert = AmbientSoundAlert()

        assertFalse(alert.update(peakDbfs = -5.0, centroidHz = 8000f, nowMs = 5000L))
        assertTrue(alert.eventCount == 0)
    }

    @Test
    fun thresholdCrossingAlertsOnceUntilSignalFallsBelowHysteresis() {
        val alert = AmbientSoundAlert().apply { enabled = true }

        assertTrue(alert.update(peakDbfs = -10.0, centroidHz = 5000f, nowMs = 5000L))
        assertFalse(alert.update(peakDbfs = -10.0, centroidHz = 5000f, nowMs = 5200L))
        assertFalse(alert.update(peakDbfs = -45.0, centroidHz = 1000f, nowMs = 5300L))
        assertTrue(alert.update(peakDbfs = -10.0, centroidHz = 5000f, nowMs = 7000L))
        assertTrue(alert.eventCount == 2)
    }

    @Test
    fun lowPeakOrCentroidDoesNotAlert() {
        val alert = AmbientSoundAlert().apply { enabled = true }

        assertFalse(alert.update(peakDbfs = -40.0, centroidHz = 5000f, nowMs = 5000L))
        assertFalse(alert.update(peakDbfs = -10.0, centroidHz = 1000f, nowMs = 7000L))
    }
}
