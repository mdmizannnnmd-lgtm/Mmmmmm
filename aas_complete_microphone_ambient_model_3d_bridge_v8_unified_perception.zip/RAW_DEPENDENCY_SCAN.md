# Complete Microphone-Driven Dependency Scan

## Scope
Scanned the v3 project source tree, Android manifest, Gradle configuration, native/JNI presence, and direct Android media/camera/sensor API references.

Project source count observed:
- 235 Kotlin source files under `app/src/main/java`
- 355 total files in the ZIP
- 239 Kotlin files were reported in the previous structural pass; this scan uses the current extracted v3 tree and counts 235 Kotlin files under the Java source root. The difference should be reconciled before release packaging.

## Functional classification
The classification is overlapping: a class can belong to multiple categories.

- MIC/AUDIO keyword/API footprint: 190
- UI/BOARD footprint: 175
- SENSOR footprint: 100
- CAMERA/VISION footprint: 87
- OUTPUT/PLAYBACK footprint: 73
- OTHER: 2

## Authoritative microphone path
Current authoritative capture owner:

`AudioProcessor -> AudioRecord -> RawMicBus`

Raw components:
- `AudioProcessor.kt`
- `RawMicBus.kt`
- `RawMicFrame.kt`
- `RawMicApi.kt`
- `RawMicDiagnostics.kt`

The scan found only two source files that directly construct/use `AudioRecord`:

1. `AudioProcessor.kt` — authoritative capture path.
2. `ArAudioMonitor.kt` — compatibility/secondary capture path.

This is the most important remaining microphone bypass. It should not be removed; instead it should be explicitly marked as compatibility mode and prevented from competing with the authoritative capture path when both are active.

## RawMicBus consumers found
Direct references were found in:

- `AudioProcessor.kt`
- `ArAudioMonitor.kt`
- `RawMicApi.kt`
- `RawMicBus.kt`
- `RawMicFrame.kt`
- `SkinAtomspare3dBoard.kt`
- `VisualShieldView.kt`

A large number of audio boards are instead fed indirectly through `AudioProcessor` callbacks/values. This is not necessarily incorrect, but it means they do not all consume the exact raw frame metadata directly.

## Playback/output gap
Direct `AudioTrack` usage: **none found**.

Direct `MediaPlayer` usage:
- `SdSoundBank.kt`
- `SkinAtomspare3dBoard.kt`

Therefore the project has playback, but no general real-time processed-PCM output engine.

Required additive layer:

`RawMicBus -> DSP pipeline -> output PCM -> AudioTrack`

Existing MediaPlayer functionality must remain untouched for compatibility.

## Android audio effects gap
No direct source usage found for:
- `AcousticEchoCanceler`
- `NoiseSuppressor`
- `AutomaticGainControl`
- `DynamicsProcessing`
- `Equalizer`
- `BassBoost`
- `LoudnessEnhancer`

These should be optional capability modules, never assumed to exist on every device.

## Echo gap
Existing:
- `EchoEngine.kt`
- `EchoEffectProtection.kt`
- echo-related boards/panels

Missing for true acoustic echo cancellation:
- playback/reference signal tap
- synchronized mic/reference frames
- adaptive acoustic path/filter
- convergence/stability management
- measured latency compensation

Detection/protection must remain distinct from true AEC.

## ANC gap
Existing anti-sound/protection concepts do not establish hardware-style ANC.

True ANC requires a synchronized reference, low-latency output, acoustic-path modeling/adaptation, and device/headphone-specific behavior.

## Camera/vision classification
Camera/vision related components include:
- `CameraManager.kt`
- `ArCoreCameraRenderer.kt`
- `ArCoreMeasureBoard.kt`
- `ArWorldActivity.kt`
- `HumanCameraDetector.kt`
- `OnnxCameraMixer.kt`
- `PoseSegEyeBodyBoard.kt`
- `WholeBodyPose133.kt`
- `YoloObbCatalog.kt`
- `YoloObbGameTrack.kt`
- `YoloSegHuman3D.kt`

These should remain, but each feature needs an explicit source policy: MIC, CAMERA, SENSOR, HYBRID, or STATIC. This prevents a visual feature from being represented as microphone-driven when it is not.

## Sensor classification
Sensor-related components include motion/game sensor hubs, heart-rate-related code, EMF-related code, and sensor-gated boards.

They should remain available but should not silently override microphone-derived state. A central source/provenance model is recommended.

## Configuration gap
There is no single authoritative configuration object covering all microphone/DSP/output/protection/camera/sensor options.

Recommended additive model:

`AppSettings`
- `RawMicSettings`
- `DspSettings`
- `EchoSettings`
- `NoiseSettings`
- `OutputSettings`
- `ProtectionSettings`
- `DetectionSettings`
- `CameraSettings`
- `BluetoothSettings`
- `DebugSettings`

Existing individual settings should remain as compatibility accessors.

## Persistence gap
Settings should have one persistent source of truth and survive Activity recreation/service restart. Existing settings APIs must remain compatible.

## Route-management gap
Add a central audio route manager for:
- built-in microphone
- wired microphone/headset
- Bluetooth microphone
- USB microphone
- built-in speaker
- wired headphones
- Bluetooth output
- USB output

Route changes should be observable by the DSP/output layer.

## Lifecycle gap
Audit all microphone/audio consumers for:
- permission denial/revocation
- audio focus loss/regain
- phone-call interruption
- Bluetooth connect/disconnect
- wired headset insertion/removal
- screen-off/background
- service restart
- process recreation
- microphone unavailable/error recovery

## Real-time performance gap
`RawMicBus` is safe enough for the current snapshot/listener architecture, but the full graph needs a real-time audit.

Avoid heavy work, allocations, UI work, ML inference, camera processing, network access, and disk I/O directly on the capture thread.

For sustained operation, consider an additive ring-buffer/pool implementation while preserving the existing API.

## Latency/health gap
Add:
- capture latency
- DSP processing duration
- output write latency
- buffer underrun/overrun counters
- dropped-frame counters
- callback jitter
- end-to-end estimated latency

`RawMicDiagnostics` is the base for this but does not yet provide complete end-to-end measurement.

## Calibration gap
Current dBFS values should not be presented as calibrated SPL. Add an explicit calibration layer if physical sound-pressure estimates are required.

## Security/configuration gap
Manifest currently contains `android:usesCleartextTraffic="true"`. This should be reviewed and restricted for release builds unless cleartext is intentionally required.

## Testing gap
Current tests are far smaller than the feature surface. Add tests for:
- PCM correctness
- mono/stereo
- sample-rate fallback
- silence/clipping/burst input
- FFT/pitch/centroid
- thresholds/hysteresis
- echo/protection state
- raw frame ordering
- subscriber failure isolation
- audio focus
- route changes
- Bluetooth
- service lifecycle
- permission lifecycle
- DSP latency
- output failure/recovery

## Final integration target

`Physical Mic`
`  -> AudioRecord`
`  -> AudioProcessor`
`  -> RawMicBus`
`  -> Source/Provenance layer`
`  -> Unified DSP graph`
`  -> optional AEC/NS/AGC/effects`
`  -> Protection/Limiter`
`  -> Output mixer`
`  -> AudioTrack`
`  -> physical output`

Existing boards, camera systems, sensor systems, MediaPlayer playback, and compatibility paths remain in parallel and are not deleted.

## No-removal rule
This scan identifies integration gaps only. It does not recommend deleting existing project features. The implementation strategy should be additive, with compatibility adapters where an existing component cannot yet consume the new central path.
