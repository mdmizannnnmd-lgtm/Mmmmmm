# Microphone-Driven / RAW Architecture

- `AudioProcessor` is the sole owner of `AudioRecord`.
- `RawMicBus` receives the actual PCM16 microphone frame from `AudioProcessor`.
- All boards remain UI/state modules; they are driven by the live analysis path rather than creating their own microphone readers.
- `rawComplete` defaults to `true` across the existing boards.
- Visual pseudo-random variation was replaced with deterministic values derived from the live microphone frame.
- `ArAudioMonitor` remains a read-only auxiliary monitor for AR; it should not be started concurrently with `AudioProcessor` if exclusive microphone ownership is required.
- `rawComplete` means the analysis path does not apply its optional soft gate; it does **not** mean that Android can bypass hardware DSP, AGC, AEC, or vendor microphone processing.

## RAW COMPLETE PASS (additive)

This pass preserves the existing project components and adds a stronger raw-frame contract:

- `AudioProcessor` remains the primary `AudioRecord` owner.
- `RawMicBus` now retains the latest untouched PCM16 frame and exposes defensive snapshots.
- `RawMicBus.subscribe { ... }` provides a real-time raw-frame stream to consumers without opening another microphone device.
- `RawMicFrame` carries PCM16, length, sample rate, channels, sequence, timestamp, RMS, peak, dBFS, dominant frequency and centroid.
- `ArAudioMonitor` defaults to the shared raw microphone stream. Its previous standalone `AudioRecord` implementation is retained as an explicit `sharedRawMic=false` compatibility path.
- Raw publication occurs before any derived protection/feedback scaling, so analysis consumers can distinguish the source PCM from derived control values.
