# Camera-to-eye-gaze additive update

This patch is additive. It does not remove or replace the existing camera detector, microphone capture, audio processing, anatomy renderer, segmentation, or board APIs.

## New files / changes

- `CameraGazeController.kt`: converts fresh person detections into bounded and smoothed normalized gaze values. It checks detector readiness, freshness, confidence, finite coordinates, and applies dead-zone filtering. Stale detections hold briefly, then return to neutral.
- `VisualShieldView.kt`: optionally forwards camera detections into the controller and writes its output to the existing anatomy gaze fields.
- `activity_main.xml`: adds a separate `Camera target drives both 3D eye gazes` switch.
- `MainActivity.kt`: binds the switch to the new setting.

## Usage

Open the LIVE HUMAN CAMERA controls and enable **Camera target drives both 3D eye gazes**. The camera/body tracking setting remains independent. Disable camera gaze to reset the gaze values to neutral and return to the existing gaze sources.

## Behavior and limits

- Input: existing ML Kit `HumanDetection` center coordinates in normalized camera-frame space.
- Output: existing `Anatomy3DBoard.gazeLx/gazeLy/gazeRx/gazeRy` fields.
- This is a screen/camera-frame target-following approximation, not calibrated 3D eye tracking or gaze estimation from a person's iris.
- The current `HumanDetection` contains a person center, not a persistent multi-object tracker identity or true depth. The controller therefore follows the detected person centroid.
- No camera frame is stored by this feature.

## Build validation

The source ZIP was updated in this environment. Android Gradle build validation could not run because the Gradle wrapper distribution download was blocked by unavailable network DNS (`services.gradle.org`). Please run `./gradlew assembleDebug` in Android Studio or an environment with Gradle/Android SDK access.
