# RAW Complete additive update

This update preserves the existing project and adds capabilities without deleting existing boards or compatibility paths.

## Added
- Exact interleaved PCM16 retention from `AudioRecord` for mono/stereo capture.
- Existing mono PCM analysis path remains unchanged for compatibility.
- `RawMicApi` read-only facade for all raw microphone state.
- `RawMicDiagnostics` counters for published frames, empty reads, read errors, listener errors, and observed callback latency.
- Defensive snapshots for both mono and exact interleaved raw PCM.
- Raw frame metadata remains synchronized with sequence/timestamp/sample-rate/channel information.

## Important
The raw path is an input/capture and analysis architecture. It does not claim that generated inverse audio is hardware ANC. Actual acoustic cancellation requires a playback reference, device routing, low-latency output, acoustic-path adaptation, and real-device validation.
